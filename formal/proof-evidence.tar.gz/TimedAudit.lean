import TimedProof

namespace TimedAudit
open Approved FormalSpecAgent TypedIR TypedMachine BatchMachine BatchTotality
open TimedObligations TypedFiringContracts BatchPreservation

theorem initial : Admitted model declaredStates declaredTimers Approved.initial :=
  TimedProof.initial

theorem timers : TimerContracts model declaredStates declaredTimers :=
  TimedProof.timers

theorem preservation :
    Each (fun p => FiringPreserves model p.1 p.2) (rawChecks model declaredTimers) :=
  TimedProof.preservation

theorem advance (s : Snapshot) (limit : Int)
    (admitted : Admitted model declaredStates declaredTimers s) (bound : s.now ≤ limit) :
    ∃ batch, BatchMachine.advance model s limit = .ok batch ∧
      Drained model declaredStates declaredTimers limit batch.after ∧
      Preserved declaredTimers model batch :=
  advance_total_with_timers model declaredStates declaredTimers limit timers s admitted bound

theorem dispatch (s : Snapshot) (limit : Int)
    (admitted : Admitted model declaredStates declaredTimers s) (bound : s.now ≤ limit)
    (event : Nat) (fields : Values) (declared : event ∈ model.externalEvents) :
    ∃ prefixBatch, BatchMachine.advance model s limit = .ok prefixBatch ∧
      Drained model declaredStates declaredTimers limit prefixBatch.after ∧
      (if (enabled model prefixBatch.after event fields).isEmpty then
        BatchMachine.dispatch model s event fields limit = .error .uncovered ∧
          rollback s (BatchMachine.dispatch model s event fields limit) = s
      else ∃ batch, BatchMachine.dispatch model s event fields limit = .ok batch ∧
        Admitted model declaredStates declaredTimers batch.after ∧ batch.after.now = limit ∧
        Preserved declaredTimers model batch) :=
  dispatch_success_or_uncovered model declaredStates declaredTimers limit timers s admitted bound
    event fields declared (external_raw_from_checks model declaredTimers preservation event declared)

end TimedAudit
#print axioms TimedAudit.initial
#print axioms TimedAudit.timers
#print axioms TimedAudit.preservation
#print axioms TimedAudit.advance
#print axioms TimedAudit.dispatch

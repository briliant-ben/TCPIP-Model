import unittest
import support as s
class RealTcpdumpLog(unittest.TestCase):
 def test_header_and_stats(self):
  text='tcpdump: listening on tap0, link-type EN10MB (Ethernet), snapshot length 65535 bytes\n2 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n'
  self.assertEqual(s.capture_stats(text),dict(captured=2,received=3,dropped=0))
 def test_bad_stat_not_ignored(self):
  for stat in ['-1 packets captured','bad packets captured','0 packets dropped by kernel\n0 packets dropped by kernel']:
   text='tcpdump: listening on tap0\n2 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n'+stat
   with self.assertRaises(ValueError):s.capture_stats(text)

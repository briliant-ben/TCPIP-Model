import unittest
import struct
import copy
import support


def make_global_header(endian, snap=65535, link=1, vmaj=2, vmin=4, thiszone=0, sigfig=0):
    if endian == '<':
        magic = struct.pack('<I', 0xa1b2c3d4)
    else:
        magic = struct.pack('>I', 0xa1b2c3d4)
    return magic + struct.pack(endian + 'HHIIII', vmaj, vmin, thiszone, sigfig, snap, link)


def make_packet_record(endian, ts_sec, ts_frac, data):
    incl_len = len(data)
    orig_len = incl_len
    return struct.pack(endian + 'IIII', ts_sec, ts_frac, incl_len, orig_len) + data


def build_pcap(packets, endian='<'):
    raw = make_global_header(endian)
    for pkt in packets:
        raw += make_packet_record(endian, pkt['ts_sec'], pkt['ts_frac'], pkt['data'])
    return raw


class TestElapsedMs(unittest.TestCase):
    def test_valid_floor(self):
        self.assertEqual(support.elapsed_ms(1000000, 2000000), 1)
        self.assertEqual(support.elapsed_ms(1000000, 1999999), 0)
    def test_zero_origin(self):
        self.assertEqual(support.elapsed_ms(0, 1000000), 1)
    def test_rejects_bool(self):
        with self.assertRaises(ValueError):
            support.elapsed_ms(True, 100)
        with self.assertRaises(ValueError):
            support.elapsed_ms(0, True)
    def test_rejects_negative(self):
        with self.assertRaises(ValueError):
            support.elapsed_ms(-1, 100)
    def test_rejects_sample_less_origin(self):
        with self.assertRaises(ValueError):
            support.elapsed_ms(100, 99)


class TestCaptureStats(unittest.TestCase):
    def test_valid(self):
        text = "3 packets captured\n3 packets received by filter\n0 packets dropped by kernel"
        self.assertEqual(support.capture_stats(text),
                         {'captured': 3, 'received': 3, 'dropped': 0})
    def test_singular(self):
        text = "1 packet captured\n1 packet received by filter\n0 packets dropped by kernel"
        self.assertEqual(support.capture_stats(text),
                         {'captured': 1, 'received': 1, 'dropped': 0})
    def test_dropped_nonzero(self):
        text = "3 packets captured\n3 packets received by filter\n1 packets dropped by kernel"
        with self.assertRaises(ValueError):
            support.capture_stats(text)
    def test_missing_stats(self):
        text = "3 packets captured"
        with self.assertRaises(ValueError):
            support.capture_stats(text)
    def test_extra_header_line_ignored(self):
        text = ("tcpdump: listening on tap0, link-type EN10MB (Ethernet), snapshot length 65535 bytes\n"
                "2 packets captured\n3 packets received by filter\n0 packets dropped by kernel")
        self.assertEqual(support.capture_stats(text),
                         {'captured': 2, 'received': 3, 'dropped': 0})
    def test_arbitrary_nonstat_line_ignored(self):
        text = ("some diagnostic info\n"
                "2 packets captured\n3 packets received by filter\n0 packets dropped by kernel")
        self.assertEqual(support.capture_stats(text),
                         {'captured': 2, 'received': 3, 'dropped': 0})
    def test_negative(self):
        text = "-1 packets captured\n3 packets received by filter\n0 packets dropped by kernel"
        with self.assertRaises(ValueError):
            support.capture_stats(text)
    def test_captured_not_equal_received_ok(self):
        text = "3 packets captured\n5 packets received by filter\n0 packets dropped by kernel"
        self.assertEqual(support.capture_stats(text),
                         {'captured': 3, 'received': 5, 'dropped': 0})
    def test_duplicate_stat(self):
        text = "3 packets captured\n4 packets captured\n0 packets dropped by kernel"
        with self.assertRaises(ValueError):
            support.capture_stats(text)
    def test_duplicate_dropped(self):
        text = "3 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n0 packets dropped by kernel"
        with self.assertRaises(ValueError):
            support.capture_stats(text)
    def test_malformed_stat_line_rejected(self):
        # Line contains stat keyword but not exact match
        base = "2 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n"
        bad_lines = [
            "-1 packets captured",
            "bad packets captured",
            "packets captured",
            "3 packets captured extra",
            "0 packets dropped by kernel extra"
        ]
        for bad in bad_lines:
            text = base + bad
            with self.assertRaises(ValueError):
                support.capture_stats(text)
    def test_trailing_newline(self):
        text = "2 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n"
        self.assertEqual(support.capture_stats(text),
                         {'captured': 2, 'received': 3, 'dropped': 0})


class TestPcapRecords(unittest.TestCase):
    def test_empty_pcap(self):
        raw = make_global_header('<')
        self.assertEqual(support.pcap_records(raw), [])
    def test_little_endian_one_packet(self):
        data = b'\x00' * 20
        raw = build_pcap([{'ts_sec': 1, 'ts_frac': 2, 'data': data}], '<')
        records = support.pcap_records(raw)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]['timestamp_ns'], 1 * 1_000_000_000 + 2 * 1000)
        self.assertEqual(records[0]['raw'], data)
    def test_big_endian(self):
        data = b'\x00' * 20
        raw = build_pcap([{'ts_sec': 1, 'ts_frac': 2, 'data': data}], '>')
        records = support.pcap_records(raw)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]['timestamp_ns'], 1 * 1_000_000_000 + 2 * 1000)
    def test_multiple_packets(self):
        data1 = b'\x01' * 14
        data2 = b'\x02' * 18
        raw = build_pcap([
            {'ts_sec': 1, 'ts_frac': 0, 'data': data1},
            {'ts_sec': 1, 'ts_frac': 1000, 'data': data2}
        ], '<')
        records = support.pcap_records(raw)
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]['raw'], data1)
        self.assertEqual(records[1]['raw'], data2)
    def test_nanosecond_magic_rejected(self):
        raw = make_global_header('<')
        raw = b'\x4d\x3c\xb2\xa1' + raw[4:]
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_unsupported_magic(self):
        raw = b'\x00\x01\x02\x03' + b'\x00' * 20
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_version_not_2_4(self):
        raw = make_global_header('<', vmaj=2, vmin=3)
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_link_not_ethernet(self):
        raw = make_global_header('<', link=0)
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_snaplen_out_of_range(self):
        raw = make_global_header('<', snap=0)
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
        raw = make_global_header('<', snap=65536)
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_frac_too_large(self):
        data = b'\x00' * 14
        raw = build_pcap([{'ts_sec': 1, 'ts_frac': 1000000, 'data': data}], '<')
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_captured_gt_snap(self):
        raw = make_global_header('<', snap=10)
        data = b'\x00' * 14
        raw += make_packet_record('<', 1, 0, data)
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_truncated_capture(self):
        data = b'\x00' * 14
        packet = make_packet_record('<', 1, 0, data)
        # modify orig_len to be larger
        packet = packet[:12] + struct.pack('<I', 20) + packet[16:]
        raw = make_global_header('<') + packet
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_too_short_packet(self):
        data = b'\x00' * 13
        raw = build_pcap([{'ts_sec': 1, 'ts_frac': 0, 'data': data}], '<')
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_incomplete_data(self):
        data = b'\x00' * 14
        raw = make_global_header('<') + make_packet_record('<', 1, 0, data)[:20]
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_non_decreasing_timestamps(self):
        data1 = b'\x00' * 14
        data2 = b'\x01' * 14
        raw = build_pcap([
            {'ts_sec': 2, 'ts_frac': 0, 'data': data1},
            {'ts_sec': 1, 'ts_frac': 0, 'data': data2}
        ], '<')
        with self.assertRaises(ValueError):
            support.pcap_records(raw)
    def test_trailing_bytes(self):
        data = b'\x00' * 14
        raw = build_pcap([{'ts_sec': 1, 'ts_frac': 0, 'data': data}], '<') + b'\x00'
        with self.assertRaises(ValueError):
            support.pcap_records(raw)


class TestQuietOk(unittest.TestCase):
    def test_valid_true(self):
        records = [{'timestamp_ns': 1000000000}]
        self.assertTrue(support.quiet_ok(records, 1100000000, quiet_ms=100))
    def test_valid_false_due_to_short_quiet(self):
        records = [{'timestamp_ns': 1000000000}]
        self.assertFalse(support.quiet_ok(records, 1099999999, quiet_ms=100))
    def test_last_gt_stop_returns_false(self):
        records = [{'timestamp_ns': 1000000000}]
        self.assertFalse(support.quiet_ok(records, 999999999, quiet_ms=100))
    def test_empty_records_returns_false(self):
        self.assertFalse(support.quiet_ok([], 1100000000))
    def test_bool_rejected(self):
        records = [{'timestamp_ns': 1000000000}]
        with self.assertRaises(ValueError):
            support.quiet_ok(records, True, quiet_ms=100)
        with self.assertRaises(ValueError):
            support.quiet_ok(records, 1100000000, quiet_ms=True)
    def test_record_timestamp_bool(self):
        records = [{'timestamp_ns': True}]
        with self.assertRaises(ValueError):
            support.quiet_ok(records, 1100000000)
    def test_non_list_records(self):
        with self.assertRaises(ValueError):
            support.quiet_ok({}, 1100000000)
    def test_missing_timestamp_key(self):
        records = [{}]
        with self.assertRaises(ValueError):
            support.quiet_ok(records, 1100000000)


class TestOperationResult(unittest.TestCase):
    def test_error_uncovered_event(self):
        rows = [{'status': 'error', 'failure': 'uncovered_event'}]
        res = support.operation_result(rows)
        self.assertEqual(res, {'status': 'error', 'category': 'model_gap', 'failure': 'uncovered_event', 'frames': [], 'services': []})
    def test_error_rule_conflict(self):
        rows = [{'status': 'error', 'failure': 'rule_conflict'}]
        res = support.operation_result(rows)
        self.assertEqual(res['category'], 'rule_conflict')
    def test_error_invariant(self):
        rows = [{'status': 'error', 'failure': 'invariant: bad'}]
        res = support.operation_result(rows)
        self.assertEqual(res['category'], 'invariant_failure')
    def test_error_driver(self):
        rows = [{'status': 'error', 'failure': 'something'}]
        res = support.operation_result(rows)
        self.assertEqual(res['category'], 'driver_failure')
    def test_error_missing_failure(self):
        rows = [{'status': 'error'}]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_error_empty_failure(self):
        rows = [{'status': 'error', 'failure': ''}]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_bad_preceding_status(self):
        rows = [{'status': 'other'}, {'status': 'ok'}]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_ok_ethernet_tx(self):
        rows = [
            {'status': 'transition', 'emitted': [{'message': 'ethernet.tx', 'fields': {'frame': [1,2,3]}}]},
            {'status': 'ok'}
        ]
        res = support.operation_result(rows)
        self.assertEqual(res['status'], 'ok')
        self.assertIsNone(res['category'])
        self.assertIsNone(res['failure'])
        self.assertEqual(res['frames'], [bytes([1,2,3])])
        self.assertEqual(res['services'], [])
    def test_ok_multiple_emissions(self):
        rows = [
            {'status': 'transition', 'emitted': [
                {'message': 'ethernet.tx', 'fields': {'frame': [4,5]}},
                {'message': 'service.call', 'fields': {'a': 1, 'b': 'x'}}
            ]},
            {'status': 'ok'}
        ]
        res = support.operation_result(rows)
        self.assertEqual(res['frames'], [bytes([4,5])])
        self.assertEqual(len(res['services']), 1)
        self.assertEqual(res['services'][0]['message'], 'service.call')
        self.assertEqual(res['services'][0]['fields'], {'a': 1, 'b': 'x'})
    def test_ok_deep_copy(self):
        original_emission = {'message': 'service.call', 'fields': {'list': [1,2]}}
        rows = [
            {'status': 'transition', 'emitted': [original_emission]},
            {'status': 'ok'}
        ]
        res = support.operation_result(rows)
        # mutate original after call
        original_emission['fields']['list'].append(3)
        self.assertNotEqual(res['services'][0]['fields']['list'], [1,2,3])
    def test_ok_terminal_emitted_rejected(self):
        rows = [
            {'status': 'transition', 'emitted': []},
            {'status': 'ok', 'emitted': [1]}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_transition_missing_emitted(self):
        rows = [
            {'status': 'transition'},
            {'status': 'ok'}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_emission_not_dict(self):
        rows = [
            {'status': 'transition', 'emitted': [1]},
            {'status': 'ok'}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_ethernet_tx_bad_fields(self):
        rows = [
            {'status': 'transition', 'emitted': [{'message': 'ethernet.tx', 'fields': {'other': [1]}}]},
            {'status': 'ok'}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_frame_list_bool_rejected(self):
        rows = [
            {'status': 'transition', 'emitted': [{'message': 'ethernet.tx', 'fields': {'frame': [True]}}]},
            {'status': 'ok'}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_frame_list_non_int_rejected(self):
        rows = [
            {'status': 'transition', 'emitted': [{'message': 'ethernet.tx', 'fields': {'frame': [1, 'a']}}]},
            {'status': 'ok'}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)
    def test_frame_list_out_of_range(self):
        rows = [
            {'status': 'transition', 'emitted': [{'message': 'ethernet.tx', 'fields': {'frame': [256]}}]},
            {'status': 'ok'}
        ]
        with self.assertRaises(ValueError):
            support.operation_result(rows)


class TestRecordError(unittest.TestCase):
    def test_error_none_creates(self):
        report = {'error': None}
        support.record_error(report, 'driver_failure', 'some reason')
        self.assertEqual(report['error'], {'category': 'driver_failure', 'reason': 'some reason'})
        self.assertEqual(report['secondary_errors'], [])
    def test_error_existing_appends(self):
        first_error = {'category': 'model_gap', 'reason': 'first'}
        report = {'error': first_error, 'secondary_errors': []}
        support.record_error(report, 'rule_conflict', 'second')
        self.assertIs(report['error'], first_error)
        self.assertEqual(report['secondary_errors'], [{'category': 'rule_conflict', 'reason': 'second'}])
    def test_invalid_category(self):
        report = {'error': None}
        with self.assertRaises(ValueError):
            support.record_error(report, 'bad_category', 'reason')
    def test_non_dict_report(self):
        with self.assertRaises(ValueError):
            support.record_error([], 'driver_failure', 'reason')
    def test_missing_error_key(self):
        report = {}
        with self.assertRaises(ValueError):
            support.record_error(report, 'driver_failure', 'reason')
    def test_reason_not_str(self):
        report = {'error': None}
        with self.assertRaises(ValueError):
            support.record_error(report, 'driver_failure', 123)


if __name__ == '__main__':
    unittest.main()

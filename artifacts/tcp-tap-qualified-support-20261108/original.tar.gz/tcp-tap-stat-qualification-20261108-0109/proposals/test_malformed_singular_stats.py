import unittest
import support as s
class MalformedSingularStats(unittest.TestCase):
 def test_additional_malformed_singular_stats_are_not_ignored(self):
  valid='tcpdump: listening on tap0\n2 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n'
  for bad in ['-1 packet dropped by kernel','bad packet captured','-1   packet   received by filter']:
   with self.subTest(bad=bad):
    with self.assertRaises(ValueError):s.capture_stats(valid+bad+'\n')

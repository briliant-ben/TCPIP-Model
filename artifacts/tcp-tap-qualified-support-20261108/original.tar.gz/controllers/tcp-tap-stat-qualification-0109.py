from pathlib import Path
import ast,hashlib,json,os,resource,shutil,subprocess,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-tap-stat-qualification-20261108-0109';O.mkdir(exist_ok=False);PRE=P/'candidates/tcp-tap-pure-support-log-20261108-0107';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def status(**x):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,network_executed=False,prototype_complete=False,**x))
try:
 status(status='running',stage='actual_additional_malformed_stat_counterexample')
 assert json.loads((PRE/'status.json').read_text())['status']=='pure_candidate_ready_controller_review_required'
 d=O/'proposals';shutil.copytree(PRE/'proposals',d,ignore=shutil.ignore_patterns('__pycache__'))
 EXTRA='''import unittest
import support as s
class MalformedSingularStats(unittest.TestCase):
 def test_additional_malformed_singular_stats_are_not_ignored(self):
  valid='tcpdump: listening on tap0\\n2 packets captured\\n3 packets received by filter\\n0 packets dropped by kernel\\n'
  for bad in ['-1 packet dropped by kernel','bad packet captured','-1   packet   received by filter']:
   with self.subTest(bad=bad):
    with self.assertRaises(ValueError):s.capture_stats(valid+bad+'\\n')
'''
 (d/'test_malformed_singular_stats.py').write_text(EXTRA);save('extra-freeze.json',dict(sha256=hashlib.sha256(EXTRA.encode()).hexdigest(),frozen_before_patch=True))
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(20,20));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
 def run(name):
  with(O/name).open('w')as log:return subprocess.run([str(PY),'-B',str(d/'run_pure_tests.py')],cwd=d,stdout=log,stderr=subprocess.STDOUT,timeout=30,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'}).returncode
 before=run('original-extra-counterexample.log');assert before!=0,'expected original helper failure not observed'
 f=d/'support.py';old=f.read_text();needle='            if keyword in line:';replacement="            if re.search(r'\\b' + keyword.replace('packets', r'packets?').replace(' ', r'\\s+') + r'\\b', line):"
 assert old.count(needle)==1;new=old.replace(needle,replacement);ast.parse(new);f.write_text(new)
 save('exact-patch.json',dict(origin='controller zero-API literal generic log-validation fix, NOT DeepSeek-authored',old=needle,new=replacement,before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=hashlib.sha256(new.encode()).hexdigest(),original_107_review_scope='unpatched helper only',original_independent_tests_unchanged=True))
 after=run('qualified-tests.log');assert after==0,'qualified helper tests failed'
 status(status='qualified_pure_helper_pass_controller_integration_required',stage='finished',original_counterexample_returncode=before,qualified_returncode=after,methods=73,independent_new_review=False,finished_at=time.time())
except Exception as e:
 status(status='failed_or_rejected',stage='stopped',error=str(e),finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

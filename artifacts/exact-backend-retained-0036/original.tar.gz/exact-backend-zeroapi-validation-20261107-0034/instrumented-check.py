import sys,json,unittest
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import protocol_lab.symbolic as sym
import protocol_lab.pipeline.runner as runner
checks=[];flows=[];verifies=[];errors=[]
original=sym.check;run=runner.run;verify=runner.verify
def observed(*a,**kw):
 if kw.get('out')is None:kw['out']=Path(sys.argv[2])/('actual-check-'+str(len(checks)))
 r=original(*a,**kw);checks.append(r);Path(sys.argv[2]+'/actual-checks.json').write_text(json.dumps(checks));return r
def observed_run(*a,**kw):
 r=run(*a,**kw);flows.append({'assessment':r.get('assessment'),'formal':r.get('stages',{}).get('formal')});return r
def observed_verify(*a,**kw):
 try:r=verify(*a,**kw);verifies.append(r);return r
 except ValueError as e:errors.append(str(e));raise
sym.check=observed;runner.run=observed_run;runner.verify=observed_verify
suite=unittest.defaultTestLoader.discover(sys.argv[1]+'/tests',pattern='test_solver_preprocessing.py');r=unittest.TextTestRunner(verbosity=2).run(suite)
core=[v for v in checks if v.get('model_semantic_sha256')=='d52526eebfacc3299c90a217d9b6515f8232f72b71230af14191b543ae28e648'and v.get('solver_preprocess')=='exact-v1'];corepass=any(v.get('status')=='bounded_pass'and v.get('safety_query')=='unsat'and v.get('overlap_query')=='unsat'and v.get('depth')==2 and v.get('solver_timeout_ms')==60000 for v in core)
policy_errors=[e for e in errors if any(k in e.lower()for k in ('preprocess','policy','tactic'))]
result=dict(tests=r.testsRun,errors=len(r.errors),failures=len(r.failures),skips=len(r.skipped),actual_core_bounded_pass=corepass,real_pipeline_runs=len(flows),positive_verifications=len(verifies),policy_rejections=policy_errors,flow_formal=[f['formal']for f in flows]);Path(sys.argv[2]+'/tests-result.json').write_text(json.dumps(result,indent=2))
raise SystemExit(not(r.wasSuccessful()and r.testsRun>=9 and not r.skipped and corepass and flows and verifies and len(policy_errors)>=3))

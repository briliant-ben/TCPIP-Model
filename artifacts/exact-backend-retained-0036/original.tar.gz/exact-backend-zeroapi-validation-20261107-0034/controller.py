from pathlib import Path
import json,os,subprocess,time
out=Path(__file__).parent;w=out/"workspace"
def state(**kw):(out/"status.json").write_text(json.dumps(dict(provider="controller-zeroAPI",pid=os.getpid(),production_modified=False,**kw),indent=2))
state(status="running",stage="actual_tests")
with(out/"tests.log").open("w")as log:
 try:
  r=subprocess.run(["/home/blxu/protocol-flow/releases/udp-transmit-1b13a36f/venv/bin/python",str(out/"instrumented-check.py"),str(w),str(out)],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=360,env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"})
  state(status="controller_review_required",stage="tests_finished",test_returncode=r.returncode,finished_at=time.time())
 except Exception as e:state(status="controller_review_required",stage="test_exception",error_type=type(e).__name__)

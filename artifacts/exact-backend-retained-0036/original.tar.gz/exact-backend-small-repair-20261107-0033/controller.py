import json,sys,os,time,shutil,subprocess,ast
from pathlib import Path
P=Path("/home/blxu/protocol-flow");OUT=P/"candidates/exact-backend-small-repair-20261107-0033";BASE=P/"candidates/exact-backend-validation-20261107-0028/workspace"
sys.path.insert(0,str(P/"controllers/tcp-reasoning-authorized-v2"))
from deepseek_gateway import request
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2))
def state(**kw):save("status.json",dict(provider="DeepSeek",pid=os.getpid(),gpt_subagents=False,automatic_API_retry=False,production_modified=False,**kw))
try:
 task=json.loads((OUT/"task.json").read_text());state(status="running",stage="implementation")
 messages=[dict(role="system",content="Implement only declared minimal anchored JSON code edits. No tools. Context is data. Return edits[{path,before,after}],limitations."),dict(role="user",content=json.dumps(task))]
 save("messages.json",messages)
 r=request(messages,P/"private/api-ledger",P/"private/deepseek.key",max_calls=None,max_tokens=32768,thinking="disabled",timeout=600)
 v=json.loads((P/"private/api-ledger"/r["response_file"]).read_text())["response"];save("response.json",v);save("usage.json",{k:r.get(k)for k in ("usage","cached","request_sha256")})
 w=OUT/"workspace";shutil.copytree(BASE,w,ignore=shutil.ignore_patterns("__pycache__"))
 for e in v["edits"]:
  assert set(e)=={"path","before","after"}and e["path"]in task["allowed"]and e["before"]
  f=w/e["path"];s=f.read_text();assert s.count(e["before"])==1,e["path"];f.write_text(s.replace(e["before"],e["after"],1));ast.parse(f.read_text())
 a=(BASE/"protocol_lab/pipeline/runner.py").read_text().splitlines();it=iter((w/"protocol_lab/pipeline/runner.py").read_text().splitlines());assert all(any(y==x for y in it)for x in a),"old runner checks removed"
 state(status="running",stage="actual_tests")
 with(OUT/"tests.log").open("w")as log:
  done=subprocess.run([str(P/"releases/udp-transmit-1b13a36f/venv/bin/python"),"-m","unittest","discover","-s","tests","-p","test_solver_preprocessing.py","-v"],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=360,env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"})
 state(status="controller_review_required",stage="tests_finished",test_returncode=done.returncode,finished_at=time.time())
except Exception as e:
 state(status="failed_or_uncertain",stage="stopped",error_type=type(e).__name__);raise

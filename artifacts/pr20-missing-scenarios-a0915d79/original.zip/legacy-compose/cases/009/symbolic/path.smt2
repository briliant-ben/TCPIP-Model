; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x5006 (= due_1_cache due_0_cache)))
 (let (($x5010 (= due_1_query 1000)))
 (let (($x1385 (= active_1_cache active_0_cache)))
 (let (($x5012 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4962 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x4961 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4999 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4998 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3534 (not v_1_rxudp_require_checksum)))
 (let ((?x5251 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x3128 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x5251)))))
 (let ((?x13838 (seq.unit (_ bv8 8))))
 (let ((?x3328 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x13838 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x3128))))))
 (let ((?x4182 (seq.unit (_ bv6 8))))
 (let ((?x348 (seq.unit (_ bv4 8))))
 (let ((?x4478 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x348 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x4182 ?x3328))))))
 (let ((?x7722 (seq.unit (_ bv2 8))))
 (let ((?x5254 (seq.unit (_ bv1 8))))
 (let ((?x2770 (seq.unit (_ bv0 8))))
 (let ((?x1796 (seq.++ ?x2770 (seq.++ ?x5254 (seq.++ ?x7722 ?x4478)))))
 (let ((?x1500 (seq.unit (_ bv26 8))))
 (let ((?x7518 (seq.++ ?x2770 (seq.++ ?x1500 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv148 8)) ?x1796))))))
 (let ((?x2635 (seq.unit (_ bv144 8))))
 (let ((?x4498 (seq.unit (_ bv31 8))))
 (let ((?x2879 (seq.unit (_ bv64 8))))
 (let ((?x297 (seq.unit (_ bv156 8))))
 (let ((?x7039 (seq.++ ?x297 (seq.++ ?x2879 (seq.++ ?x4498 (seq.++ ?x2635 ?x7518))))))
 (let ((?x2632 (seq.unit (_ bv192 8))))
 (let ((?x13837 (seq.++ ?x5254 (seq.++ ?x2632 (seq.++ ?x2770 (seq.++ ?x7722 (seq.++ ?x7722 ?x7039)))))))
 (let ((?x342 (seq.unit (_ bv187 8))))
 (let ((?x4670 (seq.unit (_ bv182 8))))
 (let ((?x1783 (seq.++ ?x4670 (seq.++ ?x342 (seq.++ ?x2632 (seq.++ ?x2770 (seq.++ ?x7722 ?x13837)))))))
 (let ((?x6478 (seq.unit (_ bv17 8))))
 (let ((?x219 (seq.++ ?x2770 (seq.++ ?x2879 (seq.++ ?x2770 (seq.++ ?x2879 (seq.++ ?x6478 ?x1783)))))))
 (let ((?x4977 (seq.unit (_ bv46 8))))
 (let ((?x2973 (seq.unit (_ bv69 8))))
 (let ((?x5349 (seq.++ ?x2973 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x4977 (seq.++ ?x2770 ?x219)))))))
 (let (($x19959 (= v_1_pending_packet ?x5349)))
 (let (($x19958 (= v_1_ip_checksum 46779)))
 (let (($x1752 (= v_1_udp_checksum 30612)))
 (let (($x1751 (= v_1_udp_raw_checksum 30612)))
 (let (($x4531 (= v_1_ip_length 46)))
 (let (($x1042 (= v_1_udp_length 26)))
 (let (($x4774 (= v_1_packet ?x5349)))
 (let ((?x4246 (seq.++ ?x7722 (seq.++ ?x5254 (seq.++ ?x2632 (seq.++ ?x2770 (seq.++ ?x7722 ?x7722)))))))
 (let ((?x5993 (seq.++ ?x2632 (seq.++ ?x2770 ?x4246))))
 (let ((?x4993 (seq.++ ?x2770 (seq.++ ?x2879 (seq.++ ?x6478 (seq.++ ?x4670 (seq.++ ?x342 ?x5993)))))))
 (let ((?x5801 (seq.++ ?x2770 (seq.++ ?x4977 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2879 ?x4993)))))))
 (let (($x3168 (= v_1_ip_wire (seq.++ ?x2973 (seq.++ ?x2770 ?x5801)))))
 (let ((?x4756 (seq.++ ?x2770 (seq.++ ?x2879 (seq.++ ?x6478 (seq.++ ?x2770 (seq.++ ?x2770 ?x5993)))))))
 (let ((?x4761 (seq.++ ?x2770 (seq.++ ?x4977 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2879 ?x4756)))))))
 (let (($x4764 (= v_1_ip_zero (seq.++ ?x2973 (seq.++ ?x2770 ?x4761)))))
 (let (($x5684 (= v_1_udp_wire ?x7039)))
 (let ((?x6817 (seq.++ ?x7722 (seq.++ ?x7722 (seq.++ ?x2770 (seq.++ ?x6478 (seq.++ ?x2770 ?x1500)))))))
 (let ((?x14341 (seq.++ ?x2770 (seq.++ ?x7722 (seq.++ ?x5254 (seq.++ ?x2632 (seq.++ ?x2770 ?x6817)))))))
 (let (($x4357 (= v_1_pseudoheader (seq.++ ?x2632 ?x14341))))
 (let ((?x7499 (seq.++ ?x2635 (seq.++ ?x2770 (seq.++ ?x1500 (seq.++ ?x2770 (seq.++ ?x2770 ?x1796)))))))
 (let (($x1873 (= v_1_udp_zero (seq.++ ?x297 (seq.++ ?x2879 (seq.++ ?x4498 ?x7499))))))
 (let (($x4496 (= v_1_payload ?x1796)))
 (let (($x3392 (= v_1_cache_ttl_ms 60000)))
 (let (($x5715 (= 0 v_1_retry_count)))
 (let (($x7487 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x7141 (= 1 state_1)))
 (let (($x1728 (not active_0_cache)))
 (let (($x1192 (or $x1728 (not (<= due_0_cache 0)))))
 (let (($x1726 (not active_0_query)))
 (let (($x1354 (or $x1726 (not (<= due_0_query 0)))))
 (let (($x2794 (= state_0 0)))
 (and $x2794 (>= 0 now_0) $x1354 $x1192 $x7141 $x7487 $x5715 $x3392 v_1_checksums_enabled $x4496 $x1873 $x4357 $x5684 $x4764 $x3168 $x4774 $x1042 $x4531 $x1751 $x1752 $x19958 $x19959 $x3534 $x4998 (= v_1_rxudp_disposition "none") $x4999 $x4961 $x4962 $x5012 (= v_1_echo_disposition "none") active_1_query $x1385 $x5010 $x5006))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3838 (= due_2_query due_1_query)))
 (let (($x6298 (not active_2_query)))
 (let (($x2580 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2602 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x4392 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x4391 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x3311 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x3310 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x7118 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x5074 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x562 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x3494 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x5062 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x4587 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x3738 (= v_2_ip_length v_1_ip_length)))
 (let (($x591 (= v_2_udp_length v_1_udp_length)))
 (let (($x5964 (= v_2_packet v_1_packet)))
 (let (($x2798 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2720 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x376 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x5264 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x6096 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x4413 (= v_2_payload v_1_payload)))
 (let (($x570 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3624 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x4512 (= 0 v_2_retry_count)))
 (let ((?x2770 (seq.unit (_ bv0 8))))
 (let ((?x5908 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.unit (_ bv2 8))))))))
 (let ((?x7722 (seq.unit (_ bv2 8))))
 (let (($x4856 (= v_2_peer_mac (seq.++ ?x7722 ?x5908))))
 (let (($x1488 (= 2 state_2)))
 (let (($x4855 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x4539 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x5094 (seq.len v_1_pending_packet)))
 (let (($x5095 (<= 28 ?x5094)))
 (let (($x4641 (= state_1 1)))
 (and $x4641 $x5095 $x4539 $x4855 $x1488 $x4856 $x4512 $x3624 $x570 $x4413 $x6096 $x5264 $x376 $x2720 $x2798 $x5964 $x591 $x3738 $x4587 $x5062 $x3494 $x562 $x5074 $x7118 $x3310 $x3311 $x4391 $x4392 $x2602 $x2580 $x6298 active_2_cache $x3838 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5251 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x3128 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x5251)))))
 (let ((?x13838 (seq.unit (_ bv8 8))))
 (let ((?x3328 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x13838 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x3128))))))
 (let ((?x4182 (seq.unit (_ bv6 8))))
 (let ((?x348 (seq.unit (_ bv4 8))))
 (let ((?x4478 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x348 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x4182 ?x3328))))))
 (let ((?x7722 (seq.unit (_ bv2 8))))
 (let ((?x5254 (seq.unit (_ bv1 8))))
 (let ((?x2770 (seq.unit (_ bv0 8))))
 (let ((?x1796 (seq.++ ?x2770 (seq.++ ?x5254 (seq.++ ?x7722 ?x4478)))))
 (= input_0_app.send_data ?x1796)))))))))))))
(assert
 (= 28 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x2632 (seq.unit (_ bv192 8))))
(let ((?x2782 (seq.++ ?x2632 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x5254 (seq.unit (_ bv1 8))))
(let ((?x2770 (seq.unit (_ bv0 8))))
(let ((?x2550 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x5254 ?x2782)))))))
(let ((?x7722 (seq.unit (_ bv2 8))))
(let ((?x3554 (seq.++ ?x2632 (seq.++ ?x2770 (seq.++ ?x7722 (seq.++ ?x7722 (seq.++ ?x7722 ?x2550)))))))
(let ((?x4250 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x7722 ?x3554)))))))
(let ((?x348 (seq.unit (_ bv4 8))))
(let ((?x4182 (seq.unit (_ bv6 8))))
(let ((?x4667 (seq.++ ?x4182 (seq.++ ?x348 (seq.++ ?x2770 (seq.++ ?x7722 (seq.++ ?x7722 ?x4250)))))))
(let ((?x13838 (seq.unit (_ bv8 8))))
(let ((?x1737 (seq.++ ?x4182 (seq.++ ?x2770 (seq.++ ?x5254 (seq.++ ?x13838 (seq.++ ?x2770 ?x4667)))))))
(let ((?x1742 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x7722 (seq.++ ?x13838 ?x1737)))))))
(let ((?x1747 (seq.++ ?x2770 (seq.++ ?x2770 (seq.++ ?x5254 (seq.++ ?x7722 (seq.++ ?x2770 ?x1742)))))))
(let ((?x4381 (seq.++ ?x7722 (seq.++ ?x2770 (seq.++ ?x2770 ?x1747)))))
(= input_1_net.frame_frame ?x4381))))))))))))))))))
(check-sat)

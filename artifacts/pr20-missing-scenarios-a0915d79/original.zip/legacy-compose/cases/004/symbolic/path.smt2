; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2667 (= due_1_cache due_0_cache)))
 (let (($x248 (= due_1_query 1000)))
 (let (($x4421 (= active_1_cache active_0_cache)))
 (let (($x250 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2769 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x2768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x2628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x996 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1729 (not v_1_rxudp_require_checksum)))
 (let ((?x5592 (seq.unit (_ bv9 8))))
 (let ((?x6655 (seq.++ ?x5592 (seq.++ (seq.unit (_ bv95 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv97 8)))))))
 (let ((?x4180 (seq.unit (_ bv0 8))))
 (let ((?x3025 (seq.unit (_ bv144 8))))
 (let ((?x3863 (seq.unit (_ bv31 8))))
 (let ((?x5914 (seq.unit (_ bv64 8))))
 (let ((?x3459 (seq.unit (_ bv156 8))))
 (let ((?x268 (seq.++ ?x3459 (seq.++ ?x5914 (seq.++ ?x3863 (seq.++ ?x3025 (seq.++ ?x4180 ?x6655)))))))
 (let ((?x2760 (seq.unit (_ bv2 8))))
 (let ((?x4267 (seq.unit (_ bv192 8))))
 (let ((?x165 (seq.unit (_ bv1 8))))
 (let ((?x2753 (seq.++ ?x165 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x2760 ?x268)))))))
 (let ((?x2767 (seq.unit (_ bv204 8))))
 (let ((?x5480 (seq.unit (_ bv182 8))))
 (let ((?x12 (seq.++ ?x5480 (seq.++ ?x2767 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 ?x2753)))))))
 (let ((?x7257 (seq.unit (_ bv17 8))))
 (let ((?x5457 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x7257 ?x12)))))))
 (let ((?x3419 (seq.unit (_ bv29 8))))
 (let ((?x435 (seq.unit (_ bv69 8))))
 (let ((?x7392 (seq.++ ?x435 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x3419 (seq.++ ?x4180 ?x5457)))))))
 (let (($x7405 (= v_1_pending_packet ?x7392)))
 (let (($x6515 (= v_1_ip_checksum 46796)))
 (let (($x899 (= v_1_udp_checksum 24327)))
 (let (($x4594 (= v_1_udp_raw_checksum 24327)))
 (let (($x341 (= v_1_ip_length 29)))
 (let (($x5475 (= v_1_udp_length 9)))
 (let (($x5474 (= v_1_packet ?x7392)))
 (let ((?x1393 (seq.++ ?x2760 (seq.++ ?x165 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 ?x2760)))))))
 (let ((?x5769 (seq.++ ?x4267 (seq.++ ?x4180 ?x1393))))
 (let ((?x5318 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x7257 (seq.++ ?x5480 (seq.++ ?x2767 ?x5769)))))))
 (let ((?x5343 (seq.++ ?x4180 (seq.++ ?x3419 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x5914 ?x5318)))))))
 (let (($x2507 (= v_1_ip_wire (seq.++ ?x435 (seq.++ ?x4180 ?x5343)))))
 (let ((?x3585 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x7257 (seq.++ ?x4180 (seq.++ ?x4180 ?x5769)))))))
 (let ((?x6754 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x5914 ?x3585)))))
 (let (($x5583 (= v_1_ip_zero (seq.++ ?x435 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x3419 ?x6754)))))))
 (let (($x7500 (= v_1_udp_wire ?x268)))
 (let ((?x7121 (seq.++ ?x2760 (seq.++ ?x2760 (seq.++ ?x4180 (seq.++ ?x7257 (seq.++ ?x4180 ?x5592)))))))
 (let ((?x1089 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x165 (seq.++ ?x4267 (seq.++ ?x4180 ?x7121)))))))
 (let (($x52 (= v_1_pseudoheader (seq.++ ?x4267 ?x1089))))
 (let ((?x306 (seq.++ ?x4180 (seq.++ ?x5592 (seq.++ ?x4180 (seq.++ ?x4180 (seq.unit (_ bv97 8))))))))
 (let (($x1344 (= v_1_udp_zero (seq.++ ?x3459 (seq.++ ?x5914 (seq.++ ?x3863 (seq.++ ?x3025 ?x306)))))))
 (let ((?x1223 (seq.unit (_ bv97 8))))
 (let (($x5541 (= v_1_payload ?x1223)))
 (let (($x4471 (= v_1_cache_ttl_ms 60000)))
 (let (($x3694 (= 0 v_1_retry_count)))
 (let (($x5557 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x3693 (= 1 state_1)))
 (let (($x22 (not active_0_cache)))
 (let (($x5555 (or $x22 (not (<= due_0_cache 0)))))
 (let (($x2581 (not active_0_query)))
 (let (($x5553 (or $x2581 (not (<= due_0_query 0)))))
 (let (($x7399 (= state_0 0)))
 (and $x7399 (>= 0 now_0) $x5553 $x5555 $x3693 $x5557 $x3694 $x4471 v_1_checksums_enabled $x5541 $x1344 $x52 $x7500 $x5583 $x2507 $x5474 $x5475 $x341 $x4594 $x899 $x6515 $x7405 $x1729 $x996 (= v_1_rxudp_disposition "none") $x2628 $x2768 $x2769 $x250 (= v_1_echo_disposition "none") active_1_query $x4421 $x248 $x2667)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1583 (= due_2_cache due_1_cache)))
 (let (($x1582 (= due_2_query due_1_query)))
 (let (($x1581 (= active_2_cache active_1_cache)))
 (let (($x1580 (= active_2_query active_1_query)))
 (let (($x1579 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2671 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2670 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x7387 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x7331 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x3849 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x3848 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x3847 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let ((?x5500 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x4180 (seq.unit (_ bv0 8))))
 (let ((?x5503 (seq.++ ?x4180 ?x5500)))
 (let ((?x7273 (seq.++ (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49271 0)))) ?x5503)))
 (let ((?x2463 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49271 0)))) ?x7273)))
 (let ((?x1501 (seq.unit (_ bv13 8))))
 (let ((?x3025 (seq.unit (_ bv144 8))))
 (let ((?x3863 (seq.unit (_ bv31 8))))
 (let ((?x5914 (seq.unit (_ bv64 8))))
 (let ((?x1119 (seq.++ ?x5914 (seq.++ ?x3863 (seq.++ ?x3025 (seq.++ ?x4180 (seq.++ ?x1501 ?x2463)))))))
 (let ((?x3459 (seq.unit (_ bv156 8))))
 (let ((?x1510 (seq.++ ?x3459 ?x1119)))
 (let ((?x2760 (seq.unit (_ bv2 8))))
 (let ((?x4267 (seq.unit (_ bv192 8))))
 (let ((?x165 (seq.unit (_ bv1 8))))
 (let ((?x4089 (seq.++ ?x165 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x2760 ?x1510)))))))
 (let ((?x2601 (seq.unit (_ bv200 8))))
 (let ((?x5480 (seq.unit (_ bv182 8))))
 (let ((?x7354 (seq.++ ?x5480 (seq.++ ?x2601 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 ?x4089)))))))
 (let ((?x7257 (seq.unit (_ bv17 8))))
 (let ((?x4397 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x7257 ?x7354)))))))
 (let ((?x3582 (seq.unit (_ bv33 8))))
 (let ((?x435 (seq.unit (_ bv69 8))))
 (let ((?x6083 (seq.++ ?x435 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x3582 (seq.++ ?x4180 ?x4397)))))))
 (let (($x5923 (= v_2_pending_packet ?x6083)))
 (let (($x1389 (= v_2_ip_checksum 46792)))
 (let ((?x5671 (ite v_1_checksums_enabled 49271 0)))
 (let (($x3859 (= v_2_udp_checksum ?x5671)))
 (let (($x3028 (= v_2_udp_raw_checksum 49271)))
 (let (($x4339 (= v_2_ip_length 33)))
 (let (($x5373 (= v_2_udp_length 13)))
 (let (($x4087 (= v_2_packet ?x6083)))
 (let ((?x1393 (seq.++ ?x2760 (seq.++ ?x165 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 ?x2760)))))))
 (let ((?x5769 (seq.++ ?x4267 (seq.++ ?x4180 ?x1393))))
 (let ((?x5969 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x7257 (seq.++ ?x5480 (seq.++ ?x2601 ?x5769)))))))
 (let ((?x6076 (seq.++ ?x4180 (seq.++ ?x3582 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x5914 ?x5969)))))))
 (let (($x1463 (= v_2_ip_wire (seq.++ ?x435 (seq.++ ?x4180 ?x6076)))))
 (let ((?x3585 (seq.++ ?x4180 (seq.++ ?x5914 (seq.++ ?x7257 (seq.++ ?x4180 (seq.++ ?x4180 ?x5769)))))))
 (let ((?x6754 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x5914 ?x3585)))))
 (let (($x1538 (= v_2_ip_zero (seq.++ ?x435 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x3582 ?x6754)))))))
 (let (($x3414 (= v_2_udp_wire ?x1510)))
 (let ((?x5843 (seq.++ ?x2760 (seq.++ ?x2760 (seq.++ ?x4180 (seq.++ ?x7257 (seq.++ ?x4180 ?x1501)))))))
 (let ((?x522 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x165 (seq.++ ?x4267 (seq.++ ?x4180 ?x5843)))))))
 (let (($x528 (= v_2_pseudoheader (seq.++ ?x4267 ?x522))))
 (let ((?x3544 (seq.++ ?x3025 (seq.++ ?x4180 (seq.++ ?x1501 (seq.++ ?x4180 (seq.++ ?x4180 ?x5503)))))))
 (let (($x386 (= v_2_udp_zero (seq.++ ?x3459 (seq.++ ?x5914 (seq.++ ?x3863 ?x3544))))))
 (let (($x3517 (= v_2_payload ?x5503)))
 (let (($x3317 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3316 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x3315 (= v_2_retry_count v_1_retry_count)))
 (let (($x3314 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x3313 (= 1 state_2)))
 (let (($x6837 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x3570 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x5384 (= state_1 1)))
 (and $x5384 $x3570 $x6837 $x3313 $x3314 $x3315 $x3316 $x3317 $x3517 $x386 $x528 $x3414 $x1538 $x1463 $x4087 $x5373 $x4339 $x3028 $x3859 $x1389 $x5923 $x3847 $x3848 $x3849 $x7331 $x7387 $x2670 $x2671 $x1579 $x1580 $x1581 $x1582 $x1583)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1206 (= due_3_query due_2_query)))
 (let (($x4350 (not active_3_query)))
 (let (($x1366 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x411 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x5889 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x1468 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x1467 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x4360 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x4318 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x1310 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x1494 (= (as seq.empty (Seq (_ BitVec 8))) v_3_pending_packet)))
 (let (($x2694 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x3853 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x3044 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x4141 (= v_3_ip_length v_2_ip_length)))
 (let (($x1257 (= v_3_udp_length v_2_udp_length)))
 (let (($x427 (= v_3_packet v_2_packet)))
 (let (($x5720 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x4485 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x4617 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x4651 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1377 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x6056 (= v_3_payload v_2_payload)))
 (let (($x295 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2882 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x1523 (= 0 v_3_retry_count)))
 (let ((?x4180 (seq.unit (_ bv0 8))))
 (let ((?x3490 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.unit (_ bv2 8))))))))
 (let ((?x2760 (seq.unit (_ bv2 8))))
 (let (($x5940 (= v_3_peer_mac (seq.++ ?x2760 ?x3490))))
 (let (($x4374 (= 2 state_3)))
 (let (($x1161 (or (not active_2_cache) (not (<= due_2_cache 2)))))
 (let (($x1325 (or (not active_2_query) (not (<= due_2_query 2)))))
 (let ((?x7304 (seq.len v_2_pending_packet)))
 (let (($x4135 (<= 28 ?x7304)))
 (let (($x3482 (= state_2 1)))
 (and $x3482 $x4135 $x1325 $x1161 $x4374 $x5940 $x1523 $x2882 $x295 $x6056 $x1377 $x4651 $x4617 $x4485 $x5720 $x427 $x1257 $x4141 $x3044 $x3853 $x2694 $x1494 $x1310 $x4318 $x4360 $x1467 $x1468 $x5889 $x411 $x1366 $x4350 active_3_cache $x1206 (= due_3_cache (+ 2 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1223 (seq.unit (_ bv97 8))))
 (= input_0_app.send_data ?x1223)))
(assert
 (= 20 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x5500 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x4180 (seq.unit (_ bv0 8))))
 (let ((?x5503 (seq.++ ?x4180 ?x5500)))
 (= input_1_app.send_data ?x5503)))))
(assert
 (= 28 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x4267 (seq.unit (_ bv192 8))))
(let ((?x1004 (seq.++ ?x4267 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x165 (seq.unit (_ bv1 8))))
(let ((?x4180 (seq.unit (_ bv0 8))))
(let ((?x1454 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x165 ?x1004)))))))
(let ((?x2760 (seq.unit (_ bv2 8))))
(let ((?x4557 (seq.++ ?x4267 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x2760 (seq.++ ?x2760 ?x1454)))))))
(let ((?x848 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x2760 ?x4557)))))))
(let ((?x3640 (seq.unit (_ bv4 8))))
(let ((?x6438 (seq.unit (_ bv6 8))))
(let ((?x32 (seq.++ ?x6438 (seq.++ ?x3640 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x2760 ?x848)))))))
(let ((?x6041 (seq.unit (_ bv8 8))))
(let ((?x7400 (seq.++ ?x6438 (seq.++ ?x4180 (seq.++ ?x165 (seq.++ ?x6041 (seq.++ ?x4180 ?x32)))))))
(let ((?x5277 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x2760 (seq.++ ?x6041 ?x7400)))))))
(let ((?x3921 (seq.++ ?x4180 (seq.++ ?x4180 (seq.++ ?x165 (seq.++ ?x2760 (seq.++ ?x4180 ?x5277)))))))
(let ((?x6528 (seq.++ ?x2760 (seq.++ ?x4180 (seq.++ ?x4180 ?x3921)))))
(= input_2_net.frame_frame ?x6528))))))))))))))))))
(check-sat)

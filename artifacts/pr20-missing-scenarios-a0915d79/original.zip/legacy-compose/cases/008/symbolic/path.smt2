; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x5899 (= due_1_cache due_0_cache)))
 (let (($x313 (= due_1_query 1000)))
 (let (($x22213 (= active_1_cache active_0_cache)))
 (let (($x1364 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x6262 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x6261 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x6260 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x6259 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x7141 (not v_1_rxudp_require_checksum)))
 (let ((?x1681 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x1684 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x1681)))))
 (let ((?x5461 (seq.unit (_ bv8 8))))
 (let ((?x4278 (seq.unit (_ bv6 8))))
 (let ((?x1688 (seq.++ ?x4278 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x5461 (seq.++ (seq.unit (_ bv9 8)) ?x1684))))))
 (let ((?x5865 (seq.unit (_ bv4 8))))
 (let ((?x365 (seq.unit (_ bv2 8))))
 (let ((?x1692 (seq.++ ?x365 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x5865 (seq.++ (seq.unit (_ bv5 8)) ?x1688))))))
 (let ((?x636 (seq.unit (_ bv1 8))))
 (let ((?x3292 (seq.unit (_ bv0 8))))
 (let ((?x1694 (seq.++ ?x3292 (seq.++ ?x636 ?x1692))))
 (let ((?x4955 (seq.unit (_ bv25 8))))
 (let ((?x426 (seq.++ ?x3292 (seq.++ ?x4955 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv167 8)) ?x1694))))))
 (let ((?x5992 (seq.unit (_ bv144 8))))
 (let ((?x7704 (seq.unit (_ bv31 8))))
 (let ((?x6490 (seq.unit (_ bv64 8))))
 (let ((?x17428 (seq.unit (_ bv156 8))))
 (let ((?x1356 (seq.++ ?x17428 (seq.++ ?x6490 (seq.++ ?x7704 (seq.++ ?x5992 ?x426))))))
 (let ((?x3916 (seq.unit (_ bv192 8))))
 (let ((?x343 (seq.++ ?x636 (seq.++ ?x3916 (seq.++ ?x3292 (seq.++ ?x365 (seq.++ ?x365 ?x1356)))))))
 (let ((?x2860 (seq.unit (_ bv188 8))))
 (let ((?x563 (seq.unit (_ bv182 8))))
 (let ((?x2797 (seq.++ ?x563 (seq.++ ?x2860 (seq.++ ?x3916 (seq.++ ?x3292 (seq.++ ?x365 ?x343)))))))
 (let ((?x4293 (seq.unit (_ bv17 8))))
 (let ((?x6153 (seq.++ ?x3292 (seq.++ ?x6490 (seq.++ ?x3292 (seq.++ ?x6490 (seq.++ ?x4293 ?x2797)))))))
 (let ((?x555 (seq.unit (_ bv45 8))))
 (let ((?x3287 (seq.unit (_ bv69 8))))
 (let ((?x6158 (seq.++ ?x3287 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x555 (seq.++ ?x3292 ?x6153)))))))
 (let (($x6258 (= v_1_pending_packet ?x6158)))
 (let (($x6257 (= v_1_ip_checksum 46780)))
 (let (($x6256 (= v_1_udp_checksum 30631)))
 (let (($x6255 (= v_1_udp_raw_checksum 30631)))
 (let (($x6254 (= v_1_ip_length 45)))
 (let (($x6253 (= v_1_udp_length 25)))
 (let (($x6159 (= v_1_packet ?x6158)))
 (let ((?x5706 (seq.++ ?x365 (seq.++ ?x636 (seq.++ ?x3916 (seq.++ ?x3292 (seq.++ ?x365 ?x365)))))))
 (let ((?x988 (seq.++ ?x3916 (seq.++ ?x3292 ?x5706))))
 (let ((?x356 (seq.++ ?x3292 (seq.++ ?x6490 (seq.++ ?x4293 (seq.++ ?x563 (seq.++ ?x2860 ?x988)))))))
 (let ((?x1340 (seq.++ ?x3292 (seq.++ ?x555 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x6490 ?x356)))))))
 (let (($x15 (= v_1_ip_wire (seq.++ ?x3287 (seq.++ ?x3292 ?x1340)))))
 (let ((?x4734 (seq.++ ?x3292 (seq.++ ?x6490 (seq.++ ?x4293 (seq.++ ?x3292 (seq.++ ?x3292 ?x988)))))))
 (let ((?x4739 (seq.++ ?x3292 (seq.++ ?x555 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x6490 ?x4734)))))))
 (let (($x4742 (= v_1_ip_zero (seq.++ ?x3287 (seq.++ ?x3292 ?x4739)))))
 (let (($x44 (= v_1_udp_wire ?x1356)))
 (let ((?x4118 (seq.++ ?x365 (seq.++ ?x365 (seq.++ ?x3292 (seq.++ ?x4293 (seq.++ ?x3292 ?x4955)))))))
 (let ((?x4948 (seq.++ ?x3292 (seq.++ ?x365 (seq.++ ?x636 (seq.++ ?x3916 (seq.++ ?x3292 ?x4118)))))))
 (let (($x4996 (= v_1_pseudoheader (seq.++ ?x3916 ?x4948))))
 (let ((?x24445 (seq.++ ?x5992 (seq.++ ?x3292 (seq.++ ?x4955 (seq.++ ?x3292 (seq.++ ?x3292 ?x1694)))))))
 (let (($x4098 (= v_1_udp_zero (seq.++ ?x17428 (seq.++ ?x6490 (seq.++ ?x7704 ?x24445))))))
 (let (($x6241 (= v_1_payload ?x1694)))
 (let (($x4363 (= v_1_cache_ttl_ms 60000)))
 (let (($x16409 (= 0 v_1_retry_count)))
 (let (($x4364 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x19031 (= 1 state_1)))
 (let (($x5632 (not active_0_cache)))
 (let (($x3868 (or $x5632 (not (<= due_0_cache 0)))))
 (let (($x6083 (not active_0_query)))
 (let (($x5272 (or $x6083 (not (<= due_0_query 0)))))
 (let (($x12085 (= state_0 0)))
 (and $x12085 (>= 0 now_0) $x5272 $x3868 $x19031 $x4364 $x16409 $x4363 v_1_checksums_enabled $x6241 $x4098 $x4996 $x44 $x4742 $x15 $x6159 $x6253 $x6254 $x6255 $x6256 $x6257 $x6258 $x7141 $x6259 (= v_1_rxudp_disposition "none") $x6260 $x6261 $x6262 $x1364 (= v_1_echo_disposition "none") active_1_query $x22213 $x313 $x5899))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x5636 (= due_2_query due_1_query)))
 (let (($x4433 (not active_2_query)))
 (let (($x5540 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x7072 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x3577 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x918 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x3730 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x3592 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2879 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x3732 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x3022 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x7059 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x3177 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1076 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2970 (= v_2_ip_length v_1_ip_length)))
 (let (($x4230 (= v_2_udp_length v_1_udp_length)))
 (let (($x5543 (= v_2_packet v_1_packet)))
 (let (($x3733 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x3573 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x5655 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x5653 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x3735 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x3478 (= v_2_payload v_1_payload)))
 (let (($x5547 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3423 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x3518 (= 0 v_2_retry_count)))
 (let ((?x3292 (seq.unit (_ bv0 8))))
 (let ((?x309 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.unit (_ bv2 8))))))))
 (let ((?x365 (seq.unit (_ bv2 8))))
 (let (($x1369 (= v_2_peer_mac (seq.++ ?x365 ?x309))))
 (let (($x3516 (= 2 state_2)))
 (let (($x1546 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x4984 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x5474 (seq.len v_1_pending_packet)))
 (let (($x6513 (<= 28 ?x5474)))
 (let (($x2887 (= state_1 1)))
 (and $x2887 $x6513 $x4984 $x1546 $x3516 $x1369 $x3518 $x3423 $x5547 $x3478 $x3735 $x5653 $x5655 $x3573 $x3733 $x5543 $x4230 $x2970 $x1076 $x3177 $x7059 $x3022 $x3732 $x2879 $x3592 $x3730 $x918 $x3577 $x7072 $x5540 $x4433 active_2_cache $x5636 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1681 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x1684 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x1681)))))
 (let ((?x5461 (seq.unit (_ bv8 8))))
 (let ((?x4278 (seq.unit (_ bv6 8))))
 (let ((?x1688 (seq.++ ?x4278 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x5461 (seq.++ (seq.unit (_ bv9 8)) ?x1684))))))
 (let ((?x5865 (seq.unit (_ bv4 8))))
 (let ((?x365 (seq.unit (_ bv2 8))))
 (let ((?x1692 (seq.++ ?x365 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x5865 (seq.++ (seq.unit (_ bv5 8)) ?x1688))))))
 (let ((?x636 (seq.unit (_ bv1 8))))
 (let ((?x3292 (seq.unit (_ bv0 8))))
 (let ((?x1694 (seq.++ ?x3292 (seq.++ ?x636 ?x1692))))
 (= input_0_app.send_data ?x1694)))))))))))))
(assert
 (= 28 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x3916 (seq.unit (_ bv192 8))))
(let ((?x24559 (seq.++ ?x3916 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x636 (seq.unit (_ bv1 8))))
(let ((?x3292 (seq.unit (_ bv0 8))))
(let ((?x1701 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x636 ?x24559)))))))
(let ((?x365 (seq.unit (_ bv2 8))))
(let ((?x1706 (seq.++ ?x3916 (seq.++ ?x3292 (seq.++ ?x365 (seq.++ ?x365 (seq.++ ?x365 ?x1701)))))))
(let ((?x1711 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x365 ?x1706)))))))
(let ((?x5865 (seq.unit (_ bv4 8))))
(let ((?x4278 (seq.unit (_ bv6 8))))
(let ((?x1716 (seq.++ ?x4278 (seq.++ ?x5865 (seq.++ ?x3292 (seq.++ ?x365 (seq.++ ?x365 ?x1711)))))))
(let ((?x5461 (seq.unit (_ bv8 8))))
(let ((?x1721 (seq.++ ?x4278 (seq.++ ?x3292 (seq.++ ?x636 (seq.++ ?x5461 (seq.++ ?x3292 ?x1716)))))))
(let ((?x1726 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x365 (seq.++ ?x5461 ?x1721)))))))
(let ((?x1732 (seq.++ ?x3292 (seq.++ ?x3292 (seq.++ ?x636 (seq.++ ?x365 (seq.++ ?x3292 ?x1726)))))))
(let ((?x1735 (seq.++ ?x365 (seq.++ ?x3292 (seq.++ ?x3292 ?x1732)))))
(= input_1_net.frame_frame ?x1735))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2765 (= due_1_cache 60000)))
 (let (($x2141 (= due_1_query due_0_query)))
 (let (($x18343 (not active_1_query)))
 (let (($x4409 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x15160 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x536 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x12977 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x2260 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x354 (not v_1_rxudp_require_checksum)))
 (let (($x2259 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x5454 (= v_1_ip_checksum 0)))
 (let (($x1031 (= v_1_udp_checksum 0)))
 (let (($x24103 (= v_1_udp_raw_checksum 0)))
 (let (($x6026 (= v_1_ip_length 0)))
 (let (($x5484 (= v_1_udp_length 0)))
 (let (($x2341 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2340 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4342 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1221 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x5329 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x106 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3107 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x6510 (= v_1_cache_ttl_ms 60000)))
 (let (($x4557 (= 0 v_1_retry_count)))
 (let ((?x4091 (seq.unit (_ bv0 8))))
 (let ((?x976 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.unit (_ bv2 8))))))))
 (let ((?x5045 (seq.unit (_ bv2 8))))
 (let (($x3106 (= v_1_peer_mac (seq.++ ?x5045 ?x976))))
 (let (($x18911 (= 2 state_1)))
 (let (($x2609 (not active_0_cache)))
 (let (($x1333 (or $x2609 (not (<= due_0_cache 0)))))
 (let (($x3228 (not active_0_query)))
 (let (($x2238 (or $x3228 (not (<= due_0_query 0)))))
 (let (($x4994 (= state_0 0)))
 (and $x4994 (>= 0 now_0) $x2238 $x1333 $x18911 $x3106 $x4557 $x6510 v_1_checksums_enabled $x3107 $x106 $x5329 $x1221 $x4342 $x2340 $x2341 $x5484 $x6026 $x24103 $x1031 $x5454 $x2259 $x354 $x2260 (= v_1_rxudp_disposition "none") $x12977 $x536 $x15160 $x4409 (= v_1_echo_disposition "none") $x18343 active_1_cache $x2141 $x2765))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x961 (= due_2_cache due_1_cache)))
 (let (($x17009 (= due_2_query due_1_query)))
 (let (($x1698 (= active_2_cache active_1_cache)))
 (let (($x4874 (= active_2_query active_1_query)))
 (let (($x4873 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x4872 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x4871 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x4870 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x4790 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x4975 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x1888 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x3356 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x5727 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x1715 (= v_2_ip_checksum 46797)))
 (let ((?x5658 (ite v_1_checksums_enabled 49161 0)))
 (let (($x3162 (= v_2_udp_checksum ?x5658)))
 (let (($x3340 (= v_2_udp_raw_checksum 49161)))
 (let (($x1535 (= v_2_ip_length 28)))
 (let (($x4654 (= v_2_udp_length 8)))
 (let ((?x12153 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x5658))) (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x5658))))))
 (let ((?x14795 (seq.unit (_ bv8 8))))
 (let ((?x4091 (seq.unit (_ bv0 8))))
 (let ((?x3293 (seq.unit (_ bv144 8))))
 (let ((?x6367 (seq.unit (_ bv31 8))))
 (let ((?x2724 (seq.unit (_ bv64 8))))
 (let ((?x3795 (seq.++ ?x2724 (seq.++ ?x6367 (seq.++ ?x3293 (seq.++ ?x4091 (seq.++ ?x14795 ?x12153)))))))
 (let ((?x4653 (seq.unit (_ bv156 8))))
 (let ((?x12970 (seq.++ ?x4653 ?x3795)))
 (let ((?x5045 (seq.unit (_ bv2 8))))
 (let ((?x6420 (seq.unit (_ bv192 8))))
 (let ((?x3625 (seq.unit (_ bv1 8))))
 (let ((?x4121 (seq.++ ?x3625 (seq.++ ?x6420 (seq.++ ?x4091 (seq.++ ?x5045 (seq.++ ?x5045 ?x12970)))))))
 (let ((?x13794 (seq.unit (_ bv205 8))))
 (let ((?x15021 (seq.unit (_ bv182 8))))
 (let ((?x12036 (seq.++ ?x15021 (seq.++ ?x13794 (seq.++ ?x6420 (seq.++ ?x4091 (seq.++ ?x5045 ?x4121)))))))
 (let ((?x636 (seq.unit (_ bv17 8))))
 (let ((?x8543 (seq.++ ?x4091 (seq.++ ?x2724 (seq.++ ?x4091 (seq.++ ?x2724 (seq.++ ?x636 ?x12036)))))))
 (let ((?x5396 (seq.unit (_ bv28 8))))
 (let ((?x6965 (seq.unit (_ bv69 8))))
 (let ((?x22774 (seq.++ ?x6965 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x5396 (seq.++ ?x4091 ?x8543)))))))
 (let (($x1021 (= v_2_packet ?x22774)))
 (let ((?x27225 (seq.++ ?x5045 (seq.++ ?x3625 (seq.++ ?x6420 (seq.++ ?x4091 (seq.++ ?x5045 ?x5045)))))))
 (let ((?x26476 (seq.++ ?x6420 (seq.++ ?x4091 ?x27225))))
 (let ((?x4329 (seq.++ ?x4091 (seq.++ ?x2724 (seq.++ ?x636 (seq.++ ?x15021 (seq.++ ?x13794 ?x26476)))))))
 (let ((?x27595 (seq.++ ?x4091 (seq.++ ?x5396 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x2724 ?x4329)))))))
 (let (($x5637 (= v_2_ip_wire (seq.++ ?x6965 (seq.++ ?x4091 ?x27595)))))
 (let ((?x11306 (seq.++ ?x4091 (seq.++ ?x2724 (seq.++ ?x636 (seq.++ ?x4091 (seq.++ ?x4091 ?x26476)))))))
 (let ((?x27354 (seq.++ ?x4091 (seq.++ ?x5396 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x2724 ?x11306)))))))
 (let (($x26278 (= v_2_ip_zero (seq.++ ?x6965 (seq.++ ?x4091 ?x27354)))))
 (let (($x24020 (= v_2_udp_wire ?x12970)))
 (let ((?x25937 (seq.++ ?x5045 (seq.++ ?x5045 (seq.++ ?x4091 (seq.++ ?x636 (seq.++ ?x4091 ?x14795)))))))
 (let ((?x4580 (seq.++ ?x4091 (seq.++ ?x5045 (seq.++ ?x3625 (seq.++ ?x6420 (seq.++ ?x4091 ?x25937)))))))
 (let (($x5369 (= v_2_pseudoheader (seq.++ ?x6420 ?x4580))))
 (let ((?x2245 (seq.++ ?x6367 (seq.++ ?x3293 (seq.++ ?x4091 (seq.++ ?x14795 (seq.++ ?x4091 ?x4091)))))))
 (let (($x1824 (= v_2_udp_zero (seq.++ ?x4653 (seq.++ ?x2724 ?x2245)))))
 (let (($x2060 (= (as seq.empty (Seq (_ BitVec 8))) v_2_payload)))
 (let (($x4862 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x11497 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2423 (= v_2_retry_count v_1_retry_count)))
 (let (($x6032 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x4325 (= 2 state_2)))
 (let (($x2323 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x18343 (not active_1_query)))
 (let (($x2714 (or $x18343 (not (<= due_1_query 1)))))
 (let (($x5034 (= state_1 2)))
 (and $x5034 $x2714 $x2323 $x4325 $x6032 $x2423 $x11497 $x4862 $x2060 $x1824 $x5369 $x24020 $x26278 $x5637 $x1021 $x4654 $x1535 $x3340 $x3162 $x1715 $x5727 $x3356 $x1888 $x4975 $x4790 $x4870 $x4871 $x4872 $x4873 $x4874 $x1698 $x17009 $x961)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x7345 (= due_3_cache due_2_cache)))
 (let (($x4158 (= due_3_query due_2_query)))
 (let (($x1478 (= active_3_cache active_2_cache)))
 (let (($x8461 (= active_3_query active_2_query)))
 (let (($x5906 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x19583 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x4842 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x3599 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x2371 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x309 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x4533 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x6609 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x7332 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x12114 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x5321 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x5199 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x6338 (= v_3_ip_length v_2_ip_length)))
 (let (($x26458 (= v_3_udp_length v_2_udp_length)))
 (let (($x6972 (= v_3_packet v_2_packet)))
 (let (($x5524 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x92 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x685 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1750 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x5793 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x1926 (= v_3_payload v_2_payload)))
 (let (($x2042 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2041 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x5262 (= v_3_retry_count v_2_retry_count)))
 (let (($x6381 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x6882 (= 2 state_3)))
 (let (($x20846 (or (not active_2_cache) (not (<= due_2_cache 2)))))
 (let (($x2101 (or (not active_2_query) (not (<= due_2_query 2)))))
 (let (($x2066 (= state_2 2)))
 (and $x2066 $x2101 $x20846 $x6882 $x6381 $x5262 $x2041 $x2042 $x1926 $x5793 $x1750 $x685 $x92 $x5524 $x6972 $x26458 $x6338 $x5199 $x5321 $x12114 $x7332 $x6609 $x4533 $x309 $x2371 $x3599 $x4842 $x19583 $x5906 $x8461 $x1478 $x4158 $x7345)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x6420 (seq.unit (_ bv192 8))))
 (let ((?x3418 (seq.++ ?x6420 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x3625 (seq.unit (_ bv1 8))))
 (let ((?x4091 (seq.unit (_ bv0 8))))
 (let ((?x2678 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x3625 ?x3418)))))))
 (let ((?x5045 (seq.unit (_ bv2 8))))
 (let ((?x5986 (seq.++ ?x6420 (seq.++ ?x4091 (seq.++ ?x5045 (seq.++ ?x5045 (seq.++ ?x5045 ?x2678)))))))
 (let ((?x5808 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x5045 ?x5986)))))))
 (let ((?x962 (seq.unit (_ bv4 8))))
 (let ((?x24967 (seq.unit (_ bv6 8))))
 (let ((?x987 (seq.++ ?x24967 (seq.++ ?x962 (seq.++ ?x4091 (seq.++ ?x5045 (seq.++ ?x5045 ?x5808)))))))
 (let ((?x14795 (seq.unit (_ bv8 8))))
 (let ((?x40 (seq.++ ?x24967 (seq.++ ?x4091 (seq.++ ?x3625 (seq.++ ?x14795 (seq.++ ?x4091 ?x987)))))))
 (let ((?x1206 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x5045 (seq.++ ?x14795 ?x40)))))))
 (let ((?x5743 (seq.++ ?x4091 (seq.++ ?x4091 (seq.++ ?x3625 (seq.++ ?x5045 (seq.++ ?x4091 ?x1206)))))))
 (let ((?x1432 (seq.++ ?x5045 (seq.++ ?x4091 (seq.++ ?x4091 ?x5743)))))
 (= input_0_net.frame_frame ?x1432))))))))))))))))))
(assert
 (= 22 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 2 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x6420 (seq.unit (_ bv192 8))))
(let ((?x7207 (seq.++ ?x6420 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x7207))))
(check-sat)

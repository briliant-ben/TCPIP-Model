; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1732 (= due_1_cache due_0_cache)))
 (let (($x4732 (= due_1_query 1000)))
 (let (($x5205 (= active_1_cache active_0_cache)))
 (let (($x2698 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x366 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x23170 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x13658 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1646 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3042 (not v_1_rxudp_require_checksum)))
 (let ((?x19171 (seq.unit (_ bv255 8))))
 (let ((?x6400 (seq.unit (_ bv10 8))))
 (let ((?x5961 (seq.++ ?x6400 (seq.++ ?x19171 (seq.++ ?x19171 (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv5 8))))))))
 (let ((?x3269 (seq.unit (_ bv0 8))))
 (let ((?x984 (seq.unit (_ bv144 8))))
 (let ((?x14559 (seq.unit (_ bv31 8))))
 (let ((?x7246 (seq.unit (_ bv64 8))))
 (let ((?x4559 (seq.unit (_ bv156 8))))
 (let ((?x6261 (seq.++ ?x4559 (seq.++ ?x7246 (seq.++ ?x14559 (seq.++ ?x984 (seq.++ ?x3269 ?x5961)))))))
 (let ((?x22566 (seq.unit (_ bv2 8))))
 (let ((?x5084 (seq.unit (_ bv192 8))))
 (let ((?x4459 (seq.unit (_ bv1 8))))
 (let ((?x3711 (seq.++ ?x4459 (seq.++ ?x5084 (seq.++ ?x3269 (seq.++ ?x22566 (seq.++ ?x22566 ?x6261)))))))
 (let ((?x23431 (seq.unit (_ bv203 8))))
 (let ((?x2985 (seq.unit (_ bv182 8))))
 (let ((?x4884 (seq.++ ?x2985 (seq.++ ?x23431 (seq.++ ?x5084 (seq.++ ?x3269 (seq.++ ?x22566 ?x3711)))))))
 (let ((?x27409 (seq.unit (_ bv17 8))))
 (let ((?x4064 (seq.++ ?x3269 (seq.++ ?x7246 (seq.++ ?x3269 (seq.++ ?x7246 (seq.++ ?x27409 ?x4884)))))))
 (let ((?x5322 (seq.unit (_ bv30 8))))
 (let ((?x3493 (seq.unit (_ bv69 8))))
 (let ((?x6926 (seq.++ ?x3493 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x5322 (seq.++ ?x3269 ?x4064)))))))
 (let (($x1645 (= v_1_pending_packet ?x6926)))
 (let (($x1644 (= v_1_ip_checksum 46795)))
 (let (($x1643 (= v_1_udp_checksum 65535)))
 (let (($x6113 (= v_1_udp_raw_checksum 0)))
 (let (($x1642 (= v_1_ip_length 30)))
 (let (($x2374 (= v_1_udp_length 10)))
 (let (($x4019 (= v_1_packet ?x6926)))
 (let ((?x25699 (seq.++ ?x22566 (seq.++ ?x4459 (seq.++ ?x5084 (seq.++ ?x3269 (seq.++ ?x22566 ?x22566)))))))
 (let ((?x1797 (seq.++ ?x5084 (seq.++ ?x3269 ?x25699))))
 (let ((?x4384 (seq.++ ?x3269 (seq.++ ?x7246 (seq.++ ?x27409 (seq.++ ?x2985 (seq.++ ?x23431 ?x1797)))))))
 (let ((?x1977 (seq.++ ?x3269 (seq.++ ?x5322 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x7246 ?x4384)))))))
 (let (($x4296 (= v_1_ip_wire (seq.++ ?x3493 (seq.++ ?x3269 ?x1977)))))
 (let ((?x1092 (seq.++ ?x3269 (seq.++ ?x7246 (seq.++ ?x27409 (seq.++ ?x3269 (seq.++ ?x3269 ?x1797)))))))
 (let ((?x2358 (seq.++ ?x3269 (seq.++ ?x5322 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x7246 ?x1092)))))))
 (let (($x5583 (= v_1_ip_zero (seq.++ ?x3493 (seq.++ ?x3269 ?x2358)))))
 (let (($x14516 (= v_1_udp_wire ?x6261)))
 (let ((?x3358 (seq.++ ?x22566 (seq.++ ?x22566 (seq.++ ?x3269 (seq.++ ?x27409 (seq.++ ?x3269 ?x6400)))))))
 (let ((?x1263 (seq.++ ?x3269 (seq.++ ?x22566 (seq.++ ?x4459 (seq.++ ?x5084 (seq.++ ?x3269 ?x3358)))))))
 (let (($x6951 (= v_1_pseudoheader (seq.++ ?x5084 ?x1263))))
 (let ((?x5666 (seq.++ ?x6400 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x5084 (seq.unit (_ bv5 8))))))))
 (let ((?x3405 (seq.++ ?x4559 (seq.++ ?x7246 (seq.++ ?x14559 (seq.++ ?x984 (seq.++ ?x3269 ?x5666)))))))
 (let (($x6371 (= v_1_udp_zero ?x3405)))
 (let ((?x4972 (seq.++ ?x5084 (seq.unit (_ bv5 8)))))
 (let (($x1149 (= v_1_payload ?x4972)))
 (let (($x5937 (= v_1_cache_ttl_ms 60000)))
 (let (($x23824 (= 0 v_1_retry_count)))
 (let (($x5331 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x2611 (= 1 state_1)))
 (let (($x5343 (not active_0_cache)))
 (let (($x21174 (or $x5343 (not (<= due_0_cache 0)))))
 (let (($x12 (not active_0_query)))
 (let (($x213 (or $x12 (not (<= due_0_query 0)))))
 (let (($x1446 (= state_0 0)))
 (and $x1446 (>= 0 now_0) $x213 $x21174 $x2611 $x5331 $x23824 $x5937 v_1_checksums_enabled $x1149 $x6371 $x6951 $x14516 $x5583 $x4296 $x4019 $x2374 $x1642 $x6113 $x1643 $x1644 $x1645 $x3042 $x1646 (= v_1_rxudp_disposition "none") $x13658 $x23170 $x366 $x2698 (= v_1_echo_disposition "none") active_1_query $x5205 $x4732 $x1732)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x9190 (= due_2_query due_1_query)))
 (let (($x5604 (not active_2_query)))
 (let (($x2689 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x7070 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x16257 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x16256 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x15464 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x5569 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x15463 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x10845 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x7955 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x4566 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x18911 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x18910 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x27233 (= v_2_ip_length v_1_ip_length)))
 (let (($x27232 (= v_2_udp_length v_1_udp_length)))
 (let (($x8700 (= v_2_packet v_1_packet)))
 (let (($x4028 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x15466 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x4671 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x3565 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x5405 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x4608 (= v_2_payload v_1_payload)))
 (let (($x2729 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x4572 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x4442 (= 0 v_2_retry_count)))
 (let ((?x3269 (seq.unit (_ bv0 8))))
 (let ((?x2130 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.unit (_ bv2 8))))))))
 (let ((?x22566 (seq.unit (_ bv2 8))))
 (let (($x1652 (= v_2_peer_mac (seq.++ ?x22566 ?x2130))))
 (let (($x5221 (= 2 state_2)))
 (let (($x1651 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x265 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x5404 (seq.len v_1_pending_packet)))
 (let (($x975 (<= 28 ?x5404)))
 (let (($x2045 (= state_1 1)))
 (and $x2045 $x975 $x265 $x1651 $x5221 $x1652 $x4442 $x4572 $x2729 $x4608 $x5405 $x3565 $x4671 $x15466 $x4028 $x8700 $x27232 $x27233 $x18910 $x18911 $x4566 $x7955 $x10845 $x15463 $x5569 $x15464 $x16256 $x16257 $x7070 $x2689 $x5604 active_2_cache $x9190 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5084 (seq.unit (_ bv192 8))))
 (let ((?x4972 (seq.++ ?x5084 (seq.unit (_ bv5 8)))))
 (= input_0_app.send_data ?x4972))))
(assert
 (= 28 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x5084 (seq.unit (_ bv192 8))))
(let ((?x6646 (seq.++ ?x5084 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x4459 (seq.unit (_ bv1 8))))
(let ((?x3269 (seq.unit (_ bv0 8))))
(let ((?x3176 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x4459 ?x6646)))))))
(let ((?x22566 (seq.unit (_ bv2 8))))
(let ((?x563 (seq.++ ?x5084 (seq.++ ?x3269 (seq.++ ?x22566 (seq.++ ?x22566 (seq.++ ?x22566 ?x3176)))))))
(let ((?x5047 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x22566 ?x563)))))))
(let ((?x811 (seq.unit (_ bv4 8))))
(let ((?x19812 (seq.unit (_ bv6 8))))
(let ((?x4994 (seq.++ ?x19812 (seq.++ ?x811 (seq.++ ?x3269 (seq.++ ?x22566 (seq.++ ?x22566 ?x5047)))))))
(let ((?x5956 (seq.unit (_ bv8 8))))
(let ((?x12698 (seq.++ ?x19812 (seq.++ ?x3269 (seq.++ ?x4459 (seq.++ ?x5956 (seq.++ ?x3269 ?x4994)))))))
(let ((?x5483 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x22566 (seq.++ ?x5956 ?x12698)))))))
(let ((?x3938 (seq.++ ?x3269 (seq.++ ?x3269 (seq.++ ?x4459 (seq.++ ?x22566 (seq.++ ?x3269 ?x5483)))))))
(let ((?x25369 (seq.++ ?x22566 (seq.++ ?x3269 (seq.++ ?x3269 ?x3938)))))
(= input_1_net.frame_frame ?x25369))))))))))))))))))
(check-sat)

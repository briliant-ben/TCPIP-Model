; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3644 (= due_1_cache due_0_cache)))
 (let (($x24446 (= due_1_query 1000)))
 (let (($x3642 (= active_1_cache active_0_cache)))
 (let (($x24445 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2887 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x907 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x17147 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x17146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x4548 (not v_1_rxudp_require_checksum)))
 (let ((?x14567 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x6816 (seq.unit (_ bv0 8))))
 (let ((?x15459 (seq.++ ?x6816 ?x14567)))
 (let ((?x6815 (seq.unit (_ bv192 8))))
 (let ((?x5898 (seq.unit (_ bv13 8))))
 (let ((?x22735 (seq.++ ?x6816 (seq.++ ?x5898 (seq.++ ?x6815 (seq.++ (seq.unit (_ bv119 8)) ?x15459))))))
 (let ((?x3689 (seq.unit (_ bv144 8))))
 (let ((?x4140 (seq.unit (_ bv31 8))))
 (let ((?x5039 (seq.unit (_ bv64 8))))
 (let ((?x5478 (seq.unit (_ bv156 8))))
 (let ((?x12395 (seq.++ ?x5478 (seq.++ ?x5039 (seq.++ ?x4140 (seq.++ ?x3689 ?x22735))))))
 (let ((?x939 (seq.unit (_ bv2 8))))
 (let ((?x4564 (seq.unit (_ bv1 8))))
 (let ((?x16091 (seq.++ ?x4564 (seq.++ ?x6815 (seq.++ ?x6816 (seq.++ ?x939 (seq.++ ?x939 ?x12395)))))))
 (let ((?x4293 (seq.unit (_ bv200 8))))
 (let ((?x13426 (seq.unit (_ bv182 8))))
 (let ((?x21257 (seq.++ ?x13426 (seq.++ ?x4293 (seq.++ ?x6815 (seq.++ ?x6816 (seq.++ ?x939 ?x16091)))))))
 (let ((?x1312 (seq.unit (_ bv17 8))))
 (let ((?x27737 (seq.++ ?x6816 (seq.++ ?x5039 (seq.++ ?x6816 (seq.++ ?x5039 (seq.++ ?x1312 ?x21257)))))))
 (let ((?x1045 (seq.unit (_ bv33 8))))
 (let ((?x5999 (seq.unit (_ bv69 8))))
 (let ((?x17028 (seq.++ ?x5999 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x1045 (seq.++ ?x6816 ?x27737)))))))
 (let (($x2407 (= v_1_pending_packet ?x17028)))
 (let (($x1427 (= v_1_ip_checksum 46792)))
 (let (($x11643 (= v_1_udp_checksum 49271)))
 (let (($x11642 (= v_1_udp_raw_checksum 49271)))
 (let (($x12041 (= v_1_ip_length 33)))
 (let (($x12040 (= v_1_udp_length 13)))
 (let (($x17029 (= v_1_packet ?x17028)))
 (let ((?x1856 (seq.++ ?x939 (seq.++ ?x4564 (seq.++ ?x6815 (seq.++ ?x6816 (seq.++ ?x939 ?x939)))))))
 (let ((?x3407 (seq.++ ?x6815 (seq.++ ?x6816 ?x1856))))
 (let ((?x814 (seq.++ ?x6816 (seq.++ ?x5039 (seq.++ ?x1312 (seq.++ ?x13426 (seq.++ ?x4293 ?x3407)))))))
 (let ((?x3569 (seq.++ ?x6816 (seq.++ ?x1045 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x5039 ?x814)))))))
 (let (($x11755 (= v_1_ip_wire (seq.++ ?x5999 (seq.++ ?x6816 ?x3569)))))
 (let ((?x9462 (seq.++ ?x6816 (seq.++ ?x5039 (seq.++ ?x1312 (seq.++ ?x6816 (seq.++ ?x6816 ?x3407)))))))
 (let ((?x9236 (seq.++ ?x6816 (seq.++ ?x1045 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x5039 ?x9462)))))))
 (let (($x23514 (= v_1_ip_zero (seq.++ ?x5999 (seq.++ ?x6816 ?x9236)))))
 (let (($x12396 (= v_1_udp_wire ?x12395)))
 (let ((?x3083 (seq.++ ?x939 (seq.++ ?x939 (seq.++ ?x6816 (seq.++ ?x1312 (seq.++ ?x6816 ?x5898)))))))
 (let ((?x3090 (seq.++ ?x6816 (seq.++ ?x939 (seq.++ ?x4564 (seq.++ ?x6815 (seq.++ ?x6816 ?x3083)))))))
 (let (($x3089 (= v_1_pseudoheader (seq.++ ?x6815 ?x3090))))
 (let ((?x5690 (seq.++ ?x3689 (seq.++ ?x6816 (seq.++ ?x5898 (seq.++ ?x6816 (seq.++ ?x6816 ?x15459)))))))
 (let (($x3837 (= v_1_udp_zero (seq.++ ?x5478 (seq.++ ?x5039 (seq.++ ?x4140 ?x5690))))))
 (let (($x5078 (= v_1_payload ?x15459)))
 (let (($x3566 (= v_1_cache_ttl_ms 60000)))
 (let (($x2725 (= 0 v_1_retry_count)))
 (let (($x5391 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x6494 (= 1 state_1)))
 (let (($x3001 (not active_0_cache)))
 (let (($x4184 (or $x3001 (not (<= due_0_cache 0)))))
 (let (($x2999 (not active_0_query)))
 (let (($x3100 (or $x2999 (not (<= due_0_query 0)))))
 (let (($x2698 (= state_0 0)))
 (and $x2698 (>= 0 now_0) $x3100 $x4184 $x6494 $x5391 $x2725 $x3566 v_1_checksums_enabled $x5078 $x3837 $x3089 $x12396 $x23514 $x11755 $x17029 $x12040 $x12041 $x11642 $x11643 $x1427 $x2407 $x4548 $x17146 (= v_1_rxudp_disposition "none") $x17147 $x907 $x2887 $x24445 (= v_1_echo_disposition "none") active_1_query $x3642 $x24446 $x3644))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1504 (= due_2_cache due_1_cache)))
 (let (($x198 (= due_2_query due_1_query)))
 (let (($x2539 (= active_2_cache active_1_cache)))
 (let (($x5305 (= active_2_query active_1_query)))
 (let (($x5865 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x4278 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x5461 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x1913 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x6754 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x4457 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x4194 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x4503 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x3585 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x3610 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x3609 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x5607 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x5246 (= v_2_ip_length v_1_ip_length)))
 (let (($x6888 (= v_2_udp_length v_1_udp_length)))
 (let (($x1089 (= v_2_packet v_1_packet)))
 (let (($x5416 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x4541 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2523 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1438 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x7121 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x7231 (= v_2_payload v_1_payload)))
 (let (($x5520 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3489 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x5593 (= v_2_retry_count v_1_retry_count)))
 (let (($x263 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x4497 (= 1 state_2)))
 (let (($x4123 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x2675 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x5287 (= state_1 1)))
 (and $x5287 $x2675 $x4123 $x4497 $x263 $x5593 $x3489 $x5520 $x7231 $x7121 $x1438 $x2523 $x4541 $x5416 $x1089 $x6888 $x5246 $x5607 $x3609 $x3610 $x3585 $x4503 $x4194 $x4457 $x6754 $x1913 $x5461 $x4278 $x5865 $x5305 $x2539 $x198 $x1504)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1472 (= due_3_query due_2_query)))
 (let (($x22563 (not active_3_query)))
 (let (($x6289 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x6288 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x6287 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x6286 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x6284 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x6283 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x6282 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x6281 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x22562 (= (as seq.empty (Seq (_ BitVec 8))) v_3_pending_packet)))
 (let (($x6279 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x6278 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x6277 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x6276 (= v_3_ip_length v_2_ip_length)))
 (let (($x6275 (= v_3_udp_length v_2_udp_length)))
 (let (($x6274 (= v_3_packet v_2_packet)))
 (let (($x6273 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x6272 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x6271 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x6270 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x6269 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x6268 (= v_3_payload v_2_payload)))
 (let (($x6267 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x6266 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x6265 (= 0 v_3_retry_count)))
 (let ((?x6816 (seq.unit (_ bv0 8))))
 (let ((?x4604 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.unit (_ bv3 8))))))))
 (let ((?x939 (seq.unit (_ bv2 8))))
 (let (($x20845 (= v_3_peer_mac (seq.++ ?x939 ?x4604))))
 (let (($x6263 (= 2 state_3)))
 (let (($x20844 (or (not active_2_cache) (not (<= due_2_cache 2)))))
 (let (($x21266 (or (not active_2_query) (not (<= due_2_query 2)))))
 (let ((?x5906 (seq.len v_2_pending_packet)))
 (let (($x5907 (<= 28 ?x5906)))
 (let (($x2858 (= state_2 1)))
 (and $x2858 $x5907 $x21266 $x20844 $x6263 $x20845 $x6265 $x6266 $x6267 $x6268 $x6269 $x6270 $x6271 $x6272 $x6273 $x6274 $x6275 $x6276 $x6277 $x6278 $x6279 $x22562 $x6281 $x6282 $x6283 $x6284 $x6286 $x6287 $x6288 $x6289 $x22563 active_3_cache $x1472 (= due_3_cache (+ 2 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x14567 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x6816 (seq.unit (_ bv0 8))))
 (let ((?x15459 (seq.++ ?x6816 ?x14567)))
 (= input_0_app.send_data ?x15459)))))
(assert
 (= 12 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x6815 (seq.unit (_ bv192 8))))
 (let ((?x9186 (seq.++ ?x6815 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x6816 (seq.unit (_ bv0 8))))
 (let ((?x17546 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 ?x9186)))))))
 (let ((?x939 (seq.unit (_ bv2 8))))
 (let ((?x8442 (seq.++ ?x6815 (seq.++ ?x6816 (seq.++ ?x939 (seq.++ ?x939 (seq.++ ?x6816 ?x17546)))))))
 (let ((?x27363 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x939 ?x8442)))))))
 (let ((?x4564 (seq.unit (_ bv1 8))))
 (let ((?x1519 (seq.unit (_ bv4 8))))
 (let ((?x1092 (seq.unit (_ bv6 8))))
 (let ((?x20121 (seq.++ ?x1092 (seq.++ ?x1519 (seq.++ ?x6816 (seq.++ ?x4564 (seq.++ ?x939 ?x27363)))))))
 (let ((?x1299 (seq.unit (_ bv8 8))))
 (let ((?x1365 (seq.++ ?x1092 (seq.++ ?x6816 (seq.++ ?x4564 (seq.++ ?x1299 (seq.++ ?x6816 ?x20121)))))))
 (let ((?x19067 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x939 (seq.++ ?x1299 ?x1365)))))))
 (let ((?x5422 (seq.unit (_ bv255 8))))
 (let ((?x3061 (seq.++ ?x5422 (seq.++ ?x5422 (seq.++ ?x5422 (seq.++ ?x939 (seq.++ ?x6816 ?x19067)))))))
 (let ((?x14313 (seq.++ ?x5422 (seq.++ ?x5422 (seq.++ ?x5422 ?x3061)))))
 (= input_1_net.frame_frame ?x14313)))))))))))))))))))
(assert
 (= 28 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x6815 (seq.unit (_ bv192 8))))
(let ((?x1574 (seq.++ ?x6815 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x4564 (seq.unit (_ bv1 8))))
(let ((?x6816 (seq.unit (_ bv0 8))))
(let ((?x16421 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x4564 ?x1574)))))))
(let ((?x939 (seq.unit (_ bv2 8))))
(let ((?x26488 (seq.++ ?x6815 (seq.++ ?x6816 (seq.++ ?x939 (seq.++ ?x939 (seq.++ ?x939 ?x16421)))))))
(let ((?x1191 (seq.unit (_ bv3 8))))
(let ((?x18941 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x1191 ?x26488)))))))
(let ((?x1519 (seq.unit (_ bv4 8))))
(let ((?x1092 (seq.unit (_ bv6 8))))
(let ((?x11488 (seq.++ ?x1092 (seq.++ ?x1519 (seq.++ ?x6816 (seq.++ ?x939 (seq.++ ?x939 ?x18941)))))))
(let ((?x1299 (seq.unit (_ bv8 8))))
(let ((?x14683 (seq.++ ?x1092 (seq.++ ?x6816 (seq.++ ?x4564 (seq.++ ?x1299 (seq.++ ?x6816 ?x11488)))))))
(let ((?x19031 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x1191 (seq.++ ?x1299 ?x14683)))))))
(let ((?x22658 (seq.++ ?x6816 (seq.++ ?x6816 (seq.++ ?x4564 (seq.++ ?x939 (seq.++ ?x6816 ?x19031)))))))
(let ((?x23305 (seq.++ ?x939 (seq.++ ?x6816 (seq.++ ?x6816 ?x22658)))))
(= input_2_net.frame_frame ?x23305)))))))))))))))))))
(check-sat)

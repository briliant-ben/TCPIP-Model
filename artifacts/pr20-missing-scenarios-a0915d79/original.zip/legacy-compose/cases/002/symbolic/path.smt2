; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.send_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3468 (= due_1_cache due_0_cache)))
 (let (($x409 (= due_1_query 1000)))
 (let (($x3467 (= active_1_cache active_0_cache)))
 (let (($x5851 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x1153 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x7158 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x6034 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x6033 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3940 (not v_1_rxudp_require_checksum)))
 (let ((?x950 (seq.unit (_ bv0 8))))
 (let ((?x7203 (seq.++ ?x950 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
 (let ((?x1033 (seq.unit (_ bv144 8))))
 (let ((?x752 (seq.unit (_ bv31 8))))
 (let ((?x6243 (seq.unit (_ bv64 8))))
 (let ((?x1052 (seq.unit (_ bv156 8))))
 (let ((?x138 (seq.++ ?x1052 (seq.++ ?x6243 (seq.++ ?x752 (seq.++ ?x1033 ?x7203))))))
 (let ((?x6659 (seq.unit (_ bv2 8))))
 (let ((?x934 (seq.unit (_ bv192 8))))
 (let ((?x943 (seq.unit (_ bv1 8))))
 (let ((?x5965 (seq.++ ?x943 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 (seq.++ ?x6659 ?x138)))))))
 (let ((?x425 (seq.unit (_ bv205 8))))
 (let ((?x5734 (seq.unit (_ bv182 8))))
 (let ((?x579 (seq.++ ?x5734 (seq.++ ?x425 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 ?x5965)))))))
 (let ((?x6011 (seq.unit (_ bv17 8))))
 (let ((?x5836 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x6011 ?x579)))))))
 (let ((?x4432 (seq.unit (_ bv28 8))))
 (let ((?x2836 (seq.unit (_ bv69 8))))
 (let ((?x5423 (seq.++ ?x2836 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x4432 (seq.++ ?x950 ?x5836)))))))
 (let (($x6088 (= v_1_pending_packet ?x5423)))
 (let (($x1348 (= v_1_ip_checksum 46797)))
 (let (($x6055 (= v_1_udp_checksum 49161)))
 (let (($x1023 (= v_1_udp_raw_checksum 49161)))
 (let (($x515 (= v_1_ip_length 28)))
 (let (($x516 (= v_1_udp_length 8)))
 (let (($x7133 (= v_1_packet ?x5423)))
 (let ((?x4342 (seq.++ ?x6659 (seq.++ ?x943 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 ?x6659)))))))
 (let ((?x4479 (seq.++ ?x934 (seq.++ ?x950 ?x4342))))
 (let ((?x464 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x6011 (seq.++ ?x5734 (seq.++ ?x425 ?x4479)))))))
 (let ((?x1209 (seq.++ ?x950 (seq.++ ?x4432 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x6243 ?x464)))))))
 (let (($x2829 (= v_1_ip_wire (seq.++ ?x2836 (seq.++ ?x950 ?x1209)))))
 (let ((?x1524 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x6011 (seq.++ ?x950 (seq.++ ?x950 ?x4479)))))))
 (let ((?x4368 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x6243 ?x1524)))))
 (let (($x4601 (= v_1_ip_zero (seq.++ ?x2836 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x4432 ?x4368)))))))
 (let (($x4398 (= v_1_udp_wire ?x138)))
 (let ((?x378 (seq.++ ?x6659 (seq.++ ?x950 (seq.++ ?x6011 (seq.++ ?x950 (seq.unit (_ bv8 8))))))))
 (let ((?x4439 (seq.++ ?x6659 (seq.++ ?x943 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 ?x378)))))))
 (let (($x4604 (= v_1_pseudoheader (seq.++ ?x934 (seq.++ ?x950 ?x4439)))))
 (let ((?x326 (seq.++ ?x1033 (seq.++ ?x950 (seq.++ (seq.unit (_ bv8 8)) (seq.++ ?x950 ?x950))))))
 (let (($x1431 (= v_1_udp_zero (seq.++ ?x1052 (seq.++ ?x6243 (seq.++ ?x752 ?x326))))))
 (let (($x4629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x7398 (= v_1_cache_ttl_ms 60000)))
 (let (($x7389 (= 0 v_1_retry_count)))
 (let (($x4628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x3456 (= 1 state_1)))
 (let (($x97 (not active_0_cache)))
 (let (($x4627 (or $x97 (not (<= due_0_cache 0)))))
 (let (($x7576 (not active_0_query)))
 (let (($x4568 (or $x7576 (not (<= due_0_query 0)))))
 (let (($x6091 (= state_0 0)))
 (and $x6091 (>= 0 now_0) $x4568 $x4627 $x3456 $x4628 $x7389 $x7398 v_1_checksums_enabled $x4629 $x1431 $x4604 $x4398 $x4601 $x2829 $x7133 $x516 $x515 $x1023 $x6055 $x1348 $x6088 $x3940 $x6033 (= v_1_rxudp_disposition "none") $x6034 $x7158 $x1153 $x5851 (= v_1_echo_disposition "none") active_1_query $x3467 $x409 $x3468)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2721 (= due_2_query due_1_query)))
 (let (($x4369 (not active_2_query)))
 (let (($x2718 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2717 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2716 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x2715 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x2714 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x2713 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2712 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2711 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x405 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x2709 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2708 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2707 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2706 (= v_2_ip_length v_1_ip_length)))
 (let (($x2705 (= v_2_udp_length v_1_udp_length)))
 (let (($x2704 (= v_2_packet v_1_packet)))
 (let (($x2703 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2702 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2701 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2700 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2699 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2698 (= v_2_payload v_1_payload)))
 (let (($x2697 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2696 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2695 (= 0 v_2_retry_count)))
 (let ((?x950 (seq.unit (_ bv0 8))))
 (let ((?x2541 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.unit (_ bv2 8))))))))
 (let ((?x6659 (seq.unit (_ bv2 8))))
 (let (($x5957 (= v_2_peer_mac (seq.++ ?x6659 ?x2541))))
 (let (($x2693 (= 2 state_2)))
 (let (($x1278 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x7175 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let ((?x2657 (seq.len v_1_pending_packet)))
 (let (($x2658 (<= 28 ?x2657)))
 (let (($x58 (= state_1 1)))
 (and $x58 $x2658 $x7175 $x1278 $x2693 $x5957 $x2695 $x2696 $x2697 $x2698 $x2699 $x2700 $x2701 $x2702 $x2703 $x2704 $x2705 $x2706 $x2707 $x2708 $x2709 $x405 $x2711 $x2712 $x2713 $x2714 $x2715 $x2716 $x2717 $x2718 $x4369 active_2_cache $x2721 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3043 (= due_3_cache due_2_cache)))
 (let (($x3042 (= due_3_query due_2_query)))
 (let (($x3041 (= active_3_cache active_2_cache)))
 (let (($x3040 (= active_3_query active_2_query)))
 (let (($x3039 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x3038 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x3037 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x3036 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x3035 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x3034 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x3033 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x3032 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x3031 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x179 (= v_3_ip_checksum 46792)))
 (let ((?x365 (ite v_2_checksums_enabled 49271 0)))
 (let (($x178 (= v_3_udp_checksum ?x365)))
 (let (($x7258 (= v_3_udp_raw_checksum 49271)))
 (let (($x5791 (= v_3_ip_length 33)))
 (let (($x7272 (= v_3_udp_length 13)))
 (let ((?x7257 (seq.unit (_ bv128 8))))
 (let ((?x435 (seq.++ ?x7257 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x950 (seq.unit (_ bv0 8))))
 (let ((?x7362 (seq.++ ?x950 ?x435)))
 (let ((?x1095 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x365))) (seq.++ (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x365))) ?x7362))))
 (let ((?x5914 (seq.unit (_ bv13 8))))
 (let ((?x1033 (seq.unit (_ bv144 8))))
 (let ((?x752 (seq.unit (_ bv31 8))))
 (let ((?x6243 (seq.unit (_ bv64 8))))
 (let ((?x337 (seq.++ ?x6243 (seq.++ ?x752 (seq.++ ?x1033 (seq.++ ?x950 (seq.++ ?x5914 ?x1095)))))))
 (let ((?x1052 (seq.unit (_ bv156 8))))
 (let ((?x4328 (seq.++ ?x1052 ?x337)))
 (let ((?x6659 (seq.unit (_ bv2 8))))
 (let ((?x934 (seq.unit (_ bv192 8))))
 (let ((?x943 (seq.unit (_ bv1 8))))
 (let ((?x7527 (seq.++ ?x943 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 (seq.++ ?x6659 ?x4328)))))))
 (let ((?x5880 (seq.unit (_ bv200 8))))
 (let ((?x5734 (seq.unit (_ bv182 8))))
 (let ((?x1112 (seq.++ ?x5734 (seq.++ ?x5880 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 ?x7527)))))))
 (let ((?x6011 (seq.unit (_ bv17 8))))
 (let ((?x2881 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x6011 ?x1112)))))))
 (let ((?x5415 (seq.unit (_ bv33 8))))
 (let ((?x2836 (seq.unit (_ bv69 8))))
 (let ((?x1100 (seq.++ ?x2836 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x5415 (seq.++ ?x950 ?x2881)))))))
 (let (($x1101 (= v_3_packet ?x1100)))
 (let ((?x4342 (seq.++ ?x6659 (seq.++ ?x943 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 ?x6659)))))))
 (let ((?x4479 (seq.++ ?x934 (seq.++ ?x950 ?x4342))))
 (let ((?x5979 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x6011 (seq.++ ?x5734 (seq.++ ?x5880 ?x4479)))))))
 (let ((?x1332 (seq.++ ?x950 (seq.++ ?x5415 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x6243 ?x5979)))))))
 (let (($x988 (= v_3_ip_wire (seq.++ ?x2836 (seq.++ ?x950 ?x1332)))))
 (let ((?x1524 (seq.++ ?x950 (seq.++ ?x6243 (seq.++ ?x6011 (seq.++ ?x950 (seq.++ ?x950 ?x4479)))))))
 (let ((?x4368 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x6243 ?x1524)))))
 (let (($x4489 (= v_3_ip_zero (seq.++ ?x2836 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x5415 ?x4368)))))))
 (let (($x4399 (= v_3_udp_wire ?x4328)))
 (let ((?x979 (seq.++ ?x6659 (seq.++ ?x6659 (seq.++ ?x950 (seq.++ ?x6011 (seq.++ ?x950 ?x5914)))))))
 (let ((?x303 (seq.++ ?x950 (seq.++ ?x6659 (seq.++ ?x943 (seq.++ ?x934 (seq.++ ?x950 ?x979)))))))
 (let (($x1230 (= v_3_pseudoheader (seq.++ ?x934 ?x303))))
 (let ((?x4557 (seq.++ ?x1033 (seq.++ ?x950 (seq.++ ?x5914 (seq.++ ?x950 (seq.++ ?x950 ?x7362)))))))
 (let (($x1531 (= v_3_udp_zero (seq.++ ?x1052 (seq.++ ?x6243 (seq.++ ?x752 ?x4557))))))
 (let (($x4458 (= v_3_payload ?x7362)))
 (let (($x3018 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x3017 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x3016 (= v_3_retry_count v_2_retry_count)))
 (let (($x3015 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x3014 (= 2 state_3)))
 (let (($x1390 (or (not active_2_cache) (not (<= due_2_cache 11)))))
 (let (($x4369 (not active_2_query)))
 (let (($x4609 (or $x4369 (not (<= due_2_query 11)))))
 (let (($x4163 (= state_2 2)))
 (and $x4163 $x4609 $x1390 $x3014 $x3015 $x3016 $x3017 $x3018 $x4458 $x1531 $x1230 $x4399 $x4489 $x988 $x1101 $x7272 $x5791 $x7258 $x178 $x179 $x3031 $x3032 $x3033 $x3034 $x3035 $x3036 $x3037 $x3038 $x3039 $x3040 $x3041 $x3042 $x3043))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (= input_0_app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 28 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x934 (seq.unit (_ bv192 8))))
 (let ((?x5799 (seq.++ ?x934 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x943 (seq.unit (_ bv1 8))))
 (let ((?x950 (seq.unit (_ bv0 8))))
 (let ((?x428 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x943 ?x5799)))))))
 (let ((?x6659 (seq.unit (_ bv2 8))))
 (let ((?x7545 (seq.++ ?x934 (seq.++ ?x950 (seq.++ ?x6659 (seq.++ ?x6659 (seq.++ ?x6659 ?x428)))))))
 (let ((?x440 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x6659 ?x7545)))))))
 (let ((?x1283 (seq.unit (_ bv4 8))))
 (let ((?x1279 (seq.unit (_ bv6 8))))
 (let ((?x580 (seq.++ ?x1279 (seq.++ ?x1283 (seq.++ ?x950 (seq.++ ?x6659 (seq.++ ?x6659 ?x440)))))))
 (let ((?x1280 (seq.unit (_ bv8 8))))
 (let ((?x1269 (seq.++ ?x1279 (seq.++ ?x950 (seq.++ ?x943 (seq.++ ?x1280 (seq.++ ?x950 ?x580)))))))
 (let ((?x6062 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x6659 (seq.++ ?x1280 ?x1269)))))))
 (let ((?x971 (seq.++ ?x950 (seq.++ ?x950 (seq.++ ?x943 (seq.++ ?x6659 (seq.++ ?x950 ?x6062)))))))
 (let ((?x1311 (seq.++ ?x6659 (seq.++ ?x950 (seq.++ ?x950 ?x971)))))
 (= input_1_net.frame_frame ?x1311))))))))))))))))))
(assert
 (= 22 choice_2))
(assert
 (= 11 now_3))
(assert
 (let ((?x7257 (seq.unit (_ bv128 8))))
(let ((?x435 (seq.++ ?x7257 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x950 (seq.unit (_ bv0 8))))
(let ((?x7362 (seq.++ ?x950 ?x435)))
(= input_2_app.send_data ?x7362))))))
(check-sat)

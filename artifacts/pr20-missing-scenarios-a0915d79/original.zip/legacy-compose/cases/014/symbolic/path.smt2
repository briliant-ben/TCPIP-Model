; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x11498 (= due_1_cache due_0_cache)))
 (let (($x7268 (= due_1_query 1000)))
 (let (($x5465 (= active_1_cache active_0_cache)))
 (let (($x5920 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2808 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x5734 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x16212 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x20394 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2828 (not v_1_rxudp_require_checksum)))
 (let ((?x21158 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x24973 (seq.unit (_ bv0 8))))
 (let ((?x87 (seq.++ ?x24973 ?x21158)))
 (let ((?x7131 (seq.unit (_ bv192 8))))
 (let ((?x4841 (seq.unit (_ bv13 8))))
 (let ((?x435 (seq.++ ?x24973 (seq.++ ?x4841 (seq.++ ?x7131 (seq.++ (seq.unit (_ bv119 8)) ?x87))))))
 (let ((?x1297 (seq.unit (_ bv144 8))))
 (let ((?x18917 (seq.unit (_ bv31 8))))
 (let ((?x5041 (seq.unit (_ bv64 8))))
 (let ((?x16213 (seq.unit (_ bv156 8))))
 (let ((?x2511 (seq.++ ?x16213 (seq.++ ?x5041 (seq.++ ?x18917 (seq.++ ?x1297 ?x435))))))
 (let ((?x4133 (seq.unit (_ bv2 8))))
 (let ((?x4976 (seq.unit (_ bv1 8))))
 (let ((?x11637 (seq.++ ?x4976 (seq.++ ?x7131 (seq.++ ?x24973 (seq.++ ?x4133 (seq.++ ?x4133 ?x2511)))))))
 (let ((?x3936 (seq.unit (_ bv200 8))))
 (let ((?x12878 (seq.unit (_ bv182 8))))
 (let ((?x2159 (seq.++ ?x12878 (seq.++ ?x3936 (seq.++ ?x7131 (seq.++ ?x24973 (seq.++ ?x4133 ?x11637)))))))
 (let ((?x4739 (seq.unit (_ bv17 8))))
 (let ((?x20132 (seq.++ ?x24973 (seq.++ ?x5041 (seq.++ ?x24973 (seq.++ ?x5041 (seq.++ ?x4739 ?x2159)))))))
 (let ((?x4921 (seq.unit (_ bv33 8))))
 (let ((?x14795 (seq.unit (_ bv69 8))))
 (let ((?x5674 (seq.++ ?x14795 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x4921 (seq.++ ?x24973 ?x20132)))))))
 (let (($x20381 (= v_1_pending_packet ?x5674)))
 (let (($x22776 (= v_1_ip_checksum 46792)))
 (let (($x2568 (= v_1_udp_checksum 49271)))
 (let (($x19951 (= v_1_udp_raw_checksum 49271)))
 (let (($x2433 (= v_1_ip_length 33)))
 (let (($x904 (= v_1_udp_length 13)))
 (let (($x16361 (= v_1_packet ?x5674)))
 (let ((?x3865 (seq.++ ?x4133 (seq.++ ?x4976 (seq.++ ?x7131 (seq.++ ?x24973 (seq.++ ?x4133 ?x4133)))))))
 (let ((?x7525 (seq.++ ?x7131 (seq.++ ?x24973 ?x3865))))
 (let ((?x18847 (seq.++ ?x24973 (seq.++ ?x5041 (seq.++ ?x4739 (seq.++ ?x12878 (seq.++ ?x3936 ?x7525)))))))
 (let ((?x22633 (seq.++ ?x24973 (seq.++ ?x4921 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x5041 ?x18847)))))))
 (let (($x2133 (= v_1_ip_wire (seq.++ ?x14795 (seq.++ ?x24973 ?x22633)))))
 (let ((?x6982 (seq.++ ?x24973 (seq.++ ?x5041 (seq.++ ?x4739 (seq.++ ?x24973 (seq.++ ?x24973 ?x7525)))))))
 (let ((?x49 (seq.++ ?x24973 (seq.++ ?x4921 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x5041 ?x6982)))))))
 (let (($x4101 (= v_1_ip_zero (seq.++ ?x14795 (seq.++ ?x24973 ?x49)))))
 (let (($x1204 (= v_1_udp_wire ?x2511)))
 (let ((?x7345 (seq.++ ?x4133 (seq.++ ?x4133 (seq.++ ?x24973 (seq.++ ?x4739 (seq.++ ?x24973 ?x4841)))))))
 (let ((?x7112 (seq.++ ?x24973 (seq.++ ?x4133 (seq.++ ?x4976 (seq.++ ?x7131 (seq.++ ?x24973 ?x7345)))))))
 (let (($x74 (= v_1_pseudoheader (seq.++ ?x7131 ?x7112))))
 (let ((?x1374 (seq.++ ?x1297 (seq.++ ?x24973 (seq.++ ?x4841 (seq.++ ?x24973 (seq.++ ?x24973 ?x87)))))))
 (let (($x7478 (= v_1_udp_zero (seq.++ ?x16213 (seq.++ ?x5041 (seq.++ ?x18917 ?x1374))))))
 (let (($x4305 (= v_1_payload ?x87)))
 (let (($x7069 (= v_1_cache_ttl_ms 60000)))
 (let (($x2792 (= 0 v_1_retry_count)))
 (let (($x246 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x3488 (= 1 state_1)))
 (let (($x1684 (not active_0_cache)))
 (let (($x19926 (or $x1684 (not (<= due_0_cache 0)))))
 (let (($x4564 (not active_0_query)))
 (let (($x911 (or $x4564 (not (<= due_0_query 0)))))
 (let (($x2173 (= state_0 0)))
 (and $x2173 (>= 0 now_0) $x911 $x19926 $x3488 $x246 $x2792 $x7069 v_1_checksums_enabled $x4305 $x7478 $x74 $x1204 $x4101 $x2133 $x16361 $x904 $x2433 $x19951 $x2568 $x22776 $x20381 $x2828 $x20394 (= v_1_rxudp_disposition "none") $x16212 $x5734 $x2808 $x5920 (= v_1_echo_disposition "none") active_1_query $x5465 $x7268 $x11498))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x391 (= due_2_query due_1_query)))
 (let (($x2198 (not active_2_query)))
 (let (($x3508 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x4622 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x4408 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x3493 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x6119 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x6118 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x569 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2659 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x4545 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x2771 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1362 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x574 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x5645 (= v_2_ip_length v_1_ip_length)))
 (let (($x4097 (= v_2_udp_length v_1_udp_length)))
 (let (($x3926 (= v_2_packet v_1_packet)))
 (let (($x262 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x5571 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x5570 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x4437 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x4404 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1520 (= v_2_payload v_1_payload)))
 (let (($x2620 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x927 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x23 (= 0 v_2_retry_count)))
 (let ((?x24973 (seq.unit (_ bv0 8))))
 (let ((?x6268 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.unit (_ bv2 8))))))))
 (let ((?x4133 (seq.unit (_ bv2 8))))
 (let (($x4114 (= v_2_peer_mac (seq.++ ?x4133 ?x6268))))
 (let (($x5244 (= 2 state_2)))
 (let (($x18945 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x6646 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x19250 (seq.len v_1_pending_packet)))
 (let (($x16233 (<= 28 ?x19250)))
 (let (($x3343 (= state_1 1)))
 (and $x3343 $x16233 $x6646 $x18945 $x5244 $x4114 $x23 $x927 $x2620 $x1520 $x4404 $x4437 $x5570 $x5571 $x262 $x3926 $x4097 $x5645 $x574 $x1362 $x2771 $x4545 $x2659 $x569 $x6118 $x6119 $x3493 $x4408 $x4622 $x3508 $x2198 active_2_cache $x391 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x21158 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x24973 (seq.unit (_ bv0 8))))
 (let ((?x87 (seq.++ ?x24973 ?x21158)))
 (= input_0_app.send_data ?x87)))))
(assert
 (= 26 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x7131 (seq.unit (_ bv192 8))))
(let ((?x7023 (seq.++ ?x7131 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x24973 (seq.unit (_ bv0 8))))
(let ((?x420 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 ?x7023)))))))
(let ((?x4133 (seq.unit (_ bv2 8))))
(let ((?x685 (seq.++ ?x7131 (seq.++ ?x24973 (seq.++ ?x4133 (seq.++ ?x4133 (seq.++ ?x24973 ?x420)))))))
(let ((?x2723 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x4133 ?x685)))))))
(let ((?x4976 (seq.unit (_ bv1 8))))
(let ((?x1722 (seq.unit (_ bv4 8))))
(let ((?x2981 (seq.unit (_ bv6 8))))
(let ((?x2832 (seq.++ ?x2981 (seq.++ ?x1722 (seq.++ ?x24973 (seq.++ ?x4976 (seq.++ ?x4133 ?x2723)))))))
(let ((?x91 (seq.unit (_ bv8 8))))
(let ((?x3496 (seq.++ ?x2981 (seq.++ ?x24973 (seq.++ ?x4976 (seq.++ ?x91 (seq.++ ?x24973 ?x2832)))))))
(let ((?x5366 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x24973 (seq.++ ?x4133 (seq.++ ?x91 ?x3496)))))))
(let ((?x1147 (seq.unit (_ bv255 8))))
(let ((?x2404 (seq.++ ?x1147 (seq.++ ?x1147 (seq.++ ?x1147 (seq.++ ?x4133 (seq.++ ?x24973 ?x5366)))))))
(let ((?x2915 (seq.++ ?x1147 (seq.++ ?x1147 (seq.++ ?x1147 ?x2404)))))
(= input_1_net.frame_frame ?x2915)))))))))))))))))))
(check-sat)

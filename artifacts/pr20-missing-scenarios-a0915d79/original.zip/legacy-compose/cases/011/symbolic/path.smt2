; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x15751 (= due_1_cache due_0_cache)))
 (let (($x6921 (= due_1_query 1000)))
 (let (($x5294 (= active_1_cache active_0_cache)))
 (let (($x276 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x12499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3942 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x72 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4348 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2611 (not v_1_rxudp_require_checksum)))
 (let (($x4252 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1279 (= v_1_ip_checksum 0)))
 (let (($x3288 (= v_1_udp_checksum 0)))
 (let (($x5565 (= v_1_udp_raw_checksum 0)))
 (let (($x1920 (= v_1_ip_length 0)))
 (let (($x3501 (= v_1_udp_length 0)))
 (let (($x11488 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x6266 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x9690 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4730 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4733 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2134 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3533 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x11747 (= v_1_cache_ttl_ms 60000)))
 (let (($x3554 (= 0 v_1_retry_count)))
 (let (($x15208 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1792 (= 1 state_1)))
 (let (($x5168 (not active_0_cache)))
 (let (($x436 (or $x5168 (not (<= due_0_cache 0)))))
 (let (($x22631 (not active_0_query)))
 (let (($x4731 (or $x22631 (not (<= due_0_query 0)))))
 (let (($x1674 (= state_0 0)))
 (and $x1674 (>= 0 now_0) $x4731 $x436 $x1792 $x15208 $x3554 $x11747 v_1_checksums_enabled $x3533 $x2134 $x4733 $x4730 $x9690 $x6266 $x11488 $x3501 $x1920 $x5565 $x3288 $x1279 $x4252 $x2611 $x4348 (= v_1_rxudp_disposition "none") $x72 $x3942 $x12499 $x276 (= v_1_echo_disposition "none") active_1_query $x5294 $x6921 $x15751)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2023 (= due_2_cache due_1_cache)))
 (let (($x5242 (= due_2_query 2000)))
 (let (($x281 (= active_2_cache active_1_cache)))
 (let (($x1289 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x1092 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x7681 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x16248 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x1667 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x4641 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x4906 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x4905 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x7209 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x317 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x24968 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x24967 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x14342 (= v_2_ip_length v_1_ip_length)))
 (let (($x1367 (= v_2_udp_length v_1_udp_length)))
 (let (($x1216 (= v_2_packet v_1_packet)))
 (let (($x1290 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x6301 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2695 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x5962 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1409 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x4090 (= v_2_payload v_1_payload)))
 (let (($x4865 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x5966 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x841 (= 1 v_2_retry_count)))
 (let (($x7294 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1276 (= 1 state_2)))
 (let (($x3554 (= 0 v_1_retry_count)))
 (let (($x7281 (= state_1 1)))
 (and $x7281 $x3554 active_1_query (= 1000 due_1_query) (or (not active_1_cache) (not (<= due_1_cache due_1_query))) $x1276 $x7294 $x841 $x5966 $x4865 $x4090 $x1409 $x5962 $x2695 $x6301 $x1290 $x1216 $x1367 $x14342 $x24967 $x24968 $x317 $x7209 $x4905 $x4906 $x4641 $x1667 $x16248 $x7681 $x1092 $x1289 active_2_query $x281 $x5242 $x2023)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x2773 (= due_3_cache due_2_cache)))
 (let (($x2772 (= due_3_query due_2_query)))
 (let (($x4815 (= active_3_cache active_2_cache)))
 (let (($x5574 (not active_3_query)))
 (let (($x5690 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x21089 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x3341 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x1461 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x4817 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x4816 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x1794 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x2526 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x9559 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x879 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x213 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x4281 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x3337 (= v_3_ip_length v_2_ip_length)))
 (let (($x4828 (= v_3_udp_length v_2_udp_length)))
 (let (($x2506 (= v_3_packet v_2_packet)))
 (let (($x7293 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x4812 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x1147 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x4401 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x3654 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x7246 (= v_3_payload v_2_payload)))
 (let (($x4142 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x27490 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x1268 (= 0 v_3_retry_count)))
 (let (($x3289 (= (as seq.empty (Seq (_ BitVec 8))) v_3_peer_mac)))
 (let (($x1578 (= 0 state_3)))
 (let ((?x7438 (seq.len v_2_pending_packet)))
 (let (($x938 (= 0 ?x7438)))
 (let (($x841 (= 1 v_2_retry_count)))
 (let (($x1539 (= state_2 1)))
 (and $x1539 $x841 $x938 active_2_query (= 2000 due_2_query) (or (not active_2_cache) (not (<= due_2_cache due_2_query))) $x1578 $x3289 $x1268 $x27490 $x4142 $x7246 $x3654 $x4401 $x1147 $x4812 $x7293 $x2506 $x4828 $x3337 $x4281 $x213 $x879 $x9559 $x2526 $x1794 $x4816 $x4817 $x1461 $x3341 $x21089 $x5690 $x5574 $x4815 $x2772 $x2773))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2150 (seq.unit (_ bv192 8))))
 (let ((?x21254 (seq.++ ?x2150 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x21254))))
(assert
 (= 3 choice_1))
(assert
 (= 1000 now_2))
(assert
 (= 25 choice_2))
(assert
 (= 2000 now_3))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1686 (= due_1_cache due_0_cache)))
 (let (($x6224 (= due_1_query 1000)))
 (let (($x5865 (= active_1_cache active_0_cache)))
 (let (($x7301 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3525 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x677 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x7164 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1496 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x13313 (not v_1_rxudp_require_checksum)))
 (let (($x6128 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x6936 (= v_1_ip_checksum 0)))
 (let (($x6937 (= v_1_udp_checksum 0)))
 (let (($x6938 (= v_1_udp_raw_checksum 0)))
 (let (($x6939 (= v_1_ip_length 0)))
 (let (($x6940 (= v_1_udp_length 0)))
 (let (($x2815 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2814 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2813 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x2812 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x2811 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2810 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2807 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x6340 (= v_1_cache_ttl_ms 60000)))
 (let (($x2637 (= 0 v_1_retry_count)))
 (let (($x7033 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4055 (= 1 state_1)))
 (let (($x4759 (not active_0_cache)))
 (let (($x7032 (or $x4759 (not (<= due_0_cache 0)))))
 (let (($x4757 (not active_0_query)))
 (let (($x7029 (or $x4757 (not (<= due_0_query 0)))))
 (let (($x7069 (= state_0 0)))
 (and $x7069 (>= 0 now_0) $x7029 $x7032 $x4055 $x7033 $x2637 $x6340 v_1_checksums_enabled $x2807 $x2810 $x2811 $x2812 $x2813 $x2814 $x2815 $x6940 $x6939 $x6938 $x6937 $x6936 $x6128 $x13313 $x1496 (= v_1_rxudp_disposition "none") $x7164 $x677 $x3525 $x7301 (= v_1_echo_disposition "none") active_1_query $x5865 $x6224 $x1686)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2233 (= due_2_cache due_1_cache)))
 (let (($x2228 (= due_2_query due_1_query)))
 (let (($x2225 (= active_2_cache active_1_cache)))
 (let (($x2224 (= active_2_query active_1_query)))
 (let (($x2223 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2222 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2221 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x2220 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x2219 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x1827 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2218 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2217 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let ((?x4459 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x3596 (seq.unit (_ bv0 8))))
 (let ((?x5056 (seq.++ ?x3596 ?x4459)))
 (let ((?x7686 (seq.++ (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49271 0)))) ?x5056)))
 (let ((?x26343 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49271 0)))) ?x7686)))
 (let ((?x3620 (seq.unit (_ bv13 8))))
 (let ((?x1733 (seq.unit (_ bv144 8))))
 (let ((?x3146 (seq.unit (_ bv31 8))))
 (let ((?x4741 (seq.unit (_ bv64 8))))
 (let ((?x22733 (seq.++ ?x4741 (seq.++ ?x3146 (seq.++ ?x1733 (seq.++ ?x3596 (seq.++ ?x3620 ?x26343)))))))
 (let ((?x27364 (seq.unit (_ bv156 8))))
 (let ((?x23839 (seq.++ ?x27364 ?x22733)))
 (let ((?x1598 (seq.unit (_ bv2 8))))
 (let ((?x1703 (seq.unit (_ bv192 8))))
 (let ((?x1722 (seq.unit (_ bv1 8))))
 (let ((?x2387 (seq.++ ?x1722 (seq.++ ?x1703 (seq.++ ?x3596 (seq.++ ?x1598 (seq.++ ?x1598 ?x23839)))))))
 (let ((?x12698 (seq.unit (_ bv200 8))))
 (let ((?x15318 (seq.unit (_ bv182 8))))
 (let ((?x16262 (seq.++ ?x15318 (seq.++ ?x12698 (seq.++ ?x1703 (seq.++ ?x3596 (seq.++ ?x1598 ?x2387)))))))
 (let ((?x3815 (seq.unit (_ bv17 8))))
 (let ((?x12382 (seq.++ ?x3596 (seq.++ ?x4741 (seq.++ ?x3596 (seq.++ ?x4741 (seq.++ ?x3815 ?x16262)))))))
 (let ((?x26359 (seq.unit (_ bv33 8))))
 (let ((?x4735 (seq.unit (_ bv69 8))))
 (let ((?x26451 (seq.++ ?x4735 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x26359 (seq.++ ?x3596 ?x12382)))))))
 (let (($x22565 (= v_2_pending_packet ?x26451)))
 (let (($x22564 (= v_2_ip_checksum 46792)))
 (let ((?x17540 (ite v_1_checksums_enabled 49271 0)))
 (let (($x11486 (= v_2_udp_checksum ?x17540)))
 (let (($x11485 (= v_2_udp_raw_checksum 49271)))
 (let (($x23835 (= v_2_ip_length 33)))
 (let (($x829 (= v_2_udp_length 13)))
 (let (($x26452 (= v_2_packet ?x26451)))
 (let ((?x2018 (seq.++ ?x1598 (seq.++ ?x1722 (seq.++ ?x1703 (seq.++ ?x3596 (seq.++ ?x1598 ?x1598)))))))
 (let ((?x2987 (seq.++ ?x1703 (seq.++ ?x3596 ?x2018))))
 (let ((?x15210 (seq.++ ?x3596 (seq.++ ?x4741 (seq.++ ?x3815 (seq.++ ?x15318 (seq.++ ?x12698 ?x2987)))))))
 (let ((?x13830 (seq.++ ?x3596 (seq.++ ?x26359 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x4741 ?x15210)))))))
 (let (($x8457 (= v_2_ip_wire (seq.++ ?x4735 (seq.++ ?x3596 ?x13830)))))
 (let ((?x9067 (seq.++ ?x3596 (seq.++ ?x4741 (seq.++ ?x3815 (seq.++ ?x3596 (seq.++ ?x3596 ?x2987)))))))
 (let ((?x27684 (seq.++ ?x3596 (seq.++ ?x26359 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x4741 ?x9067)))))))
 (let (($x4213 (= v_2_ip_zero (seq.++ ?x4735 (seq.++ ?x3596 ?x27684)))))
 (let (($x23840 (= v_2_udp_wire ?x23839)))
 (let ((?x3939 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x3596 (seq.++ ?x3815 (seq.++ ?x3596 ?x3620)))))))
 (let ((?x7037 (seq.++ ?x3596 (seq.++ ?x1598 (seq.++ ?x1722 (seq.++ ?x1703 (seq.++ ?x3596 ?x3939)))))))
 (let (($x3872 (= v_2_pseudoheader (seq.++ ?x1703 ?x7037))))
 (let ((?x5577 (seq.++ ?x1733 (seq.++ ?x3596 (seq.++ ?x3620 (seq.++ ?x3596 (seq.++ ?x3596 ?x5056)))))))
 (let (($x3513 (= v_2_udp_zero (seq.++ ?x27364 (seq.++ ?x4741 (seq.++ ?x3146 ?x5577))))))
 (let (($x4012 (= v_2_payload ?x5056)))
 (let (($x2203 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2202 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2201 (= v_2_retry_count v_1_retry_count)))
 (let (($x2200 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x2199 (= 1 state_2)))
 (let (($x3962 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x264 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x1299 (= state_1 1)))
 (and $x1299 $x264 $x3962 $x2199 $x2200 $x2201 $x2202 $x2203 $x4012 $x3513 $x3872 $x23840 $x4213 $x8457 $x26452 $x829 $x23835 $x11485 $x11486 $x22564 $x22565 $x2217 $x2218 $x1827 $x2219 $x2220 $x2221 $x2222 $x2223 $x2224 $x2225 $x2228 $x2233)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x4769 (= due_3_query due_2_query)))
 (let (($x11629 (not active_3_query)))
 (let (($x7436 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x4317 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x6136 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x2824 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x2638 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x1262 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x6103 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x5716 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x11628 (= (as seq.empty (Seq (_ BitVec 8))) v_3_pending_packet)))
 (let (($x6342 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x4494 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x4920 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x4668 (= v_3_ip_length v_2_ip_length)))
 (let (($x4495 (= v_3_udp_length v_2_udp_length)))
 (let (($x4983 (= v_3_packet v_2_packet)))
 (let (($x5794 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x3110 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x4562 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1073 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x6343 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x5841 (= v_3_payload v_2_payload)))
 (let (($x6326 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x6325 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x3553 (= 0 v_3_retry_count)))
 (let ((?x3596 (seq.unit (_ bv0 8))))
 (let ((?x2679 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.unit (_ bv2 8))))))))
 (let ((?x1598 (seq.unit (_ bv2 8))))
 (let (($x15752 (= v_3_peer_mac (seq.++ ?x1598 ?x2679))))
 (let (($x1494 (= 2 state_3)))
 (let (($x15751 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x5805 (or (not active_2_query) (not (<= due_2_query 10)))))
 (let ((?x7481 (seq.len v_2_pending_packet)))
 (let (($x4805 (<= 28 ?x7481)))
 (let (($x2741 (= state_2 1)))
 (and $x2741 $x4805 $x5805 $x15751 $x1494 $x15752 $x3553 $x6325 $x6326 $x5841 $x6343 $x1073 $x4562 $x3110 $x5794 $x4983 $x4495 $x4668 $x4920 $x4494 $x6342 $x11628 $x5716 $x6103 $x1262 $x2638 $x2824 $x6136 $x4317 $x7436 $x11629 active_3_cache $x4769 (= due_3_cache (+ 10 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1703 (seq.unit (_ bv192 8))))
 (let ((?x705 (seq.++ ?x1703 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x705))))
(assert
 (= 20 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x4459 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x3596 (seq.unit (_ bv0 8))))
 (let ((?x5056 (seq.++ ?x3596 ?x4459)))
 (= input_1_app.send_data ?x5056)))))
(assert
 (= 28 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x1703 (seq.unit (_ bv192 8))))
(let ((?x5860 (seq.++ ?x1703 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x1722 (seq.unit (_ bv1 8))))
(let ((?x3596 (seq.unit (_ bv0 8))))
(let ((?x2946 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x1722 ?x5860)))))))
(let ((?x1598 (seq.unit (_ bv2 8))))
(let ((?x4420 (seq.++ ?x1703 (seq.++ ?x3596 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 ?x2946)))))))
(let ((?x10961 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x1598 ?x4420)))))))
(let ((?x1700 (seq.unit (_ bv4 8))))
(let ((?x1702 (seq.unit (_ bv6 8))))
(let ((?x12888 (seq.++ ?x1702 (seq.++ ?x1700 (seq.++ ?x3596 (seq.++ ?x1598 (seq.++ ?x1598 ?x10961)))))))
(let ((?x1705 (seq.unit (_ bv8 8))))
(let ((?x191 (seq.++ ?x1702 (seq.++ ?x3596 (seq.++ ?x1722 (seq.++ ?x1705 (seq.++ ?x3596 ?x12888)))))))
(let ((?x23177 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x1598 (seq.++ ?x1705 ?x191)))))))
(let ((?x4245 (seq.++ ?x3596 (seq.++ ?x3596 (seq.++ ?x1722 (seq.++ ?x1598 (seq.++ ?x3596 ?x23177)))))))
(let ((?x9804 (seq.++ ?x1598 (seq.++ ?x3596 (seq.++ ?x3596 ?x4245)))))
(= input_2_net.frame_frame ?x9804))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2699 (= due_1_cache due_0_cache)))
 (let (($x4486 (= due_1_query 1000)))
 (let (($x7463 (= active_1_cache active_0_cache)))
 (let (($x4352 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3025 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3024 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3863 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x3026 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x6285 (not v_1_rxudp_require_checksum)))
 (let ((?x514 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x432 (seq.unit (_ bv0 8))))
 (let ((?x513 (seq.++ ?x432 ?x514)))
 (let ((?x5789 (seq.unit (_ bv192 8))))
 (let ((?x5314 (seq.unit (_ bv13 8))))
 (let ((?x6513 (seq.++ ?x432 (seq.++ ?x5314 (seq.++ ?x5789 (seq.++ (seq.unit (_ bv119 8)) ?x513))))))
 (let ((?x1153 (seq.unit (_ bv144 8))))
 (let ((?x6034 (seq.unit (_ bv31 8))))
 (let ((?x7527 (seq.unit (_ bv64 8))))
 (let ((?x7315 (seq.unit (_ bv156 8))))
 (let ((?x866 (seq.++ ?x7315 (seq.++ ?x7527 (seq.++ ?x6034 (seq.++ ?x1153 ?x6513))))))
 (let ((?x5732 (seq.unit (_ bv2 8))))
 (let ((?x7370 (seq.unit (_ bv1 8))))
 (let ((?x7279 (seq.++ ?x7370 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x5732 ?x866)))))))
 (let ((?x1217 (seq.unit (_ bv200 8))))
 (let ((?x355 (seq.unit (_ bv182 8))))
 (let ((?x5804 (seq.++ ?x355 (seq.++ ?x1217 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 ?x7279)))))))
 (let ((?x2494 (seq.unit (_ bv17 8))))
 (let ((?x121 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x2494 ?x5804)))))))
 (let ((?x4236 (seq.unit (_ bv33 8))))
 (let ((?x4160 (seq.unit (_ bv69 8))))
 (let ((?x4095 (seq.++ ?x4160 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x4236 (seq.++ ?x432 ?x121)))))))
 (let (($x172 (= v_1_pending_packet ?x4095)))
 (let (($x364 (= v_1_ip_checksum 46792)))
 (let (($x7415 (= v_1_udp_checksum 49271)))
 (let (($x4611 (= v_1_udp_raw_checksum 49271)))
 (let (($x1455 (= v_1_ip_length 33)))
 (let (($x1227 (= v_1_udp_length 13)))
 (let (($x7375 (= v_1_packet ?x4095)))
 (let ((?x199 (seq.++ ?x5732 (seq.++ ?x7370 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 ?x5732)))))))
 (let ((?x197 (seq.++ ?x5789 (seq.++ ?x432 ?x199))))
 (let ((?x244 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x2494 (seq.++ ?x355 (seq.++ ?x1217 ?x197)))))))
 (let ((?x6019 (seq.++ ?x432 (seq.++ ?x4236 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7527 ?x244)))))))
 (let (($x1011 (= v_1_ip_wire (seq.++ ?x4160 (seq.++ ?x432 ?x6019)))))
 (let ((?x211 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x2494 (seq.++ ?x432 (seq.++ ?x432 ?x197)))))))
 (let ((?x2739 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7527 ?x211)))))
 (let (($x4178 (= v_1_ip_zero (seq.++ ?x4160 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x4236 ?x2739)))))))
 (let (($x2651 (= v_1_udp_wire ?x866)))
 (let ((?x526 (seq.++ ?x5732 (seq.++ ?x5732 (seq.++ ?x432 (seq.++ ?x2494 (seq.++ ?x432 ?x5314)))))))
 (let ((?x2503 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x7370 (seq.++ ?x5789 (seq.++ ?x432 ?x526)))))))
 (let (($x2508 (= v_1_pseudoheader (seq.++ ?x5789 ?x2503))))
 (let ((?x888 (seq.++ ?x1153 (seq.++ ?x432 (seq.++ ?x5314 (seq.++ ?x432 (seq.++ ?x432 ?x513)))))))
 (let (($x6469 (= v_1_udp_zero (seq.++ ?x7315 (seq.++ ?x7527 (seq.++ ?x6034 ?x888))))))
 (let (($x4256 (= v_1_payload ?x513)))
 (let (($x5401 (= v_1_cache_ttl_ms 60000)))
 (let (($x909 (= 0 v_1_retry_count)))
 (let (($x5344 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x2466 (= 1 state_1)))
 (let (($x5746 (not active_0_cache)))
 (let (($x5298 (or $x5746 (not (<= due_0_cache 0)))))
 (let (($x7545 (not active_0_query)))
 (let (($x5267 (or $x7545 (not (<= due_0_query 0)))))
 (let (($x1301 (= state_0 0)))
 (and $x1301 (>= 0 now_0) $x5267 $x5298 $x2466 $x5344 $x909 $x5401 v_1_checksums_enabled $x4256 $x6469 $x2508 $x2651 $x4178 $x1011 $x7375 $x1227 $x1455 $x4611 $x7415 $x364 $x172 $x6285 $x3026 (= v_1_rxudp_disposition "none") $x3863 $x3024 $x3025 $x4352 (= v_1_echo_disposition "none") active_1_query $x7463 $x4486 $x2699))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3718 (= due_2_cache due_1_cache)))
 (let (($x3717 (= due_2_query due_1_query)))
 (let (($x3716 (= active_2_cache active_1_cache)))
 (let (($x3715 (= active_2_query active_1_query)))
 (let (($x3714 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x3713 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x3712 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x3711 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x3710 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x3709 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x3708 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x3707 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let ((?x1279 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49161 0)))) (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49161 0)))))))
 (let ((?x5887 (seq.unit (_ bv8 8))))
 (let ((?x432 (seq.unit (_ bv0 8))))
 (let ((?x1153 (seq.unit (_ bv144 8))))
 (let ((?x6034 (seq.unit (_ bv31 8))))
 (let ((?x7527 (seq.unit (_ bv64 8))))
 (let ((?x5292 (seq.++ ?x7527 (seq.++ ?x6034 (seq.++ ?x1153 (seq.++ ?x432 (seq.++ ?x5887 ?x1279)))))))
 (let ((?x7315 (seq.unit (_ bv156 8))))
 (let ((?x536 (seq.++ ?x7315 ?x5292)))
 (let ((?x5732 (seq.unit (_ bv2 8))))
 (let ((?x5789 (seq.unit (_ bv192 8))))
 (let ((?x7370 (seq.unit (_ bv1 8))))
 (let ((?x310 (seq.++ ?x7370 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x5732 ?x536)))))))
 (let ((?x1457 (seq.unit (_ bv205 8))))
 (let ((?x355 (seq.unit (_ bv182 8))))
 (let ((?x3791 (seq.++ ?x355 (seq.++ ?x1457 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 ?x310)))))))
 (let ((?x2494 (seq.unit (_ bv17 8))))
 (let ((?x358 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x2494 ?x3791)))))))
 (let ((?x7486 (seq.unit (_ bv28 8))))
 (let ((?x4160 (seq.unit (_ bv69 8))))
 (let ((?x5516 (seq.++ ?x4160 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7486 (seq.++ ?x432 ?x358)))))))
 (let (($x2890 (= v_2_pending_packet ?x5516)))
 (let (($x2729 (= v_2_ip_checksum 46797)))
 (let ((?x5305 (ite v_1_checksums_enabled 49161 0)))
 (let (($x4572 (= v_2_udp_checksum ?x5305)))
 (let (($x6250 (= v_2_udp_raw_checksum 49161)))
 (let (($x6251 (= v_2_ip_length 28)))
 (let (($x2804 (= v_2_udp_length 8)))
 (let (($x5513 (= v_2_packet ?x5516)))
 (let ((?x199 (seq.++ ?x5732 (seq.++ ?x7370 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 ?x5732)))))))
 (let ((?x197 (seq.++ ?x5789 (seq.++ ?x432 ?x199))))
 (let ((?x6533 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x2494 (seq.++ ?x355 (seq.++ ?x1457 ?x197)))))))
 (let ((?x6473 (seq.++ ?x432 (seq.++ ?x7486 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7527 ?x6533)))))))
 (let (($x552 (= v_2_ip_wire (seq.++ ?x4160 (seq.++ ?x432 ?x6473)))))
 (let ((?x211 (seq.++ ?x432 (seq.++ ?x7527 (seq.++ ?x2494 (seq.++ ?x432 (seq.++ ?x432 ?x197)))))))
 (let ((?x2739 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7527 ?x211)))))
 (let (($x4088 (= v_2_ip_zero (seq.++ ?x4160 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7486 ?x2739)))))))
 (let (($x4633 (= v_2_udp_wire ?x536)))
 (let ((?x4243 (seq.++ ?x5732 (seq.++ ?x5732 (seq.++ ?x432 (seq.++ ?x2494 (seq.++ ?x432 ?x5887)))))))
 (let ((?x4181 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x7370 (seq.++ ?x5789 (seq.++ ?x432 ?x4243)))))))
 (let (($x2761 (= v_2_pseudoheader (seq.++ ?x5789 ?x4181))))
 (let ((?x2521 (seq.++ ?x6034 (seq.++ ?x1153 (seq.++ ?x432 (seq.++ ?x5887 (seq.++ ?x432 ?x432)))))))
 (let (($x3877 (= v_2_udp_zero (seq.++ ?x7315 (seq.++ ?x7527 ?x2521)))))
 (let (($x5986 (= (as seq.empty (Seq (_ BitVec 8))) v_2_payload)))
 (let (($x3694 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3693 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x3692 (= v_2_retry_count v_1_retry_count)))
 (let (($x3691 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x3690 (= 1 state_2)))
 (let (($x1130 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x2393 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x7427 (= state_1 1)))
 (and $x7427 $x2393 $x1130 $x3690 $x3691 $x3692 $x3693 $x3694 $x5986 $x3877 $x2761 $x4633 $x4088 $x552 $x5513 $x2804 $x6251 $x6250 $x4572 $x2729 $x2890 $x3707 $x3708 $x3709 $x3710 $x3711 $x3712 $x3713 $x3714 $x3715 $x3716 $x3717 $x3718))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x5081 (= due_3_query due_2_query)))
 (let (($x7098 (not active_3_query)))
 (let (($x5078 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x5077 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x5076 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x5075 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x5074 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x5073 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x5072 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x5071 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x2510 (= (as seq.empty (Seq (_ BitVec 8))) v_3_pending_packet)))
 (let (($x5069 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x5068 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x5067 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x5066 (= v_3_ip_length v_2_ip_length)))
 (let (($x5065 (= v_3_udp_length v_2_udp_length)))
 (let (($x5064 (= v_3_packet v_2_packet)))
 (let (($x5063 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x5062 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x5061 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x5060 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x5059 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x5058 (= v_3_payload v_2_payload)))
 (let (($x5057 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x5056 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x4663 (= 0 v_3_retry_count)))
 (let ((?x432 (seq.unit (_ bv0 8))))
 (let ((?x6530 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.unit (_ bv2 8))))))))
 (let ((?x5732 (seq.unit (_ bv2 8))))
 (let (($x5350 (= v_3_peer_mac (seq.++ ?x5732 ?x6530))))
 (let (($x5054 (= 2 state_3)))
 (let (($x4194 (or (not active_2_cache) (not (<= due_2_cache 6)))))
 (let (($x2851 (or (not active_2_query) (not (<= due_2_query 6)))))
 (let ((?x5016 (seq.len v_2_pending_packet)))
 (let (($x5017 (<= 28 ?x5016)))
 (let (($x6465 (= state_2 1)))
 (and $x6465 $x5017 $x2851 $x4194 $x5054 $x5350 $x4663 $x5056 $x5057 $x5058 $x5059 $x5060 $x5061 $x5062 $x5063 $x5064 $x5065 $x5066 $x5067 $x5068 $x5069 $x2510 $x5071 $x5072 $x5073 $x5074 $x5075 $x5076 $x5077 $x5078 $x7098 active_3_cache $x5081 (= due_3_cache (+ 6 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x514 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x432 (seq.unit (_ bv0 8))))
 (let ((?x513 (seq.++ ?x432 ?x514)))
 (= input_0_app.send_data ?x513)))))
(assert
 (= 20 choice_1))
(assert
 (= 5 now_2))
(assert
 (= input_1_app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 28 choice_2))
(assert
 (= 6 now_3))
(assert
 (let ((?x5789 (seq.unit (_ bv192 8))))
(let ((?x6581 (seq.++ ?x5789 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x7370 (seq.unit (_ bv1 8))))
(let ((?x432 (seq.unit (_ bv0 8))))
(let ((?x309 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7370 ?x6581)))))))
(let ((?x5732 (seq.unit (_ bv2 8))))
(let ((?x5895 (seq.++ ?x5789 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x5732 (seq.++ ?x5732 ?x309)))))))
(let ((?x3798 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x5732 ?x5895)))))))
(let ((?x6048 (seq.unit (_ bv4 8))))
(let ((?x1242 (seq.unit (_ bv6 8))))
(let ((?x4537 (seq.++ ?x1242 (seq.++ ?x6048 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x5732 ?x3798)))))))
(let ((?x5887 (seq.unit (_ bv8 8))))
(let ((?x1226 (seq.++ ?x1242 (seq.++ ?x432 (seq.++ ?x7370 (seq.++ ?x5887 (seq.++ ?x432 ?x4537)))))))
(let ((?x1086 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x5732 (seq.++ ?x5887 ?x1226)))))))
(let ((?x1407 (seq.++ ?x432 (seq.++ ?x432 (seq.++ ?x7370 (seq.++ ?x5732 (seq.++ ?x432 ?x1086)))))))
(let ((?x4566 (seq.++ ?x5732 (seq.++ ?x432 (seq.++ ?x432 ?x1407)))))
(= input_2_net.frame_frame ?x4566))))))))))))))))))
(check-sat)

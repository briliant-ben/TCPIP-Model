; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_echo_disposition () String)
(declare-fun v_4_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_4_rxudp_disposition () String)
(declare-fun v_4_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_rxudp_require_checksum () Bool)
(declare-fun v_4_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_checksum () Int)
(declare-fun v_4_udp_checksum () Int)
(declare-fun v_4_udp_raw_checksum () Int)
(declare-fun v_4_ip_length () Int)
(declare-fun v_4_udp_length () Int)
(declare-fun v_4_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_checksums_enabled () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.cache_ttl_milliseconds () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.cache_ttl_milliseconds () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x319 (= due_1_cache due_0_cache)))
 (let (($x318 (= due_1_query due_0_query)))
 (let (($x317 (= active_1_cache active_0_cache)))
 (let (($x316 (= active_1_query active_0_query)))
 (let (($x2312 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2258 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x2260 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x2311 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x2310 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2104 (not v_1_rxudp_require_checksum)))
 (let (($x2309 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2322 (= v_1_ip_checksum 0)))
 (let (($x5139 (= v_1_udp_checksum 0)))
 (let (($x3726 (= v_1_udp_raw_checksum 0)))
 (let (($x3733 (= v_1_ip_length 0)))
 (let (($x3734 (= v_1_udp_length 0)))
 (let (($x2305 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2304 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2301 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x2298 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x2297 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2296 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2293 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x867 (= v_1_cache_ttl_ms 120000)))
 (let (($x860 (= v_1_retry_count 0)))
 (let (($x2294 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x290 (= 0 state_1)))
 (let (($x243 (not active_0_cache)))
 (let (($x2289 (or $x243 (not (<= due_0_cache 0)))))
 (let (($x241 (not active_0_query)))
 (let (($x2284 (or $x241 (not (<= due_0_query 0)))))
 (let (($x161 (= state_0 0)))
 (and $x161 (>= 0 now_0) $x2284 $x2289 $x290 $x2294 $x860 $x867 v_1_checksums_enabled $x2293 $x2296 $x2297 $x2298 $x2301 $x2304 $x2305 $x3734 $x3733 $x3726 $x5139 $x2322 $x2309 $x2104 $x2310 (= v_1_rxudp_disposition "none") $x2311 $x2260 $x2258 $x2312 (= v_1_echo_disposition "none") $x316 $x317 $x318 $x319))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1940 (= due_2_query due_1_query)))
 (let (($x6184 (not active_2_query)))
 (let (($x1937 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x1936 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x1935 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x1934 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x1933 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x1932 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x1931 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x1930 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x1929 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x1928 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1927 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1926 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1925 (= v_2_ip_length v_1_ip_length)))
 (let (($x1924 (= v_2_udp_length v_1_udp_length)))
 (let (($x1923 (= v_2_packet v_1_packet)))
 (let (($x1922 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1921 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1920 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1919 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1918 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1917 (= v_2_payload v_1_payload)))
 (let (($x1916 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1915 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1914 (= 0 v_2_retry_count)))
 (let ((?x259 (seq.unit (_ bv0 8))))
 (let ((?x3738 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.unit (_ bv2 8))))))))
 (let ((?x261 (seq.unit (_ bv2 8))))
 (let (($x6183 (= v_2_peer_mac (seq.++ ?x261 ?x3738))))
 (let (($x1912 (= 2 state_2)))
 (let (($x6182 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x6178 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x870 (= state_1 0)))
 (and $x870 $x6178 $x6182 $x1912 $x6183 $x1914 $x1915 $x1916 $x1917 $x1918 $x1919 $x1920 $x1921 $x1922 $x1923 $x1924 $x1925 $x1926 $x1927 $x1928 $x1929 $x1930 $x1931 $x1932 $x1933 $x1934 $x1935 $x1936 $x1937 $x6184 active_2_cache $x1940 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x238 (= due_3_cache 60020)))
 (let (($x3416 (= due_3_query due_2_query)))
 (let (($x3414 (= active_3_query active_2_query)))
 (let (($x3413 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x3412 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x3411 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x3410 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x3409 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x3408 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x3407 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x3406 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x3405 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x3404 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x3403 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x3402 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x3401 (= v_3_ip_length v_2_ip_length)))
 (let (($x3400 (= v_3_udp_length v_2_udp_length)))
 (let (($x3399 (= v_3_packet v_2_packet)))
 (let (($x3398 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x3397 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x3396 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x3395 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x3394 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x3393 (= v_3_payload v_2_payload)))
 (let (($x3392 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2327 (= v_3_cache_ttl_ms 60000)))
 (let (($x3390 (= v_3_retry_count v_2_retry_count)))
 (let (($x3389 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x3388 (= 2 state_3)))
 (let (($x2259 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x6184 (not active_2_query)))
 (let (($x866 (or $x6184 (not (<= due_2_query 20)))))
 (let (($x2330 (= state_2 2)))
 (and $x2330 $x866 $x2259 $x3388 $x3389 $x3390 $x2327 $x3392 $x3393 $x3394 $x3395 $x3396 $x3397 $x3398 $x3399 $x3400 $x3401 $x3402 $x3403 $x3404 $x3405 $x3406 $x3407 $x3408 $x3409 $x3410 $x3411 $x3412 $x3413 $x3414 active_3_cache $x3416 $x238)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x4772 (= due_4_cache due_3_cache)))
 (let (($x4771 (= due_4_query due_3_query)))
 (let (($x2320 (not active_4_cache)))
 (let (($x4769 (= active_4_query active_3_query)))
 (let (($x4768 (= v_4_echo_disposition v_3_echo_disposition)))
 (let (($x4767 (= v_4_echo_ip_zero v_3_echo_ip_zero)))
 (let (($x4766 (= v_4_echo_icmp_wire v_3_echo_icmp_wire)))
 (let (($x4765 (= v_4_echo_icmp_zero v_3_echo_icmp_zero)))
 (let (($x4764 (= v_4_echo_reply v_3_echo_reply)))
 (let (($x4763 (= v_4_rxudp_disposition v_3_rxudp_disposition)))
 (let (($x4762 (= v_4_rxudp_payload v_3_rxudp_payload)))
 (let (($x4761 (= v_4_rxudp_require_checksum v_3_rxudp_require_checksum)))
 (let (($x4760 (= v_4_pending_packet v_3_pending_packet)))
 (let (($x4759 (= v_4_ip_checksum v_3_ip_checksum)))
 (let (($x4758 (= v_4_udp_checksum v_3_udp_checksum)))
 (let (($x4757 (= v_4_udp_raw_checksum v_3_udp_raw_checksum)))
 (let (($x4756 (= v_4_ip_length v_3_ip_length)))
 (let (($x4755 (= v_4_udp_length v_3_udp_length)))
 (let (($x4754 (= v_4_packet v_3_packet)))
 (let (($x4753 (= v_4_ip_wire v_3_ip_wire)))
 (let (($x4752 (= v_4_ip_zero v_3_ip_zero)))
 (let (($x4751 (= v_4_udp_wire v_3_udp_wire)))
 (let (($x4750 (= v_4_pseudoheader v_3_pseudoheader)))
 (let (($x4749 (= v_4_udp_zero v_3_udp_zero)))
 (let (($x4748 (= v_4_payload v_3_payload)))
 (let (($x4747 (= v_4_checksums_enabled v_3_checksums_enabled)))
 (let (($x4746 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x4745 (= 0 v_4_retry_count)))
 (let (($x2335 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x4743 (= 0 state_4)))
 (let (($x3746 (= state_3 2)))
 (and $x3746 active_3_cache (= 60020 due_3_cache) (or (not active_3_query) (<= due_3_cache due_3_query)) $x4743 $x2335 $x4745 $x4746 $x4747 $x4748 $x4749 $x4750 $x4751 $x4752 $x4753 $x4754 $x4755 $x4756 $x4757 $x4758 $x4759 $x4760 $x4761 $x4762 $x4763 $x4764 $x4765 $x4766 $x4767 $x4768 $x4769 $x2320 $x4771 $x4772)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 5 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 120000 input_0_app.cache_ttl_milliseconds))
(assert
 (= 8 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x257 (seq.unit (_ bv192 8))))
 (let ((?x417 (seq.++ ?x257 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x337 (seq.unit (_ bv1 8))))
 (let ((?x259 (seq.unit (_ bv0 8))))
 (let ((?x6120 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x337 ?x417)))))))
 (let ((?x261 (seq.unit (_ bv2 8))))
 (let ((?x6125 (seq.++ ?x257 (seq.++ ?x259 (seq.++ ?x261 (seq.++ ?x261 (seq.++ ?x261 ?x6120)))))))
 (let ((?x6130 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x261 ?x6125)))))))
 (let ((?x366 (seq.unit (_ bv4 8))))
 (let ((?x364 (seq.unit (_ bv6 8))))
 (let ((?x6135 (seq.++ ?x364 (seq.++ ?x366 (seq.++ ?x259 (seq.++ ?x261 (seq.++ ?x261 ?x6130)))))))
 (let ((?x362 (seq.unit (_ bv8 8))))
 (let ((?x6140 (seq.++ ?x364 (seq.++ ?x259 (seq.++ ?x337 (seq.++ ?x362 (seq.++ ?x259 ?x6135)))))))
 (let ((?x6145 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x261 (seq.++ ?x362 ?x6140)))))))
 (let ((?x6150 (seq.++ ?x259 (seq.++ ?x259 (seq.++ ?x337 (seq.++ ?x261 (seq.++ ?x259 ?x6145)))))))
 (let ((?x6153 (seq.++ ?x261 (seq.++ ?x259 (seq.++ ?x259 ?x6150)))))
 (= input_1_net.frame_frame ?x6153))))))))))))))))))
(assert
 (= 13 choice_2))
(assert
 (= 20 now_3))
(assert
 (= 60000 input_2_app.cache_ttl_milliseconds))
(assert
 (= 4 choice_3))
(assert
 (= 60020 now_4))
(check-sat)

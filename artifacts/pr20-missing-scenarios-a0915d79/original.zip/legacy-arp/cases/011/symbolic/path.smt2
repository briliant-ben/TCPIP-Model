; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1464 (= due_1_cache due_0_cache)))
 (let (($x254 (= due_1_query due_0_query)))
 (let (($x2064 (= active_1_cache active_0_cache)))
 (let (($x2328 (= active_1_query active_0_query)))
 (let (($x246 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x566 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x449 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x780 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x156 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x568 (not v_1_rxudp_require_checksum)))
 (let (($x4631 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2485 (= v_1_ip_checksum 0)))
 (let (($x4630 (= v_1_udp_checksum 0)))
 (let (($x4705 (= v_1_udp_raw_checksum 0)))
 (let (($x4704 (= v_1_ip_length 0)))
 (let (($x4780 (= v_1_udp_length 0)))
 (let (($x2325 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x996 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2962 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1789 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x2589 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x52 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4739 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x4779 (= v_1_cache_ttl_ms 60000)))
 (let (($x4788 (= v_1_retry_count 0)))
 (let (($x139 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x624 (= 0 state_1)))
 (let (($x973 (not active_0_cache)))
 (let (($x2261 (or $x973 (not (<= due_0_cache 0)))))
 (let (($x1758 (not active_0_query)))
 (let (($x5201 (or $x1758 (not (<= due_0_query 0)))))
 (let (($x779 (= state_0 0)))
 (and $x779 (>= 0 now_0) $x5201 $x2261 $x624 $x139 $x4788 $x4779 v_1_checksums_enabled $x4739 $x52 $x2589 $x1789 $x2962 $x996 $x2325 $x4780 $x4704 $x4705 $x4630 $x2485 $x4631 $x568 $x156 (= v_1_rxudp_disposition "none") $x780 $x449 $x566 $x246 (= v_1_echo_disposition "none") $x2328 $x2064 $x254 $x1464))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x4878 (seq.unit (_ bv0 8))))
(let ((?x2741 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 ?x4878)))))))
(let ((?x6150 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 ?x2741)))))))
(let ((?x3474 (seq.++ ?x4878 (seq.++ ?x4878 (seq.++ ?x4878 ?x6150)))))
(= input_0_net.frame_frame ?x3474))))))
(check-sat)

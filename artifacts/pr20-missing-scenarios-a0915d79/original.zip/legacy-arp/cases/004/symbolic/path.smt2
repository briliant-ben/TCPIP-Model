; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1997 (= due_1_cache due_0_cache)))
 (let (($x809 (= due_1_query due_0_query)))
 (let (($x1996 (= active_1_cache active_0_cache)))
 (let (($x808 (= active_1_query active_0_query)))
 (let (($x4998 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4997 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x4996 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4995 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4994 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x4993 (not v_1_rxudp_require_checksum)))
 (let (($x4992 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x198 (= v_1_ip_checksum 0)))
 (let (($x69 (= v_1_udp_checksum 0)))
 (let (($x100 (= v_1_udp_raw_checksum 0)))
 (let (($x101 (= v_1_ip_length 0)))
 (let (($x3390 (= v_1_udp_length 0)))
 (let (($x4991 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4990 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4989 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4988 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4987 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x4986 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4985 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3412 (= v_1_cache_ttl_ms 60000)))
 (let (($x3414 (= v_1_retry_count 0)))
 (let (($x4984 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x827 (= 0 state_1)))
 (let (($x1005 (not active_0_cache)))
 (let (($x4983 (or $x1005 (not (<= due_0_cache 0)))))
 (let (($x16 (not active_0_query)))
 (let (($x4980 (or $x16 (not (<= due_0_query 0)))))
 (let (($x1937 (= state_0 0)))
 (and $x1937 (>= 0 now_0) $x4980 $x4983 $x827 $x4984 $x3414 $x3412 v_1_checksums_enabled $x4985 $x4986 $x4987 $x4988 $x4989 $x4990 $x4991 $x3390 $x101 $x100 $x69 $x198 $x4992 $x4993 $x4994 (= v_1_rxudp_disposition "none") $x4995 $x4996 $x4997 $x4998 (= v_1_echo_disposition "none") $x808 $x1996 $x809 $x1997))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5201 (seq.unit (_ bv192 8))))
(let ((?x582 (seq.++ ?x5201 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
(let ((?x217 (seq.unit (_ bv0 8))))
(let ((?x588 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x217 ?x582)))))))
(let ((?x2540 (seq.unit (_ bv2 8))))
(let ((?x619 (seq.++ ?x5201 (seq.++ ?x217 (seq.++ ?x2540 (seq.++ ?x2540 (seq.++ ?x217 ?x588)))))))
(let ((?x4847 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x2540 ?x619)))))))
(let ((?x3362 (seq.unit (_ bv1 8))))
(let ((?x3371 (seq.unit (_ bv4 8))))
(let ((?x6126 (seq.unit (_ bv6 8))))
(let ((?x4852 (seq.++ ?x6126 (seq.++ ?x3371 (seq.++ ?x217 (seq.++ ?x3362 (seq.++ ?x2540 ?x4847)))))))
(let ((?x1410 (seq.unit (_ bv8 8))))
(let ((?x4857 (seq.++ ?x6126 (seq.++ ?x217 (seq.++ ?x3362 (seq.++ ?x1410 (seq.++ ?x217 ?x4852)))))))
(let ((?x4863 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x217 (seq.++ ?x2540 (seq.++ ?x1410 ?x4857)))))))
(let ((?x1668 (seq.unit (_ bv255 8))))
(let ((?x4898 (seq.++ ?x1668 (seq.++ ?x1668 (seq.++ ?x1668 (seq.++ ?x2540 (seq.++ ?x217 ?x4863)))))))
(let ((?x4900 (seq.++ ?x1668 (seq.++ ?x1668 (seq.++ ?x1668 ?x4898)))))
(= input_0_net.frame_frame ?x4900)))))))))))))))))))
(check-sat)

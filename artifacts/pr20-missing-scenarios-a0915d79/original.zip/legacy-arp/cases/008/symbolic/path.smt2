; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4510 (= due_1_cache 60000)))
 (let (($x5287 (= due_1_query due_0_query)))
 (let (($x1745 (not active_1_query)))
 (let (($x4558 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x391 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x4409 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4399 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1838 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2679 (not v_1_rxudp_require_checksum)))
 (let (($x4411 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1446 (= v_1_ip_checksum 0)))
 (let (($x3776 (= v_1_udp_checksum 0)))
 (let (($x3777 (= v_1_udp_raw_checksum 0)))
 (let (($x3774 (= v_1_ip_length 0)))
 (let (($x3775 (= v_1_udp_length 0)))
 (let (($x1777 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x144 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1743 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x207 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4679 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1782 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x452 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1370 (= v_1_cache_ttl_ms 60000)))
 (let (($x2753 (= 0 v_1_retry_count)))
 (let ((?x4739 (seq.unit (_ bv0 8))))
 (let ((?x4754 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.unit (_ bv2 8))))))))
 (let ((?x506 (seq.unit (_ bv2 8))))
 (let (($x376 (= v_1_peer_mac (seq.++ ?x506 ?x4754))))
 (let (($x5215 (= 2 state_1)))
 (let (($x4622 (not active_0_cache)))
 (let (($x2199 (or $x4622 (not (<= due_0_cache 0)))))
 (let (($x4523 (not active_0_query)))
 (let (($x4542 (or $x4523 (not (<= due_0_query 0)))))
 (let (($x3248 (= state_0 0)))
 (and $x3248 (>= 0 now_0) $x4542 $x2199 $x5215 $x376 $x2753 $x1370 v_1_checksums_enabled $x452 $x1782 $x4679 $x207 $x1743 $x144 $x1777 $x3775 $x3774 $x3777 $x3776 $x1446 $x4411 $x2679 $x1838 (= v_1_rxudp_disposition "none") $x4399 $x4409 $x391 $x4558 (= v_1_echo_disposition "none") $x1745 active_1_cache $x5287 $x4510))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2701 (= due_2_query due_1_query)))
 (let (($x1460 (not active_2_query)))
 (let (($x927 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x982 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x981 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x5071 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x5070 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x5015 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x5067 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x1005 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x2691 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x2690 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2727 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2726 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2697 (= v_2_ip_length v_1_ip_length)))
 (let (($x2696 (= v_2_udp_length v_1_udp_length)))
 (let (($x976 (= v_2_packet v_1_packet)))
 (let (($x975 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x973 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x972 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x971 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x970 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x969 (= v_2_payload v_1_payload)))
 (let (($x968 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x967 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x966 (= 0 v_2_retry_count)))
 (let ((?x4739 (seq.unit (_ bv0 8))))
 (let ((?x1685 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.unit (_ bv3 8))))))))
 (let ((?x506 (seq.unit (_ bv2 8))))
 (let (($x1459 (= v_2_peer_mac (seq.++ ?x506 ?x1685))))
 (let (($x961 (= 2 state_2)))
 (let (($x1453 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x1745 (not active_1_query)))
 (let (($x1362 (or $x1745 (not (<= due_1_query 5)))))
 (let (($x445 (= state_1 2)))
 (and $x445 $x1362 $x1453 $x961 $x1459 $x966 $x967 $x968 $x969 $x970 $x971 $x972 $x973 $x975 $x976 $x2696 $x2697 $x2726 $x2727 $x2690 $x2691 $x1005 $x5067 $x5015 $x5070 $x5071 $x981 $x982 $x927 $x1460 active_2_cache $x2701 (= due_2_cache (+ 5 v_1_cache_ttl_ms)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x6149 (= due_3_cache due_2_cache)))
 (let (($x6147 (= due_3_query due_2_query)))
 (let (($x703 (= active_3_cache active_2_cache)))
 (let (($x6119 (= active_3_query active_2_query)))
 (let (($x2939 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x2563 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x791 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x790 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x789 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x788 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x787 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x786 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x785 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x784 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x783 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x782 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x781 (= v_3_ip_length v_2_ip_length)))
 (let (($x780 (= v_3_udp_length v_2_udp_length)))
 (let (($x779 (= v_3_packet v_2_packet)))
 (let (($x778 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x777 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x776 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x775 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x774 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x773 (= v_3_payload v_2_payload)))
 (let (($x772 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x771 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x770 (= v_3_retry_count v_2_retry_count)))
 (let (($x769 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x768 (= 2 state_3)))
 (let (($x852 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x1460 (not active_2_query)))
 (let (($x1442 (or $x1460 (not (<= due_2_query 10)))))
 (let (($x1454 (= state_2 2)))
 (and $x1454 $x1442 $x852 $x768 $x769 $x770 $x771 $x772 $x773 $x774 $x775 $x776 $x777 $x778 $x779 $x780 $x781 $x782 $x783 $x784 $x785 $x786 $x787 $x788 $x789 $x790 $x791 $x2563 $x2939 $x6119 $x703 $x6147 $x6149))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x4394 (seq.unit (_ bv192 8))))
 (let ((?x473 (seq.++ ?x4394 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x4430 (seq.unit (_ bv1 8))))
 (let ((?x4739 (seq.unit (_ bv0 8))))
 (let ((?x1773 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4430 ?x473)))))))
 (let ((?x506 (seq.unit (_ bv2 8))))
 (let ((?x792 (seq.++ ?x4394 (seq.++ ?x4739 (seq.++ ?x506 (seq.++ ?x506 (seq.++ ?x506 ?x1773)))))))
 (let ((?x101 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x506 ?x792)))))))
 (let ((?x52 (seq.unit (_ bv4 8))))
 (let ((?x146 (seq.unit (_ bv6 8))))
 (let ((?x4941 (seq.++ ?x146 (seq.++ ?x52 (seq.++ ?x4739 (seq.++ ?x506 (seq.++ ?x506 ?x101)))))))
 (let ((?x5187 (seq.unit (_ bv8 8))))
 (let ((?x1798 (seq.++ ?x146 (seq.++ ?x4739 (seq.++ ?x4430 (seq.++ ?x5187 (seq.++ ?x4739 ?x4941)))))))
 (let ((?x580 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x506 (seq.++ ?x5187 ?x1798)))))))
 (let ((?x511 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4430 (seq.++ ?x506 (seq.++ ?x4739 ?x580)))))))
 (let ((?x3390 (seq.++ ?x506 (seq.++ ?x4739 (seq.++ ?x4739 ?x511)))))
 (= input_0_net.frame_frame ?x3390))))))))))))))))))
(assert
 (= 16 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x4394 (seq.unit (_ bv192 8))))
 (let ((?x473 (seq.++ ?x4394 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x4430 (seq.unit (_ bv1 8))))
 (let ((?x4739 (seq.unit (_ bv0 8))))
 (let ((?x1773 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4430 ?x473)))))))
 (let ((?x506 (seq.unit (_ bv2 8))))
 (let ((?x792 (seq.++ ?x4394 (seq.++ ?x4739 (seq.++ ?x506 (seq.++ ?x506 (seq.++ ?x506 ?x1773)))))))
 (let ((?x107 (seq.unit (_ bv3 8))))
 (let ((?x1767 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x107 ?x792)))))))
 (let ((?x52 (seq.unit (_ bv4 8))))
 (let ((?x146 (seq.unit (_ bv6 8))))
 (let ((?x156 (seq.++ ?x146 (seq.++ ?x52 (seq.++ ?x4739 (seq.++ ?x506 (seq.++ ?x506 ?x1767)))))))
 (let ((?x5187 (seq.unit (_ bv8 8))))
 (let ((?x3253 (seq.++ ?x146 (seq.++ ?x4739 (seq.++ ?x4430 (seq.++ ?x5187 (seq.++ ?x4739 ?x156)))))))
 (let ((?x3262 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x107 (seq.++ ?x5187 ?x3253)))))))
 (let ((?x1760 (seq.++ ?x4739 (seq.++ ?x4739 (seq.++ ?x4430 (seq.++ ?x506 (seq.++ ?x4739 ?x3262)))))))
 (let ((?x1959 (seq.++ ?x506 (seq.++ ?x4739 (seq.++ ?x4739 ?x1760)))))
 (= input_1_net.frame_frame ?x1959)))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x4394 (seq.unit (_ bv192 8))))
(let ((?x507 (seq.++ ?x4394 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x507))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1960 (= due_1_cache 60000)))
 (let (($x6145 (= due_1_query due_0_query)))
 (let (($x1959 (not active_1_query)))
 (let (($x1958 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x1957 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x1956 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x1955 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1954 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1838 (not v_1_rxudp_require_checksum)))
 (let (($x1953 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x399 (= v_1_ip_checksum 0)))
 (let (($x405 (= v_1_udp_checksum 0)))
 (let (($x406 (= v_1_udp_raw_checksum 0)))
 (let (($x407 (= v_1_ip_length 0)))
 (let (($x408 (= v_1_udp_length 0)))
 (let (($x1952 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1951 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1950 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1949 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1948 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1947 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1946 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x425 (= v_1_cache_ttl_ms 60000)))
 (let (($x6132 (= 0 v_1_retry_count)))
 (let ((?x141 (seq.unit (_ bv0 8))))
 (let ((?x832 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.unit (_ bv2 8))))))))
 (let ((?x4752 (seq.unit (_ bv2 8))))
 (let (($x1945 (= v_1_peer_mac (seq.++ ?x4752 ?x832))))
 (let (($x6131 (= 2 state_1)))
 (let (($x149 (not active_0_cache)))
 (let (($x1944 (or $x149 (not (<= due_0_cache 0)))))
 (let (($x651 (not active_0_query)))
 (let (($x1905 (or $x651 (not (<= due_0_query 0)))))
 (let (($x2951 (= state_0 0)))
 (and $x2951 (>= 0 now_0) $x1905 $x1944 $x6131 $x1945 $x6132 $x425 v_1_checksums_enabled $x1946 $x1947 $x1948 $x1949 $x1950 $x1951 $x1952 $x408 $x407 $x406 $x405 $x399 $x1953 $x1838 $x1954 (= v_1_rxudp_disposition "none") $x1955 $x1956 $x1957 $x1958 (= v_1_echo_disposition "none") $x1959 active_1_cache $x6145 $x1960))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x365 (seq.unit (_ bv192 8))))
(let ((?x2558 (seq.++ ?x365 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x141 (seq.unit (_ bv0 8))))
(let ((?x797 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 ?x2558)))))))
(let ((?x4752 (seq.unit (_ bv2 8))))
(let ((?x802 (seq.++ ?x365 (seq.++ ?x141 (seq.++ ?x4752 (seq.++ ?x4752 (seq.++ ?x141 ?x797)))))))
(let ((?x807 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x4752 ?x802)))))))
(let ((?x1005 (seq.unit (_ bv1 8))))
(let ((?x24 (seq.unit (_ bv4 8))))
(let ((?x3304 (seq.unit (_ bv6 8))))
(let ((?x812 (seq.++ ?x3304 (seq.++ ?x24 (seq.++ ?x141 (seq.++ ?x1005 (seq.++ ?x4752 ?x807)))))))
(let ((?x2540 (seq.unit (_ bv8 8))))
(let ((?x817 (seq.++ ?x3304 (seq.++ ?x141 (seq.++ ?x1005 (seq.++ ?x2540 (seq.++ ?x141 ?x812)))))))
(let ((?x822 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x141 (seq.++ ?x4752 (seq.++ ?x2540 ?x817)))))))
(let ((?x6152 (seq.unit (_ bv255 8))))
(let ((?x827 (seq.++ ?x6152 (seq.++ ?x6152 (seq.++ ?x6152 (seq.++ ?x4752 (seq.++ ?x141 ?x822)))))))
(let ((?x830 (seq.++ ?x6152 (seq.++ ?x6152 (seq.++ ?x6152 ?x827)))))
(= input_0_net.frame_frame ?x830)))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x5015 (= due_1_cache due_0_cache)))
 (let (($x1080 (= due_1_query 1000)))
 (let (($x5067 (= active_1_cache active_0_cache)))
 (let (($x1078 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x1082 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x1081 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x1083 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1073 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3315 (not v_1_rxudp_require_checksum)))
 (let (($x1070 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1086 (= v_1_ip_checksum 0)))
 (let (($x3865 (= v_1_udp_checksum 0)))
 (let (($x3868 (= v_1_udp_raw_checksum 0)))
 (let (($x3869 (= v_1_ip_length 0)))
 (let (($x3870 (= v_1_udp_length 0)))
 (let (($x1019 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1018 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x5112 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1053 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1050 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x6123 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2703 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1033 (= v_1_cache_ttl_ms 60000)))
 (let (($x6158 (= 0 v_1_retry_count)))
 (let (($x148 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1928 (= 1 state_1)))
 (let (($x775 (not active_0_cache)))
 (let (($x430 (or $x775 (not (<= due_0_cache 0)))))
 (let (($x3150 (not active_0_query)))
 (let (($x4856 (or $x3150 (not (<= due_0_query 0)))))
 (let (($x3369 (= state_0 0)))
 (and $x3369 (>= 0 now_0) $x4856 $x430 $x1928 $x148 $x6158 $x1033 v_1_checksums_enabled $x2703 $x6123 $x1050 $x1053 $x5112 $x1018 $x1019 $x3870 $x3869 $x3868 $x3865 $x1086 $x1070 $x3315 $x1073 (= v_1_rxudp_disposition "none") $x1083 $x1081 $x1082 $x1078 (= v_1_echo_disposition "none") active_1_query $x5067 $x1080 $x5015)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x4879 (= due_2_query due_1_query)))
 (let (($x1758 (not active_2_query)))
 (let (($x2153 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2152 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2508 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x1864 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x2233 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x2232 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x835 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x834 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x3330 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x3329 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2038 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2037 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2235 (= v_2_ip_length v_1_ip_length)))
 (let (($x2234 (= v_2_udp_length v_1_udp_length)))
 (let (($x2239 (= v_2_packet v_1_packet)))
 (let (($x2238 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x5237 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x5236 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2231 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2230 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2509 (= v_2_payload v_1_payload)))
 (let (($x2510 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1868 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x395 (= 0 v_2_retry_count)))
 (let ((?x5283 (seq.unit (_ bv0 8))))
 (let ((?x1064 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.unit (_ bv2 8))))))))
 (let ((?x246 (seq.unit (_ bv2 8))))
 (let (($x1754 (= v_2_peer_mac (seq.++ ?x246 ?x1064))))
 (let (($x2007 (= 2 state_2)))
 (let (($x825 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x5158 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let ((?x428 (seq.len v_1_pending_packet)))
 (let (($x2001 (= 0 ?x428)))
 (let (($x5110 (= state_1 1)))
 (and $x5110 $x2001 $x5158 $x825 $x2007 $x1754 $x395 $x1868 $x2510 $x2509 $x2230 $x2231 $x5236 $x5237 $x2238 $x2239 $x2234 $x2235 $x2037 $x2038 $x3329 $x3330 $x834 $x835 $x2232 $x2233 $x1864 $x2508 $x2152 $x2153 $x1758 active_2_cache $x4879 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x495 (= due_3_cache due_2_cache)))
 (let (($x826 (= due_3_query due_2_query)))
 (let (($x2951 (= active_3_cache active_2_cache)))
 (let (($x2524 (= active_3_query active_2_query)))
 (let (($x577 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x576 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x1833 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x1832 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x575 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x573 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x574 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x572 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x593 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x591 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x616 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x571 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x570 (= v_3_ip_length v_2_ip_length)))
 (let (($x569 (= v_3_udp_length v_2_udp_length)))
 (let (($x568 (= v_3_packet v_2_packet)))
 (let (($x567 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x566 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x565 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x564 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x563 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x562 (= v_3_payload v_2_payload)))
 (let (($x560 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x559 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x558 (= v_3_retry_count v_2_retry_count)))
 (let (($x557 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x556 (= 2 state_3)))
 (let (($x1040 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x1758 (not active_2_query)))
 (let (($x3864 (or $x1758 (not (<= due_2_query 20)))))
 (let (($x1095 (= state_2 2)))
 (and $x1095 $x3864 $x1040 $x556 $x557 $x558 $x559 $x560 $x562 $x563 $x564 $x565 $x566 $x567 $x568 $x569 $x570 $x571 $x616 $x591 $x593 $x572 $x574 $x573 $x575 $x1832 $x1833 $x576 $x577 $x2524 $x2951 $x826 $x495))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2762 (seq.unit (_ bv192 8))))
 (let ((?x2765 (seq.++ ?x2762 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x2765))))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x2762 (seq.unit (_ bv192 8))))
 (let ((?x1954 (seq.++ ?x2762 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x5207 (seq.unit (_ bv1 8))))
 (let ((?x5283 (seq.unit (_ bv0 8))))
 (let ((?x675 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5207 ?x1954)))))))
 (let ((?x246 (seq.unit (_ bv2 8))))
 (let ((?x5214 (seq.++ ?x2762 (seq.++ ?x5283 (seq.++ ?x246 (seq.++ ?x246 (seq.++ ?x246 ?x675)))))))
 (let ((?x4987 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x246 ?x5214)))))))
 (let ((?x1407 (seq.unit (_ bv4 8))))
 (let ((?x3467 (seq.unit (_ bv6 8))))
 (let ((?x1377 (seq.++ ?x3467 (seq.++ ?x1407 (seq.++ ?x5283 (seq.++ ?x246 (seq.++ ?x246 ?x4987)))))))
 (let ((?x789 (seq.unit (_ bv8 8))))
 (let ((?x3355 (seq.++ ?x3467 (seq.++ ?x5283 (seq.++ ?x5207 (seq.++ ?x789 (seq.++ ?x5283 ?x1377)))))))
 (let ((?x4849 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x246 (seq.++ ?x789 ?x3355)))))))
 (let ((?x3790 (seq.++ ?x5283 (seq.++ ?x5283 (seq.++ ?x5207 (seq.++ ?x246 (seq.++ ?x5283 ?x4849)))))))
 (let ((?x1463 (seq.++ ?x246 (seq.++ ?x5283 (seq.++ ?x5283 ?x3790)))))
 (= input_1_net.frame_frame ?x1463))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x2762 (seq.unit (_ bv192 8))))
(let ((?x2765 (seq.++ ?x2762 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x2765))))
(check-sat)

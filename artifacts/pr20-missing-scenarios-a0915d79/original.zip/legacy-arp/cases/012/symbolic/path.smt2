; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x675 (= due_1_cache due_0_cache)))
 (let (($x5223 (= due_1_query 1000)))
 (let (($x5217 (= active_1_cache active_0_cache)))
 (let (($x2162 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2288 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3343 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3342 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x816 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x490 (not v_1_rxudp_require_checksum)))
 (let (($x410 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2034 (= v_1_ip_checksum 0)))
 (let (($x4885 (= v_1_udp_checksum 0)))
 (let (($x6142 (= v_1_udp_raw_checksum 0)))
 (let (($x4887 (= v_1_ip_length 0)))
 (let (($x6144 (= v_1_udp_length 0)))
 (let (($x2765 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2051 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1970 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1785 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3250 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2029 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3469 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x369 (= v_1_cache_ttl_ms 60000)))
 (let (($x1054 (= 0 v_1_retry_count)))
 (let (($x1784 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4632 (= 1 state_1)))
 (let (($x2931 (not active_0_cache)))
 (let (($x3246 (or $x2931 (not (<= due_0_cache 0)))))
 (let (($x4985 (not active_0_query)))
 (let (($x6145 (or $x4985 (not (<= due_0_query 0)))))
 (let (($x5207 (= state_0 0)))
 (and $x5207 (>= 0 now_0) $x6145 $x3246 $x4632 $x1784 $x1054 $x369 v_1_checksums_enabled $x3469 $x2029 $x3250 $x1785 $x1970 $x2051 $x2765 $x6144 $x4887 $x6142 $x4885 $x2034 $x410 $x490 $x816 (= v_1_rxudp_disposition "none") $x3342 $x3343 $x2288 $x2162 (= v_1_echo_disposition "none") active_1_query $x5217 $x5223 $x675)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x136 (= due_2_query due_1_query)))
 (let (($x4388 (not active_2_query)))
 (let (($x655 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x4452 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x1024 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x772 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x971 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x1926 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x5241 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x646 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x2727 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x939 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x217 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x3189 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x4415 (= v_2_ip_length v_1_ip_length)))
 (let (($x155 (= v_2_udp_length v_1_udp_length)))
 (let (($x1925 (= v_2_packet v_1_packet)))
 (let (($x769 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1836 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x4495 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x4591 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x4449 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x5176 (= v_2_payload v_1_payload)))
 (let (($x479 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x5230 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1430 (= 0 v_2_retry_count)))
 (let ((?x567 (seq.unit (_ bv0 8))))
 (let ((?x343 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.unit (_ bv3 8))))))))
 (let ((?x2963 (seq.unit (_ bv2 8))))
 (let (($x149 (= v_2_peer_mac (seq.++ ?x2963 ?x343))))
 (let (($x482 (= 2 state_2)))
 (let (($x4390 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x3409 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let ((?x671 (seq.len v_1_pending_packet)))
 (let (($x3437 (= 0 ?x671)))
 (let (($x4757 (= state_1 1)))
 (and $x4757 $x3437 $x3409 $x4390 $x482 $x149 $x1430 $x5230 $x479 $x5176 $x4449 $x4591 $x4495 $x1836 $x769 $x1925 $x155 $x4415 $x3189 $x217 $x939 $x2727 $x646 $x5241 $x1926 $x971 $x772 $x1024 $x4452 $x655 $x4388 active_2_cache $x136 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x400 (seq.unit (_ bv192 8))))
 (let ((?x3190 (seq.++ ?x400 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x3190))))
(assert
 (= 27 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x400 (seq.unit (_ bv192 8))))
(let ((?x6120 (seq.++ ?x400 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x567 (seq.unit (_ bv0 8))))
(let ((?x1877 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 ?x6120)))))))
(let ((?x2963 (seq.unit (_ bv2 8))))
(let ((?x2035 (seq.++ ?x400 (seq.++ ?x567 (seq.++ ?x2963 (seq.++ ?x2963 (seq.++ ?x567 ?x1877)))))))
(let ((?x3761 (seq.unit (_ bv3 8))))
(let ((?x505 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x3761 ?x2035)))))))
(let ((?x1874 (seq.unit (_ bv1 8))))
(let ((?x360 (seq.unit (_ bv4 8))))
(let ((?x1042 (seq.unit (_ bv6 8))))
(let ((?x525 (seq.++ ?x1042 (seq.++ ?x360 (seq.++ ?x567 (seq.++ ?x1874 (seq.++ ?x2963 ?x505)))))))
(let ((?x4520 (seq.unit (_ bv8 8))))
(let ((?x1000 (seq.++ ?x1042 (seq.++ ?x567 (seq.++ ?x1874 (seq.++ ?x4520 (seq.++ ?x567 ?x525)))))))
(let ((?x450 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x567 (seq.++ ?x3761 (seq.++ ?x4520 ?x1000)))))))
(let ((?x4504 (seq.unit (_ bv255 8))))
(let ((?x4494 (seq.++ ?x4504 (seq.++ ?x4504 (seq.++ ?x4504 (seq.++ ?x2963 (seq.++ ?x567 ?x450)))))))
(let ((?x4694 (seq.++ ?x4504 (seq.++ ?x4504 (seq.++ ?x4504 ?x4494)))))
(= input_1_net.frame_frame ?x4694))))))))))))))))))))
(check-sat)

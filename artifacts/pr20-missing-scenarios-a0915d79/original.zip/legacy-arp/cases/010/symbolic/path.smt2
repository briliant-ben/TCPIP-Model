; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_echo_disposition () String)
(declare-fun v_4_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_4_rxudp_disposition () String)
(declare-fun v_4_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_rxudp_require_checksum () Bool)
(declare-fun v_4_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_checksum () Int)
(declare-fun v_4_udp_checksum () Int)
(declare-fun v_4_udp_raw_checksum () Int)
(declare-fun v_4_ip_length () Int)
(declare-fun v_4_udp_length () Int)
(declare-fun v_4_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_checksums_enabled () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3153 (= due_1_cache due_0_cache)))
 (let (($x4957 (= due_1_query 1000)))
 (let (($x5015 (= active_1_cache active_0_cache)))
 (let (($x2632 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4956 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x5271 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x3496 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1287 (not v_1_rxudp_require_checksum)))
 (let (($x2139 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x3967 (= v_1_ip_checksum 0)))
 (let (($x4866 (= v_1_udp_checksum 0)))
 (let (($x3957 (= v_1_udp_raw_checksum 0)))
 (let (($x3958 (= v_1_ip_length 0)))
 (let (($x3956 (= v_1_udp_length 0)))
 (let (($x3500 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x3501 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3157 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x2190 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x573 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3884 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3194 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3151 (= v_1_cache_ttl_ms 60000)))
 (let (($x6158 (= 0 v_1_retry_count)))
 (let (($x647 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x148 (= 1 state_1)))
 (let (($x4559 (not active_0_cache)))
 (let (($x3883 (or $x4559 (not (<= due_0_cache 0)))))
 (let (($x495 (not active_0_query)))
 (let (($x39 (or $x495 (not (<= due_0_query 0)))))
 (let (($x557 (= state_0 0)))
 (and $x557 (>= 0 now_0) $x39 $x3883 $x148 $x647 $x6158 $x3151 v_1_checksums_enabled $x3194 $x3884 $x573 $x2190 $x3157 $x3501 $x3500 $x3956 $x3958 $x3957 $x4866 $x3967 $x2139 $x1287 $x3496 (= v_1_rxudp_disposition "none") $x3499 $x5271 $x4956 $x2632 (= v_1_echo_disposition "none") active_1_query $x5015 $x4957 $x3153)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2729 (= due_2_cache due_1_cache)))
 (let (($x2728 (= due_2_query due_1_query)))
 (let (($x5140 (= active_2_cache active_1_cache)))
 (let (($x5036 (= active_2_query active_1_query)))
 (let (($x3462 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x5032 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x5068 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x133 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x4980 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x3737 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x16 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x4979 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x900 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x899 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2713 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2712 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x5085 (= v_2_ip_length v_1_ip_length)))
 (let (($x5084 (= v_2_udp_length v_1_udp_length)))
 (let (($x2941 (= v_2_packet v_1_packet)))
 (let (($x158 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x3419 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2055 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x46 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x4771 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x151 (= v_2_payload v_1_payload)))
 (let (($x154 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2707 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2706 (= v_2_retry_count v_1_retry_count)))
 (let (($x902 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x901 (= 1 state_2)))
 (let (($x3510 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x2768 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x3156 (= state_1 1)))
 (and $x3156 $x2768 $x3510 $x901 $x902 $x2706 $x2707 $x154 $x151 $x4771 $x46 $x2055 $x3419 $x158 $x2941 $x5084 $x5085 $x2712 $x2713 $x899 $x900 $x4979 $x16 $x3737 $x4980 $x133 $x5068 $x5032 $x3462 $x5036 $x5140 $x2728 $x2729)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x276 (= due_3_cache due_2_cache)))
 (let (($x4960 (= due_3_query 2000)))
 (let (($x273 (= active_3_cache active_2_cache)))
 (let (($x270 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x269 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x268 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x1515 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x1514 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x267 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x266 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x265 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x264 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x263 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x262 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x245 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x255 (= v_3_ip_length v_2_ip_length)))
 (let (($x254 (= v_3_udp_length v_2_udp_length)))
 (let (($x2328 (= v_3_packet v_2_packet)))
 (let (($x2281 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x853 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x2333 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x2336 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x2291 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x2334 (= v_3_payload v_2_payload)))
 (let (($x862 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x213 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x2325 (= 1 v_3_retry_count)))
 (let (($x2324 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x2292 (= 1 state_3)))
 (let (($x2314 (= 0 v_2_retry_count)))
 (let (($x3515 (= state_2 1)))
 (and $x3515 $x2314 active_2_query (= 1000 due_2_query) (or (not active_2_cache) (not (<= due_2_cache due_2_query))) $x2292 $x2324 $x2325 $x213 $x862 $x2334 $x2291 $x2336 $x2333 $x853 $x2281 $x2328 $x254 $x255 $x245 $x262 $x263 $x264 $x265 $x266 $x267 $x1514 $x1515 $x268 $x269 $x270 active_3_query $x273 $x4960 $x276)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3175 (= due_4_cache due_3_cache)))
 (let (($x4865 (= due_4_query due_3_query)))
 (let (($x5177 (= active_4_cache active_3_cache)))
 (let (($x2339 (not active_4_query)))
 (let (($x4602 (= v_4_echo_disposition v_3_echo_disposition)))
 (let (($x4530 (= v_4_echo_ip_zero v_3_echo_ip_zero)))
 (let (($x360 (= v_4_echo_icmp_wire v_3_echo_icmp_wire)))
 (let (($x1665 (= v_4_echo_icmp_zero v_3_echo_icmp_zero)))
 (let (($x4759 (= v_4_echo_reply v_3_echo_reply)))
 (let (($x4878 (= v_4_rxudp_disposition v_3_rxudp_disposition)))
 (let (($x1874 (= v_4_rxudp_payload v_3_rxudp_payload)))
 (let (($x6135 (= v_4_rxudp_require_checksum v_3_rxudp_require_checksum)))
 (let (($x3333 (= v_4_pending_packet v_3_pending_packet)))
 (let (($x3334 (= v_4_ip_checksum v_3_ip_checksum)))
 (let (($x973 (= v_4_udp_checksum v_3_udp_checksum)))
 (let (($x2261 (= v_4_udp_raw_checksum v_3_udp_raw_checksum)))
 (let (($x975 (= v_4_ip_length v_3_ip_length)))
 (let (($x3190 (= v_4_udp_length v_3_udp_length)))
 (let (($x976 (= v_4_packet v_3_packet)))
 (let (($x3191 (= v_4_ip_wire v_3_ip_wire)))
 (let (($x2696 (= v_4_ip_zero v_3_ip_zero)))
 (let (($x5005 (= v_4_udp_wire v_3_udp_wire)))
 (let (($x2957 (= v_4_pseudoheader v_3_pseudoheader)))
 (let (($x1045 (= v_4_udp_zero v_3_udp_zero)))
 (let (($x1044 (= v_4_payload v_3_payload)))
 (let (($x2589 (= v_4_checksums_enabled v_3_checksums_enabled)))
 (let (($x4437 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x707 (= 0 v_4_retry_count)))
 (let (($x3154 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x909 (= 0 state_4)))
 (let ((?x2673 (seq.len v_3_pending_packet)))
 (let (($x2769 (= 0 ?x2673)))
 (let (($x2325 (= 1 v_3_retry_count)))
 (let (($x3968 (= state_3 1)))
 (and $x3968 $x2325 $x2769 active_3_query (= 2000 due_3_query) (or (not active_3_cache) (not (<= due_3_cache due_3_query))) $x909 $x3154 $x707 $x4437 $x2589 $x1044 $x1045 $x2957 $x5005 $x2696 $x3191 $x976 $x3190 $x975 $x2261 $x973 $x3334 $x3333 $x6135 $x1874 $x4878 $x4759 $x1665 $x360 $x4530 $x4602 $x2339 $x5177 $x4865 $x3175))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x4914 (seq.unit (_ bv192 8))))
 (let ((?x395 (seq.++ ?x4914 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x395))))
(assert
 (= 1 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x4914 (seq.unit (_ bv192 8))))
 (let ((?x395 (seq.++ ?x4914 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_1_app.resolve_ip ?x395))))
(assert
 (= 3 choice_2))
(assert
 (= 1000 now_3))
(assert
 (= 25 choice_3))
(assert
 (= 2000 now_4))
(check-sat)

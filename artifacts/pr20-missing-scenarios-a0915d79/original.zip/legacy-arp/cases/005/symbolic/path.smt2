; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x876 (= due_1_cache 60000)))
 (let (($x1684 (= due_1_query due_0_query)))
 (let (($x875 (not active_1_query)))
 (let (($x874 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x873 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x872 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3384 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x3383 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1908 (not v_1_rxudp_require_checksum)))
 (let (($x1907 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x860 (= v_1_ip_checksum 0)))
 (let (($x2298 (= v_1_udp_checksum 0)))
 (let (($x2304 (= v_1_udp_raw_checksum 0)))
 (let (($x121 (= v_1_ip_length 0)))
 (let (($x2301 (= v_1_udp_length 0)))
 (let (($x5123 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x5122 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x5121 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x5120 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x5119 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x5118 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x5117 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x2312 (= v_1_cache_ttl_ms 60000)))
 (let (($x3374 (= 0 v_1_retry_count)))
 (let ((?x4559 (seq.unit (_ bv0 8))))
 (let ((?x3448 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 (seq.unit (_ bv2 8))))))))
 (let ((?x4560 (seq.unit (_ bv2 8))))
 (let (($x5116 (= v_1_peer_mac (seq.++ ?x4560 ?x3448))))
 (let (($x4871 (= 2 state_1)))
 (let (($x4676 (not active_0_cache)))
 (let (($x5115 (or $x4676 (not (<= due_0_cache 0)))))
 (let (($x4675 (not active_0_query)))
 (let (($x5112 (or $x4675 (not (<= due_0_query 0)))))
 (let (($x4901 (= state_0 0)))
 (and $x4901 (>= 0 now_0) $x5112 $x5115 $x4871 $x5116 $x3374 $x2312 v_1_checksums_enabled $x5117 $x5118 $x5119 $x5120 $x5121 $x5122 $x5123 $x2301 $x121 $x2304 $x2298 $x860 $x1907 $x1908 $x3383 (= v_1_rxudp_disposition "none") $x3384 $x872 $x873 $x874 (= v_1_echo_disposition "none") $x875 active_1_cache $x1684 $x876))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x4948 (seq.unit (_ bv14 8))))
(let ((?x4954 (seq.++ ?x4948 (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
(let ((?x4946 (seq.unit (_ bv13 8))))
(let ((?x2259 (seq.unit (_ bv12 8))))
(let ((?x4942 (seq.unit (_ bv11 8))))
(let ((?x1935 (seq.unit (_ bv10 8))))
(let ((?x4939 (seq.unit (_ bv9 8))))
(let ((?x4959 (seq.++ ?x4939 (seq.++ ?x1935 (seq.++ ?x4942 (seq.++ ?x2259 (seq.++ ?x4946 ?x4954)))))))
(let ((?x405 (seq.unit (_ bv8 8))))
(let ((?x4944 (seq.unit (_ bv7 8))))
(let ((?x3398 (seq.unit (_ bv6 8))))
(let ((?x4914 (seq.unit (_ bv5 8))))
(let ((?x87 (seq.unit (_ bv4 8))))
(let ((?x4964 (seq.++ ?x87 (seq.++ ?x4914 (seq.++ ?x3398 (seq.++ ?x4944 (seq.++ ?x405 ?x4959)))))))
(let ((?x120 (seq.unit (_ bv3 8))))
(let ((?x4560 (seq.unit (_ bv2 8))))
(let ((?x93 (seq.unit (_ bv1 8))))
(let ((?x4559 (seq.unit (_ bv0 8))))
(let ((?x4969 (seq.++ ?x93 (seq.++ ?x4559 (seq.++ ?x93 (seq.++ ?x4560 (seq.++ ?x120 ?x4964)))))))
(let ((?x3390 (seq.unit (_ bv192 8))))
(let ((?x533 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x3390 (seq.++ ?x4559 (seq.++ ?x4560 ?x4969)))))))
(let ((?x1920 (seq.++ ?x4560 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 ?x533)))))))
(let ((?x56 (seq.++ ?x4559 (seq.++ ?x4560 (seq.++ ?x3390 (seq.++ ?x4559 (seq.++ ?x4560 ?x1920)))))))
(let ((?x4531 (seq.++ ?x93 (seq.++ ?x4560 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 ?x56)))))))
(let ((?x60 (seq.++ ?x405 (seq.++ ?x4559 (seq.++ ?x3398 (seq.++ ?x87 (seq.++ ?x4559 ?x4531)))))))
(let ((?x4913 (seq.++ ?x4560 (seq.++ ?x405 (seq.++ ?x3398 (seq.++ ?x4559 (seq.++ ?x93 ?x60)))))))
(let ((?x42 (seq.++ ?x4560 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 (seq.++ ?x4559 ?x4913)))))))
(let ((?x40 (seq.unit (_ bv255 8))))
(let ((?x1653 (seq.++ ?x40 (seq.++ ?x40 (seq.++ ?x40 (seq.++ ?x40 (seq.++ ?x40 ?x42)))))))
(let ((?x3457 (seq.++ ?x40 ?x1653)))
(= input_0_net.frame_frame ?x3457))))))))))))))))))))))))))))))))
(check-sat)

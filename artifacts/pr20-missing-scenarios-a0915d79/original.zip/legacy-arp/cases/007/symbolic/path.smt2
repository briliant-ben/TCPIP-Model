; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4508 (= due_1_cache 60000)))
 (let (($x3173 (= due_1_query due_0_query)))
 (let (($x2931 (not active_1_query)))
 (let (($x2930 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4537 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x5292 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x5291 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x3470 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2029 (not v_1_rxudp_require_checksum)))
 (let (($x3469 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1784 (= v_1_ip_checksum 0)))
 (let (($x3246 (= v_1_udp_checksum 0)))
 (let (($x3250 (= v_1_udp_raw_checksum 0)))
 (let (($x3251 (= v_1_ip_length 0)))
 (let (($x3252 (= v_1_udp_length 0)))
 (let (($x5288 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x5287 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4486 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4485 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3440 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3436 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3453 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x366 (= v_1_cache_ttl_ms 60000)))
 (let (($x3131 (= 0 v_1_retry_count)))
 (let ((?x4520 (seq.unit (_ bv0 8))))
 (let ((?x3247 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.unit (_ bv2 8))))))))
 (let ((?x2283 (seq.unit (_ bv2 8))))
 (let (($x515 (= v_1_peer_mac (seq.++ ?x2283 ?x3247))))
 (let (($x2731 (= 2 state_1)))
 (let (($x1401 (not active_0_cache)))
 (let (($x5240 (or $x1401 (not (<= due_0_cache 0)))))
 (let (($x4524 (not active_0_query)))
 (let (($x2613 (or $x4524 (not (<= due_0_query 0)))))
 (let (($x3141 (= state_0 0)))
 (and $x3141 (>= 0 now_0) $x2613 $x5240 $x2731 $x515 $x3131 $x366 v_1_checksums_enabled $x3453 $x3436 $x3440 $x4485 $x4486 $x5287 $x5288 $x3252 $x3251 $x3250 $x3246 $x1784 $x3469 $x2029 $x3470 (= v_1_rxudp_disposition "none") $x5291 $x5292 $x4537 $x2930 (= v_1_echo_disposition "none") $x2931 active_1_cache $x3173 $x4508))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2118 (= due_2_query due_1_query)))
 (let (($x1878 (= active_2_query active_1_query)))
 (let (($x1877 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2165 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2164 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x2161 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x2160 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x2040 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2039 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x1901 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x1900 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x2046 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2045 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x5202 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x455 (= v_2_ip_length v_1_ip_length)))
 (let (($x2243 (= v_2_udp_length v_1_udp_length)))
 (let (($x2242 (= v_2_packet v_1_packet)))
 (let (($x432 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x437 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1853 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1852 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1851 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1850 (= v_2_payload v_1_payload)))
 (let (($x1842 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x840 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2054 (= v_2_retry_count v_1_retry_count)))
 (let ((?x4520 (seq.unit (_ bv0 8))))
 (let ((?x400 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.unit (_ bv3 8))))))))
 (let ((?x2283 (seq.unit (_ bv2 8))))
 (let (($x79 (= v_2_peer_mac (seq.++ ?x2283 ?x400))))
 (let (($x2213 (= 2 state_2)))
 (let (($x444 (or (not active_1_cache) (not (<= due_1_cache 59999)))))
 (let (($x2931 (not active_1_query)))
 (let (($x1793 (or $x2931 (not (<= due_1_query 59999)))))
 (let (($x139 (= state_1 2)))
 (and $x139 $x1793 $x444 $x2213 $x79 $x2054 $x840 $x1842 $x1850 $x1851 $x1852 $x1853 $x437 $x432 $x2242 $x2243 $x455 $x5202 $x2045 $x2046 $x1900 $x1901 $x2039 $x2040 $x2160 $x2161 $x2164 $x2165 $x1877 $x1878 active_2_cache $x2118 (= due_2_cache (+ 59999 v_1_cache_ttl_ms)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x4792 (= due_3_cache due_2_cache)))
 (let (($x4791 (= due_3_query due_2_query)))
 (let (($x4790 (= active_3_cache active_2_cache)))
 (let (($x4789 (= active_3_query active_2_query)))
 (let (($x4788 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x4787 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x4786 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x4785 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x4784 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x4783 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x4782 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x4781 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x4780 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x4779 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x4778 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x4717 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x4777 (= v_3_ip_length v_2_ip_length)))
 (let (($x4776 (= v_3_udp_length v_2_udp_length)))
 (let (($x4775 (= v_3_packet v_2_packet)))
 (let (($x4774 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x4716 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x4742 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x4741 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x4739 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x4738 (= v_3_payload v_2_payload)))
 (let (($x4737 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x4736 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x4735 (= v_3_retry_count v_2_retry_count)))
 (let (($x4734 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x4733 (= 2 state_3)))
 (let (($x361 (or (not active_2_cache) (not (<= due_2_cache 60001)))))
 (let (($x401 (or (not active_2_query) (not (<= due_2_query 60001)))))
 (let (($x1792 (= state_2 2)))
 (and $x1792 $x401 $x361 $x4733 $x4734 $x4735 $x4736 $x4737 $x4738 $x4739 $x4741 $x4742 $x4716 $x4774 $x4775 $x4776 $x4777 $x4717 $x4778 $x4779 $x4780 $x4781 $x4782 $x4783 $x4784 $x4785 $x4786 $x4787 $x4788 $x4789 $x4790 $x4791 $x4792)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2186 (seq.unit (_ bv192 8))))
 (let ((?x2634 (seq.++ ?x2186 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x624 (seq.unit (_ bv1 8))))
 (let ((?x4520 (seq.unit (_ bv0 8))))
 (let ((?x4700 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x624 ?x2634)))))))
 (let ((?x2283 (seq.unit (_ bv2 8))))
 (let ((?x1928 (seq.++ ?x2186 (seq.++ ?x4520 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 ?x4700)))))))
 (let ((?x3190 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x2283 ?x1928)))))))
 (let ((?x4966 (seq.unit (_ bv4 8))))
 (let ((?x4964 (seq.unit (_ bv6 8))))
 (let ((?x939 (seq.++ ?x4964 (seq.++ ?x4966 (seq.++ ?x4520 (seq.++ ?x2283 (seq.++ ?x2283 ?x3190)))))))
 (let ((?x2743 (seq.unit (_ bv8 8))))
 (let ((?x2735 (seq.++ ?x4964 (seq.++ ?x4520 (seq.++ ?x624 (seq.++ ?x2743 (seq.++ ?x4520 ?x939)))))))
 (let ((?x5189 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x2283 (seq.++ ?x2743 ?x2735)))))))
 (let ((?x3062 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x624 (seq.++ ?x2283 (seq.++ ?x4520 ?x5189)))))))
 (let ((?x4541 (seq.++ ?x2283 (seq.++ ?x4520 (seq.++ ?x4520 ?x3062)))))
 (= input_0_net.frame_frame ?x4541))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 59999 now_2))
(assert
 (let ((?x2186 (seq.unit (_ bv192 8))))
 (let ((?x4595 (seq.++ ?x2186 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x4520 (seq.unit (_ bv0 8))))
 (let ((?x243 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 ?x4595)))))))
 (let ((?x2283 (seq.unit (_ bv2 8))))
 (let ((?x21 (seq.++ ?x2186 (seq.++ ?x4520 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x4520 ?x243)))))))
 (let ((?x996 (seq.unit (_ bv3 8))))
 (let ((?x3176 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x996 ?x21)))))))
 (let ((?x624 (seq.unit (_ bv1 8))))
 (let ((?x4966 (seq.unit (_ bv4 8))))
 (let ((?x4964 (seq.unit (_ bv6 8))))
 (let ((?x3165 (seq.++ ?x4964 (seq.++ ?x4966 (seq.++ ?x4520 (seq.++ ?x624 (seq.++ ?x2283 ?x3176)))))))
 (let ((?x2743 (seq.unit (_ bv8 8))))
 (let ((?x5279 (seq.++ ?x4964 (seq.++ ?x4520 (seq.++ ?x624 (seq.++ ?x2743 (seq.++ ?x4520 ?x3165)))))))
 (let ((?x3153 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x4520 (seq.++ ?x996 (seq.++ ?x2743 ?x5279)))))))
 (let ((?x3372 (seq.unit (_ bv255 8))))
 (let ((?x246 (seq.++ ?x3372 (seq.++ ?x3372 (seq.++ ?x3372 (seq.++ ?x2283 (seq.++ ?x4520 ?x3153)))))))
 (let ((?x663 (seq.++ ?x3372 (seq.++ ?x3372 (seq.++ ?x3372 ?x246)))))
 (= input_1_net.frame_frame ?x663))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 60001 now_3))
(assert
 (let ((?x2186 (seq.unit (_ bv192 8))))
(let ((?x1653 (seq.++ ?x2186 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x1653))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2564 (= due_1_cache 60000)))
 (let (($x18 (= due_1_query due_0_query)))
 (let (($x4428 (not active_1_query)))
 (let (($x4427 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x5170 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x5169 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2100 (not v_1_rxudp_require_checksum)))
 (let (($x2275 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x3458 (= v_1_ip_checksum 0)))
 (let (($x3048 (= v_1_udp_checksum 0)))
 (let (($x3052 (= v_1_udp_raw_checksum 0)))
 (let (($x3053 (= v_1_ip_length 0)))
 (let (($x3054 (= v_1_udp_length 0)))
 (let (($x32 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4758 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x114 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4422 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4421 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x4695 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4694 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x532 (= v_1_cache_ttl_ms 60000)))
 (let (($x211 (= 0 v_1_retry_count)))
 (let ((?x4405 (seq.unit (_ bv0 8))))
 (let ((?x540 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.unit (_ bv2 8))))))))
 (let ((?x4406 (seq.unit (_ bv2 8))))
 (let (($x4494 (= v_1_peer_mac (seq.++ ?x4406 ?x540))))
 (let (($x2280 (= 2 state_1)))
 (let (($x4398 (not active_0_cache)))
 (let (($x4493 (or $x4398 (not (<= due_0_cache 0)))))
 (let (($x4397 (not active_0_query)))
 (let (($x4386 (or $x4397 (not (<= due_0_query 0)))))
 (let (($x831 (= state_0 0)))
 (and $x831 (>= 0 now_0) $x4386 $x4493 $x2280 $x4494 $x211 $x532 v_1_checksums_enabled $x4694 $x4695 $x4421 $x4422 $x114 $x4758 $x32 $x3054 $x3053 $x3052 $x3048 $x3458 $x2275 $x2100 $x4628 (= v_1_rxudp_disposition "none") $x4629 $x5169 $x5170 $x4427 (= v_1_echo_disposition "none") $x4428 active_1_cache $x18 $x2564))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x153 (= due_2_query due_1_query)))
 (let (($x2511 (= active_2_query active_1_query)))
 (let (($x2036 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2035 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2207 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x2206 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x446 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x445 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x3347 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x3346 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x5219 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x5221 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1897 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1896 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1895 (= v_2_ip_length v_1_ip_length)))
 (let (($x1999 (= v_2_udp_length v_1_udp_length)))
 (let (($x1998 (= v_2_packet v_1_packet)))
 (let (($x1997 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1996 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1995 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2020 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2019 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x3332 (= v_2_payload v_1_payload)))
 (let (($x3331 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1866 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1899 (= v_2_retry_count v_1_retry_count)))
 (let ((?x4405 (seq.unit (_ bv0 8))))
 (let ((?x5218 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.unit (_ bv3 8))))))))
 (let ((?x4406 (seq.unit (_ bv2 8))))
 (let (($x504 (= v_2_peer_mac (seq.++ ?x4406 ?x5218))))
 (let (($x377 (= 2 state_2)))
 (let (($x503 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x4428 (not active_1_query)))
 (let (($x495 (or $x4428 (not (<= due_1_query 10)))))
 (let (($x535 (= state_1 2)))
 (and $x535 $x495 $x503 $x377 $x504 $x1899 $x1866 $x3331 $x3332 $x2019 $x2020 $x1995 $x1996 $x1997 $x1998 $x1999 $x1895 $x1896 $x1897 $x5221 $x5219 $x3346 $x3347 $x445 $x446 $x2206 $x2207 $x2035 $x2036 $x2511 active_2_cache $x153 (= due_2_cache (+ 10 v_1_cache_ttl_ms)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1692 (= due_3_cache due_2_cache)))
 (let (($x1691 (= due_3_query due_2_query)))
 (let (($x1690 (= active_3_cache active_2_cache)))
 (let (($x1689 (= active_3_query active_2_query)))
 (let (($x1688 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x1687 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x1686 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x1685 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x1684 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x1683 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x1682 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x1681 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x1680 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x1679 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1678 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x1677 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x1676 (= v_3_ip_length v_2_ip_length)))
 (let (($x1675 (= v_3_udp_length v_2_udp_length)))
 (let (($x1674 (= v_3_packet v_2_packet)))
 (let (($x1673 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x1411 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x1410 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1672 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1671 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x1670 (= v_3_payload v_2_payload)))
 (let (($x1669 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x1668 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x1667 (= v_3_retry_count v_2_retry_count)))
 (let (($x1666 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x1665 (= 2 state_3)))
 (let (($x3443 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x2055 (or (not active_2_query) (not (<= due_2_query 20)))))
 (let (($x3466 (= state_2 2)))
 (and $x3466 $x2055 $x3443 $x1665 $x1666 $x1667 $x1668 $x1669 $x1670 $x1671 $x1672 $x1410 $x1411 $x1673 $x1674 $x1675 $x1676 $x1677 $x1678 $x1679 $x1680 $x1681 $x1682 $x1683 $x1684 $x1685 $x1686 $x1687 $x1688 $x1689 $x1690 $x1691 $x1692)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x408 (seq.unit (_ bv192 8))))
 (let ((?x2335 (seq.++ ?x408 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x4405 (seq.unit (_ bv0 8))))
 (let ((?x4673 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 ?x2335)))))))
 (let ((?x4406 (seq.unit (_ bv2 8))))
 (let ((?x4678 (seq.++ ?x408 (seq.++ ?x4405 (seq.++ ?x4406 (seq.++ ?x4406 (seq.++ ?x4405 ?x4673)))))))
 (let ((?x4559 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4406 ?x4678)))))))
 (let ((?x389 (seq.unit (_ bv1 8))))
 (let ((?x414 (seq.unit (_ bv4 8))))
 (let ((?x412 (seq.unit (_ bv6 8))))
 (let ((?x4564 (seq.++ ?x412 (seq.++ ?x414 (seq.++ ?x4405 (seq.++ ?x389 (seq.++ ?x4406 ?x4559)))))))
 (let ((?x5229 (seq.unit (_ bv8 8))))
 (let ((?x4585 (seq.++ ?x412 (seq.++ ?x4405 (seq.++ ?x389 (seq.++ ?x5229 (seq.++ ?x4405 ?x4564)))))))
 (let ((?x4515 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4406 (seq.++ ?x5229 ?x4585)))))))
 (let ((?x388 (seq.unit (_ bv255 8))))
 (let ((?x61 (seq.++ ?x388 (seq.++ ?x388 (seq.++ ?x388 (seq.++ ?x4406 (seq.++ ?x4405 ?x4515)))))))
 (let ((?x1934 (seq.++ ?x388 (seq.++ ?x388 (seq.++ ?x388 ?x61)))))
 (= input_0_net.frame_frame ?x1934)))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x408 (seq.unit (_ bv192 8))))
 (let ((?x623 (seq.++ ?x408 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x4405 (seq.unit (_ bv0 8))))
 (let ((?x5165 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 ?x623)))))))
 (let ((?x4406 (seq.unit (_ bv2 8))))
 (let ((?x4627 (seq.++ ?x408 (seq.++ ?x4405 (seq.++ ?x4406 (seq.++ ?x4406 (seq.++ ?x4405 ?x5165)))))))
 (let ((?x627 (seq.unit (_ bv3 8))))
 (let ((?x4497 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x627 ?x4627)))))))
 (let ((?x389 (seq.unit (_ bv1 8))))
 (let ((?x414 (seq.unit (_ bv4 8))))
 (let ((?x412 (seq.unit (_ bv6 8))))
 (let ((?x4478 (seq.++ ?x412 (seq.++ ?x414 (seq.++ ?x4405 (seq.++ ?x389 (seq.++ ?x4406 ?x4497)))))))
 (let ((?x5229 (seq.unit (_ bv8 8))))
 (let ((?x2288 (seq.++ ?x412 (seq.++ ?x4405 (seq.++ ?x389 (seq.++ ?x5229 (seq.++ ?x4405 ?x4478)))))))
 (let ((?x138 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x4405 (seq.++ ?x627 (seq.++ ?x5229 ?x2288)))))))
 (let ((?x388 (seq.unit (_ bv255 8))))
 (let ((?x4519 (seq.++ ?x388 (seq.++ ?x388 (seq.++ ?x388 (seq.++ ?x4406 (seq.++ ?x4405 ?x138)))))))
 (let ((?x5154 (seq.++ ?x388 (seq.++ ?x388 (seq.++ ?x388 ?x4519)))))
 (= input_1_net.frame_frame ?x5154))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x408 (seq.unit (_ bv192 8))))
(let ((?x405 (seq.++ ?x408 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x405))))
(check-sat)

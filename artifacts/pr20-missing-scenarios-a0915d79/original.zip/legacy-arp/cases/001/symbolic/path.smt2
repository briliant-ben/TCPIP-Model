; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4475 (= due_1_cache 60000)))
 (let (($x35 (= due_1_query due_0_query)))
 (let (($x4474 (not active_1_query)))
 (let (($x4473 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4472 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x4471 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4470 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4469 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x5101 (not v_1_rxudp_require_checksum)))
 (let (($x4468 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x642 (= v_1_ip_checksum 0)))
 (let (($x643 (= v_1_udp_checksum 0)))
 (let (($x644 (= v_1_udp_raw_checksum 0)))
 (let (($x645 (= v_1_ip_length 0)))
 (let (($x650 (= v_1_udp_length 0)))
 (let (($x4467 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4466 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4465 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4464 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4463 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x4462 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4461 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x665 (= v_1_cache_ttl_ms 60000)))
 (let (($x58 (= 0 v_1_retry_count)))
 (let ((?x155 (seq.unit (_ bv0 8))))
 (let ((?x143 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.unit (_ bv2 8))))))))
 (let ((?x4768 (seq.unit (_ bv2 8))))
 (let (($x4460 (= v_1_peer_mac (seq.++ ?x4768 ?x143))))
 (let (($x57 (= 2 state_1)))
 (let (($x119 (not active_0_cache)))
 (let (($x4459 (or $x119 (not (<= due_0_cache 0)))))
 (let (($x4762 (not active_0_query)))
 (let (($x4456 (or $x4762 (not (<= due_0_query 0)))))
 (let (($x13 (= state_0 0)))
 (and $x13 (>= 0 now_0) $x4456 $x4459 $x57 $x4460 $x58 $x665 v_1_checksums_enabled $x4461 $x4462 $x4463 $x4464 $x4465 $x4466 $x4467 $x650 $x645 $x644 $x643 $x642 $x4468 $x5101 $x4469 (= v_1_rxudp_disposition "none") $x4470 $x4471 $x4472 $x4473 (= v_1_echo_disposition "none") $x4474 active_1_cache $x35 $x4475))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x4893 (= due_2_cache due_1_cache)))
 (let (($x4892 (= due_2_query due_1_query)))
 (let (($x1005 (not active_2_cache)))
 (let (($x4890 (= active_2_query active_1_query)))
 (let (($x4889 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x4888 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x4887 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x4886 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x4885 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x4884 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x4883 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x4882 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x4881 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x4880 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x4879 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x4878 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x4877 (= v_2_ip_length v_1_ip_length)))
 (let (($x4876 (= v_2_udp_length v_1_udp_length)))
 (let (($x4875 (= v_2_packet v_1_packet)))
 (let (($x4874 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x4873 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x4872 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x4871 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x4870 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x4869 (= v_2_payload v_1_payload)))
 (let (($x4868 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x4867 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x4866 (= 0 v_2_retry_count)))
 (let (($x1006 (= (as seq.empty (Seq (_ BitVec 8))) v_2_peer_mac)))
 (let (($x4864 (= 0 state_2)))
 (let (($x703 (= state_1 2)))
 (and $x703 active_1_cache (= 60000 due_1_cache) (or (not active_1_query) (<= due_1_cache due_1_query)) $x4864 $x1006 $x4866 $x4867 $x4868 $x4869 $x4870 $x4871 $x4872 $x4873 $x4874 $x4875 $x4876 $x4877 $x4878 $x4879 $x4880 $x4881 $x4882 $x4883 $x4884 $x4885 $x4886 $x4887 $x4888 $x4889 $x4890 $x1005 $x4892 $x4893)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x2563 (= due_3_cache due_2_cache)))
 (let (($x2938 (= due_3_query 61000)))
 (let (($x2561 (= active_3_cache active_2_cache)))
 (let (($x2559 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x2558 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x2557 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x2556 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x2555 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x2554 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x2553 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x2552 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x2551 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x2550 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x2549 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x2548 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x2547 (= v_3_ip_length v_2_ip_length)))
 (let (($x2546 (= v_3_udp_length v_2_udp_length)))
 (let (($x2545 (= v_3_packet v_2_packet)))
 (let (($x2544 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x2543 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x2542 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x2541 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x2540 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x2539 (= v_3_payload v_2_payload)))
 (let (($x2538 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2537 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x2536 (= 0 v_3_retry_count)))
 (let (($x2535 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x2534 (= 1 state_3)))
 (let (($x1005 (not active_2_cache)))
 (let (($x652 (or $x1005 (not (<= due_2_cache 60000)))))
 (let (($x109 (or (not active_2_query) (not (<= due_2_query 60000)))))
 (let (($x1004 (= state_2 0)))
 (and $x1004 $x109 $x652 $x2534 $x2535 $x2536 $x2537 $x2538 $x2539 $x2540 $x2541 $x2542 $x2543 $x2544 $x2545 $x2546 $x2547 $x2548 $x2549 $x2550 $x2551 $x2552 $x2553 $x2554 $x2555 $x2556 $x2557 $x2558 $x2559 active_3_query $x2561 $x2938 $x2563)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x4767 (seq.unit (_ bv192 8))))
 (let ((?x1925 (seq.++ ?x4767 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x77 (seq.unit (_ bv1 8))))
 (let ((?x155 (seq.unit (_ bv0 8))))
 (let ((?x4383 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x77 ?x1925)))))))
 (let ((?x4768 (seq.unit (_ bv2 8))))
 (let ((?x4388 (seq.++ ?x4767 (seq.++ ?x155 (seq.++ ?x4768 (seq.++ ?x4768 (seq.++ ?x4768 ?x4383)))))))
 (let ((?x4393 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x4768 ?x4388)))))))
 (let ((?x3410 (seq.unit (_ bv4 8))))
 (let ((?x3409 (seq.unit (_ bv6 8))))
 (let ((?x4398 (seq.++ ?x3409 (seq.++ ?x3410 (seq.++ ?x155 (seq.++ ?x4768 (seq.++ ?x4768 ?x4393)))))))
 (let ((?x3408 (seq.unit (_ bv8 8))))
 (let ((?x4403 (seq.++ ?x3409 (seq.++ ?x155 (seq.++ ?x77 (seq.++ ?x3408 (seq.++ ?x155 ?x4398)))))))
 (let ((?x4408 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x4768 (seq.++ ?x3408 ?x4403)))))))
 (let ((?x4413 (seq.++ ?x155 (seq.++ ?x155 (seq.++ ?x77 (seq.++ ?x4768 (seq.++ ?x155 ?x4408)))))))
 (let ((?x4414 (seq.++ ?x4768 (seq.++ ?x155 (seq.++ ?x155 ?x4413)))))
 (= input_0_net.frame_frame ?x4414))))))))))))))))))
(assert
 (= 4 choice_1))
(assert
 (= 60000 now_2))
(assert
 (= 0 choice_2))
(assert
 (= 60000 now_3))
(assert
 (let ((?x4767 (seq.unit (_ bv192 8))))
(let ((?x157 (seq.++ ?x4767 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x157))))
(check-sat)

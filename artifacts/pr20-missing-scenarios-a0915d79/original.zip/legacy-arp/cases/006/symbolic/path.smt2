; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x47 (= due_1_cache due_0_cache)))
 (let (($x3157 (= due_1_query 1000)))
 (let (($x3740 (= active_1_cache active_0_cache)))
 (let (($x3159 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3156 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3155 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3154 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x3151 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2339 (not v_1_rxudp_require_checksum)))
 (let (($x3152 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x883 (= v_1_ip_checksum 0)))
 (let (($x3172 (= v_1_udp_checksum 0)))
 (let (($x3173 (= v_1_udp_raw_checksum 0)))
 (let (($x3170 (= v_1_ip_length 0)))
 (let (($x3171 (= v_1_udp_length 0)))
 (let (($x3148 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x3147 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3144 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3143 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3142 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x683 (= v_1_cache_ttl_ms 60000)))
 (let (($x877 (= 0 v_1_retry_count)))
 (let (($x3140 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x365 (= 1 state_1)))
 (let (($x990 (not active_0_cache)))
 (let (($x3139 (or $x990 (not (<= due_0_cache 0)))))
 (let (($x4751 (not active_0_query)))
 (let (($x3134 (or $x4751 (not (<= due_0_query 0)))))
 (let (($x2731 (= state_0 0)))
 (and $x2731 (>= 0 now_0) $x3134 $x3139 $x365 $x3140 $x877 $x683 v_1_checksums_enabled $x3142 $x3143 $x3144 $x3145 $x3146 $x3147 $x3148 $x3171 $x3170 $x3173 $x3172 $x883 $x3152 $x2339 $x3151 (= v_1_rxudp_disposition "none") $x3154 $x3155 $x3156 $x3159 (= v_1_echo_disposition "none") active_1_query $x3740 $x3157 $x47)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2641 (= due_2_cache due_1_cache)))
 (let (($x2640 (= due_2_query due_1_query)))
 (let (($x2639 (= active_2_cache active_1_cache)))
 (let (($x2638 (= active_2_query active_1_query)))
 (let (($x2637 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2636 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x2635 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x2634 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x2633 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x2485 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2632 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2631 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x2630 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x2629 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2628 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2627 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2626 (= v_2_ip_length v_1_ip_length)))
 (let (($x2625 (= v_2_udp_length v_1_udp_length)))
 (let (($x2624 (= v_2_packet v_1_packet)))
 (let (($x2623 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2622 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x5041 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x5040 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x4981 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2335 (= v_2_payload v_1_payload)))
 (let (($x5031 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x5030 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x5108 (= v_2_retry_count v_1_retry_count)))
 (let (($x5107 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x5106 (= 1 state_2)))
 (let (($x2748 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x2734 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x142 (= state_1 1)))
 (and $x142 $x2734 $x2748 $x5106 $x5107 $x5108 $x5030 $x5031 $x2335 $x4981 $x5040 $x5041 $x2622 $x2623 $x2624 $x2625 $x2626 $x2627 $x2628 $x2629 $x2630 $x2631 $x2632 $x2485 $x2633 $x2634 $x2635 $x2636 $x2637 $x2638 $x2639 $x2640 $x2641)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1429 (= due_3_query due_2_query)))
 (let (($x2548 (not active_3_query)))
 (let (($x1426 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x1425 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x1424 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x1423 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x1422 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x1421 (= v_3_rxudp_disposition v_2_rxudp_disposition)))
 (let (($x1420 (= v_3_rxudp_payload v_2_rxudp_payload)))
 (let (($x1419 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x1418 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x1417 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1416 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x1415 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x1414 (= v_3_ip_length v_2_ip_length)))
 (let (($x1412 (= v_3_udp_length v_2_udp_length)))
 (let (($x1409 (= v_3_packet v_2_packet)))
 (let (($x1408 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x1407 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x1406 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1405 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1404 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x1403 (= v_3_payload v_2_payload)))
 (let (($x1402 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x1401 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x1400 (= 0 v_3_retry_count)))
 (let ((?x4407 (seq.unit (_ bv0 8))))
 (let ((?x584 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.unit (_ bv2 8))))))))
 (let ((?x4901 (seq.unit (_ bv2 8))))
 (let (($x207 (= v_3_peer_mac (seq.++ ?x4901 ?x584))))
 (let (($x1398 (= 2 state_3)))
 (let (($x68 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x4679 (or (not active_2_query) (not (<= due_2_query 10)))))
 (let ((?x1378 (seq.len v_2_pending_packet)))
 (let (($x1382 (= 0 ?x1378)))
 (let (($x5091 (= state_2 1)))
 (and $x5091 $x1382 $x4679 $x68 $x1398 $x207 $x1400 $x1401 $x1402 $x1403 $x1404 $x1405 $x1406 $x1407 $x1408 $x1409 $x1412 $x1414 $x1415 $x1416 $x1417 $x1418 $x1419 $x1420 $x1421 $x1422 $x1423 $x1424 $x1425 $x1426 $x2548 active_3_cache $x1429 (= due_3_cache (+ 10 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5158 (seq.unit (_ bv192 8))))
 (let ((?x588 (seq.++ ?x5158 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x588))))
(assert
 (= 12 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x5158 (seq.unit (_ bv192 8))))
 (let ((?x491 (seq.++ ?x5158 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x4407 (seq.unit (_ bv0 8))))
 (let ((?x4504 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 ?x491)))))))
 (let ((?x4901 (seq.unit (_ bv2 8))))
 (let ((?x4429 (seq.++ ?x5158 (seq.++ ?x4407 (seq.++ ?x4901 (seq.++ ?x4901 (seq.++ ?x4407 ?x4504)))))))
 (let ((?x4483 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4901 ?x4429)))))))
 (let ((?x5116 (seq.unit (_ bv1 8))))
 (let ((?x4850 (seq.unit (_ bv4 8))))
 (let ((?x4849 (seq.unit (_ bv6 8))))
 (let ((?x5148 (seq.++ ?x4849 (seq.++ ?x4850 (seq.++ ?x4407 (seq.++ ?x5116 (seq.++ ?x4901 ?x4483)))))))
 (let ((?x4848 (seq.unit (_ bv8 8))))
 (let ((?x4501 (seq.++ ?x4849 (seq.++ ?x4407 (seq.++ ?x5116 (seq.++ ?x4848 (seq.++ ?x4407 ?x5148)))))))
 (let ((?x4703 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4901 (seq.++ ?x4848 ?x4501)))))))
 (let ((?x617 (seq.unit (_ bv255 8))))
 (let ((?x4753 (seq.++ ?x617 (seq.++ ?x617 (seq.++ ?x617 (seq.++ ?x4901 (seq.++ ?x4407 ?x4703)))))))
 (let ((?x4630 (seq.++ ?x617 (seq.++ ?x617 (seq.++ ?x617 ?x4753)))))
 (= input_1_net.frame_frame ?x4630)))))))))))))))))))
(assert
 (= 29 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x5158 (seq.unit (_ bv192 8))))
(let ((?x2304 (seq.++ ?x5158 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x5116 (seq.unit (_ bv1 8))))
(let ((?x4407 (seq.unit (_ bv0 8))))
(let ((?x4491 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x5116 ?x2304)))))))
(let ((?x4901 (seq.unit (_ bv2 8))))
(let ((?x4442 (seq.++ ?x5158 (seq.++ ?x4407 (seq.++ ?x4901 (seq.++ ?x4901 (seq.++ ?x4901 ?x4491)))))))
(let ((?x1933 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4901 ?x4442)))))))
(let ((?x4850 (seq.unit (_ bv4 8))))
(let ((?x4849 (seq.unit (_ bv6 8))))
(let ((?x4680 (seq.++ ?x4849 (seq.++ ?x4850 (seq.++ ?x4407 (seq.++ ?x4901 (seq.++ ?x4901 ?x1933)))))))
(let ((?x4848 (seq.unit (_ bv8 8))))
(let ((?x4577 (seq.++ ?x4849 (seq.++ ?x4407 (seq.++ ?x5116 (seq.++ ?x4848 (seq.++ ?x4407 ?x4680)))))))
(let ((?x5255 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x4901 (seq.++ ?x4848 ?x4577)))))))
(let ((?x702 (seq.++ ?x4407 (seq.++ ?x4407 (seq.++ ?x5116 (seq.++ ?x4901 (seq.++ ?x4407 ?x5255)))))))
(let ((?x146 (seq.++ ?x4901 (seq.++ ?x4407 (seq.++ ?x4407 ?x702)))))
(= input_2_net.frame_frame ?x146))))))))))))))))))
(check-sat)

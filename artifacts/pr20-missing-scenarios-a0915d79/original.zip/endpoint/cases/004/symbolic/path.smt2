; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3538 (= due_1_cache due_0_cache)))
 (let (($x3536 (= due_1_query due_0_query)))
 (let (($x3839 (= active_1_cache active_0_cache)))
 (let (($x7667 (= active_1_query active_0_query)))
 (let (($x2770 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3167 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3165 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x5559 (= v_1_rxudp_disposition "deliver")))
 (let (($x3164 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x28354 (not v_1_rxudp_require_checksum)))
 (let (($x3161 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2025 (= v_1_ip_checksum 0)))
 (let (($x2026 (= v_1_udp_checksum 0)))
 (let (($x2401 (= v_1_udp_raw_checksum 0)))
 (let (($x4617 (= v_1_ip_length 0)))
 (let (($x718 (= v_1_udp_length 0)))
 (let (($x3160 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x3159 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3158 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3157 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3156 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3155 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3154 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x7719 (= v_1_cache_ttl_ms 60000)))
 (let (($x6267 (= v_1_retry_count 0)))
 (let (($x3153 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x5718 (= 0 state_1)))
 (let (($x969 (not active_0_cache)))
 (let (($x3152 (or $x969 (not (<= due_0_cache 0)))))
 (let (($x7691 (not active_0_query)))
 (let (($x3149 (or $x7691 (not (<= due_0_query 0)))))
 (let (($x279 (= state_0 0)))
 (and $x279 (>= 0 now_0) $x3149 $x3152 $x5718 $x3153 $x6267 $x7719 v_1_checksums_enabled $x3154 $x3155 $x3156 $x3157 $x3158 $x3159 $x3160 $x718 $x4617 $x2401 $x2026 $x2025 $x3161 $x28354 $x3164 $x5559 $x3165 $x3166 $x3167 $x2770 (= v_1_echo_disposition "none") $x7667 $x3839 $x3536 $x3538)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x7662 (= due_2_cache due_1_cache)))
 (let (($x4048 (= due_2_query due_1_query)))
 (let (($x7663 (= active_2_cache active_1_cache)))
 (let (($x7510 (= active_2_query active_1_query)))
 (let (($x7666 (= v_2_echo_disposition "reply")))
 (let ((?x3778 (seq.unit (_ bv192 8))))
 (let ((?x5747 (seq.++ ?x3778 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x238 (seq.unit (_ bv1 8))))
 (let ((?x7713 (seq.unit (_ bv2 8))))
 (let ((?x2490 (seq.unit (_ bv0 8))))
 (let ((?x3361 (seq.++ ?x2490 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x238 ?x5747)))))))
 (let ((?x302 (seq.unit (_ bv64 8))))
 (let ((?x3373 (seq.++ ?x302 (seq.++ ?x2490 (seq.++ ?x302 (seq.++ ?x238 (seq.++ ?x2490 ?x3361)))))))
 (let ((?x3375 (seq.++ ?x2490 (seq.++ ?x2490 ?x3373))))
 (let ((?x1728 (seq.unit (_ bv28 8))))
 (let ((?x2498 (seq.unit (_ bv69 8))))
 (let (($x2346 (= v_2_echo_ip_zero (seq.++ ?x2498 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x1728 ?x3375)))))))
 (let ((?x1835 (seq.unit (_ bv18 8))))
 (let ((?x5125 (seq.++ ?x1835 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x1833 (seq.unit (_ bv254 8))))
 (let ((?x2284 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ (seq.unit (_ bv65 8)) (seq.++ ?x1833 ?x5125))))))
 (let (($x2345 (= v_2_echo_icmp_wire ?x2284)))
 (let (($x2344 (= v_2_echo_icmp_zero (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x2490 ?x5125)))))))
 (let ((?x2326 (seq.++ ?x238 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x7713 ?x2284)))))))
 (let ((?x1829 (seq.unit (_ bv221 8))))
 (let ((?x1730 (seq.unit (_ bv182 8))))
 (let ((?x2331 (seq.++ ?x1730 (seq.++ ?x1829 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 ?x2326)))))))
 (let ((?x2336 (seq.++ ?x2490 (seq.++ ?x302 (seq.++ ?x2490 (seq.++ ?x302 (seq.++ ?x238 ?x2331)))))))
 (let ((?x2342 (seq.++ ?x2498 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x1728 (seq.++ ?x2490 ?x2336)))))))
 (let (($x2343 (= v_2_echo_reply ?x2342)))
 (let (($x873 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x7672 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x7512 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x7674 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x7513 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x7676 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x7621 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1746 (= v_2_ip_length v_1_ip_length)))
 (let (($x7622 (= v_2_udp_length v_1_udp_length)))
 (let (($x7572 (= v_2_packet v_1_packet)))
 (let (($x42 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x7573 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2353 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x7575 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x3746 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x7679 (= v_2_payload v_1_payload)))
 (let (($x121 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x7681 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x3747 (= v_2_retry_count v_1_retry_count)))
 (let (($x7685 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x122 (= 0 state_2)))
 (let (($x4337 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x4418 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x4054 (= state_1 0)))
 (and $x4054 $x4418 $x4337 $x122 $x7685 $x3747 $x7681 $x121 $x7679 $x3746 $x7575 $x2353 $x7573 $x42 $x7572 $x7622 $x1746 $x7621 $x7676 $x7513 $x7674 $x7512 $x7672 $x873 $x2343 $x2344 $x2345 $x2346 $x7666 $x7510 $x7663 $x4048 $x7662))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1736 (seq.unit (_ bv165 8))))
 (let ((?x1741 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 ?x1736)))))))
 (let ((?x1779 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 ?x1741)))))))
 (let ((?x1783 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 (seq.++ ?x1736 ?x1779)))))))
 (let ((?x3778 (seq.unit (_ bv192 8))))
 (let ((?x1787 (seq.++ ?x3778 (seq.++ (seq.unit (_ bv9 8)) (seq.++ ?x1736 (seq.++ ?x1736 ?x1783))))))
 (let ((?x67 (seq.unit (_ bv8 8))))
 (let ((?x2490 (seq.unit (_ bv0 8))))
 (let ((?x302 (seq.unit (_ bv64 8))))
 (let ((?x869 (seq.unit (_ bv156 8))))
 (let ((?x3470 (seq.unit (_ bv144 8))))
 (let ((?x1792 (seq.++ ?x3470 (seq.++ ?x869 (seq.++ ?x302 (seq.++ ?x2490 (seq.++ ?x67 ?x1787)))))))
 (let ((?x4190 (seq.unit (_ bv31 8))))
 (let ((?x238 (seq.unit (_ bv1 8))))
 (let ((?x7713 (seq.unit (_ bv2 8))))
 (let ((?x1797 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x238 (seq.++ ?x4190 ?x1792)))))))
 (let ((?x1732 (seq.unit (_ bv205 8))))
 (let ((?x1802 (seq.++ ?x1732 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x7713 ?x1797)))))))
 (let ((?x1730 (seq.unit (_ bv182 8))))
 (let ((?x303 (seq.unit (_ bv17 8))))
 (let ((?x1805 (seq.++ ?x302 (seq.++ ?x2490 (seq.++ ?x302 (seq.++ ?x303 (seq.++ ?x1730 ?x1802)))))))
 (let ((?x1728 (seq.unit (_ bv28 8))))
 (let ((?x1810 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x1728 (seq.++ ?x2490 (seq.++ ?x2490 ?x1805)))))))
 (let ((?x2498 (seq.unit (_ bv69 8))))
 (let ((?x1815 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x67 (seq.++ ?x2490 (seq.++ ?x2498 ?x1810)))))))
 (let ((?x1820 (seq.++ ?x238 (seq.++ ?x7713 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x2490 ?x1815)))))))
 (let ((?x1825 (seq.++ ?x7713 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x2490 ?x1820)))))))
 (= input_0_net.frame_frame ?x1825)))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x1841 (seq.unit (_ bv126 8))))
(let ((?x1846 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 ?x1841)))))))
(let ((?x1851 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 ?x1846)))))))
(let ((?x1856 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 (seq.++ ?x1841 ?x1851)))))))
(let ((?x1732 (seq.unit (_ bv205 8))))
(let ((?x1839 (seq.unit (_ bv171 8))))
(let ((?x1837 (seq.unit (_ bv52 8))))
(let ((?x1861 (seq.++ ?x1837 (seq.++ ?x1839 (seq.++ ?x1732 (seq.++ ?x1841 (seq.++ ?x1841 ?x1856)))))))
(let ((?x1835 (seq.unit (_ bv18 8))))
(let ((?x1833 (seq.unit (_ bv254 8))))
(let ((?x1831 (seq.unit (_ bv57 8))))
(let ((?x2490 (seq.unit (_ bv0 8))))
(let ((?x67 (seq.unit (_ bv8 8))))
(let ((?x1866 (seq.++ ?x67 (seq.++ ?x2490 (seq.++ ?x1831 (seq.++ ?x1833 (seq.++ ?x1835 ?x1861)))))))
(let ((?x238 (seq.unit (_ bv1 8))))
(let ((?x7713 (seq.unit (_ bv2 8))))
(let ((?x3778 (seq.unit (_ bv192 8))))
(let ((?x1871 (seq.++ ?x7713 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x238 ?x1866)))))))
(let ((?x1829 (seq.unit (_ bv221 8))))
(let ((?x1730 (seq.unit (_ bv182 8))))
(let ((?x1876 (seq.++ ?x1730 (seq.++ ?x1829 (seq.++ ?x3778 (seq.++ ?x2490 (seq.++ ?x7713 ?x1871)))))))
(let ((?x302 (seq.unit (_ bv64 8))))
(let ((?x1881 (seq.++ ?x2490 (seq.++ ?x302 (seq.++ ?x2490 (seq.++ ?x302 (seq.++ ?x238 ?x1876)))))))
(let ((?x1728 (seq.unit (_ bv28 8))))
(let ((?x2498 (seq.unit (_ bv69 8))))
(let ((?x1886 (seq.++ ?x2498 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x1728 (seq.++ ?x2490 ?x1881)))))))
(let ((?x1891 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x7713 (seq.++ ?x67 (seq.++ ?x2490 ?x1886)))))))
(let ((?x1896 (seq.++ ?x2490 (seq.++ ?x238 (seq.++ ?x7713 (seq.++ ?x2490 (seq.++ ?x2490 ?x1891)))))))
(let ((?x1900 (seq.++ ?x7713 (seq.++ ?x2490 (seq.++ ?x2490 (seq.++ ?x2490 ?x1896))))))
(= input_1_net.frame_frame ?x1900)))))))))))))))))))))))))))))))
(check-sat)

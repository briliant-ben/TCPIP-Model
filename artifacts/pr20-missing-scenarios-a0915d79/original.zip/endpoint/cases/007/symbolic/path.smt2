; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1819 (= due_1_cache due_0_cache)))
 (let (($x6077 (= due_1_query due_0_query)))
 (let (($x13930 (= active_1_cache active_0_cache)))
 (let (($x13932 (= active_1_query active_0_query)))
 (let (($x4447 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x225 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3874 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3835 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x11434 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x3725 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x188 (not v_1_rxudp_require_checksum)))
 (let (($x2414 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x5664 (= v_1_ip_checksum 0)))
 (let (($x8612 (= v_1_udp_checksum 0)))
 (let (($x7318 (= v_1_udp_raw_checksum 0)))
 (let (($x9414 (= v_1_ip_length 0)))
 (let (($x22464 (= v_1_udp_length 0)))
 (let (($x3110 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x931 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x5456 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3311 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3310 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3046 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3309 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x26306 (= v_1_cache_ttl_ms 60000)))
 (let (($x12207 (= v_1_retry_count 0)))
 (let (($x3308 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x10134 (= 0 state_1)))
 (let (($x1675 (not active_0_cache)))
 (let (($x3307 (or $x1675 (not (<= due_0_cache 0)))))
 (let (($x8972 (not active_0_query)))
 (let (($x2263 (or $x8972 (not (<= due_0_query 0)))))
 (let (($x3224 (= state_0 0)))
 (and $x3224 (>= 0 now_0) $x2263 $x3307 $x10134 $x3308 $x12207 $x26306 v_1_checksums_enabled $x3309 $x3046 $x3310 $x3311 $x5456 $x931 $x3110 $x22464 $x9414 $x7318 $x8612 $x5664 $x2414 $x188 $x3725 $x11434 $x3835 $x3874 $x225 $x4447 (= v_1_echo_disposition "none") $x13932 $x13930 $x6077 $x1819)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x3387 (seq.unit (_ bv0 8))))
(let ((?x4896 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 ?x3387)))))))
(let ((?x7345 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 ?x4896)))))))
(let ((?x7703 (seq.unit (_ bv111 8))))
(let ((?x940 (seq.unit (_ bv108 8))))
(let ((?x4421 (seq.++ ?x940 (seq.++ ?x940 (seq.++ ?x7703 (seq.++ ?x3387 (seq.++ ?x3387 ?x7345)))))))
(let ((?x7627 (seq.unit (_ bv101 8))))
(let ((?x7628 (seq.unit (_ bv104 8))))
(let ((?x7629 (seq.unit (_ bv45 8))))
(let ((?x1515 (seq.unit (_ bv124 8))))
(let ((?x7520 (seq.unit (_ bv13 8))))
(let ((?x4354 (seq.++ ?x7520 (seq.++ ?x1515 (seq.++ ?x7629 (seq.++ ?x7628 (seq.++ ?x7627 ?x4421)))))))
(let ((?x18836 (seq.unit (_ bv64 8))))
(let ((?x1387 (seq.unit (_ bv156 8))))
(let ((?x21937 (seq.unit (_ bv144 8))))
(let ((?x4424 (seq.unit (_ bv31 8))))
(let ((?x4364 (seq.++ ?x4424 (seq.++ ?x21937 (seq.++ ?x1387 (seq.++ ?x18836 (seq.++ ?x3387 ?x4354)))))))
(let ((?x5041 (seq.unit (_ bv1 8))))
(let ((?x56 (seq.unit (_ bv2 8))))
(let ((?x3386 (seq.unit (_ bv192 8))))
(let ((?x4376 (seq.++ ?x56 (seq.++ ?x3386 (seq.++ ?x3387 (seq.++ ?x56 (seq.++ ?x5041 ?x4364)))))))
(let ((?x1649 (seq.unit (_ bv206 8))))
(let ((?x1647 (seq.unit (_ bv182 8))))
(let ((?x3191 (seq.++ ?x1647 (seq.++ ?x1649 (seq.++ ?x3386 (seq.++ ?x3387 (seq.++ ?x56 ?x4376)))))))
(let ((?x1569 (seq.unit (_ bv17 8))))
(let ((?x4221 (seq.++ ?x3387 (seq.++ ?x18836 (seq.++ ?x3387 (seq.++ ?x18836 (seq.++ ?x1569 ?x3191)))))))
(let ((?x1645 (seq.unit (_ bv27 8))))
(let ((?x4090 (seq.unit (_ bv69 8))))
(let ((?x7712 (seq.++ ?x4090 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x1645 (seq.++ ?x3387 ?x4221)))))))
(let ((?x347 (seq.unit (_ bv8 8))))
(let ((?x2403 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x56 (seq.++ ?x347 (seq.++ ?x3387 ?x7712)))))))
(let ((?x5422 (seq.++ ?x3387 (seq.++ ?x5041 (seq.++ ?x56 (seq.++ ?x3387 (seq.++ ?x3387 ?x2403)))))))
(let ((?x4330 (seq.++ ?x56 (seq.++ ?x3387 (seq.++ ?x3387 (seq.++ ?x3387 ?x5422))))))
(= input_0_net.frame_frame ?x4330)))))))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x5137 (= due_1_cache due_0_cache)))
 (let (($x1761 (= due_1_query due_0_query)))
 (let (($x5136 (= active_1_cache active_0_cache)))
 (let (($x1760 (= active_1_query active_0_query)))
 (let (($x1080 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x1142 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x1141 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x1140 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1757 (= v_1_rxudp_disposition "deliver")))
 (let ((?x3349 (seq.unit (_ bv128 8))))
 (let ((?x3692 (seq.++ ?x3349 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x223 (seq.unit (_ bv0 8))))
 (let ((?x2500 (seq.++ ?x223 ?x3692)))
 (let (($x1139 (= v_1_rxudp_payload ?x2500)))
 (let (($x6072 (not v_1_rxudp_require_checksum)))
 (let (($x5580 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2473 (= v_1_ip_checksum 0)))
 (let (($x2476 (= v_1_udp_checksum 0)))
 (let (($x2477 (= v_1_udp_raw_checksum 0)))
 (let (($x2478 (= v_1_ip_length 0)))
 (let (($x2479 (= v_1_udp_length 0)))
 (let (($x4042 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x893 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x5256 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x5255 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x5274 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3775 (= v_1_cache_ttl_ms 60000)))
 (let (($x3776 (= v_1_retry_count 0)))
 (let (($x5273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1747 (= 0 state_1)))
 (let (($x7713 (not active_0_cache)))
 (let (($x5272 (or $x7713 (not (<= due_0_cache 0)))))
 (let (($x7711 (not active_0_query)))
 (let (($x5269 (or $x7711 (not (<= due_0_query 0)))))
 (let (($x7636 (= state_0 0)))
 (and $x7636 (>= 0 now_0) $x5269 $x5272 $x1747 $x5273 $x3776 $x3775 v_1_checksums_enabled $x5274 $x5255 $x5256 $x893 $x4145 $x4146 $x4042 $x2479 $x2478 $x2477 $x2476 $x2473 $x5580 $x6072 $x1139 $x1757 $x1140 $x1141 $x1142 $x1080 (= v_1_echo_disposition "none") $x1760 $x5136 $x1761 $x5137)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2418 (= due_2_cache due_1_cache)))
 (let (($x2417 (= due_2_query due_1_query)))
 (let (($x2416 (= active_2_cache active_1_cache)))
 (let (($x2415 (= active_2_query active_1_query)))
 (let (($x2414 (= v_2_echo_disposition "reply")))
 (let ((?x831 (seq.unit (_ bv192 8))))
 (let ((?x7516 (seq.++ ?x831 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x7563 (seq.unit (_ bv1 8))))
 (let ((?x214 (seq.unit (_ bv2 8))))
 (let ((?x223 (seq.unit (_ bv0 8))))
 (let ((?x2273 (seq.++ ?x223 (seq.++ ?x831 (seq.++ ?x223 (seq.++ ?x214 (seq.++ ?x7563 ?x7516)))))))
 (let ((?x6192 (seq.unit (_ bv64 8))))
 (let ((?x2278 (seq.++ ?x6192 (seq.++ ?x223 (seq.++ ?x6192 (seq.++ ?x7563 (seq.++ ?x223 ?x2273)))))))
 (let ((?x2280 (seq.++ ?x223 (seq.++ ?x223 ?x2278))))
 (let ((?x3337 (seq.unit (_ bv33 8))))
 (let ((?x6190 (seq.unit (_ bv69 8))))
 (let (($x5551 (= v_2_echo_ip_zero (seq.++ ?x6190 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x3337 ?x2280)))))))
 (let ((?x3349 (seq.unit (_ bv128 8))))
 (let ((?x2500 (seq.++ ?x223 (seq.++ ?x3349 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x223))))))
 (let ((?x3415 (seq.unit (_ bv205 8))))
 (let ((?x3413 (seq.unit (_ bv171 8))))
 (let ((?x3411 (seq.unit (_ bv52 8))))
 (let ((?x3409 (seq.unit (_ bv18 8))))
 (let ((?x273 (seq.++ ?x3409 (seq.++ ?x3411 (seq.++ ?x3413 (seq.++ ?x3415 ?x2500))))))
 (let ((?x3407 (seq.unit (_ bv118 8))))
 (let ((?x5418 (seq.++ ?x223 (seq.++ ?x223 (seq.++ (seq.unit (_ bv66 8)) (seq.++ ?x3407 ?x273))))))
 (let (($x5199 (= v_2_echo_icmp_wire ?x5418)))
 (let (($x5394 (= v_2_echo_icmp_zero (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x273)))))))
 (let ((?x3975 (seq.++ ?x7563 (seq.++ ?x831 (seq.++ ?x223 (seq.++ ?x214 (seq.++ ?x214 ?x5418)))))))
 (let ((?x3403 (seq.unit (_ bv216 8))))
 (let ((?x5338 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x3403 (seq.++ ?x831 (seq.++ ?x223 (seq.++ ?x214 ?x3975)))))))
 (let ((?x5343 (seq.++ ?x223 (seq.++ ?x6192 (seq.++ ?x223 (seq.++ ?x6192 (seq.++ ?x7563 ?x5338)))))))
 (let ((?x195 (seq.++ ?x6190 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x3337 (seq.++ ?x223 ?x5343)))))))
 (let (($x1133 (= v_2_echo_reply ?x195)))
 (let (($x2409 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2408 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2407 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x2406 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x2405 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2404 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2403 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2402 (= v_2_ip_length v_1_ip_length)))
 (let (($x2401 (= v_2_udp_length v_1_udp_length)))
 (let (($x2400 (= v_2_packet v_1_packet)))
 (let (($x2399 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2398 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2397 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2396 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2395 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2394 (= v_2_payload v_1_payload)))
 (let (($x2393 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2392 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2391 (= v_2_retry_count v_1_retry_count)))
 (let (($x2390 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x2389 (= 0 state_2)))
 (let (($x7669 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x3912 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x254 (= state_1 0)))
 (and $x254 $x3912 $x7669 $x2389 $x2390 $x2391 $x2392 $x2393 $x2394 $x2395 $x2396 $x2397 $x2398 $x2399 $x2400 $x2401 $x2402 $x2403 $x2404 $x2405 $x2406 $x2407 $x2408 $x2409 $x1133 $x5394 $x5199 $x5551 $x2414 $x2415 $x2416 $x2417 $x2418))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x223 (seq.unit (_ bv0 8))))
 (let ((?x6227 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x223)))))
 (let ((?x2311 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x6227)))))))
 (let ((?x2316 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x2311)))))))
 (let ((?x3351 (seq.unit (_ bv7 8))))
 (let ((?x3748 (seq.unit (_ bv255 8))))
 (let ((?x3349 (seq.unit (_ bv128 8))))
 (let ((?x3355 (seq.++ ?x223 (seq.++ ?x3349 (seq.++ ?x3748 (seq.++ ?x3351 ?x2316))))))
 (let ((?x831 (seq.unit (_ bv192 8))))
 (let ((?x3359 (seq.++ ?x223 (seq.++ (seq.unit (_ bv13 8)) (seq.++ ?x831 (seq.++ (seq.unit (_ bv119 8)) ?x3355))))))
 (let ((?x6192 (seq.unit (_ bv64 8))))
 (let ((?x3509 (seq.unit (_ bv156 8))))
 (let ((?x6196 (seq.unit (_ bv144 8))))
 (let ((?x25 (seq.unit (_ bv31 8))))
 (let ((?x7563 (seq.unit (_ bv1 8))))
 (let ((?x3364 (seq.++ ?x7563 (seq.++ ?x25 (seq.++ ?x6196 (seq.++ ?x3509 (seq.++ ?x6192 ?x3359)))))))
 (let ((?x214 (seq.unit (_ bv2 8))))
 (let ((?x3369 (seq.++ ?x214 (seq.++ ?x214 (seq.++ ?x831 (seq.++ ?x223 (seq.++ ?x214 ?x3364)))))))
 (let ((?x3373 (seq.++ (seq.unit (_ bv177 8)) (seq.++ (seq.unit (_ bv246 8)) (seq.++ ?x831 (seq.++ ?x223 ?x3369))))))
 (let ((?x1058 (seq.unit (_ bv17 8))))
 (let ((?x3378 (seq.++ (seq.unit (_ bv210 8)) (seq.++ ?x6192 (seq.++ ?x223 (seq.++ ?x6192 (seq.++ ?x1058 ?x3373)))))))
 (let ((?x2184 (seq.unit (_ bv4 8))))
 (let ((?x3337 (seq.unit (_ bv33 8))))
 (let ((?x6190 (seq.unit (_ bv69 8))))
 (let ((?x3383 (seq.++ ?x6190 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x3337 (seq.++ ?x2184 ?x3378)))))))
 (let ((?x4945 (seq.unit (_ bv8 8))))
 (let ((?x3388 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x214 (seq.++ ?x4945 (seq.++ ?x223 ?x3383)))))))
 (let ((?x3393 (seq.++ ?x223 (seq.++ ?x7563 (seq.++ ?x214 (seq.++ ?x223 (seq.++ ?x223 ?x3388)))))))
 (let ((?x3397 (seq.++ ?x214 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x3393))))))
 (= input_0_net.frame_frame ?x3397)))))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x223 (seq.unit (_ bv0 8))))
(let ((?x6227 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x223)))))
(let ((?x2311 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x6227)))))))
(let ((?x2316 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 ?x2311)))))))
(let ((?x3351 (seq.unit (_ bv7 8))))
(let ((?x3748 (seq.unit (_ bv255 8))))
(let ((?x3349 (seq.unit (_ bv128 8))))
(let ((?x3355 (seq.++ ?x223 (seq.++ ?x3349 (seq.++ ?x3748 (seq.++ ?x3351 ?x2316))))))
(let ((?x3415 (seq.unit (_ bv205 8))))
(let ((?x3413 (seq.unit (_ bv171 8))))
(let ((?x3411 (seq.unit (_ bv52 8))))
(let ((?x3409 (seq.unit (_ bv18 8))))
(let ((?x3407 (seq.unit (_ bv118 8))))
(let ((?x3420 (seq.++ ?x3407 (seq.++ ?x3409 (seq.++ ?x3411 (seq.++ ?x3413 (seq.++ ?x3415 ?x3355)))))))
(let ((?x3405 (seq.unit (_ bv58 8))))
(let ((?x4945 (seq.unit (_ bv8 8))))
(let ((?x7563 (seq.unit (_ bv1 8))))
(let ((?x214 (seq.unit (_ bv2 8))))
(let ((?x3425 (seq.++ ?x214 (seq.++ ?x7563 (seq.++ ?x4945 (seq.++ ?x223 (seq.++ ?x3405 ?x3420)))))))
(let ((?x831 (seq.unit (_ bv192 8))))
(let ((?x3430 (seq.++ ?x223 (seq.++ ?x214 (seq.++ ?x214 (seq.++ ?x831 (seq.++ ?x223 ?x3425)))))))
(let ((?x3403 (seq.unit (_ bv216 8))))
(let ((?x3401 (seq.unit (_ bv245 8))))
(let ((?x3435 (seq.++ ?x7563 (seq.++ ?x7563 (seq.++ ?x3401 (seq.++ ?x3403 (seq.++ ?x831 ?x3430)))))))
(let ((?x6192 (seq.unit (_ bv64 8))))
(let ((?x3337 (seq.unit (_ bv33 8))))
(let ((?x3439 (seq.++ ?x3337 (seq.++ ?x3748 (seq.++ ?x3748 (seq.++ ?x6192 (seq.++ ?x223 ?x3435)))))))
(let ((?x6190 (seq.unit (_ bv69 8))))
(let ((?x3444 (seq.++ ?x4945 (seq.++ ?x223 (seq.++ ?x6190 (seq.++ ?x223 (seq.++ ?x223 ?x3439)))))))
(let ((?x3449 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x214 ?x3444)))))))
(let ((?x3454 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x223 (seq.++ ?x7563 (seq.++ ?x214 ?x3449)))))))
(let ((?x3456 (seq.++ ?x214 (seq.++ ?x223 ?x3454))))
(= input_1_net.frame_frame ?x3456))))))))))))))))))))))))))))))))))
(check-sat)

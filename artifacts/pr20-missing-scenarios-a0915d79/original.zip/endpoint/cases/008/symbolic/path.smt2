; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x9952 (= due_1_cache due_0_cache)))
 (let (($x5711 (= due_1_query due_0_query)))
 (let (($x19409 (= active_1_cache active_0_cache)))
 (let (($x4646 (= active_1_query active_0_query)))
 (let (($x46 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2005 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x2390 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x7521 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x5082 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x2392 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x4066 (not v_1_rxudp_require_checksum)))
 (let (($x196 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x3662 (= v_1_ip_checksum 0)))
 (let (($x23105 (= v_1_udp_checksum 0)))
 (let (($x21945 (= v_1_udp_raw_checksum 0)))
 (let (($x25661 (= v_1_ip_length 0)))
 (let (($x24363 (= v_1_udp_length 0)))
 (let (($x4448 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x13558 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1780 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x5120 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3119 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3391 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x11997 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3856 (= v_1_cache_ttl_ms 60000)))
 (let (($x27704 (= v_1_retry_count 0)))
 (let (($x24192 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x14301 (= 0 state_1)))
 (let (($x25179 (not active_0_cache)))
 (let (($x3846 (or $x25179 (not (<= due_0_cache 0)))))
 (let (($x1878 (not active_0_query)))
 (let (($x28314 (or $x1878 (not (<= due_0_query 0)))))
 (let (($x3287 (= state_0 0)))
 (and $x3287 (>= 0 now_0) $x28314 $x3846 $x14301 $x24192 $x27704 $x3856 v_1_checksums_enabled $x11997 $x3391 $x3119 $x5120 $x1780 $x13558 $x4448 $x24363 $x25661 $x21945 $x23105 $x3662 $x196 $x4066 $x2392 $x5082 $x7521 $x2390 $x2005 $x46 (= v_1_echo_disposition "none") $x4646 $x19409 $x5711 $x9952)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x27641 (seq.unit (_ bv0 8))))
(let ((?x3179 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 ?x27641)))))))
(let ((?x4645 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 ?x3179)))))))
(let ((?x1781 (seq.unit (_ bv111 8))))
(let ((?x19529 (seq.unit (_ bv108 8))))
(let ((?x2257 (seq.++ ?x19529 (seq.++ ?x19529 (seq.++ ?x1781 (seq.++ ?x27641 (seq.++ ?x27641 ?x4645)))))))
(let ((?x23253 (seq.unit (_ bv101 8))))
(let ((?x19530 (seq.unit (_ bv104 8))))
(let ((?x23211 (seq.unit (_ bv45 8))))
(let ((?x11459 (seq.unit (_ bv124 8))))
(let ((?x2260 (seq.unit (_ bv13 8))))
(let ((?x7509 (seq.++ ?x2260 (seq.++ ?x11459 (seq.++ ?x23211 (seq.++ ?x19530 (seq.++ ?x23253 ?x2257)))))))
(let ((?x2384 (seq.unit (_ bv64 8))))
(let ((?x5678 (seq.unit (_ bv156 8))))
(let ((?x6063 (seq.unit (_ bv144 8))))
(let ((?x2359 (seq.unit (_ bv31 8))))
(let ((?x7635 (seq.++ ?x2359 (seq.++ ?x6063 (seq.++ ?x5678 (seq.++ ?x2384 (seq.++ ?x27641 ?x7509)))))))
(let ((?x9414 (seq.unit (_ bv1 8))))
(let ((?x475 (seq.unit (_ bv2 8))))
(let ((?x14529 (seq.unit (_ bv192 8))))
(let ((?x5360 (seq.++ ?x475 (seq.++ ?x14529 (seq.++ ?x27641 (seq.++ ?x475 (seq.++ ?x9414 ?x7635)))))))
(let ((?x14703 (seq.unit (_ bv186 8))))
(let ((?x7571 (seq.unit (_ bv182 8))))
(let ((?x2277 (seq.++ ?x7571 (seq.++ ?x14703 (seq.++ ?x14529 (seq.++ ?x27641 (seq.++ ?x475 ?x5360)))))))
(let ((?x2312 (seq.unit (_ bv17 8))))
(let ((?x13032 (seq.++ ?x27641 (seq.++ ?x2384 (seq.++ ?x27641 (seq.++ ?x2384 (seq.++ ?x2312 ?x2277)))))))
(let ((?x3185 (seq.unit (_ bv47 8))))
(let ((?x18426 (seq.unit (_ bv69 8))))
(let ((?x15675 (seq.++ ?x18426 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x3185 (seq.++ ?x27641 ?x13032)))))))
(let ((?x3094 (seq.unit (_ bv8 8))))
(let ((?x23609 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x475 (seq.++ ?x3094 (seq.++ ?x27641 ?x15675)))))))
(let ((?x5420 (seq.++ ?x27641 (seq.++ ?x9414 (seq.++ ?x475 (seq.++ ?x27641 (seq.++ ?x27641 ?x23609)))))))
(let ((?x3638 (seq.++ ?x475 (seq.++ ?x27641 (seq.++ ?x27641 (seq.++ ?x27641 ?x5420))))))
(= input_0_net.frame_frame ?x3638)))))))))))))))))))))))))))))))))))
(check-sat)

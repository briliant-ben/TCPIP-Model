from pathlib import Path
import json,subprocess,os,time
out=Path(__file__).parent;w=out/"workspace";codes={}
for name in ["test_tcp_peer_symbolic_gate.py","test_tcp_wire_harness_preflight.py"]:
 (out/"status.json").write_text(json.dumps(dict(pid=os.getpid(),status="running",stage=name,paid_requests=0)))
 with(out/(name+".log")).open("w")as log:r=subprocess.run(["/home/blxu/protocol-flow/releases/udp-transmit-1b13a36f/venv/bin/python","-m","unittest","discover","-s","tests","-p",name,"-v"],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=180,env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"});codes[name]=r.returncode
(out/"status.json").write_text(json.dumps(dict(pid=os.getpid(),status="controller_review_required",stage="finished",test_returncodes=codes,paid_requests=0,live_TCP_evidence=False,finished_at=time.time()),indent=2))

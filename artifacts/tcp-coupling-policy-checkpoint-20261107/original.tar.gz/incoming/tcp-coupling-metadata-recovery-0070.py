from pathlib import Path
import ast,copy,hashlib,json,os,subprocess,time,traceback
P=Path('/home/blxu/protocol-flow');PRE=P/'candidates/tcp-ir-coupling-policy-20261107-0069';O=P/'candidates/tcp-ir-coupling-metadata-20261107-0070';O.mkdir(exist_ok=False)
PYTHON=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,prototype_complete=False,**v))
try:
 status(status='running',stage='prove_already_applied_direction',started_at=time.time())
 source=(PRE/'round-1/couple_tcp.py').read_text();v=json.loads((PRE/'repair-2-response.json').read_text());assert len(v['patches'])==4
 m=json.loads((PRE/'validation-0001/candidate-model.json').read_text());drops=[t for t in m['transitions']if 'TCP-IP-FRAME-DROP'in t['requirements']];assert len(drops)==1
 def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
 def conjuncts(x):
  if isinstance(x,dict)and x.get('op')=='and':return set().union(*(conjuncts(y)for y in x['args']))
  return {canon(x)}
 required=[{'op':'eq','args':[{'op':'bytes_slice','args':[{'event':'frame'},offset,4]},{'bytes':ip}]}for offset,ip in [(26,[192,0,2,2]),(30,[192,0,2,1])]]
 assert set(map(canon,required))<=conjuncts(drops[0]['guard'])
 p0=v['patches'][0];assert source.count(p0['old'])==0 and source.count(p0['new'])==2
 save('already-applied-certificate.json',dict(previous_failed_application_preserved=True,skipped_patch_index=0,old_count=0,new_count=2,drop_rule=drops[0]['id'],necessary_guard_conjuncts=required,source_sha256=hashlib.sha256(source.encode()).hexdigest(),API_calls=0))
 for patch in v['patches'][1:]:
  assert set(patch)=={'old','new'}and source.count(patch['old'])==1
  source=source.replace(patch['old'],patch['new'],1)
 ast.parse(source);r=O/'round-1';r.mkdir();(r/'couple_tcp.py').write_text(source)
 template=(P/'incoming/validate-tcp-coupling-0069.py').read_text().replace('tcp-ir-coupling-policy-20261107-0069','tcp-ir-coupling-metadata-20261107-0070')
 needle=" save('candidate-model.json',m)"
 assert template.count(needle)==1
 insertion="""
 old_model=json.loads((P/'candidates/tcp-ir-coupling-policy-20261107-0069/validation-0001/candidate-model.json').read_text())
 def without_transition_sources(model):
  out=copy.deepcopy(model)
  for transition in out['transitions']:transition.pop('requirements')
  return out
 need(without_transition_sources(m)==without_transition_sources(old_model),'metadata recovery changed executable IR')
 save('metadata-only-certificate.json',dict(executable_IR_unchanged=True,only_transition_requirements_may_differ=True,previous_model_sha256=hashlib.sha256(json.dumps(old_model,sort_keys=True).encode()).hexdigest()))
"""
 template=template.replace(needle,needle+insertion);checker=r/'executed-validator.py';checker.write_text(template)
 status(status='running',stage='trusted_four_core_eighteen_policy_gate')
 with(r/'validation-controller.log').open('w')as log:
  cp=subprocess.run([str(PYTHON),str(checker)],stdout=log,stderr=subprocess.STDOUT,timeout=420,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 f=O/'validation-0001/status.json';result=json.loads(f.read_text())if f.exists()else {'status':'no_result'}
 status(status='candidate_ready_for_controller_review'if cp.returncode==0 and result['status']=='finite_candidate_gate_pass_controller_review_required'else'candidate_rejected',stage='finished',returncode=cp.returncode,validation=result,finished_at=time.time(),legacy_45_not_rerun=True)
except Exception as e:
 status(status='controller_recovery_failed',stage='stopped',error_type=type(e).__name__,error=str(e),finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

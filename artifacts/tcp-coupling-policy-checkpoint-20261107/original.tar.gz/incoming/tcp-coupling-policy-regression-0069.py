from pathlib import Path
import copy,hashlib,json,os,platform,resource,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-ir-coupling-policy-20261107-0069/regression-0001';O.mkdir(exist_ok=False);W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';C=P/'candidates/tcp-ir-coupling-policy-20261107-0069/validation-0001';M=C/'candidate-model.json'
resource.setrlimit(resource.RLIMIT_CPU,(900,900));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3));sys.path.insert(0,str(W))
from protocol_lab.ir import load
from protocol_lab.flow import run_scenario
from protocol_lab.codegen.execute import run
from protocol_lab.symbolic import crosscheck_trace

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,network=False,all_input_safety='not_claimed',prototype_complete=False,**v))
def need(ok,msg):
 if not ok:raise ValueError(msg)
def prefix_emissions(rows,prefix):
 return [dict(at_ms=r['at_ms'],emitted=[dict(message=prefix+'.'+e['message'],fields=copy.deepcopy(e['fields']))for e in r['emitted']])for r in rows]
status(status='running',stage='freeze_old_literal_projections',started_at=time.time())
try:
 paths={k:W/('spec/'+k+'-oracle.json')for k in ['ipv4-udp-icmp-endpoint','arp-endpoint','arp-udp-transmit','tcp-wire-endpoint']};oracles={k:json.loads(p.read_text())for k,p in paths.items()};scenes=[]
 for key in ['ipv4-udp-icmp-endpoint','arp-endpoint','arp-udp-transmit']:
  for name,old in oracles[key]['cases'].items():
   s=copy.deepcopy(old);s['id']='L-'+key+'-'+name;s['initial']={'L.'+k:v for k,v in old.get('initial',{}).items()}
   for step in s['steps']:
    if 'event'in step:step['event']='L.'+step['event']
    if 'expect_trace'in step:step['expect_trace']=prefix_emissions(step['expect_trace'],'L')
   s['expect']=dict(state='COMPOSED',variables={'L.'+k:v for k,v in old['expect'].get('variables',{}).items()},timers={'L.'+k:v for k,v in old['expect']['timers'].items()});s['expect']['variables'].update({'L.control':old['expect']['state'],'T.control':'CLOSED'});scenes.append(s)
 arp=oracles['arp-endpoint'];tcp=oracles['tcp-wire-endpoint'];request=list(bytes.fromhex(arp['request_hex']));reply=list(bytes.fromhex(arp['peer_reply_hex']))
 def ethernet(raw,outgoing):
  return ([2,0,0,0,0,2,2,0,0,0,0,1]if outgoing else[2,0,0,0,0,1,2,0,0,0,0,2])+[8,0]+list(raw)+[0]*max(0,46-len(raw))
 positive=['bidirectional-cumulative-close','synack-mss-only','syn-loss-retransmission','data-loss-retransmission','partial-ack-prefix-retransmission','sequence-wrap']
 for name in positive:
  old=tcp['cases'][name];need(old['steps'][0]['event']=='app.connect'and old['steps'][0]['at_ms']==0 and old['steps'][1]['at_ms']>1,'unexpected TCP prelude')
  first=old['steps'][0]['expect_trace'];need(len(first)==1 and len(first[0]['emitted'])==1 and first[0]['emitted'][0]['message']=='ipv4.tx','unexpected initial literal SYN');syn=first[0]['emitted'][0]['fields']['packet']
  s=dict(scenario_version='0.2',id='T-'+name,initial={'T.'+k:v for k,v in old.get('initial',{}).items()},steps=[dict(at_ms=0,event='T.app.connect',fields={},expect_trace=[dict(at_ms=0,emitted=[dict(message='L.ethernet.tx',fields={'frame':request})])]),dict(at_ms=1,event='L.net.frame',fields={'frame':reply},expect_trace=[dict(at_ms=1,emitted=[dict(message='L.neighbor.resolved',fields={'ip':[192,0,2,2],'mac':[2,0,0,0,0,2]}),dict(message='L.ethernet.tx',fields={'frame':ethernet(syn,True)})])])])
  for old_step in old['steps'][1:]:
   step=copy.deepcopy(old_step)
   if old_step.get('event')=='net.packet':step['event']='L.net.frame';step['fields']={'frame':ethernet(old_step['fields']['packet'],False)}
   elif 'event'in old_step:step['event']='T.'+old_step['event']
   converted=[]
   for row in old_step.get('expect_trace',[]):
    out=[]
    for e in row['emitted']:
     out.append(dict(message='L.ethernet.tx',fields={'frame':ethernet(e['fields']['packet'],True)})if e['message']=='ipv4.tx'else dict(message='T.'+e['message'],fields=copy.deepcopy(e['fields'])))
    converted.append(dict(at_ms=row['at_ms'],emitted=out))
   if 'expect_trace'in step:step['expect_trace']=converted
   s['steps'].append(step)
  if 'settle_ms'in old:s['settle_ms']=old['settle_ms']
  need(max([step['at_ms']for step in old['steps']]+[old.get('settle_ms',0)])<60001,'cache expiry outside declared projection')
  s['expect']=dict(state='COMPOSED',variables={'T.'+k:v for k,v in old['expect'].get('variables',{}).items()},timers={'T.'+k:v for k,v in old['expect']['timers'].items()});s['expect']['variables'].update({'L.control':'RESOLVED','T.control':old['expect']['state'],'L.pending_packet':[],'ip_pending_owner':'none'});s['expect']['timers']['L.cache']=60001;scenes.append(s)
 save('frozen-projected-oracles.json',scenes);bindings=dict(source_git='137ad5c3c7d2b3798cc08661f82341b1266536a6',source_oracle_hashes={str(p.relative_to(W)):sha(p)for p in paths.values()},fixture_sha256=sha(O/'frozen-projected-oracles.json'),candidate_model_sha256=sha(M),native_elf_sha256=sha(C/'build/protocol-native'),generation_sha256=sha(C/'generated/generation.json'),compile_sha256=sha(C/'build/compile.json'),cases=len(scenes),network=False,projection='L complete namespace/control lowering, T original input times+all raw literal bytes unchanged; initial TCP egress delayed to ARP1ms, Ethernet wrapping/namespace explicit, extra cache60001; not a general equivalence proof')
 need(bindings['fixture_sha256']=='1494d7445a0f66560232751c5f7c3a2daf604d0bb79dda6cda349157fa1053e0','frozen45 corpus changed');save('bindings.json',bindings);m=load(M);results=[]
 for index,s in enumerate(scenes):
  status(status='running',stage='reference',case=s['id'],index=index+1,total=len(scenes));save(s['id']+'/scenario.json',s);ref=run_scenario(m,s);save(s['id']+'/reference-trace.json',ref.trace)
  if s['id'].startswith('L-'):
   for row in ref.trace:
    need({k:v for k,v in row['before']['variables'].items()if k.startswith('T.')}=={k:v for k,v in row['after']['variables'].items()if k.startswith('T.')},'L transition mutated TCP state')
    need(not any(k.startswith('T.')for k in row['after']['timers']),'L transition activated TCP timer')
  status(status='running',stage='actual_native',case=s['id'],index=index+1,total=len(scenes));native=run(C/'generated',C/'build',O/s['id']/'scenario.json',O/s['id']/'native');need(native['status']=='pass','native mismatch')
  status(status='running',stage='independent_fixed_Z3',case=s['id'],index=index+1,total=len(scenes));formal=crosscheck_trace(m,ref.trace,O/s['id']/'symbolic');need(formal.get('query')=='sat'and formal.get('status')=='match','fixed-input Z3 unresolved or mismatch')
  results.append(dict(id=s['id'],literal_trace='pass',native='pass',fixed_Z3='sat_replay_match',transitions=len(ref.trace)));save('results.json',results)
 need(sha(M)==bindings['candidate_model_sha256']and sha(C/'build/protocol-native')==bindings['native_elf_sha256'],'candidate/native input changed')
 status(status='finite_regression_pass_controller_review_required',stage='finished',cases=len(results),transitions=sum(r['transitions']for r in results),kernel=platform.release(),finished_at=time.time())
except Exception as e:
 status(status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__,error=str(e)[:1800],finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

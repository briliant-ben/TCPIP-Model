from pathlib import Path
import faulthandler,hashlib,json,os,resource,sys,time
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-fixed-trace-diagnostic-20261107-0071';O.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_CPU,(30,35));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));faulthandler.dump_traceback_later(12,repeat=False)
W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';C=P/'candidates/tcp-ir-coupling-envelope-20261107-0067/validation-0002';R=P/'candidates/tcp-coupling-regression-20261107-0068/L-arp-udp-transmit-udp-zero-is-ffff';sys.path.insert(0,str(W))
from protocol_lab.ir import load
from protocol_lab.symbolic import Encoding,encode_trace
start=time.monotonic();cpu=time.process_time();events=[]
def mark(stage,**data):
 events.append(dict(stage=stage,wall_seconds=time.monotonic()-start,cpu_seconds=time.process_time()-cpu,**data));(O/'phase-journal.json').write_text(json.dumps(dict(pid=os.getpid(),solver_called=False,events=events),indent=2)+'\n');print(json.dumps(events[-1]),flush=True)
m=load(C/'candidate-model.json');trace=json.loads((R/'reference-trace.json').read_text());(O/'bindings.json').write_text(json.dumps(dict(model_sha256=hashlib.sha256((C/'candidate-model.json').read_bytes()).hexdigest(),trace_sha256=hashlib.sha256((R/'reference-trace.json').read_bytes()).hexdigest(),symbolic_source_sha256=hashlib.sha256((W/'protocol_lab/symbolic.py').read_bytes()).hexdigest(),scope='encode-only diagnostic, no SAT/UNSAT/UNKNOWN result or recovered missing query claim'),indent=2)+'\n')
original=Encoding.encode_step
def timed(self,index):
 mark('before_encode_step',index=index);v=original(self,index);mark('after_encode_step',index=index);return v
Encoding.encode_step=timed
mark('before_encode_trace',steps=len(trace));e=encode_trace(m,trace);mark('after_encode_trace',assertions=len(e.solver.assertions()));q=e.solver.to_smt2();(O/'new-diagnostic-query.smt2').write_text(q);mark('query_saved_no_solve',query_sha256=hashlib.sha256(q.encode()).hexdigest());faulthandler.cancel_dump_traceback_later()

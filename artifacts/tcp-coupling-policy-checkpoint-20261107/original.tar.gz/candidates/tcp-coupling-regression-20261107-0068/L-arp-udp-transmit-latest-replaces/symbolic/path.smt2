; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x52628 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x52350 (= due_1_T.user due_0_T.user)))
 (let (($x36837 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x52359 (= due_1_L.cache due_0_L.cache)))
 (let (($x75067 (= due_1_L.query 1000)))
 (let (($x52540 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x52539 (= active_1_T.user active_0_T.user)))
 (let (($x89563 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x90327 (= active_1_L.cache active_0_L.cache)))
 (let (($x9958 (= v_1_ip_pending_owner "UDP")))
 (let (($x50311 (= v_1_T.control "CLOSED")))
 (let (($x32985 (= v_1_T.wire_flags 0)))
 (let (($x12801 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x76189 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x41239 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x76310 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x16 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x15866 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x53046 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3232 (= v_1_T.take 0)))
 (let (($x3229 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3230 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x3233 (= v_1_T.snd_wnd 8)))
 (let (($x6663 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x6658 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x83084 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3237 (= v_1_T.local_window 16)))
 (let (($x3238 (= v_1_T.msl_ms 60000)))
 (let (($x3239 (= v_1_T.user_timeout_ms 30000)))
 (let (($x3240 (= v_1_T.retries 0)))
 (let (($x32932 (= v_1_T.rto_ms 1000)))
 (let (($x47719 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x47716 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x47717 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x47720 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x47721 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x47722 (= v_1_T.irs (_ bv0 32))))
 (let (($x47723 (= v_1_T.iss (_ bv1000 32))))
 (let (($x30772 (= v_1_L.control "PENDING")))
 (let (($x59989 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x56660 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x41384 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x36831 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x89306 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x50339 (not v_1_L.rxudp_require_checksum)))
 (let ((?x8754 (seq.unit (_ bv9 8))))
 (let ((?x3197 (seq.++ ?x8754 (seq.++ (seq.unit (_ bv95 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv97 8)))))))
 (let ((?x52313 (seq.unit (_ bv0 8))))
 (let ((?x52938 (seq.unit (_ bv144 8))))
 (let ((?x32764 (seq.unit (_ bv31 8))))
 (let ((?x3334 (seq.unit (_ bv64 8))))
 (let ((?x11143 (seq.unit (_ bv156 8))))
 (let ((?x36789 (seq.++ ?x11143 (seq.++ ?x3334 (seq.++ ?x32764 (seq.++ ?x52938 (seq.++ ?x52313 ?x3197)))))))
 (let ((?x25580 (seq.unit (_ bv2 8))))
 (let ((?x90283 (seq.unit (_ bv192 8))))
 (let ((?x35696 (seq.unit (_ bv1 8))))
 (let ((?x12647 (seq.++ ?x35696 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x25580 ?x36789)))))))
 (let ((?x11211 (seq.unit (_ bv204 8))))
 (let ((?x41379 (seq.unit (_ bv182 8))))
 (let ((?x83034 (seq.++ ?x41379 (seq.++ ?x11211 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 ?x12647)))))))
 (let ((?x60705 (seq.unit (_ bv17 8))))
 (let ((?x32686 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x60705 ?x83034)))))))
 (let ((?x55576 (seq.unit (_ bv29 8))))
 (let ((?x70322 (seq.unit (_ bv69 8))))
 (let ((?x9961 (seq.++ ?x70322 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x55576 (seq.++ ?x52313 ?x32686)))))))
 (let (($x41362 (= v_1_L.pending_packet ?x9961)))
 (let (($x6748 (= v_1_L.ip_checksum 46796)))
 (let (($x87676 (= v_1_L.udp_checksum 24327)))
 (let (($x11198 (= v_1_L.udp_raw_checksum 24327)))
 (let (($x41407 (= v_1_L.ip_length 29)))
 (let (($x53014 (= v_1_L.udp_length 9)))
 (let (($x41231 (= v_1_L.packet ?x9961)))
 (let ((?x91462 (seq.++ ?x25580 (seq.++ ?x35696 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 ?x25580)))))))
 (let ((?x56648 (seq.++ ?x90283 (seq.++ ?x52313 ?x91462))))
 (let ((?x60378 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x60705 (seq.++ ?x41379 (seq.++ ?x11211 ?x56648)))))))
 (let ((?x32768 (seq.++ ?x52313 (seq.++ ?x55576 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x3334 ?x60378)))))))
 (let (($x52591 (= v_1_L.ip_wire (seq.++ ?x70322 (seq.++ ?x52313 ?x32768)))))
 (let ((?x9526 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x60705 (seq.++ ?x52313 (seq.++ ?x52313 ?x56648)))))))
 (let ((?x32979 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x3334 ?x9526)))))
 (let (($x47785 (= v_1_L.ip_zero (seq.++ ?x70322 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x55576 ?x32979)))))))
 (let (($x56597 (= v_1_L.udp_wire ?x36789)))
 (let ((?x56607 (seq.++ ?x25580 (seq.++ ?x25580 (seq.++ ?x52313 (seq.++ ?x60705 (seq.++ ?x52313 ?x8754)))))))
 (let ((?x3200 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x35696 (seq.++ ?x90283 (seq.++ ?x52313 ?x56607)))))))
 (let (($x3134 (= v_1_L.pseudoheader (seq.++ ?x90283 ?x3200))))
 (let ((?x56311 (seq.++ ?x52313 (seq.++ ?x8754 (seq.++ ?x52313 (seq.++ ?x52313 (seq.unit (_ bv97 8))))))))
 (let (($x3520 (= v_1_L.udp_zero (seq.++ ?x11143 (seq.++ ?x3334 (seq.++ ?x32764 (seq.++ ?x52938 ?x56311)))))))
 (let ((?x97457 (seq.unit (_ bv97 8))))
 (let (($x32719 (= v_1_L.payload ?x97457)))
 (let (($x92443 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x89078 (= 0 v_1_L.retry_count)))
 (let (($x77580 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x89591 (= 0 state_1)))
 (let (($x12943 (not active_0_T.time_wait)))
 (let (($x81357 (or $x12943 (not (<= due_0_T.time_wait 0)))))
 (let (($x13018 (not active_0_T.user)))
 (let (($x75516 (or $x13018 (not (<= due_0_T.user 0)))))
 (let (($x41130 (not active_0_T.rtx)))
 (let (($x85709 (or $x41130 (not (<= due_0_T.rtx 0)))))
 (let (($x52318 (not active_0_L.cache)))
 (let (($x77318 (or $x52318 (not (<= due_0_L.cache 0)))))
 (let (($x38319 (not active_0_L.query)))
 (let (($x84705 (or $x38319 (not (<= due_0_L.query 0)))))
 (let (($x3795 (= state_0 0)))
 (and $x3795 (>= 0 now_0) $x84705 $x77318 $x85709 $x75516 $x81357 $x89591 $x77580 $x89078 $x92443 v_1_L.checksums_enabled $x32719 $x3520 $x3134 $x56597 $x47785 $x52591 $x41231 $x53014 $x41407 $x11198 $x87676 $x6748 $x41362 $x50339 $x89306 (= v_1_L.rxudp_disposition "none") $x36831 $x41384 $x56660 $x59989 (= v_1_L.echo_disposition "none") $x30772 $x47723 $x47722 $x47721 $x47720 $x47717 $x47716 $x47719 (= v_1_T.tx_flags "S") $x32932 $x3240 v_1_T.active_open $x3239 $x3238 $x3237 $x83084 $x6658 $x6663 $x3233 $x3230 $x3229 $x3232 $x53046 $x15866 $x16 $x76310 $x41239 $x76189 $x12801 $x32985 (= v_1_T.wire_disposition "none") $x50311 $x9958 active_1_L.query $x90327 $x89563 $x52539 $x52540 $x75067 $x52359 $x36837 $x52350 $x52628)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3718 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x3717 (= due_2_T.user due_1_T.user)))
 (let (($x3716 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x3715 (= due_2_L.cache due_1_L.cache)))
 (let (($x3714 (= due_2_L.query due_1_L.query)))
 (let (($x3713 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x3712 (= active_2_T.user active_1_T.user)))
 (let (($x3711 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x3710 (= active_2_L.cache active_1_L.cache)))
 (let (($x3709 (= active_2_L.query active_1_L.query)))
 (let (($x3708 (= v_2_ip_pending_owner "UDP")))
 (let (($x3707 (= v_2_T.control v_1_T.control)))
 (let (($x3706 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x3705 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x3704 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x3703 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x3702 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x3701 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x3700 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x3699 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x3698 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x3697 (= v_2_T.take v_1_T.take)))
 (let (($x3696 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x3695 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x3694 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x3693 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x3692 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x3691 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x3690 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x3689 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x3688 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x3687 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x3686 (= v_2_T.retries v_1_T.retries)))
 (let (($x3685 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x3684 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x3683 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x3682 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x3681 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x3680 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x3679 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x3678 (= v_2_T.irs v_1_T.irs)))
 (let (($x3677 (= v_2_T.iss v_1_T.iss)))
 (let (($x3676 (= v_2_L.control "PENDING")))
 (let (($x3675 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x3674 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x3673 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x3672 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x3671 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x3670 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x3669 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x3668 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let ((?x41361 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x52313 (seq.unit (_ bv0 8))))
 (let ((?x70883 (seq.++ ?x52313 ?x41361)))
 (let ((?x47774 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x47770 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x47748 (seq.unit (_ bv13 8))))
 (let ((?x52938 (seq.unit (_ bv144 8))))
 (let ((?x30741 (seq.++ ?x52938 (seq.++ ?x52313 (seq.++ ?x47748 (seq.++ ?x47770 (seq.++ ?x47774 ?x70883)))))))
 (let ((?x32764 (seq.unit (_ bv31 8))))
 (let ((?x3334 (seq.unit (_ bv64 8))))
 (let ((?x11143 (seq.unit (_ bv156 8))))
 (let ((?x52320 (seq.++ ?x11143 (seq.++ ?x3334 (seq.++ ?x32764 ?x30741)))))
 (let ((?x25580 (seq.unit (_ bv2 8))))
 (let ((?x90283 (seq.unit (_ bv192 8))))
 (let ((?x35696 (seq.unit (_ bv1 8))))
 (let ((?x26597 (seq.++ ?x35696 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x25580 ?x52320)))))))
 (let ((?x5543 (seq.unit (_ bv200 8))))
 (let ((?x41379 (seq.unit (_ bv182 8))))
 (let ((?x35680 (seq.++ ?x41379 (seq.++ ?x5543 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 ?x26597)))))))
 (let ((?x60705 (seq.unit (_ bv17 8))))
 (let ((?x73020 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x60705 ?x35680)))))))
 (let ((?x3241 (seq.unit (_ bv33 8))))
 (let ((?x70322 (seq.unit (_ bv69 8))))
 (let ((?x3886 (seq.++ ?x70322 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x3241 (seq.++ ?x52313 ?x73020)))))))
 (let (($x12711 (= v_2_L.pending_packet ?x3886)))
 (let (($x6653 (= v_2_L.ip_checksum 46792)))
 (let ((?x58110 (ite v_1_L.checksums_enabled 49271 0)))
 (let (($x25542 (= v_2_L.udp_checksum ?x58110)))
 (let (($x8784 (= v_2_L.udp_raw_checksum 49271)))
 (let (($x6755 (= v_2_L.ip_length 33)))
 (let (($x3594 (= v_2_L.udp_length 13)))
 (let (($x56666 (= v_2_L.packet ?x3886)))
 (let ((?x91462 (seq.++ ?x25580 (seq.++ ?x35696 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 ?x25580)))))))
 (let ((?x56648 (seq.++ ?x90283 (seq.++ ?x52313 ?x91462))))
 (let ((?x25540 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x60705 (seq.++ ?x41379 (seq.++ ?x5543 ?x56648)))))))
 (let ((?x45191 (seq.++ ?x52313 (seq.++ ?x3241 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x3334 ?x25540)))))))
 (let (($x41462 (= v_2_L.ip_wire (seq.++ ?x70322 (seq.++ ?x52313 ?x45191)))))
 (let ((?x9526 (seq.++ ?x52313 (seq.++ ?x3334 (seq.++ ?x60705 (seq.++ ?x52313 (seq.++ ?x52313 ?x56648)))))))
 (let ((?x32979 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x3334 ?x9526)))))
 (let (($x30874 (= v_2_L.ip_zero (seq.++ ?x70322 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x3241 ?x32979)))))))
 (let (($x47806 (= v_2_L.udp_wire ?x52320)))
 (let ((?x47792 (seq.++ ?x25580 (seq.++ ?x25580 (seq.++ ?x52313 (seq.++ ?x60705 (seq.++ ?x52313 ?x47748)))))))
 (let ((?x32978 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x35696 (seq.++ ?x90283 (seq.++ ?x52313 ?x47792)))))))
 (let (($x78442 (= v_2_L.pseudoheader (seq.++ ?x90283 ?x32978))))
 (let ((?x32580 (seq.++ ?x52938 (seq.++ ?x52313 (seq.++ ?x47748 (seq.++ ?x52313 (seq.++ ?x52313 ?x70883)))))))
 (let (($x3353 (= v_2_L.udp_zero (seq.++ ?x11143 (seq.++ ?x3334 (seq.++ ?x32764 ?x32580))))))
 (let (($x68598 (= v_2_L.payload ?x70883)))
 (let (($x3654 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x3653 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x3652 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x3651 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x3650 (= 0 state_2)))
 (let (($x66240 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x13072 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x36821 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x6735 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x3236 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x30772 (= v_1_L.control "PENDING")))
 (let (($x61337 (= state_1 0)))
 (and $x61337 $x30772 $x3236 $x6735 $x36821 $x13072 $x66240 $x3650 $x3651 $x3652 $x3653 $x3654 $x68598 $x3353 $x78442 $x47806 $x30874 $x41462 $x56666 $x3594 $x6755 $x8784 $x25542 $x6653 $x12711 $x3668 $x3669 $x3670 $x3671 $x3672 $x3673 $x3674 $x3675 $x3676 $x3677 $x3678 $x3679 $x3680 $x3681 $x3682 $x3683 $x3684 $x3685 $x3686 $x3687 $x3688 $x3689 $x3690 $x3691 $x3692 $x3693 $x3694 $x3695 $x3696 $x3697 $x3698 $x3699 $x3700 $x3701 $x3702 $x3703 $x3704 $x3705 $x3706 $x3707 $x3708 $x3709 $x3710 $x3711 $x3712 $x3713 $x3714 $x3715 $x3716 $x3717 $x3718))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x30122 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x30121 (= due_3_T.user due_2_T.user)))
 (let (($x30120 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x30118 (= due_3_L.query due_2_L.query)))
 (let (($x30117 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x30116 (= active_3_T.user active_2_T.user)))
 (let (($x30115 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x41189 (not active_3_L.query)))
 (let (($x30112 (= v_3_ip_pending_owner "none")))
 (let (($x30111 (= v_3_T.control v_2_T.control)))
 (let (($x30110 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x30109 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x30108 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x30107 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x30106 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x30105 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x30104 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x30103 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x30102 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x30101 (= v_3_T.take v_2_T.take)))
 (let (($x30100 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x30099 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x30098 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x30097 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x30096 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x30095 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x30094 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x30093 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x30092 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x30091 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x30090 (= v_3_T.retries v_2_T.retries)))
 (let (($x30089 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x30088 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x30087 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x30086 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x30085 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x30084 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x30083 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x30082 (= v_3_T.irs v_2_T.irs)))
 (let (($x30081 (= v_3_T.iss v_2_T.iss)))
 (let (($x30080 (= v_3_L.control "RESOLVED")))
 (let (($x30079 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x30078 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x30077 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x30076 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x30075 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x30074 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x30073 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x30072 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x32562 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x30070 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x30069 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x30068 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x30067 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x30066 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x30065 (= v_3_L.packet v_2_L.packet)))
 (let (($x30064 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x30063 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x30062 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x30061 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x30060 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x30059 (= v_3_L.payload v_2_L.payload)))
 (let (($x30058 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x30057 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x30056 (= 0 v_3_L.retry_count)))
 (let ((?x52313 (seq.unit (_ bv0 8))))
 (let ((?x9922 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.unit (_ bv2 8))))))))
 (let ((?x25580 (seq.unit (_ bv2 8))))
 (let ((?x97810 (seq.++ ?x25580 ?x9922)))
 (let (($x69010 (= v_3_L.peer_mac ?x97810)))
 (let (($x30054 (= 0 state_3)))
 (let (($x40361 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x59641 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x30596 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x63343 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x3861 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let ((?x30011 (seq.len v_2_L.pending_packet)))
 (let (($x30012 (<= 28 ?x30011)))
 (let (($x3676 (= v_2_L.control "PENDING")))
 (let (($x9487 (= state_2 0)))
 (and $x9487 $x3676 $x30012 $x3861 $x63343 $x30596 $x59641 $x40361 $x30054 $x69010 $x30056 $x30057 $x30058 $x30059 $x30060 $x30061 $x30062 $x30063 $x30064 $x30065 $x30066 $x30067 $x30068 $x30069 $x30070 $x32562 $x30072 $x30073 $x30074 $x30075 $x30076 $x30077 $x30078 $x30079 $x30080 $x30081 $x30082 $x30083 $x30084 $x30085 $x30086 $x30087 $x30088 $x30089 $x30090 $x30091 $x30092 $x30093 $x30094 $x30095 $x30096 $x30097 $x30098 $x30099 $x30100 $x30101 $x30102 $x30103 $x30104 $x30105 $x30106 $x30107 $x30108 $x30109 $x30110 $x30111 $x30112 $x41189 active_3_L.cache $x30115 $x30116 $x30117 $x30118 (= due_3_L.cache (+ 2 v_2_L.cache_ttl_ms)) $x30120 $x30121 $x30122))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x97457 (seq.unit (_ bv97 8))))
 (= input_0_L.app.send_data ?x97457)))
(assert
 (= 20 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x41361 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x52313 (seq.unit (_ bv0 8))))
 (let ((?x70883 (seq.++ ?x52313 ?x41361)))
 (= input_1_L.app.send_data ?x70883)))))
(assert
 (= 29 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x90283 (seq.unit (_ bv192 8))))
(let ((?x35722 (seq.++ ?x90283 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x35696 (seq.unit (_ bv1 8))))
(let ((?x52313 (seq.unit (_ bv0 8))))
(let ((?x41356 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x35696 ?x35722)))))))
(let ((?x25580 (seq.unit (_ bv2 8))))
(let ((?x35690 (seq.++ ?x90283 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x25580 (seq.++ ?x25580 ?x41356)))))))
(let ((?x75193 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x25580 ?x35690)))))))
(let ((?x75752 (seq.unit (_ bv4 8))))
(let ((?x52425 (seq.unit (_ bv6 8))))
(let ((?x52621 (seq.++ ?x52425 (seq.++ ?x75752 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x25580 ?x75193)))))))
(let ((?x35704 (seq.unit (_ bv8 8))))
(let ((?x14421 (seq.++ ?x52425 (seq.++ ?x52313 (seq.++ ?x35696 (seq.++ ?x35704 (seq.++ ?x52313 ?x52621)))))))
(let ((?x48616 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x25580 (seq.++ ?x35704 ?x14421)))))))
(let ((?x11127 (seq.++ ?x52313 (seq.++ ?x52313 (seq.++ ?x35696 (seq.++ ?x25580 (seq.++ ?x52313 ?x48616)))))))
(let ((?x41223 (seq.++ ?x25580 (seq.++ ?x52313 (seq.++ ?x52313 ?x11127)))))
(= input_2_L.net.frame_frame ?x41223))))))))))))))))))
(check-sat)

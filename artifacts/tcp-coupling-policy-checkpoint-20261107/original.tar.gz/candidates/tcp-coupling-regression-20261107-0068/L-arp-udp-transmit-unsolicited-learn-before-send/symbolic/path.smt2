; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x55532 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x8400 (= due_1_T.user due_0_T.user)))
 (let (($x90336 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x58960 (= due_1_L.cache 60000)))
 (let (($x8399 (= due_1_L.query due_0_L.query)))
 (let (($x88567 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x12831 (= active_1_T.user active_0_T.user)))
 (let (($x8398 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x59497 (not active_1_L.query)))
 (let (($x37885 (= v_1_T.control "CLOSED")))
 (let (($x13161 (= v_1_T.wire_flags 0)))
 (let (($x48302 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x45071 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x32926 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x98681 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x3864 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x32532 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x33840 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x10542 (= v_1_T.take 0)))
 (let (($x10543 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x10544 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x10545 (= v_1_T.snd_wnd 8)))
 (let (($x87176 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x20261 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x55506 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x10619 (= v_1_T.local_window 16)))
 (let (($x10620 (= v_1_T.msl_ms 60000)))
 (let (($x10621 (= v_1_T.user_timeout_ms 30000)))
 (let (($x10622 (= v_1_T.retries 0)))
 (let (($x52069 (= v_1_T.rto_ms 1000)))
 (let (($x10616 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x36804 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x10617 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x10618 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x10484 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x10482 (= v_1_T.irs (_ bv0 32))))
 (let (($x10483 (= v_1_T.iss (_ bv1000 32))))
 (let (($x2766 (= v_1_L.control "RESOLVED")))
 (let (($x53553 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x10577 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x10576 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x52063 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x52062 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x37716 (not v_1_L.rxudp_require_checksum)))
 (let (($x10572 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x10556 (= v_1_L.ip_checksum 0)))
 (let (($x10557 (= v_1_L.udp_checksum 0)))
 (let (($x13180 (= v_1_L.udp_raw_checksum 0)))
 (let (($x13181 (= v_1_L.ip_length 0)))
 (let (($x13182 (= v_1_L.udp_length 0)))
 (let (($x4823 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x4822 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x13289 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x13288 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x28760 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x28759 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x28757 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x52050 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x8327 (= 0 v_1_L.retry_count)))
 (let ((?x27489 (seq.unit (_ bv0 8))))
 (let ((?x51702 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.unit (_ bv2 8))))))))
 (let ((?x101965 (seq.unit (_ bv2 8))))
 (let ((?x80545 (seq.++ ?x101965 ?x51702)))
 (let (($x52057 (= v_1_L.peer_mac ?x80545)))
 (let (($x71725 (= 0 state_1)))
 (let (($x76242 (not active_0_T.time_wait)))
 (let (($x52056 (or $x76242 (not (<= due_0_T.time_wait 0)))))
 (let (($x55520 (not active_0_T.user)))
 (let (($x13129 (or $x55520 (not (<= due_0_T.user 0)))))
 (let (($x44026 (not active_0_T.rtx)))
 (let (($x13258 (or $x44026 (not (<= due_0_T.rtx 0)))))
 (let (($x56832 (not active_0_L.cache)))
 (let (($x30516 (or $x56832 (not (<= due_0_L.cache 0)))))
 (let (($x53292 (not active_0_L.query)))
 (let (($x4828 (or $x53292 (not (<= due_0_L.query 0)))))
 (let (($x8193 (= state_0 0)))
 (and $x8193 (>= 0 now_0) $x4828 $x30516 $x13258 $x13129 $x52056 $x71725 $x52057 $x8327 $x52050 v_1_L.checksums_enabled $x28757 $x28759 $x28760 $x13288 $x13289 $x4822 $x4823 $x13182 $x13181 $x13180 $x10557 $x10556 $x10572 $x37716 $x52062 (= v_1_L.rxudp_disposition "none") $x52063 $x10576 $x10577 $x53553 (= v_1_L.echo_disposition "none") $x2766 $x10483 $x10482 $x10484 $x10618 $x10617 $x36804 $x10616 (= v_1_T.tx_flags "S") $x52069 $x10622 v_1_T.active_open $x10621 $x10620 $x10619 $x55506 $x20261 $x87176 $x10545 $x10544 $x10543 $x10542 $x33840 $x32532 $x3864 $x98681 $x32926 $x45071 $x48302 $x13161 (= v_1_T.wire_disposition "none") $x37885 (= v_1_ip_pending_owner "none") $x59497 active_1_L.cache $x8398 $x12831 $x88567 $x8399 $x58960 $x90336 $x8400 $x55532))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x37553 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x37552 (= due_2_T.user due_1_T.user)))
 (let (($x37551 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x37550 (= due_2_L.cache due_1_L.cache)))
 (let (($x37549 (= due_2_L.query due_1_L.query)))
 (let (($x37548 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x37547 (= active_2_T.user active_1_T.user)))
 (let (($x37546 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x37545 (= active_2_L.cache active_1_L.cache)))
 (let (($x37544 (= active_2_L.query active_1_L.query)))
 (let (($x37543 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x37542 (= v_2_T.control v_1_T.control)))
 (let (($x37541 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x37540 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x37539 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x37538 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x37537 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x37536 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x37535 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x37534 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x37533 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x37532 (= v_2_T.take v_1_T.take)))
 (let (($x37531 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x37530 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x37529 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x37528 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x37527 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x37526 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x37525 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x37524 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x37523 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x37522 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x37521 (= v_2_T.retries v_1_T.retries)))
 (let (($x37520 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x37519 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x37518 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x37517 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x37516 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x37515 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x37514 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x37513 (= v_2_T.irs v_1_T.irs)))
 (let (($x37512 (= v_2_T.iss v_1_T.iss)))
 (let (($x37511 (= v_2_L.control "RESOLVED")))
 (let (($x37510 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x37509 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x37508 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x37507 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x37506 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x37505 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x37504 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x37503 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x37502 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x66258 (= v_2_L.ip_checksum 46797)))
 (let ((?x11216 (ite v_1_L.checksums_enabled 49161 0)))
 (let (($x87654 (= v_2_L.udp_checksum ?x11216)))
 (let (($x86741 (= v_2_L.udp_raw_checksum 49161)))
 (let (($x87899 (= v_2_L.ip_length 28)))
 (let (($x87898 (= v_2_L.udp_length 8)))
 (let ((?x58263 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x11216))) (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x11216))))))
 (let ((?x27297 (seq.unit (_ bv8 8))))
 (let ((?x27489 (seq.unit (_ bv0 8))))
 (let ((?x59334 (seq.unit (_ bv144 8))))
 (let ((?x101924 (seq.unit (_ bv31 8))))
 (let ((?x103000 (seq.unit (_ bv64 8))))
 (let ((?x23511 (seq.++ ?x103000 (seq.++ ?x101924 (seq.++ ?x59334 (seq.++ ?x27489 (seq.++ ?x27297 ?x58263)))))))
 (let ((?x103002 (seq.unit (_ bv156 8))))
 (let ((?x97350 (seq.++ ?x103002 ?x23511)))
 (let ((?x101965 (seq.unit (_ bv2 8))))
 (let ((?x59200 (seq.unit (_ bv192 8))))
 (let ((?x87416 (seq.unit (_ bv1 8))))
 (let ((?x78717 (seq.++ ?x87416 (seq.++ ?x59200 (seq.++ ?x27489 (seq.++ ?x101965 (seq.++ ?x101965 ?x97350)))))))
 (let ((?x67033 (seq.unit (_ bv205 8))))
 (let ((?x77077 (seq.unit (_ bv182 8))))
 (let ((?x68815 (seq.++ ?x77077 (seq.++ ?x67033 (seq.++ ?x59200 (seq.++ ?x27489 (seq.++ ?x101965 ?x78717)))))))
 (let ((?x66612 (seq.unit (_ bv17 8))))
 (let ((?x89947 (seq.++ ?x27489 (seq.++ ?x103000 (seq.++ ?x27489 (seq.++ ?x103000 (seq.++ ?x66612 ?x68815)))))))
 (let ((?x52614 (seq.unit (_ bv28 8))))
 (let ((?x79542 (seq.unit (_ bv69 8))))
 (let ((?x88410 (seq.++ ?x79542 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x52614 (seq.++ ?x27489 ?x89947)))))))
 (let (($x88411 (= v_2_L.packet ?x88410)))
 (let ((?x10756 (seq.++ ?x101965 (seq.++ ?x87416 (seq.++ ?x59200 (seq.++ ?x27489 (seq.++ ?x101965 ?x101965)))))))
 (let ((?x10513 (seq.++ ?x59200 (seq.++ ?x27489 ?x10756))))
 (let ((?x59983 (seq.++ ?x27489 (seq.++ ?x103000 (seq.++ ?x66612 (seq.++ ?x77077 (seq.++ ?x67033 ?x10513)))))))
 (let ((?x78369 (seq.++ ?x27489 (seq.++ ?x52614 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x103000 ?x59983)))))))
 (let (($x68499 (= v_2_L.ip_wire (seq.++ ?x79542 (seq.++ ?x27489 ?x78369)))))
 (let ((?x88754 (seq.++ ?x27489 (seq.++ ?x103000 (seq.++ ?x66612 (seq.++ ?x27489 (seq.++ ?x27489 ?x10513)))))))
 (let ((?x87731 (seq.++ ?x27489 (seq.++ ?x52614 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x103000 ?x88754)))))))
 (let (($x73811 (= v_2_L.ip_zero (seq.++ ?x79542 (seq.++ ?x27489 ?x87731)))))
 (let (($x69101 (= v_2_L.udp_wire ?x97350)))
 (let ((?x56164 (seq.++ ?x101965 (seq.++ ?x101965 (seq.++ ?x27489 (seq.++ ?x66612 (seq.++ ?x27489 ?x27297)))))))
 (let ((?x25584 (seq.++ ?x27489 (seq.++ ?x101965 (seq.++ ?x87416 (seq.++ ?x59200 (seq.++ ?x27489 ?x56164)))))))
 (let (($x56347 (= v_2_L.pseudoheader (seq.++ ?x59200 ?x25584))))
 (let ((?x13275 (seq.++ ?x101924 (seq.++ ?x59334 (seq.++ ?x27489 (seq.++ ?x27297 (seq.++ ?x27489 ?x27489)))))))
 (let (($x13143 (= v_2_L.udp_zero (seq.++ ?x103002 (seq.++ ?x103000 ?x13275)))))
 (let (($x13158 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.payload)))
 (let (($x37489 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x37488 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x37487 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x37486 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x37485 (= 0 state_2)))
 (let (($x1218 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x13267 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x13263 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x13259 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x59497 (not active_1_L.query)))
 (let (($x10754 (or $x59497 (not (<= due_1_L.query 1)))))
 (let (($x2766 (= v_1_L.control "RESOLVED")))
 (let (($x100289 (= state_1 0)))
 (and $x100289 $x2766 $x10754 $x13259 $x13263 $x13267 $x1218 $x37485 $x37486 $x37487 $x37488 $x37489 $x13158 $x13143 $x56347 $x69101 $x73811 $x68499 $x88411 $x87898 $x87899 $x86741 $x87654 $x66258 $x37502 $x37503 $x37504 $x37505 $x37506 $x37507 $x37508 $x37509 $x37510 $x37511 $x37512 $x37513 $x37514 $x37515 $x37516 $x37517 $x37518 $x37519 $x37520 $x37521 $x37522 $x37523 $x37524 $x37525 $x37526 $x37527 $x37528 $x37529 $x37530 $x37531 $x37532 $x37533 $x37534 $x37535 $x37536 $x37537 $x37538 $x37539 $x37540 $x37541 $x37542 $x37543 $x37544 $x37545 $x37546 $x37547 $x37548 $x37549 $x37550 $x37551 $x37552 $x37553))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x64679 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x64678 (= due_3_T.user due_2_T.user)))
 (let (($x64677 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x64676 (= due_3_L.cache due_2_L.cache)))
 (let (($x64675 (= due_3_L.query due_2_L.query)))
 (let (($x64674 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x64673 (= active_3_T.user active_2_T.user)))
 (let (($x64672 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x64671 (= active_3_L.cache active_2_L.cache)))
 (let (($x64670 (= active_3_L.query active_2_L.query)))
 (let (($x64669 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x64668 (= v_3_T.control v_2_T.control)))
 (let (($x64667 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x64666 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x64665 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x64664 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x64663 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x64662 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x64661 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x64660 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x64659 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x64658 (= v_3_T.take v_2_T.take)))
 (let (($x64657 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x64656 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x64655 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x64654 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x64653 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x64652 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x64651 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x64650 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x64649 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x64648 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x64647 (= v_3_T.retries v_2_T.retries)))
 (let (($x64646 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x64645 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x64644 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x64643 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x64642 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x64641 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x64640 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x96813 (= v_3_T.irs v_2_T.irs)))
 (let (($x96812 (= v_3_T.iss v_2_T.iss)))
 (let (($x64639 (= v_3_L.control "RESOLVED")))
 (let (($x64638 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x64637 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x64636 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x64635 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x64634 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x64633 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x64632 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x64631 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x64630 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x64629 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x64628 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x64627 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x64626 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x64625 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x64624 (= v_3_L.packet v_2_L.packet)))
 (let (($x64623 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x64622 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x64621 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x64620 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x64619 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x64618 (= v_3_L.payload v_2_L.payload)))
 (let (($x64617 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x64616 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x64615 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x64614 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x64613 (= 0 state_3)))
 (let (($x10635 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x13115 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x13205 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x13118 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x10746 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let (($x37511 (= v_2_L.control "RESOLVED")))
 (let (($x10502 (= state_2 0)))
 (and $x10502 $x37511 $x10746 $x13118 $x13205 $x13115 $x10635 $x64613 $x64614 $x64615 $x64616 $x64617 $x64618 $x64619 $x64620 $x64621 $x64622 $x64623 $x64624 $x64625 $x64626 $x64627 $x64628 $x64629 $x64630 $x64631 $x64632 $x64633 $x64634 $x64635 $x64636 $x64637 $x64638 $x64639 $x96812 $x96813 $x64640 $x64641 $x64642 $x64643 $x64644 $x64645 $x64646 $x64647 $x64648 $x64649 $x64650 $x64651 $x64652 $x64653 $x64654 $x64655 $x64656 $x64657 $x64658 $x64659 $x64660 $x64661 $x64662 $x64663 $x64664 $x64665 $x64666 $x64667 $x64668 $x64669 $x64670 $x64671 $x64672 $x64673 $x64674 $x64675 $x64676 $x64677 $x64678 $x64679))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x59200 (seq.unit (_ bv192 8))))
 (let ((?x101323 (seq.++ ?x59200 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x87416 (seq.unit (_ bv1 8))))
 (let ((?x27489 (seq.unit (_ bv0 8))))
 (let ((?x79343 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x87416 ?x101323)))))))
 (let ((?x101965 (seq.unit (_ bv2 8))))
 (let ((?x69778 (seq.++ ?x59200 (seq.++ ?x27489 (seq.++ ?x101965 (seq.++ ?x101965 (seq.++ ?x101965 ?x79343)))))))
 (let ((?x66491 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x101965 ?x69778)))))))
 (let ((?x80157 (seq.unit (_ bv4 8))))
 (let ((?x45173 (seq.unit (_ bv6 8))))
 (let ((?x86445 (seq.++ ?x45173 (seq.++ ?x80157 (seq.++ ?x27489 (seq.++ ?x101965 (seq.++ ?x101965 ?x66491)))))))
 (let ((?x27297 (seq.unit (_ bv8 8))))
 (let ((?x84235 (seq.++ ?x45173 (seq.++ ?x27489 (seq.++ ?x87416 (seq.++ ?x27297 (seq.++ ?x27489 ?x86445)))))))
 (let ((?x66767 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x101965 (seq.++ ?x27297 ?x84235)))))))
 (let ((?x70682 (seq.++ ?x27489 (seq.++ ?x27489 (seq.++ ?x87416 (seq.++ ?x101965 (seq.++ ?x27489 ?x66767)))))))
 (let ((?x78439 (seq.++ ?x101965 (seq.++ ?x27489 (seq.++ ?x27489 ?x70682)))))
 (= input_0_L.net.frame_frame ?x78439))))))))))))))))))
(assert
 (= 22 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_L.app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 2 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x59200 (seq.unit (_ bv192 8))))
(let ((?x71893 (seq.++ ?x59200 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x71893))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.send_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x8701 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x40304 (= due_1_T.user due_0_T.user)))
 (let (($x33610 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x14399 (= due_1_L.cache due_0_L.cache)))
 (let (($x75264 (= due_1_L.query 1000)))
 (let (($x3632 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x14397 (= active_1_T.user active_0_T.user)))
 (let (($x3563 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x40339 (= active_1_L.cache active_0_L.cache)))
 (let (($x56578 (= v_1_ip_pending_owner "UDP")))
 (let (($x5339 (= v_1_T.control "CLOSED")))
 (let (($x9951 (= v_1_T.wire_flags 0)))
 (let (($x85390 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x60320 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x60319 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x85931 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x71086 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x67667 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x67752 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x12967 (= v_1_T.take 0)))
 (let (($x87677 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x78738 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x3820 (= v_1_T.snd_wnd 8)))
 (let (($x67754 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x73103 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x73102 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3530 (= v_1_T.local_window 16)))
 (let (($x31730 (= v_1_T.msl_ms 60000)))
 (let (($x3534 (= v_1_T.user_timeout_ms 30000)))
 (let (($x32569 (= v_1_T.retries 0)))
 (let (($x3609 (= v_1_T.rto_ms 1000)))
 (let (($x3821 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x32819 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3823 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x3819 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x63457 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x92470 (= v_1_T.irs (_ bv0 32))))
 (let (($x92469 (= v_1_T.iss (_ bv1000 32))))
 (let (($x14432 (= v_1_L.control "PENDING")))
 (let (($x74076 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x87394 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x13526 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x76883 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x84359 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x97440 (not v_1_L.rxudp_require_checksum)))
 (let ((?x43446 (seq.unit (_ bv0 8))))
 (let ((?x41368 (seq.++ ?x43446 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
 (let ((?x30745 (seq.unit (_ bv144 8))))
 (let ((?x56333 (seq.unit (_ bv31 8))))
 (let ((?x3633 (seq.unit (_ bv64 8))))
 (let ((?x32994 (seq.unit (_ bv156 8))))
 (let ((?x70657 (seq.++ ?x32994 (seq.++ ?x3633 (seq.++ ?x56333 (seq.++ ?x30745 ?x41368))))))
 (let ((?x14424 (seq.unit (_ bv2 8))))
 (let ((?x14425 (seq.unit (_ bv192 8))))
 (let ((?x38366 (seq.unit (_ bv1 8))))
 (let ((?x80304 (seq.++ ?x38366 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 (seq.++ ?x14424 ?x70657)))))))
 (let ((?x36817 (seq.unit (_ bv205 8))))
 (let ((?x52477 (seq.unit (_ bv182 8))))
 (let ((?x63393 (seq.++ ?x52477 (seq.++ ?x36817 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 ?x80304)))))))
 (let ((?x49903 (seq.unit (_ bv17 8))))
 (let ((?x73523 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x49903 ?x63393)))))))
 (let ((?x6698 (seq.unit (_ bv28 8))))
 (let ((?x3554 (seq.unit (_ bv69 8))))
 (let ((?x88846 (seq.++ ?x3554 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x6698 (seq.++ ?x43446 ?x73523)))))))
 (let (($x73598 (= v_1_L.pending_packet ?x88846)))
 (let (($x71786 (= v_1_L.ip_checksum 46797)))
 (let (($x87823 (= v_1_L.udp_checksum 49161)))
 (let (($x87822 (= v_1_L.udp_raw_checksum 49161)))
 (let (($x88335 (= v_1_L.ip_length 28)))
 (let (($x88334 (= v_1_L.udp_length 8)))
 (let (($x88847 (= v_1_L.packet ?x88846)))
 (let ((?x52528 (seq.++ ?x14424 (seq.++ ?x38366 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 ?x14424)))))))
 (let ((?x11216 (seq.++ ?x14425 (seq.++ ?x43446 ?x52528))))
 (let ((?x71908 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x49903 (seq.++ ?x52477 (seq.++ ?x36817 ?x11216)))))))
 (let ((?x76476 (seq.++ ?x43446 (seq.++ ?x6698 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x3633 ?x71908)))))))
 (let (($x82844 (= v_1_L.ip_wire (seq.++ ?x3554 (seq.++ ?x43446 ?x76476)))))
 (let ((?x53078 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x49903 (seq.++ ?x43446 (seq.++ ?x43446 ?x11216)))))))
 (let ((?x41265 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x3633 ?x53078)))))
 (let (($x41389 (= v_1_L.ip_zero (seq.++ ?x3554 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x6698 ?x41265)))))))
 (let (($x11202 (= v_1_L.udp_wire ?x70657)))
 (let ((?x41250 (seq.++ ?x14424 (seq.++ ?x43446 (seq.++ ?x49903 (seq.++ ?x43446 (seq.unit (_ bv8 8))))))))
 (let ((?x41255 (seq.++ ?x14424 (seq.++ ?x38366 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 ?x41250)))))))
 (let (($x41258 (= v_1_L.pseudoheader (seq.++ ?x14425 (seq.++ ?x43446 ?x41255)))))
 (let ((?x52626 (seq.++ ?x30745 (seq.++ ?x43446 (seq.++ (seq.unit (_ bv8 8)) (seq.++ ?x43446 ?x43446))))))
 (let (($x12916 (= v_1_L.udp_zero (seq.++ ?x32994 (seq.++ ?x3633 (seq.++ ?x56333 ?x52626))))))
 (let (($x52500 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x3607 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x3603 (= 0 v_1_L.retry_count)))
 (let (($x52499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x14395 (= 0 state_1)))
 (let (($x20285 (not active_0_T.time_wait)))
 (let (($x9968 (or $x20285 (not (<= due_0_T.time_wait 0)))))
 (let (($x40118 (not active_0_T.user)))
 (let (($x52624 (or $x40118 (not (<= due_0_T.user 0)))))
 (let (($x3634 (not active_0_T.rtx)))
 (let (($x12989 (or $x3634 (not (<= due_0_T.rtx 0)))))
 (let (($x36837 (not active_0_L.cache)))
 (let (($x52810 (or $x36837 (not (<= due_0_L.cache 0)))))
 (let (($x90327 (not active_0_L.query)))
 (let (($x52627 (or $x90327 (not (<= due_0_L.query 0)))))
 (let (($x14393 (= state_0 0)))
 (and $x14393 (>= 0 now_0) $x52627 $x52810 $x12989 $x52624 $x9968 $x14395 $x52499 $x3603 $x3607 v_1_L.checksums_enabled $x52500 $x12916 $x41258 $x11202 $x41389 $x82844 $x88847 $x88334 $x88335 $x87822 $x87823 $x71786 $x73598 $x97440 $x84359 (= v_1_L.rxudp_disposition "none") $x76883 $x13526 $x87394 $x74076 (= v_1_L.echo_disposition "none") $x14432 $x92469 $x92470 $x63457 $x3819 $x3823 $x32819 $x3821 (= v_1_T.tx_flags "S") $x3609 $x32569 v_1_T.active_open $x3534 $x31730 $x3530 $x73102 $x73103 $x67754 $x3820 $x78738 $x87677 $x12967 $x67752 $x67667 $x71086 $x85931 $x60319 $x60320 $x85390 $x9951 (= v_1_T.wire_disposition "none") $x5339 $x56578 active_1_L.query $x40339 $x3563 $x14397 $x3632 $x75264 $x14399 $x33610 $x40304 $x8701)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3395 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x3394 (= due_2_T.user due_1_T.user)))
 (let (($x3393 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x3391 (= due_2_L.query due_1_L.query)))
 (let (($x3390 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x3389 (= active_2_T.user active_1_T.user)))
 (let (($x3388 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x63657 (not active_2_L.query)))
 (let (($x3385 (= v_2_ip_pending_owner "none")))
 (let (($x3384 (= v_2_T.control v_1_T.control)))
 (let (($x3383 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x3382 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x3381 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x3380 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x3379 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x3378 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x3377 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x3376 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x3375 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x3374 (= v_2_T.take v_1_T.take)))
 (let (($x3373 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x3372 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x3371 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x3370 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x3369 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x3368 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x3367 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x3366 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x3365 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x3364 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x3363 (= v_2_T.retries v_1_T.retries)))
 (let (($x3362 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x3361 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x3360 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x3359 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x3358 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x3357 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x3356 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x3355 (= v_2_T.irs v_1_T.irs)))
 (let (($x3354 (= v_2_T.iss v_1_T.iss)))
 (let (($x3353 (= v_2_L.control "RESOLVED")))
 (let (($x3352 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x3351 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x3350 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x3349 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x3348 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x3347 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x3346 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x3345 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x6690 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x3343 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x3342 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x3341 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x3340 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x3339 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x3338 (= v_2_L.packet v_1_L.packet)))
 (let (($x3337 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x3336 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x3335 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x3334 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x3333 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x3332 (= v_2_L.payload v_1_L.payload)))
 (let (($x3331 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x3330 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x3329 (= 0 v_2_L.retry_count)))
 (let ((?x43446 (seq.unit (_ bv0 8))))
 (let ((?x30765 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.unit (_ bv2 8))))))))
 (let ((?x14424 (seq.unit (_ bv2 8))))
 (let ((?x88634 (seq.++ ?x14424 ?x30765)))
 (let (($x6689 (= v_2_L.peer_mac ?x88634)))
 (let (($x3327 (= 0 state_2)))
 (let (($x6693 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x41369 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x52491 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x41136 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x60705 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x3285 (seq.len v_1_L.pending_packet)))
 (let (($x3286 (<= 28 ?x3285)))
 (let (($x14432 (= v_1_L.control "PENDING")))
 (let (($x32875 (= state_1 0)))
 (and $x32875 $x14432 $x3286 $x60705 $x41136 $x52491 $x41369 $x6693 $x3327 $x6689 $x3329 $x3330 $x3331 $x3332 $x3333 $x3334 $x3335 $x3336 $x3337 $x3338 $x3339 $x3340 $x3341 $x3342 $x3343 $x6690 $x3345 $x3346 $x3347 $x3348 $x3349 $x3350 $x3351 $x3352 $x3353 $x3354 $x3355 $x3356 $x3357 $x3358 $x3359 $x3360 $x3361 $x3362 $x3363 $x3364 $x3365 $x3366 $x3367 $x3368 $x3369 $x3370 $x3371 $x3372 $x3373 $x3374 $x3375 $x3376 $x3377 $x3378 $x3379 $x3380 $x3381 $x3382 $x3383 $x3384 $x3385 $x63657 active_2_L.cache $x3388 $x3389 $x3390 $x3391 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x3393 $x3394 $x3395))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x35742 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x35741 (= due_3_T.user due_2_T.user)))
 (let (($x35740 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x35739 (= due_3_L.cache due_2_L.cache)))
 (let (($x35738 (= due_3_L.query due_2_L.query)))
 (let (($x35737 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x35736 (= active_3_T.user active_2_T.user)))
 (let (($x35735 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x35734 (= active_3_L.cache active_2_L.cache)))
 (let (($x35733 (= active_3_L.query active_2_L.query)))
 (let (($x35732 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x35731 (= v_3_T.control v_2_T.control)))
 (let (($x35730 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x35729 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x35728 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x35727 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x35726 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x35725 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x35724 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x35723 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x35722 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x35721 (= v_3_T.take v_2_T.take)))
 (let (($x35720 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x35719 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x35718 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x35717 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x35716 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x35715 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x35714 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x35713 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x35712 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x35711 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x35710 (= v_3_T.retries v_2_T.retries)))
 (let (($x35709 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x35708 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x35707 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x35706 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x35705 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x35704 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x35703 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x35702 (= v_3_T.irs v_2_T.irs)))
 (let (($x35701 (= v_3_T.iss v_2_T.iss)))
 (let (($x35700 (= v_3_L.control "RESOLVED")))
 (let (($x35699 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x35698 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x35697 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x35696 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x35695 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x35694 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x35693 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x35692 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x35691 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x80175 (= v_3_L.ip_checksum 46792)))
 (let ((?x41129 (ite v_2_L.checksums_enabled 49271 0)))
 (let (($x60366 (= v_3_L.udp_checksum ?x41129)))
 (let (($x77268 (= v_3_L.udp_raw_checksum 49271)))
 (let (($x84422 (= v_3_L.ip_length 33)))
 (let (($x45192 (= v_3_L.udp_length 13)))
 (let ((?x80243 (seq.unit (_ bv128 8))))
 (let ((?x67003 (seq.++ ?x80243 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x43446 (seq.unit (_ bv0 8))))
 (let ((?x76736 (seq.++ ?x43446 ?x67003)))
 (let ((?x6665 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x41129))) (seq.++ (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x41129))) ?x76736))))
 (let ((?x91360 (seq.unit (_ bv13 8))))
 (let ((?x30745 (seq.unit (_ bv144 8))))
 (let ((?x56333 (seq.unit (_ bv31 8))))
 (let ((?x3633 (seq.unit (_ bv64 8))))
 (let ((?x41142 (seq.++ ?x3633 (seq.++ ?x56333 (seq.++ ?x30745 (seq.++ ?x43446 (seq.++ ?x91360 ?x6665)))))))
 (let ((?x32994 (seq.unit (_ bv156 8))))
 (let ((?x41143 (seq.++ ?x32994 ?x41142)))
 (let ((?x14424 (seq.unit (_ bv2 8))))
 (let ((?x14425 (seq.unit (_ bv192 8))))
 (let ((?x38366 (seq.unit (_ bv1 8))))
 (let ((?x45060 (seq.++ ?x38366 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 (seq.++ ?x14424 ?x41143)))))))
 (let ((?x85190 (seq.unit (_ bv200 8))))
 (let ((?x52477 (seq.unit (_ bv182 8))))
 (let ((?x45055 (seq.++ ?x52477 (seq.++ ?x85190 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 ?x45060)))))))
 (let ((?x49903 (seq.unit (_ bv17 8))))
 (let ((?x45049 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x49903 ?x45055)))))))
 (let ((?x41330 (seq.unit (_ bv33 8))))
 (let ((?x3554 (seq.unit (_ bv69 8))))
 (let ((?x61332 (seq.++ ?x3554 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x41330 (seq.++ ?x43446 ?x45049)))))))
 (let (($x46815 (= v_3_L.packet ?x61332)))
 (let ((?x52528 (seq.++ ?x14424 (seq.++ ?x38366 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 ?x14424)))))))
 (let ((?x11216 (seq.++ ?x14425 (seq.++ ?x43446 ?x52528))))
 (let ((?x45103 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x49903 (seq.++ ?x52477 (seq.++ ?x85190 ?x11216)))))))
 (let ((?x33017 (seq.++ ?x43446 (seq.++ ?x41330 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x3633 ?x45103)))))))
 (let (($x48618 (= v_3_L.ip_wire (seq.++ ?x3554 (seq.++ ?x43446 ?x33017)))))
 (let ((?x53078 (seq.++ ?x43446 (seq.++ ?x3633 (seq.++ ?x49903 (seq.++ ?x43446 (seq.++ ?x43446 ?x11216)))))))
 (let ((?x41265 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x3633 ?x53078)))))
 (let (($x86754 (= v_3_L.ip_zero (seq.++ ?x3554 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x41330 ?x41265)))))))
 (let (($x52466 (= v_3_L.udp_wire ?x41143)))
 (let ((?x36835 (seq.++ ?x14424 (seq.++ ?x14424 (seq.++ ?x43446 (seq.++ ?x49903 (seq.++ ?x43446 ?x91360)))))))
 (let ((?x41419 (seq.++ ?x43446 (seq.++ ?x14424 (seq.++ ?x38366 (seq.++ ?x14425 (seq.++ ?x43446 ?x36835)))))))
 (let (($x41171 (= v_3_L.pseudoheader (seq.++ ?x14425 ?x41419))))
 (let ((?x88597 (seq.++ ?x30745 (seq.++ ?x43446 (seq.++ ?x91360 (seq.++ ?x43446 (seq.++ ?x43446 ?x76736)))))))
 (let (($x90283 (= v_3_L.udp_zero (seq.++ ?x32994 (seq.++ ?x3633 (seq.++ ?x56333 ?x88597))))))
 (let (($x32889 (= v_3_L.payload ?x76736)))
 (let (($x35669 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x35668 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x35663 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x35662 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x35661 (= 0 state_3)))
 (let (($x36805 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 11)))))
 (let (($x9962 (or (not active_2_T.user) (not (<= due_2_T.user 11)))))
 (let (($x41349 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 11)))))
 (let (($x41337 (or (not active_2_L.cache) (not (<= due_2_L.cache 11)))))
 (let (($x63657 (not active_2_L.query)))
 (let (($x41192 (or $x63657 (not (<= due_2_L.query 11)))))
 (let (($x3353 (= v_2_L.control "RESOLVED")))
 (let (($x6735 (= state_2 0)))
 (and $x6735 $x3353 $x41192 $x41337 $x41349 $x9962 $x36805 $x35661 $x35662 $x35663 $x35668 $x35669 $x32889 $x90283 $x41171 $x52466 $x86754 $x48618 $x46815 $x45192 $x84422 $x77268 $x60366 $x80175 $x35691 $x35692 $x35693 $x35694 $x35695 $x35696 $x35697 $x35698 $x35699 $x35700 $x35701 $x35702 $x35703 $x35704 $x35705 $x35706 $x35707 $x35708 $x35709 $x35710 $x35711 $x35712 $x35713 $x35714 $x35715 $x35716 $x35717 $x35718 $x35719 $x35720 $x35721 $x35722 $x35723 $x35724 $x35725 $x35726 $x35727 $x35728 $x35729 $x35730 $x35731 $x35732 $x35733 $x35734 $x35735 $x35736 $x35737 $x35738 $x35739 $x35740 $x35741 $x35742)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (= input_0_L.app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x14425 (seq.unit (_ bv192 8))))
 (let ((?x45167 (seq.++ ?x14425 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x38366 (seq.unit (_ bv1 8))))
 (let ((?x43446 (seq.unit (_ bv0 8))))
 (let ((?x88097 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x38366 ?x45167)))))))
 (let ((?x14424 (seq.unit (_ bv2 8))))
 (let ((?x83633 (seq.++ ?x14425 (seq.++ ?x43446 (seq.++ ?x14424 (seq.++ ?x14424 (seq.++ ?x14424 ?x88097)))))))
 (let ((?x86354 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x14424 ?x83633)))))))
 (let ((?x53927 (seq.unit (_ bv4 8))))
 (let ((?x26773 (seq.unit (_ bv6 8))))
 (let ((?x73905 (seq.++ ?x26773 (seq.++ ?x53927 (seq.++ ?x43446 (seq.++ ?x14424 (seq.++ ?x14424 ?x86354)))))))
 (let ((?x11197 (seq.unit (_ bv8 8))))
 (let ((?x71878 (seq.++ ?x26773 (seq.++ ?x43446 (seq.++ ?x38366 (seq.++ ?x11197 (seq.++ ?x43446 ?x73905)))))))
 (let ((?x79689 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x14424 (seq.++ ?x11197 ?x71878)))))))
 (let ((?x59744 (seq.++ ?x43446 (seq.++ ?x43446 (seq.++ ?x38366 (seq.++ ?x14424 (seq.++ ?x43446 ?x79689)))))))
 (let ((?x72533 (seq.++ ?x14424 (seq.++ ?x43446 (seq.++ ?x43446 ?x59744)))))
 (= input_1_L.net.frame_frame ?x72533))))))))))))))))))
(assert
 (= 22 choice_2))
(assert
 (= 11 now_3))
(assert
 (let ((?x80243 (seq.unit (_ bv128 8))))
(let ((?x67003 (seq.++ ?x80243 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x43446 (seq.unit (_ bv0 8))))
(let ((?x76736 (seq.++ ?x43446 ?x67003)))
(= input_2_L.app.send_data ?x76736))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x51701 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x12992 (= due_1_T.user due_0_T.user)))
 (let (($x63775 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x51700 (= due_1_L.cache due_0_L.cache)))
 (let (($x3629 (= due_1_L.query 1000)))
 (let (($x336 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x51699 (= active_1_T.user active_0_T.user)))
 (let (($x53078 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x358 (= active_1_L.cache active_0_L.cache)))
 (let (($x33127 (= v_1_T.control "CLOSED")))
 (let (($x52771 (= v_1_T.wire_flags 0)))
 (let (($x3628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x3627 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x3626 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x3625 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x13052 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x3624 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x3623 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3599 (= v_1_T.take 0)))
 (let (($x3600 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3602 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x8699 (= v_1_T.snd_wnd 8)))
 (let (($x91097 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x25232 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x8994 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x68751 (= v_1_T.local_window 16)))
 (let (($x3534 (= v_1_T.msl_ms 60000)))
 (let (($x31730 (= v_1_T.user_timeout_ms 30000)))
 (let (($x3530 (= v_1_T.retries 0)))
 (let (($x3531 (= v_1_T.rto_ms 1000)))
 (let (($x3536 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x3537 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3542 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x3543 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x3548 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x3549 (= v_1_T.irs (_ bv0 32))))
 (let (($x3550 (= v_1_T.iss (_ bv1000 32))))
 (let (($x7121 (= v_1_L.control "PENDING")))
 (let (($x63747 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x32620 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63194 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x3622 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x3620 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x12553 (not v_1_L.rxudp_require_checksum)))
 (let (($x3621 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x3565 (= v_1_L.ip_checksum 0)))
 (let (($x3568 (= v_1_L.udp_checksum 0)))
 (let (($x3571 (= v_1_L.udp_raw_checksum 0)))
 (let (($x3572 (= v_1_L.ip_length 0)))
 (let (($x3576 (= v_1_L.udp_length 0)))
 (let (($x3618 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x3619 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x3617 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x3615 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x3614 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x3613 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x3616 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x56990 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x51664 (= 0 v_1_L.retry_count)))
 (let (($x3610 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x13000 (= 0 state_1)))
 (let (($x12991 (not active_0_T.time_wait)))
 (let (($x3608 (or $x12991 (not (<= due_0_T.time_wait 0)))))
 (let (($x2708 (not active_0_T.user)))
 (let (($x3606 (or $x2708 (not (<= due_0_T.user 0)))))
 (let (($x32208 (not active_0_T.rtx)))
 (let (($x3593 (or $x32208 (not (<= due_0_T.rtx 0)))))
 (let (($x12645 (not active_0_L.cache)))
 (let (($x3594 (or $x12645 (not (<= due_0_L.cache 0)))))
 (let (($x52968 (not active_0_L.query)))
 (let (($x3584 (or $x52968 (not (<= due_0_L.query 0)))))
 (let (($x53180 (= state_0 0)))
 (and $x53180 (>= 0 now_0) $x3584 $x3594 $x3593 $x3606 $x3608 $x13000 $x3610 $x51664 $x56990 v_1_L.checksums_enabled $x3616 $x3613 $x3614 $x3615 $x3617 $x3619 $x3618 $x3576 $x3572 $x3571 $x3568 $x3565 $x3621 $x12553 $x3620 (= v_1_L.rxudp_disposition "none") $x3622 $x63194 $x32620 $x63747 (= v_1_L.echo_disposition "none") $x7121 $x3550 $x3549 $x3548 $x3543 $x3542 $x3537 $x3536 (= v_1_T.tx_flags "S") $x3531 $x3530 v_1_T.active_open $x31730 $x3534 $x68751 $x8994 $x25232 $x91097 $x8699 $x3602 $x3600 $x3599 $x3623 $x3624 $x13052 $x3625 $x3626 $x3627 $x3628 $x52771 (= v_1_T.wire_disposition "none") $x33127 (= v_1_ip_pending_owner "none") active_1_L.query $x358 $x53078 $x51699 $x336 $x3629 $x51700 $x63775 $x12992 $x51701))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x32928 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x32927 (= due_2_T.user due_1_T.user)))
 (let (($x7179 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x32962 (= due_2_L.query due_1_L.query)))
 (let (($x32961 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x32737 (= active_2_T.user active_1_T.user)))
 (let (($x32736 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x8739 (not active_2_L.query)))
 (let (($x32934 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x32933 (= v_2_T.control v_1_T.control)))
 (let (($x32655 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x32654 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x32926 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x32925 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x32639 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x12655 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x52821 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x12900 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x32707 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x32706 (= v_2_T.take v_1_T.take)))
 (let (($x32966 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x32965 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x32590 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x32589 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x52915 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x63167 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x32804 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x32803 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x5549 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x8759 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x63645 (= v_2_T.retries v_1_T.retries)))
 (let (($x12604 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x32641 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x32640 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32701 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32700 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32790 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x32667 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x32666 (= v_2_T.irs v_1_T.irs)))
 (let (($x12677 (= v_2_T.iss v_1_T.iss)))
 (let (($x13049 (= v_2_L.control "RESOLVED")))
 (let (($x32912 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x32911 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x32944 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x32943 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x32818 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x32817 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32715 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32714 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x32705 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x32704 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x32852 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x32851 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x32820 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x32819 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x13013 (= v_2_L.packet v_1_L.packet)))
 (let (($x5562 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x8971 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x84797 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x32824 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32823 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x32968 (= v_2_L.payload v_1_L.payload)))
 (let (($x32967 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x32749 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x32748 (= 0 v_2_L.retry_count)))
 (let ((?x51659 (seq.unit (_ bv0 8))))
 (let ((?x84656 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.unit (_ bv3 8))))))))
 (let ((?x12827 (seq.unit (_ bv2 8))))
 (let (($x53076 (= v_2_L.peer_mac (seq.++ ?x12827 ?x84656))))
 (let (($x32815 (= 0 state_2)))
 (let (($x52780 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x3641 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x53089 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x32597 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x62607 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x32585 (seq.len v_1_L.pending_packet)))
 (let (($x32801 (= 0 ?x32585)))
 (let (($x7121 (= v_1_L.control "PENDING")))
 (let (($x74453 (= state_1 0)))
 (and $x74453 $x7121 $x32801 $x62607 $x32597 $x53089 $x3641 $x52780 $x32815 $x53076 $x32748 $x32749 $x32967 $x32968 $x32823 $x32824 $x84797 $x8971 $x5562 $x13013 $x32819 $x32820 $x32851 $x32852 $x32704 $x32705 $x32714 $x32715 $x32817 $x32818 $x32943 $x32944 $x32911 $x32912 $x13049 $x12677 $x32666 $x32667 $x32790 $x32700 $x32701 $x32640 $x32641 $x12604 $x63645 $x8759 $x5549 $x32803 $x32804 $x63167 $x52915 $x32589 $x32590 $x32965 $x32966 $x32706 $x32707 $x12900 $x52821 $x12655 $x32639 $x32925 $x32926 $x32654 $x32655 $x32933 $x32934 $x8739 active_2_L.cache $x32736 $x32737 $x32961 $x32962 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x7179 $x32927 $x32928)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x52660 (seq.unit (_ bv192 8))))
 (let ((?x12790 (seq.++ ?x52660 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x12790))))
(assert
 (= 28 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x52660 (seq.unit (_ bv192 8))))
(let ((?x12795 (seq.++ ?x52660 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x51659 (seq.unit (_ bv0 8))))
(let ((?x49910 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 ?x12795)))))))
(let ((?x12827 (seq.unit (_ bv2 8))))
(let ((?x49915 (seq.++ ?x52660 (seq.++ ?x51659 (seq.++ ?x12827 (seq.++ ?x12827 (seq.++ ?x51659 ?x49910)))))))
(let ((?x49905 (seq.unit (_ bv3 8))))
(let ((?x49920 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x49905 ?x49915)))))))
(let ((?x12614 (seq.unit (_ bv1 8))))
(let ((?x7189 (seq.unit (_ bv4 8))))
(let ((?x8812 (seq.unit (_ bv6 8))))
(let ((?x49925 (seq.++ ?x8812 (seq.++ ?x7189 (seq.++ ?x51659 (seq.++ ?x12614 (seq.++ ?x12827 ?x49920)))))))
(let ((?x12874 (seq.unit (_ bv8 8))))
(let ((?x49930 (seq.++ ?x8812 (seq.++ ?x51659 (seq.++ ?x12614 (seq.++ ?x12874 (seq.++ ?x51659 ?x49925)))))))
(let ((?x49935 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x51659 (seq.++ ?x49905 (seq.++ ?x12874 ?x49930)))))))
(let ((?x60696 (seq.unit (_ bv255 8))))
(let ((?x49940 (seq.++ ?x60696 (seq.++ ?x60696 (seq.++ ?x60696 (seq.++ ?x12827 (seq.++ ?x51659 ?x49935)))))))
(let ((?x49943 (seq.++ ?x60696 (seq.++ ?x60696 (seq.++ ?x60696 ?x49940)))))
(= input_1_L.net.frame_frame ?x49943))))))))))))))))))))
(check-sat)

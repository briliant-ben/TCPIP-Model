; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x62333 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x24835 (= due_1_T.user due_0_T.user)))
 (let (($x92960 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x62332 (= due_1_L.cache due_0_L.cache)))
 (let (($x93885 (= due_1_L.query due_0_L.query)))
 (let (($x92959 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x62331 (= active_1_T.user active_0_T.user)))
 (let (($x63478 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x92958 (= active_1_L.cache active_0_L.cache)))
 (let (($x62334 (= active_1_L.query active_0_L.query)))
 (let (($x11319 (= v_1_T.control "CLOSED")))
 (let (($x12565 (= v_1_T.wire_flags 0)))
 (let (($x52868 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x52867 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x52866 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x52865 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x52864 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52863 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x52862 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x12578 (= v_1_T.take 0)))
 (let (($x12579 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x12580 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x12581 (= v_1_T.snd_wnd 8)))
 (let (($x52861 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x52860 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x52859 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x34887 (= v_1_T.local_window 16)))
 (let (($x53886 (= v_1_T.msl_ms 60000)))
 (let (($x60706 (= v_1_T.user_timeout_ms 30000)))
 (let (($x97372 (= v_1_T.retries 0)))
 (let (($x53887 (= v_1_T.rto_ms 1000)))
 (let (($x62604 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x53888 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x60707 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x1741 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x53889 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x2422 (= v_1_T.irs (_ bv0 32))))
 (let (($x26886 (= v_1_T.iss (_ bv1000 32))))
 (let (($x31774 (= v_1_L.control "EMPTY")))
 (let (($x52858 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x52857 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x52856 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x52855 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x91124 (= v_1_L.rxudp_disposition "deliver")))
 (let (($x52854 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x10965 (not v_1_L.rxudp_require_checksum)))
 (let (($x52851 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x12588 (= v_1_L.ip_checksum 0)))
 (let (($x12582 (= v_1_L.udp_checksum 0)))
 (let (($x12583 (= v_1_L.udp_raw_checksum 0)))
 (let (($x12584 (= v_1_L.ip_length 0)))
 (let (($x12597 (= v_1_L.udp_length 0)))
 (let (($x52850 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x52849 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x52848 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x52847 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x52846 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x52845 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x52844 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x12617 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x12612 (= v_1_L.retry_count 0)))
 (let (($x52843 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x290 (= 0 state_1)))
 (let (($x53923 (not active_0_T.time_wait)))
 (let (($x52842 (or $x53923 (not (<= due_0_T.time_wait 0)))))
 (let (($x26807 (not active_0_T.user)))
 (let (($x52839 (or $x26807 (not (<= due_0_T.user 0)))))
 (let (($x98629 (not active_0_T.rtx)))
 (let (($x52836 (or $x98629 (not (<= due_0_T.rtx 0)))))
 (let (($x53921 (not active_0_L.cache)))
 (let (($x52833 (or $x53921 (not (<= due_0_L.cache 0)))))
 (let (($x62495 (not active_0_L.query)))
 (let (($x52830 (or $x62495 (not (<= due_0_L.query 0)))))
 (let (($x125489 (= state_0 0)))
 (and $x125489 (>= 0 now_0) $x52830 $x52833 $x52836 $x52839 $x52842 $x290 $x52843 $x12612 $x12617 v_1_L.checksums_enabled $x52844 $x52845 $x52846 $x52847 $x52848 $x52849 $x52850 $x12597 $x12584 $x12583 $x12582 $x12588 $x52851 $x10965 $x52854 $x91124 $x52855 $x52856 $x52857 $x52858 (= v_1_L.echo_disposition "none") $x31774 $x26886 $x2422 $x53889 $x1741 $x60707 $x53888 $x62604 (= v_1_T.tx_flags "S") $x53887 $x97372 v_1_T.active_open $x60706 $x53886 $x34887 $x52859 $x52860 $x52861 $x12581 $x12580 $x12579 $x12578 $x52862 $x52863 $x52864 $x52865 $x52866 $x52867 $x52868 $x12565 (= v_1_T.wire_disposition "none") $x11319 (= v_1_ip_pending_owner "none") $x62334 $x92958 $x63478 $x62331 $x92959 $x93885 $x62332 $x92960 $x24835 $x62333))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x11285 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x11284 (= due_2_T.user due_1_T.user)))
 (let (($x11283 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x11282 (= due_2_L.cache due_1_L.cache)))
 (let (($x11281 (= due_2_L.query due_1_L.query)))
 (let (($x11280 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x11279 (= active_2_T.user active_1_T.user)))
 (let (($x11278 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x11277 (= active_2_L.cache active_1_L.cache)))
 (let (($x11276 (= active_2_L.query active_1_L.query)))
 (let (($x11275 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x11274 (= v_2_T.control v_1_T.control)))
 (let (($x11273 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x11272 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x11271 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x11270 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x11269 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x11268 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x11267 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x11266 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x11265 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x11264 (= v_2_T.take v_1_T.take)))
 (let (($x11263 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x11262 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x11261 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x11260 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x11259 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x11258 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x11257 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x11256 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x11255 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x11254 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x11253 (= v_2_T.retries v_1_T.retries)))
 (let (($x11252 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x11251 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x11250 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x11249 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x11248 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x11247 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x11246 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x11245 (= v_2_T.irs v_1_T.irs)))
 (let (($x11244 (= v_2_T.iss v_1_T.iss)))
 (let (($x11243 (= v_2_L.control "EMPTY")))
 (let (($x11242 (= v_2_L.echo_disposition "reply")))
 (let ((?x53934 (seq.unit (_ bv192 8))))
 (let ((?x53936 (seq.++ ?x53934 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x31880 (seq.unit (_ bv1 8))))
 (let ((?x53935 (seq.unit (_ bv2 8))))
 (let ((?x62570 (seq.unit (_ bv0 8))))
 (let ((?x11133 (seq.++ ?x62570 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x31880 ?x53936)))))))
 (let ((?x91517 (seq.unit (_ bv64 8))))
 (let ((?x11138 (seq.++ ?x91517 (seq.++ ?x62570 (seq.++ ?x91517 (seq.++ ?x31880 (seq.++ ?x62570 ?x11133)))))))
 (let ((?x11140 (seq.++ ?x62570 (seq.++ ?x62570 ?x11138))))
 (let ((?x52648 (seq.unit (_ bv28 8))))
 (let ((?x55378 (seq.unit (_ bv69 8))))
 (let (($x53123 (= v_2_L.echo_ip_zero (seq.++ ?x55378 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x52648 ?x11140)))))))
 (let ((?x52725 (seq.unit (_ bv18 8))))
 (let ((?x63081 (seq.++ ?x52725 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x52723 (seq.unit (_ bv254 8))))
 (let ((?x53063 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ (seq.unit (_ bv65 8)) (seq.++ ?x52723 ?x63081))))))
 (let (($x53122 (= v_2_L.echo_icmp_wire ?x53063)))
 (let (($x53121 (= v_2_L.echo_icmp_zero (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x62570 ?x63081)))))))
 (let ((?x53104 (seq.++ ?x31880 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x53935 ?x53063)))))))
 (let ((?x52719 (seq.unit (_ bv221 8))))
 (let ((?x52650 (seq.unit (_ bv182 8))))
 (let ((?x53109 (seq.++ ?x52650 (seq.++ ?x52719 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 ?x53104)))))))
 (let ((?x53114 (seq.++ ?x62570 (seq.++ ?x91517 (seq.++ ?x62570 (seq.++ ?x91517 (seq.++ ?x31880 ?x53109)))))))
 (let ((?x53119 (seq.++ ?x55378 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x52648 (seq.++ ?x62570 ?x53114)))))))
 (let (($x53120 (= v_2_L.echo_reply ?x53119)))
 (let (($x11237 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x11236 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x11235 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x11234 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x11233 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x11232 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x11231 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x11230 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x11229 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x11228 (= v_2_L.packet v_1_L.packet)))
 (let (($x11227 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x11226 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x11225 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x11224 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x11223 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x11222 (= v_2_L.payload v_1_L.payload)))
 (let (($x11221 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x11220 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x11219 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x11218 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x11217 (= 0 state_2)))
 (let (($x12783 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x12901 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x62550 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x53914 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x12809 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x31774 (= v_1_L.control "EMPTY")))
 (let (($x32179 (= state_1 0)))
 (and $x32179 $x31774 $x12809 $x53914 $x62550 $x12901 $x12783 $x11217 $x11218 $x11219 $x11220 $x11221 $x11222 $x11223 $x11224 $x11225 $x11226 $x11227 $x11228 $x11229 $x11230 $x11231 $x11232 $x11233 $x11234 $x11235 $x11236 $x11237 $x53120 $x53121 $x53122 $x53123 $x11242 $x11243 $x11244 $x11245 $x11246 $x11247 $x11248 $x11249 $x11250 $x11251 $x11252 $x11253 $x11254 $x11255 $x11256 $x11257 $x11258 $x11259 $x11260 $x11261 $x11262 $x11263 $x11264 $x11265 $x11266 $x11267 $x11268 $x11269 $x11270 $x11271 $x11272 $x11273 $x11274 $x11275 $x11276 $x11277 $x11278 $x11279 $x11280 $x11281 $x11282 $x11283 $x11284 $x11285)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 35 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x52656 (seq.unit (_ bv165 8))))
 (let ((?x52661 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 ?x52656)))))))
 (let ((?x52666 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 ?x52661)))))))
 (let ((?x52671 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 (seq.++ ?x52656 ?x52666)))))))
 (let ((?x53934 (seq.unit (_ bv192 8))))
 (let ((?x52675 (seq.++ ?x53934 (seq.++ (seq.unit (_ bv9 8)) (seq.++ ?x52656 (seq.++ ?x52656 ?x52671))))))
 (let ((?x14374 (seq.unit (_ bv8 8))))
 (let ((?x62570 (seq.unit (_ bv0 8))))
 (let ((?x91517 (seq.unit (_ bv64 8))))
 (let ((?x19837 (seq.unit (_ bv156 8))))
 (let ((?x19835 (seq.unit (_ bv144 8))))
 (let ((?x52680 (seq.++ ?x19835 (seq.++ ?x19837 (seq.++ ?x91517 (seq.++ ?x62570 (seq.++ ?x14374 ?x52675)))))))
 (let ((?x19833 (seq.unit (_ bv31 8))))
 (let ((?x31880 (seq.unit (_ bv1 8))))
 (let ((?x53935 (seq.unit (_ bv2 8))))
 (let ((?x52685 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x31880 (seq.++ ?x19833 ?x52680)))))))
 (let ((?x52652 (seq.unit (_ bv205 8))))
 (let ((?x52690 (seq.++ ?x52652 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x53935 ?x52685)))))))
 (let ((?x52650 (seq.unit (_ bv182 8))))
 (let ((?x91519 (seq.unit (_ bv17 8))))
 (let ((?x52695 (seq.++ ?x91517 (seq.++ ?x62570 (seq.++ ?x91517 (seq.++ ?x91519 (seq.++ ?x52650 ?x52690)))))))
 (let ((?x52648 (seq.unit (_ bv28 8))))
 (let ((?x52700 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x52648 (seq.++ ?x62570 (seq.++ ?x62570 ?x52695)))))))
 (let ((?x55378 (seq.unit (_ bv69 8))))
 (let ((?x52705 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x14374 (seq.++ ?x62570 (seq.++ ?x55378 ?x52700)))))))
 (let ((?x52710 (seq.++ ?x31880 (seq.++ ?x53935 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x62570 ?x52705)))))))
 (let ((?x52715 (seq.++ ?x53935 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x62570 ?x52710)))))))
 (= input_0_L.net.frame_frame ?x52715)))))))))))))))))))))))))))))
(assert
 (= 54 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x52731 (seq.unit (_ bv126 8))))
(let ((?x52736 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 ?x52731)))))))
(let ((?x52741 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 ?x52736)))))))
(let ((?x52746 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 (seq.++ ?x52731 ?x52741)))))))
(let ((?x52652 (seq.unit (_ bv205 8))))
(let ((?x52729 (seq.unit (_ bv171 8))))
(let ((?x52727 (seq.unit (_ bv52 8))))
(let ((?x52751 (seq.++ ?x52727 (seq.++ ?x52729 (seq.++ ?x52652 (seq.++ ?x52731 (seq.++ ?x52731 ?x52746)))))))
(let ((?x52725 (seq.unit (_ bv18 8))))
(let ((?x52723 (seq.unit (_ bv254 8))))
(let ((?x52721 (seq.unit (_ bv57 8))))
(let ((?x62570 (seq.unit (_ bv0 8))))
(let ((?x14374 (seq.unit (_ bv8 8))))
(let ((?x52756 (seq.++ ?x14374 (seq.++ ?x62570 (seq.++ ?x52721 (seq.++ ?x52723 (seq.++ ?x52725 ?x52751)))))))
(let ((?x31880 (seq.unit (_ bv1 8))))
(let ((?x53935 (seq.unit (_ bv2 8))))
(let ((?x53934 (seq.unit (_ bv192 8))))
(let ((?x52761 (seq.++ ?x53935 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x31880 ?x52756)))))))
(let ((?x52719 (seq.unit (_ bv221 8))))
(let ((?x52650 (seq.unit (_ bv182 8))))
(let ((?x52766 (seq.++ ?x52650 (seq.++ ?x52719 (seq.++ ?x53934 (seq.++ ?x62570 (seq.++ ?x53935 ?x52761)))))))
(let ((?x91517 (seq.unit (_ bv64 8))))
(let ((?x52771 (seq.++ ?x62570 (seq.++ ?x91517 (seq.++ ?x62570 (seq.++ ?x91517 (seq.++ ?x31880 ?x52766)))))))
(let ((?x52648 (seq.unit (_ bv28 8))))
(let ((?x55378 (seq.unit (_ bv69 8))))
(let ((?x52776 (seq.++ ?x55378 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x52648 (seq.++ ?x62570 ?x52771)))))))
(let ((?x52781 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x53935 (seq.++ ?x14374 (seq.++ ?x62570 ?x52776)))))))
(let ((?x52786 (seq.++ ?x62570 (seq.++ ?x31880 (seq.++ ?x53935 (seq.++ ?x62570 (seq.++ ?x62570 ?x52781)))))))
(let ((?x52790 (seq.++ ?x53935 (seq.++ ?x62570 (seq.++ ?x62570 (seq.++ ?x62570 ?x52786))))))
(= input_1_L.net.frame_frame ?x52790)))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x26648 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x92437 (= due_1_T.user due_0_T.user)))
 (let (($x32554 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x30441 (= due_1_L.cache 60000)))
 (let (($x92439 (= due_1_L.query due_0_L.query)))
 (let (($x56619 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x52881 (= active_1_T.user active_0_T.user)))
 (let (($x50290 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x2619 (not active_1_L.query)))
 (let (($x26068 (= v_1_T.control "CLOSED")))
 (let (($x56155 (= v_1_T.wire_flags 0)))
 (let (($x33762 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x63423 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x32153 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x30575 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x91190 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x48579 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x33000 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x56160 (= v_1_T.take 0)))
 (let (($x56157 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x56158 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x61338 (= v_1_T.snd_wnd 8)))
 (let (($x3545 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x48584 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x48586 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3868 (= v_1_T.local_window 16)))
 (let (($x2480 (= v_1_T.msl_ms 60000)))
 (let (($x3865 (= v_1_T.user_timeout_ms 30000)))
 (let (($x52836 (= v_1_T.retries 0)))
 (let (($x95179 (= v_1_T.rto_ms 1000)))
 (let (($x50116 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x55591 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x32559 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x55592 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x3870 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x12990 (= v_1_T.irs (_ bv0 32))))
 (let (($x95180 (= v_1_T.iss (_ bv1000 32))))
 (let (($x30899 (= v_1_L.control "RESOLVED")))
 (let (($x48594 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x55530 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x48602 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x53195 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x48601 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x25898 (not v_1_L.rxudp_require_checksum)))
 (let (($x53576 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x46833 (= v_1_L.ip_checksum 0)))
 (let (($x46831 (= v_1_L.udp_checksum 0)))
 (let (($x46834 (= v_1_L.udp_raw_checksum 0)))
 (let (($x46835 (= v_1_L.ip_length 0)))
 (let (($x46841 (= v_1_L.udp_length 0)))
 (let (($x48600 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x48596 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x53196 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x48603 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x49978 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x53087 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x52913 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x46849 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x30884 (= 0 v_1_L.retry_count)))
 (let ((?x48625 (seq.unit (_ bv0 8))))
 (let ((?x32613 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.unit (_ bv2 8))))))))
 (let ((?x48626 (seq.unit (_ bv2 8))))
 (let ((?x51638 (seq.++ ?x48626 ?x32613)))
 (let (($x56268 (= v_1_L.peer_mac ?x51638)))
 (let (($x30883 (= 0 state_1)))
 (let (($x3537 (not active_0_T.time_wait)))
 (let (($x3585 (or $x3537 (not (<= due_0_T.time_wait 0)))))
 (let (($x33018 (not active_0_T.user)))
 (let (($x30597 (or $x33018 (not (<= due_0_T.user 0)))))
 (let (($x51134 (not active_0_T.rtx)))
 (let (($x56313 (or $x51134 (not (<= due_0_T.rtx 0)))))
 (let (($x32654 (not active_0_L.cache)))
 (let (($x56136 (or $x32654 (not (<= due_0_L.cache 0)))))
 (let (($x49913 (not active_0_L.query)))
 (let (($x56093 (or $x49913 (not (<= due_0_L.query 0)))))
 (let (($x80624 (= state_0 0)))
 (and $x80624 (>= 0 now_0) $x56093 $x56136 $x56313 $x30597 $x3585 $x30883 $x56268 $x30884 $x46849 v_1_L.checksums_enabled $x52913 $x53087 $x49978 $x48603 $x53196 $x48596 $x48600 $x46841 $x46835 $x46834 $x46831 $x46833 $x53576 $x25898 $x48601 (= v_1_L.rxudp_disposition "none") $x53195 $x48602 $x55530 $x48594 (= v_1_L.echo_disposition "none") $x30899 $x95180 $x12990 $x3870 $x55592 $x32559 $x55591 $x50116 (= v_1_T.tx_flags "S") $x95179 $x52836 v_1_T.active_open $x3865 $x2480 $x3868 $x48586 $x48584 $x3545 $x61338 $x56158 $x56157 $x56160 $x33000 $x48579 $x91190 $x30575 $x32153 $x63423 $x33762 $x56155 (= v_1_T.wire_disposition "none") $x26068 (= v_1_ip_pending_owner "none") $x2619 active_1_L.cache $x50290 $x52881 $x56619 $x92439 $x30441 $x32554 $x92437 $x26648))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x25657 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x25656 (= due_2_T.user due_1_T.user)))
 (let (($x25655 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x25654 (= due_2_L.cache due_1_L.cache)))
 (let (($x25653 (= due_2_L.query due_1_L.query)))
 (let (($x25652 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x25651 (= active_2_T.user active_1_T.user)))
 (let (($x25650 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x46844 (not active_2_L.cache)))
 (let (($x25648 (= active_2_L.query active_1_L.query)))
 (let (($x25647 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x25646 (= v_2_T.control v_1_T.control)))
 (let (($x25645 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x25644 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x25643 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x25642 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x25641 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x25640 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x25639 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x25638 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x25637 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x25636 (= v_2_T.take v_1_T.take)))
 (let (($x25635 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x25634 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x25633 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x25632 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x25631 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x25630 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x25629 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x25628 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x25627 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x25626 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x25625 (= v_2_T.retries v_1_T.retries)))
 (let (($x25624 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x25623 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x25622 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x25621 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x25620 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x25619 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x25618 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x25617 (= v_2_T.irs v_1_T.irs)))
 (let (($x25616 (= v_2_T.iss v_1_T.iss)))
 (let (($x25615 (= v_2_L.control "EMPTY")))
 (let (($x25614 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x25613 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x25612 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x25611 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x25610 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x25609 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x25608 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x25607 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x25606 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x25605 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x25604 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x25603 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x25602 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x25601 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x25600 (= v_2_L.packet v_1_L.packet)))
 (let (($x25599 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x25598 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x25597 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x25596 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x25595 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x25594 (= v_2_L.payload v_1_L.payload)))
 (let (($x25593 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x25592 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x25591 (= 0 v_2_L.retry_count)))
 (let (($x46843 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.peer_mac)))
 (let (($x25589 (= 0 state_2)))
 (let (($x30899 (= v_1_L.control "RESOLVED")))
 (let (($x56172 (= state_1 0)))
 (and $x56172 $x30899 active_1_L.cache (= 60000 due_1_L.cache) (or (not active_1_L.query) (<= due_1_L.cache due_1_L.query)) (or (not active_1_T.rtx) (<= due_1_L.cache due_1_T.rtx)) (or (not active_1_T.user) (<= due_1_L.cache due_1_T.user)) (or (not active_1_T.time_wait) (<= due_1_L.cache due_1_T.time_wait)) $x25589 $x46843 $x25591 $x25592 $x25593 $x25594 $x25595 $x25596 $x25597 $x25598 $x25599 $x25600 $x25601 $x25602 $x25603 $x25604 $x25605 $x25606 $x25607 $x25608 $x25609 $x25610 $x25611 $x25612 $x25613 $x25614 $x25615 $x25616 $x25617 $x25618 $x25619 $x25620 $x25621 $x25622 $x25623 $x25624 $x25625 $x25626 $x25627 $x25628 $x25629 $x25630 $x25631 $x25632 $x25633 $x25634 $x25635 $x25636 $x25637 $x25638 $x25639 $x25640 $x25641 $x25642 $x25643 $x25644 $x25645 $x25646 $x25647 $x25648 $x46844 $x25650 $x25651 $x25652 $x25653 $x25654 $x25655 $x25656 $x25657)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x45191 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x45190 (= due_3_T.user due_2_T.user)))
 (let (($x45189 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x45188 (= due_3_L.cache due_2_L.cache)))
 (let (($x46848 (= due_3_L.query 61000)))
 (let (($x45186 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x45185 (= active_3_T.user active_2_T.user)))
 (let (($x45184 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x45183 (= active_3_L.cache active_2_L.cache)))
 (let (($x45181 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x45180 (= v_3_T.control v_2_T.control)))
 (let (($x45179 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x45178 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x45177 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x45176 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x45175 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x45174 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x45173 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x45172 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x45171 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x45170 (= v_3_T.take v_2_T.take)))
 (let (($x45169 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x45168 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x45167 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x45166 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x45165 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x45164 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x45163 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x45162 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x45161 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x45160 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x45159 (= v_3_T.retries v_2_T.retries)))
 (let (($x45158 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x45157 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x45156 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x45155 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x45154 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x45153 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x45152 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x45151 (= v_3_T.irs v_2_T.irs)))
 (let (($x45150 (= v_3_T.iss v_2_T.iss)))
 (let (($x45149 (= v_3_L.control "PENDING")))
 (let (($x45148 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x45147 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x45146 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x45145 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x45144 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x45143 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x45142 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x45141 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x45140 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x45139 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x45138 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x45137 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x45136 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x45135 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x45134 (= v_3_L.packet v_2_L.packet)))
 (let (($x45133 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x45132 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x45131 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x45130 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x45129 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x45128 (= v_3_L.payload v_2_L.payload)))
 (let (($x45127 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x45126 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x45125 (= 0 v_3_L.retry_count)))
 (let (($x45124 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x45123 (= 0 state_3)))
 (let (($x46846 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 60000)))))
 (let (($x46858 (or (not active_2_T.user) (not (<= due_2_T.user 60000)))))
 (let (($x46866 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 60000)))))
 (let (($x46844 (not active_2_L.cache)))
 (let (($x46870 (or $x46844 (not (<= due_2_L.cache 60000)))))
 (let (($x56114 (or (not active_2_L.query) (not (<= due_2_L.query 60000)))))
 (let (($x25615 (= v_2_L.control "EMPTY")))
 (let (($x61358 (= state_2 0)))
 (and $x61358 $x25615 $x56114 $x46870 $x46866 $x46858 $x46846 $x45123 $x45124 $x45125 $x45126 $x45127 $x45128 $x45129 $x45130 $x45131 $x45132 $x45133 $x45134 $x45135 $x45136 $x45137 $x45138 $x45139 $x45140 $x45141 $x45142 $x45143 $x45144 $x45145 $x45146 $x45147 $x45148 $x45149 $x45150 $x45151 $x45152 $x45153 $x45154 $x45155 $x45156 $x45157 $x45158 $x45159 $x45160 $x45161 $x45162 $x45163 $x45164 $x45165 $x45166 $x45167 $x45168 $x45169 $x45170 $x45171 $x45172 $x45173 $x45174 $x45175 $x45176 $x45177 $x45178 $x45179 $x45180 $x45181 active_3_L.query $x45183 $x45184 $x45185 $x45186 $x46848 $x45188 $x45189 $x45190 $x45191))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x32982 (seq.unit (_ bv192 8))))
 (let ((?x3810 (seq.++ ?x32982 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x30761 (seq.unit (_ bv1 8))))
 (let ((?x48625 (seq.unit (_ bv0 8))))
 (let ((?x88353 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x30761 ?x3810)))))))
 (let ((?x48626 (seq.unit (_ bv2 8))))
 (let ((?x77474 (seq.++ ?x32982 (seq.++ ?x48625 (seq.++ ?x48626 (seq.++ ?x48626 (seq.++ ?x48626 ?x88353)))))))
 (let ((?x74825 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48626 ?x77474)))))))
 (let ((?x50202 (seq.unit (_ bv4 8))))
 (let ((?x55520 (seq.unit (_ bv6 8))))
 (let ((?x66824 (seq.++ ?x55520 (seq.++ ?x50202 (seq.++ ?x48625 (seq.++ ?x48626 (seq.++ ?x48626 ?x74825)))))))
 (let ((?x32619 (seq.unit (_ bv8 8))))
 (let ((?x87069 (seq.++ ?x55520 (seq.++ ?x48625 (seq.++ ?x30761 (seq.++ ?x32619 (seq.++ ?x48625 ?x66824)))))))
 (let ((?x77038 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x48626 (seq.++ ?x32619 ?x87069)))))))
 (let ((?x80570 (seq.++ ?x48625 (seq.++ ?x48625 (seq.++ ?x30761 (seq.++ ?x48626 (seq.++ ?x48625 ?x77038)))))))
 (let ((?x89360 (seq.++ ?x48626 (seq.++ ?x48625 (seq.++ ?x48625 ?x80570)))))
 (= input_0_L.net.frame_frame ?x89360))))))))))))))))))
(assert
 (= 4 choice_1))
(assert
 (= 60000 now_2))
(assert
 (= 0 choice_2))
(assert
 (= 60000 now_3))
(assert
 (let ((?x32982 (seq.unit (_ bv192 8))))
(let ((?x52819 (seq.++ ?x32982 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x52819))))
(check-sat)

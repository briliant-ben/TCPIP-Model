; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_T.time_wait () Int)
(declare-fun due_4_T.user () Int)
(declare-fun due_4_T.rtx () Int)
(declare-fun due_4_L.cache () Int)
(declare-fun due_4_L.query () Int)
(declare-fun active_4_T.time_wait () Bool)
(declare-fun active_4_T.user () Bool)
(declare-fun active_4_T.rtx () Bool)
(declare-fun active_4_L.cache () Bool)
(declare-fun active_4_L.query () Bool)
(declare-fun v_4_ip_pending_owner () String)
(declare-fun v_4_T.control () String)
(declare-fun v_4_T.wire_disposition () String)
(declare-fun v_4_T.wire_flags () Int)
(declare-fun v_4_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_4_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_4_T.take () Int)
(declare-fun v_4_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_4_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_4_T.snd_wnd () Int)
(declare-fun v_4_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_T.local_window () Int)
(declare-fun v_4_T.msl_ms () Int)
(declare-fun v_4_T.user_timeout_ms () Int)
(declare-fun v_4_T.active_open () Bool)
(declare-fun v_4_T.retries () Int)
(declare-fun v_4_T.rto_ms () Int)
(declare-fun v_4_T.tx_flags () String)
(declare-fun v_4_T.tx_ack () (_ BitVec 32))
(declare-fun v_4_T.tx_seq () (_ BitVec 32))
(declare-fun v_4_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_4_T.snd_nxt () (_ BitVec 32))
(declare-fun v_4_T.snd_una () (_ BitVec 32))
(declare-fun v_4_T.irs () (_ BitVec 32))
(declare-fun v_4_T.iss () (_ BitVec 32))
(declare-fun v_4_L.control () String)
(declare-fun v_4_L.echo_disposition () String)
(declare-fun v_4_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_4_L.rxudp_disposition () String)
(declare-fun v_4_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_L.rxudp_require_checksum () Bool)
(declare-fun v_4_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_L.ip_checksum () Int)
(declare-fun v_4_L.udp_checksum () Int)
(declare-fun v_4_L.udp_raw_checksum () Int)
(declare-fun v_4_L.ip_length () Int)
(declare-fun v_4_L.udp_length () Int)
(declare-fun v_4_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_4_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_4_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_4_L.checksums_enabled () Bool)
(declare-fun v_4_L.cache_ttl_ms () Int)
(declare-fun v_4_L.retry_count () Int)
(declare-fun v_4_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x49936 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x53194 (= due_1_T.user due_0_T.user)))
 (let (($x56648 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x56644 (= due_1_L.cache due_0_L.cache)))
 (let (($x92463 (= due_1_L.query 1000)))
 (let (($x3606 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x49935 (= active_1_T.user active_0_T.user)))
 (let (($x56645 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x5549 (= active_1_L.cache active_0_L.cache)))
 (let (($x31339 (= v_1_T.control "CLOSED")))
 (let (($x92443 (= v_1_T.wire_flags 0)))
 (let (($x49912 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x49920 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x49922 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x53181 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x49929 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x49930 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x125505 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x56588 (= v_1_T.take 0)))
 (let (($x56589 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x56590 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x56591 (= v_1_T.snd_wnd 8)))
 (let (($x91300 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x56299 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x56303 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x33806 (= v_1_T.local_window 16)))
 (let (($x33702 (= v_1_T.msl_ms 60000)))
 (let (($x2575 (= v_1_T.user_timeout_ms 30000)))
 (let (($x2497 (= v_1_T.retries 0)))
 (let (($x2626 (= v_1_T.rto_ms 1000)))
 (let (($x56594 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x56595 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x56596 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x56592 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x56593 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x56355 (= v_1_T.irs (_ bv0 32))))
 (let (($x13435 (= v_1_T.iss (_ bv1000 32))))
 (let (($x95202 (= v_1_L.control "PENDING")))
 (let (($x92464 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x92462 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x92460 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x92457 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x92459 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x31170 (not v_1_L.rxudp_require_checksum)))
 (let (($x92458 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x56608 (= v_1_L.ip_checksum 0)))
 (let (($x56609 (= v_1_L.udp_checksum 0)))
 (let (($x56604 (= v_1_L.udp_raw_checksum 0)))
 (let (($x56607 (= v_1_L.ip_length 0)))
 (let (($x56610 (= v_1_L.udp_length 0)))
 (let (($x92451 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x92448 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x92450 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x92449 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x92447 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x92446 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x80437 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x312 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x26648 (= 0 v_1_L.retry_count)))
 (let (($x92437 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x32554 (= 0 state_1)))
 (let (($x50290 (not active_0_T.time_wait)))
 (let (($x92440 (or $x50290 (not (<= due_0_T.time_wait 0)))))
 (let (($x52960 (not active_0_T.user)))
 (let (($x67987 (or $x52960 (not (<= due_0_T.user 0)))))
 (let (($x50216 (not active_0_T.rtx)))
 (let (($x56832 (or $x50216 (not (<= due_0_T.rtx 0)))))
 (let (($x53076 (not active_0_L.cache)))
 (let (($x56348 (or $x53076 (not (<= due_0_L.cache 0)))))
 (let (($x91372 (not active_0_L.query)))
 (let (($x56602 (or $x91372 (not (<= due_0_L.query 0)))))
 (let (($x95181 (= state_0 0)))
 (and $x95181 (>= 0 now_0) $x56602 $x56348 $x56832 $x67987 $x92440 $x32554 $x92437 $x26648 $x312 v_1_L.checksums_enabled $x80437 $x92446 $x92447 $x92449 $x92450 $x92448 $x92451 $x56610 $x56607 $x56604 $x56609 $x56608 $x92458 $x31170 $x92459 (= v_1_L.rxudp_disposition "none") $x92457 $x92460 $x92462 $x92464 (= v_1_L.echo_disposition "none") $x95202 $x13435 $x56355 $x56593 $x56592 $x56596 $x56595 $x56594 (= v_1_T.tx_flags "S") $x2626 $x2497 v_1_T.active_open $x2575 $x33702 $x33806 $x56303 $x56299 $x91300 $x56591 $x56590 $x56589 $x56588 $x125505 $x49930 $x49929 $x53181 $x49922 $x49920 $x49912 $x92443 (= v_1_T.wire_disposition "none") $x31339 (= v_1_ip_pending_owner "none") active_1_L.query $x5549 $x56645 $x49935 $x3606 $x92463 $x56644 $x56648 $x53194 $x49936))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x30903 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x30902 (= due_2_T.user due_1_T.user)))
 (let (($x30901 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x30900 (= due_2_L.cache due_1_L.cache)))
 (let (($x30899 (= due_2_L.query due_1_L.query)))
 (let (($x30898 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x30897 (= active_2_T.user active_1_T.user)))
 (let (($x30896 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x30895 (= active_2_L.cache active_1_L.cache)))
 (let (($x30894 (= active_2_L.query active_1_L.query)))
 (let (($x30893 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x30892 (= v_2_T.control v_1_T.control)))
 (let (($x30891 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x30890 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x30889 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x30888 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x30887 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x30886 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x30885 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x30884 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x30883 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x30882 (= v_2_T.take v_1_T.take)))
 (let (($x30881 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x30880 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x30879 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x30878 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x30877 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x30876 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x30875 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x30874 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x30873 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x30872 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x30871 (= v_2_T.retries v_1_T.retries)))
 (let (($x30870 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x30869 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x30868 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x30867 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x30866 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x30865 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x30864 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x30863 (= v_2_T.irs v_1_T.irs)))
 (let (($x30862 (= v_2_T.iss v_1_T.iss)))
 (let (($x30861 (= v_2_L.control "PENDING")))
 (let (($x30860 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x30859 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x30783 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x30782 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x30781 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x30780 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x30779 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x30778 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x30777 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x30776 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x30775 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x30774 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x30773 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x30772 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x30771 (= v_2_L.packet v_1_L.packet)))
 (let (($x30770 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x30769 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x30768 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x30767 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x30766 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x30765 (= v_2_L.payload v_1_L.payload)))
 (let (($x30764 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x30763 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x30762 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x30761 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x30760 (= 0 state_2)))
 (let (($x92455 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x92456 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x56270 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x49924 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x56611 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let (($x95202 (= v_1_L.control "PENDING")))
 (let (($x56605 (= state_1 0)))
 (and $x56605 $x95202 $x56611 $x49924 $x56270 $x92456 $x92455 $x30760 $x30761 $x30762 $x30763 $x30764 $x30765 $x30766 $x30767 $x30768 $x30769 $x30770 $x30771 $x30772 $x30773 $x30774 $x30775 $x30776 $x30777 $x30778 $x30779 $x30780 $x30781 $x30782 $x30783 $x30859 $x30860 $x30861 $x30862 $x30863 $x30864 $x30865 $x30866 $x30867 $x30868 $x30869 $x30870 $x30871 $x30872 $x30873 $x30874 $x30875 $x30876 $x30877 $x30878 $x30879 $x30880 $x30881 $x30882 $x30883 $x30884 $x30885 $x30886 $x30887 $x30888 $x30889 $x30890 $x30891 $x30892 $x30893 $x30894 $x30895 $x30896 $x30897 $x30898 $x30899 $x30900 $x30901 $x30902 $x30903))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x48647 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x48646 (= due_3_T.user due_2_T.user)))
 (let (($x48645 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x48644 (= due_3_L.cache due_2_L.cache)))
 (let (($x63621 (= due_3_L.query 2000)))
 (let (($x48642 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x48641 (= active_3_T.user active_2_T.user)))
 (let (($x48640 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x48639 (= active_3_L.cache active_2_L.cache)))
 (let (($x48637 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x48636 (= v_3_T.control v_2_T.control)))
 (let (($x48635 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x48634 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x48633 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x48632 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x48631 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x48630 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x48629 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x48628 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x48627 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x48626 (= v_3_T.take v_2_T.take)))
 (let (($x48625 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x48624 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x48623 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x48622 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x48621 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x48620 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x48619 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x48618 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x48617 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x48616 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x48615 (= v_3_T.retries v_2_T.retries)))
 (let (($x48614 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x48613 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x48612 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x48611 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x48610 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x48609 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x48608 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x48607 (= v_3_T.irs v_2_T.irs)))
 (let (($x48606 (= v_3_T.iss v_2_T.iss)))
 (let (($x48605 (= v_3_L.control "PENDING")))
 (let (($x48604 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x48603 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x48602 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x48601 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x48600 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x48599 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x48598 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x48597 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x48596 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x48595 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x48594 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x48593 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x48592 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x48591 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x48590 (= v_3_L.packet v_2_L.packet)))
 (let (($x48589 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x48588 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x48587 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x48586 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x48585 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x48584 (= v_3_L.payload v_2_L.payload)))
 (let (($x48583 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x48582 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x48581 (= 1 v_3_L.retry_count)))
 (let (($x48580 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x48579 (= 0 state_3)))
 (let (($x48563 (= 0 v_2_L.retry_count)))
 (let (($x30861 (= v_2_L.control "PENDING")))
 (let (($x33741 (= state_2 0)))
 (and $x33741 $x30861 $x48563 active_2_L.query (= 1000 due_2_L.query) (or (not active_2_L.cache) (not (<= due_2_L.cache due_2_L.query))) (or (not active_2_T.rtx) (<= due_2_L.query due_2_T.rtx)) (or (not active_2_T.user) (<= due_2_L.query due_2_T.user)) (or (not active_2_T.time_wait) (<= due_2_L.query due_2_T.time_wait)) $x48579 $x48580 $x48581 $x48582 $x48583 $x48584 $x48585 $x48586 $x48587 $x48588 $x48589 $x48590 $x48591 $x48592 $x48593 $x48594 $x48595 $x48596 $x48597 $x48598 $x48599 $x48600 $x48601 $x48602 $x48603 $x48604 $x48605 $x48606 $x48607 $x48608 $x48609 $x48610 $x48611 $x48612 $x48613 $x48614 $x48615 $x48616 $x48617 $x48618 $x48619 $x48620 $x48621 $x48622 $x48623 $x48624 $x48625 $x48626 $x48627 $x48628 $x48629 $x48630 $x48631 $x48632 $x48633 $x48634 $x48635 $x48636 $x48637 active_3_L.query $x48639 $x48640 $x48641 $x48642 $x63621 $x48644 $x48645 $x48646 $x48647)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x55531 (= due_4_T.time_wait due_3_T.time_wait)))
 (let (($x51707 (= due_4_T.user due_3_T.user)))
 (let (($x12910 (= due_4_T.rtx due_3_T.rtx)))
 (let (($x52824 (= due_4_L.cache due_3_L.cache)))
 (let (($x12990 (= due_4_L.query due_3_L.query)))
 (let (($x55592 (= active_4_T.time_wait active_3_T.time_wait)))
 (let (($x55591 (= active_4_T.user active_3_T.user)))
 (let (($x8727 (= active_4_T.rtx active_3_T.rtx)))
 (let (($x52836 (= active_4_L.cache active_3_L.cache)))
 (let (($x2480 (not active_4_L.query)))
 (let (($x51710 (= v_4_ip_pending_owner v_3_ip_pending_owner)))
 (let (($x5553 (= v_4_T.control v_3_T.control)))
 (let (($x53230 (= v_4_T.wire_disposition v_3_T.wire_disposition)))
 (let (($x83077 (= v_4_T.wire_flags v_3_T.wire_flags)))
 (let (($x53088 (= v_4_T.wire_packet v_3_T.wire_packet)))
 (let (($x53087 (= v_4_T.wire_ip_zero v_3_T.wire_ip_zero)))
 (let (($x3585 (= v_4_T.wire_tcp v_3_T.wire_tcp)))
 (let (($x55579 (= v_4_T.wire_pseudo v_3_T.wire_pseudo)))
 (let (($x32706 (= v_4_T.wire_tcp_zero v_3_T.wire_tcp_zero)))
 (let (($x53240 (= v_4_T.wire_data v_3_T.wire_data)))
 (let (($x53241 (= v_4_T.rx_chunk v_3_T.rx_chunk)))
 (let (($x5559 (= v_4_T.take v_3_T.take)))
 (let (($x32704 (= v_4_T.snd_wl2 v_3_T.snd_wl2)))
 (let (($x91447 (= v_4_T.snd_wl1 v_3_T.snd_wl1)))
 (let (($x95208 (= v_4_T.snd_wnd v_3_T.snd_wnd)))
 (let (($x95146 (= v_4_T.rcv_buf v_3_T.rcv_buf)))
 (let (($x91177 (= v_4_T.rtx_buf v_3_T.rtx_buf)))
 (let (($x13072 (= v_4_T.snd_buf v_3_T.snd_buf)))
 (let (($x91323 (= v_4_T.local_window v_3_T.local_window)))
 (let (($x91322 (= v_4_T.msl_ms v_3_T.msl_ms)))
 (let (($x91463 (= v_4_T.user_timeout_ms v_3_T.user_timeout_ms)))
 (let (($x5491 (= v_4_T.active_open v_3_T.active_open)))
 (let (($x91287 (= v_4_T.retries v_3_T.retries)))
 (let (($x91286 (= v_4_T.rto_ms v_3_T.rto_ms)))
 (let (($x53293 (= v_4_T.tx_flags v_3_T.tx_flags)))
 (let (($x12752 (= v_4_T.tx_ack v_3_T.tx_ack)))
 (let (($x91359 (= v_4_T.tx_seq v_3_T.tx_seq)))
 (let (($x91254 (= v_4_T.rcv_nxt v_3_T.rcv_nxt)))
 (let (($x91435 (= v_4_T.snd_nxt v_3_T.snd_nxt)))
 (let (($x91406 (= v_4_T.snd_una v_3_T.snd_una)))
 (let (($x3795 (= v_4_T.irs v_3_T.irs)))
 (let (($x3796 (= v_4_T.iss v_3_T.iss)))
 (let (($x13029 (= v_4_L.control "EMPTY")))
 (let (($x125447 (= v_4_L.echo_disposition v_3_L.echo_disposition)))
 (let (($x130 (= v_4_L.echo_ip_zero v_3_L.echo_ip_zero)))
 (let (($x91342 (= v_4_L.echo_icmp_wire v_3_L.echo_icmp_wire)))
 (let (($x55594 (= v_4_L.echo_icmp_zero v_3_L.echo_icmp_zero)))
 (let (($x55593 (= v_4_L.echo_reply v_3_L.echo_reply)))
 (let (($x91103 (= v_4_L.rxudp_disposition v_3_L.rxudp_disposition)))
 (let (($x55354 (= v_4_L.rxudp_payload v_3_L.rxudp_payload)))
 (let (($x5554 (= v_4_L.rxudp_require_checksum v_3_L.rxudp_require_checksum)))
 (let (($x91408 (= v_4_L.pending_packet v_3_L.pending_packet)))
 (let (($x12816 (= v_4_L.ip_checksum v_3_L.ip_checksum)))
 (let (($x8725 (= v_4_L.udp_checksum v_3_L.udp_checksum)))
 (let (($x12745 (= v_4_L.udp_raw_checksum v_3_L.udp_raw_checksum)))
 (let (($x91258 (= v_4_L.ip_length v_3_L.ip_length)))
 (let (($x55459 (= v_4_L.udp_length v_3_L.udp_length)))
 (let (($x91334 (= v_4_L.packet v_3_L.packet)))
 (let (($x13033 (= v_4_L.ip_wire v_3_L.ip_wire)))
 (let (($x131 (= v_4_L.ip_zero v_3_L.ip_zero)))
 (let (($x97214 (= v_4_L.udp_wire v_3_L.udp_wire)))
 (let (($x53039 (= v_4_L.pseudoheader v_3_L.pseudoheader)))
 (let (($x53027 (= v_4_L.udp_zero v_3_L.udp_zero)))
 (let (($x5492 (= v_4_L.payload v_3_L.payload)))
 (let (($x33001 (= v_4_L.checksums_enabled v_3_L.checksums_enabled)))
 (let (($x361 (= v_4_L.cache_ttl_ms v_3_L.cache_ttl_ms)))
 (let (($x91317 (= 0 v_4_L.retry_count)))
 (let (($x2478 (= (as seq.empty (Seq (_ BitVec 8))) v_4_L.peer_mac)))
 (let (($x95147 (= 0 state_4)))
 (let ((?x30850 (seq.len v_3_L.pending_packet)))
 (let (($x63789 (= 0 ?x30850)))
 (let (($x48581 (= 1 v_3_L.retry_count)))
 (let (($x48605 (= v_3_L.control "PENDING")))
 (let (($x76681 (= state_3 0)))
 (and $x76681 $x48605 $x48581 $x63789 active_3_L.query (= 2000 due_3_L.query) (or (not active_3_L.cache) (not (<= due_3_L.cache due_3_L.query))) (or (not active_3_T.rtx) (<= due_3_L.query due_3_T.rtx)) (or (not active_3_T.user) (<= due_3_L.query due_3_T.user)) (or (not active_3_T.time_wait) (<= due_3_L.query due_3_T.time_wait)) $x95147 $x2478 $x91317 $x361 $x33001 $x5492 $x53027 $x53039 $x97214 $x131 $x13033 $x91334 $x55459 $x91258 $x12745 $x8725 $x12816 $x91408 $x5554 $x55354 $x91103 $x55593 $x55594 $x91342 $x130 $x125447 $x13029 $x3796 $x3795 $x91406 $x91435 $x91254 $x91359 $x12752 $x53293 $x91286 $x91287 $x5491 $x91463 $x91322 $x91323 $x13072 $x91177 $x95146 $x95208 $x91447 $x32704 $x5559 $x53241 $x53240 $x32706 $x55579 $x3585 $x53087 $x53088 $x83077 $x53230 $x5553 $x51710 $x2480 $x52836 $x8727 $x55591 $x55592 $x12990 $x52824 $x12910 $x51707 $x55531))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x50007 (seq.unit (_ bv192 8))))
 (let ((?x50073 (seq.++ ?x50007 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x50073))))
(assert
 (= 1 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x50007 (seq.unit (_ bv192 8))))
 (let ((?x50073 (seq.++ ?x50007 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_1_L.app.resolve_ip ?x50073))))
(assert
 (= 3 choice_2))
(assert
 (= 1000 now_3))
(assert
 (= 26 choice_3))
(assert
 (= 2000 now_4))
(check-sat)

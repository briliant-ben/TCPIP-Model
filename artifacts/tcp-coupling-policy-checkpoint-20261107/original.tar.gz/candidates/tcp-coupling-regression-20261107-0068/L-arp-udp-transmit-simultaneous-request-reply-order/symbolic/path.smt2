; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x59983 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x12976 (= due_1_T.user due_0_T.user)))
 (let (($x31883 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x30844 (= due_1_L.cache due_0_L.cache)))
 (let (($x96847 (= due_1_L.query 1000)))
 (let (($x16678 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x76856 (= active_1_T.user active_0_T.user)))
 (let (($x33719 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x30834 (= active_1_L.cache active_0_L.cache)))
 (let (($x79751 (= v_1_ip_pending_owner "UDP")))
 (let (($x35057 (= v_1_T.control "CLOSED")))
 (let (($x26648 (= v_1_T.wire_flags 0)))
 (let (($x96846 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x96845 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x96844 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x96843 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x96842 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x96841 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x96840 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x47700 (= v_1_T.take 0)))
 (let (($x36800 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3361 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x40310 (= v_1_T.snd_wnd 8)))
 (let (($x96839 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x96838 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x96837 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x88500 (= v_1_T.local_window 16)))
 (let (($x41236 (= v_1_T.msl_ms 60000)))
 (let (($x32673 (= v_1_T.user_timeout_ms 30000)))
 (let (($x32674 (= v_1_T.retries 0)))
 (let (($x43434 (= v_1_T.rto_ms 1000)))
 (let (($x9482 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x1078 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x40580 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x97533 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x40599 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x98723 (= v_1_T.irs (_ bv0 32))))
 (let (($x40600 (= v_1_T.iss (_ bv1000 32))))
 (let (($x35836 (= v_1_L.control "PENDING")))
 (let (($x96836 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x96835 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x96834 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x96833 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x96832 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x30318 (not v_1_L.rxudp_require_checksum)))
 (let ((?x94259 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x30486 (seq.unit (_ bv0 8))))
 (let ((?x94260 (seq.++ ?x30486 ?x94259)))
 (let ((?x77227 (seq.unit (_ bv192 8))))
 (let ((?x35472 (seq.unit (_ bv13 8))))
 (let ((?x94386 (seq.++ ?x30486 (seq.++ ?x35472 (seq.++ ?x77227 (seq.++ (seq.unit (_ bv119 8)) ?x94260))))))
 (let ((?x53006 (seq.unit (_ bv144 8))))
 (let ((?x12963 (seq.unit (_ bv31 8))))
 (let ((?x84423 (seq.unit (_ bv64 8))))
 (let ((?x33033 (seq.unit (_ bv156 8))))
 (let ((?x94390 (seq.++ ?x33033 (seq.++ ?x84423 (seq.++ ?x12963 (seq.++ ?x53006 ?x94386))))))
 (let ((?x84577 (seq.unit (_ bv2 8))))
 (let ((?x103116 (seq.unit (_ bv1 8))))
 (let ((?x96807 (seq.++ ?x103116 (seq.++ ?x77227 (seq.++ ?x30486 (seq.++ ?x84577 (seq.++ ?x84577 ?x94390)))))))
 (let ((?x96702 (seq.unit (_ bv200 8))))
 (let ((?x96700 (seq.unit (_ bv182 8))))
 (let ((?x96814 (seq.++ ?x96700 (seq.++ ?x96702 (seq.++ ?x77227 (seq.++ ?x30486 (seq.++ ?x84577 ?x96807)))))))
 (let ((?x35782 (seq.unit (_ bv17 8))))
 (let ((?x96820 (seq.++ ?x30486 (seq.++ ?x84423 (seq.++ ?x30486 (seq.++ ?x84423 (seq.++ ?x35782 ?x96814)))))))
 (let ((?x94394 (seq.unit (_ bv33 8))))
 (let ((?x10561 (seq.unit (_ bv69 8))))
 (let ((?x98596 (seq.++ ?x10561 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x94394 (seq.++ ?x30486 ?x96820)))))))
 (let (($x96831 (= v_1_L.pending_packet ?x98596)))
 (let (($x96830 (= v_1_L.ip_checksum 46792)))
 (let (($x96829 (= v_1_L.udp_checksum 49271)))
 (let (($x96828 (= v_1_L.udp_raw_checksum 49271)))
 (let (($x96827 (= v_1_L.ip_length 33)))
 (let (($x96826 (= v_1_L.udp_length 13)))
 (let (($x96825 (= v_1_L.packet ?x98596)))
 (let ((?x35515 (seq.++ ?x84577 (seq.++ ?x103116 (seq.++ ?x77227 (seq.++ ?x30486 (seq.++ ?x84577 ?x84577)))))))
 (let ((?x20242 (seq.++ ?x77227 (seq.++ ?x30486 ?x35515))))
 (let ((?x96758 (seq.++ ?x30486 (seq.++ ?x84423 (seq.++ ?x35782 (seq.++ ?x96700 (seq.++ ?x96702 ?x20242)))))))
 (let ((?x96763 (seq.++ ?x30486 (seq.++ ?x94394 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x84423 ?x96758)))))))
 (let (($x96766 (= v_1_L.ip_wire (seq.++ ?x10561 (seq.++ ?x30486 ?x96763)))))
 (let ((?x94463 (seq.++ ?x30486 (seq.++ ?x84423 (seq.++ ?x35782 (seq.++ ?x30486 (seq.++ ?x30486 ?x20242)))))))
 (let ((?x94468 (seq.++ ?x30486 (seq.++ ?x94394 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x84423 ?x94463)))))))
 (let (($x94471 (= v_1_L.ip_zero (seq.++ ?x10561 (seq.++ ?x30486 ?x94468)))))
 (let (($x94391 (= v_1_L.udp_wire ?x94390)))
 (let ((?x3426 (seq.++ ?x84577 (seq.++ ?x84577 (seq.++ ?x30486 (seq.++ ?x35782 (seq.++ ?x30486 ?x35472)))))))
 (let ((?x3435 (seq.++ ?x30486 (seq.++ ?x84577 (seq.++ ?x103116 (seq.++ ?x77227 (seq.++ ?x30486 ?x3426)))))))
 (let (($x3439 (= v_1_L.pseudoheader (seq.++ ?x77227 ?x3435))))
 (let ((?x35506 (seq.++ ?x53006 (seq.++ ?x30486 (seq.++ ?x35472 (seq.++ ?x30486 (seq.++ ?x30486 ?x94260)))))))
 (let (($x35509 (= v_1_L.udp_zero (seq.++ ?x33033 (seq.++ ?x84423 (seq.++ ?x12963 ?x35506))))))
 (let (($x90338 (= v_1_L.payload ?x94260)))
 (let (($x27380 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x35824 (= 0 v_1_L.retry_count)))
 (let (($x68736 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x35823 (= 0 state_1)))
 (let (($x10551 (not active_0_T.time_wait)))
 (let (($x75669 (or $x10551 (not (<= due_0_T.time_wait 0)))))
 (let (($x14412 (not active_0_T.user)))
 (let (($x98799 (or $x14412 (not (<= due_0_T.user 0)))))
 (let (($x27392 (not active_0_T.rtx)))
 (let (($x58964 (or $x27392 (not (<= due_0_T.rtx 0)))))
 (let (($x78866 (not active_0_L.cache)))
 (let (($x30508 (or $x78866 (not (<= due_0_L.cache 0)))))
 (let (($x27204 (not active_0_L.query)))
 (let (($x1014 (or $x27204 (not (<= due_0_L.query 0)))))
 (let (($x20334 (= state_0 0)))
 (and $x20334 (>= 0 now_0) $x1014 $x30508 $x58964 $x98799 $x75669 $x35823 $x68736 $x35824 $x27380 v_1_L.checksums_enabled $x90338 $x35509 $x3439 $x94391 $x94471 $x96766 $x96825 $x96826 $x96827 $x96828 $x96829 $x96830 $x96831 $x30318 $x96832 (= v_1_L.rxudp_disposition "none") $x96833 $x96834 $x96835 $x96836 (= v_1_L.echo_disposition "none") $x35836 $x40600 $x98723 $x40599 $x97533 $x40580 $x1078 $x9482 (= v_1_T.tx_flags "S") $x43434 $x32674 v_1_T.active_open $x32673 $x41236 $x88500 $x96837 $x96838 $x96839 $x40310 $x3361 $x36800 $x47700 $x96840 $x96841 $x96842 $x96843 $x96844 $x96845 $x96846 $x26648 (= v_1_T.wire_disposition "none") $x35057 $x79751 active_1_L.query $x30834 $x33719 $x76856 $x16678 $x96847 $x30844 $x31883 $x12976 $x59983))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x30177 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x30176 (= due_2_T.user due_1_T.user)))
 (let (($x30175 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x30173 (= due_2_L.query due_1_L.query)))
 (let (($x30172 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x30171 (= active_2_T.user active_1_T.user)))
 (let (($x30170 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x96556 (not active_2_L.query)))
 (let (($x30167 (= v_2_ip_pending_owner "none")))
 (let (($x30166 (= v_2_T.control v_1_T.control)))
 (let (($x30165 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x30164 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x30163 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x30162 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x30161 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x30160 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x30159 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x30158 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x30157 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x30156 (= v_2_T.take v_1_T.take)))
 (let (($x30155 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x30154 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x30153 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x30152 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x30151 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x30150 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x30149 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x30148 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x30147 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x30146 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x30145 (= v_2_T.retries v_1_T.retries)))
 (let (($x30144 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x30143 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x30142 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x30141 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x30140 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x30139 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x30138 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x30137 (= v_2_T.irs v_1_T.irs)))
 (let (($x30136 (= v_2_T.iss v_1_T.iss)))
 (let (($x30135 (= v_2_L.control "RESOLVED")))
 (let (($x30134 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x30133 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x30132 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x30131 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x30130 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x30129 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x30128 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x30127 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x96555 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x30125 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x30124 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x30032 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x30031 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x30030 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x30029 (= v_2_L.packet v_1_L.packet)))
 (let (($x30028 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x30027 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x30026 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x30025 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x30024 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x30023 (= v_2_L.payload v_1_L.payload)))
 (let (($x30022 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x30021 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x30020 (= 0 v_2_L.retry_count)))
 (let ((?x30486 (seq.unit (_ bv0 8))))
 (let ((?x10637 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.unit (_ bv2 8))))))))
 (let ((?x84577 (seq.unit (_ bv2 8))))
 (let ((?x10595 (seq.++ ?x84577 ?x10637)))
 (let (($x96554 (= v_2_L.peer_mac ?x10595)))
 (let (($x30018 (= 0 state_2)))
 (let (($x96553 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x96549 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x96545 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x96541 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x96684 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x29965 (seq.len v_1_L.pending_packet)))
 (let (($x29966 (<= 28 ?x29965)))
 (let (($x35836 (= v_1_L.control "PENDING")))
 (let (($x74903 (= state_1 0)))
 (and $x74903 $x35836 $x29966 $x96684 $x96541 $x96545 $x96549 $x96553 $x30018 $x96554 $x30020 $x30021 $x30022 $x30023 $x30024 $x30025 $x30026 $x30027 $x30028 $x30029 $x30030 $x30031 $x30032 $x30124 $x30125 $x96555 $x30127 $x30128 $x30129 $x30130 $x30131 $x30132 $x30133 $x30134 $x30135 $x30136 $x30137 $x30138 $x30139 $x30140 $x30141 $x30142 $x30143 $x30144 $x30145 $x30146 $x30147 $x30148 $x30149 $x30150 $x30151 $x30152 $x30153 $x30154 $x30155 $x30156 $x30157 $x30158 $x30159 $x30160 $x30161 $x30162 $x30163 $x30164 $x30165 $x30166 $x30167 $x96556 active_2_L.cache $x30170 $x30171 $x30172 $x30173 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x30175 $x30176 $x30177))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x94259 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x30486 (seq.unit (_ bv0 8))))
 (let ((?x94260 (seq.++ ?x30486 ?x94259)))
 (= input_0_L.app.send_data ?x94260)))))
(assert
 (= 27 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x77227 (seq.unit (_ bv192 8))))
(let ((?x95157 (seq.++ ?x77227 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x30486 (seq.unit (_ bv0 8))))
(let ((?x94265 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 ?x95157)))))))
(let ((?x84577 (seq.unit (_ bv2 8))))
(let ((?x94270 (seq.++ ?x77227 (seq.++ ?x30486 (seq.++ ?x84577 (seq.++ ?x84577 (seq.++ ?x30486 ?x94265)))))))
(let ((?x94275 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x84577 ?x94270)))))))
(let ((?x103116 (seq.unit (_ bv1 8))))
(let ((?x81830 (seq.unit (_ bv4 8))))
(let ((?x38371 (seq.unit (_ bv6 8))))
(let ((?x94280 (seq.++ ?x38371 (seq.++ ?x81830 (seq.++ ?x30486 (seq.++ ?x103116 (seq.++ ?x84577 ?x94275)))))))
(let ((?x12829 (seq.unit (_ bv8 8))))
(let ((?x94285 (seq.++ ?x38371 (seq.++ ?x30486 (seq.++ ?x103116 (seq.++ ?x12829 (seq.++ ?x30486 ?x94280)))))))
(let ((?x94290 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x30486 (seq.++ ?x84577 (seq.++ ?x12829 ?x94285)))))))
(let ((?x32597 (seq.unit (_ bv255 8))))
(let ((?x94295 (seq.++ ?x32597 (seq.++ ?x32597 (seq.++ ?x32597 (seq.++ ?x84577 (seq.++ ?x30486 ?x94290)))))))
(let ((?x94298 (seq.++ ?x32597 (seq.++ ?x32597 (seq.++ ?x32597 ?x94295)))))
(= input_1_L.net.frame_frame ?x94298)))))))))))))))))))
(check-sat)

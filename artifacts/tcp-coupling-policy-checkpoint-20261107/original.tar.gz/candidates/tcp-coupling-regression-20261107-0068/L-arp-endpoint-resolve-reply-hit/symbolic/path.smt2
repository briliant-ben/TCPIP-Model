; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x53292 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x53291 (= due_1_T.user due_0_T.user)))
 (let (($x53290 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x53289 (= due_1_L.cache due_0_L.cache)))
 (let (($x12860 (= due_1_L.query 1000)))
 (let (($x53287 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x53286 (= active_1_T.user active_0_T.user)))
 (let (($x53285 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x53284 (= active_1_L.cache active_0_L.cache)))
 (let (($x5864 (= v_1_T.control "CLOSED")))
 (let (($x12769 (= v_1_T.wire_flags 0)))
 (let (($x12861 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x7206 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x7205 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x7204 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x7203 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x7202 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x7201 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x97378 (= v_1_T.take 0)))
 (let (($x63766 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x87453 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x52689 (= v_1_T.snd_wnd 8)))
 (let (($x7200 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x7199 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x7198 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x97443 (= v_1_T.local_window 16)))
 (let (($x62369 (= v_1_T.msl_ms 60000)))
 (let (($x63112 (= v_1_T.user_timeout_ms 30000)))
 (let (($x7100 (= v_1_T.retries 0)))
 (let (($x7101 (= v_1_T.rto_ms 1000)))
 (let (($x7105 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x7106 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x7107 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x7112 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x7113 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x7118 (= v_1_T.irs (_ bv0 32))))
 (let (($x7119 (= v_1_T.iss (_ bv1000 32))))
 (let (($x53250 (= v_1_L.control "PENDING")))
 (let (($x7197 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x7196 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x7195 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63183 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x7194 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x5694 (not v_1_L.rxudp_require_checksum)))
 (let (($x7193 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x7134 (= v_1_L.ip_checksum 0)))
 (let (($x7135 (= v_1_L.udp_checksum 0)))
 (let (($x7138 (= v_1_L.udp_raw_checksum 0)))
 (let (($x7141 (= v_1_L.ip_length 0)))
 (let (($x7142 (= v_1_L.udp_length 0)))
 (let (($x126 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x8762 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x65519 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x31854 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x52912 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x52911 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x7192 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x97511 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x53226 (= 0 v_1_L.retry_count)))
 (let (($x7190 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x53224 (= 0 state_1)))
 (let (($x12939 (not active_0_T.time_wait)))
 (let (($x7191 (or $x12939 (not (<= due_0_T.time_wait 0)))))
 (let (($x63161 (not active_0_T.user)))
 (let (($x7185 (or $x63161 (not (<= due_0_T.user 0)))))
 (let (($x63647 (not active_0_T.rtx)))
 (let (($x7183 (or $x63647 (not (<= due_0_T.rtx 0)))))
 (let (($x94752 (not active_0_L.cache)))
 (let (($x7178 (or $x94752 (not (<= due_0_L.cache 0)))))
 (let (($x12677 (not active_0_L.query)))
 (let (($x7179 (or $x12677 (not (<= due_0_L.query 0)))))
 (let (($x52801 (= state_0 0)))
 (and $x52801 (>= 0 now_0) $x7179 $x7178 $x7183 $x7185 $x7191 $x53224 $x7190 $x53226 $x97511 v_1_L.checksums_enabled $x7192 $x52911 $x52912 $x31854 $x65519 $x8762 $x126 $x7142 $x7141 $x7138 $x7135 $x7134 $x7193 $x5694 $x7194 (= v_1_L.rxudp_disposition "none") $x63183 $x7195 $x7196 $x7197 (= v_1_L.echo_disposition "none") $x53250 $x7119 $x7118 $x7113 $x7112 $x7107 $x7106 $x7105 (= v_1_T.tx_flags "S") $x7101 $x7100 v_1_T.active_open $x63112 $x62369 $x97443 $x7198 $x7199 $x7200 $x52689 $x87453 $x63766 $x97378 $x7201 $x7202 $x7203 $x7204 $x7205 $x7206 $x12861 $x12769 (= v_1_T.wire_disposition "none") $x5864 (= v_1_ip_pending_owner "none") active_1_L.query $x53284 $x53285 $x53286 $x53287 $x12860 $x53289 $x53290 $x53291 $x53292))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x5562 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x5561 (= due_2_T.user due_1_T.user)))
 (let (($x5560 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x5558 (= due_2_L.query due_1_L.query)))
 (let (($x5557 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x5556 (= active_2_T.user active_1_T.user)))
 (let (($x5555 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x13002 (not active_2_L.query)))
 (let (($x5552 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x5551 (= v_2_T.control v_1_T.control)))
 (let (($x5550 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x5549 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x5548 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x5547 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x5546 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x5545 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x5544 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x5543 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x5542 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x5541 (= v_2_T.take v_1_T.take)))
 (let (($x5540 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x5539 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x5538 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x5537 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x5536 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x5535 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x5534 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x5533 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x5532 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x5531 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x5530 (= v_2_T.retries v_1_T.retries)))
 (let (($x5529 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x5528 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x5527 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x5526 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x5525 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x5524 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x5523 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x5522 (= v_2_T.irs v_1_T.irs)))
 (let (($x5521 (= v_2_T.iss v_1_T.iss)))
 (let (($x5520 (= v_2_L.control "RESOLVED")))
 (let (($x5519 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x5518 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x5517 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x5516 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x5515 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x5514 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x5513 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x5512 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x5511 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x5510 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x5509 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x5508 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x5507 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x5506 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x5505 (= v_2_L.packet v_1_L.packet)))
 (let (($x5504 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x5503 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x5502 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x5501 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x5500 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x5499 (= v_2_L.payload v_1_L.payload)))
 (let (($x5498 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x5497 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x5496 (= 0 v_2_L.retry_count)))
 (let ((?x53059 (seq.unit (_ bv0 8))))
 (let ((?x51129 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.unit (_ bv2 8))))))))
 (let ((?x53076 (seq.unit (_ bv2 8))))
 (let ((?x51134 (seq.++ ?x53076 ?x51129)))
 (let (($x30814 (= v_2_L.peer_mac ?x51134)))
 (let (($x5494 (= 0 state_2)))
 (let (($x296 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x60701 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x63640 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x63080 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x87427 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x5463 (seq.len v_1_L.pending_packet)))
 (let (($x5473 (= 0 ?x5463)))
 (let (($x53250 (= v_1_L.control "PENDING")))
 (let (($x9279 (= state_1 0)))
 (and $x9279 $x53250 $x5473 $x87427 $x63080 $x63640 $x60701 $x296 $x5494 $x30814 $x5496 $x5497 $x5498 $x5499 $x5500 $x5501 $x5502 $x5503 $x5504 $x5505 $x5506 $x5507 $x5508 $x5509 $x5510 $x5511 $x5512 $x5513 $x5514 $x5515 $x5516 $x5517 $x5518 $x5519 $x5520 $x5521 $x5522 $x5523 $x5524 $x5525 $x5526 $x5527 $x5528 $x5529 $x5530 $x5531 $x5532 $x5533 $x5534 $x5535 $x5536 $x5537 $x5538 $x5539 $x5540 $x5541 $x5542 $x5543 $x5544 $x5545 $x5546 $x5547 $x5548 $x5549 $x5550 $x5551 $x5552 $x13002 active_2_L.cache $x5555 $x5556 $x5557 $x5558 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x5560 $x5561 $x5562))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x51724 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x51723 (= due_3_T.user due_2_T.user)))
 (let (($x51722 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x51721 (= due_3_L.cache due_2_L.cache)))
 (let (($x51720 (= due_3_L.query due_2_L.query)))
 (let (($x51719 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x51718 (= active_3_T.user active_2_T.user)))
 (let (($x51717 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x51716 (= active_3_L.cache active_2_L.cache)))
 (let (($x51715 (= active_3_L.query active_2_L.query)))
 (let (($x51714 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x51713 (= v_3_T.control v_2_T.control)))
 (let (($x51712 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x51711 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x51710 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x51709 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x51708 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x51707 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x51706 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x51705 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x51704 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x51703 (= v_3_T.take v_2_T.take)))
 (let (($x51702 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x51701 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x51700 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x51699 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x51698 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x51697 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x51696 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x51695 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x51694 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x51693 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x51692 (= v_3_T.retries v_2_T.retries)))
 (let (($x51691 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x51690 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x51689 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x51688 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x51687 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x51686 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x51685 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x51684 (= v_3_T.irs v_2_T.irs)))
 (let (($x51683 (= v_3_T.iss v_2_T.iss)))
 (let (($x51682 (= v_3_L.control "RESOLVED")))
 (let (($x51681 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x51680 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x51679 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x51678 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x51677 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x51676 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x51675 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x51674 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x51673 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x51672 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x51671 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x51670 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x51669 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x51668 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x51667 (= v_3_L.packet v_2_L.packet)))
 (let (($x51666 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x51665 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x51664 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x51663 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x51662 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x51661 (= v_3_L.payload v_2_L.payload)))
 (let (($x51660 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x51659 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x51658 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x51657 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x51656 (= 0 state_3)))
 (let (($x13097 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x7133 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x7130 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x7125 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x13002 (not active_2_L.query)))
 (let (($x52793 (or $x13002 (not (<= due_2_L.query 20)))))
 (let (($x5520 (= v_2_L.control "RESOLVED")))
 (let (($x7189 (= state_2 0)))
 (and $x7189 $x5520 $x52793 $x7125 $x7130 $x7133 $x13097 $x51656 $x51657 $x51658 $x51659 $x51660 $x51661 $x51662 $x51663 $x51664 $x51665 $x51666 $x51667 $x51668 $x51669 $x51670 $x51671 $x51672 $x51673 $x51674 $x51675 $x51676 $x51677 $x51678 $x51679 $x51680 $x51681 $x51682 $x51683 $x51684 $x51685 $x51686 $x51687 $x51688 $x51689 $x51690 $x51691 $x51692 $x51693 $x51694 $x51695 $x51696 $x51697 $x51698 $x51699 $x51700 $x51701 $x51702 $x51703 $x51704 $x51705 $x51706 $x51707 $x51708 $x51709 $x51710 $x51711 $x51712 $x51713 $x51714 $x51715 $x51716 $x51717 $x51718 $x51719 $x51720 $x51721 $x51722 $x51723 $x51724)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x94761 (seq.unit (_ bv192 8))))
 (let ((?x258 (seq.++ ?x94761 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x258))))
(assert
 (= 30 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x94761 (seq.unit (_ bv192 8))))
 (let ((?x53196 (seq.++ ?x94761 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x53171 (seq.unit (_ bv1 8))))
 (let ((?x53059 (seq.unit (_ bv0 8))))
 (let ((?x91452 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53171 ?x53196)))))))
 (let ((?x53076 (seq.unit (_ bv2 8))))
 (let ((?x65073 (seq.++ ?x94761 (seq.++ ?x53059 (seq.++ ?x53076 (seq.++ ?x53076 (seq.++ ?x53076 ?x91452)))))))
 (let ((?x91300 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53076 ?x65073)))))))
 (let ((?x53183 (seq.unit (_ bv4 8))))
 (let ((?x53181 (seq.unit (_ bv6 8))))
 (let ((?x91360 (seq.++ ?x53181 (seq.++ ?x53183 (seq.++ ?x53059 (seq.++ ?x53076 (seq.++ ?x53076 ?x91300)))))))
 (let ((?x53179 (seq.unit (_ bv8 8))))
 (let ((?x91368 (seq.++ ?x53181 (seq.++ ?x53059 (seq.++ ?x53171 (seq.++ ?x53179 (seq.++ ?x53059 ?x91360)))))))
 (let ((?x55534 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53076 (seq.++ ?x53179 ?x91368)))))))
 (let ((?x55393 (seq.++ ?x53059 (seq.++ ?x53059 (seq.++ ?x53171 (seq.++ ?x53076 (seq.++ ?x53059 ?x55534)))))))
 (let ((?x91381 (seq.++ ?x53076 (seq.++ ?x53059 (seq.++ ?x53059 ?x55393)))))
 (= input_1_L.net.frame_frame ?x91381))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x94761 (seq.unit (_ bv192 8))))
(let ((?x258 (seq.++ ?x94761 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x258))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x88224 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x54795 (= due_1_T.user due_0_T.user)))
 (let (($x56788 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x89953 (= due_1_L.cache 60000)))
 (let (($x69466 (= due_1_L.query due_0_L.query)))
 (let (($x54793 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x70687 (= active_1_T.user active_0_T.user)))
 (let (($x54792 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x54767 (not active_1_L.query)))
 (let (($x10331 (= v_1_T.control "CLOSED")))
 (let (($x40083 (= v_1_T.wire_flags 0)))
 (let (($x52998 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x62353 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x25545 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x51609 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x53285 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x53284 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x53287 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x20289 (= v_1_T.take 0)))
 (let (($x47194 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x209 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x51635 (= v_1_T.snd_wnd 8)))
 (let (($x53286 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x87442 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x12861 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x20299 (= v_1_T.local_window 16)))
 (let (($x20291 (= v_1_T.msl_ms 60000)))
 (let (($x55532 (= v_1_T.user_timeout_ms 30000)))
 (let (($x5337 (= v_1_T.retries 0)))
 (let (($x91273 (= v_1_T.rto_ms 1000)))
 (let (($x7123 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x26844 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x11656 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x11658 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x40088 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x40089 (= v_1_T.irs (_ bv0 32))))
 (let (($x40090 (= v_1_T.iss (_ bv1000 32))))
 (let (($x75092 (= v_1_L.control "RESOLVED")))
 (let (($x7206 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x43449 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x11621 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x11620 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x52883 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x10161 (not v_1_L.rxudp_require_checksum)))
 (let (($x91033 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x40103 (= v_1_L.ip_checksum 0)))
 (let (($x40104 (= v_1_L.udp_checksum 0)))
 (let (($x40102 (= v_1_L.udp_raw_checksum 0)))
 (let (($x40105 (= v_1_L.ip_length 0)))
 (let (($x40107 (= v_1_L.udp_length 0)))
 (let (($x5126 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x12858 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x11634 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x11633 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x40116 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x40115 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x30887 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x40119 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x32322 (= 0 v_1_L.retry_count)))
 (let ((?x41942 (seq.unit (_ bv0 8))))
 (let ((?x30502 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.unit (_ bv2 8))))))))
 (let ((?x41943 (seq.unit (_ bv2 8))))
 (let ((?x25623 (seq.++ ?x41943 ?x30502)))
 (let (($x7154 (= v_1_L.peer_mac ?x25623)))
 (let (($x30896 (= 0 state_1)))
 (let (($x71125 (not active_0_T.time_wait)))
 (let (($x52941 (or $x71125 (not (<= due_0_T.time_wait 0)))))
 (let (($x41925 (not active_0_T.user)))
 (let (($x56274 (or $x41925 (not (<= due_0_T.user 0)))))
 (let (($x20305 (not active_0_T.rtx)))
 (let (($x87712 (or $x20305 (not (<= due_0_T.rtx 0)))))
 (let (($x45148 (not active_0_L.cache)))
 (let (($x70791 (or $x45148 (not (<= due_0_L.cache 0)))))
 (let (($x55520 (not active_0_L.query)))
 (let (($x11603 (or $x55520 (not (<= due_0_L.query 0)))))
 (let (($x45134 (= state_0 0)))
 (and $x45134 (>= 0 now_0) $x11603 $x70791 $x87712 $x56274 $x52941 $x30896 $x7154 $x32322 $x40119 v_1_L.checksums_enabled $x30887 $x40115 $x40116 $x11633 $x11634 $x12858 $x5126 $x40107 $x40105 $x40102 $x40104 $x40103 $x91033 $x10161 $x52883 (= v_1_L.rxudp_disposition "none") $x11620 $x11621 $x43449 $x7206 (= v_1_L.echo_disposition "none") $x75092 $x40090 $x40089 $x40088 $x11658 $x11656 $x26844 $x7123 (= v_1_T.tx_flags "S") $x91273 $x5337 v_1_T.active_open $x55532 $x20291 $x20299 $x12861 $x87442 $x53286 $x51635 $x209 $x47194 $x20289 $x53287 $x53284 $x53285 $x51609 $x25545 $x62353 $x52998 $x40083 (= v_1_T.wire_disposition "none") $x10331 (= v_1_ip_pending_owner "none") $x54767 active_1_L.cache $x54792 $x70687 $x54793 $x69466 $x89953 $x56788 $x54795 $x88224))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x9987 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x9986 (= due_2_T.user due_1_T.user)))
 (let (($x9985 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x9983 (= due_2_L.query due_1_L.query)))
 (let (($x9982 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x9981 (= active_2_T.user active_1_T.user)))
 (let (($x9980 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x11641 (not active_2_L.query)))
 (let (($x9977 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x9976 (= v_2_T.control v_1_T.control)))
 (let (($x9975 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x9974 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x9973 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x9972 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x9971 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x9970 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x9969 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x9968 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x9967 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x9966 (= v_2_T.take v_1_T.take)))
 (let (($x9965 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x9964 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x9963 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x9962 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x9961 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x9960 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x9959 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x9958 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x9957 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x9956 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x9955 (= v_2_T.retries v_1_T.retries)))
 (let (($x9954 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x9953 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x9952 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x9951 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x9950 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x9949 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x9948 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x9947 (= v_2_T.irs v_1_T.irs)))
 (let (($x9946 (= v_2_T.iss v_1_T.iss)))
 (let (($x9945 (= v_2_L.control "RESOLVED")))
 (let (($x9944 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x9943 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x9942 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x9941 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x9940 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x9939 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x9938 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x9937 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x9936 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x9935 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x9934 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x9933 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x9932 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x9931 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x9930 (= v_2_L.packet v_1_L.packet)))
 (let (($x9929 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x9928 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x9927 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x9926 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x9925 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x9924 (= v_2_L.payload v_1_L.payload)))
 (let (($x9923 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x9922 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x9921 (= 0 v_2_L.retry_count)))
 (let ((?x41942 (seq.unit (_ bv0 8))))
 (let ((?x11613 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.unit (_ bv3 8))))))))
 (let ((?x41943 (seq.unit (_ bv2 8))))
 (let (($x11607 (= v_2_L.peer_mac (seq.++ ?x41943 ?x11613))))
 (let (($x9919 (= 0 state_2)))
 (let (($x11604 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x11599 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x11595 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x11591 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x54767 (not active_1_L.query)))
 (let (($x11588 (or $x54767 (not (<= due_1_L.query 5)))))
 (let (($x75092 (= v_1_L.control "RESOLVED")))
 (let (($x52999 (= state_1 0)))
 (and $x52999 $x75092 $x11588 $x11591 $x11595 $x11599 $x11604 $x9919 $x11607 $x9921 $x9922 $x9923 $x9924 $x9925 $x9926 $x9927 $x9928 $x9929 $x9930 $x9931 $x9932 $x9933 $x9934 $x9935 $x9936 $x9937 $x9938 $x9939 $x9940 $x9941 $x9942 $x9943 $x9944 $x9945 $x9946 $x9947 $x9948 $x9949 $x9950 $x9951 $x9952 $x9953 $x9954 $x9955 $x9956 $x9957 $x9958 $x9959 $x9960 $x9961 $x9962 $x9963 $x9964 $x9965 $x9966 $x9967 $x9968 $x9969 $x9970 $x9971 $x9972 $x9973 $x9974 $x9975 $x9976 $x9977 $x11641 active_2_L.cache $x9980 $x9981 $x9982 $x9983 (= due_2_L.cache (+ 5 v_1_L.cache_ttl_ms)) $x9985 $x9986 $x9987))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x38382 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x38381 (= due_3_T.user due_2_T.user)))
 (let (($x38380 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x38379 (= due_3_L.cache due_2_L.cache)))
 (let (($x38378 (= due_3_L.query due_2_L.query)))
 (let (($x38377 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x38376 (= active_3_T.user active_2_T.user)))
 (let (($x38375 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x38374 (= active_3_L.cache active_2_L.cache)))
 (let (($x38373 (= active_3_L.query active_2_L.query)))
 (let (($x38372 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x38371 (= v_3_T.control v_2_T.control)))
 (let (($x38370 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x38369 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x38368 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x38367 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x38366 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x38365 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x38364 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x38363 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x38362 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x38361 (= v_3_T.take v_2_T.take)))
 (let (($x38360 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x38359 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x38358 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x38357 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x38356 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x38355 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x38354 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x38353 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x38352 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x38351 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x38350 (= v_3_T.retries v_2_T.retries)))
 (let (($x38349 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x38348 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x38347 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x38346 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x38345 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x38344 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x38343 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x38342 (= v_3_T.irs v_2_T.irs)))
 (let (($x38341 (= v_3_T.iss v_2_T.iss)))
 (let (($x38340 (= v_3_L.control "RESOLVED")))
 (let (($x38339 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x38338 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x38337 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x38336 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x38335 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x38334 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x38333 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x38332 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x38331 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x38330 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x38329 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x38328 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x38327 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x38326 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x38325 (= v_3_L.packet v_2_L.packet)))
 (let (($x38324 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x38323 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x38322 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x38321 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x38320 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x38319 (= v_3_L.payload v_2_L.payload)))
 (let (($x38318 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x38317 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x38316 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x38315 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x38314 (= 0 state_3)))
 (let (($x40112 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 10)))))
 (let (($x32998 (or (not active_2_T.user) (not (<= due_2_T.user 10)))))
 (let (($x43441 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 10)))))
 (let (($x48622 (or (not active_2_L.cache) (not (<= due_2_L.cache 10)))))
 (let (($x11641 (not active_2_L.query)))
 (let (($x43447 (or $x11641 (not (<= due_2_L.query 10)))))
 (let (($x9945 (= v_2_L.control "RESOLVED")))
 (let (($x11655 (= state_2 0)))
 (and $x11655 $x9945 $x43447 $x48622 $x43441 $x32998 $x40112 $x38314 $x38315 $x38316 $x38317 $x38318 $x38319 $x38320 $x38321 $x38322 $x38323 $x38324 $x38325 $x38326 $x38327 $x38328 $x38329 $x38330 $x38331 $x38332 $x38333 $x38334 $x38335 $x38336 $x38337 $x38338 $x38339 $x38340 $x38341 $x38342 $x38343 $x38344 $x38345 $x38346 $x38347 $x38348 $x38349 $x38350 $x38351 $x38352 $x38353 $x38354 $x38355 $x38356 $x38357 $x38358 $x38359 $x38360 $x38361 $x38362 $x38363 $x38364 $x38365 $x38366 $x38367 $x38368 $x38369 $x38370 $x38371 $x38372 $x38373 $x38374 $x38375 $x38376 $x38377 $x38378 $x38379 $x38380 $x38381 $x38382)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x68516 (seq.unit (_ bv192 8))))
 (let ((?x54753 (seq.++ ?x68516 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x53906 (seq.unit (_ bv1 8))))
 (let ((?x41942 (seq.unit (_ bv0 8))))
 (let ((?x89757 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x53906 ?x54753)))))))
 (let ((?x41943 (seq.unit (_ bv2 8))))
 (let ((?x88220 (seq.++ ?x68516 (seq.++ ?x41942 (seq.++ ?x41943 (seq.++ ?x41943 (seq.++ ?x41943 ?x89757)))))))
 (let ((?x70050 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41943 ?x88220)))))))
 (let ((?x43469 (seq.unit (_ bv4 8))))
 (let ((?x20323 (seq.unit (_ bv6 8))))
 (let ((?x65622 (seq.++ ?x20323 (seq.++ ?x43469 (seq.++ ?x41942 (seq.++ ?x41943 (seq.++ ?x41943 ?x70050)))))))
 (let ((?x97851 (seq.unit (_ bv8 8))))
 (let ((?x72872 (seq.++ ?x20323 (seq.++ ?x41942 (seq.++ ?x53906 (seq.++ ?x97851 (seq.++ ?x41942 ?x65622)))))))
 (let ((?x69804 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41943 (seq.++ ?x97851 ?x72872)))))))
 (let ((?x83322 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x53906 (seq.++ ?x41943 (seq.++ ?x41942 ?x69804)))))))
 (let ((?x68998 (seq.++ ?x41943 (seq.++ ?x41942 (seq.++ ?x41942 ?x83322)))))
 (= input_0_L.net.frame_frame ?x68998))))))))))))))))))
(assert
 (= 16 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x68516 (seq.unit (_ bv192 8))))
 (let ((?x54753 (seq.++ ?x68516 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x53906 (seq.unit (_ bv1 8))))
 (let ((?x41942 (seq.unit (_ bv0 8))))
 (let ((?x89757 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x53906 ?x54753)))))))
 (let ((?x41943 (seq.unit (_ bv2 8))))
 (let ((?x88220 (seq.++ ?x68516 (seq.++ ?x41942 (seq.++ ?x41943 (seq.++ ?x41943 (seq.++ ?x41943 ?x89757)))))))
 (let ((?x89814 (seq.unit (_ bv3 8))))
 (let ((?x88791 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x89814 ?x88220)))))))
 (let ((?x43469 (seq.unit (_ bv4 8))))
 (let ((?x20323 (seq.unit (_ bv6 8))))
 (let ((?x82300 (seq.++ ?x20323 (seq.++ ?x43469 (seq.++ ?x41942 (seq.++ ?x41943 (seq.++ ?x41943 ?x88791)))))))
 (let ((?x97851 (seq.unit (_ bv8 8))))
 (let ((?x89108 (seq.++ ?x20323 (seq.++ ?x41942 (seq.++ ?x53906 (seq.++ ?x97851 (seq.++ ?x41942 ?x82300)))))))
 (let ((?x88085 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x89814 (seq.++ ?x97851 ?x89108)))))))
 (let ((?x75136 (seq.++ ?x41942 (seq.++ ?x41942 (seq.++ ?x53906 (seq.++ ?x41943 (seq.++ ?x41942 ?x88085)))))))
 (let ((?x89562 (seq.++ ?x41943 (seq.++ ?x41942 (seq.++ ?x41942 ?x75136)))))
 (= input_1_L.net.frame_frame ?x89562)))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x68516 (seq.unit (_ bv192 8))))
(let ((?x55594 (seq.++ ?x68516 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x55594))))
(check-sat)

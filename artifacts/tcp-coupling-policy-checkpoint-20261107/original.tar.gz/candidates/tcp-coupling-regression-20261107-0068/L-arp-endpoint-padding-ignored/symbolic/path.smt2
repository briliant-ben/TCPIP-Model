; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x9981 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x9980 (= due_1_T.user due_0_T.user)))
 (let (($x9977 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x52572 (= due_1_L.cache 60000)))
 (let (($x9976 (= due_1_L.query due_0_L.query)))
 (let (($x43498 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x9975 (= active_1_T.user active_0_T.user)))
 (let (($x5553 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x52571 (not active_1_L.query)))
 (let (($x3848 (= v_1_T.wire_flags 0)))
 (let (($x52570 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x52569 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x52568 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x52567 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x52566 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52565 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x52564 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x56657 (= v_1_T.take 0)))
 (let (($x51660 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x32589 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x97820 (= v_1_T.snd_wnd 8)))
 (let (($x52563 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x52562 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x52561 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x43445 (= v_1_T.local_window 16)))
 (let (($x56658 (= v_1_T.msl_ms 60000)))
 (let (($x56633 (= v_1_T.user_timeout_ms 30000)))
 (let (($x56647 (= v_1_T.retries 0)))
 (let (($x63738 (= v_1_T.rto_ms 1000)))
 (let (($x43440 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x79930 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3815 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x33003 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x63167 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x32999 (= v_1_T.irs (_ bv0 32))))
 (let (($x56659 (= v_1_T.iss (_ bv1000 32))))
 (let (($x9957 (= v_1_L.control "RESOLVED")))
 (let (($x52560 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x52559 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x52558 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x52557 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x52556 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x52555 (not v_1_L.rxudp_require_checksum)))
 (let (($x47629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x89524 (= v_1_L.ip_checksum 0)))
 (let (($x53131 (= v_1_L.udp_checksum 0)))
 (let (($x43435 (= v_1_L.udp_raw_checksum 0)))
 (let (($x21530 (= v_1_L.ip_length 0)))
 (let (($x45130 (= v_1_L.udp_length 0)))
 (let (($x47628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x47627 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x47608 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x47607 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x47606 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x47601 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x47600 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x32762 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x9944 (= 0 v_1_L.retry_count)))
 (let ((?x32609 (seq.unit (_ bv0 8))))
 (let ((?x53523 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 (seq.unit (_ bv2 8))))))))
 (let ((?x38343 (seq.unit (_ bv2 8))))
 (let ((?x47184 (seq.++ ?x38343 ?x53523)))
 (let (($x47599 (= v_1_L.peer_mac ?x47184)))
 (let (($x9943 (= 0 state_1)))
 (let (($x38331 (not active_0_T.time_wait)))
 (let (($x47594 (or $x38331 (not (<= due_0_T.time_wait 0)))))
 (let (($x90303 (not active_0_T.user)))
 (let (($x47591 (or $x90303 (not (<= due_0_T.user 0)))))
 (let (($x25629 (not active_0_T.rtx)))
 (let (($x52554 (or $x25629 (not (<= due_0_T.rtx 0)))))
 (let (($x38329 (not active_0_L.cache)))
 (let (($x52551 (or $x38329 (not (<= due_0_L.cache 0)))))
 (let (($x20298 (not active_0_L.query)))
 (let (($x52548 (or $x20298 (not (<= due_0_L.query 0)))))
 (let (($x26923 (= state_0 0)))
 (and $x26923 (>= 0 now_0) $x52548 $x52551 $x52554 $x47591 $x47594 $x9943 $x47599 $x9944 $x32762 v_1_L.checksums_enabled $x47600 $x47601 $x47606 $x47607 $x47608 $x47627 $x47628 $x45130 $x21530 $x43435 $x53131 $x89524 $x47629 $x52555 $x52556 (= v_1_L.rxudp_disposition "none") $x52557 $x52558 $x52559 $x52560 (= v_1_L.echo_disposition "none") $x9957 $x56659 $x32999 $x63167 $x33003 $x3815 $x79930 $x43440 (= v_1_T.tx_flags "S") $x63738 $x56647 v_1_T.active_open $x56633 $x56658 $x43445 $x52561 $x52562 $x52563 $x97820 $x32589 $x51660 $x56657 $x52564 $x52565 $x52566 $x52567 $x52568 $x52569 $x52570 $x3848 (= v_1_T.wire_disposition "none") (= v_1_T.control "CLOSED") (= v_1_ip_pending_owner "none") $x52571 active_1_L.cache $x5553 $x9975 $x43498 $x9976 $x52572 $x9977 $x9980 $x9981)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x52421 (seq.unit (_ bv14 8))))
(let ((?x52428 (seq.++ ?x52421 (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
(let ((?x52419 (seq.unit (_ bv13 8))))
(let ((?x52417 (seq.unit (_ bv12 8))))
(let ((?x47618 (seq.unit (_ bv11 8))))
(let ((?x52416 (seq.unit (_ bv10 8))))
(let ((?x52414 (seq.unit (_ bv9 8))))
(let ((?x52433 (seq.++ ?x52414 (seq.++ ?x52416 (seq.++ ?x47618 (seq.++ ?x52417 (seq.++ ?x52419 ?x52428)))))))
(let ((?x46812 (seq.unit (_ bv8 8))))
(let ((?x52412 (seq.unit (_ bv7 8))))
(let ((?x47010 (seq.unit (_ bv6 8))))
(let ((?x52410 (seq.unit (_ bv5 8))))
(let ((?x45135 (seq.unit (_ bv4 8))))
(let ((?x52438 (seq.++ ?x45135 (seq.++ ?x52410 (seq.++ ?x47010 (seq.++ ?x52412 (seq.++ ?x46812 ?x52433)))))))
(let ((?x52408 (seq.unit (_ bv3 8))))
(let ((?x38343 (seq.unit (_ bv2 8))))
(let ((?x38366 (seq.unit (_ bv1 8))))
(let ((?x32609 (seq.unit (_ bv0 8))))
(let ((?x52443 (seq.++ ?x38366 (seq.++ ?x32609 (seq.++ ?x38366 (seq.++ ?x38343 (seq.++ ?x52408 ?x52438)))))))
(let ((?x38342 (seq.unit (_ bv192 8))))
(let ((?x52448 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x38342 (seq.++ ?x32609 (seq.++ ?x38343 ?x52443)))))))
(let ((?x52453 (seq.++ ?x38343 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 ?x52448)))))))
(let ((?x52458 (seq.++ ?x32609 (seq.++ ?x38343 (seq.++ ?x38342 (seq.++ ?x32609 (seq.++ ?x38343 ?x52453)))))))
(let ((?x52463 (seq.++ ?x38366 (seq.++ ?x38343 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 ?x52458)))))))
(let ((?x52468 (seq.++ ?x46812 (seq.++ ?x32609 (seq.++ ?x47010 (seq.++ ?x45135 (seq.++ ?x32609 ?x52463)))))))
(let ((?x52473 (seq.++ ?x38343 (seq.++ ?x46812 (seq.++ ?x47010 (seq.++ ?x32609 (seq.++ ?x38366 ?x52468)))))))
(let ((?x52478 (seq.++ ?x38343 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 (seq.++ ?x32609 ?x52473)))))))
(let ((?x43462 (seq.unit (_ bv255 8))))
(let ((?x52483 (seq.++ ?x43462 (seq.++ ?x43462 (seq.++ ?x43462 (seq.++ ?x43462 (seq.++ ?x43462 ?x52478)))))))
(let ((?x52484 (seq.++ ?x43462 ?x52483)))
(= input_0_L.net.frame_frame ?x52484))))))))))))))))))))))))))))))))
(check-sat)

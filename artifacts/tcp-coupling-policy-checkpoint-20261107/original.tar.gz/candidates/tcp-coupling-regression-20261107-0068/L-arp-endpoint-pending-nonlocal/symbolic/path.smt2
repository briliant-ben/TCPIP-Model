; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x45155 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x97822 (= due_1_T.user due_0_T.user)))
 (let (($x38351 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x43468 (= due_1_L.cache due_0_L.cache)))
 (let (($x14423 (= due_1_L.query 1000)))
 (let (($x56660 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x46845 (= active_1_T.user active_0_T.user)))
 (let (($x38349 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x48583 (= active_1_L.cache active_0_L.cache)))
 (let (($x12993 (= v_1_T.control "CLOSED")))
 (let (($x72975 (= v_1_T.wire_flags 0)))
 (let (($x14422 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x62633 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x14421 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x97363 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x52322 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x40363 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x40362 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x1179 (= v_1_T.take 0)))
 (let (($x744 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x52354 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x74213 (= v_1_T.snd_wnd 8)))
 (let (($x40366 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x40365 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x40360 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x9531 (= v_1_T.local_window 16)))
 (let (($x30790 (= v_1_T.msl_ms 60000)))
 (let (($x63089 (= v_1_T.user_timeout_ms 30000)))
 (let (($x49903 (= v_1_T.retries 0)))
 (let (($x32871 (= v_1_T.rto_ms 1000)))
 (let (($x52853 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x3587 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3555 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x56060 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x2587 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x40273 (= v_1_T.irs (_ bv0 32))))
 (let (($x40274 (= v_1_T.iss (_ bv1000 32))))
 (let (($x3884 (= v_1_L.control "PENDING")))
 (let (($x40359 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x40358 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x40357 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x40356 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x40355 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x12793 (not v_1_L.rxudp_require_checksum)))
 (let (($x40354 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x40282 (= v_1_L.ip_checksum 0)))
 (let (($x40283 (= v_1_L.udp_checksum 0)))
 (let (($x40284 (= v_1_L.udp_raw_checksum 0)))
 (let (($x40285 (= v_1_L.ip_length 0)))
 (let (($x40286 (= v_1_L.udp_length 0)))
 (let (($x40353 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x59728 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x40352 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x40351 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x74227 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x89562 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x47629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x40299 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x30583 (= 0 v_1_L.retry_count)))
 (let (($x89524 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x53280 (= 0 state_1)))
 (let (($x76052 (not active_0_T.time_wait)))
 (let (($x52349 (or $x76052 (not (<= due_0_T.time_wait 0)))))
 (let (($x83934 (not active_0_T.user)))
 (let (($x40348 (or $x83934 (not (<= due_0_T.user 0)))))
 (let (($x72872 (not active_0_T.rtx)))
 (let (($x40347 (or $x72872 (not (<= due_0_T.rtx 0)))))
 (let (($x77307 (not active_0_L.cache)))
 (let (($x40340 (or $x77307 (not (<= due_0_L.cache 0)))))
 (let (($x85803 (not active_0_L.query)))
 (let (($x40344 (or $x85803 (not (<= due_0_L.query 0)))))
 (let (($x53575 (= state_0 0)))
 (and $x53575 (>= 0 now_0) $x40344 $x40340 $x40347 $x40348 $x52349 $x53280 $x89524 $x30583 $x40299 v_1_L.checksums_enabled $x47629 $x89562 $x74227 $x40351 $x40352 $x59728 $x40353 $x40286 $x40285 $x40284 $x40283 $x40282 $x40354 $x12793 $x40355 (= v_1_L.rxudp_disposition "none") $x40356 $x40357 $x40358 $x40359 (= v_1_L.echo_disposition "none") $x3884 $x40274 $x40273 $x2587 $x56060 $x3555 $x3587 $x52853 (= v_1_T.tx_flags "S") $x32871 $x49903 v_1_T.active_open $x63089 $x30790 $x9531 $x40360 $x40365 $x40366 $x74213 $x52354 $x744 $x1179 $x40362 $x40363 $x52322 $x97363 $x14421 $x62633 $x14422 $x72975 (= v_1_T.wire_disposition "none") $x12993 (= v_1_ip_pending_owner "none") active_1_L.query $x48583 $x38349 $x46845 $x56660 $x14423 $x43468 $x38351 $x97822 $x45155))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x52530 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x52529 (= due_2_T.user due_1_T.user)))
 (let (($x11181 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x11166 (= due_2_L.cache due_1_L.cache)))
 (let (($x9959 (= due_2_L.query due_1_L.query)))
 (let (($x52524 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x52523 (= active_2_T.user active_1_T.user)))
 (let (($x52487 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x43487 (= active_2_L.cache active_1_L.cache)))
 (let (($x58266 (= active_2_L.query active_1_L.query)))
 (let (($x52596 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x52595 (= v_2_T.control v_1_T.control)))
 (let (($x11110 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x49923 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x7086 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x9970 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x97825 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x13010 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x63773 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x53055 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x53054 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x11195 (= v_2_T.take v_1_T.take)))
 (let (($x11194 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x52610 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x52609 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x52600 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x52599 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x53927 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x26773 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x11197 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x11196 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x9967 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x56124 (= v_2_T.retries v_1_T.retries)))
 (let (($x3804 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x56637 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x11201 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x11200 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x12981 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x12788 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x52644 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x52643 (= v_2_T.irs v_1_T.irs)))
 (let (($x11193 (= v_2_T.iss v_1_T.iss)))
 (let (($x11192 (= v_2_L.control "PENDING")))
 (let (($x90314 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x98790 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x10678 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x10679 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x1087 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x53926 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x52634 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x52633 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x52534 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x52533 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x52640 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x52639 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x32944 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x3843 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x63763 (= v_2_L.packet v_1_L.packet)))
 (let (($x63762 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x9969 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x12874 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x3885 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x55580 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x87670 (= v_2_L.payload v_1_L.payload)))
 (let (($x32880 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x9926 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x9974 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x65564 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x91057 (= 0 state_2)))
 (let (($x57606 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x14412 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x52329 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x14427 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x62669 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x3884 (= v_1_L.control "PENDING")))
 (let (($x12891 (= state_1 0)))
 (and $x12891 $x3884 $x62669 $x14427 $x52329 $x14412 $x57606 $x91057 $x65564 $x9974 $x9926 $x32880 $x87670 $x55580 $x3885 $x12874 $x9969 $x63762 $x63763 $x3843 $x32944 $x52639 $x52640 $x52533 $x52534 $x52633 $x52634 $x53926 $x1087 $x10679 $x10678 $x98790 $x90314 $x11192 $x11193 $x52643 $x52644 $x12788 $x12981 $x11200 $x11201 $x56637 $x3804 $x56124 $x9967 $x11196 $x11197 $x26773 $x53927 $x52599 $x52600 $x52609 $x52610 $x11194 $x11195 $x53054 $x53055 $x63773 $x13010 $x97825 $x9970 $x7086 $x49923 $x11110 $x52595 $x52596 $x58266 $x43487 $x52487 $x52523 $x52524 $x9959 $x11166 $x11181 $x52529 $x52530))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x36847 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x36846 (= due_3_T.user due_2_T.user)))
 (let (($x36845 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x36843 (= due_3_L.query due_2_L.query)))
 (let (($x36842 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x36841 (= active_3_T.user active_2_T.user)))
 (let (($x36840 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x3634 (not active_3_L.query)))
 (let (($x36837 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x36836 (= v_3_T.control v_2_T.control)))
 (let (($x36835 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x36834 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x36833 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x36832 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x36831 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x36830 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x36829 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x36828 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x36827 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x36826 (= v_3_T.take v_2_T.take)))
 (let (($x36825 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x36824 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x36823 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x36822 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x36821 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x36820 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x36819 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x36818 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x36817 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x36816 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x36815 (= v_3_T.retries v_2_T.retries)))
 (let (($x36814 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x36813 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x36812 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x36811 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x36810 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x36809 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x36808 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x36807 (= v_3_T.irs v_2_T.irs)))
 (let (($x36806 (= v_3_T.iss v_2_T.iss)))
 (let (($x36805 (= v_3_L.control "RESOLVED")))
 (let (($x36804 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x36803 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x36802 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x36801 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x36800 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x36799 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x36798 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x36797 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x36796 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x36795 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x36794 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x36793 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x36792 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x36791 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x36790 (= v_3_L.packet v_2_L.packet)))
 (let (($x36789 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x36788 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x36787 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x36786 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x36785 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x36784 (= v_3_L.payload v_2_L.payload)))
 (let (($x36783 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x36782 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x36781 (= 0 v_3_L.retry_count)))
 (let ((?x52563 (seq.unit (_ bv0 8))))
 (let ((?x55788 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.unit (_ bv2 8))))))))
 (let ((?x97820 (seq.unit (_ bv2 8))))
 (let ((?x47225 (seq.++ ?x97820 ?x55788)))
 (let (($x3577 (= v_3_L.peer_mac ?x47225)))
 (let (($x36779 (= 0 state_3)))
 (let (($x43469 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 10)))))
 (let (($x26923 (or (not active_2_T.user) (not (<= due_2_T.user 10)))))
 (let (($x14393 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 10)))))
 (let (($x14414 (or (not active_2_L.cache) (not (<= due_2_L.cache 10)))))
 (let (($x14406 (or (not active_2_L.query) (not (<= due_2_L.query 10)))))
 (let ((?x36748 (seq.len v_2_L.pending_packet)))
 (let (($x36758 (= 0 ?x36748)))
 (let (($x11192 (= v_2_L.control "PENDING")))
 (let (($x59104 (= state_2 0)))
 (and $x59104 $x11192 $x36758 $x14406 $x14414 $x14393 $x26923 $x43469 $x36779 $x3577 $x36781 $x36782 $x36783 $x36784 $x36785 $x36786 $x36787 $x36788 $x36789 $x36790 $x36791 $x36792 $x36793 $x36794 $x36795 $x36796 $x36797 $x36798 $x36799 $x36800 $x36801 $x36802 $x36803 $x36804 $x36805 $x36806 $x36807 $x36808 $x36809 $x36810 $x36811 $x36812 $x36813 $x36814 $x36815 $x36816 $x36817 $x36818 $x36819 $x36820 $x36821 $x36822 $x36823 $x36824 $x36825 $x36826 $x36827 $x36828 $x36829 $x36830 $x36831 $x36832 $x36833 $x36834 $x36835 $x36836 $x36837 $x3634 active_3_L.cache $x36840 $x36841 $x36842 $x36843 (= due_3_L.cache (+ 10 v_2_L.cache_ttl_ms)) $x36845 $x36846 $x36847))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x38292 (seq.unit (_ bv192 8))))
 (let ((?x89563 (seq.++ ?x38292 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x89563))))
(assert
 (= 12 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x38292 (seq.unit (_ bv192 8))))
 (let ((?x71767 (seq.++ ?x38292 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x52563 (seq.unit (_ bv0 8))))
 (let ((?x70009 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 ?x71767)))))))
 (let ((?x97820 (seq.unit (_ bv2 8))))
 (let ((?x70901 (seq.++ ?x38292 (seq.++ ?x52563 (seq.++ ?x97820 (seq.++ ?x97820 (seq.++ ?x52563 ?x70009)))))))
 (let ((?x82786 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x97820 ?x70901)))))))
 (let ((?x52512 (seq.unit (_ bv1 8))))
 (let ((?x74452 (seq.unit (_ bv4 8))))
 (let ((?x91278 (seq.unit (_ bv6 8))))
 (let ((?x85668 (seq.++ ?x91278 (seq.++ ?x74452 (seq.++ ?x52563 (seq.++ ?x52512 (seq.++ ?x97820 ?x82786)))))))
 (let ((?x52517 (seq.unit (_ bv8 8))))
 (let ((?x66994 (seq.++ ?x91278 (seq.++ ?x52563 (seq.++ ?x52512 (seq.++ ?x52517 (seq.++ ?x52563 ?x85668)))))))
 (let ((?x90103 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x97820 (seq.++ ?x52517 ?x66994)))))))
 (let ((?x3847 (seq.unit (_ bv255 8))))
 (let ((?x88566 (seq.++ ?x3847 (seq.++ ?x3847 (seq.++ ?x3847 (seq.++ ?x97820 (seq.++ ?x52563 ?x90103)))))))
 (let ((?x88055 (seq.++ ?x3847 (seq.++ ?x3847 (seq.++ ?x3847 ?x88566)))))
 (= input_1_L.net.frame_frame ?x88055)))))))))))))))))))
(assert
 (= 30 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x38292 (seq.unit (_ bv192 8))))
(let ((?x12626 (seq.++ ?x38292 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x52512 (seq.unit (_ bv1 8))))
(let ((?x52563 (seq.unit (_ bv0 8))))
(let ((?x65614 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52512 ?x12626)))))))
(let ((?x97820 (seq.unit (_ bv2 8))))
(let ((?x81493 (seq.++ ?x38292 (seq.++ ?x52563 (seq.++ ?x97820 (seq.++ ?x97820 (seq.++ ?x97820 ?x65614)))))))
(let ((?x89831 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x97820 ?x81493)))))))
(let ((?x74452 (seq.unit (_ bv4 8))))
(let ((?x91278 (seq.unit (_ bv6 8))))
(let ((?x88294 (seq.++ ?x91278 (seq.++ ?x74452 (seq.++ ?x52563 (seq.++ ?x97820 (seq.++ ?x97820 ?x89831)))))))
(let ((?x52517 (seq.unit (_ bv8 8))))
(let ((?x76312 (seq.++ ?x91278 (seq.++ ?x52563 (seq.++ ?x52512 (seq.++ ?x52517 (seq.++ ?x52563 ?x88294)))))))
(let ((?x78207 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x97820 (seq.++ ?x52517 ?x76312)))))))
(let ((?x418 (seq.++ ?x52563 (seq.++ ?x52563 (seq.++ ?x52512 (seq.++ ?x97820 (seq.++ ?x52563 ?x78207)))))))
(let ((?x56867 (seq.++ ?x97820 (seq.++ ?x52563 (seq.++ ?x52563 ?x418)))))
(= input_2_L.net.frame_frame ?x56867))))))))))))))))))
(check-sat)

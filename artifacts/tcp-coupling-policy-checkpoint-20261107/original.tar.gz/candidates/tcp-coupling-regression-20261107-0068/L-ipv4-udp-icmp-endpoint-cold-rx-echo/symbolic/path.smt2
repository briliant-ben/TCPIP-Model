; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x965 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x964 (= due_1_T.user due_0_T.user)))
 (let (($x963 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x962 (= due_1_L.cache due_0_L.cache)))
 (let (($x961 (= due_1_L.query due_0_L.query)))
 (let (($x960 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x959 (= active_1_T.user active_0_T.user)))
 (let (($x958 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x957 (= active_1_L.cache active_0_L.cache)))
 (let (($x956 (= active_1_L.query active_0_L.query)))
 (let (($x32369 (= v_1_T.control "CLOSED")))
 (let (($x33615 (= v_1_T.wire_flags 0)))
 (let (($x63438 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x63437 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x63436 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x63435 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x63434 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x63433 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x63432 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x33628 (= v_1_T.take 0)))
 (let (($x33629 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x33630 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x33631 (= v_1_T.snd_wnd 8)))
 (let (($x63431 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x63430 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x63429 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x218 (= v_1_T.local_window 16)))
 (let (($x33647 (= v_1_T.msl_ms 60000)))
 (let (($x33649 (= v_1_T.user_timeout_ms 30000)))
 (let (($x33912 (= v_1_T.retries 0)))
 (let (($x33914 (= v_1_T.rto_ms 1000)))
 (let (($x33916 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x33917 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x33918 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x33919 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x33920 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x33642 (= v_1_T.irs (_ bv0 32))))
 (let (($x33812 (= v_1_T.iss (_ bv1000 32))))
 (let (($x923 (= v_1_L.control "EMPTY")))
 (let (($x63428 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x63427 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63426 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63425 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x917 (= v_1_L.rxudp_disposition "deliver")))
 (let ((?x63088 (seq.unit (_ bv128 8))))
 (let ((?x2735 (seq.++ ?x63088 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x2736 (seq.++ ?x442 ?x2735)))
 (let (($x63424 (= v_1_L.rxudp_payload ?x2736)))
 (let (($x32014 (not v_1_L.rxudp_require_checksum)))
 (let (($x63417 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x2460 (= v_1_L.ip_checksum 0)))
 (let (($x2461 (= v_1_L.udp_checksum 0)))
 (let (($x2462 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2463 (= v_1_L.ip_length 0)))
 (let (($x2464 (= v_1_L.udp_length 0)))
 (let (($x63416 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x63415 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x63414 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x63413 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x63412 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x63411 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x63410 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x2486 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x2489 (= v_1_L.retry_count 0)))
 (let (($x63409 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x897 (= 0 state_1)))
 (let (($x407 (not active_0_T.time_wait)))
 (let (($x63408 (or $x407 (not (<= due_0_T.time_wait 0)))))
 (let (($x405 (not active_0_T.user)))
 (let (($x63405 (or $x405 (not (<= due_0_T.user 0)))))
 (let (($x403 (not active_0_T.rtx)))
 (let (($x63402 (or $x403 (not (<= due_0_T.rtx 0)))))
 (let (($x401 (not active_0_L.cache)))
 (let (($x63399 (or $x401 (not (<= due_0_L.cache 0)))))
 (let (($x399 (not active_0_L.query)))
 (let (($x63396 (or $x399 (not (<= due_0_L.query 0)))))
 (let (($x216 (= state_0 0)))
 (and $x216 (>= 0 now_0) $x63396 $x63399 $x63402 $x63405 $x63408 $x897 $x63409 $x2489 $x2486 v_1_L.checksums_enabled $x63410 $x63411 $x63412 $x63413 $x63414 $x63415 $x63416 $x2464 $x2463 $x2462 $x2461 $x2460 $x63417 $x32014 $x63424 $x917 $x63425 $x63426 $x63427 $x63428 (= v_1_L.echo_disposition "none") $x923 $x33812 $x33642 $x33920 $x33919 $x33918 $x33917 $x33916 (= v_1_T.tx_flags "S") $x33914 $x33912 v_1_T.active_open $x33649 $x33647 $x218 $x63429 $x63430 $x63431 $x33631 $x33630 $x33629 $x33628 $x63432 $x63433 $x63434 $x63435 $x63436 $x63437 $x63438 $x33615 (= v_1_T.wire_disposition "none") $x32369 (= v_1_ip_pending_owner "none") $x956 $x957 $x958 $x959 $x960 $x961 $x962 $x963 $x964 $x965))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x32335 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x32334 (= due_2_T.user due_1_T.user)))
 (let (($x32333 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x32332 (= due_2_L.cache due_1_L.cache)))
 (let (($x32331 (= due_2_L.query due_1_L.query)))
 (let (($x32330 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x32329 (= active_2_T.user active_1_T.user)))
 (let (($x32328 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x32327 (= active_2_L.cache active_1_L.cache)))
 (let (($x32326 (= active_2_L.query active_1_L.query)))
 (let (($x32325 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x32324 (= v_2_T.control v_1_T.control)))
 (let (($x32323 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x32322 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x32321 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x32320 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x32319 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x32318 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x32317 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x32316 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x32315 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x32314 (= v_2_T.take v_1_T.take)))
 (let (($x32313 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x32312 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x32311 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x32310 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x32309 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x32308 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x32307 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x32306 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x32305 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x32304 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x32303 (= v_2_T.retries v_1_T.retries)))
 (let (($x32302 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x32301 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x32300 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32299 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32298 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32297 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x32296 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x32295 (= v_2_T.irs v_1_T.irs)))
 (let (($x32294 (= v_2_T.iss v_1_T.iss)))
 (let (($x32293 (= v_2_L.control "EMPTY")))
 (let (($x32292 (= v_2_L.echo_disposition "reply")))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x447 (seq.++ ?x440 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x32182 (seq.++ ?x442 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x514 ?x447)))))))
 (let ((?x732 (seq.unit (_ bv64 8))))
 (let ((?x32187 (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x514 (seq.++ ?x442 ?x32182)))))))
 (let ((?x32189 (seq.++ ?x442 (seq.++ ?x442 ?x32187))))
 (let ((?x63076 (seq.unit (_ bv33 8))))
 (let ((?x726 (seq.unit (_ bv69 8))))
 (let (($x63661 (= v_2_L.echo_ip_zero (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x63076 ?x32189)))))))
 (let ((?x63088 (seq.unit (_ bv128 8))))
 (let ((?x2736 (seq.++ ?x442 (seq.++ ?x63088 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x442))))))
 (let ((?x63154 (seq.unit (_ bv205 8))))
 (let ((?x63152 (seq.unit (_ bv171 8))))
 (let ((?x63150 (seq.unit (_ bv52 8))))
 (let ((?x63148 (seq.unit (_ bv18 8))))
 (let ((?x2508 (seq.++ ?x63148 (seq.++ ?x63150 (seq.++ ?x63152 (seq.++ ?x63154 ?x2736))))))
 (let ((?x63146 (seq.unit (_ bv118 8))))
 (let ((?x63601 (seq.++ ?x442 (seq.++ ?x442 (seq.++ (seq.unit (_ bv66 8)) (seq.++ ?x63146 ?x2508))))))
 (let (($x63660 (= v_2_L.echo_icmp_wire ?x63601)))
 (let (($x63659 (= v_2_L.echo_icmp_zero (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x2508)))))))
 (let ((?x63642 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x63601)))))))
 (let ((?x63142 (seq.unit (_ bv216 8))))
 (let ((?x63647 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x63142 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63642)))))))
 (let ((?x63652 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x514 ?x63647)))))))
 (let ((?x63657 (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x63076 (seq.++ ?x442 ?x63652)))))))
 (let (($x63658 (= v_2_L.echo_reply ?x63657)))
 (let (($x32287 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32286 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32285 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x32284 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x32283 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x32282 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x32281 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x32280 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x32279 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x32278 (= v_2_L.packet v_1_L.packet)))
 (let (($x32277 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x32276 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x32275 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x32274 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32273 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x32272 (= v_2_L.payload v_1_L.payload)))
 (let (($x32271 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x32270 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x32269 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x32268 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x32267 (= 0 state_2)))
 (let (($x33693 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x2634 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x33942 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x33682 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x2520 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x923 (= v_1_L.control "EMPTY")))
 (let (($x2740 (= state_1 0)))
 (and $x2740 $x923 $x2520 $x33682 $x33942 $x2634 $x33693 $x32267 $x32268 $x32269 $x32270 $x32271 $x32272 $x32273 $x32274 $x32275 $x32276 $x32277 $x32278 $x32279 $x32280 $x32281 $x32282 $x32283 $x32284 $x32285 $x32286 $x32287 $x63658 $x63659 $x63660 $x63661 $x32292 $x32293 $x32294 $x32295 $x32296 $x32297 $x32298 $x32299 $x32300 $x32301 $x32302 $x32303 $x32304 $x32305 $x32306 $x32307 $x32308 $x32309 $x32310 $x32311 $x32312 $x32313 $x32314 $x32315 $x32316 $x32317 $x32318 $x32319 $x32320 $x32321 $x32322 $x32323 $x32324 $x32325 $x32326 $x32327 $x32328 $x32329 $x32330 $x32331 $x32332 $x32333 $x32334 $x32335)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 35 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x32153 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x442)))))
 (let ((?x32221 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32153)))))))
 (let ((?x32226 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32221)))))))
 (let ((?x63090 (seq.unit (_ bv7 8))))
 (let ((?x522 (seq.unit (_ bv255 8))))
 (let ((?x63088 (seq.unit (_ bv128 8))))
 (let ((?x63094 (seq.++ ?x442 (seq.++ ?x63088 (seq.++ ?x522 (seq.++ ?x63090 ?x32226))))))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x63098 (seq.++ ?x442 (seq.++ (seq.unit (_ bv13 8)) (seq.++ ?x440 (seq.++ (seq.unit (_ bv119 8)) ?x63094))))))
 (let ((?x732 (seq.unit (_ bv64 8))))
 (let ((?x746 (seq.unit (_ bv156 8))))
 (let ((?x744 (seq.unit (_ bv144 8))))
 (let ((?x742 (seq.unit (_ bv31 8))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x63103 (seq.++ ?x514 (seq.++ ?x742 (seq.++ ?x744 (seq.++ ?x746 (seq.++ ?x732 ?x63098)))))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x63108 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63103)))))))
 (let ((?x63112 (seq.++ (seq.unit (_ bv177 8)) (seq.++ (seq.unit (_ bv246 8)) (seq.++ ?x440 (seq.++ ?x442 ?x63108))))))
 (let ((?x734 (seq.unit (_ bv17 8))))
 (let ((?x63117 (seq.++ (seq.unit (_ bv210 8)) (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x734 ?x63112)))))))
 (let ((?x542 (seq.unit (_ bv4 8))))
 (let ((?x63076 (seq.unit (_ bv33 8))))
 (let ((?x726 (seq.unit (_ bv69 8))))
 (let ((?x63122 (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x63076 (seq.++ ?x542 ?x63117)))))))
 (let ((?x538 (seq.unit (_ bv8 8))))
 (let ((?x63127 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x538 (seq.++ ?x442 ?x63122)))))))
 (let ((?x63132 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x442 ?x63127)))))))
 (let ((?x63136 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x63132))))))
 (= input_0_L.net.frame_frame ?x63136)))))))))))))))))))))))))))))))
(assert
 (= 54 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x442 (seq.unit (_ bv0 8))))
(let ((?x32153 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x442)))))
(let ((?x32221 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32153)))))))
(let ((?x32226 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32221)))))))
(let ((?x63090 (seq.unit (_ bv7 8))))
(let ((?x522 (seq.unit (_ bv255 8))))
(let ((?x63088 (seq.unit (_ bv128 8))))
(let ((?x63094 (seq.++ ?x442 (seq.++ ?x63088 (seq.++ ?x522 (seq.++ ?x63090 ?x32226))))))
(let ((?x63154 (seq.unit (_ bv205 8))))
(let ((?x63152 (seq.unit (_ bv171 8))))
(let ((?x63150 (seq.unit (_ bv52 8))))
(let ((?x63148 (seq.unit (_ bv18 8))))
(let ((?x63146 (seq.unit (_ bv118 8))))
(let ((?x63159 (seq.++ ?x63146 (seq.++ ?x63148 (seq.++ ?x63150 (seq.++ ?x63152 (seq.++ ?x63154 ?x63094)))))))
(let ((?x63144 (seq.unit (_ bv58 8))))
(let ((?x538 (seq.unit (_ bv8 8))))
(let ((?x514 (seq.unit (_ bv1 8))))
(let ((?x444 (seq.unit (_ bv2 8))))
(let ((?x63164 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x538 (seq.++ ?x442 (seq.++ ?x63144 ?x63159)))))))
(let ((?x440 (seq.unit (_ bv192 8))))
(let ((?x63169 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x440 (seq.++ ?x442 ?x63164)))))))
(let ((?x63142 (seq.unit (_ bv216 8))))
(let ((?x63140 (seq.unit (_ bv245 8))))
(let ((?x63174 (seq.++ ?x514 (seq.++ ?x514 (seq.++ ?x63140 (seq.++ ?x63142 (seq.++ ?x440 ?x63169)))))))
(let ((?x732 (seq.unit (_ bv64 8))))
(let ((?x63076 (seq.unit (_ bv33 8))))
(let ((?x63179 (seq.++ ?x63076 (seq.++ ?x522 (seq.++ ?x522 (seq.++ ?x732 (seq.++ ?x442 ?x63174)))))))
(let ((?x726 (seq.unit (_ bv69 8))))
(let ((?x63184 (seq.++ ?x538 (seq.++ ?x442 (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 ?x63179)))))))
(let ((?x63189 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 ?x63184)))))))
(let ((?x63194 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x444 ?x63189)))))))
(let ((?x63196 (seq.++ ?x444 (seq.++ ?x442 ?x63194))))
(= input_1_L.net.frame_frame ?x63196))))))))))))))))))))))))))))))))))
(check-sat)

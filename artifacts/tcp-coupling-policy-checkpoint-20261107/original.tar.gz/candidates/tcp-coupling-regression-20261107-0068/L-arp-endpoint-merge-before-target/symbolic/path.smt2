; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x51718 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x52947 (= due_1_T.user due_0_T.user)))
 (let (($x51717 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x56624 (= due_1_L.cache 60000)))
 (let (($x51716 (= due_1_L.query due_0_L.query)))
 (let (($x445 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x51715 (= active_1_T.user active_0_T.user)))
 (let (($x63651 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x56627 (not active_1_L.query)))
 (let (($x95544 (= v_1_T.control "CLOSED")))
 (let (($x32889 (= v_1_T.wire_flags 0)))
 (let (($x56626 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x73549 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x32782 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x32781 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x32780 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x32779 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x32778 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3856 (= v_1_T.take 0)))
 (let (($x3861 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3864 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x32895 (= v_1_T.snd_wnd 8)))
 (let (($x32766 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x32763 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x32883 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x32891 (= v_1_T.local_window 16)))
 (let (($x32892 (= v_1_T.msl_ms 60000)))
 (let (($x3807 (= v_1_T.user_timeout_ms 30000)))
 (let (($x68079 (= v_1_T.retries 0)))
 (let (($x71032 (= v_1_T.rto_ms 1000)))
 (let (($x32765 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x32767 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x33013 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x12655 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x12645 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x32571 (= v_1_T.irs (_ bv0 32))))
 (let (($x3584 (= v_1_T.iss (_ bv1000 32))))
 (let (($x13007 (= v_1_L.control "RESOLVED")))
 (let (($x32876 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x32686 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x32873 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x32875 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x32874 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x95388 (not v_1_L.rxudp_require_checksum)))
 (let (($x87676 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x32771 (= v_1_L.ip_checksum 0)))
 (let (($x32687 (= v_1_L.udp_checksum 0)))
 (let (($x32772 (= v_1_L.udp_raw_checksum 0)))
 (let (($x32773 (= v_1_L.ip_length 0)))
 (let (($x32774 (= v_1_L.udp_length 0)))
 (let (($x87675 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x53182 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x3841 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x3840 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x56653 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x56652 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x84331 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x3886 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x51129 (= 0 v_1_L.retry_count)))
 (let ((?x3543 (seq.unit (_ bv0 8))))
 (let ((?x53576 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.unit (_ bv2 8))))))))
 (let ((?x3537 (seq.unit (_ bv2 8))))
 (let ((?x53577 (seq.++ ?x3537 ?x53576)))
 (let (($x56640 (= v_1_L.peer_mac ?x53577)))
 (let (($x69010 (= 0 state_1)))
 (let (($x3607 (not active_0_T.time_wait)))
 (let (($x56639 (or $x3607 (not (<= due_0_T.time_wait 0)))))
 (let (($x12991 (not active_0_T.user)))
 (let (($x3838 (or $x12991 (not (<= due_0_T.user 0)))))
 (let (($x3606 (not active_0_T.rtx)))
 (let (($x53194 (or $x3606 (not (<= due_0_T.rtx 0)))))
 (let (($x3595 (not active_0_L.cache)))
 (let (($x56645 (or $x3595 (not (<= due_0_L.cache 0)))))
 (let (($x2708 (not active_0_L.query)))
 (let (($x3874 (or $x2708 (not (<= due_0_L.query 0)))))
 (let (($x5530 (= state_0 0)))
 (and $x5530 (>= 0 now_0) $x3874 $x56645 $x53194 $x3838 $x56639 $x69010 $x56640 $x51129 $x3886 v_1_L.checksums_enabled $x84331 $x56652 $x56653 $x3840 $x3841 $x53182 $x87675 $x32774 $x32773 $x32772 $x32687 $x32771 $x87676 $x95388 $x32874 (= v_1_L.rxudp_disposition "none") $x32875 $x32873 $x32686 $x32876 (= v_1_L.echo_disposition "none") $x13007 $x3584 $x32571 $x12645 $x12655 $x33013 $x32767 $x32765 (= v_1_T.tx_flags "S") $x71032 $x68079 v_1_T.active_open $x3807 $x32892 $x32891 $x32883 $x32763 $x32766 $x32895 $x3864 $x3861 $x3856 $x32778 $x32779 $x32780 $x32781 $x32782 $x73549 $x56626 $x32889 (= v_1_T.wire_disposition "none") $x95544 (= v_1_ip_pending_owner "none") $x56627 active_1_L.cache $x63651 $x51715 $x445 $x51716 $x56624 $x51717 $x52947 $x51718))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x95216 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x95215 (= due_2_T.user due_1_T.user)))
 (let (($x95214 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x95212 (= due_2_L.query due_1_L.query)))
 (let (($x95211 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x95210 (= active_2_T.user active_1_T.user)))
 (let (($x95209 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x95207 (= active_2_L.query active_1_L.query)))
 (let (($x95206 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x95205 (= v_2_T.control v_1_T.control)))
 (let (($x95204 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x95203 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x95202 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x95201 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x95200 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x95199 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x95198 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x95197 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x95196 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x95195 (= v_2_T.take v_1_T.take)))
 (let (($x95194 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x95193 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x95192 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x95191 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x95190 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x95189 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x95188 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x95187 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x95186 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x95185 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x95184 (= v_2_T.retries v_1_T.retries)))
 (let (($x95183 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x95182 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x95181 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x95180 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x95179 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x95178 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x95177 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x95176 (= v_2_T.irs v_1_T.irs)))
 (let (($x95175 (= v_2_T.iss v_1_T.iss)))
 (let (($x95174 (= v_2_L.control "RESOLVED")))
 (let (($x95173 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x95172 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x95171 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x95170 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x95169 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x95168 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x95167 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x95166 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x95165 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x95164 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x95163 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x95162 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x95161 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x95160 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x95159 (= v_2_L.packet v_1_L.packet)))
 (let (($x95158 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x95157 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x95156 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x95155 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x95154 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x95153 (= v_2_L.payload v_1_L.payload)))
 (let (($x95152 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x95151 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x95150 (= v_2_L.retry_count v_1_L.retry_count)))
 (let ((?x3543 (seq.unit (_ bv0 8))))
 (let ((?x32986 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.unit (_ bv3 8))))))))
 (let ((?x3537 (seq.unit (_ bv2 8))))
 (let (($x56634 (= v_2_L.peer_mac (seq.++ ?x3537 ?x32986))))
 (let (($x95148 (= 0 state_2)))
 (let (($x56629 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x9472 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x87671 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x3835 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x56627 (not active_1_L.query)))
 (let (($x3836 (or $x56627 (not (<= due_1_L.query 10)))))
 (let (($x13007 (= v_1_L.control "RESOLVED")))
 (let (($x32764 (= state_1 0)))
 (and $x32764 $x13007 $x3836 $x3835 $x87671 $x9472 $x56629 $x95148 $x56634 $x95150 $x95151 $x95152 $x95153 $x95154 $x95155 $x95156 $x95157 $x95158 $x95159 $x95160 $x95161 $x95162 $x95163 $x95164 $x95165 $x95166 $x95167 $x95168 $x95169 $x95170 $x95171 $x95172 $x95173 $x95174 $x95175 $x95176 $x95177 $x95178 $x95179 $x95180 $x95181 $x95182 $x95183 $x95184 $x95185 $x95186 $x95187 $x95188 $x95189 $x95190 $x95191 $x95192 $x95193 $x95194 $x95195 $x95196 $x95197 $x95198 $x95199 $x95200 $x95201 $x95202 $x95203 $x95204 $x95205 $x95206 $x95207 active_2_L.cache $x95209 $x95210 $x95211 $x95212 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x95214 $x95215 $x95216))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x49968 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x49967 (= due_3_T.user due_2_T.user)))
 (let (($x50162 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x50161 (= due_3_L.cache due_2_L.cache)))
 (let (($x77035 (= due_3_L.query due_2_L.query)))
 (let (($x50310 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x50124 (= active_3_T.user active_2_T.user)))
 (let (($x50123 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x49991 (= active_3_L.cache active_2_L.cache)))
 (let (($x49990 (= active_3_L.query active_2_L.query)))
 (let (($x49984 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x49983 (= v_3_T.control v_2_T.control)))
 (let (($x50142 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x50141 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x50074 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x50073 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x50008 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x50007 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x50134 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x50133 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x50352 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x50351 (= v_3_T.take v_2_T.take)))
 (let (($x50076 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x50075 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x52887 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x12868 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x50315 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x50118 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x49977 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x50290 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x50216 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x50312 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x51694 (= v_3_T.retries v_2_T.retries)))
 (let (($x3520 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x50194 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x50193 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x49997 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x49996 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x50294 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x50293 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x49998 (= v_3_T.irs v_2_T.irs)))
 (let (($x50144 (= v_3_T.iss v_2_T.iss)))
 (let (($x49950 (= v_3_L.control "RESOLVED")))
 (let (($x49949 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x50097 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x50096 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x49952 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x49951 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x49993 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x49992 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x50000 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x49999 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x51696 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x12955 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x52756 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x52789 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x50125 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x50138 (= v_3_L.packet v_2_L.packet)))
 (let (($x8697 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x8813 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x50147 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x50224 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x49958 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x49957 (= v_3_L.payload v_2_L.payload)))
 (let (($x50155 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x50218 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x50205 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x50204 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x50202 (= 0 state_3)))
 (let (($x32899 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x3817 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x32900 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x83645 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x32898 (or (not active_2_L.query) (not (<= due_2_L.query 20)))))
 (let (($x95174 (= v_2_L.control "RESOLVED")))
 (let (($x3882 (= state_2 0)))
 (and $x3882 $x95174 $x32898 $x83645 $x32900 $x3817 $x32899 $x50202 $x50204 $x50205 $x50218 $x50155 $x49957 $x49958 $x50224 $x50147 $x8813 $x8697 $x50138 $x50125 $x52789 $x52756 $x12955 $x51696 $x49999 $x50000 $x49992 $x49993 $x49951 $x49952 $x50096 $x50097 $x49949 $x49950 $x50144 $x49998 $x50293 $x50294 $x49996 $x49997 $x50193 $x50194 $x3520 $x51694 $x50312 $x50216 $x50290 $x49977 $x50118 $x50315 $x12868 $x52887 $x50075 $x50076 $x50351 $x50352 $x50133 $x50134 $x50007 $x50008 $x50073 $x50074 $x50141 $x50142 $x49983 $x49984 $x49990 $x49991 $x50123 $x50124 $x50310 $x77035 $x50161 $x50162 $x49967 $x49968))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x3548 (seq.unit (_ bv192 8))))
 (let ((?x52969 (seq.++ ?x3548 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x3543 (seq.unit (_ bv0 8))))
 (let ((?x12716 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 ?x52969)))))))
 (let ((?x3537 (seq.unit (_ bv2 8))))
 (let ((?x91464 (seq.++ ?x3548 (seq.++ ?x3543 (seq.++ ?x3537 (seq.++ ?x3537 (seq.++ ?x3543 ?x12716)))))))
 (let ((?x125422 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3537 ?x91464)))))))
 (let ((?x3637 (seq.unit (_ bv1 8))))
 (let ((?x3596 (seq.unit (_ bv4 8))))
 (let ((?x32609 (seq.unit (_ bv6 8))))
 (let ((?x206 (seq.++ ?x32609 (seq.++ ?x3596 (seq.++ ?x3543 (seq.++ ?x3637 (seq.++ ?x3537 ?x125422)))))))
 (let ((?x3545 (seq.unit (_ bv8 8))))
 (let ((?x96319 (seq.++ ?x32609 (seq.++ ?x3543 (seq.++ ?x3637 (seq.++ ?x3545 (seq.++ ?x3543 ?x206)))))))
 (let ((?x53248 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3537 (seq.++ ?x3545 ?x96319)))))))
 (let ((?x52772 (seq.unit (_ bv255 8))))
 (let ((?x352 (seq.++ ?x52772 (seq.++ ?x52772 (seq.++ ?x52772 (seq.++ ?x3537 (seq.++ ?x3543 ?x53248)))))))
 (let ((?x53274 (seq.++ ?x52772 (seq.++ ?x52772 (seq.++ ?x52772 ?x352)))))
 (= input_0_L.net.frame_frame ?x53274)))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x3548 (seq.unit (_ bv192 8))))
 (let ((?x202 (seq.++ ?x3548 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x3543 (seq.unit (_ bv0 8))))
 (let ((?x91401 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 ?x202)))))))
 (let ((?x3537 (seq.unit (_ bv2 8))))
 (let ((?x97288 (seq.++ ?x3548 (seq.++ ?x3543 (seq.++ ?x3537 (seq.++ ?x3537 (seq.++ ?x3543 ?x91401)))))))
 (let ((?x91277 (seq.unit (_ bv3 8))))
 (let ((?x63642 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x91277 ?x97288)))))))
 (let ((?x3637 (seq.unit (_ bv1 8))))
 (let ((?x3596 (seq.unit (_ bv4 8))))
 (let ((?x32609 (seq.unit (_ bv6 8))))
 (let ((?x34132 (seq.++ ?x32609 (seq.++ ?x3596 (seq.++ ?x3543 (seq.++ ?x3637 (seq.++ ?x3537 ?x63642)))))))
 (let ((?x3545 (seq.unit (_ bv8 8))))
 (let ((?x91331 (seq.++ ?x32609 (seq.++ ?x3543 (seq.++ ?x3637 (seq.++ ?x3545 (seq.++ ?x3543 ?x34132)))))))
 (let ((?x91190 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x3543 (seq.++ ?x91277 (seq.++ ?x3545 ?x91331)))))))
 (let ((?x52772 (seq.unit (_ bv255 8))))
 (let ((?x53238 (seq.++ ?x52772 (seq.++ ?x52772 (seq.++ ?x52772 (seq.++ ?x3537 (seq.++ ?x3543 ?x91190)))))))
 (let ((?x52906 (seq.++ ?x52772 (seq.++ ?x52772 (seq.++ ?x52772 ?x53238)))))
 (= input_1_L.net.frame_frame ?x52906))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x3548 (seq.unit (_ bv192 8))))
(let ((?x3531 (seq.++ ?x3548 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x3531))))
(check-sat)

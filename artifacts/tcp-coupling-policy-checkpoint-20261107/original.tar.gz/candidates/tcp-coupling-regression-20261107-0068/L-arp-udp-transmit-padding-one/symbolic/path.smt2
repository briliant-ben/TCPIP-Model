; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x25366 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x25365 (= due_1_T.user due_0_T.user)))
 (let (($x25364 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x25362 (= due_1_L.cache due_0_L.cache)))
 (let (($x98208 (= due_1_L.query 1000)))
 (let (($x25360 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x25359 (= active_1_T.user active_0_T.user)))
 (let (($x25358 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x25357 (= active_1_L.cache active_0_L.cache)))
 (let (($x25355 (= v_1_ip_pending_owner "UDP")))
 (let (($x24015 (= v_1_T.control "CLOSED")))
 (let (($x102982 (= v_1_T.wire_flags 0)))
 (let (($x98207 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x98206 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x98205 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x98204 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x98203 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x98202 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x98201 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x101189 (= v_1_T.take 0)))
 (let (($x1322 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x94258 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x52347 (= v_1_T.snd_wnd 8)))
 (let (($x98200 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x98199 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x98198 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x80194 (= v_1_T.local_window 16)))
 (let (($x59671 (= v_1_T.msl_ms 60000)))
 (let (($x83539 (= v_1_T.user_timeout_ms 30000)))
 (let (($x80192 (= v_1_T.retries 0)))
 (let (($x66967 (= v_1_T.rto_ms 1000)))
 (let (($x80263 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x89084 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x89597 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x94332 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x77744 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x81641 (= v_1_T.irs (_ bv0 32))))
 (let (($x71132 (= v_1_T.iss (_ bv1000 32))))
 (let (($x25323 (= v_1_L.control "PENDING")))
 (let (($x98197 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x98196 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x98195 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x98194 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x98193 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x23863 (not v_1_L.rxudp_require_checksum)))
 (let ((?x57297 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x57302 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x57297)))))
 (let ((?x14681 (seq.unit (_ bv8 8))))
 (let ((?x14687 (seq.unit (_ bv6 8))))
 (let ((?x57310 (seq.++ ?x14687 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x14681 (seq.++ (seq.unit (_ bv9 8)) ?x57302))))))
 (let ((?x14707 (seq.unit (_ bv4 8))))
 (let ((?x1600 (seq.unit (_ bv2 8))))
 (let ((?x57317 (seq.++ ?x1600 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x14707 (seq.++ (seq.unit (_ bv5 8)) ?x57310))))))
 (let ((?x14699 (seq.unit (_ bv1 8))))
 (let ((?x1598 (seq.unit (_ bv0 8))))
 (let ((?x57323 (seq.++ ?x1598 (seq.++ ?x14699 ?x57317))))
 (let ((?x13701 (seq.unit (_ bv25 8))))
 (let ((?x57872 (seq.++ ?x1598 (seq.++ ?x13701 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv167 8)) ?x57323))))))
 (let ((?x25473 (seq.unit (_ bv144 8))))
 (let ((?x25471 (seq.unit (_ bv31 8))))
 (let ((?x25159 (seq.unit (_ bv64 8))))
 (let ((?x25475 (seq.unit (_ bv156 8))))
 (let ((?x57876 (seq.++ ?x25475 (seq.++ ?x25159 (seq.++ ?x25471 (seq.++ ?x25473 ?x57872))))))
 (let ((?x1597 (seq.unit (_ bv192 8))))
 (let ((?x98170 (seq.++ ?x14699 (seq.++ ?x1597 (seq.++ ?x1598 (seq.++ ?x1600 (seq.++ ?x1600 ?x57876)))))))
 (let ((?x98066 (seq.unit (_ bv188 8))))
 (let ((?x98064 (seq.unit (_ bv182 8))))
 (let ((?x98175 (seq.++ ?x98064 (seq.++ ?x98066 (seq.++ ?x1597 (seq.++ ?x1598 (seq.++ ?x1600 ?x98170)))))))
 (let ((?x25119 (seq.unit (_ bv17 8))))
 (let ((?x98180 (seq.++ ?x1598 (seq.++ ?x25159 (seq.++ ?x1598 (seq.++ ?x25159 (seq.++ ?x25119 ?x98175)))))))
 (let ((?x57880 (seq.unit (_ bv45 8))))
 (let ((?x25138 (seq.unit (_ bv69 8))))
 (let ((?x98185 (seq.++ ?x25138 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x57880 (seq.++ ?x1598 ?x98180)))))))
 (let (($x98192 (= v_1_L.pending_packet ?x98185)))
 (let (($x98191 (= v_1_L.ip_checksum 46780)))
 (let (($x98190 (= v_1_L.udp_checksum 30631)))
 (let (($x98189 (= v_1_L.udp_raw_checksum 30631)))
 (let (($x98188 (= v_1_L.ip_length 45)))
 (let (($x98187 (= v_1_L.udp_length 25)))
 (let (($x98186 (= v_1_L.packet ?x98185)))
 (let ((?x1460 (seq.++ ?x1600 (seq.++ ?x14699 (seq.++ ?x1597 (seq.++ ?x1598 (seq.++ ?x1600 ?x1600)))))))
 (let ((?x1462 (seq.++ ?x1597 (seq.++ ?x1598 ?x1460))))
 (let ((?x98122 (seq.++ ?x1598 (seq.++ ?x25159 (seq.++ ?x25119 (seq.++ ?x98064 (seq.++ ?x98066 ?x1462)))))))
 (let ((?x98127 (seq.++ ?x1598 (seq.++ ?x57880 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x25159 ?x98122)))))))
 (let (($x98130 (= v_1_L.ip_wire (seq.++ ?x25138 (seq.++ ?x1598 ?x98127)))))
 (let ((?x57951 (seq.++ ?x1598 (seq.++ ?x25159 (seq.++ ?x25119 (seq.++ ?x1598 (seq.++ ?x1598 ?x1462)))))))
 (let ((?x57956 (seq.++ ?x1598 (seq.++ ?x57880 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x25159 ?x57951)))))))
 (let (($x57959 (= v_1_L.ip_zero (seq.++ ?x25138 (seq.++ ?x1598 ?x57956)))))
 (let (($x57877 (= v_1_L.udp_wire ?x57876)))
 (let ((?x32675 (seq.++ ?x1600 (seq.++ ?x1600 (seq.++ ?x1598 (seq.++ ?x25119 (seq.++ ?x1598 ?x13701)))))))
 (let ((?x5562 (seq.++ ?x1598 (seq.++ ?x1600 (seq.++ ?x14699 (seq.++ ?x1597 (seq.++ ?x1598 ?x32675)))))))
 (let (($x47820 (= v_1_L.pseudoheader (seq.++ ?x1597 ?x5562))))
 (let ((?x75247 (seq.++ ?x25473 (seq.++ ?x1598 (seq.++ ?x13701 (seq.++ ?x1598 (seq.++ ?x1598 ?x57323)))))))
 (let (($x87113 (= v_1_L.udp_zero (seq.++ ?x25475 (seq.++ ?x25159 (seq.++ ?x25471 ?x75247))))))
 (let (($x45056 (= v_1_L.payload ?x57323)))
 (let (($x103055 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x25299 (= 0 v_1_L.retry_count)))
 (let (($x102931 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x25297 (= 0 state_1)))
 (let (($x1566 (not active_0_T.time_wait)))
 (let (($x30081 (or $x1566 (not (<= due_0_T.time_wait 0)))))
 (let (($x1564 (not active_0_T.user)))
 (let (($x5871 (or $x1564 (not (<= due_0_T.user 0)))))
 (let (($x1562 (not active_0_T.rtx)))
 (let (($x3468 (or $x1562 (not (<= due_0_T.rtx 0)))))
 (let (($x1560 (not active_0_L.cache)))
 (let (($x90045 (or $x1560 (not (<= due_0_L.cache 0)))))
 (let (($x1558 (not active_0_L.query)))
 (let (($x5806 (or $x1558 (not (<= due_0_L.query 0)))))
 (let (($x1382 (= state_0 0)))
 (and $x1382 (>= 0 now_0) $x5806 $x90045 $x3468 $x5871 $x30081 $x25297 $x102931 $x25299 $x103055 v_1_L.checksums_enabled $x45056 $x87113 $x47820 $x57877 $x57959 $x98130 $x98186 $x98187 $x98188 $x98189 $x98190 $x98191 $x98192 $x23863 $x98193 (= v_1_L.rxudp_disposition "none") $x98194 $x98195 $x98196 $x98197 (= v_1_L.echo_disposition "none") $x25323 $x71132 $x81641 $x77744 $x94332 $x89597 $x89084 $x80263 (= v_1_T.tx_flags "S") $x66967 $x80192 v_1_T.active_open $x83539 $x59671 $x80194 $x98198 $x98199 $x98200 $x52347 $x94258 $x1322 $x101189 $x98201 $x98202 $x98203 $x98204 $x98205 $x98206 $x98207 $x102982 (= v_1_T.wire_disposition "none") $x24015 $x25355 active_1_L.query $x25357 $x25358 $x25359 $x25360 $x98208 $x25362 $x25364 $x25365 $x25366))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x23722 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x23721 (= due_2_T.user due_1_T.user)))
 (let (($x23720 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x23718 (= due_2_L.query due_1_L.query)))
 (let (($x23717 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x23716 (= active_2_T.user active_1_T.user)))
 (let (($x23715 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x58013 (not active_2_L.query)))
 (let (($x23712 (= v_2_ip_pending_owner "none")))
 (let (($x23711 (= v_2_T.control v_1_T.control)))
 (let (($x23710 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x23709 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x23708 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x23707 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x23706 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x23705 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x23704 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x23703 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x23702 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x23701 (= v_2_T.take v_1_T.take)))
 (let (($x23700 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x23699 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x23698 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x23697 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x23696 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x23695 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x23694 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x23693 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x23692 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x23691 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x23690 (= v_2_T.retries v_1_T.retries)))
 (let (($x23689 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x23688 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x23687 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x23686 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x23685 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x23684 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x23683 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x23682 (= v_2_T.irs v_1_T.irs)))
 (let (($x23681 (= v_2_T.iss v_1_T.iss)))
 (let (($x23680 (= v_2_L.control "RESOLVED")))
 (let (($x23679 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x23678 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x23677 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x23676 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x23675 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x23674 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x23673 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x23672 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x58012 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x23670 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x23669 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x23668 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x23667 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x23666 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x23665 (= v_2_L.packet v_1_L.packet)))
 (let (($x23664 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x23663 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x23662 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x23661 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x23660 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x18906 (= v_2_L.payload v_1_L.payload)))
 (let (($x18905 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x18904 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x23659 (= 0 v_2_L.retry_count)))
 (let ((?x1598 (seq.unit (_ bv0 8))))
 (let ((?x61780 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.unit (_ bv2 8))))))))
 (let ((?x1600 (seq.unit (_ bv2 8))))
 (let ((?x61781 (seq.++ ?x1600 ?x61780)))
 (let (($x58011 (= v_2_L.peer_mac ?x61781)))
 (let (($x23657 (= 0 state_2)))
 (let (($x58010 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x58006 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x58000 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x57790 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x57535 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x23632 (seq.len v_1_L.pending_packet)))
 (let (($x23633 (<= 28 ?x23632)))
 (let (($x25323 (= v_1_L.control "PENDING")))
 (let (($x58275 (= state_1 0)))
 (and $x58275 $x25323 $x23633 $x57535 $x57790 $x58000 $x58006 $x58010 $x23657 $x58011 $x23659 $x18904 $x18905 $x18906 $x23660 $x23661 $x23662 $x23663 $x23664 $x23665 $x23666 $x23667 $x23668 $x23669 $x23670 $x58012 $x23672 $x23673 $x23674 $x23675 $x23676 $x23677 $x23678 $x23679 $x23680 $x23681 $x23682 $x23683 $x23684 $x23685 $x23686 $x23687 $x23688 $x23689 $x23690 $x23691 $x23692 $x23693 $x23694 $x23695 $x23696 $x23697 $x23698 $x23699 $x23700 $x23701 $x23702 $x23703 $x23704 $x23705 $x23706 $x23707 $x23708 $x23709 $x23710 $x23711 $x23712 $x58013 active_2_L.cache $x23715 $x23716 $x23717 $x23718 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x23720 $x23721 $x23722))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x57297 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x57302 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x57297)))))
 (let ((?x14681 (seq.unit (_ bv8 8))))
 (let ((?x14687 (seq.unit (_ bv6 8))))
 (let ((?x57310 (seq.++ ?x14687 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x14681 (seq.++ (seq.unit (_ bv9 8)) ?x57302))))))
 (let ((?x14707 (seq.unit (_ bv4 8))))
 (let ((?x1600 (seq.unit (_ bv2 8))))
 (let ((?x57317 (seq.++ ?x1600 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x14707 (seq.++ (seq.unit (_ bv5 8)) ?x57310))))))
 (let ((?x14699 (seq.unit (_ bv1 8))))
 (let ((?x1598 (seq.unit (_ bv0 8))))
 (let ((?x57323 (seq.++ ?x1598 (seq.++ ?x14699 ?x57317))))
 (= input_0_L.app.send_data ?x57323)))))))))))))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x1597 (seq.unit (_ bv192 8))))
(let ((?x25054 (seq.++ ?x1597 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x14699 (seq.unit (_ bv1 8))))
(let ((?x1598 (seq.unit (_ bv0 8))))
(let ((?x57336 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x14699 ?x25054)))))))
(let ((?x1600 (seq.unit (_ bv2 8))))
(let ((?x57344 (seq.++ ?x1597 (seq.++ ?x1598 (seq.++ ?x1600 (seq.++ ?x1600 (seq.++ ?x1600 ?x57336)))))))
(let ((?x57349 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1600 ?x57344)))))))
(let ((?x14707 (seq.unit (_ bv4 8))))
(let ((?x14687 (seq.unit (_ bv6 8))))
(let ((?x57354 (seq.++ ?x14687 (seq.++ ?x14707 (seq.++ ?x1598 (seq.++ ?x1600 (seq.++ ?x1600 ?x57349)))))))
(let ((?x14681 (seq.unit (_ bv8 8))))
(let ((?x57359 (seq.++ ?x14687 (seq.++ ?x1598 (seq.++ ?x14699 (seq.++ ?x14681 (seq.++ ?x1598 ?x57354)))))))
(let ((?x57364 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x1600 (seq.++ ?x14681 ?x57359)))))))
(let ((?x57369 (seq.++ ?x1598 (seq.++ ?x1598 (seq.++ ?x14699 (seq.++ ?x1600 (seq.++ ?x1598 ?x57364)))))))
(let ((?x57372 (seq.++ ?x1600 (seq.++ ?x1598 (seq.++ ?x1598 ?x57369)))))
(= input_1_L.net.frame_frame ?x57372))))))))))))))))))
(check-sat)

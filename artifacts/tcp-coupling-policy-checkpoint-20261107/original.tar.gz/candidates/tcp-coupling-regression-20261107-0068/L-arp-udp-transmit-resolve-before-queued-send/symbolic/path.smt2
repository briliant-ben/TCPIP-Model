; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x35692 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x37516 (= due_1_T.user due_0_T.user)))
 (let (($x30526 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x37515 (= due_1_L.cache due_0_L.cache)))
 (let (($x52987 (= due_1_L.query 1000)))
 (let (($x37514 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x50134 (= active_1_T.user active_0_T.user)))
 (let (($x37513 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x40117 (= active_1_L.cache active_0_L.cache)))
 (let (($x36182 (= v_1_T.control "CLOSED")))
 (let (($x64622 (= v_1_T.wire_flags 0)))
 (let (($x52986 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x52985 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x52984 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x52983 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x52982 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52997 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x63741 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x27567 (= v_1_T.take 0)))
 (let (($x27335 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x99145 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x27541 (= v_1_T.snd_wnd 8)))
 (let (($x12556 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x53043 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x53041 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x32870 (= v_1_T.local_window 16)))
 (let (($x47221 (= v_1_T.msl_ms 60000)))
 (let (($x1719 (= v_1_T.user_timeout_ms 30000)))
 (let (($x7334 (= v_1_T.retries 0)))
 (let (($x7335 (= v_1_T.rto_ms 1000)))
 (let (($x7333 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x7336 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x7337 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x7338 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x7339 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x7344 (= v_1_T.irs (_ bv0 32))))
 (let (($x7345 (= v_1_T.iss (_ bv1000 32))))
 (let (($x68819 (= v_1_L.control "PENDING")))
 (let (($x63102 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x1227 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x12888 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x12934 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x52942 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x36012 (not v_1_L.rxudp_require_checksum)))
 (let (($x12935 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x7360 (= v_1_L.ip_checksum 0)))
 (let (($x7361 (= v_1_L.udp_checksum 0)))
 (let (($x7364 (= v_1_L.udp_raw_checksum 0)))
 (let (($x7367 (= v_1_L.ip_length 0)))
 (let (($x7368 (= v_1_L.udp_length 0)))
 (let (($x12546 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x12545 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x12797 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x12791 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x94730 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x63109 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x12786 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x53098 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x58961 (= 0 v_1_L.retry_count)))
 (let (($x13079 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x48347 (= 0 state_1)))
 (let (($x42524 (not active_0_T.time_wait)))
 (let (($x12954 (or $x42524 (not (<= due_0_T.time_wait 0)))))
 (let (($x64654 (not active_0_T.user)))
 (let (($x13080 (or $x64654 (not (<= due_0_T.user 0)))))
 (let (($x16678 (not active_0_T.rtx)))
 (let (($x12976 (or $x16678 (not (<= due_0_T.rtx 0)))))
 (let (($x597 (not active_0_L.cache)))
 (let (($x33719 (or $x597 (not (<= due_0_L.cache 0)))))
 (let (($x64652 (not active_0_L.query)))
 (let (($x53018 (or $x64652 (not (<= due_0_L.query 0)))))
 (let (($x38353 (= state_0 0)))
 (and $x38353 (>= 0 now_0) $x53018 $x33719 $x12976 $x13080 $x12954 $x48347 $x13079 $x58961 $x53098 v_1_L.checksums_enabled $x12786 $x63109 $x94730 $x12791 $x12797 $x12545 $x12546 $x7368 $x7367 $x7364 $x7361 $x7360 $x12935 $x36012 $x52942 (= v_1_L.rxudp_disposition "none") $x12934 $x12888 $x1227 $x63102 (= v_1_L.echo_disposition "none") $x68819 $x7345 $x7344 $x7339 $x7338 $x7337 $x7336 $x7333 (= v_1_T.tx_flags "S") $x7335 $x7334 v_1_T.active_open $x1719 $x47221 $x32870 $x53041 $x53043 $x12556 $x27541 $x99145 $x27335 $x27567 $x63741 $x52997 $x52982 $x52983 $x52984 $x52985 $x52986 $x64622 (= v_1_T.wire_disposition "none") $x36182 (= v_1_ip_pending_owner "none") active_1_L.query $x40117 $x37513 $x50134 $x37514 $x52987 $x37515 $x30526 $x37516 $x35692))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x35850 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x35849 (= due_2_T.user due_1_T.user)))
 (let (($x35848 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x35847 (= due_2_L.cache due_1_L.cache)))
 (let (($x35846 (= due_2_L.query due_1_L.query)))
 (let (($x35845 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x35844 (= active_2_T.user active_1_T.user)))
 (let (($x35843 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x35842 (= active_2_L.cache active_1_L.cache)))
 (let (($x35841 (= active_2_L.query active_1_L.query)))
 (let (($x35840 (= v_2_ip_pending_owner "UDP")))
 (let (($x35839 (= v_2_T.control v_1_T.control)))
 (let (($x35838 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x35837 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x35836 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x35835 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x35834 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x35833 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x35832 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x35831 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x35830 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x35829 (= v_2_T.take v_1_T.take)))
 (let (($x35828 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x35827 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x35826 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x35825 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x35824 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x35823 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x35822 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x35821 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x35820 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x35819 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x35818 (= v_2_T.retries v_1_T.retries)))
 (let (($x35817 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x35816 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x35815 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x35814 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x35813 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x35812 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x35811 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x35810 (= v_2_T.irs v_1_T.irs)))
 (let (($x35809 (= v_2_T.iss v_1_T.iss)))
 (let (($x35808 (= v_2_L.control "PENDING")))
 (let (($x35807 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x35806 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x35805 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x35804 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x35803 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x35802 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x35801 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x35800 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let ((?x85099 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x41141 (seq.unit (_ bv0 8))))
 (let ((?x85101 (seq.++ ?x41141 ?x85099)))
 (let ((?x10561 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x74475 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x62682 (seq.unit (_ bv13 8))))
 (let ((?x10590 (seq.unit (_ bv144 8))))
 (let ((?x81639 (seq.++ ?x10590 (seq.++ ?x41141 (seq.++ ?x62682 (seq.++ ?x74475 (seq.++ ?x10561 ?x85101)))))))
 (let ((?x10594 (seq.unit (_ bv31 8))))
 (let ((?x87113 (seq.unit (_ bv64 8))))
 (let ((?x10539 (seq.unit (_ bv156 8))))
 (let ((?x13135 (seq.++ ?x10539 (seq.++ ?x87113 (seq.++ ?x10594 ?x81639)))))
 (let ((?x103043 (seq.unit (_ bv2 8))))
 (let ((?x52451 (seq.unit (_ bv192 8))))
 (let ((?x56076 (seq.unit (_ bv1 8))))
 (let ((?x79479 (seq.++ ?x56076 (seq.++ ?x52451 (seq.++ ?x41141 (seq.++ ?x103043 (seq.++ ?x103043 ?x13135)))))))
 (let ((?x72011 (seq.unit (_ bv200 8))))
 (let ((?x10646 (seq.unit (_ bv182 8))))
 (let ((?x84423 (seq.++ ?x10646 (seq.++ ?x72011 (seq.++ ?x52451 (seq.++ ?x41141 (seq.++ ?x103043 ?x79479)))))))
 (let ((?x70345 (seq.unit (_ bv17 8))))
 (let ((?x60225 (seq.++ ?x41141 (seq.++ ?x87113 (seq.++ ?x41141 (seq.++ ?x87113 (seq.++ ?x70345 ?x84423)))))))
 (let ((?x83215 (seq.unit (_ bv33 8))))
 (let ((?x69827 (seq.unit (_ bv69 8))))
 (let ((?x69240 (seq.++ ?x69827 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x83215 (seq.++ ?x41141 ?x60225)))))))
 (let (($x56800 (= v_2_L.pending_packet ?x69240)))
 (let (($x70335 (= v_2_L.ip_checksum 46792)))
 (let ((?x10559 (ite v_1_L.checksums_enabled 49271 0)))
 (let (($x66863 (= v_2_L.udp_checksum ?x10559)))
 (let (($x66864 (= v_2_L.udp_raw_checksum 49271)))
 (let (($x80008 (= v_2_L.ip_length 33)))
 (let (($x86202 (= v_2_L.udp_length 13)))
 (let (($x79711 (= v_2_L.packet ?x69240)))
 (let ((?x12770 (seq.++ ?x103043 (seq.++ ?x56076 (seq.++ ?x52451 (seq.++ ?x41141 (seq.++ ?x103043 ?x103043)))))))
 (let ((?x63118 (seq.++ ?x52451 (seq.++ ?x41141 ?x12770))))
 (let ((?x4861 (seq.++ ?x41141 (seq.++ ?x87113 (seq.++ ?x70345 (seq.++ ?x10646 (seq.++ ?x72011 ?x63118)))))))
 (let ((?x66379 (seq.++ ?x41141 (seq.++ ?x83215 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x87113 ?x4861)))))))
 (let (($x11627 (= v_2_L.ip_wire (seq.++ ?x69827 (seq.++ ?x41141 ?x66379)))))
 (let ((?x13255 (seq.++ ?x41141 (seq.++ ?x87113 (seq.++ ?x70345 (seq.++ ?x41141 (seq.++ ?x41141 ?x63118)))))))
 (let ((?x90044 (seq.++ ?x41141 (seq.++ ?x83215 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x87113 ?x13255)))))))
 (let (($x68943 (= v_2_L.ip_zero (seq.++ ?x69827 (seq.++ ?x41141 ?x90044)))))
 (let (($x13219 (= v_2_L.udp_wire ?x13135)))
 (let ((?x27341 (seq.++ ?x103043 (seq.++ ?x103043 (seq.++ ?x41141 (seq.++ ?x70345 (seq.++ ?x41141 ?x62682)))))))
 (let ((?x98897 (seq.++ ?x41141 (seq.++ ?x103043 (seq.++ ?x56076 (seq.++ ?x52451 (seq.++ ?x41141 ?x27341)))))))
 (let (($x13060 (= v_2_L.pseudoheader (seq.++ ?x52451 ?x98897))))
 (let ((?x97248 (seq.++ ?x10590 (seq.++ ?x41141 (seq.++ ?x62682 (seq.++ ?x41141 (seq.++ ?x41141 ?x85101)))))))
 (let (($x30809 (= v_2_L.udp_zero (seq.++ ?x10539 (seq.++ ?x87113 (seq.++ ?x10594 ?x97248))))))
 (let (($x52 (= v_2_L.payload ?x85101)))
 (let (($x35786 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x35785 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x35784 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x35783 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x35782 (= 0 state_2)))
 (let (($x82882 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x32183 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x91111 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x53049 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x63114 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x68819 (= v_1_L.control "PENDING")))
 (let (($x27327 (= state_1 0)))
 (and $x27327 $x68819 $x63114 $x53049 $x91111 $x32183 $x82882 $x35782 $x35783 $x35784 $x35785 $x35786 $x52 $x30809 $x13060 $x13219 $x68943 $x11627 $x79711 $x86202 $x80008 $x66864 $x66863 $x70335 $x56800 $x35800 $x35801 $x35802 $x35803 $x35804 $x35805 $x35806 $x35807 $x35808 $x35809 $x35810 $x35811 $x35812 $x35813 $x35814 $x35815 $x35816 $x35817 $x35818 $x35819 $x35820 $x35821 $x35822 $x35823 $x35824 $x35825 $x35826 $x35827 $x35828 $x35829 $x35830 $x35831 $x35832 $x35833 $x35834 $x35835 $x35836 $x35837 $x35838 $x35839 $x35840 $x35841 $x35842 $x35843 $x35844 $x35845 $x35846 $x35847 $x35848 $x35849 $x35850))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x95164 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x57118 (= due_3_T.user due_2_T.user)))
 (let (($x95163 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x95162 (= due_3_L.query due_2_L.query)))
 (let (($x95161 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x34714 (= active_3_T.user active_2_T.user)))
 (let (($x95160 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x75661 (not active_3_L.query)))
 (let (($x49944 (= v_3_ip_pending_owner "none")))
 (let (($x95158 (= v_3_T.control v_2_T.control)))
 (let (($x32688 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x95157 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x52935 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x95156 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x51128 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x95155 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x52917 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x95154 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x56634 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x32625 (= v_3_T.take v_2_T.take)))
 (let (($x95150 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x52774 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x95151 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x84656 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x95152 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x3546 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x95153 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x51703 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x52789 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x12829 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x52756 (= v_3_T.retries v_2_T.retries)))
 (let (($x5534 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x32616 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x12955 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x32597 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x53158 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x51696 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x55441 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x32610 (= v_3_T.irs v_2_T.irs)))
 (let (($x49999 (= v_3_T.iss v_2_T.iss)))
 (let (($x8724 (= v_3_L.control "RESOLVED")))
 (let (($x63080 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x53369 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x49992 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x32595 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x12658 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x49993 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x30500 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x30499 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x56971 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x30497 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x30496 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x30495 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x30494 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x30493 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x30492 (= v_3_L.packet v_2_L.packet)))
 (let (($x30491 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x30490 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x30489 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x30488 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x30487 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x30486 (= v_3_L.payload v_2_L.payload)))
 (let (($x30485 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x30484 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x30483 (= 0 v_3_L.retry_count)))
 (let ((?x41141 (seq.unit (_ bv0 8))))
 (let ((?x196 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.unit (_ bv2 8))))))))
 (let ((?x103043 (seq.unit (_ bv2 8))))
 (let ((?x101920 (seq.++ ?x103043 ?x196)))
 (let (($x13104 (= v_3_L.peer_mac ?x101920)))
 (let (($x30481 (= 0 state_3)))
 (let (($x13103 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 10)))))
 (let (($x4856 (or (not active_2_T.user) (not (<= due_2_T.user 10)))))
 (let (($x75239 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 10)))))
 (let (($x89127 (or (not active_2_L.cache) (not (<= due_2_L.cache 10)))))
 (let (($x73149 (or (not active_2_L.query) (not (<= due_2_L.query 10)))))
 (let ((?x2307 (seq.len v_2_L.pending_packet)))
 (let (($x2308 (<= 28 ?x2307)))
 (let (($x35808 (= v_2_L.control "PENDING")))
 (let (($x12941 (= state_2 0)))
 (and $x12941 $x35808 $x2308 $x73149 $x89127 $x75239 $x4856 $x13103 $x30481 $x13104 $x30483 $x30484 $x30485 $x30486 $x30487 $x30488 $x30489 $x30490 $x30491 $x30492 $x30493 $x30494 $x30495 $x30496 $x30497 $x56971 $x30499 $x30500 $x49993 $x12658 $x32595 $x49992 $x53369 $x63080 $x8724 $x49999 $x32610 $x55441 $x51696 $x53158 $x32597 $x12955 $x32616 $x5534 $x52756 $x12829 $x52789 $x51703 $x95153 $x3546 $x95152 $x84656 $x95151 $x52774 $x95150 $x32625 $x56634 $x95154 $x52917 $x95155 $x51128 $x95156 $x52935 $x95157 $x32688 $x95158 $x49944 $x75661 active_3_L.cache $x95160 $x34714 $x95161 $x95162 (= due_3_L.cache (+ 10 v_2_L.cache_ttl_ms)) $x95163 $x57118 $x95164))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x52451 (seq.unit (_ bv192 8))))
 (let ((?x41355 (seq.++ ?x52451 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x41355))))
(assert
 (= 20 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x85099 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x41141 (seq.unit (_ bv0 8))))
 (let ((?x85101 (seq.++ ?x41141 ?x85099)))
 (= input_1_L.app.send_data ?x85101)))))
(assert
 (= 29 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x52451 (seq.unit (_ bv192 8))))
(let ((?x13261 (seq.++ ?x52451 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x56076 (seq.unit (_ bv1 8))))
(let ((?x41141 (seq.unit (_ bv0 8))))
(let ((?x3737 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x56076 ?x13261)))))))
(let ((?x103043 (seq.unit (_ bv2 8))))
(let ((?x82564 (seq.++ ?x52451 (seq.++ ?x41141 (seq.++ ?x103043 (seq.++ ?x103043 (seq.++ ?x103043 ?x3737)))))))
(let ((?x10524 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x103043 ?x82564)))))))
(let ((?x10625 (seq.unit (_ bv4 8))))
(let ((?x59497 (seq.unit (_ bv6 8))))
(let ((?x21337 (seq.++ ?x59497 (seq.++ ?x10625 (seq.++ ?x41141 (seq.++ ?x103043 (seq.++ ?x103043 ?x10524)))))))
(let ((?x2766 (seq.unit (_ bv8 8))))
(let ((?x70200 (seq.++ ?x59497 (seq.++ ?x41141 (seq.++ ?x56076 (seq.++ ?x2766 (seq.++ ?x41141 ?x21337)))))))
(let ((?x26605 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x103043 (seq.++ ?x2766 ?x70200)))))))
(let ((?x10500 (seq.++ ?x41141 (seq.++ ?x41141 (seq.++ ?x56076 (seq.++ ?x103043 (seq.++ ?x41141 ?x26605)))))))
(let ((?x87983 (seq.++ ?x103043 (seq.++ ?x41141 (seq.++ ?x41141 ?x10500)))))
(= input_2_L.net.frame_frame ?x87983))))))))))))))))))
(check-sat)

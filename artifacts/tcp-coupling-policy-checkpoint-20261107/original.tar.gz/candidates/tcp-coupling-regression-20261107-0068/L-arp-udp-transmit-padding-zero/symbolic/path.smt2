; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x102890 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x103973 (= due_1_T.user due_0_T.user)))
 (let (($x52337 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x27439 (= due_1_L.cache due_0_L.cache)))
 (let (($x98146 (= due_1_L.query 1000)))
 (let (($x57519 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x57522 (= active_1_T.user active_0_T.user)))
 (let (($x58073 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x58068 (= active_1_L.cache active_0_L.cache)))
 (let (($x58059 (= v_1_ip_pending_owner "UDP")))
 (let (($x45064 (= v_1_T.control "CLOSED")))
 (let (($x23529 (= v_1_T.wire_flags 0)))
 (let (($x98145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x98117 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x98116 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x32813 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x32680 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x1511 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x30771 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x53235 (= v_1_T.take 0)))
 (let (($x30382 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x30345 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x53234 (= v_1_T.snd_wnd 8)))
 (let (($x62648 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x69346 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x1413 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x103966 (= v_1_T.local_window 16)))
 (let (($x103960 (= v_1_T.msl_ms 60000)))
 (let (($x51725 (= v_1_T.user_timeout_ms 30000)))
 (let (($x5821 (= v_1_T.retries 0)))
 (let (($x103959 (= v_1_T.rto_ms 1000)))
 (let (($x5822 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x65242 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x56080 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x24904 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x96555 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x111 (= v_1_T.irs (_ bv0 32))))
 (let (($x102976 (= v_1_T.iss (_ bv1000 32))))
 (let (($x61335 (= v_1_L.control "PENDING")))
 (let (($x61341 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x52468 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x60215 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x86131 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x96641 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x46208 (not v_1_L.rxudp_require_checksum)))
 (let ((?x57387 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x56152 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x57387)))))
 (let ((?x24972 (seq.unit (_ bv8 8))))
 (let ((?x57933 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x24972 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x56152))))))
 (let ((?x1346 (seq.unit (_ bv6 8))))
 (let ((?x23684 (seq.unit (_ bv4 8))))
 (let ((?x35816 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x23684 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x1346 ?x57933))))))
 (let ((?x58003 (seq.unit (_ bv2 8))))
 (let ((?x24964 (seq.unit (_ bv1 8))))
 (let ((?x58005 (seq.unit (_ bv0 8))))
 (let ((?x101907 (seq.++ ?x58005 (seq.++ ?x24964 (seq.++ ?x58003 ?x35816)))))
 (let ((?x103107 (seq.unit (_ bv26 8))))
 (let ((?x81914 (seq.++ ?x58005 (seq.++ ?x103107 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv148 8)) ?x101907))))))
 (let ((?x1620 (seq.unit (_ bv144 8))))
 (let ((?x1617 (seq.unit (_ bv31 8))))
 (let ((?x98189 (seq.unit (_ bv64 8))))
 (let ((?x1622 (seq.unit (_ bv156 8))))
 (let ((?x57546 (seq.++ ?x1622 (seq.++ ?x98189 (seq.++ ?x1617 (seq.++ ?x1620 ?x81914))))))
 (let ((?x25005 (seq.unit (_ bv192 8))))
 (let ((?x1519 (seq.++ ?x24964 (seq.++ ?x25005 (seq.++ ?x58005 (seq.++ ?x58003 (seq.++ ?x58003 ?x57546)))))))
 (let ((?x57816 (seq.unit (_ bv187 8))))
 (let ((?x41316 (seq.unit (_ bv182 8))))
 (let ((?x58031 (seq.++ ?x41316 (seq.++ ?x57816 (seq.++ ?x25005 (seq.++ ?x58005 (seq.++ ?x58003 ?x1519)))))))
 (let ((?x5806 (seq.unit (_ bv17 8))))
 (let ((?x98072 (seq.++ ?x58005 (seq.++ ?x98189 (seq.++ ?x58005 (seq.++ ?x98189 (seq.++ ?x5806 ?x58031)))))))
 (let ((?x88055 (seq.unit (_ bv46 8))))
 (let ((?x24937 (seq.unit (_ bv69 8))))
 (let ((?x98138 (seq.++ ?x24937 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x88055 (seq.++ ?x58005 ?x98072)))))))
 (let (($x102828 (= v_1_L.pending_packet ?x98138)))
 (let (($x57541 (= v_1_L.ip_checksum 46779)))
 (let (($x57540 (= v_1_L.udp_checksum 30612)))
 (let (($x57992 (= v_1_L.udp_raw_checksum 30612)))
 (let (($x57807 (= v_1_L.ip_length 46)))
 (let (($x30029 (= v_1_L.udp_length 26)))
 (let (($x30028 (= v_1_L.packet ?x98138)))
 (let ((?x1531 (seq.++ ?x58003 (seq.++ ?x24964 (seq.++ ?x25005 (seq.++ ?x58005 (seq.++ ?x58003 ?x58003)))))))
 (let ((?x1529 (seq.++ ?x25005 (seq.++ ?x58005 ?x1531))))
 (let ((?x97954 (seq.++ ?x58005 (seq.++ ?x98189 (seq.++ ?x5806 (seq.++ ?x41316 (seq.++ ?x57816 ?x1529)))))))
 (let ((?x57395 (seq.++ ?x58005 (seq.++ ?x88055 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x98189 ?x97954)))))))
 (let (($x57931 (= v_1_L.ip_wire (seq.++ ?x24937 (seq.++ ?x58005 ?x57395)))))
 (let ((?x98049 (seq.++ ?x58005 (seq.++ ?x98189 (seq.++ ?x5806 (seq.++ ?x58005 (seq.++ ?x58005 ?x1529)))))))
 (let ((?x57764 (seq.++ ?x58005 (seq.++ ?x88055 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x98189 ?x98049)))))))
 (let (($x57767 (= v_1_L.ip_zero (seq.++ ?x24937 (seq.++ ?x58005 ?x57764)))))
 (let (($x57547 (= v_1_L.udp_wire ?x57546)))
 (let ((?x53136 (seq.++ ?x58003 (seq.++ ?x58003 (seq.++ ?x58005 (seq.++ ?x5806 (seq.++ ?x58005 ?x103107)))))))
 (let ((?x63076 (seq.++ ?x58005 (seq.++ ?x58003 (seq.++ ?x24964 (seq.++ ?x25005 (seq.++ ?x58005 ?x53136)))))))
 (let (($x29934 (= v_1_L.pseudoheader (seq.++ ?x25005 ?x63076))))
 (let ((?x1542 (seq.++ ?x1620 (seq.++ ?x58005 (seq.++ ?x103107 (seq.++ ?x58005 (seq.++ ?x58005 ?x101907)))))))
 (let (($x1537 (= v_1_L.udp_zero (seq.++ ?x1622 (seq.++ ?x98189 (seq.++ ?x1617 ?x1542))))))
 (let (($x18893 (= v_1_L.payload ?x101907)))
 (let (($x45161 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x83631 (= 0 v_1_L.retry_count)))
 (let (($x23635 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x57451 (= 0 state_1)))
 (let (($x1408 (not active_0_T.time_wait)))
 (let (($x23634 (or $x1408 (not (<= due_0_T.time_wait 0)))))
 (let (($x1409 (not active_0_T.user)))
 (let (($x23616 (or $x1409 (not (<= due_0_T.user 0)))))
 (let (($x1412 (not active_0_T.rtx)))
 (let (($x52543 (or $x1412 (not (<= due_0_T.rtx 0)))))
 (let (($x1414 (not active_0_L.cache)))
 (let (($x91362 (or $x1414 (not (<= due_0_L.cache 0)))))
 (let (($x1416 (not active_0_L.query)))
 (let (($x97433 (or $x1416 (not (<= due_0_L.query 0)))))
 (let (($x52874 (= state_0 0)))
 (and $x52874 (>= 0 now_0) $x97433 $x91362 $x52543 $x23616 $x23634 $x57451 $x23635 $x83631 $x45161 v_1_L.checksums_enabled $x18893 $x1537 $x29934 $x57547 $x57767 $x57931 $x30028 $x30029 $x57807 $x57992 $x57540 $x57541 $x102828 $x46208 $x96641 (= v_1_L.rxudp_disposition "none") $x86131 $x60215 $x52468 $x61341 (= v_1_L.echo_disposition "none") $x61335 $x102976 $x111 $x96555 $x24904 $x56080 $x65242 $x5822 (= v_1_T.tx_flags "S") $x103959 $x5821 v_1_T.active_open $x51725 $x103960 $x103966 $x1413 $x69346 $x62648 $x53234 $x30345 $x30382 $x53235 $x30771 $x1511 $x32680 $x32813 $x98116 $x98117 $x98145 $x23529 (= v_1_T.wire_disposition "none") $x45064 $x58059 active_1_L.query $x58068 $x58073 $x57522 $x57519 $x98146 $x27439 $x52337 $x103973 $x102890))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x18802 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x46073 (= due_2_T.user due_1_T.user)))
 (let (($x46072 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x46070 (= due_2_L.query due_1_L.query)))
 (let (($x46069 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x46068 (= active_2_T.user active_1_T.user)))
 (let (($x46067 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x9419 (not active_2_L.query)))
 (let (($x46064 (= v_2_ip_pending_owner "none")))
 (let (($x46063 (= v_2_T.control v_1_T.control)))
 (let (($x46062 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x46061 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x46060 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x46059 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x46058 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x46057 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x46056 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x46055 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x46054 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x46053 (= v_2_T.take v_1_T.take)))
 (let (($x46052 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x46051 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x46050 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x46049 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x46048 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x46047 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x46046 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x46045 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x46044 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x46043 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x46042 (= v_2_T.retries v_1_T.retries)))
 (let (($x46041 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x46040 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x46039 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x46038 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x46037 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x46036 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x46035 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x46034 (= v_2_T.irs v_1_T.irs)))
 (let (($x46033 (= v_2_T.iss v_1_T.iss)))
 (let (($x46032 (= v_2_L.control "RESOLVED")))
 (let (($x46031 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x46030 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x46029 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x46028 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x46027 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x46026 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x46025 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x46024 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x3311 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x46022 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x46021 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x46020 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x46019 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x46018 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x46017 (= v_2_L.packet v_1_L.packet)))
 (let (($x46016 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x46015 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x46014 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x46013 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x46012 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x46011 (= v_2_L.payload v_1_L.payload)))
 (let (($x46010 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x46009 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x46008 (= 0 v_2_L.retry_count)))
 (let ((?x58005 (seq.unit (_ bv0 8))))
 (let ((?x61539 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.unit (_ bv2 8))))))))
 (let ((?x58003 (seq.unit (_ bv2 8))))
 (let ((?x61540 (seq.++ ?x58003 ?x61539)))
 (let (($x84577 (= v_2_L.peer_mac ?x61540)))
 (let (($x46006 (= 0 state_2)))
 (let (($x1465 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x97912 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x97907 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x35736 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x98101 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x45963 (seq.len v_1_L.pending_packet)))
 (let (($x45964 (<= 28 ?x45963)))
 (let (($x61335 (= v_1_L.control "PENDING")))
 (let (($x55501 (= state_1 0)))
 (and $x55501 $x61335 $x45964 $x98101 $x35736 $x97907 $x97912 $x1465 $x46006 $x84577 $x46008 $x46009 $x46010 $x46011 $x46012 $x46013 $x46014 $x46015 $x46016 $x46017 $x46018 $x46019 $x46020 $x46021 $x46022 $x3311 $x46024 $x46025 $x46026 $x46027 $x46028 $x46029 $x46030 $x46031 $x46032 $x46033 $x46034 $x46035 $x46036 $x46037 $x46038 $x46039 $x46040 $x46041 $x46042 $x46043 $x46044 $x46045 $x46046 $x46047 $x46048 $x46049 $x46050 $x46051 $x46052 $x46053 $x46054 $x46055 $x46056 $x46057 $x46058 $x46059 $x46060 $x46061 $x46062 $x46063 $x46064 $x9419 active_2_L.cache $x46067 $x46068 $x46069 $x46070 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x46072 $x46073 $x18802))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x57387 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x56152 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x57387)))))
 (let ((?x24972 (seq.unit (_ bv8 8))))
 (let ((?x57933 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x24972 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x56152))))))
 (let ((?x1346 (seq.unit (_ bv6 8))))
 (let ((?x23684 (seq.unit (_ bv4 8))))
 (let ((?x35816 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x23684 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x1346 ?x57933))))))
 (let ((?x58003 (seq.unit (_ bv2 8))))
 (let ((?x24964 (seq.unit (_ bv1 8))))
 (let ((?x58005 (seq.unit (_ bv0 8))))
 (let ((?x101907 (seq.++ ?x58005 (seq.++ ?x24964 (seq.++ ?x58003 ?x35816)))))
 (= input_0_L.app.send_data ?x101907)))))))))))))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x25005 (seq.unit (_ bv192 8))))
(let ((?x24990 (seq.++ ?x25005 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x24964 (seq.unit (_ bv1 8))))
(let ((?x58005 (seq.unit (_ bv0 8))))
(let ((?x96636 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x24964 ?x24990)))))))
(let ((?x58003 (seq.unit (_ bv2 8))))
(let ((?x57939 (seq.++ ?x25005 (seq.++ ?x58005 (seq.++ ?x58003 (seq.++ ?x58003 (seq.++ ?x58003 ?x96636)))))))
(let ((?x57756 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58003 ?x57939)))))))
(let ((?x23684 (seq.unit (_ bv4 8))))
(let ((?x1346 (seq.unit (_ bv6 8))))
(let ((?x57936 (seq.++ ?x1346 (seq.++ ?x23684 (seq.++ ?x58005 (seq.++ ?x58003 (seq.++ ?x58003 ?x57756)))))))
(let ((?x24972 (seq.unit (_ bv8 8))))
(let ((?x97980 (seq.++ ?x1346 (seq.++ ?x58005 (seq.++ ?x24964 (seq.++ ?x24972 (seq.++ ?x58005 ?x57936)))))))
(let ((?x57555 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x58003 (seq.++ ?x24972 ?x97980)))))))
(let ((?x57560 (seq.++ ?x58005 (seq.++ ?x58005 (seq.++ ?x24964 (seq.++ ?x58003 (seq.++ ?x58005 ?x57555)))))))
(let ((?x57563 (seq.++ ?x58003 (seq.++ ?x58005 (seq.++ ?x58005 ?x57560)))))
(= input_1_L.net.frame_frame ?x57563))))))))))))))))))
(check-sat)

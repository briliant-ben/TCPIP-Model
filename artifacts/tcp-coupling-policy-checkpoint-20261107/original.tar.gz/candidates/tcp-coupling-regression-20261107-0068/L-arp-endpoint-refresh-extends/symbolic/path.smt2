; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x63423 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x32153 (= due_1_T.user due_0_T.user)))
 (let (($x30575 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x3882 (= due_1_L.cache 60000)))
 (let (($x48579 (= due_1_L.query due_0_L.query)))
 (let (($x33000 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x56160 (= active_1_T.user active_0_T.user)))
 (let (($x56157 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x45166 (not active_1_L.query)))
 (let (($x58642 (= v_1_T.control "CLOSED")))
 (let (($x51144 (= v_1_T.wire_flags 0)))
 (let (($x55796 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x55795 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x55798 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x55797 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x55835 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x55790 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x55789 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x55872 (= v_1_T.take 0)))
 (let (($x45154 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x5554 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x130 (= v_1_T.snd_wnd 8)))
 (let (($x52906 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x97833 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x97832 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x55873 (= v_1_T.local_window 16)))
 (let (($x55874 (= v_1_T.msl_ms 60000)))
 (let (($x48605 (= v_1_T.user_timeout_ms 30000)))
 (let (($x45143 (= v_1_T.retries 0)))
 (let (($x45173 (= v_1_T.rto_ms 1000)))
 (let (($x95147 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x55875 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x55876 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x55877 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x55878 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x55879 (= v_1_T.irs (_ bv0 32))))
 (let (($x55880 (= v_1_T.iss (_ bv1000 32))))
 (let (($x53196 (= v_1_L.control "RESOLVED")))
 (let (($x55824 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x55823 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x55811 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x55810 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x97847 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x58480 (not v_1_L.rxudp_require_checksum)))
 (let (($x97846 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x46993 (= v_1_L.ip_checksum 0)))
 (let (($x46991 (= v_1_L.udp_checksum 0)))
 (let (($x46992 (= v_1_L.udp_raw_checksum 0)))
 (let (($x46995 (= v_1_L.ip_length 0)))
 (let (($x47002 (= v_1_L.udp_length 0)))
 (let (($x97830 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x47013 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x47012 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x32870 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x55819 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x55816 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x55815 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x47006 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x48591 (= 0 v_1_L.retry_count)))
 (let ((?x56103 (seq.unit (_ bv0 8))))
 (let ((?x32874 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.unit (_ bv2 8))))))))
 (let ((?x2619 (seq.unit (_ bv2 8))))
 (let ((?x3586 (seq.++ ?x2619 ?x32874)))
 (let (($x45141 (= v_1_L.peer_mac ?x3586)))
 (let (($x53089 (= 0 state_1)))
 (let (($x45179 (not active_0_T.time_wait)))
 (let (($x56269 (or $x45179 (not (<= due_0_T.time_wait 0)))))
 (let (($x30603 (not active_0_T.user)))
 (let (($x91334 (or $x30603 (not (<= due_0_T.user 0)))))
 (let (($x91317 (not active_0_T.rtx)))
 (let (($x91105 (or $x91317 (not (<= due_0_T.rtx 0)))))
 (let (($x45177 (not active_0_L.cache)))
 (let (($x97816 (or $x45177 (not (<= due_0_L.cache 0)))))
 (let (($x96319 (not active_0_L.query)))
 (let (($x97855 (or $x96319 (not (<= due_0_L.query 0)))))
 (let (($x46844 (= state_0 0)))
 (and $x46844 (>= 0 now_0) $x97855 $x97816 $x91105 $x91334 $x56269 $x53089 $x45141 $x48591 $x47006 v_1_L.checksums_enabled $x55815 $x55816 $x55819 $x32870 $x47012 $x47013 $x97830 $x47002 $x46995 $x46992 $x46991 $x46993 $x97846 $x58480 $x97847 (= v_1_L.rxudp_disposition "none") $x55810 $x55811 $x55823 $x55824 (= v_1_L.echo_disposition "none") $x53196 $x55880 $x55879 $x55878 $x55877 $x55876 $x55875 $x95147 (= v_1_T.tx_flags "S") $x45173 $x45143 v_1_T.active_open $x48605 $x55874 $x55873 $x97832 $x97833 $x52906 $x130 $x5554 $x45154 $x55872 $x55789 $x55790 $x55835 $x55797 $x55798 $x55795 $x55796 $x51144 (= v_1_T.wire_disposition "none") $x58642 (= v_1_ip_pending_owner "none") $x45166 active_1_L.cache $x56157 $x56160 $x33000 $x48579 $x3882 $x30575 $x32153 $x63423))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x58308 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x58307 (= due_2_T.user due_1_T.user)))
 (let (($x58306 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x58304 (= due_2_L.query due_1_L.query)))
 (let (($x58303 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x58302 (= active_2_T.user active_1_T.user)))
 (let (($x58301 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x58299 (= active_2_L.query active_1_L.query)))
 (let (($x58298 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x58297 (= v_2_T.control v_1_T.control)))
 (let (($x58296 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x58295 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x58294 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x58293 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x58292 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x58291 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x58290 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x58289 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x58288 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x58287 (= v_2_T.take v_1_T.take)))
 (let (($x58286 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x58285 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x58284 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x58283 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x58282 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x58281 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x58280 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x58279 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x58278 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x58277 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x58276 (= v_2_T.retries v_1_T.retries)))
 (let (($x58275 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x58274 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x58273 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x58272 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x58271 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x58270 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x58269 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x58268 (= v_2_T.irs v_1_T.irs)))
 (let (($x58267 (= v_2_T.iss v_1_T.iss)))
 (let (($x58266 (= v_2_L.control "RESOLVED")))
 (let (($x58265 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x58264 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x58263 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x58262 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x58261 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x58260 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x58259 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x58258 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x58257 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x58256 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x58255 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x58254 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x58253 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x58252 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x58251 (= v_2_L.packet v_1_L.packet)))
 (let (($x58250 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x58249 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x58248 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x58247 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x58246 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x58245 (= v_2_L.payload v_1_L.payload)))
 (let (($x58244 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x58243 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x58242 (= v_2_L.retry_count v_1_L.retry_count)))
 (let ((?x56103 (seq.unit (_ bv0 8))))
 (let ((?x55842 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.unit (_ bv3 8))))))))
 (let ((?x2619 (seq.unit (_ bv2 8))))
 (let (($x55808 (= v_2_L.peer_mac (seq.++ ?x2619 ?x55842))))
 (let (($x58240 (= 0 state_2)))
 (let (($x55807 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 59999)))))
 (let (($x55799 (or (not active_1_T.user) (not (<= due_1_T.user 59999)))))
 (let (($x55791 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 59999)))))
 (let (($x45147 (or (not active_1_L.cache) (not (<= due_1_L.cache 59999)))))
 (let (($x45166 (not active_1_L.query)))
 (let (($x30587 (or $x45166 (not (<= due_1_L.query 59999)))))
 (let (($x53196 (= v_1_L.control "RESOLVED")))
 (let (($x51148 (= state_1 0)))
 (and $x51148 $x53196 $x30587 $x45147 $x55791 $x55799 $x55807 $x58240 $x55808 $x58242 $x58243 $x58244 $x58245 $x58246 $x58247 $x58248 $x58249 $x58250 $x58251 $x58252 $x58253 $x58254 $x58255 $x58256 $x58257 $x58258 $x58259 $x58260 $x58261 $x58262 $x58263 $x58264 $x58265 $x58266 $x58267 $x58268 $x58269 $x58270 $x58271 $x58272 $x58273 $x58274 $x58275 $x58276 $x58277 $x58278 $x58279 $x58280 $x58281 $x58282 $x58283 $x58284 $x58285 $x58286 $x58287 $x58288 $x58289 $x58290 $x58291 $x58292 $x58293 $x58294 $x58295 $x58296 $x58297 $x58298 $x58299 active_2_L.cache $x58301 $x58302 $x58303 $x58304 (= due_2_L.cache (+ 59999 v_1_L.cache_ttl_ms)) $x58306 $x58307 $x58308))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x43500 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x43499 (= due_3_T.user due_2_T.user)))
 (let (($x43498 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x43497 (= due_3_L.cache due_2_L.cache)))
 (let (($x43496 (= due_3_L.query due_2_L.query)))
 (let (($x43495 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x43494 (= active_3_T.user active_2_T.user)))
 (let (($x43493 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x43492 (= active_3_L.cache active_2_L.cache)))
 (let (($x43491 (= active_3_L.query active_2_L.query)))
 (let (($x43490 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x43489 (= v_3_T.control v_2_T.control)))
 (let (($x43488 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x43487 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x43486 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x43485 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x43484 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x43483 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x43482 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x43481 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x43480 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x43479 (= v_3_T.take v_2_T.take)))
 (let (($x43478 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x43477 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x43476 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x43475 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x43474 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x43473 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x43472 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x43471 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x43470 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x43469 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x43468 (= v_3_T.retries v_2_T.retries)))
 (let (($x43467 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x43466 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x43465 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x43464 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x43463 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x43462 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x43461 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x43460 (= v_3_T.irs v_2_T.irs)))
 (let (($x43459 (= v_3_T.iss v_2_T.iss)))
 (let (($x43458 (= v_3_L.control "RESOLVED")))
 (let (($x43457 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x43456 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x43455 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x43454 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x43453 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x43452 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x43451 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x43450 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x43449 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x43448 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x43447 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x43446 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x43445 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x43444 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x43443 (= v_3_L.packet v_2_L.packet)))
 (let (($x43442 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x43441 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x43440 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x43439 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x43438 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x43437 (= v_3_L.payload v_2_L.payload)))
 (let (($x43436 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x43435 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x43434 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x43433 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x43432 (= 0 state_3)))
 (let (($x97821 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 60001)))))
 (let (($x97843 (or (not active_2_T.user) (not (<= due_2_T.user 60001)))))
 (let (($x97818 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 60001)))))
 (let (($x97809 (or (not active_2_L.cache) (not (<= due_2_L.cache 60001)))))
 (let (($x97820 (or (not active_2_L.query) (not (<= due_2_L.query 60001)))))
 (let (($x58266 (= v_2_L.control "RESOLVED")))
 (let (($x97871 (= state_2 0)))
 (and $x97871 $x58266 $x97820 $x97809 $x97818 $x97843 $x97821 $x43432 $x43433 $x43434 $x43435 $x43436 $x43437 $x43438 $x43439 $x43440 $x43441 $x43442 $x43443 $x43444 $x43445 $x43446 $x43447 $x43448 $x43449 $x43450 $x43451 $x43452 $x43453 $x43454 $x43455 $x43456 $x43457 $x43458 $x43459 $x43460 $x43461 $x43462 $x43463 $x43464 $x43465 $x43466 $x43467 $x43468 $x43469 $x43470 $x43471 $x43472 $x43473 $x43474 $x43475 $x43476 $x43477 $x43478 $x43479 $x43480 $x43481 $x43482 $x43483 $x43484 $x43485 $x43486 $x43487 $x43488 $x43489 $x43490 $x43491 $x43492 $x43493 $x43494 $x43495 $x43496 $x43497 $x43498 $x43499 $x43500))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x50133 (seq.unit (_ bv192 8))))
 (let ((?x56119 (seq.++ ?x50133 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x30506 (seq.unit (_ bv1 8))))
 (let ((?x56103 (seq.unit (_ bv0 8))))
 (let ((?x56599 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x30506 ?x56119)))))))
 (let ((?x2619 (seq.unit (_ bv2 8))))
 (let ((?x90296 (seq.++ ?x50133 (seq.++ ?x56103 (seq.++ ?x2619 (seq.++ ?x2619 (seq.++ ?x2619 ?x56599)))))))
 (let ((?x85685 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x2619 ?x90296)))))))
 (let ((?x25629 (seq.unit (_ bv4 8))))
 (let ((?x25628 (seq.unit (_ bv6 8))))
 (let ((?x73930 (seq.++ ?x25628 (seq.++ ?x25629 (seq.++ ?x56103 (seq.++ ?x2619 (seq.++ ?x2619 ?x85685)))))))
 (let ((?x25627 (seq.unit (_ bv8 8))))
 (let ((?x78368 (seq.++ ?x25628 (seq.++ ?x56103 (seq.++ ?x30506 (seq.++ ?x25627 (seq.++ ?x56103 ?x73930)))))))
 (let ((?x83067 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x2619 (seq.++ ?x25627 ?x78368)))))))
 (let ((?x69466 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x30506 (seq.++ ?x2619 (seq.++ ?x56103 ?x83067)))))))
 (let ((?x88225 (seq.++ ?x2619 (seq.++ ?x56103 (seq.++ ?x56103 ?x69466)))))
 (= input_0_L.net.frame_frame ?x88225))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 59999 now_2))
(assert
 (let ((?x50133 (seq.unit (_ bv192 8))))
 (let ((?x61330 (seq.++ ?x50133 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x56103 (seq.unit (_ bv0 8))))
 (let ((?x25658 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 ?x61330)))))))
 (let ((?x2619 (seq.unit (_ bv2 8))))
 (let ((?x56124 (seq.++ ?x50133 (seq.++ ?x56103 (seq.++ ?x2619 (seq.++ ?x2619 (seq.++ ?x56103 ?x25658)))))))
 (let ((?x78761 (seq.unit (_ bv3 8))))
 (let ((?x77735 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x78761 ?x56124)))))))
 (let ((?x30506 (seq.unit (_ bv1 8))))
 (let ((?x25629 (seq.unit (_ bv4 8))))
 (let ((?x25628 (seq.unit (_ bv6 8))))
 (let ((?x46816 (seq.++ ?x25628 (seq.++ ?x25629 (seq.++ ?x56103 (seq.++ ?x30506 (seq.++ ?x2619 ?x77735)))))))
 (let ((?x25627 (seq.unit (_ bv8 8))))
 (let ((?x90291 (seq.++ ?x25628 (seq.++ ?x56103 (seq.++ ?x30506 (seq.++ ?x25627 (seq.++ ?x56103 ?x46816)))))))
 (let ((?x88635 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x56103 (seq.++ ?x78761 (seq.++ ?x25627 ?x90291)))))))
 (let ((?x30505 (seq.unit (_ bv255 8))))
 (let ((?x91179 (seq.++ ?x30505 (seq.++ ?x30505 (seq.++ ?x30505 (seq.++ ?x2619 (seq.++ ?x56103 ?x88635)))))))
 (let ((?x46880 (seq.++ ?x30505 (seq.++ ?x30505 (seq.++ ?x30505 ?x91179)))))
 (= input_1_L.net.frame_frame ?x46880))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 60001 now_3))
(assert
 (let ((?x50133 (seq.unit (_ bv192 8))))
(let ((?x56096 (seq.++ ?x50133 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x56096))))
(check-sat)

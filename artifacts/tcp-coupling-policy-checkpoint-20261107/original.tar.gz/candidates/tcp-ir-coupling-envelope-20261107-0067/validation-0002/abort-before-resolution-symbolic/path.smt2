; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x924 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x3450 (= due_1_T.user 30000)))
 (let (($x3475 (= due_1_T.rtx 1000)))
 (let (($x921 (= due_1_L.cache due_0_L.cache)))
 (let (($x3465 (= due_1_L.query 1000)))
 (let (($x2933 (not active_1_T.time_wait)))
 (let (($x916 (= active_1_L.cache active_0_L.cache)))
 (let (($x914 (= v_1_ip_pending_owner "TCP")))
 (let (($x913 (= v_1_T.control "SYN-SENT")))
 (let (($x2932 (= v_1_T.wire_flags 2)))
 (let ((?x3531 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x33451 (seq.unit (_ bv16 8))))
 (let ((?x83 (seq.unit (_ bv0 8))))
 (let ((?x154 (seq.unit (_ bv2 8))))
 (let ((?x689 (seq.unit (_ bv80 8))))
 (let ((?x3155 (seq.++ ?x83 (seq.++ ?x689 (seq.++ ?x154 (seq.++ ?x83 (seq.++ ?x33451 ?x3531)))))))
 (let ((?x33375 (seq.unit (_ bv232 8))))
 (let ((?x33539 (seq.unit (_ bv3 8))))
 (let ((?x2832 (seq.++ ?x33539 (seq.++ ?x33375 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x83 ?x3155)))))))
 (let ((?x3218 (seq.unit (_ bv144 8))))
 (let ((?x3405 (seq.unit (_ bv31 8))))
 (let ((?x2963 (seq.unit (_ bv64 8))))
 (let ((?x2878 (seq.++ ?x2963 (seq.++ ?x3405 (seq.++ ?x3218 (seq.++ ?x83 (seq.++ ?x83 ?x2832)))))))
 (let ((?x3220 (seq.unit (_ bv156 8))))
 (let ((?x222 (seq.++ ?x3220 ?x2878)))
 (let ((?x153 (seq.unit (_ bv192 8))))
 (let ((?x32785 (seq.unit (_ bv1 8))))
 (let ((?x63638 (seq.++ ?x32785 (seq.++ ?x153 (seq.++ ?x83 (seq.++ ?x154 (seq.++ ?x154 ?x222)))))))
 (let ((?x3109 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x153 (seq.++ ?x83 (seq.++ ?x154 ?x63638))))))
 (let ((?x186 (seq.unit (_ bv6 8))))
 (let ((?x304 (seq.++ ?x83 (seq.++ ?x2963 (seq.++ ?x186 (seq.++ (seq.unit (_ bv182 8)) ?x3109))))))
 (let ((?x32932 (seq.unit (_ bv40 8))))
 (let ((?x63581 (seq.++ ?x83 (seq.++ ?x32932 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x2963 ?x304)))))))
 (let ((?x217 (seq.unit (_ bv69 8))))
 (let ((?x3614 (seq.++ ?x217 (seq.++ ?x83 ?x63581))))
 (let (($x3615 (= v_1_T.wire_packet ?x3614)))
 (let ((?x762 (seq.++ ?x154 (seq.++ ?x32785 (seq.++ ?x153 (seq.++ ?x83 (seq.++ ?x154 ?x154)))))))
 (let ((?x768 (seq.++ ?x186 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x153 (seq.++ ?x83 ?x762)))))))
 (let ((?x773 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x2963 (seq.++ ?x83 (seq.++ ?x2963 ?x768)))))))
 (let (($x63626 (= v_1_T.wire_ip_zero (seq.++ ?x217 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x32932 ?x773)))))))
 (let (($x63625 (= v_1_T.wire_tcp ?x222)))
 (let ((?x32826 (seq.++ ?x154 (seq.++ ?x83 (seq.++ ?x186 (seq.++ ?x83 (seq.unit (_ bv20 8))))))))
 (let ((?x33433 (seq.++ ?x154 (seq.++ ?x32785 (seq.++ ?x153 (seq.++ ?x83 (seq.++ ?x154 ?x32826)))))))
 (let (($x2707 (= v_1_T.wire_pseudo (seq.++ ?x153 (seq.++ ?x83 ?x33433)))))
 (let ((?x32875 (seq.++ ?x83 (seq.++ ?x33451 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x83 ?x83)))))))
 (let ((?x33244 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x689 (seq.++ ?x154 ?x32875)))))))
 (let ((?x33196 (seq.++ ?x83 (seq.++ ?x83 (seq.++ ?x33539 (seq.++ ?x33375 (seq.++ ?x83 ?x33244)))))))
 (let (($x3208 (= v_1_T.wire_tcp_zero (seq.++ ?x3220 (seq.++ ?x2963 (seq.++ ?x3405 (seq.++ ?x3218 ?x33196)))))))
 (let (($x2761 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x2833 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x32958 (= v_1_T.take 0)))
 (let (($x33503 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x33504 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x33264 (= v_1_T.snd_wnd 8)))
 (let (($x3569 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x2860 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x2859 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x33036 (= v_1_T.local_window 16)))
 (let (($x33037 (= v_1_T.msl_ms 60000)))
 (let (($x33038 (= v_1_T.user_timeout_ms 30000)))
 (let (($x892 (= 0 v_1_T.retries)))
 (let (($x891 (= 1000 v_1_T.rto_ms)))
 (let (($x890 (= v_1_T.tx_flags "S")))
 (let (($x33041 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x33206 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x33207 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x3369 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x33209 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x33210 (= v_1_T.irs (_ bv0 32))))
 (let (($x33211 (= v_1_T.iss (_ bv1000 32))))
 (let (($x882 (= v_1_L.control "PENDING")))
 (let (($x3038 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x2667 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63674 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63673 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x63636 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x32053 (not v_1_L.rxudp_require_checksum)))
 (let (($x63635 (= v_1_L.pending_packet ?x3614)))
 (let (($x33221 (= v_1_L.ip_checksum 0)))
 (let (($x33313 (= v_1_L.udp_checksum 0)))
 (let (($x33314 (= v_1_L.udp_raw_checksum 0)))
 (let (($x33315 (= v_1_L.ip_length 0)))
 (let (($x33316 (= v_1_L.udp_length 0)))
 (let (($x32929 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x32928 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x32927 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x32926 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x32925 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x32924 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x32923 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x33325 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x858 (= 0 v_1_L.retry_count)))
 (let (($x32922 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x856 (= 0 state_1)))
 (let (($x370 (not active_0_T.time_wait)))
 (let (($x32921 (or $x370 (not (<= due_0_T.time_wait 0)))))
 (let (($x2774 (not active_0_T.user)))
 (let (($x33015 (or $x2774 (not (<= due_0_T.user 0)))))
 (let (($x249 (not active_0_T.rtx)))
 (let (($x32989 (or $x249 (not (<= due_0_T.rtx 0)))))
 (let (($x3386 (not active_0_L.cache)))
 (let (($x33027 (or $x3386 (not (<= due_0_L.cache 0)))))
 (let (($x3345 (not active_0_L.query)))
 (let (($x33024 (or $x3345 (not (<= due_0_L.query 0)))))
 (let (($x1137 (= state_0 0)))
 (and $x1137 (>= 0 now_0) $x33024 $x33027 $x32989 $x33015 $x32921 $x856 $x32922 $x858 $x33325 v_1_L.checksums_enabled $x32923 $x32924 $x32925 $x32926 $x32927 $x32928 $x32929 $x33316 $x33315 $x33314 $x33313 $x33221 $x63635 $x32053 $x63636 (= v_1_L.rxudp_disposition "none") $x63673 $x63674 $x2667 $x3038 (= v_1_L.echo_disposition "none") $x882 $x33211 $x33210 $x33209 $x3369 $x33207 $x33206 $x33041 $x890 $x891 $x892 v_1_T.active_open $x33038 $x33037 $x33036 $x2859 $x2860 $x3569 $x33264 $x33504 $x33503 $x32958 $x2833 $x2761 $x3208 $x2707 $x63625 $x63626 $x3615 $x2932 (= v_1_T.wire_disposition "none") $x913 $x914 active_1_L.query $x916 active_1_T.rtx active_1_T.user $x2933 $x3465 $x921 $x3475 $x3450 $x924)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x34828 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x34827 (= due_2_T.user due_1_T.user)))
 (let (($x34826 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x34825 (= due_2_L.cache due_1_L.cache)))
 (let (($x34824 (= due_2_L.query due_1_L.query)))
 (let (($x2534 (not active_2_T.time_wait)))
 (let (($x2533 (not active_2_T.user)))
 (let (($x33185 (not active_2_T.rtx)))
 (let (($x34820 (= active_2_L.cache active_1_L.cache)))
 (let (($x34819 (= active_2_L.query active_1_L.query)))
 (let (($x34818 (= v_2_ip_pending_owner (ite (= v_1_ip_pending_owner "TCP") "none" v_1_ip_pending_owner))))
 (let (($x34817 (= v_2_T.control "CLOSED")))
 (let (($x34816 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x34815 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x34814 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x34813 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x34812 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x34811 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x34810 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x34809 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x34808 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x34807 (= v_2_T.take v_1_T.take)))
 (let (($x34806 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x34805 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x34804 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x34803 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x34802 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x34801 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x34800 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x34799 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x34798 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x34797 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x34796 (= v_2_T.retries v_1_T.retries)))
 (let (($x34795 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x34794 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x34793 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x34792 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x34791 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x34790 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x34789 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x34788 (= v_2_T.irs v_1_T.irs)))
 (let (($x34787 (= v_2_T.iss v_1_T.iss)))
 (let (($x34786 (= v_2_L.control v_1_L.control)))
 (let (($x34785 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x34784 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x34783 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x34782 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x34781 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x34780 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x34779 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x34778 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x914 (= v_1_ip_pending_owner "TCP")))
 (let (($x34777 (= v_2_L.pending_packet (ite $x914 (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet))))
 (let (($x34776 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x34775 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x34774 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x34773 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x34772 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x34771 (= v_2_L.packet v_1_L.packet)))
 (let (($x34770 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x34769 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x34768 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x34767 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x34766 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x34765 (= v_2_L.payload v_1_L.payload)))
 (let (($x34764 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x34763 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x34762 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x34761 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x34760 (= 0 state_2)))
 (let (($x2933 (not active_1_T.time_wait)))
 (let (($x33172 (or $x2933 (not (<= due_1_T.time_wait 5)))))
 (let (($x33171 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x2525 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x33167 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x33320 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x913 (= v_1_T.control "SYN-SENT")))
 (let (($x2522 (= state_1 0)))
 (and $x2522 $x913 $x33320 $x33167 $x2525 $x33171 $x33172 $x34760 $x34761 $x34762 $x34763 $x34764 $x34765 $x34766 $x34767 $x34768 $x34769 $x34770 $x34771 $x34772 $x34773 $x34774 $x34775 $x34776 $x34777 $x34778 $x34779 $x34780 $x34781 $x34782 $x34783 $x34784 $x34785 $x34786 $x34787 $x34788 $x34789 $x34790 $x34791 $x34792 $x34793 $x34794 $x34795 $x34796 $x34797 $x34798 $x34799 $x34800 $x34801 $x34802 $x34803 $x34804 $x34805 $x34806 $x34807 $x34808 $x34809 $x34810 $x34811 $x34812 $x34813 $x34814 $x34815 $x34816 $x34817 $x34818 $x34819 $x34820 $x33185 $x2533 $x2534 $x34824 $x34825 $x34826 $x34827 $x34828))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 174 choice_1))
(assert
 (= 5 now_2))
(check-sat)

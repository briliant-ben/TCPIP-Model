; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!2
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!2
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!2
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x32959 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x63487 (= due_1_T.user due_0_T.user)))
 (let (($x63550 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x33111 (= due_1_L.cache due_0_L.cache)))
 (let (($x35619 (= due_1_L.query 1000)))
 (let (($x61 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x32635 (= active_1_T.user active_0_T.user)))
 (let (($x32634 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x33213 (= active_1_L.cache active_0_L.cache)))
 (let (($x30561 (= v_1_T.control "CLOSED")))
 (let (($x64415 (= v_1_T.wire_flags 0)))
 (let (($x35615 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x35614 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x35617 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x35616 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x35618 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x64621 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x64620 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x64508 (= v_1_T.take 0)))
 (let (($x64509 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x64469 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x64470 (= v_1_T.snd_wnd 8)))
 (let (($x64586 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x64585 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x34797 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x64493 (= v_1_T.local_window 16)))
 (let (($x64494 (= v_1_T.msl_ms 60000)))
 (let (($x64412 (= v_1_T.user_timeout_ms 30000)))
 (let (($x64413 (= v_1_T.retries 0)))
 (let (($x64441 (= v_1_T.rto_ms 1000)))
 (let (($x64443 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x64418 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x64439 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x64440 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x34780 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x63433 (= v_1_T.irs (_ bv0 32))))
 (let (($x253 (= v_1_T.iss (_ bv1000 32))))
 (let (($x32835 (= v_1_L.control "PENDING")))
 (let (($x65128 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x65127 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x65126 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x65125 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x65124 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x30391 (not v_1_L.rxudp_require_checksum)))
 (let (($x65123 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x2386 (= v_1_L.ip_checksum 0)))
 (let (($x2387 (= v_1_L.udp_checksum 0)))
 (let (($x2388 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2389 (= v_1_L.ip_length 0)))
 (let (($x2390 (= v_1_L.udp_length 0)))
 (let (($x65122 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x65121 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x65120 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x65119 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x65118 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x65117 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x65116 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x35555 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x63625 (= 0 v_1_L.retry_count)))
 (let (($x65115 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x3208 (= 0 state_1)))
 (let (($x63397 (not active_0_T.time_wait)))
 (let (($x65114 (or $x63397 (not (<= due_0_T.time_wait 0)))))
 (let (($x34814 (not active_0_T.user)))
 (let (($x65112 (or $x34814 (not (<= due_0_T.user 0)))))
 (let (($x1243 (not active_0_T.rtx)))
 (let (($x64821 (or $x1243 (not (<= due_0_T.rtx 0)))))
 (let (($x594 (not active_0_L.cache)))
 (let (($x64811 (or $x594 (not (<= due_0_L.cache 0)))))
 (let (($x34812 (not active_0_L.query)))
 (let (($x64584 (or $x34812 (not (<= due_0_L.query 0)))))
 (let (($x63407 (= state_0 0)))
 (and $x63407 (>= 0 now_0) $x64584 $x64811 $x64821 $x65112 $x65114 $x3208 $x65115 $x63625 $x35555 v_1_L.checksums_enabled $x65116 $x65117 $x65118 $x65119 $x65120 $x65121 $x65122 $x2390 $x2389 $x2388 $x2387 $x2386 $x65123 $x30391 $x65124 (= v_1_L.rxudp_disposition "none") $x65125 $x65126 $x65127 $x65128 (= v_1_L.echo_disposition "none") $x32835 $x253 $x63433 $x34780 $x64440 $x64439 $x64418 $x64443 (= v_1_T.tx_flags "S") $x64441 $x64413 v_1_T.active_open $x64412 $x64494 $x64493 $x34797 $x64585 $x64586 $x64470 $x64469 $x64509 $x64508 $x64620 $x64621 $x35618 $x35616 $x35617 $x35614 $x35615 $x64415 (= v_1_T.wire_disposition "none") $x30561 (= v_1_ip_pending_owner "none") active_1_L.query $x33213 $x32634 $x32635 $x61 $x35619 $x33111 $x63550 $x63487 $x32959))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x30259 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x30258 (= due_2_T.user due_1_T.user)))
 (let (($x30257 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x30255 (= due_2_L.query due_1_L.query)))
 (let (($x30254 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x30253 (= active_2_T.user active_1_T.user)))
 (let (($x30252 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x65246 (not active_2_L.query)))
 (let (($x30249 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x30248 (= v_2_T.control v_1_T.control)))
 (let (($x30247 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x30246 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x30245 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x30244 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x30243 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x30242 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x30241 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x30240 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x30239 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x30238 (= v_2_T.take v_1_T.take)))
 (let (($x30237 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x30236 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x30235 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x30234 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x30233 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x30232 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x30231 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x30230 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x30229 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x30228 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x30227 (= v_2_T.retries v_1_T.retries)))
 (let (($x30226 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x30225 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x30224 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x30223 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x30222 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x30221 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x30220 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x30219 (= v_2_T.irs v_1_T.irs)))
 (let (($x30218 (= v_2_T.iss v_1_T.iss)))
 (let (($x30217 (= v_2_L.control "RESOLVED")))
 (let (($x30216 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x30215 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x30214 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x30213 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x30212 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x30211 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x30210 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x30209 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x30208 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x30207 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x30206 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x30205 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x30204 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x30203 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x30202 (= v_2_L.packet v_1_L.packet)))
 (let (($x30201 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x30200 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x30199 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x30198 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x30197 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x30196 (= v_2_L.payload v_1_L.payload)))
 (let (($x30195 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x30194 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x30193 (= 0 v_2_L.retry_count)))
 (let ((?x726 (seq.unit (_ bv0 8))))
 (let ((?x958 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.unit (_ bv2 8))))))))
 (let ((?x63705 (seq.unit (_ bv2 8))))
 (let ((?x959 (seq.++ ?x63705 ?x958)))
 (let (($x65245 (= v_2_L.peer_mac ?x959)))
 (let (($x30191 (= 0 state_2)))
 (let (($x65244 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x64644 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x64663 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x64659 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x64573 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x30160 (seq.len v_1_L.pending_packet)))
 (let (($x30170 (= 0 ?x30160)))
 (let (($x32835 (= v_1_L.control "PENDING")))
 (let (($x2379 (= state_1 0)))
 (and $x2379 $x32835 $x30170 $x64573 $x64659 $x64663 $x64644 $x65244 $x30191 $x65245 $x30193 $x30194 $x30195 $x30196 $x30197 $x30198 $x30199 $x30200 $x30201 $x30202 $x30203 $x30204 $x30205 $x30206 $x30207 $x30208 $x30209 $x30210 $x30211 $x30212 $x30213 $x30214 $x30215 $x30216 $x30217 $x30218 $x30219 $x30220 $x30221 $x30222 $x30223 $x30224 $x30225 $x30226 $x30227 $x30228 $x30229 $x30230 $x30231 $x30232 $x30233 $x30234 $x30235 $x30236 $x30237 $x30238 $x30239 $x30240 $x30241 $x30242 $x30243 $x30244 $x30245 $x30246 $x30247 $x30248 $x30249 $x65246 active_2_L.cache $x30252 $x30253 $x30254 $x30255 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x30257 $x30258 $x30259))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3443 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x2359 (= due_3_T.rtx 1020)))
 (let (($x13 (= due_3_L.cache due_2_L.cache)))
 (let (($x32680 (= due_3_L.query due_2_L.query)))
 (let (($x65106 (not active_3_T.time_wait)))
 (let (($x2550 (= active_3_L.cache active_2_L.cache)))
 (let (($x33118 (= active_3_L.query active_2_L.query)))
 (let (($x32638 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x33161 (= v_3_T.control "SYN-SENT")))
 (let (($x33060 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x65169 (= v_3_T.wire_flags 2)))
 (let ((?x726 (seq.unit (_ bv0 8))))
 (let ((?x2667 (seq.++ ?x726 ?x726)))
 (let ((?x33212 (seq.++ ?x726 (seq.++ ?x726 ?x2667))))
 (let ((?x33150 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x1183 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x63705 (seq.unit (_ bv2 8))))
 (let ((?x33395 (seq.unit (_ bv80 8))))
 (let ((?x64549 (seq.++ ?x726 (seq.++ ?x33395 (seq.++ ?x63705 (seq.++ ?x1183 (seq.++ ?x33150 ?x33212)))))))
 (let ((?x35595 (seq.unit ((_ extract 7 0) v_2_T.iss))))
 (let ((?x65188 (seq.unit ((_ extract 15 8) v_2_T.iss))))
 (let ((?x64704 (seq.++ ?x65188 (seq.++ ?x35595 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 ?x64549)))))))
 (let ((?x35590 (seq.unit ((_ extract 23 16) v_2_T.iss))))
 (let ((?x35581 (seq.unit ((_ extract 31 24) v_2_T.iss))))
 (let ((?x206 (seq.unit (_ bv144 8))))
 (let ((?x205 (seq.unit (_ bv31 8))))
 (let ((?x131 (seq.unit (_ bv64 8))))
 (let ((?x64420 (seq.++ ?x131 (seq.++ ?x205 (seq.++ ?x206 (seq.++ ?x35581 (seq.++ ?x35590 ?x64704)))))))
 (let ((?x32815 (seq.unit (_ bv156 8))))
 (let ((?x64425 (seq.++ ?x32815 ?x64420)))
 (let ((?x64712 (seq.unit (_ bv20 8))))
 (let ((?x32924 (seq.unit (_ bv6 8))))
 (let ((?x64904 (seq.++ ?x63705 (seq.++ ?x726 (seq.++ ?x32924 (seq.++ ?x726 (seq.++ ?x64712 ?x64425)))))))
 (let ((?x1137 (seq.unit (_ bv192 8))))
 (let ((?x370 (seq.unit (_ bv1 8))))
 (let ((?x64909 (seq.++ ?x63705 (seq.++ ?x370 (seq.++ ?x1137 (seq.++ ?x726 (seq.++ ?x63705 ?x64904)))))))
 (let ((?x64912 ((_ ir4_ones_sum16_checksum_instance!2 0) (seq.++ ?x1137 (seq.++ ?x726 ?x64909)))))
 (let ((?x3033 (seq.++ (seq.unit (bvnot ((_ extract 15 8) ?x64912))) (seq.++ (seq.unit (bvnot ((_ extract 7 0) ?x64912))) ?x2667))))
 (let ((?x538 (seq.++ ?x726 (seq.++ ?x33395 (seq.++ ?x63705 (seq.++ ?x1183 (seq.++ ?x33150 ?x3033)))))))
 (let ((?x35644 (seq.++ ?x65188 (seq.++ ?x35595 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 ?x538)))))))
 (let ((?x35649 (seq.++ ?x131 (seq.++ ?x205 (seq.++ ?x206 (seq.++ ?x35581 (seq.++ ?x35590 ?x35644)))))))
 (let ((?x35655 (seq.++ ?x32815 ?x35649)))
 (let ((?x65280 (seq.++ ?x370 (seq.++ ?x1137 (seq.++ ?x726 (seq.++ ?x63705 (seq.++ ?x63705 ?x35655)))))))
 (let ((?x64562 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x1137 (seq.++ ?x726 (seq.++ ?x63705 ?x65280))))))
 (let ((?x64501 (seq.++ ?x726 (seq.++ ?x131 (seq.++ ?x32924 (seq.++ (seq.unit (_ bv182 8)) ?x64562))))))
 (let ((?x64631 (seq.unit (_ bv40 8))))
 (let ((?x64629 (seq.++ ?x726 (seq.++ ?x64631 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x131 ?x64501)))))))
 (let ((?x129 (seq.unit (_ bv69 8))))
 (let (($x65168 (= v_3_T.wire_packet (seq.++ ?x129 (seq.++ ?x726 ?x64629)))))
 (let ((?x33484 (seq.++ ?x63705 (seq.++ ?x370 (seq.++ ?x1137 (seq.++ ?x726 (seq.++ ?x63705 ?x63705)))))))
 (let ((?x369 (seq.++ ?x32924 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x1137 (seq.++ ?x726 ?x33484)))))))
 (let ((?x33153 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x131 (seq.++ ?x726 (seq.++ ?x131 ?x369)))))))
 (let (($x64861 (= v_3_T.wire_ip_zero (seq.++ ?x129 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x64631 ?x33153)))))))
 (let (($x35651 (= v_3_T.wire_tcp ?x35655)))
 (let ((?x65030 (seq.++ ?x63705 (seq.++ ?x63705 (seq.++ ?x726 (seq.++ ?x32924 (seq.++ ?x726 ?x64712)))))))
 (let ((?x65035 (seq.++ ?x726 (seq.++ ?x63705 (seq.++ ?x370 (seq.++ ?x1137 (seq.++ ?x726 ?x65030)))))))
 (let (($x65037 (= v_3_T.wire_pseudo (seq.++ ?x1137 ?x65035))))
 (let (($x64755 (= v_3_T.wire_tcp_zero ?x64425)))
 (let (($x35576 (= (as seq.empty (Seq (_ BitVec 8))) v_3_T.wire_data)))
 (let (($x35445 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x307 (= v_3_T.take v_2_T.take)))
 (let (($x305 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x306 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x2544 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x33240 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x2538 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x2663 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x3203 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x3021 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x2657 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x2558 (= 0 v_3_T.retries)))
 (let (($x33309 (= 1000 v_3_T.rto_ms)))
 (let (($x33387 (= v_3_T.tx_flags "S")))
 (let (($x35573 (= v_3_T.tx_ack (_ bv0 32))))
 (let (($x2587 (= v_3_T.tx_seq v_2_T.iss)))
 (let (($x2586 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x35574 (= v_3_T.snd_nxt (bvadd (_ bv1 32) v_2_T.iss))))
 (let (($x2705 (= v_3_T.snd_una v_2_T.iss)))
 (let (($x33142 (= v_3_T.irs v_2_T.irs)))
 (let (($x32704 (= v_3_T.iss v_2_T.iss)))
 (let (($x35482 (= v_3_L.control v_2_L.control)))
 (let (($x32884 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x63751 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x3207 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x2943 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x3400 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x3399 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x3064 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x2829 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x2828 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x63612 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x63611 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x3581 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x3580 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x3202 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x3201 (= v_3_L.packet v_2_L.packet)))
 (let (($x2853 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x63574 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x63573 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x3273 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x2647 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x63672 (= v_3_L.payload v_2_L.payload)))
 (let (($x2583 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x32616 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x32615 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x33531 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x33195 (= 0 state_3)))
 (let (($x35549 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x65186 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x64544 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x2381 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x65246 (not active_2_L.query)))
 (let (($x64472 (or $x65246 (not (<= due_2_L.query 20)))))
 (let (($x30217 (= v_2_L.control "RESOLVED")))
 (let (($x3073 (= v_2_T.control "CLOSED")))
 (let (($x35637 (= state_2 0)))
 (and $x35637 $x3073 $x30217 $x64472 $x2381 $x64544 $x65186 $x35549 $x33195 $x33531 $x32615 $x32616 $x2583 $x63672 $x2647 $x3273 $x63573 $x63574 $x2853 $x3201 $x3202 $x3580 $x3581 $x63611 $x63612 $x2828 $x2829 $x3064 $x3399 $x3400 $x2943 $x3207 $x63751 $x32884 $x35482 $x32704 $x33142 $x2705 $x35574 $x2586 $x2587 $x35573 $x33387 $x33309 $x2558 v_3_T.active_open $x2657 $x3021 $x3203 $x2663 $x2538 $x33240 $x2544 $x306 $x305 $x307 $x35445 $x35576 $x64755 $x65037 $x35651 $x64861 $x65168 $x65169 $x33060 $x33161 $x32638 $x33118 $x2550 active_3_T.rtx active_3_T.user $x65106 $x32680 $x13 $x2359 (= due_3_T.user (+ 20 v_2_T.user_timeout_ms)) $x3443))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1137 (seq.unit (_ bv192 8))))
 (let ((?x33022 (seq.++ ?x1137 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x33022))))
(assert
 (= 30 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x1137 (seq.unit (_ bv192 8))))
 (let ((?x63673 (seq.++ ?x1137 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x370 (seq.unit (_ bv1 8))))
 (let ((?x726 (seq.unit (_ bv0 8))))
 (let ((?x94262 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x370 ?x63673)))))))
 (let ((?x63705 (seq.unit (_ bv2 8))))
 (let ((?x94267 (seq.++ ?x1137 (seq.++ ?x726 (seq.++ ?x63705 (seq.++ ?x63705 (seq.++ ?x63705 ?x94262)))))))
 (let ((?x94272 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x63705 ?x94267)))))))
 (let ((?x32926 (seq.unit (_ bv4 8))))
 (let ((?x32924 (seq.unit (_ bv6 8))))
 (let ((?x94277 (seq.++ ?x32924 (seq.++ ?x32926 (seq.++ ?x726 (seq.++ ?x63705 (seq.++ ?x63705 ?x94272)))))))
 (let ((?x33325 (seq.unit (_ bv8 8))))
 (let ((?x94282 (seq.++ ?x32924 (seq.++ ?x726 (seq.++ ?x370 (seq.++ ?x33325 (seq.++ ?x726 ?x94277)))))))
 (let ((?x94287 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x63705 (seq.++ ?x33325 ?x94282)))))))
 (let ((?x94292 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x370 (seq.++ ?x63705 (seq.++ ?x726 ?x94287)))))))
 (let ((?x94295 (seq.++ ?x63705 (seq.++ ?x726 (seq.++ ?x726 ?x94292)))))
 (= input_1_L.net.frame_frame ?x94295))))))))))))))))))
(assert
 (= 66 choice_2))
(assert
 (= 20 now_3))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3188 (= due_1_cache due_0_cache)))
 (let (($x3630 (= due_1_query due_0_query)))
 (let (($x1108 (= active_1_cache active_0_cache)))
 (let (($x3187 (= active_1_query active_0_query)))
 (let (($x3172 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3171 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3170 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3169 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x3185 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x3168 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3167 (not v_1_rxudp_require_checksum)))
 (let (($x3166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x736 (= v_1_ip_checksum 0)))
 (let (($x4644 (= v_1_udp_checksum 0)))
 (let (($x3458 (= v_1_udp_raw_checksum 0)))
 (let (($x1019 (= v_1_ip_length 0)))
 (let (($x2954 (= v_1_udp_length 0)))
 (let (($x3165 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x3164 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3163 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3162 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3161 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3160 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3159 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3695 (= v_1_cache_ttl_ms 60000)))
 (let (($x3456 (= v_1_retry_count 0)))
 (let (($x3158 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x247 (= 0 state_1)))
 (let (($x1619 (not active_0_cache)))
 (let (($x3157 (or $x1619 (not (<= due_0_cache 0)))))
 (let (($x1617 (not active_0_query)))
 (let (($x3154 (or $x1617 (not (<= due_0_query 0)))))
 (let (($x6638 (= state_0 0)))
 (and $x6638 (>= 0 now_0) $x3154 $x3157 $x247 $x3158 $x3456 $x3695 v_1_checksums_enabled $x3159 $x3160 $x3161 $x3162 $x3163 $x3164 $x3165 $x2954 $x1019 $x3458 $x4644 $x736 $x3166 $x3167 $x3168 $x3185 $x3169 $x3170 $x3171 $x3172 (= v_1_echo_disposition "none") $x3187 $x1108 $x3630 $x3188)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5601 (seq.unit (_ bv0 8))))
(let ((?x2051 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 ?x5601)))))))
(let ((?x2056 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 ?x2051)))))))
(let ((?x669 (seq.unit (_ bv111 8))))
(let ((?x667 (seq.unit (_ bv108 8))))
(let ((?x2060 (seq.++ ?x667 (seq.++ ?x667 (seq.++ ?x669 (seq.++ ?x5601 (seq.++ ?x5601 ?x2056)))))))
(let ((?x665 (seq.unit (_ bv101 8))))
(let ((?x663 (seq.unit (_ bv104 8))))
(let ((?x661 (seq.unit (_ bv45 8))))
(let ((?x659 (seq.unit (_ bv124 8))))
(let ((?x657 (seq.unit (_ bv13 8))))
(let ((?x2065 (seq.++ ?x657 (seq.++ ?x659 (seq.++ ?x661 (seq.++ ?x663 (seq.++ ?x665 ?x2060)))))))
(let ((?x2372 (seq.unit (_ bv64 8))))
(let ((?x6534 (seq.unit (_ bv156 8))))
(let ((?x1714 (seq.unit (_ bv144 8))))
(let ((?x671 (seq.unit (_ bv31 8))))
(let ((?x2069 (seq.++ ?x671 (seq.++ ?x1714 (seq.++ ?x6534 (seq.++ ?x2372 (seq.++ ?x5601 ?x2065)))))))
(let ((?x5648 (seq.unit (_ bv1 8))))
(let ((?x5603 (seq.unit (_ bv2 8))))
(let ((?x3455 (seq.unit (_ bv192 8))))
(let ((?x3068 (seq.++ ?x5603 (seq.++ ?x3455 (seq.++ ?x5601 (seq.++ ?x5603 (seq.++ ?x5648 ?x2069)))))))
(let ((?x655 (seq.unit (_ bv206 8))))
(let ((?x653 (seq.unit (_ bv182 8))))
(let ((?x3073 (seq.++ ?x653 (seq.++ ?x655 (seq.++ ?x3455 (seq.++ ?x5601 (seq.++ ?x5603 ?x3068)))))))
(let ((?x1708 (seq.unit (_ bv17 8))))
(let ((?x3078 (seq.++ ?x5601 (seq.++ ?x2372 (seq.++ ?x5601 (seq.++ ?x2372 (seq.++ ?x1708 ?x3073)))))))
(let ((?x651 (seq.unit (_ bv27 8))))
(let ((?x5042 (seq.unit (_ bv69 8))))
(let ((?x3083 (seq.++ ?x5042 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x651 (seq.++ ?x5601 ?x3078)))))))
(let ((?x1647 (seq.unit (_ bv8 8))))
(let ((?x3088 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5603 (seq.++ ?x1647 (seq.++ ?x5601 ?x3083)))))))
(let ((?x3093 (seq.++ ?x5601 (seq.++ ?x5648 (seq.++ ?x5603 (seq.++ ?x5601 (seq.++ ?x5601 ?x3088)))))))
(let ((?x3097 (seq.++ ?x5603 (seq.++ ?x5601 (seq.++ ?x5601 (seq.++ ?x5601 ?x3093))))))
(= input_0_net.frame_frame ?x3097)))))))))))))))))))))))))))))))))))
(check-sat)

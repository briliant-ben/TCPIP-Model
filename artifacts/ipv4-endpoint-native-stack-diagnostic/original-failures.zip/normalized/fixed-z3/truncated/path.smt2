; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3748 (= due_1_cache due_0_cache)))
 (let (($x1724 (= due_1_query due_0_query)))
 (let (($x2191 (= active_1_cache active_0_cache)))
 (let (($x2128 (= active_1_query active_0_query)))
 (let (($x3212 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3211 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3178 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3177 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1722 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x3176 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3175 (not v_1_rxudp_require_checksum)))
 (let (($x3174 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1154 (= v_1_ip_checksum 0)))
 (let (($x2095 (= v_1_udp_checksum 0)))
 (let (($x4842 (= v_1_udp_raw_checksum 0)))
 (let (($x1053 (= v_1_ip_length 0)))
 (let (($x3495 (= v_1_udp_length 0)))
 (let (($x559 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x7704 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1610 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x191 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x5063 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x7722 (= v_1_cache_ttl_ms 60000)))
 (let (($x6481 (= v_1_retry_count 0)))
 (let (($x635 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1712 (= 0 state_1)))
 (let (($x5713 (not active_0_cache)))
 (let (($x7491 (or $x5713 (not (<= due_0_cache 0)))))
 (let (($x5715 (not active_0_query)))
 (let (($x4416 (or $x5715 (not (<= due_0_query 0)))))
 (let (($x2062 (= state_0 0)))
 (and $x2062 (>= 0 now_0) $x4416 $x7491 $x1712 $x635 $x6481 $x7722 v_1_checksums_enabled $x5063 $x191 $x1610 $x3145 $x3146 $x7704 $x559 $x3495 $x1053 $x4842 $x2095 $x1154 $x3174 $x3175 $x3176 $x1722 $x3177 $x3178 $x3211 $x3212 (= v_1_echo_disposition "none") $x2128 $x2191 $x1724 $x3748)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x4911 (seq.unit (_ bv0 8))))
(let ((?x3135 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 ?x4911)))))))
(let ((?x3140 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 ?x3135)))))))
(let ((?x7490 (seq.unit (_ bv111 8))))
(let ((?x3763 (seq.unit (_ bv108 8))))
(let ((?x4193 (seq.++ ?x3763 (seq.++ ?x3763 (seq.++ ?x7490 (seq.++ ?x4911 (seq.++ ?x4911 ?x3140)))))))
(let ((?x7359 (seq.unit (_ bv101 8))))
(let ((?x715 (seq.unit (_ bv104 8))))
(let ((?x6181 (seq.unit (_ bv45 8))))
(let ((?x3186 (seq.unit (_ bv124 8))))
(let ((?x6321 (seq.unit (_ bv13 8))))
(let ((?x6136 (seq.++ ?x6321 (seq.++ ?x3186 (seq.++ ?x6181 (seq.++ ?x715 (seq.++ ?x7359 ?x4193)))))))
(let ((?x1648 (seq.unit (_ bv64 8))))
(let ((?x305 (seq.unit (_ bv156 8))))
(let ((?x6007 (seq.unit (_ bv144 8))))
(let ((?x4448 (seq.unit (_ bv31 8))))
(let ((?x4065 (seq.++ ?x4448 (seq.++ ?x6007 (seq.++ ?x305 (seq.++ ?x1648 (seq.++ ?x4911 ?x6136)))))))
(let ((?x1019 (seq.unit (_ bv1 8))))
(let ((?x3608 (seq.unit (_ bv2 8))))
(let ((?x5699 (seq.unit (_ bv192 8))))
(let ((?x5742 (seq.++ ?x3608 (seq.++ ?x5699 (seq.++ ?x4911 (seq.++ ?x3608 (seq.++ ?x1019 ?x4065)))))))
(let ((?x5128 (seq.unit (_ bv186 8))))
(let ((?x1156 (seq.unit (_ bv182 8))))
(let ((?x5728 (seq.++ ?x1156 (seq.++ ?x5128 (seq.++ ?x5699 (seq.++ ?x4911 (seq.++ ?x3608 ?x5742)))))))
(let ((?x1650 (seq.unit (_ bv17 8))))
(let ((?x5702 (seq.++ ?x4911 (seq.++ ?x1648 (seq.++ ?x4911 (seq.++ ?x1648 (seq.++ ?x1650 ?x5728)))))))
(let ((?x3183 (seq.unit (_ bv47 8))))
(let ((?x5659 (seq.unit (_ bv69 8))))
(let ((?x4988 (seq.++ ?x5659 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x3183 (seq.++ ?x4911 ?x5702)))))))
(let ((?x3521 (seq.unit (_ bv8 8))))
(let ((?x5741 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x3608 (seq.++ ?x3521 (seq.++ ?x4911 ?x4988)))))))
(let ((?x7804 (seq.++ ?x4911 (seq.++ ?x1019 (seq.++ ?x3608 (seq.++ ?x4911 (seq.++ ?x4911 ?x5741)))))))
(let ((?x2142 (seq.++ ?x3608 (seq.++ ?x4911 (seq.++ ?x4911 (seq.++ ?x4911 ?x7804))))))
(= input_0_net.frame_frame ?x2142)))))))))))))))))))))))))))))))))))
(check-sat)

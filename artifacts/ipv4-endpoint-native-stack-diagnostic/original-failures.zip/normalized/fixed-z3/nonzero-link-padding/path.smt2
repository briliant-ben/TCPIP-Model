; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x843 (= due_1_cache due_0_cache)))
 (let (($x4225 (= due_1_query due_0_query)))
 (let (($x837 (= active_1_cache active_0_cache)))
 (let (($x2378 (= active_1_query active_0_query)))
 (let (($x6561 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x6042 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x6041 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x6040 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x718 (= v_1_rxudp_disposition "deliver")))
 (let (($x6039 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x7047 (not v_1_rxudp_require_checksum)))
 (let (($x6032 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2003 (= v_1_ip_checksum 0)))
 (let (($x2006 (= v_1_udp_checksum 0)))
 (let (($x30 (= v_1_udp_raw_checksum 0)))
 (let (($x1130 (= v_1_ip_length 0)))
 (let (($x2484 (= v_1_udp_length 0)))
 (let (($x6031 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x6030 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x6029 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x6028 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x6027 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x6026 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x6025 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3755 (= v_1_cache_ttl_ms 60000)))
 (let (($x6507 (= v_1_retry_count 0)))
 (let (($x6024 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x274 (= 0 state_1)))
 (let (($x4106 (not active_0_cache)))
 (let (($x6023 (or $x4106 (not (<= due_0_cache 0)))))
 (let (($x6327 (not active_0_query)))
 (let (($x6020 (or $x6327 (not (<= due_0_query 0)))))
 (let (($x3647 (= state_0 0)))
 (and $x3647 (>= 0 now_0) $x6020 $x6023 $x274 $x6024 $x6507 $x3755 v_1_checksums_enabled $x6025 $x6026 $x6027 $x6028 $x6029 $x6030 $x6031 $x2484 $x1130 $x30 $x2006 $x2003 $x6032 $x7047 $x6039 $x718 $x6040 $x6041 $x6042 $x6561 (= v_1_echo_disposition "none") $x2378 $x837 $x4225 $x843)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1724 (= due_2_cache due_1_cache)))
 (let (($x1723 (= due_2_query due_1_query)))
 (let (($x1722 (= active_2_cache active_1_cache)))
 (let (($x1721 (= active_2_query active_1_query)))
 (let (($x1720 (= v_2_echo_disposition "reply")))
 (let ((?x3180 (seq.unit (_ bv192 8))))
 (let ((?x3182 (seq.++ ?x3180 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x3195 (seq.unit (_ bv1 8))))
 (let ((?x3181 (seq.unit (_ bv2 8))))
 (let ((?x4761 (seq.unit (_ bv0 8))))
 (let ((?x1612 (seq.++ ?x4761 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x3195 ?x3182)))))))
 (let ((?x4282 (seq.unit (_ bv64 8))))
 (let ((?x1617 (seq.++ ?x4282 (seq.++ ?x4761 (seq.++ ?x4282 (seq.++ ?x3195 (seq.++ ?x4761 ?x1612)))))))
 (let ((?x1619 (seq.++ ?x4761 (seq.++ ?x4761 ?x1617))))
 (let ((?x5596 (seq.unit (_ bv28 8))))
 (let ((?x5056 (seq.unit (_ bv69 8))))
 (let (($x6557 (= v_2_echo_ip_zero (seq.++ ?x5056 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x5596 ?x1619)))))))
 (let ((?x5676 (seq.unit (_ bv18 8))))
 (let ((?x5779 (seq.++ ?x5676 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x5674 (seq.unit (_ bv254 8))))
 (let ((?x2045 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ (seq.unit (_ bv65 8)) (seq.++ ?x5674 ?x5779))))))
 (let (($x2135 (= v_2_echo_icmp_wire ?x2045)))
 (let (($x3599 (= v_2_echo_icmp_zero (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x4761 ?x5779)))))))
 (let ((?x4754 (seq.++ ?x3195 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x3181 ?x2045)))))))
 (let ((?x5670 (seq.unit (_ bv221 8))))
 (let ((?x5598 (seq.unit (_ bv182 8))))
 (let ((?x6531 (seq.++ ?x5598 (seq.++ ?x5670 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 ?x4754)))))))
 (let ((?x5047 (seq.++ ?x4761 (seq.++ ?x4282 (seq.++ ?x4761 (seq.++ ?x4282 (seq.++ ?x3195 ?x6531)))))))
 (let ((?x4943 (seq.++ ?x5056 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x5596 (seq.++ ?x4761 ?x5047)))))))
 (let (($x3598 (= v_2_echo_reply ?x4943)))
 (let (($x1715 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x6881 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x1714 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x1713 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x1712 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1711 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1710 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1709 (= v_2_ip_length v_1_ip_length)))
 (let (($x1708 (= v_2_udp_length v_1_udp_length)))
 (let (($x1707 (= v_2_packet v_1_packet)))
 (let (($x1706 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1705 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1704 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1703 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1702 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1701 (= v_2_payload v_1_payload)))
 (let (($x1700 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1699 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1698 (= v_2_retry_count v_1_retry_count)))
 (let (($x1697 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1696 (= 0 state_2)))
 (let (($x5934 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x5904 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x2216 (= state_1 0)))
 (and $x2216 $x5904 $x5934 $x1696 $x1697 $x1698 $x1699 $x1700 $x1701 $x1702 $x1703 $x1704 $x1705 $x1706 $x1707 $x1708 $x1709 $x1710 $x1711 $x1712 $x1713 $x1714 $x6881 $x1715 $x3598 $x3599 $x2135 $x6557 $x1720 $x1721 $x1722 $x1723 $x1724))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5604 (seq.unit (_ bv165 8))))
 (let ((?x5612 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 ?x5604)))))))
 (let ((?x5617 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 ?x5612)))))))
 (let ((?x5622 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 (seq.++ ?x5604 ?x5617)))))))
 (let ((?x3180 (seq.unit (_ bv192 8))))
 (let ((?x5626 (seq.++ ?x3180 (seq.++ (seq.unit (_ bv9 8)) (seq.++ ?x5604 (seq.++ ?x5604 ?x5622))))))
 (let ((?x1171 (seq.unit (_ bv8 8))))
 (let ((?x4761 (seq.unit (_ bv0 8))))
 (let ((?x4282 (seq.unit (_ bv64 8))))
 (let ((?x3455 (seq.unit (_ bv156 8))))
 (let ((?x2880 (seq.unit (_ bv144 8))))
 (let ((?x5631 (seq.++ ?x2880 (seq.++ ?x3455 (seq.++ ?x4282 (seq.++ ?x4761 (seq.++ ?x1171 ?x5626)))))))
 (let ((?x2663 (seq.unit (_ bv31 8))))
 (let ((?x3195 (seq.unit (_ bv1 8))))
 (let ((?x3181 (seq.unit (_ bv2 8))))
 (let ((?x5636 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x3195 (seq.++ ?x2663 ?x5631)))))))
 (let ((?x5600 (seq.unit (_ bv205 8))))
 (let ((?x5641 (seq.++ ?x5600 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x3181 ?x5636)))))))
 (let ((?x5598 (seq.unit (_ bv182 8))))
 (let ((?x7434 (seq.unit (_ bv17 8))))
 (let ((?x5646 (seq.++ ?x4282 (seq.++ ?x4761 (seq.++ ?x4282 (seq.++ ?x7434 (seq.++ ?x5598 ?x5641)))))))
 (let ((?x5596 (seq.unit (_ bv28 8))))
 (let ((?x5651 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x5596 (seq.++ ?x4761 (seq.++ ?x4761 ?x5646)))))))
 (let ((?x5056 (seq.unit (_ bv69 8))))
 (let ((?x5656 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x1171 (seq.++ ?x4761 (seq.++ ?x5056 ?x5651)))))))
 (let ((?x5661 (seq.++ ?x3195 (seq.++ ?x3181 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x4761 ?x5656)))))))
 (let ((?x5666 (seq.++ ?x3181 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x4761 ?x5661)))))))
 (= input_0_net.frame_frame ?x5666)))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x5682 (seq.unit (_ bv126 8))))
(let ((?x5690 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 ?x5682)))))))
(let ((?x5695 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 ?x5690)))))))
(let ((?x5700 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 (seq.++ ?x5682 ?x5695)))))))
(let ((?x5600 (seq.unit (_ bv205 8))))
(let ((?x5680 (seq.unit (_ bv171 8))))
(let ((?x5678 (seq.unit (_ bv52 8))))
(let ((?x5705 (seq.++ ?x5678 (seq.++ ?x5680 (seq.++ ?x5600 (seq.++ ?x5682 (seq.++ ?x5682 ?x5700)))))))
(let ((?x5676 (seq.unit (_ bv18 8))))
(let ((?x5674 (seq.unit (_ bv254 8))))
(let ((?x5672 (seq.unit (_ bv57 8))))
(let ((?x4761 (seq.unit (_ bv0 8))))
(let ((?x1171 (seq.unit (_ bv8 8))))
(let ((?x5710 (seq.++ ?x1171 (seq.++ ?x4761 (seq.++ ?x5672 (seq.++ ?x5674 (seq.++ ?x5676 ?x5705)))))))
(let ((?x3195 (seq.unit (_ bv1 8))))
(let ((?x3181 (seq.unit (_ bv2 8))))
(let ((?x3180 (seq.unit (_ bv192 8))))
(let ((?x5715 (seq.++ ?x3181 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x3195 ?x5710)))))))
(let ((?x5670 (seq.unit (_ bv221 8))))
(let ((?x5598 (seq.unit (_ bv182 8))))
(let ((?x5720 (seq.++ ?x5598 (seq.++ ?x5670 (seq.++ ?x3180 (seq.++ ?x4761 (seq.++ ?x3181 ?x5715)))))))
(let ((?x4282 (seq.unit (_ bv64 8))))
(let ((?x5725 (seq.++ ?x4761 (seq.++ ?x4282 (seq.++ ?x4761 (seq.++ ?x4282 (seq.++ ?x3195 ?x5720)))))))
(let ((?x5596 (seq.unit (_ bv28 8))))
(let ((?x5056 (seq.unit (_ bv69 8))))
(let ((?x5730 (seq.++ ?x5056 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x5596 (seq.++ ?x4761 ?x5725)))))))
(let ((?x5735 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x3181 (seq.++ ?x1171 (seq.++ ?x4761 ?x5730)))))))
(let ((?x5740 (seq.++ ?x4761 (seq.++ ?x3195 (seq.++ ?x3181 (seq.++ ?x4761 (seq.++ ?x4761 ?x5735)))))))
(let ((?x5742 (seq.++ ?x3181 (seq.++ ?x4761 (seq.++ ?x4761 (seq.++ ?x4761 ?x5740))))))
(= input_1_net.frame_frame ?x5742)))))))))))))))))))))))))))))))
(check-sat)

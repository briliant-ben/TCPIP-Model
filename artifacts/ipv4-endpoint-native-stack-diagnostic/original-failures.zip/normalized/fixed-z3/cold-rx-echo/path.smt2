; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x638 (= due_1_cache due_0_cache)))
 (let (($x637 (= due_1_query due_0_query)))
 (let (($x636 (= active_1_cache active_0_cache)))
 (let (($x635 (= active_1_query active_0_query)))
 (let (($x4630 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x4628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4627 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x629 (= v_1_rxudp_disposition "deliver")))
 (let ((?x4044 (seq.unit (_ bv128 8))))
 (let ((?x2942 (seq.++ ?x4044 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x197 (seq.unit (_ bv0 8))))
 (let ((?x2943 (seq.++ ?x197 ?x2942)))
 (let (($x4626 (= v_1_rxudp_payload ?x2943)))
 (let (($x2324 (not v_1_rxudp_require_checksum)))
 (let (($x4616 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2637 (= v_1_ip_checksum 0)))
 (let (($x2640 (= v_1_udp_checksum 0)))
 (let (($x2641 (= v_1_udp_raw_checksum 0)))
 (let (($x2642 (= v_1_ip_length 0)))
 (let (($x2643 (= v_1_udp_length 0)))
 (let (($x4615 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4614 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4613 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4612 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4611 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x4610 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4609 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x952 (= v_1_cache_ttl_ms 60000)))
 (let (($x2806 (= v_1_retry_count 0)))
 (let (($x4608 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x609 (= 0 state_1)))
 (let (($x181 (not active_0_cache)))
 (let (($x4607 (or $x181 (not (<= due_0_cache 0)))))
 (let (($x179 (not active_0_query)))
 (let (($x4604 (or $x179 (not (<= due_0_query 0)))))
 (let (($x99 (= state_0 0)))
 (and $x99 (>= 0 now_0) $x4604 $x4607 $x609 $x4608 $x2806 $x952 v_1_checksums_enabled $x4609 $x4610 $x4611 $x4612 $x4613 $x4614 $x4615 $x2643 $x2642 $x2641 $x2640 $x2637 $x4616 $x2324 $x4626 $x629 $x4627 $x4628 $x4629 $x4630 (= v_1_echo_disposition "none") $x635 $x636 $x637 $x638)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2598 (= due_2_cache due_1_cache)))
 (let (($x2597 (= due_2_query due_1_query)))
 (let (($x2596 (= active_2_cache active_1_cache)))
 (let (($x2595 (= active_2_query active_1_query)))
 (let (($x2594 (= v_2_echo_disposition "reply")))
 (let ((?x195 (seq.unit (_ bv192 8))))
 (let ((?x202 (seq.++ ?x195 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x244 (seq.unit (_ bv1 8))))
 (let ((?x199 (seq.unit (_ bv2 8))))
 (let ((?x197 (seq.unit (_ bv0 8))))
 (let ((?x2485 (seq.++ ?x197 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x244 ?x202)))))))
 (let ((?x437 (seq.unit (_ bv64 8))))
 (let ((?x2490 (seq.++ ?x437 (seq.++ ?x197 (seq.++ ?x437 (seq.++ ?x244 (seq.++ ?x197 ?x2485)))))))
 (let ((?x2492 (seq.++ ?x197 (seq.++ ?x197 ?x2490))))
 (let ((?x4032 (seq.unit (_ bv33 8))))
 (let ((?x426 (seq.unit (_ bv69 8))))
 (let (($x4794 (= v_2_echo_ip_zero (seq.++ ?x426 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x4032 ?x2492)))))))
 (let ((?x4044 (seq.unit (_ bv128 8))))
 (let ((?x2943 (seq.++ ?x197 (seq.++ ?x4044 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x197))))))
 (let ((?x4110 (seq.unit (_ bv205 8))))
 (let ((?x4108 (seq.unit (_ bv171 8))))
 (let ((?x4106 (seq.unit (_ bv52 8))))
 (let ((?x4104 (seq.unit (_ bv18 8))))
 (let ((?x2857 (seq.++ ?x4104 (seq.++ ?x4106 (seq.++ ?x4108 (seq.++ ?x4110 ?x2943))))))
 (let ((?x4102 (seq.unit (_ bv118 8))))
 (let ((?x4734 (seq.++ ?x197 (seq.++ ?x197 (seq.++ (seq.unit (_ bv66 8)) (seq.++ ?x4102 ?x2857))))))
 (let (($x4793 (= v_2_echo_icmp_wire ?x4734)))
 (let (($x4792 (= v_2_echo_icmp_zero (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2857)))))))
 (let ((?x4775 (seq.++ ?x244 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x199 ?x4734)))))))
 (let ((?x4098 (seq.unit (_ bv216 8))))
 (let ((?x4780 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x4098 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 ?x4775)))))))
 (let ((?x4785 (seq.++ ?x197 (seq.++ ?x437 (seq.++ ?x197 (seq.++ ?x437 (seq.++ ?x244 ?x4780)))))))
 (let ((?x4790 (seq.++ ?x426 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x4032 (seq.++ ?x197 ?x4785)))))))
 (let (($x4791 (= v_2_echo_reply ?x4790)))
 (let (($x2589 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2588 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2587 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x2586 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x2585 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2584 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2583 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2582 (= v_2_ip_length v_1_ip_length)))
 (let (($x2581 (= v_2_udp_length v_1_udp_length)))
 (let (($x2580 (= v_2_packet v_1_packet)))
 (let (($x2579 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2578 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2577 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2576 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2575 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2574 (= v_2_payload v_1_payload)))
 (let (($x2573 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2572 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2571 (= v_2_retry_count v_1_retry_count)))
 (let (($x2570 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x2569 (= 0 state_2)))
 (let (($x3044 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x2895 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x1076 (= state_1 0)))
 (and $x1076 $x2895 $x3044 $x2569 $x2570 $x2571 $x2572 $x2573 $x2574 $x2575 $x2576 $x2577 $x2578 $x2579 $x2580 $x2581 $x2582 $x2583 $x2584 $x2585 $x2586 $x2587 $x2588 $x2589 $x4791 $x4792 $x4793 $x4794 $x2594 $x2595 $x2596 $x2597 $x2598))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x197 (seq.unit (_ bv0 8))))
 (let ((?x2453 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x197)))))
 (let ((?x2523 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2453)))))))
 (let ((?x2528 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2523)))))))
 (let ((?x4046 (seq.unit (_ bv7 8))))
 (let ((?x252 (seq.unit (_ bv255 8))))
 (let ((?x4044 (seq.unit (_ bv128 8))))
 (let ((?x4050 (seq.++ ?x197 (seq.++ ?x4044 (seq.++ ?x252 (seq.++ ?x4046 ?x2528))))))
 (let ((?x195 (seq.unit (_ bv192 8))))
 (let ((?x4054 (seq.++ ?x197 (seq.++ (seq.unit (_ bv13 8)) (seq.++ ?x195 (seq.++ (seq.unit (_ bv119 8)) ?x4050))))))
 (let ((?x437 (seq.unit (_ bv64 8))))
 (let ((?x459 (seq.unit (_ bv156 8))))
 (let ((?x457 (seq.unit (_ bv144 8))))
 (let ((?x455 (seq.unit (_ bv31 8))))
 (let ((?x244 (seq.unit (_ bv1 8))))
 (let ((?x4059 (seq.++ ?x244 (seq.++ ?x455 (seq.++ ?x457 (seq.++ ?x459 (seq.++ ?x437 ?x4054)))))))
 (let ((?x199 (seq.unit (_ bv2 8))))
 (let ((?x4064 (seq.++ ?x199 (seq.++ ?x199 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 ?x4059)))))))
 (let ((?x4068 (seq.++ (seq.unit (_ bv177 8)) (seq.++ (seq.unit (_ bv246 8)) (seq.++ ?x195 (seq.++ ?x197 ?x4064))))))
 (let ((?x439 (seq.unit (_ bv17 8))))
 (let ((?x4073 (seq.++ (seq.unit (_ bv210 8)) (seq.++ ?x437 (seq.++ ?x197 (seq.++ ?x437 (seq.++ ?x439 ?x4068)))))))
 (let ((?x273 (seq.unit (_ bv4 8))))
 (let ((?x4032 (seq.unit (_ bv33 8))))
 (let ((?x426 (seq.unit (_ bv69 8))))
 (let ((?x4078 (seq.++ ?x426 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x4032 (seq.++ ?x273 ?x4073)))))))
 (let ((?x269 (seq.unit (_ bv8 8))))
 (let ((?x4083 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x269 (seq.++ ?x197 ?x4078)))))))
 (let ((?x4088 (seq.++ ?x197 (seq.++ ?x244 (seq.++ ?x199 (seq.++ ?x197 (seq.++ ?x197 ?x4083)))))))
 (let ((?x4092 (seq.++ ?x199 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x4088))))))
 (= input_0_net.frame_frame ?x4092)))))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x197 (seq.unit (_ bv0 8))))
(let ((?x2453 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x197)))))
(let ((?x2523 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2453)))))))
(let ((?x2528 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2523)))))))
(let ((?x4046 (seq.unit (_ bv7 8))))
(let ((?x252 (seq.unit (_ bv255 8))))
(let ((?x4044 (seq.unit (_ bv128 8))))
(let ((?x4050 (seq.++ ?x197 (seq.++ ?x4044 (seq.++ ?x252 (seq.++ ?x4046 ?x2528))))))
(let ((?x4110 (seq.unit (_ bv205 8))))
(let ((?x4108 (seq.unit (_ bv171 8))))
(let ((?x4106 (seq.unit (_ bv52 8))))
(let ((?x4104 (seq.unit (_ bv18 8))))
(let ((?x4102 (seq.unit (_ bv118 8))))
(let ((?x4115 (seq.++ ?x4102 (seq.++ ?x4104 (seq.++ ?x4106 (seq.++ ?x4108 (seq.++ ?x4110 ?x4050)))))))
(let ((?x4100 (seq.unit (_ bv58 8))))
(let ((?x269 (seq.unit (_ bv8 8))))
(let ((?x244 (seq.unit (_ bv1 8))))
(let ((?x199 (seq.unit (_ bv2 8))))
(let ((?x4120 (seq.++ ?x199 (seq.++ ?x244 (seq.++ ?x269 (seq.++ ?x197 (seq.++ ?x4100 ?x4115)))))))
(let ((?x195 (seq.unit (_ bv192 8))))
(let ((?x4125 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x199 (seq.++ ?x195 (seq.++ ?x197 ?x4120)))))))
(let ((?x4098 (seq.unit (_ bv216 8))))
(let ((?x4096 (seq.unit (_ bv245 8))))
(let ((?x4130 (seq.++ ?x244 (seq.++ ?x244 (seq.++ ?x4096 (seq.++ ?x4098 (seq.++ ?x195 ?x4125)))))))
(let ((?x437 (seq.unit (_ bv64 8))))
(let ((?x4032 (seq.unit (_ bv33 8))))
(let ((?x4135 (seq.++ ?x4032 (seq.++ ?x252 (seq.++ ?x252 (seq.++ ?x437 (seq.++ ?x197 ?x4130)))))))
(let ((?x426 (seq.unit (_ bv69 8))))
(let ((?x4140 (seq.++ ?x269 (seq.++ ?x197 (seq.++ ?x426 (seq.++ ?x197 (seq.++ ?x197 ?x4135)))))))
(let ((?x4145 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x199 ?x4140)))))))
(let ((?x4150 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x244 (seq.++ ?x199 ?x4145)))))))
(let ((?x4152 (seq.++ ?x199 (seq.++ ?x197 ?x4150))))
(= input_1_net.frame_frame ?x4152))))))))))))))))))))))))))))))))))
(check-sat)

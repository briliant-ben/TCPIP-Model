; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x53288 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x53287 (= due_1_T.user due_0_T.user)))
 (let (($x53286 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x53285 (= due_1_L.cache due_0_L.cache)))
 (let (($x97529 (= due_1_L.query 1000)))
 (let (($x53283 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x53282 (= active_1_T.user active_0_T.user)))
 (let (($x53281 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x53280 (= active_1_L.cache active_0_L.cache)))
 (let (($x5848 (= v_1_T.control "CLOSED")))
 (let (($x12548 (= v_1_T.wire_flags 0)))
 (let (($x87447 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x97247 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x7159 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x7157 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x5133 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x7156 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x7155 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x97361 (= v_1_T.take 0)))
 (let (($x62374 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x62373 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x26846 (= v_1_T.snd_wnd 8)))
 (let (($x7158 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x12768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x11209 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x62544 (= v_1_T.local_window 16)))
 (let (($x13567 (= v_1_T.msl_ms 60000)))
 (let (($x13566 (= v_1_T.user_timeout_ms 30000)))
 (let (($x7087 (= v_1_T.retries 0)))
 (let (($x7088 (= v_1_T.rto_ms 1000)))
 (let (($x7092 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x7093 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x7094 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x7099 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x7100 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x7105 (= v_1_T.irs (_ bv0 32))))
 (let (($x7106 (= v_1_T.iss (_ bv1000 32))))
 (let (($x53246 (= v_1_L.control "PENDING")))
 (let (($x62407 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x91025 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x11208 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x53007 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x93933 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x5678 (not v_1_L.rxudp_require_checksum)))
 (let (($x53006 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x7121 (= v_1_L.ip_checksum 0)))
 (let (($x7122 (= v_1_L.udp_checksum 0)))
 (let (($x7125 (= v_1_L.udp_raw_checksum 0)))
 (let (($x7128 (= v_1_L.ip_length 0)))
 (let (($x7129 (= v_1_L.udp_length 0)))
 (let (($x53005 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x63195 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x53012 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x63107 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x63109 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x541 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x53045 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x87446 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x53222 (= 0 v_1_L.retry_count)))
 (let (($x13078 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x53220 (= 0 state_1)))
 (let (($x12867 (not active_0_T.time_wait)))
 (let (($x49 (or $x12867 (not (<= due_0_T.time_wait 0)))))
 (let (($x63656 (not active_0_T.user)))
 (let (($x63785 (or $x63656 (not (<= due_0_T.user 0)))))
 (let (($x13006 (not active_0_T.rtx)))
 (let (($x12636 (or $x13006 (not (<= due_0_T.rtx 0)))))
 (let (($x93959 (not active_0_L.cache)))
 (let (($x63767 (or $x93959 (not (<= due_0_L.cache 0)))))
 (let (($x12646 (not active_0_L.query)))
 (let (($x12892 (or $x12646 (not (<= due_0_L.query 0)))))
 (let (($x52892 (= state_0 0)))
 (and $x52892 (>= 0 now_0) $x12892 $x63767 $x12636 $x63785 $x49 $x53220 $x13078 $x53222 $x87446 v_1_L.checksums_enabled $x53045 $x541 $x63109 $x63107 $x53012 $x63195 $x53005 $x7129 $x7128 $x7125 $x7122 $x7121 $x53006 $x5678 $x93933 (= v_1_L.rxudp_disposition "none") $x53007 $x11208 $x91025 $x62407 (= v_1_L.echo_disposition "none") $x53246 $x7106 $x7105 $x7100 $x7099 $x7094 $x7093 $x7092 (= v_1_T.tx_flags "S") $x7088 $x7087 v_1_T.active_open $x13566 $x13567 $x62544 $x11209 $x12768 $x7158 $x26846 $x62373 $x62374 $x97361 $x7155 $x7156 $x5133 $x7157 $x7159 $x97247 $x87447 $x12548 (= v_1_T.wire_disposition "none") $x5848 (= v_1_ip_pending_owner "none") active_1_L.query $x53280 $x53281 $x53282 $x53283 $x97529 $x53285 $x53286 $x53287 $x53288))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x5546 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x5545 (= due_2_T.user due_1_T.user)))
 (let (($x5544 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x5542 (= due_2_L.query due_1_L.query)))
 (let (($x5541 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x5540 (= active_2_T.user active_1_T.user)))
 (let (($x5539 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x125516 (not active_2_L.query)))
 (let (($x5536 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x5535 (= v_2_T.control v_1_T.control)))
 (let (($x5534 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x5533 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x5532 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x5531 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x5530 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x5529 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x5528 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x5527 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x5526 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x5525 (= v_2_T.take v_1_T.take)))
 (let (($x5524 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x5523 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x5522 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x5521 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x5520 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x5519 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x5518 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x5517 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x5516 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x5515 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x5514 (= v_2_T.retries v_1_T.retries)))
 (let (($x5513 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x5512 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x5511 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x5510 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x5509 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x5508 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x5507 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x5506 (= v_2_T.irs v_1_T.irs)))
 (let (($x5505 (= v_2_T.iss v_1_T.iss)))
 (let (($x5504 (= v_2_L.control "RESOLVED")))
 (let (($x5503 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x5502 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x5501 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x5500 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x5499 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x5498 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x5497 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x5496 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x5495 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x5494 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x5493 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x5492 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x5491 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x5490 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x5489 (= v_2_L.packet v_1_L.packet)))
 (let (($x5488 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x5487 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x5486 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x5485 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x5484 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x5483 (= v_2_L.payload v_1_L.payload)))
 (let (($x5482 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x5481 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x5480 (= 0 v_2_L.retry_count)))
 (let ((?x53898 (seq.unit (_ bv0 8))))
 (let ((?x56027 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.unit (_ bv2 8))))))))
 (let ((?x53057 (seq.unit (_ bv2 8))))
 (let ((?x56028 (seq.++ ?x53057 ?x56027)))
 (let (($x12922 (= v_2_L.peer_mac ?x56028)))
 (let (($x5478 (= 0 state_2)))
 (let (($x12921 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x12871 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x63104 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x12955 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x7097 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x5447 (seq.len v_1_L.pending_packet)))
 (let (($x5457 (= 0 ?x5447)))
 (let (($x53246 (= v_1_L.control "PENDING")))
 (let (($x87458 (= state_1 0)))
 (and $x87458 $x53246 $x5457 $x7097 $x12955 $x63104 $x12871 $x12921 $x5478 $x12922 $x5480 $x5481 $x5482 $x5483 $x5484 $x5485 $x5486 $x5487 $x5488 $x5489 $x5490 $x5491 $x5492 $x5493 $x5494 $x5495 $x5496 $x5497 $x5498 $x5499 $x5500 $x5501 $x5502 $x5503 $x5504 $x5505 $x5506 $x5507 $x5508 $x5509 $x5510 $x5511 $x5512 $x5513 $x5514 $x5515 $x5516 $x5517 $x5518 $x5519 $x5520 $x5521 $x5522 $x5523 $x5524 $x5525 $x5526 $x5527 $x5528 $x5529 $x5530 $x5531 $x5532 $x5533 $x5534 $x5535 $x5536 $x125516 active_2_L.cache $x5539 $x5540 $x5541 $x5542 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x5544 $x5545 $x5546))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x51728 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x51727 (= due_3_T.user due_2_T.user)))
 (let (($x51726 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x51725 (= due_3_L.cache due_2_L.cache)))
 (let (($x51724 (= due_3_L.query due_2_L.query)))
 (let (($x51723 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x51722 (= active_3_T.user active_2_T.user)))
 (let (($x51721 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x51720 (= active_3_L.cache active_2_L.cache)))
 (let (($x51719 (= active_3_L.query active_2_L.query)))
 (let (($x51718 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x51717 (= v_3_T.control v_2_T.control)))
 (let (($x51716 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x51715 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x51714 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x51713 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x51712 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x51711 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x51710 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x51709 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x51708 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x51707 (= v_3_T.take v_2_T.take)))
 (let (($x51706 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x51705 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x51704 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x51703 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x51702 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x51701 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x51700 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x51699 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x51698 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x51697 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x51696 (= v_3_T.retries v_2_T.retries)))
 (let (($x51695 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x51694 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x51693 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x51692 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x51691 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x51690 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x51689 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x51688 (= v_3_T.irs v_2_T.irs)))
 (let (($x51687 (= v_3_T.iss v_2_T.iss)))
 (let (($x51686 (= v_3_L.control "RESOLVED")))
 (let (($x51685 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x51684 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x51683 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x51682 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x51681 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x51680 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x51679 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x51678 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x51677 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x51676 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x51675 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x51674 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x51673 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x51672 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x51671 (= v_3_L.packet v_2_L.packet)))
 (let (($x51670 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x51669 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x51668 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x51667 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x51666 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x51665 (= v_3_L.payload v_2_L.payload)))
 (let (($x51664 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x51663 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x51662 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x51661 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x51660 (= 0 state_3)))
 (let (($x87459 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x7120 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x7117 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x7112 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x125516 (not active_2_L.query)))
 (let (($x26730 (or $x125516 (not (<= due_2_L.query 20)))))
 (let (($x5504 (= v_2_L.control "RESOLVED")))
 (let (($x7176 (= state_2 0)))
 (and $x7176 $x5504 $x26730 $x7112 $x7117 $x7120 $x87459 $x51660 $x51661 $x51662 $x51663 $x51664 $x51665 $x51666 $x51667 $x51668 $x51669 $x51670 $x51671 $x51672 $x51673 $x51674 $x51675 $x51676 $x51677 $x51678 $x51679 $x51680 $x51681 $x51682 $x51683 $x51684 $x51685 $x51686 $x51687 $x51688 $x51689 $x51690 $x51691 $x51692 $x51693 $x51694 $x51695 $x51696 $x51697 $x51698 $x51699 $x51700 $x51701 $x51702 $x51703 $x51704 $x51705 $x51706 $x51707 $x51708 $x51709 $x51710 $x51711 $x51712 $x51713 $x51714 $x51715 $x51716 $x51717 $x51718 $x51719 $x51720 $x51721 $x51722 $x51723 $x51724 $x51725 $x51726 $x51727 $x51728)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x30838 (seq.unit (_ bv192 8))))
 (let ((?x52924 (seq.++ ?x30838 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x52924))))
(assert
 (= 30 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x30838 (seq.unit (_ bv192 8))))
 (let ((?x53192 (seq.++ ?x30838 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x53167 (seq.unit (_ bv1 8))))
 (let ((?x53898 (seq.unit (_ bv0 8))))
 (let ((?x15814 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53167 ?x53192)))))))
 (let ((?x53057 (seq.unit (_ bv2 8))))
 (let ((?x91365 (seq.++ ?x30838 (seq.++ ?x53898 (seq.++ ?x53057 (seq.++ ?x53057 (seq.++ ?x53057 ?x15814)))))))
 (let ((?x91366 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53057 ?x91365)))))))
 (let ((?x53179 (seq.unit (_ bv4 8))))
 (let ((?x53177 (seq.unit (_ bv6 8))))
 (let ((?x91371 (seq.++ ?x53177 (seq.++ ?x53179 (seq.++ ?x53898 (seq.++ ?x53057 (seq.++ ?x53057 ?x91366)))))))
 (let ((?x53175 (seq.unit (_ bv8 8))))
 (let ((?x55544 (seq.++ ?x53177 (seq.++ ?x53898 (seq.++ ?x53167 (seq.++ ?x53175 (seq.++ ?x53898 ?x91371)))))))
 (let ((?x1639 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53057 (seq.++ ?x53175 ?x55544)))))))
 (let ((?x91381 (seq.++ ?x53898 (seq.++ ?x53898 (seq.++ ?x53167 (seq.++ ?x53057 (seq.++ ?x53898 ?x1639)))))))
 (let ((?x91459 (seq.++ ?x53057 (seq.++ ?x53898 (seq.++ ?x53898 ?x91381)))))
 (= input_1_L.net.frame_frame ?x91459))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x30838 (seq.unit (_ bv192 8))))
(let ((?x52924 (seq.++ ?x30838 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x52924))))
(check-sat)

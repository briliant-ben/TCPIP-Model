; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x74301 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x54758 (= due_1_T.user due_0_T.user)))
 (let (($x82203 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x79737 (= due_1_L.cache 60000)))
 (let (($x56709 (= due_1_L.query due_0_L.query)))
 (let (($x54756 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x66864 (= active_1_T.user active_0_T.user)))
 (let (($x54755 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x54730 (not active_1_L.query)))
 (let (($x10274 (= v_1_T.control "CLOSED")))
 (let (($x59039 (= v_1_T.wire_flags 0)))
 (let (($x63755 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x7151 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x25512 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x3525 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x9259 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x53287 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x30833 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x11583 (= v_1_T.take 0)))
 (let (($x11584 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x11586 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x7124 (= v_1_T.snd_wnd 8)))
 (let (($x53288 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x12712 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x53282 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x13037 (= v_1_T.local_window 16)))
 (let (($x52878 (= v_1_T.msl_ms 60000)))
 (let (($x11533 (= v_1_T.user_timeout_ms 30000)))
 (let (($x40063 (= v_1_T.retries 0)))
 (let (($x40064 (= v_1_T.rto_ms 1000)))
 (let (($x65237 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x50263 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x30506 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x30750 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x47183 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x20231 (= v_1_T.irs (_ bv0 32))))
 (let (($x47182 (= v_1_T.iss (_ bv1000 32))))
 (let (($x87274 (= v_1_L.control "RESOLVED")))
 (let (($x53281 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x43435 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x11568 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x11567 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x52853 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x10104 (not v_1_L.rxudp_require_checksum)))
 (let (($x7146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x87445 (= v_1_L.ip_checksum 0)))
 (let (($x7138 (= v_1_L.udp_checksum 0)))
 (let (($x30845 (= v_1_L.udp_raw_checksum 0)))
 (let (($x7083 (= v_1_L.ip_length 0)))
 (let (($x11603 (= v_1_L.udp_length 0)))
 (let (($x7166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x7178 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x11581 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x11580 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x40095 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x40094 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x90287 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x40076 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x30872 (= 0 v_1_L.retry_count)))
 (let ((?x41923 (seq.unit (_ bv0 8))))
 (let ((?x30478 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.unit (_ bv2 8))))))))
 (let ((?x41924 (seq.unit (_ bv2 8))))
 (let ((?x25590 (seq.++ ?x41924 ?x30478)))
 (let (($x7182 (= v_1_L.peer_mac ?x25590)))
 (let (($x30873 (= 0 state_1)))
 (let (($x88851 (not active_0_T.time_wait)))
 (let (($x52937 (or $x88851 (not (<= due_0_T.time_wait 0)))))
 (let (($x41909 (not active_0_T.user)))
 (let (($x56290 (or $x41909 (not (<= due_0_T.user 0)))))
 (let (($x20253 (not active_0_T.rtx)))
 (let (($x90318 (or $x20253 (not (<= due_0_T.rtx 0)))))
 (let (($x45137 (not active_0_L.cache)))
 (let (($x30864 (or $x45137 (not (<= due_0_L.cache 0)))))
 (let (($x97517 (not active_0_L.query)))
 (let (($x11550 (or $x97517 (not (<= due_0_L.query 0)))))
 (let (($x45123 (= state_0 0)))
 (and $x45123 (>= 0 now_0) $x11550 $x30864 $x90318 $x56290 $x52937 $x30873 $x7182 $x30872 $x40076 v_1_L.checksums_enabled $x90287 $x40094 $x40095 $x11580 $x11581 $x7178 $x7166 $x11603 $x7083 $x30845 $x7138 $x87445 $x7146 $x10104 $x52853 (= v_1_L.rxudp_disposition "none") $x11567 $x11568 $x43435 $x53281 (= v_1_L.echo_disposition "none") $x87274 $x47182 $x20231 $x47183 $x30750 $x30506 $x50263 $x65237 (= v_1_T.tx_flags "S") $x40064 $x40063 v_1_T.active_open $x11533 $x52878 $x13037 $x53282 $x12712 $x53288 $x7124 $x11586 $x11584 $x11583 $x30833 $x53287 $x9259 $x3525 $x25512 $x7151 $x63755 $x59039 (= v_1_T.wire_disposition "none") $x10274 (= v_1_ip_pending_owner "none") $x54730 active_1_L.cache $x54755 $x66864 $x54756 $x56709 $x79737 $x82203 $x54758 $x74301))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x9930 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x9929 (= due_2_T.user due_1_T.user)))
 (let (($x9928 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x9926 (= due_2_L.query due_1_L.query)))
 (let (($x9925 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x9924 (= active_2_T.user active_1_T.user)))
 (let (($x9923 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x11606 (not active_2_L.query)))
 (let (($x9920 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x9919 (= v_2_T.control v_1_T.control)))
 (let (($x9918 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x9917 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x9916 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x9915 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x9914 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x9913 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x9912 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x9911 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x9910 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x9909 (= v_2_T.take v_1_T.take)))
 (let (($x9908 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x9907 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x9906 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x9905 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x9904 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x9903 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x9902 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x9901 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x9900 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x9899 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x9898 (= v_2_T.retries v_1_T.retries)))
 (let (($x9897 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x9896 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x9895 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x9894 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x9893 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x9892 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x9891 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x9890 (= v_2_T.irs v_1_T.irs)))
 (let (($x9889 (= v_2_T.iss v_1_T.iss)))
 (let (($x9888 (= v_2_L.control "RESOLVED")))
 (let (($x9887 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x9886 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x9885 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x9884 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x9883 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x9882 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x9881 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x9880 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x9879 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x9878 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x9877 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x9876 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x9875 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x9874 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x9873 (= v_2_L.packet v_1_L.packet)))
 (let (($x9872 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x9871 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x9870 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x9869 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x9868 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x9867 (= v_2_L.payload v_1_L.payload)))
 (let (($x9866 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x9865 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x9864 (= 0 v_2_L.retry_count)))
 (let ((?x41923 (seq.unit (_ bv0 8))))
 (let ((?x43427 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.unit (_ bv3 8))))))))
 (let ((?x41924 (seq.unit (_ bv2 8))))
 (let (($x7192 (= v_2_L.peer_mac (seq.++ ?x41924 ?x43427))))
 (let (($x9862 (= 0 state_2)))
 (let (($x7153 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x53064 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x87435 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x7189 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x54730 (not active_1_L.query)))
 (let (($x7185 (or $x54730 (not (<= due_1_L.query 5)))))
 (let (($x87274 (= v_1_L.control "RESOLVED")))
 (let (($x5321 (= state_1 0)))
 (and $x5321 $x87274 $x7185 $x7189 $x87435 $x53064 $x7153 $x9862 $x7192 $x9864 $x9865 $x9866 $x9867 $x9868 $x9869 $x9870 $x9871 $x9872 $x9873 $x9874 $x9875 $x9876 $x9877 $x9878 $x9879 $x9880 $x9881 $x9882 $x9883 $x9884 $x9885 $x9886 $x9887 $x9888 $x9889 $x9890 $x9891 $x9892 $x9893 $x9894 $x9895 $x9896 $x9897 $x9898 $x9899 $x9900 $x9901 $x9902 $x9903 $x9904 $x9905 $x9906 $x9907 $x9908 $x9909 $x9910 $x9911 $x9912 $x9913 $x9914 $x9915 $x9916 $x9917 $x9918 $x9919 $x9920 $x11606 active_2_L.cache $x9923 $x9924 $x9925 $x9926 (= due_2_L.cache (+ 5 v_1_L.cache_ttl_ms)) $x9928 $x9929 $x9930))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x38360 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x38359 (= due_3_T.user due_2_T.user)))
 (let (($x38358 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x38357 (= due_3_L.cache due_2_L.cache)))
 (let (($x38356 (= due_3_L.query due_2_L.query)))
 (let (($x38355 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x38354 (= active_3_T.user active_2_T.user)))
 (let (($x38353 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x38352 (= active_3_L.cache active_2_L.cache)))
 (let (($x38351 (= active_3_L.query active_2_L.query)))
 (let (($x38350 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x38349 (= v_3_T.control v_2_T.control)))
 (let (($x38348 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x38347 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x38346 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x38345 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x38344 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x38343 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x38342 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x38341 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x38340 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x38339 (= v_3_T.take v_2_T.take)))
 (let (($x38338 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x38337 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x38336 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x38335 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x38334 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x38333 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x38332 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x38331 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x38330 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x38329 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x38328 (= v_3_T.retries v_2_T.retries)))
 (let (($x38327 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x38326 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x38325 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x38324 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x38323 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x38322 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x38321 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x38320 (= v_3_T.irs v_2_T.irs)))
 (let (($x38319 (= v_3_T.iss v_2_T.iss)))
 (let (($x38318 (= v_3_L.control "RESOLVED")))
 (let (($x38317 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x38316 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x38315 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x38314 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x38313 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x38312 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x38311 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x38310 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x38309 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x38308 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x38307 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x38306 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x38305 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x38304 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x38303 (= v_3_L.packet v_2_L.packet)))
 (let (($x38302 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x38301 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x38300 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x38299 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x38298 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x38297 (= v_3_L.payload v_2_L.payload)))
 (let (($x38296 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x38295 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x38294 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x38293 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x38292 (= 0 state_3)))
 (let (($x40070 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 10)))))
 (let (($x11541 (or (not active_2_T.user) (not (<= due_2_T.user 10)))))
 (let (($x11537 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 10)))))
 (let (($x11543 (or (not active_2_L.cache) (not (<= due_2_L.cache 10)))))
 (let (($x11606 (not active_2_L.query)))
 (let (($x40090 (or $x11606 (not (<= due_2_L.query 10)))))
 (let (($x9888 (= v_2_L.control "RESOLVED")))
 (let (($x11602 (= state_2 0)))
 (and $x11602 $x9888 $x40090 $x11543 $x11537 $x11541 $x40070 $x38292 $x38293 $x38294 $x38295 $x38296 $x38297 $x38298 $x38299 $x38300 $x38301 $x38302 $x38303 $x38304 $x38305 $x38306 $x38307 $x38308 $x38309 $x38310 $x38311 $x38312 $x38313 $x38314 $x38315 $x38316 $x38317 $x38318 $x38319 $x38320 $x38321 $x38322 $x38323 $x38324 $x38325 $x38326 $x38327 $x38328 $x38329 $x38330 $x38331 $x38332 $x38333 $x38334 $x38335 $x38336 $x38337 $x38338 $x38339 $x38340 $x38341 $x38342 $x38343 $x38344 $x38345 $x38346 $x38347 $x38348 $x38349 $x38350 $x38351 $x38352 $x38353 $x38354 $x38355 $x38356 $x38357 $x38358 $x38359 $x38360)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x81350 (seq.unit (_ bv192 8))))
 (let ((?x54718 (seq.++ ?x81350 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x52948 (seq.unit (_ bv1 8))))
 (let ((?x41923 (seq.unit (_ bv0 8))))
 (let ((?x89760 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x52948 ?x54718)))))))
 (let ((?x41924 (seq.unit (_ bv2 8))))
 (let ((?x88223 (seq.++ ?x81350 (seq.++ ?x41923 (seq.++ ?x41924 (seq.++ ?x41924 (seq.++ ?x41924 ?x89760)))))))
 (let ((?x70055 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41924 ?x88223)))))))
 (let ((?x99146 (seq.unit (_ bv4 8))))
 (let ((?x99145 (seq.unit (_ bv6 8))))
 (let ((?x73205 (seq.++ ?x99145 (seq.++ ?x99146 (seq.++ ?x41923 (seq.++ ?x41924 (seq.++ ?x41924 ?x70055)))))))
 (let ((?x46978 (seq.unit (_ bv8 8))))
 (let ((?x72878 (seq.++ ?x99145 (seq.++ ?x41923 (seq.++ ?x52948 (seq.++ ?x46978 (seq.++ ?x41923 ?x73205)))))))
 (let ((?x69808 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41924 (seq.++ ?x46978 ?x72878)))))))
 (let ((?x83328 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x52948 (seq.++ ?x41924 (seq.++ ?x41923 ?x69808)))))))
 (let ((?x63288 (seq.++ ?x41924 (seq.++ ?x41923 (seq.++ ?x41923 ?x83328)))))
 (= input_0_L.net.frame_frame ?x63288))))))))))))))))))
(assert
 (= 16 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x81350 (seq.unit (_ bv192 8))))
 (let ((?x54718 (seq.++ ?x81350 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x52948 (seq.unit (_ bv1 8))))
 (let ((?x41923 (seq.unit (_ bv0 8))))
 (let ((?x89760 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x52948 ?x54718)))))))
 (let ((?x41924 (seq.unit (_ bv2 8))))
 (let ((?x88223 (seq.++ ?x81350 (seq.++ ?x41923 (seq.++ ?x41924 (seq.++ ?x41924 (seq.++ ?x41924 ?x89760)))))))
 (let ((?x89817 (seq.unit (_ bv3 8))))
 (let ((?x88794 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x89817 ?x88223)))))))
 (let ((?x99146 (seq.unit (_ bv4 8))))
 (let ((?x99145 (seq.unit (_ bv6 8))))
 (let ((?x69675 (seq.++ ?x99145 (seq.++ ?x99146 (seq.++ ?x41923 (seq.++ ?x41924 (seq.++ ?x41924 ?x88794)))))))
 (let ((?x46978 (seq.unit (_ bv8 8))))
 (let ((?x89111 (seq.++ ?x99145 (seq.++ ?x41923 (seq.++ ?x52948 (seq.++ ?x46978 (seq.++ ?x41923 ?x69675)))))))
 (let ((?x88088 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x89817 (seq.++ ?x46978 ?x89111)))))))
 (let ((?x80954 (seq.++ ?x41923 (seq.++ ?x41923 (seq.++ ?x52948 (seq.++ ?x41924 (seq.++ ?x41923 ?x88088)))))))
 (let ((?x89565 (seq.++ ?x41924 (seq.++ ?x41923 (seq.++ ?x41923 ?x80954)))))
 (= input_1_L.net.frame_frame ?x89565)))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x81350 (seq.unit (_ bv192 8))))
(let ((?x55373 (seq.++ ?x81350 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x55373))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x341 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x63590 (= due_1_T.user due_0_T.user)))
 (let (($x46 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x12621 (= due_1_L.cache due_0_L.cache)))
 (let (($x12624 (= due_1_L.query due_0_L.query)))
 (let (($x12619 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x12671 (= active_1_T.user active_0_T.user)))
 (let (($x12603 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x12674 (= active_1_L.cache active_0_L.cache)))
 (let (($x45 (= active_1_L.query active_0_L.query)))
 (let (($x52710 (= v_1_T.wire_flags 0)))
 (let (($x8791 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x8790 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x8789 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x8788 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x8787 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x8786 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x8785 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x11086 (= v_1_T.take 0)))
 (let (($x11087 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x11150 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x11151 (= v_1_T.snd_wnd 8)))
 (let (($x8784 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x8783 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x8782 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x97223 (= v_1_T.local_window 16)))
 (let (($x125464 (= v_1_T.msl_ms 60000)))
 (let (($x62396 (= v_1_T.user_timeout_ms 30000)))
 (let (($x125465 (= v_1_T.retries 0)))
 (let (($x62436 (= v_1_T.rto_ms 1000)))
 (let (($x63673 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x25175 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x63675 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x25177 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x25179 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x63677 (= v_1_T.irs (_ bv0 32))))
 (let (($x125475 (= v_1_T.iss (_ bv1000 32))))
 (let (($x12542 (= v_1_L.control "EMPTY")))
 (let (($x8781 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x8780 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x8779 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x8778 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x12560 (= v_1_L.rxudp_disposition "drop_ip_length")))
 (let (($x8777 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x8776 (not v_1_L.rxudp_require_checksum)))
 (let (($x8775 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x25221 (= v_1_L.ip_checksum 0)))
 (let (($x125448 (= v_1_L.udp_checksum 0)))
 (let (($x25223 (= v_1_L.udp_raw_checksum 0)))
 (let (($x125449 (= v_1_L.ip_length 0)))
 (let (($x25224 (= v_1_L.udp_length 0)))
 (let (($x8774 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x8773 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x8772 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x8771 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x8770 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x8769 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x8768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x25232 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x25234 (= v_1_L.retry_count 0)))
 (let (($x8767 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x12607 (= 0 state_1)))
 (let (($x26870 (not active_0_T.time_wait)))
 (let (($x8766 (or $x26870 (not (<= due_0_T.time_wait 0)))))
 (let (($x97537 (not active_0_T.user)))
 (let (($x8763 (or $x97537 (not (<= due_0_T.user 0)))))
 (let (($x62614 (not active_0_T.rtx)))
 (let (($x8760 (or $x62614 (not (<= due_0_T.rtx 0)))))
 (let (($x62615 (not active_0_L.cache)))
 (let (($x8757 (or $x62615 (not (<= due_0_L.cache 0)))))
 (let (($x97661 (not active_0_L.query)))
 (let (($x8754 (or $x97661 (not (<= due_0_L.query 0)))))
 (let (($x53099 (= state_0 0)))
 (and $x53099 (>= 0 now_0) $x8754 $x8757 $x8760 $x8763 $x8766 $x12607 $x8767 $x25234 $x25232 v_1_L.checksums_enabled $x8768 $x8769 $x8770 $x8771 $x8772 $x8773 $x8774 $x25224 $x125449 $x25223 $x125448 $x25221 $x8775 $x8776 $x8777 $x12560 $x8778 $x8779 $x8780 $x8781 (= v_1_L.echo_disposition "none") $x12542 $x125475 $x63677 $x25179 $x25177 $x63675 $x25175 $x63673 (= v_1_T.tx_flags "S") $x62436 $x125465 v_1_T.active_open $x62396 $x125464 $x97223 $x8782 $x8783 $x8784 $x11151 $x11150 $x11087 $x11086 $x8785 $x8786 $x8787 $x8788 $x8789 $x8790 $x8791 $x52710 (= v_1_T.wire_disposition "none") (= v_1_T.control "CLOSED") (= v_1_ip_pending_owner "none") $x45 $x12674 $x12603 $x12671 $x12619 $x12624 $x12621 $x46 $x63590 $x341)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 37 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x71 (seq.unit (_ bv0 8))))
(let ((?x8688 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 ?x71)))))))
(let ((?x8693 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 ?x8688)))))))
(let ((?x8684 (seq.unit (_ bv111 8))))
(let ((?x8682 (seq.unit (_ bv108 8))))
(let ((?x8698 (seq.++ ?x8682 (seq.++ ?x8682 (seq.++ ?x8684 (seq.++ ?x71 (seq.++ ?x71 ?x8693)))))))
(let ((?x8680 (seq.unit (_ bv101 8))))
(let ((?x8678 (seq.unit (_ bv104 8))))
(let ((?x8676 (seq.unit (_ bv45 8))))
(let ((?x8674 (seq.unit (_ bv124 8))))
(let ((?x8672 (seq.unit (_ bv13 8))))
(let ((?x8703 (seq.++ ?x8672 (seq.++ ?x8674 (seq.++ ?x8676 (seq.++ ?x8678 (seq.++ ?x8680 ?x8698)))))))
(let ((?x91010 (seq.unit (_ bv64 8))))
(let ((?x52832 (seq.unit (_ bv156 8))))
(let ((?x91012 (seq.unit (_ bv144 8))))
(let ((?x91007 (seq.unit (_ bv31 8))))
(let ((?x8708 (seq.++ ?x91007 (seq.++ ?x91012 (seq.++ ?x52832 (seq.++ ?x91010 (seq.++ ?x71 ?x8703)))))))
(let ((?x34718 (seq.unit (_ bv1 8))))
(let ((?x62697 (seq.unit (_ bv2 8))))
(let ((?x57720 (seq.unit (_ bv192 8))))
(let ((?x8713 (seq.++ ?x62697 (seq.++ ?x57720 (seq.++ ?x71 (seq.++ ?x62697 (seq.++ ?x34718 ?x8708)))))))
(let ((?x8670 (seq.unit (_ bv206 8))))
(let ((?x8668 (seq.unit (_ bv182 8))))
(let ((?x8718 (seq.++ ?x8668 (seq.++ ?x8670 (seq.++ ?x57720 (seq.++ ?x71 (seq.++ ?x62697 ?x8713)))))))
(let ((?x52826 (seq.unit (_ bv17 8))))
(let ((?x8723 (seq.++ ?x71 (seq.++ ?x91010 (seq.++ ?x71 (seq.++ ?x91010 (seq.++ ?x52826 ?x8718)))))))
(let ((?x8666 (seq.unit (_ bv27 8))))
(let ((?x32299 (seq.unit (_ bv69 8))))
(let ((?x8728 (seq.++ ?x32299 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x8666 (seq.++ ?x71 ?x8723)))))))
(let ((?x11202 (seq.unit (_ bv8 8))))
(let ((?x8733 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x62697 (seq.++ ?x11202 (seq.++ ?x71 ?x8728)))))))
(let ((?x8738 (seq.++ ?x71 (seq.++ ?x34718 (seq.++ ?x62697 (seq.++ ?x71 (seq.++ ?x71 ?x8733)))))))
(let ((?x8742 (seq.++ ?x62697 (seq.++ ?x71 (seq.++ ?x71 (seq.++ ?x71 ?x8738))))))
(= input_0_L.net.frame_frame ?x8742)))))))))))))))))))))))))))))))))))
(check-sat)

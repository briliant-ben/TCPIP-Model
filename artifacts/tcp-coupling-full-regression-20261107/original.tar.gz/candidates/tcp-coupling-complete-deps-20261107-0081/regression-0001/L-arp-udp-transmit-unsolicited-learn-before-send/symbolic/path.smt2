; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x32862 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x8341 (= due_1_T.user due_0_T.user)))
 (let (($x90352 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x32470 (= due_1_L.cache 60000)))
 (let (($x8340 (= due_1_L.query due_0_L.query)))
 (let (($x5507 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x102137 (= active_1_T.user active_0_T.user)))
 (let (($x8339 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x45455 (not active_1_L.query)))
 (let (($x37833 (= v_1_T.control "CLOSED")))
 (let (($x10631 (= v_1_T.wire_flags 0)))
 (let (($x32469 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x59366 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x99143 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x58236 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x59036 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x69310 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x97418 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x10457 (= v_1_T.take 0)))
 (let (($x10458 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x10459 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x10460 (= v_1_T.snd_wnd 8)))
 (let (($x82702 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x68418 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x56158 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x10537 (= v_1_T.local_window 16)))
 (let (($x10538 (= v_1_T.msl_ms 60000)))
 (let (($x10539 (= v_1_T.user_timeout_ms 30000)))
 (let (($x10540 (= v_1_T.retries 0)))
 (let (($x10509 (= v_1_T.rto_ms 1000)))
 (let (($x10534 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x51721 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x10535 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x10536 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x10400 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x10398 (= v_1_T.irs (_ bv0 32))))
 (let (($x10399 (= v_1_T.iss (_ bv1000 32))))
 (let (($x52488 (= v_1_L.control "RESOLVED")))
 (let (($x70650 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x101269 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x10496 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x10495 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x10490 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x37661 (not v_1_L.rxudp_require_checksum)))
 (let (($x10489 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x10471 (= v_1_L.ip_checksum 0)))
 (let (($x10472 (= v_1_L.udp_checksum 0)))
 (let (($x13116 (= v_1_L.udp_raw_checksum 0)))
 (let (($x13117 (= v_1_L.ip_length 0)))
 (let (($x13118 (= v_1_L.udp_length 0)))
 (let (($x10488 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x4756 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x4755 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x13210 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x13209 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x28722 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x52291 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x13099 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x8262 (= 0 v_1_L.retry_count)))
 (let ((?x90186 (seq.unit (_ bv0 8))))
 (let ((?x27518 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.unit (_ bv2 8))))))))
 (let ((?x102015 (seq.unit (_ bv2 8))))
 (let ((?x3776 (seq.++ ?x102015 ?x27518)))
 (let (($x13102 (= v_1_L.peer_mac ?x3776)))
 (let (($x87577 (= 0 state_1)))
 (let (($x27362 (not active_0_T.time_wait)))
 (let (($x13101 (or $x27362 (not (<= due_0_T.time_wait 0)))))
 (let (($x52467 (not active_0_T.user)))
 (let (($x10599 (or $x52467 (not (<= due_0_T.user 0)))))
 (let (($x98662 (not active_0_T.rtx)))
 (let (($x13179 (or $x98662 (not (<= due_0_T.rtx 0)))))
 (let (($x101871 (not active_0_L.cache)))
 (let (($x56117 (or $x101871 (not (<= due_0_L.cache 0)))))
 (let (($x44006 (not active_0_L.query)))
 (let (($x4761 (or $x44006 (not (<= due_0_L.query 0)))))
 (let (($x8134 (= state_0 0)))
 (and $x8134 (>= 0 now_0) $x4761 $x56117 $x13179 $x10599 $x13101 $x87577 $x13102 $x8262 $x13099 v_1_L.checksums_enabled $x52291 $x28722 $x13209 $x13210 $x4755 $x4756 $x10488 $x13118 $x13117 $x13116 $x10472 $x10471 $x10489 $x37661 $x10490 (= v_1_L.rxudp_disposition "none") $x10495 $x10496 $x101269 $x70650 (= v_1_L.echo_disposition "none") $x52488 $x10399 $x10398 $x10400 $x10536 $x10535 $x51721 $x10534 (= v_1_T.tx_flags "S") $x10509 $x10540 v_1_T.active_open $x10539 $x10538 $x10537 $x56158 $x68418 $x82702 $x10460 $x10459 $x10458 $x10457 $x97418 $x69310 $x59036 $x58236 $x99143 $x59366 $x32469 $x10631 (= v_1_T.wire_disposition "none") $x37833 (= v_1_ip_pending_owner "none") $x45455 active_1_L.cache $x8339 $x102137 $x5507 $x8340 $x32470 $x90352 $x8341 $x32862))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x37501 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x37500 (= due_2_T.user due_1_T.user)))
 (let (($x37499 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x37498 (= due_2_L.cache due_1_L.cache)))
 (let (($x37497 (= due_2_L.query due_1_L.query)))
 (let (($x37496 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x37495 (= active_2_T.user active_1_T.user)))
 (let (($x37494 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x37493 (= active_2_L.cache active_1_L.cache)))
 (let (($x37492 (= active_2_L.query active_1_L.query)))
 (let (($x37491 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x37490 (= v_2_T.control v_1_T.control)))
 (let (($x37489 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x37488 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x37487 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x37486 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x37485 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x37484 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x37483 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x37482 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x37481 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x37480 (= v_2_T.take v_1_T.take)))
 (let (($x37479 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x37478 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x37477 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x37476 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x37475 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x37474 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x37473 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x37472 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x37471 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x37470 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x37469 (= v_2_T.retries v_1_T.retries)))
 (let (($x37468 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x37467 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x37466 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x37465 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x37464 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x37463 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x37462 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x37461 (= v_2_T.irs v_1_T.irs)))
 (let (($x37460 (= v_2_T.iss v_1_T.iss)))
 (let (($x37459 (= v_2_L.control "RESOLVED")))
 (let (($x37458 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x37457 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x37456 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x37455 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x37454 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x37453 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x37452 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x37451 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x37450 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x89437 (= v_2_L.ip_checksum 46797)))
 (let ((?x45457 (ite v_1_L.checksums_enabled 49161 0)))
 (let (($x89950 (= v_2_L.udp_checksum ?x45457)))
 (let (($x89949 (= v_2_L.udp_raw_checksum 49161)))
 (let (($x68824 (= v_2_L.ip_length 28)))
 (let (($x68823 (= v_2_L.udp_length 8)))
 (let ((?x6632 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x45457))) (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x45457))))))
 (let ((?x27337 (seq.unit (_ bv8 8))))
 (let ((?x90186 (seq.unit (_ bv0 8))))
 (let ((?x59522 (seq.unit (_ bv144 8))))
 (let ((?x101906 (seq.unit (_ bv31 8))))
 (let ((?x103011 (seq.unit (_ bv64 8))))
 (let ((?x23467 (seq.++ ?x103011 (seq.++ ?x101906 (seq.++ ?x59522 (seq.++ ?x90186 (seq.++ ?x27337 ?x6632)))))))
 (let ((?x103013 (seq.unit (_ bv156 8))))
 (let ((?x16694 (seq.++ ?x103013 ?x23467)))
 (let ((?x102015 (seq.unit (_ bv2 8))))
 (let ((?x59198 (seq.unit (_ bv192 8))))
 (let ((?x88028 (seq.unit (_ bv1 8))))
 (let ((?x73123 (seq.++ ?x88028 (seq.++ ?x59198 (seq.++ ?x90186 (seq.++ ?x102015 (seq.++ ?x102015 ?x16694)))))))
 (let ((?x72220 (seq.unit (_ bv205 8))))
 (let ((?x85102 (seq.unit (_ bv182 8))))
 (let ((?x82951 (seq.++ ?x85102 (seq.++ ?x72220 (seq.++ ?x59198 (seq.++ ?x90186 (seq.++ ?x102015 ?x73123)))))))
 (let ((?x80251 (seq.unit (_ bv17 8))))
 (let ((?x78723 (seq.++ ?x90186 (seq.++ ?x103011 (seq.++ ?x90186 (seq.++ ?x103011 (seq.++ ?x80251 ?x82951)))))))
 (let ((?x66062 (seq.unit (_ bv28 8))))
 (let ((?x80632 (seq.unit (_ bv69 8))))
 (let ((?x68820 (seq.++ ?x80632 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x66062 (seq.++ ?x90186 ?x78723)))))))
 (let (($x68822 (= v_2_L.packet ?x68820)))
 (let ((?x13241 (seq.++ ?x102015 (seq.++ ?x88028 (seq.++ ?x59198 (seq.++ ?x90186 (seq.++ ?x102015 ?x102015)))))))
 (let ((?x47700 (seq.++ ?x59198 (seq.++ ?x90186 ?x13241))))
 (let ((?x87291 (seq.++ ?x90186 (seq.++ ?x103011 (seq.++ ?x80251 (seq.++ ?x85102 (seq.++ ?x72220 ?x47700)))))))
 (let ((?x71386 (seq.++ ?x90186 (seq.++ ?x66062 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x103011 ?x87291)))))))
 (let (($x82346 (= v_2_L.ip_wire (seq.++ ?x80632 (seq.++ ?x90186 ?x71386)))))
 (let ((?x88618 (seq.++ ?x90186 (seq.++ ?x103011 (seq.++ ?x80251 (seq.++ ?x90186 (seq.++ ?x90186 ?x47700)))))))
 (let ((?x77517 (seq.++ ?x90186 (seq.++ ?x66062 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x103011 ?x88618)))))))
 (let (($x89269 (= v_2_L.ip_zero (seq.++ ?x80632 (seq.++ ?x90186 ?x77517)))))
 (let (($x66059 (= v_2_L.udp_wire ?x16694)))
 (let ((?x59435 (seq.++ ?x102015 (seq.++ ?x102015 (seq.++ ?x90186 (seq.++ ?x80251 (seq.++ ?x90186 ?x27337)))))))
 (let ((?x56089 (seq.++ ?x90186 (seq.++ ?x102015 (seq.++ ?x88028 (seq.++ ?x59198 (seq.++ ?x90186 ?x59435)))))))
 (let (($x59171 (= v_2_L.pseudoheader (seq.++ ?x59198 ?x56089))))
 (let ((?x8968 (seq.++ ?x101906 (seq.++ ?x59522 (seq.++ ?x90186 (seq.++ ?x27337 (seq.++ ?x90186 ?x90186)))))))
 (let (($x10612 (= v_2_L.udp_zero (seq.++ ?x103013 (seq.++ ?x103011 ?x8968)))))
 (let (($x10628 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.payload)))
 (let (($x37437 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x37436 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x37435 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x37434 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x37433 (= 0 state_2)))
 (let (($x47698 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x13188 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x13184 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x13180 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x45455 (not active_1_L.query)))
 (let (($x13240 (or $x45455 (not (<= due_1_L.query 1)))))
 (let (($x52488 (= v_1_L.control "RESOLVED")))
 (let (($x48445 (= state_1 0)))
 (and $x48445 $x52488 $x13240 $x13180 $x13184 $x13188 $x47698 $x37433 $x37434 $x37435 $x37436 $x37437 $x10628 $x10612 $x59171 $x66059 $x89269 $x82346 $x68822 $x68823 $x68824 $x89949 $x89950 $x89437 $x37450 $x37451 $x37452 $x37453 $x37454 $x37455 $x37456 $x37457 $x37458 $x37459 $x37460 $x37461 $x37462 $x37463 $x37464 $x37465 $x37466 $x37467 $x37468 $x37469 $x37470 $x37471 $x37472 $x37473 $x37474 $x37475 $x37476 $x37477 $x37478 $x37479 $x37480 $x37481 $x37482 $x37483 $x37484 $x37485 $x37486 $x37487 $x37488 $x37489 $x37490 $x37491 $x37492 $x37493 $x37494 $x37495 $x37496 $x37497 $x37498 $x37499 $x37500 $x37501))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x64614 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x64613 (= due_3_T.user due_2_T.user)))
 (let (($x96788 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x96787 (= due_3_L.cache due_2_L.cache)))
 (let (($x64612 (= due_3_L.query due_2_L.query)))
 (let (($x64611 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x293 (= active_3_T.user active_2_T.user)))
 (let (($x64610 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x64609 (= active_3_L.cache active_2_L.cache)))
 (let (($x64608 (= active_3_L.query active_2_L.query)))
 (let (($x64607 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x64606 (= v_3_T.control v_2_T.control)))
 (let (($x64605 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x64604 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x64603 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x64602 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x64601 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x64600 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x64599 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x64598 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x64597 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x64596 (= v_3_T.take v_2_T.take)))
 (let (($x64595 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x64594 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x64593 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x64592 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x64591 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x64590 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x64589 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x64588 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x64587 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x64586 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x64585 (= v_3_T.retries v_2_T.retries)))
 (let (($x64584 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x64583 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x64582 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x64581 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x64580 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x64579 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x64578 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x64577 (= v_3_T.irs v_2_T.irs)))
 (let (($x64576 (= v_3_T.iss v_2_T.iss)))
 (let (($x64575 (= v_3_L.control "RESOLVED")))
 (let (($x64574 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x64573 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x64572 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x64571 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x64570 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x64569 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x64568 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x64567 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x64566 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x64565 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x64564 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x64563 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x64562 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x64561 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x64560 (= v_3_L.packet v_2_L.packet)))
 (let (($x64559 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x64558 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x64557 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x64556 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x64555 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x64554 (= v_3_L.payload v_2_L.payload)))
 (let (($x64553 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x64552 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x64551 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x64550 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x64549 (= 0 state_3)))
 (let (($x10550 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x10585 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x52029 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x10588 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x13232 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let (($x37459 (= v_2_L.control "RESOLVED")))
 (let (($x10418 (= state_2 0)))
 (and $x10418 $x37459 $x13232 $x10588 $x52029 $x10585 $x10550 $x64549 $x64550 $x64551 $x64552 $x64553 $x64554 $x64555 $x64556 $x64557 $x64558 $x64559 $x64560 $x64561 $x64562 $x64563 $x64564 $x64565 $x64566 $x64567 $x64568 $x64569 $x64570 $x64571 $x64572 $x64573 $x64574 $x64575 $x64576 $x64577 $x64578 $x64579 $x64580 $x64581 $x64582 $x64583 $x64584 $x64585 $x64586 $x64587 $x64588 $x64589 $x64590 $x64591 $x64592 $x64593 $x64594 $x64595 $x64596 $x64597 $x64598 $x64599 $x64600 $x64601 $x64602 $x64603 $x64604 $x64605 $x64606 $x64607 $x64608 $x64609 $x64610 $x293 $x64611 $x64612 $x96787 $x96788 $x64613 $x64614))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x59198 (seq.unit (_ bv192 8))))
 (let ((?x30993 (seq.++ ?x59198 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x88028 (seq.unit (_ bv1 8))))
 (let ((?x90186 (seq.unit (_ bv0 8))))
 (let ((?x77400 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x88028 ?x30993)))))))
 (let ((?x102015 (seq.unit (_ bv2 8))))
 (let ((?x77125 (seq.++ ?x59198 (seq.++ ?x90186 (seq.++ ?x102015 (seq.++ ?x102015 (seq.++ ?x102015 ?x77400)))))))
 (let ((?x79951 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x102015 ?x77125)))))))
 (let ((?x79465 (seq.unit (_ bv4 8))))
 (let ((?x27238 (seq.unit (_ bv6 8))))
 (let ((?x75944 (seq.++ ?x27238 (seq.++ ?x79465 (seq.++ ?x90186 (seq.++ ?x102015 (seq.++ ?x102015 ?x79951)))))))
 (let ((?x27337 (seq.unit (_ bv8 8))))
 (let ((?x84515 (seq.++ ?x27238 (seq.++ ?x90186 (seq.++ ?x88028 (seq.++ ?x27337 (seq.++ ?x90186 ?x75944)))))))
 (let ((?x85955 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x102015 (seq.++ ?x27337 ?x84515)))))))
 (let ((?x84583 (seq.++ ?x90186 (seq.++ ?x90186 (seq.++ ?x88028 (seq.++ ?x102015 (seq.++ ?x90186 ?x85955)))))))
 (let ((?x67405 (seq.++ ?x102015 (seq.++ ?x90186 (seq.++ ?x90186 ?x84583)))))
 (= input_0_L.net.frame_frame ?x67405))))))))))))))))))
(assert
 (= 22 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_L.app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 2 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x59198 (seq.unit (_ bv192 8))))
(let ((?x71895 (seq.++ ?x59198 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x71895))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.send_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x1670 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x62589 (= due_1_T.user due_0_T.user)))
 (let (($x41920 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x59731 (= due_1_L.cache due_0_L.cache)))
 (let (($x75269 (= due_1_L.query 1000)))
 (let (($x14387 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x89565 (= active_1_T.user active_0_T.user)))
 (let (($x1723 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x1678 (= active_1_L.cache active_0_L.cache)))
 (let (($x56302 (= v_1_ip_pending_owner "UDP")))
 (let (($x52777 (= v_1_T.control "CLOSED")))
 (let (($x45035 (= v_1_T.wire_flags 0)))
 (let (($x75268 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x85393 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x60321 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x75649 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x67673 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x67671 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x67756 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x52591 (= v_1_T.take 0)))
 (let (($x52772 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x83882 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x86096 (= v_1_T.snd_wnd 8)))
 (let (($x67758 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x73108 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x87133 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3579 (= v_1_T.local_window 16)))
 (let (($x3578 (= v_1_T.msl_ms 60000)))
 (let (($x72979 (= v_1_T.user_timeout_ms 30000)))
 (let (($x87678 (= v_1_T.retries 0)))
 (let (($x15816 (= v_1_T.rto_ms 1000)))
 (let (($x56640 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x55443 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x9868 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x83082 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x2711 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x51721 (= v_1_T.irs (_ bv0 32))))
 (let (($x52943 (= v_1_T.iss (_ bv1000 32))))
 (let (($x40314 (= v_1_L.control "PENDING")))
 (let (($x71376 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x87397 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x78241 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x73157 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x73604 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x3468 (not v_1_L.rxudp_require_checksum)))
 (let ((?x43432 (seq.unit (_ bv0 8))))
 (let ((?x3847 (seq.++ ?x43432 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
 (let ((?x30720 (seq.unit (_ bv144 8))))
 (let ((?x56334 (seq.unit (_ bv31 8))))
 (let ((?x14353 (seq.unit (_ bv64 8))))
 (let ((?x32975 (seq.unit (_ bv156 8))))
 (let ((?x41085 (seq.++ ?x32975 (seq.++ ?x14353 (seq.++ ?x56334 (seq.++ ?x30720 ?x3847))))))
 (let ((?x14393 (seq.unit (_ bv2 8))))
 (let ((?x52291 (seq.unit (_ bv192 8))))
 (let ((?x38344 (seq.unit (_ bv1 8))))
 (let ((?x69007 (seq.++ ?x38344 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 (seq.++ ?x14393 ?x41085)))))))
 (let ((?x11606 (seq.unit (_ bv205 8))))
 (let ((?x52441 (seq.unit (_ bv182 8))))
 (let ((?x79265 (seq.++ ?x52441 (seq.++ ?x11606 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 ?x69007)))))))
 (let ((?x86241 (seq.unit (_ bv17 8))))
 (let ((?x86937 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x86241 ?x79265)))))))
 (let ((?x41167 (seq.unit (_ bv28 8))))
 (let ((?x3520 (seq.unit (_ bv69 8))))
 (let ((?x89362 (seq.++ ?x3520 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x41167 (seq.++ ?x43432 ?x86937)))))))
 (let (($x73603 (= v_1_L.pending_packet ?x89362)))
 (let (($x87826 (= v_1_L.ip_checksum 46797)))
 (let (($x87825 (= v_1_L.udp_checksum 49161)))
 (let (($x88338 (= v_1_L.udp_raw_checksum 49161)))
 (let (($x88337 (= v_1_L.ip_length 28)))
 (let (($x88850 (= v_1_L.udp_length 8)))
 (let (($x88849 (= v_1_L.packet ?x89362)))
 (let ((?x11111 (seq.++ ?x14393 (seq.++ ?x38344 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 ?x14393)))))))
 (let ((?x87908 (seq.++ ?x52291 (seq.++ ?x43432 ?x11111))))
 (let ((?x86061 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x86241 (seq.++ ?x52441 (seq.++ ?x11606 ?x87908)))))))
 (let ((?x76480 (seq.++ ?x43432 (seq.++ ?x41167 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x14353 ?x86061)))))))
 (let (($x83012 (= v_1_L.ip_wire (seq.++ ?x3520 (seq.++ ?x43432 ?x76480)))))
 (let ((?x32753 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x86241 (seq.++ ?x43432 (seq.++ ?x43432 ?x87908)))))))
 (let ((?x32751 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x14353 ?x32753)))))
 (let (($x32666 (= v_1_L.ip_zero (seq.++ ?x3520 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x41167 ?x32751)))))))
 (let (($x41122 (= v_1_L.udp_wire ?x41085)))
 (let ((?x56649 (seq.++ ?x14393 (seq.++ ?x43432 (seq.++ ?x86241 (seq.++ ?x43432 (seq.unit (_ bv8 8))))))))
 (let ((?x41347 (seq.++ ?x14393 (seq.++ ?x38344 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 ?x56649)))))))
 (let (($x41143 (= v_1_L.pseudoheader (seq.++ ?x52291 (seq.++ ?x43432 ?x41347)))))
 (let ((?x11182 (seq.++ ?x30720 (seq.++ ?x43432 (seq.++ (seq.unit (_ bv8 8)) (seq.++ ?x43432 ?x43432))))))
 (let (($x52569 (= v_1_L.udp_zero (seq.++ ?x32975 (seq.++ ?x14353 (seq.++ ?x56334 ?x11182))))))
 (let (($x52638 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x41313 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x40293 (= 0 v_1_L.retry_count)))
 (let (($x52637 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x12804 (= 0 state_1)))
 (let (($x53526 (not active_0_T.time_wait)))
 (let (($x52636 (or $x53526 (not (<= due_0_T.time_wait 0)))))
 (let (($x40075 (not active_0_T.user)))
 (let (($x52634 (or $x40075 (not (<= due_0_T.user 0)))))
 (let (($x32580 (not active_0_T.rtx)))
 (let (($x52630 (or $x32580 (not (<= due_0_T.rtx 0)))))
 (let (($x36812 (not active_0_L.cache)))
 (let (($x52627 (or $x36812 (not (<= due_0_L.cache 0)))))
 (let (($x74222 (not active_0_L.query)))
 (let (($x52625 (or $x74222 (not (<= due_0_L.query 0)))))
 (let (($x40265 (= state_0 0)))
 (and $x40265 (>= 0 now_0) $x52625 $x52627 $x52630 $x52634 $x52636 $x12804 $x52637 $x40293 $x41313 v_1_L.checksums_enabled $x52638 $x52569 $x41143 $x41122 $x32666 $x83012 $x88849 $x88850 $x88337 $x88338 $x87825 $x87826 $x73603 $x3468 $x73604 (= v_1_L.rxudp_disposition "none") $x73157 $x78241 $x87397 $x71376 (= v_1_L.echo_disposition "none") $x40314 $x52943 $x51721 $x2711 $x83082 $x9868 $x55443 $x56640 (= v_1_T.tx_flags "S") $x15816 $x87678 v_1_T.active_open $x72979 $x3578 $x3579 $x87133 $x73108 $x67758 $x86096 $x83882 $x52772 $x52591 $x67756 $x67671 $x67673 $x75649 $x60321 $x85393 $x75268 $x45035 (= v_1_T.wire_disposition "none") $x52777 $x56302 active_1_L.query $x1678 $x1723 $x89565 $x14387 $x75269 $x59731 $x41920 $x62589 $x1670)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3333 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x3332 (= due_2_T.user due_1_T.user)))
 (let (($x3331 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x3329 (= due_2_L.query due_1_L.query)))
 (let (($x3328 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x3327 (= active_2_T.user active_1_T.user)))
 (let (($x3326 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x63774 (not active_2_L.query)))
 (let (($x3323 (= v_2_ip_pending_owner "none")))
 (let (($x3322 (= v_2_T.control v_1_T.control)))
 (let (($x3321 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x3320 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x3319 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x3318 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x3317 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x3316 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x3315 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x3314 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x3313 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x3312 (= v_2_T.take v_1_T.take)))
 (let (($x3311 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x3310 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x3309 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x3308 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x3307 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x3306 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x3305 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x3304 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x3303 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x3302 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x3301 (= v_2_T.retries v_1_T.retries)))
 (let (($x3300 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x3299 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x3298 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x3297 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x3296 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x3295 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x3294 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x12769 (= v_2_T.irs v_1_T.irs)))
 (let (($x3293 (= v_2_T.iss v_1_T.iss)))
 (let (($x3292 (= v_2_L.control "RESOLVED")))
 (let (($x3291 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x3290 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x3289 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x3288 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x3287 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x3286 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x3285 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x3284 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x10659 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x3282 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x3281 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x3280 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x3279 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x3278 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x3277 (= v_2_L.packet v_1_L.packet)))
 (let (($x3276 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x3275 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x3274 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x3273 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x3272 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x3271 (= v_2_L.payload v_1_L.payload)))
 (let (($x3270 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x3269 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x3268 (= 0 v_2_L.retry_count)))
 (let ((?x43432 (seq.unit (_ bv0 8))))
 (let ((?x83692 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.unit (_ bv2 8))))))))
 (let ((?x14393 (seq.unit (_ bv2 8))))
 (let ((?x20292 (seq.++ ?x14393 ?x83692)))
 (let (($x51685 (= v_2_L.peer_mac ?x20292)))
 (let (($x3266 (= 0 state_2)))
 (let (($x41406 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x11106 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x41133 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x41394 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x11095 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x3223 (seq.len v_1_L.pending_packet)))
 (let (($x3224 (<= 28 ?x3223)))
 (let (($x40314 (= v_1_L.control "PENDING")))
 (let (($x32746 (= state_1 0)))
 (and $x32746 $x40314 $x3224 $x11095 $x41394 $x41133 $x11106 $x41406 $x3266 $x51685 $x3268 $x3269 $x3270 $x3271 $x3272 $x3273 $x3274 $x3275 $x3276 $x3277 $x3278 $x3279 $x3280 $x3281 $x3282 $x10659 $x3284 $x3285 $x3286 $x3287 $x3288 $x3289 $x3290 $x3291 $x3292 $x3293 $x12769 $x3294 $x3295 $x3296 $x3297 $x3298 $x3299 $x3300 $x3301 $x3302 $x3303 $x3304 $x3305 $x3306 $x3307 $x3308 $x3309 $x3310 $x3311 $x3312 $x3313 $x3314 $x3315 $x3316 $x3317 $x3318 $x3319 $x3320 $x3321 $x3322 $x3323 $x63774 active_2_L.cache $x3326 $x3327 $x3328 $x3329 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x3331 $x3332 $x3333))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x35715 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x35714 (= due_3_T.user due_2_T.user)))
 (let (($x35713 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x35712 (= due_3_L.cache due_2_L.cache)))
 (let (($x35711 (= due_3_L.query due_2_L.query)))
 (let (($x35710 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x35709 (= active_3_T.user active_2_T.user)))
 (let (($x35708 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x35707 (= active_3_L.cache active_2_L.cache)))
 (let (($x35706 (= active_3_L.query active_2_L.query)))
 (let (($x35705 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x35704 (= v_3_T.control v_2_T.control)))
 (let (($x35703 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x35702 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x35701 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x35700 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x35699 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x35698 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x35697 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x35696 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x35695 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x35694 (= v_3_T.take v_2_T.take)))
 (let (($x35693 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x35692 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x35691 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x35690 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x35689 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x35688 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x35687 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x35686 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x35685 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x35681 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x35680 (= v_3_T.retries v_2_T.retries)))
 (let (($x35679 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x35678 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x35677 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x35676 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x35675 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x35671 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x35670 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x35666 (= v_3_T.irs v_2_T.irs)))
 (let (($x35665 (= v_3_T.iss v_2_T.iss)))
 (let (($x35660 (= v_3_L.control "RESOLVED")))
 (let (($x35659 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x35658 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x35657 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x35653 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x35652 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x35651 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x35650 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x35645 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x35644 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x61307 (= v_3_L.ip_checksum 46792)))
 (let ((?x12824 (ite v_2_L.checksums_enabled 49271 0)))
 (let (($x61308 (= v_3_L.udp_checksum ?x12824)))
 (let (($x61336 (= v_3_L.udp_raw_checksum 49271)))
 (let (($x45109 (= v_3_L.ip_length 33)))
 (let (($x45038 (= v_3_L.udp_length 13)))
 (let ((?x66133 (seq.unit (_ bv128 8))))
 (let ((?x13415 (seq.++ ?x66133 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x43432 (seq.unit (_ bv0 8))))
 (let ((?x76139 (seq.++ ?x43432 ?x13415)))
 (let ((?x3523 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x12824))) (seq.++ (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x12824))) ?x76139))))
 (let ((?x41376 (seq.unit (_ bv13 8))))
 (let ((?x30720 (seq.unit (_ bv144 8))))
 (let ((?x56334 (seq.unit (_ bv31 8))))
 (let ((?x14353 (seq.unit (_ bv64 8))))
 (let ((?x12959 (seq.++ ?x14353 (seq.++ ?x56334 (seq.++ ?x30720 (seq.++ ?x43432 (seq.++ ?x41376 ?x3523)))))))
 (let ((?x32975 (seq.unit (_ bv156 8))))
 (let ((?x52423 (seq.++ ?x32975 ?x12959)))
 (let ((?x14393 (seq.unit (_ bv2 8))))
 (let ((?x52291 (seq.unit (_ bv192 8))))
 (let ((?x38344 (seq.unit (_ bv1 8))))
 (let ((?x45058 (seq.++ ?x38344 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 (seq.++ ?x14393 ?x52423)))))))
 (let ((?x65684 (seq.unit (_ bv200 8))))
 (let ((?x52441 (seq.unit (_ bv182 8))))
 (let ((?x45051 (seq.++ ?x52441 (seq.++ ?x65684 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 ?x45058)))))))
 (let ((?x86241 (seq.unit (_ bv17 8))))
 (let ((?x45046 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x86241 ?x45051)))))))
 (let ((?x11149 (seq.unit (_ bv33 8))))
 (let ((?x3520 (seq.unit (_ bv69 8))))
 (let ((?x45041 (seq.++ ?x3520 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x11149 (seq.++ ?x43432 ?x45046)))))))
 (let (($x45040 (= v_3_L.packet ?x45041)))
 (let ((?x11111 (seq.++ ?x14393 (seq.++ ?x38344 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 ?x14393)))))))
 (let ((?x87908 (seq.++ ?x52291 (seq.++ ?x43432 ?x11111))))
 (let ((?x45081 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x86241 (seq.++ ?x52441 (seq.++ ?x65684 ?x87908)))))))
 (let ((?x45086 (seq.++ ?x43432 (seq.++ ?x11149 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x14353 ?x45081)))))))
 (let (($x45093 (= v_3_L.ip_wire (seq.++ ?x3520 (seq.++ ?x43432 ?x45086)))))
 (let ((?x32753 (seq.++ ?x43432 (seq.++ ?x14353 (seq.++ ?x86241 (seq.++ ?x43432 (seq.++ ?x43432 ?x87908)))))))
 (let ((?x32751 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x14353 ?x32753)))))
 (let (($x86590 (= v_3_L.ip_zero (seq.++ ?x3520 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x11149 ?x32751)))))))
 (let (($x8710 (= v_3_L.udp_wire ?x52423)))
 (let ((?x57661 (seq.++ ?x14393 (seq.++ ?x14393 (seq.++ ?x43432 (seq.++ ?x86241 (seq.++ ?x43432 ?x41376)))))))
 (let ((?x9897 (seq.++ ?x43432 (seq.++ ?x14393 (seq.++ ?x38344 (seq.++ ?x52291 (seq.++ ?x43432 ?x57661)))))))
 (let (($x41104 (= v_3_L.pseudoheader (seq.++ ?x52291 ?x9897))))
 (let ((?x36805 (seq.++ ?x30720 (seq.++ ?x43432 (seq.++ ?x41376 (seq.++ ?x43432 (seq.++ ?x43432 ?x76139)))))))
 (let (($x52410 (= v_3_L.udp_zero (seq.++ ?x32975 (seq.++ ?x14353 (seq.++ ?x56334 ?x36805))))))
 (let (($x9903 (= v_3_L.payload ?x76139)))
 (let (($x35629 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x35628 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x35627 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x35626 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x35625 (= 0 state_3)))
 (let (($x52506 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 11)))))
 (let (($x31886 (or (not active_2_T.user) (not (<= due_2_T.user 11)))))
 (let (($x52558 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 11)))))
 (let (($x10648 (or (not active_2_L.cache) (not (<= due_2_L.cache 11)))))
 (let (($x63774 (not active_2_L.query)))
 (let (($x32874 (or $x63774 (not (<= due_2_L.query 11)))))
 (let (($x3292 (= v_2_L.control "RESOLVED")))
 (let (($x6677 (= state_2 0)))
 (and $x6677 $x3292 $x32874 $x10648 $x52558 $x31886 $x52506 $x35625 $x35626 $x35627 $x35628 $x35629 $x9903 $x52410 $x41104 $x8710 $x86590 $x45093 $x45040 $x45038 $x45109 $x61336 $x61308 $x61307 $x35644 $x35645 $x35650 $x35651 $x35652 $x35653 $x35657 $x35658 $x35659 $x35660 $x35665 $x35666 $x35670 $x35671 $x35675 $x35676 $x35677 $x35678 $x35679 $x35680 $x35681 $x35685 $x35686 $x35687 $x35688 $x35689 $x35690 $x35691 $x35692 $x35693 $x35694 $x35695 $x35696 $x35697 $x35698 $x35699 $x35700 $x35701 $x35702 $x35703 $x35704 $x35705 $x35706 $x35707 $x35708 $x35709 $x35710 $x35711 $x35712 $x35713 $x35714 $x35715)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (= input_0_L.app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x52291 (seq.unit (_ bv192 8))))
 (let ((?x45156 (seq.++ ?x52291 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x38344 (seq.unit (_ bv1 8))))
 (let ((?x43432 (seq.unit (_ bv0 8))))
 (let ((?x68741 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x38344 ?x45156)))))))
 (let ((?x14393 (seq.unit (_ bv2 8))))
 (let ((?x67114 (seq.++ ?x52291 (seq.++ ?x43432 (seq.++ ?x14393 (seq.++ ?x14393 (seq.++ ?x14393 ?x68741)))))))
 (let ((?x84965 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x14393 ?x67114)))))))
 (let ((?x11172 (seq.unit (_ bv4 8))))
 (let ((?x11136 (seq.unit (_ bv6 8))))
 (let ((?x56913 (seq.++ ?x11136 (seq.++ ?x11172 (seq.++ ?x43432 (seq.++ ?x14393 (seq.++ ?x14393 ?x84965)))))))
 (let ((?x11135 (seq.unit (_ bv8 8))))
 (let ((?x79688 (seq.++ ?x11136 (seq.++ ?x43432 (seq.++ ?x38344 (seq.++ ?x11135 (seq.++ ?x43432 ?x56913)))))))
 (let ((?x77958 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x14393 (seq.++ ?x11135 ?x79688)))))))
 (let ((?x75298 (seq.++ ?x43432 (seq.++ ?x43432 (seq.++ ?x38344 (seq.++ ?x14393 (seq.++ ?x43432 ?x77958)))))))
 (let ((?x79177 (seq.++ ?x14393 (seq.++ ?x43432 (seq.++ ?x43432 ?x75298)))))
 (= input_1_L.net.frame_frame ?x79177))))))))))))))))))
(assert
 (= 22 choice_2))
(assert
 (= 11 now_3))
(assert
 (let ((?x66133 (seq.unit (_ bv128 8))))
(let ((?x13415 (seq.++ ?x66133 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x43432 (seq.unit (_ bv0 8))))
(let ((?x76139 (seq.++ ?x43432 ?x13415)))
(= input_2_L.app.send_data ?x76139))))))
(check-sat)

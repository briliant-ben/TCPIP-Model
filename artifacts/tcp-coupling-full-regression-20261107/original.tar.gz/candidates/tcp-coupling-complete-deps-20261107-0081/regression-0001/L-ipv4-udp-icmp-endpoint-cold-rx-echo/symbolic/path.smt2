; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x965 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x964 (= due_1_T.user due_0_T.user)))
 (let (($x963 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x962 (= due_1_L.cache due_0_L.cache)))
 (let (($x961 (= due_1_L.query due_0_L.query)))
 (let (($x960 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x959 (= active_1_T.user active_0_T.user)))
 (let (($x958 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x957 (= active_1_L.cache active_0_L.cache)))
 (let (($x956 (= active_1_L.query active_0_L.query)))
 (let (($x32375 (= v_1_T.control "CLOSED")))
 (let (($x33623 (= v_1_T.wire_flags 0)))
 (let (($x63446 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x63445 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x63444 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x63443 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x63442 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x63441 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x63440 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x33636 (= v_1_T.take 0)))
 (let (($x33637 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x33638 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x33639 (= v_1_T.snd_wnd 8)))
 (let (($x63439 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x63438 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x63437 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x218 (= v_1_T.local_window 16)))
 (let (($x33655 (= v_1_T.msl_ms 60000)))
 (let (($x33657 (= v_1_T.user_timeout_ms 30000)))
 (let (($x33920 (= v_1_T.retries 0)))
 (let (($x33922 (= v_1_T.rto_ms 1000)))
 (let (($x33924 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x33925 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x33926 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x33927 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x33928 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x33650 (= v_1_T.irs (_ bv0 32))))
 (let (($x33820 (= v_1_T.iss (_ bv1000 32))))
 (let (($x923 (= v_1_L.control "EMPTY")))
 (let (($x63436 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x63435 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63434 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63433 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x917 (= v_1_L.rxudp_disposition "deliver")))
 (let ((?x63096 (seq.unit (_ bv128 8))))
 (let ((?x2741 (seq.++ ?x63096 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x2742 (seq.++ ?x442 ?x2741)))
 (let (($x63432 (= v_1_L.rxudp_payload ?x2742)))
 (let (($x32020 (not v_1_L.rxudp_require_checksum)))
 (let (($x63425 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x2466 (= v_1_L.ip_checksum 0)))
 (let (($x2467 (= v_1_L.udp_checksum 0)))
 (let (($x2468 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2469 (= v_1_L.ip_length 0)))
 (let (($x2470 (= v_1_L.udp_length 0)))
 (let (($x63424 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x63423 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x63422 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x63421 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x63420 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x63419 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x63418 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x2492 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x2495 (= v_1_L.retry_count 0)))
 (let (($x63417 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x897 (= 0 state_1)))
 (let (($x407 (not active_0_T.time_wait)))
 (let (($x63416 (or $x407 (not (<= due_0_T.time_wait 0)))))
 (let (($x405 (not active_0_T.user)))
 (let (($x63413 (or $x405 (not (<= due_0_T.user 0)))))
 (let (($x403 (not active_0_T.rtx)))
 (let (($x63410 (or $x403 (not (<= due_0_T.rtx 0)))))
 (let (($x401 (not active_0_L.cache)))
 (let (($x63407 (or $x401 (not (<= due_0_L.cache 0)))))
 (let (($x399 (not active_0_L.query)))
 (let (($x63404 (or $x399 (not (<= due_0_L.query 0)))))
 (let (($x216 (= state_0 0)))
 (and $x216 (>= 0 now_0) $x63404 $x63407 $x63410 $x63413 $x63416 $x897 $x63417 $x2495 $x2492 v_1_L.checksums_enabled $x63418 $x63419 $x63420 $x63421 $x63422 $x63423 $x63424 $x2470 $x2469 $x2468 $x2467 $x2466 $x63425 $x32020 $x63432 $x917 $x63433 $x63434 $x63435 $x63436 (= v_1_L.echo_disposition "none") $x923 $x33820 $x33650 $x33928 $x33927 $x33926 $x33925 $x33924 (= v_1_T.tx_flags "S") $x33922 $x33920 v_1_T.active_open $x33657 $x33655 $x218 $x63437 $x63438 $x63439 $x33639 $x33638 $x33637 $x33636 $x63440 $x63441 $x63442 $x63443 $x63444 $x63445 $x63446 $x33623 (= v_1_T.wire_disposition "none") $x32375 (= v_1_ip_pending_owner "none") $x956 $x957 $x958 $x959 $x960 $x961 $x962 $x963 $x964 $x965))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x32341 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x32340 (= due_2_T.user due_1_T.user)))
 (let (($x32339 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x32338 (= due_2_L.cache due_1_L.cache)))
 (let (($x32337 (= due_2_L.query due_1_L.query)))
 (let (($x32336 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x32335 (= active_2_T.user active_1_T.user)))
 (let (($x32334 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x32333 (= active_2_L.cache active_1_L.cache)))
 (let (($x32332 (= active_2_L.query active_1_L.query)))
 (let (($x32331 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x32330 (= v_2_T.control v_1_T.control)))
 (let (($x32329 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x32328 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x32327 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x32326 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x32325 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x32324 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x32323 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x32322 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x32321 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x32320 (= v_2_T.take v_1_T.take)))
 (let (($x32319 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x32318 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x32317 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x32316 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x32315 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x32314 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x32313 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x32312 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x32311 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x32310 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x32309 (= v_2_T.retries v_1_T.retries)))
 (let (($x32308 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x32307 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x32306 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32305 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32304 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32303 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x32302 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x32301 (= v_2_T.irs v_1_T.irs)))
 (let (($x32300 (= v_2_T.iss v_1_T.iss)))
 (let (($x32299 (= v_2_L.control "EMPTY")))
 (let (($x32298 (= v_2_L.echo_disposition "reply")))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x447 (seq.++ ?x440 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x32188 (seq.++ ?x442 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x514 ?x447)))))))
 (let ((?x732 (seq.unit (_ bv64 8))))
 (let ((?x32193 (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x514 (seq.++ ?x442 ?x32188)))))))
 (let ((?x32195 (seq.++ ?x442 (seq.++ ?x442 ?x32193))))
 (let ((?x63084 (seq.unit (_ bv33 8))))
 (let ((?x726 (seq.unit (_ bv69 8))))
 (let (($x63669 (= v_2_L.echo_ip_zero (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x63084 ?x32195)))))))
 (let ((?x63096 (seq.unit (_ bv128 8))))
 (let ((?x2742 (seq.++ ?x442 (seq.++ ?x63096 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x442))))))
 (let ((?x63162 (seq.unit (_ bv205 8))))
 (let ((?x63160 (seq.unit (_ bv171 8))))
 (let ((?x63158 (seq.unit (_ bv52 8))))
 (let ((?x63156 (seq.unit (_ bv18 8))))
 (let ((?x2514 (seq.++ ?x63156 (seq.++ ?x63158 (seq.++ ?x63160 (seq.++ ?x63162 ?x2742))))))
 (let ((?x63154 (seq.unit (_ bv118 8))))
 (let ((?x63609 (seq.++ ?x442 (seq.++ ?x442 (seq.++ (seq.unit (_ bv66 8)) (seq.++ ?x63154 ?x2514))))))
 (let (($x63668 (= v_2_L.echo_icmp_wire ?x63609)))
 (let (($x63667 (= v_2_L.echo_icmp_zero (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x2514)))))))
 (let ((?x63650 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x63609)))))))
 (let ((?x63150 (seq.unit (_ bv216 8))))
 (let ((?x63655 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x63150 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63650)))))))
 (let ((?x63660 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x514 ?x63655)))))))
 (let ((?x63665 (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x63084 (seq.++ ?x442 ?x63660)))))))
 (let (($x63666 (= v_2_L.echo_reply ?x63665)))
 (let (($x32293 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32292 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32291 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x32290 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x32289 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x32288 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x32287 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x32286 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x32285 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x32284 (= v_2_L.packet v_1_L.packet)))
 (let (($x32283 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x32282 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x32281 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x32280 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32279 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x32278 (= v_2_L.payload v_1_L.payload)))
 (let (($x32277 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x32276 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x32275 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x32274 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x32273 (= 0 state_2)))
 (let (($x33701 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x2640 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x33950 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x33690 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x2526 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x923 (= v_1_L.control "EMPTY")))
 (let (($x2746 (= state_1 0)))
 (and $x2746 $x923 $x2526 $x33690 $x33950 $x2640 $x33701 $x32273 $x32274 $x32275 $x32276 $x32277 $x32278 $x32279 $x32280 $x32281 $x32282 $x32283 $x32284 $x32285 $x32286 $x32287 $x32288 $x32289 $x32290 $x32291 $x32292 $x32293 $x63666 $x63667 $x63668 $x63669 $x32298 $x32299 $x32300 $x32301 $x32302 $x32303 $x32304 $x32305 $x32306 $x32307 $x32308 $x32309 $x32310 $x32311 $x32312 $x32313 $x32314 $x32315 $x32316 $x32317 $x32318 $x32319 $x32320 $x32321 $x32322 $x32323 $x32324 $x32325 $x32326 $x32327 $x32328 $x32329 $x32330 $x32331 $x32332 $x32333 $x32334 $x32335 $x32336 $x32337 $x32338 $x32339 $x32340 $x32341)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 35 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x32159 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x442)))))
 (let ((?x32227 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32159)))))))
 (let ((?x32232 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32227)))))))
 (let ((?x63098 (seq.unit (_ bv7 8))))
 (let ((?x522 (seq.unit (_ bv255 8))))
 (let ((?x63096 (seq.unit (_ bv128 8))))
 (let ((?x63102 (seq.++ ?x442 (seq.++ ?x63096 (seq.++ ?x522 (seq.++ ?x63098 ?x32232))))))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x63106 (seq.++ ?x442 (seq.++ (seq.unit (_ bv13 8)) (seq.++ ?x440 (seq.++ (seq.unit (_ bv119 8)) ?x63102))))))
 (let ((?x732 (seq.unit (_ bv64 8))))
 (let ((?x746 (seq.unit (_ bv156 8))))
 (let ((?x744 (seq.unit (_ bv144 8))))
 (let ((?x742 (seq.unit (_ bv31 8))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x63111 (seq.++ ?x514 (seq.++ ?x742 (seq.++ ?x744 (seq.++ ?x746 (seq.++ ?x732 ?x63106)))))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x63116 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63111)))))))
 (let ((?x63120 (seq.++ (seq.unit (_ bv177 8)) (seq.++ (seq.unit (_ bv246 8)) (seq.++ ?x440 (seq.++ ?x442 ?x63116))))))
 (let ((?x734 (seq.unit (_ bv17 8))))
 (let ((?x63125 (seq.++ (seq.unit (_ bv210 8)) (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x734 ?x63120)))))))
 (let ((?x542 (seq.unit (_ bv4 8))))
 (let ((?x63084 (seq.unit (_ bv33 8))))
 (let ((?x726 (seq.unit (_ bv69 8))))
 (let ((?x63130 (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x63084 (seq.++ ?x542 ?x63125)))))))
 (let ((?x538 (seq.unit (_ bv8 8))))
 (let ((?x63135 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x538 (seq.++ ?x442 ?x63130)))))))
 (let ((?x63140 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x442 ?x63135)))))))
 (let ((?x63144 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x63140))))))
 (= input_0_L.net.frame_frame ?x63144)))))))))))))))))))))))))))))))
(assert
 (= 54 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x442 (seq.unit (_ bv0 8))))
(let ((?x32159 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x442)))))
(let ((?x32227 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32159)))))))
(let ((?x32232 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x32227)))))))
(let ((?x63098 (seq.unit (_ bv7 8))))
(let ((?x522 (seq.unit (_ bv255 8))))
(let ((?x63096 (seq.unit (_ bv128 8))))
(let ((?x63102 (seq.++ ?x442 (seq.++ ?x63096 (seq.++ ?x522 (seq.++ ?x63098 ?x32232))))))
(let ((?x63162 (seq.unit (_ bv205 8))))
(let ((?x63160 (seq.unit (_ bv171 8))))
(let ((?x63158 (seq.unit (_ bv52 8))))
(let ((?x63156 (seq.unit (_ bv18 8))))
(let ((?x63154 (seq.unit (_ bv118 8))))
(let ((?x63167 (seq.++ ?x63154 (seq.++ ?x63156 (seq.++ ?x63158 (seq.++ ?x63160 (seq.++ ?x63162 ?x63102)))))))
(let ((?x63152 (seq.unit (_ bv58 8))))
(let ((?x538 (seq.unit (_ bv8 8))))
(let ((?x514 (seq.unit (_ bv1 8))))
(let ((?x444 (seq.unit (_ bv2 8))))
(let ((?x63172 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x538 (seq.++ ?x442 (seq.++ ?x63152 ?x63167)))))))
(let ((?x440 (seq.unit (_ bv192 8))))
(let ((?x63177 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x440 (seq.++ ?x442 ?x63172)))))))
(let ((?x63150 (seq.unit (_ bv216 8))))
(let ((?x63148 (seq.unit (_ bv245 8))))
(let ((?x63182 (seq.++ ?x514 (seq.++ ?x514 (seq.++ ?x63148 (seq.++ ?x63150 (seq.++ ?x440 ?x63177)))))))
(let ((?x732 (seq.unit (_ bv64 8))))
(let ((?x63084 (seq.unit (_ bv33 8))))
(let ((?x63187 (seq.++ ?x63084 (seq.++ ?x522 (seq.++ ?x522 (seq.++ ?x732 (seq.++ ?x442 ?x63182)))))))
(let ((?x726 (seq.unit (_ bv69 8))))
(let ((?x63192 (seq.++ ?x538 (seq.++ ?x442 (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 ?x63187)))))))
(let ((?x63197 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 ?x63192)))))))
(let ((?x63202 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x444 ?x63197)))))))
(let ((?x63204 (seq.++ ?x444 (seq.++ ?x442 ?x63202))))
(= input_1_L.net.frame_frame ?x63204))))))))))))))))))))))))))))))))))
(check-sat)

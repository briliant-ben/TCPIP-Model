; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x35713 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x7980 (= due_1_T.user due_0_T.user)))
 (let (($x102788 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x51557 (= due_1_L.cache due_0_L.cache)))
 (let (($x98090 (= due_1_L.query 1000)))
 (let (($x57456 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x57459 (= active_1_T.user active_0_T.user)))
 (let (($x58010 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x58005 (= active_1_L.cache active_0_L.cache)))
 (let (($x57996 (= v_1_ip_pending_owner "UDP")))
 (let (($x46318 (= v_1_T.control "CLOSED")))
 (let (($x23288 (= v_1_T.wire_flags 0)))
 (let (($x98062 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x98061 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x3367 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x5508 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x1451 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52586 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x41176 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x104103 (= v_1_T.take 0)))
 (let (($x91433 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x103886 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x30286 (= v_1_T.snd_wnd 8)))
 (let (($x1356 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x96552 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x53123 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x515 (= v_1_T.local_window 16)))
 (let (($x5740 (= v_1_T.msl_ms 60000)))
 (let (($x104155 (= v_1_T.user_timeout_ms 30000)))
 (let (($x1705 (= v_1_T.retries 0)))
 (let (($x5741 (= v_1_T.rto_ms 1000)))
 (let (($x34900 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x5751 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x32977 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x24839 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x10396 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x89269 (= v_1_T.irs (_ bv0 32))))
 (let (($x3866 (= v_1_T.iss (_ bv1000 32))))
 (let (($x58249 (= v_1_L.control "PENDING")))
 (let (($x41146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x3364 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x52317 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x6499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x45048 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x46148 (not v_1_L.rxudp_require_checksum)))
 (let ((?x57321 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x10611 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x57321)))))
 (let ((?x24907 (seq.unit (_ bv8 8))))
 (let ((?x57869 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x24907 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x10611))))))
 (let ((?x1287 (seq.unit (_ bv6 8))))
 (let ((?x23632 (seq.unit (_ bv4 8))))
 (let ((?x94337 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x23632 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x1287 ?x57869))))))
 (let ((?x57940 (seq.unit (_ bv2 8))))
 (let ((?x24899 (seq.unit (_ bv1 8))))
 (let ((?x57942 (seq.unit (_ bv0 8))))
 (let ((?x53029 (seq.++ ?x57942 (seq.++ ?x24899 (seq.++ ?x57940 ?x94337)))))
 (let ((?x103009 (seq.unit (_ bv26 8))))
 (let ((?x52807 (seq.++ ?x57942 (seq.++ ?x103009 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv148 8)) ?x53029))))))
 (let ((?x1563 (seq.unit (_ bv144 8))))
 (let ((?x1560 (seq.unit (_ bv31 8))))
 (let ((?x98135 (seq.unit (_ bv64 8))))
 (let ((?x1565 (seq.unit (_ bv156 8))))
 (let ((?x97932 (seq.++ ?x1565 (seq.++ ?x98135 (seq.++ ?x1560 (seq.++ ?x1563 ?x52807))))))
 (let ((?x24940 (seq.unit (_ bv192 8))))
 (let ((?x1462 (seq.++ ?x24899 (seq.++ ?x24940 (seq.++ ?x57942 (seq.++ ?x57940 (seq.++ ?x57940 ?x97932)))))))
 (let ((?x57752 (seq.unit (_ bv187 8))))
 (let ((?x13110 (seq.unit (_ bv182 8))))
 (let ((?x57506 (seq.++ ?x13110 (seq.++ ?x57752 (seq.++ ?x24940 (seq.++ ?x57942 (seq.++ ?x57940 ?x1462)))))))
 (let ((?x13326 (seq.unit (_ bv17 8))))
 (let ((?x57408 (seq.++ ?x57942 (seq.++ ?x98135 (seq.++ ?x57942 (seq.++ ?x98135 (seq.++ ?x13326 ?x57506)))))))
 (let ((?x103929 (seq.unit (_ bv46 8))))
 (let ((?x24872 (seq.unit (_ bv69 8))))
 (let ((?x98082 (seq.++ ?x24872 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x103929 (seq.++ ?x57942 ?x57408)))))))
 (let (($x57478 (= v_1_L.pending_packet ?x98082)))
 (let (($x57477 (= v_1_L.ip_checksum 46779)))
 (let (($x57929 (= v_1_L.udp_checksum 30612)))
 (let (($x57560 (= v_1_L.udp_raw_checksum 30612)))
 (let (($x11582 (= v_1_L.ip_length 46)))
 (let (($x90186 (= v_1_L.udp_length 26)))
 (let (($x98083 (= v_1_L.packet ?x98082)))
 (let ((?x1474 (seq.++ ?x57940 (seq.++ ?x24899 (seq.++ ?x24940 (seq.++ ?x57942 (seq.++ ?x57940 ?x57940)))))))
 (let ((?x1472 (seq.++ ?x24940 (seq.++ ?x57942 ?x1474))))
 (let ((?x97898 (seq.++ ?x57942 (seq.++ ?x98135 (seq.++ ?x13326 (seq.++ ?x13110 (seq.++ ?x57752 ?x1472)))))))
 (let ((?x57332 (seq.++ ?x57942 (seq.++ ?x103929 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x98135 ?x97898)))))))
 (let (($x57867 (= v_1_L.ip_wire (seq.++ ?x24872 (seq.++ ?x57942 ?x57332)))))
 (let ((?x97996 (seq.++ ?x57942 (seq.++ ?x98135 (seq.++ ?x13326 (seq.++ ?x57942 (seq.++ ?x57942 ?x1472)))))))
 (let ((?x57516 (seq.++ ?x57942 (seq.++ ?x103929 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x98135 ?x97996)))))))
 (let (($x57519 (= v_1_L.ip_zero (seq.++ ?x24872 (seq.++ ?x57942 ?x57516)))))
 (let (($x57483 (= v_1_L.udp_wire ?x97932)))
 (let ((?x46826 (seq.++ ?x57940 (seq.++ ?x57940 (seq.++ ?x57942 (seq.++ ?x13326 (seq.++ ?x57942 ?x103009)))))))
 (let ((?x9486 (seq.++ ?x57942 (seq.++ ?x57940 (seq.++ ?x24899 (seq.++ ?x24940 (seq.++ ?x57942 ?x46826)))))))
 (let (($x103978 (= v_1_L.pseudoheader (seq.++ ?x24940 ?x9486))))
 (let ((?x1485 (seq.++ ?x1563 (seq.++ ?x57942 (seq.++ ?x103009 (seq.++ ?x57942 (seq.++ ?x57942 ?x53029)))))))
 (let (($x1480 (= v_1_L.udp_zero (seq.++ ?x1565 (seq.++ ?x98135 (seq.++ ?x1560 ?x1485))))))
 (let (($x23741 (= v_1_L.payload ?x53029)))
 (let (($x52852 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x52596 (= 0 v_1_L.retry_count)))
 (let (($x23578 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x57381 (= 0 state_1)))
 (let (($x1352 (not active_0_T.time_wait)))
 (let (($x23577 (or $x1352 (not (<= due_0_T.time_wait 0)))))
 (let (($x1353 (not active_0_T.user)))
 (let (($x23572 (or $x1353 (not (<= due_0_T.user 0)))))
 (let (($x1355 (not active_0_T.rtx)))
 (let (($x104039 (or $x1355 (not (<= due_0_T.rtx 0)))))
 (let (($x1357 (not active_0_L.cache)))
 (let (($x91323 (or $x1357 (not (<= due_0_L.cache 0)))))
 (let (($x1359 (not active_0_L.query)))
 (let (($x91327 (or $x1359 (not (<= due_0_L.query 0)))))
 (let (($x92449 (= state_0 0)))
 (and $x92449 (>= 0 now_0) $x91327 $x91323 $x104039 $x23572 $x23577 $x57381 $x23578 $x52596 $x52852 v_1_L.checksums_enabled $x23741 $x1480 $x103978 $x57483 $x57519 $x57867 $x98083 $x90186 $x11582 $x57560 $x57929 $x57477 $x57478 $x46148 $x45048 (= v_1_L.rxudp_disposition "none") $x6499 $x52317 $x3364 $x41146 (= v_1_L.echo_disposition "none") $x58249 $x3866 $x89269 $x10396 $x24839 $x32977 $x5751 $x34900 (= v_1_T.tx_flags "S") $x5741 $x1705 v_1_T.active_open $x104155 $x5740 $x515 $x53123 $x96552 $x1356 $x30286 $x103886 $x91433 $x104103 $x41176 $x52586 $x1451 $x5508 $x3367 $x98061 $x98062 $x23288 (= v_1_T.wire_disposition "none") $x46318 $x57996 active_1_L.query $x58005 $x58010 $x57459 $x57456 $x98090 $x51557 $x102788 $x7980 $x35713))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x46014 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x46013 (= due_2_T.user due_1_T.user)))
 (let (($x46012 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x46010 (= due_2_L.query due_1_L.query)))
 (let (($x46009 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x46008 (= active_2_T.user active_1_T.user)))
 (let (($x46007 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x56599 (not active_2_L.query)))
 (let (($x46004 (= v_2_ip_pending_owner "none")))
 (let (($x46003 (= v_2_T.control v_1_T.control)))
 (let (($x46002 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x46001 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x46000 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x45999 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x45998 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x45997 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x45996 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x45995 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x45994 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x45993 (= v_2_T.take v_1_T.take)))
 (let (($x45992 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x45991 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x45990 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x45989 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x45988 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x45987 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x45986 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x45985 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x45984 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x45983 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x45982 (= v_2_T.retries v_1_T.retries)))
 (let (($x45981 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x45980 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x45979 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x45978 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x45977 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x45976 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x45975 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x45974 (= v_2_T.irs v_1_T.irs)))
 (let (($x45973 (= v_2_T.iss v_1_T.iss)))
 (let (($x45972 (= v_2_L.control "RESOLVED")))
 (let (($x45971 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x45970 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x45969 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x45968 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x45967 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x45966 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x45965 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x45964 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x56358 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x45962 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x45961 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x45960 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x45959 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x45958 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x45957 (= v_2_L.packet v_1_L.packet)))
 (let (($x45956 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x45955 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x45954 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x45953 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x45952 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x45951 (= v_2_L.payload v_1_L.payload)))
 (let (($x45950 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x45949 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x45948 (= 0 v_2_L.retry_count)))
 (let ((?x57942 (seq.unit (_ bv0 8))))
 (let ((?x61478 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.unit (_ bv2 8))))))))
 (let ((?x57940 (seq.unit (_ bv2 8))))
 (let ((?x61479 (seq.++ ?x57940 ?x61478)))
 (let (($x89381 (= v_2_L.peer_mac ?x61479)))
 (let (($x45946 (= 0 state_2)))
 (let (($x32900 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x58064 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x58059 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x57758 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x98045 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x45903 (seq.len v_1_L.pending_packet)))
 (let (($x45904 (<= 28 ?x45903)))
 (let (($x58249 (= v_1_L.control "PENDING")))
 (let (($x91322 (= state_1 0)))
 (and $x91322 $x58249 $x45904 $x98045 $x57758 $x58059 $x58064 $x32900 $x45946 $x89381 $x45948 $x45949 $x45950 $x45951 $x45952 $x45953 $x45954 $x45955 $x45956 $x45957 $x45958 $x45959 $x45960 $x45961 $x45962 $x56358 $x45964 $x45965 $x45966 $x45967 $x45968 $x45969 $x45970 $x45971 $x45972 $x45973 $x45974 $x45975 $x45976 $x45977 $x45978 $x45979 $x45980 $x45981 $x45982 $x45983 $x45984 $x45985 $x45986 $x45987 $x45988 $x45989 $x45990 $x45991 $x45992 $x45993 $x45994 $x45995 $x45996 $x45997 $x45998 $x45999 $x46000 $x46001 $x46002 $x46003 $x46004 $x56599 active_2_L.cache $x46007 $x46008 $x46009 $x46010 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x46012 $x46013 $x46014))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x57321 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x10611 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x57321)))))
 (let ((?x24907 (seq.unit (_ bv8 8))))
 (let ((?x57869 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x24907 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x10611))))))
 (let ((?x1287 (seq.unit (_ bv6 8))))
 (let ((?x23632 (seq.unit (_ bv4 8))))
 (let ((?x94337 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x23632 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x1287 ?x57869))))))
 (let ((?x57940 (seq.unit (_ bv2 8))))
 (let ((?x24899 (seq.unit (_ bv1 8))))
 (let ((?x57942 (seq.unit (_ bv0 8))))
 (let ((?x53029 (seq.++ ?x57942 (seq.++ ?x24899 (seq.++ ?x57940 ?x94337)))))
 (= input_0_L.app.send_data ?x53029)))))))))))))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x24940 (seq.unit (_ bv192 8))))
(let ((?x24925 (seq.++ ?x24940 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x24899 (seq.unit (_ bv1 8))))
(let ((?x57942 (seq.unit (_ bv0 8))))
(let ((?x57971 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x24899 ?x24925)))))))
(let ((?x57940 (seq.unit (_ bv2 8))))
(let ((?x57875 (seq.++ ?x24940 (seq.++ ?x57942 (seq.++ ?x57940 (seq.++ ?x57940 (seq.++ ?x57940 ?x57971)))))))
(let ((?x57511 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57940 ?x57875)))))))
(let ((?x23632 (seq.unit (_ bv4 8))))
(let ((?x1287 (seq.unit (_ bv6 8))))
(let ((?x57931 (seq.++ ?x1287 (seq.++ ?x23632 (seq.++ ?x57942 (seq.++ ?x57940 (seq.++ ?x57940 ?x57511)))))))
(let ((?x24907 (seq.unit (_ bv8 8))))
(let ((?x28717 (seq.++ ?x1287 (seq.++ ?x57942 (seq.++ ?x24899 (seq.++ ?x24907 (seq.++ ?x57942 ?x57931)))))))
(let ((?x57491 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x57940 (seq.++ ?x24907 ?x28717)))))))
(let ((?x57496 (seq.++ ?x57942 (seq.++ ?x57942 (seq.++ ?x24899 (seq.++ ?x57940 (seq.++ ?x57942 ?x57491)))))))
(let ((?x57499 (seq.++ ?x57940 (seq.++ ?x57942 (seq.++ ?x57942 ?x57496)))))
(= input_1_L.net.frame_frame ?x57499))))))))))))))))))
(check-sat)

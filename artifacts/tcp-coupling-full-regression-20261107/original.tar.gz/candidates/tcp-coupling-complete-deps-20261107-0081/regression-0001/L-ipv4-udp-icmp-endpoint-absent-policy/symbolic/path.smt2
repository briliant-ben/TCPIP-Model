; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.require_checksum_required () Bool)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x59353 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x19832 (= due_1_T.user due_0_T.user)))
 (let (($x19831 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x19830 (= due_1_L.cache due_0_L.cache)))
 (let (($x19829 (= due_1_L.query due_0_L.query)))
 (let (($x19828 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x19827 (= active_1_T.user active_0_T.user)))
 (let (($x19826 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x19825 (= active_1_L.cache active_0_L.cache)))
 (let (($x19824 (= active_1_L.query active_0_L.query)))
 (let (($x14582 (= v_1_T.control "CLOSED")))
 (let (($x55363 (= v_1_T.wire_flags 0)))
 (let (($x91522 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x91521 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x91520 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x91519 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x91518 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x91517 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x91516 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x55376 (= v_1_T.take 0)))
 (let (($x55377 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x55378 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x55379 (= v_1_T.snd_wnd 8)))
 (let (($x91515 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x91514 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x91513 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x84 (= v_1_T.local_window 16)))
 (let (($x65082 (= v_1_T.msl_ms 60000)))
 (let (($x65076 (= v_1_T.user_timeout_ms 30000)))
 (let (($x65079 (= v_1_T.retries 0)))
 (let (($x2373 (= v_1_T.rto_ms 1000)))
 (let (($x31746 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x96382 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x65366 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x65367 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x65100 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x65098 (= v_1_T.irs (_ bv0 32))))
 (let (($x65095 (= v_1_T.iss (_ bv1000 32))))
 (let (($x62479 (= v_1_L.control "EMPTY")))
 (let (($x91512 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x91511 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x91510 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x91509 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x62680 (= v_1_L.rxudp_disposition "deliver")))
 (let ((?x90985 (seq.unit (_ bv128 8))))
 (let ((?x34907 (seq.++ ?x90985 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x92957 (seq.unit (_ bv0 8))))
 (let (($x91508 (= v_1_L.rxudp_payload (seq.++ ?x92957 ?x34907))))
 (let (($x14342 (not v_1_L.rxudp_require_checksum)))
 (let (($x91501 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x65453 (= v_1_L.ip_checksum 0)))
 (let (($x65382 (= v_1_L.udp_checksum 0)))
 (let (($x31920 (= v_1_L.udp_raw_checksum 0)))
 (let (($x65393 (= v_1_L.ip_length 0)))
 (let (($x34697 (= v_1_L.udp_length 0)))
 (let (($x91500 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x91499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x91498 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x91497 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x91496 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x91495 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x91494 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x31783 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x65565 (= v_1_L.retry_count 0)))
 (let (($x91493 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x1672 (= 0 state_1)))
 (let (($x59242 (not active_0_T.time_wait)))
 (let (($x91492 (or $x59242 (not (<= due_0_T.time_wait 0)))))
 (let (($x59107 (not active_0_T.user)))
 (let (($x91489 (or $x59107 (not (<= due_0_T.user 0)))))
 (let (($x59208 (not active_0_T.rtx)))
 (let (($x91486 (or $x59208 (not (<= due_0_T.rtx 0)))))
 (let (($x59251 (not active_0_L.cache)))
 (let (($x91483 (or $x59251 (not (<= due_0_L.cache 0)))))
 (let (($x59104 (not active_0_L.query)))
 (let (($x91480 (or $x59104 (not (<= due_0_L.query 0)))))
 (let (($x62673 (= state_0 0)))
 (and $x62673 (>= 0 now_0) $x91480 $x91483 $x91486 $x91489 $x91492 $x1672 $x91493 $x65565 $x31783 v_1_L.checksums_enabled $x91494 $x91495 $x91496 $x91497 $x91498 $x91499 $x91500 $x34697 $x65393 $x31920 $x65382 $x65453 $x91501 $x14342 $x91508 $x62680 $x91509 $x91510 $x91511 $x91512 (= v_1_L.echo_disposition "none") $x62479 $x65095 $x65098 $x65100 $x65367 $x65366 $x96382 $x31746 (= v_1_T.tx_flags "S") $x2373 $x65079 v_1_T.active_open $x65076 $x65082 $x84 $x91513 $x91514 $x91515 $x55379 $x55378 $x55377 $x55376 $x91516 $x91517 $x91518 $x91519 $x91520 $x91521 $x91522 $x55363 (= v_1_T.wire_disposition "none") $x14582 (= v_1_ip_pending_owner "none") $x19824 $x19825 $x19826 $x19827 $x19828 $x19829 $x19830 $x19831 $x19832 $x59353)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x14418 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x14417 (= due_2_T.user due_1_T.user)))
 (let (($x14416 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x14415 (= due_2_L.cache due_1_L.cache)))
 (let (($x14414 (= due_2_L.query due_1_L.query)))
 (let (($x14413 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x14412 (= active_2_T.user active_1_T.user)))
 (let (($x14411 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x14410 (= active_2_L.cache active_1_L.cache)))
 (let (($x14409 (= active_2_L.query active_1_L.query)))
 (let (($x14408 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x14407 (= v_2_T.control v_1_T.control)))
 (let (($x14406 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x14405 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x14404 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x14403 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x14402 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x14401 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x14400 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x14399 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x14398 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x14397 (= v_2_T.take v_1_T.take)))
 (let (($x14396 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x14395 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x14394 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x14393 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x14392 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x14391 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x14390 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x14389 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x14388 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x14387 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x14386 (= v_2_T.retries v_1_T.retries)))
 (let (($x14385 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x14384 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x14383 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x14382 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x14381 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x14380 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x14379 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x14378 (= v_2_T.irs v_1_T.irs)))
 (let (($x14377 (= v_2_T.iss v_1_T.iss)))
 (let (($x14376 (= v_2_L.control "EMPTY")))
 (let (($x14375 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x14374 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x14373 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x14372 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x14371 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x14370 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x14369 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x14367 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x14366 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x14365 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x14364 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x14363 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x14362 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x14361 (= v_2_L.packet v_1_L.packet)))
 (let (($x14360 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x14359 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x14358 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x14357 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x14356 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x14355 (= v_2_L.payload v_1_L.payload)))
 (let (($x14354 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x14353 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x14352 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x14351 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x14350 (= 0 state_2)))
 (let (($x519 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x34817 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x65153 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x65146 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x65447 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x62479 (= v_1_L.control "EMPTY")))
 (let (($x63403 (= state_1 0)))
 (and $x63403 $x62479 $x65447 $x65146 $x65153 $x34817 $x519 $x14350 $x14351 $x14352 $x14353 $x14354 $x14355 $x14356 $x14357 $x14358 $x14359 $x14360 $x14361 $x14362 $x14363 $x14364 $x14365 $x14366 $x14367 v_2_L.rxudp_require_checksum $x14369 $x14370 $x14371 $x14372 $x14373 $x14374 $x14375 $x14376 $x14377 $x14378 $x14379 $x14380 $x14381 $x14382 $x14383 $x14384 $x14385 $x14386 $x14387 $x14388 $x14389 $x14390 $x14391 $x14392 $x14393 $x14394 $x14395 $x14396 $x14397 $x14398 $x14399 $x14400 $x14401 $x14402 $x14403 $x14404 $x14405 $x14406 $x14407 $x14408 $x14409 $x14410 $x14411 $x14412 $x14413 $x14414 $x14415 $x14416 $x14417 $x14418)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x53949 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x53948 (= due_3_T.user due_2_T.user)))
 (let (($x53947 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x53946 (= due_3_L.cache due_2_L.cache)))
 (let (($x53945 (= due_3_L.query due_2_L.query)))
 (let (($x53944 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x53943 (= active_3_T.user active_2_T.user)))
 (let (($x53942 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x53941 (= active_3_L.cache active_2_L.cache)))
 (let (($x53940 (= active_3_L.query active_2_L.query)))
 (let (($x53939 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x53938 (= v_3_T.control v_2_T.control)))
 (let (($x53937 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x53936 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x53935 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x53934 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x53933 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x53932 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x53931 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x53930 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x53929 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x53928 (= v_3_T.take v_2_T.take)))
 (let (($x53927 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x53926 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x53925 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x53924 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x53923 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x53922 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x53921 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x53920 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x53919 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x53918 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x53917 (= v_3_T.retries v_2_T.retries)))
 (let (($x53916 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x53915 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x53914 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x53913 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x53912 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x53911 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x53910 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x53909 (= v_3_T.irs v_2_T.irs)))
 (let (($x53908 (= v_3_T.iss v_2_T.iss)))
 (let (($x53907 (= v_3_L.control "EMPTY")))
 (let (($x53906 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x53905 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x53904 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x53903 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x53902 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x53901 (= v_3_L.rxudp_disposition "drop_absent")))
 (let (($x55393 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.rxudp_payload)))
 (let (($x53899 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x53898 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x53897 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x53896 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x53895 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x53894 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x53893 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x53892 (= v_3_L.packet v_2_L.packet)))
 (let (($x53891 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x53890 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x53889 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x53888 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x53887 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x53886 (= v_3_L.payload v_2_L.payload)))
 (let (($x53885 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x53884 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x53883 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x53882 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x53881 (= 0 state_3)))
 (let (($x55394 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x55486 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x55514 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x91113 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x55421 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let (($x14376 (= v_2_L.control "EMPTY")))
 (let (($x15857 (= state_2 0)))
 (and $x15857 $x14376 v_2_L.rxudp_require_checksum $x55421 $x91113 $x55514 $x55486 $x55394 $x53881 $x53882 $x53883 $x53884 $x53885 $x53886 $x53887 $x53888 $x53889 $x53890 $x53891 $x53892 $x53893 $x53894 $x53895 $x53896 $x53897 $x53898 $x53899 $x55393 $x53901 $x53902 $x53903 $x53904 $x53905 $x53906 $x53907 $x53908 $x53909 $x53910 $x53911 $x53912 $x53913 $x53914 $x53915 $x53916 $x53917 $x53918 $x53919 $x53920 $x53921 $x53922 $x53923 $x53924 $x53925 $x53926 $x53927 $x53928 $x53929 $x53930 $x53931 $x53932 $x53933 $x53934 $x53935 $x53936 $x53937 $x53938 $x53939 $x53940 $x53941 $x53942 $x53943 $x53944 $x53945 $x53946 $x53947 $x53948 $x53949))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 35 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x92957 (seq.unit (_ bv0 8))))
 (let ((?x90991 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x92957)))))))
 (let ((?x90996 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x90991)))))))
 (let ((?x90987 (seq.unit (_ bv7 8))))
 (let ((?x96362 (seq.unit (_ bv255 8))))
 (let ((?x91001 (seq.++ ?x96362 (seq.++ ?x90987 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x90996)))))))
 (let ((?x90985 (seq.unit (_ bv128 8))))
 (let ((?x90983 (seq.unit (_ bv13 8))))
 (let ((?x91006 (seq.++ ?x90983 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x90985 ?x91001)))))))
 (let ((?x57714 (seq.unit (_ bv64 8))))
 (let ((?x57721 (seq.unit (_ bv156 8))))
 (let ((?x57720 (seq.unit (_ bv144 8))))
 (let ((?x57719 (seq.unit (_ bv31 8))))
 (let ((?x91011 (seq.++ ?x57719 (seq.++ ?x57720 (seq.++ ?x57721 (seq.++ ?x57714 (seq.++ ?x92957 ?x91006)))))))
 (let ((?x31952 (seq.unit (_ bv1 8))))
 (let ((?x62332 (seq.unit (_ bv2 8))))
 (let ((?x97271 (seq.unit (_ bv192 8))))
 (let ((?x91016 (seq.++ ?x62332 (seq.++ ?x97271 (seq.++ ?x92957 (seq.++ ?x62332 (seq.++ ?x31952 ?x91011)))))))
 (let ((?x90981 (seq.unit (_ bv200 8))))
 (let ((?x90979 (seq.unit (_ bv182 8))))
 (let ((?x91021 (seq.++ ?x90979 (seq.++ ?x90981 (seq.++ ?x97271 (seq.++ ?x92957 (seq.++ ?x62332 ?x91016)))))))
 (let ((?x57715 (seq.unit (_ bv17 8))))
 (let ((?x91026 (seq.++ ?x92957 (seq.++ ?x57714 (seq.++ ?x92957 (seq.++ ?x57714 (seq.++ ?x57715 ?x91021)))))))
 (let ((?x90977 (seq.unit (_ bv33 8))))
 (let ((?x57711 (seq.unit (_ bv69 8))))
 (let ((?x91031 (seq.++ ?x57711 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x90977 (seq.++ ?x92957 ?x91026)))))))
 (let ((?x34788 (seq.unit (_ bv8 8))))
 (let ((?x91036 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x62332 (seq.++ ?x34788 (seq.++ ?x92957 ?x91031)))))))
 (let ((?x91041 (seq.++ ?x92957 (seq.++ ?x31952 (seq.++ ?x62332 (seq.++ ?x92957 (seq.++ ?x92957 ?x91036)))))))
 (let ((?x91045 (seq.++ ?x62332 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x91041))))))
 (= input_0_L.net.frame_frame ?x91045))))))))))))))))))))))))))))))))
(assert
 (= 36 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_L.app.require_checksum_required true))
(assert
 (= 33 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x92957 (seq.unit (_ bv0 8))))
(let ((?x90991 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x92957)))))))
(let ((?x90996 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x90991)))))))
(let ((?x90987 (seq.unit (_ bv7 8))))
(let ((?x96362 (seq.unit (_ bv255 8))))
(let ((?x91001 (seq.++ ?x96362 (seq.++ ?x90987 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x90996)))))))
(let ((?x90985 (seq.unit (_ bv128 8))))
(let ((?x90983 (seq.unit (_ bv13 8))))
(let ((?x91006 (seq.++ ?x90983 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x90985 ?x91001)))))))
(let ((?x57714 (seq.unit (_ bv64 8))))
(let ((?x57721 (seq.unit (_ bv156 8))))
(let ((?x57720 (seq.unit (_ bv144 8))))
(let ((?x57719 (seq.unit (_ bv31 8))))
(let ((?x91011 (seq.++ ?x57719 (seq.++ ?x57720 (seq.++ ?x57721 (seq.++ ?x57714 (seq.++ ?x92957 ?x91006)))))))
(let ((?x31952 (seq.unit (_ bv1 8))))
(let ((?x62332 (seq.unit (_ bv2 8))))
(let ((?x97271 (seq.unit (_ bv192 8))))
(let ((?x91016 (seq.++ ?x62332 (seq.++ ?x97271 (seq.++ ?x92957 (seq.++ ?x62332 (seq.++ ?x31952 ?x91011)))))))
(let ((?x90981 (seq.unit (_ bv200 8))))
(let ((?x90979 (seq.unit (_ bv182 8))))
(let ((?x91021 (seq.++ ?x90979 (seq.++ ?x90981 (seq.++ ?x97271 (seq.++ ?x92957 (seq.++ ?x62332 ?x91016)))))))
(let ((?x57715 (seq.unit (_ bv17 8))))
(let ((?x91026 (seq.++ ?x92957 (seq.++ ?x57714 (seq.++ ?x92957 (seq.++ ?x57714 (seq.++ ?x57715 ?x91021)))))))
(let ((?x90977 (seq.unit (_ bv33 8))))
(let ((?x57711 (seq.unit (_ bv69 8))))
(let ((?x91031 (seq.++ ?x57711 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x90977 (seq.++ ?x92957 ?x91026)))))))
(let ((?x34788 (seq.unit (_ bv8 8))))
(let ((?x91036 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x62332 (seq.++ ?x34788 (seq.++ ?x92957 ?x91031)))))))
(let ((?x91041 (seq.++ ?x92957 (seq.++ ?x31952 (seq.++ ?x62332 (seq.++ ?x92957 (seq.++ ?x92957 ?x91036)))))))
(let ((?x91045 (seq.++ ?x62332 (seq.++ ?x92957 (seq.++ ?x92957 (seq.++ ?x92957 ?x91041))))))
(= input_2_L.net.frame_frame ?x91045))))))))))))))))))))))))))))))))
(check-sat)

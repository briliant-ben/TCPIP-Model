; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x97957 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x57877 (= due_1_T.user due_0_T.user)))
 (let (($x57489 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x18694 (= due_1_L.cache due_0_L.cache)))
 (let (($x71204 (= due_1_L.query 1000)))
 (let (($x43410 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x97925 (= active_1_T.user active_0_T.user)))
 (let (($x52430 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x69240 (= active_1_L.cache active_0_L.cache)))
 (let (($x43669 (= v_1_ip_pending_owner "UDP")))
 (let (($x42354 (= v_1_T.control "CLOSED")))
 (let (($x98072 (= v_1_T.wire_flags 0)))
 (let (($x59330 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x2747 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x18744 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x18742 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x68277 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52057 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x48446 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x65912 (= v_1_T.take 0)))
 (let (($x52305 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x66783 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x87266 (= v_1_T.snd_wnd 8)))
 (let (($x48433 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x19030 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x19029 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x30801 (= v_1_T.local_window 16)))
 (let (($x82808 (= v_1_T.msl_ms 60000)))
 (let (($x16104 (= v_1_T.user_timeout_ms 30000)))
 (let (($x77476 (= v_1_T.retries 0)))
 (let (($x70166 (= v_1_T.rto_ms 1000)))
 (let (($x10699 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x86153 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x22864 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x22860 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x82083 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x74874 (= v_1_T.irs (_ bv0 32))))
 (let (($x79441 (= v_1_T.iss (_ bv1000 32))))
 (let (($x77358 (= v_1_L.control "PENDING")))
 (let (($x43653 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x43659 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x97744 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x93359 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x93356 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x42198 (not v_1_L.rxudp_require_checksum)))
 (let ((?x18965 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x27800 (seq.unit (_ bv0 8))))
 (let ((?x12018 (seq.++ ?x27800 ?x18965)))
 (let ((?x98149 (seq.unit (_ bv192 8))))
 (let ((?x16023 (seq.unit (_ bv13 8))))
 (let ((?x69578 (seq.++ ?x27800 (seq.++ ?x16023 (seq.++ ?x98149 (seq.++ (seq.unit (_ bv119 8)) ?x12018))))))
 (let ((?x43695 (seq.unit (_ bv144 8))))
 (let ((?x43691 (seq.unit (_ bv31 8))))
 (let ((?x18898 (seq.unit (_ bv64 8))))
 (let ((?x43690 (seq.unit (_ bv156 8))))
 (let ((?x18856 (seq.++ ?x43690 (seq.++ ?x18898 (seq.++ ?x43691 (seq.++ ?x43695 ?x69578))))))
 (let ((?x98150 (seq.unit (_ bv2 8))))
 (let ((?x35638 (seq.unit (_ bv1 8))))
 (let ((?x10427 (seq.++ ?x35638 (seq.++ ?x98149 (seq.++ ?x27800 (seq.++ ?x98150 (seq.++ ?x98150 ?x18856)))))))
 (let ((?x79556 (seq.unit (_ bv200 8))))
 (let ((?x18984 (seq.unit (_ bv182 8))))
 (let ((?x10498 (seq.++ ?x18984 (seq.++ ?x79556 (seq.++ ?x98149 (seq.++ ?x27800 (seq.++ ?x98150 ?x10427)))))))
 (let ((?x32499 (seq.unit (_ bv17 8))))
 (let ((?x57472 (seq.++ ?x27800 (seq.++ ?x18898 (seq.++ ?x27800 (seq.++ ?x18898 (seq.++ ?x32499 ?x10498)))))))
 (let ((?x18797 (seq.unit (_ bv33 8))))
 (let ((?x84097 (seq.unit (_ bv69 8))))
 (let ((?x18776 (seq.++ ?x84097 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x18797 (seq.++ ?x27800 ?x57472)))))))
 (let (($x82909 (= v_1_L.pending_packet ?x18776)))
 (let (($x67753 (= v_1_L.ip_checksum 46792)))
 (let (($x10468 (= v_1_L.udp_checksum 49271)))
 (let (($x10467 (= v_1_L.udp_raw_checksum 49271)))
 (let (($x62127 (= v_1_L.ip_length 33)))
 (let (($x62126 (= v_1_L.udp_length 13)))
 (let (($x19007 (= v_1_L.packet ?x18776)))
 (let ((?x61717 (seq.++ ?x98150 (seq.++ ?x35638 (seq.++ ?x98149 (seq.++ ?x27800 (seq.++ ?x98150 ?x98150)))))))
 (let ((?x61715 (seq.++ ?x98149 (seq.++ ?x27800 ?x61717))))
 (let ((?x43620 (seq.++ ?x27800 (seq.++ ?x18898 (seq.++ ?x32499 (seq.++ ?x18984 (seq.++ ?x79556 ?x61715)))))))
 (let ((?x85452 (seq.++ ?x27800 (seq.++ ?x18797 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x18898 ?x43620)))))))
 (let (($x3833 (= v_1_L.ip_wire (seq.++ ?x84097 (seq.++ ?x27800 ?x85452)))))
 (let ((?x23315 (seq.++ ?x27800 (seq.++ ?x18898 (seq.++ ?x32499 (seq.++ ?x27800 (seq.++ ?x27800 ?x61715)))))))
 (let ((?x18783 (seq.++ ?x27800 (seq.++ ?x18797 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x18898 ?x23315)))))))
 (let (($x82727 (= v_1_L.ip_zero (seq.++ ?x84097 (seq.++ ?x27800 ?x18783)))))
 (let (($x62103 (= v_1_L.udp_wire ?x18856)))
 (let ((?x61924 (seq.++ ?x98150 (seq.++ ?x98150 (seq.++ ?x27800 (seq.++ ?x32499 (seq.++ ?x27800 ?x16023)))))))
 (let ((?x24986 (seq.++ ?x27800 (seq.++ ?x98150 (seq.++ ?x35638 (seq.++ ?x98149 (seq.++ ?x27800 ?x61924)))))))
 (let (($x18623 (= v_1_L.pseudoheader (seq.++ ?x98149 ?x24986))))
 (let ((?x61987 (seq.++ ?x43695 (seq.++ ?x27800 (seq.++ ?x16023 (seq.++ ?x27800 (seq.++ ?x27800 ?x12018)))))))
 (let (($x61991 (= v_1_L.udp_zero (seq.++ ?x43690 (seq.++ ?x18898 (seq.++ ?x43691 ?x61987))))))
 (let (($x61762 (= v_1_L.payload ?x12018)))
 (let (($x61920 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x82615 (= 0 v_1_L.retry_count)))
 (let (($x61869 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x67843 (= 0 state_1)))
 (let (($x43681 (not active_0_T.time_wait)))
 (let (($x61860 (or $x43681 (not (<= due_0_T.time_wait 0)))))
 (let (($x43566 (not active_0_T.user)))
 (let (($x92570 (or $x43566 (not (<= due_0_T.user 0)))))
 (let (($x43567 (not active_0_T.rtx)))
 (let (($x92563 (or $x43567 (not (<= due_0_T.rtx 0)))))
 (let (($x70787 (not active_0_L.cache)))
 (let (($x61858 (or $x70787 (not (<= due_0_L.cache 0)))))
 (let (($x18738 (not active_0_L.query)))
 (let (($x18657 (or $x18738 (not (<= due_0_L.query 0)))))
 (let (($x23668 (= state_0 0)))
 (and $x23668 (>= 0 now_0) $x18657 $x61858 $x92563 $x92570 $x61860 $x67843 $x61869 $x82615 $x61920 v_1_L.checksums_enabled $x61762 $x61991 $x18623 $x62103 $x82727 $x3833 $x19007 $x62126 $x62127 $x10467 $x10468 $x67753 $x82909 $x42198 $x93356 (= v_1_L.rxudp_disposition "none") $x93359 $x97744 $x43659 $x43653 (= v_1_L.echo_disposition "none") $x77358 $x79441 $x74874 $x82083 $x22860 $x22864 $x86153 $x10699 (= v_1_T.tx_flags "S") $x70166 $x77476 v_1_T.active_open $x16104 $x82808 $x30801 $x19029 $x19030 $x48433 $x87266 $x66783 $x52305 $x65912 $x48446 $x52057 $x68277 $x18742 $x18744 $x2747 $x59330 $x98072 (= v_1_T.wire_disposition "none") $x42354 $x43669 active_1_L.query $x69240 $x52430 $x97925 $x43410 $x71204 $x18694 $x57489 $x57877 $x97957))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x42041 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x42040 (= due_2_T.user due_1_T.user)))
 (let (($x42039 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x42038 (= due_2_L.cache due_1_L.cache)))
 (let (($x42037 (= due_2_L.query due_1_L.query)))
 (let (($x42036 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x42035 (= active_2_T.user active_1_T.user)))
 (let (($x42034 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x42033 (= active_2_L.cache active_1_L.cache)))
 (let (($x42032 (= active_2_L.query active_1_L.query)))
 (let (($x42031 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x42030 (= v_2_T.control v_1_T.control)))
 (let (($x42029 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x42028 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x42027 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x42026 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x42025 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x42024 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x42023 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x42022 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x42021 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x42020 (= v_2_T.take v_1_T.take)))
 (let (($x42019 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x42018 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x42017 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x42016 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x42015 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x42014 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x42013 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x42012 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x42011 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x42010 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x42009 (= v_2_T.retries v_1_T.retries)))
 (let (($x42008 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x42007 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x42006 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x42005 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x42004 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x42003 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x42002 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x42001 (= v_2_T.irs v_1_T.irs)))
 (let (($x42000 (= v_2_T.iss v_1_T.iss)))
 (let (($x41999 (= v_2_L.control "PENDING")))
 (let (($x41998 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x41997 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x41996 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x41995 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x41994 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x41993 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x37290 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x37289 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x37288 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x37269 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x37268 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x37267 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x37262 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x37261 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x37260 (= v_2_L.packet v_1_L.packet)))
 (let (($x37255 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x37254 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x37253 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x37252 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x37247 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x37246 (= v_2_L.payload v_1_L.payload)))
 (let (($x41992 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x41991 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x41990 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x41989 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x41988 (= 0 state_2)))
 (let (($x18724 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x43401 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x79762 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x97754 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x43526 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x77358 (= v_1_L.control "PENDING")))
 (let (($x61720 (= state_1 0)))
 (and $x61720 $x77358 $x43526 $x97754 $x79762 $x43401 $x18724 $x41988 $x41989 $x41990 $x41991 $x41992 $x37246 $x37247 $x37252 $x37253 $x37254 $x37255 $x37260 $x37261 $x37262 $x37267 $x37268 $x37269 $x37288 $x37289 $x37290 $x41993 $x41994 $x41995 $x41996 $x41997 $x41998 $x41999 $x42000 $x42001 $x42002 $x42003 $x42004 $x42005 $x42006 $x42007 $x42008 $x42009 $x42010 $x42011 $x42012 $x42013 $x42014 $x42015 $x42016 $x42017 $x42018 $x42019 $x42020 $x42021 $x42022 $x42023 $x42024 $x42025 $x42026 $x42027 $x42028 $x42029 $x42030 $x42031 $x42032 $x42033 $x42034 $x42035 $x42036 $x42037 $x42038 $x42039 $x42040 $x42041))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x20479 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x20478 (= due_3_T.user due_2_T.user)))
 (let (($x20477 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x20475 (= due_3_L.query due_2_L.query)))
 (let (($x20474 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x20473 (= active_3_T.user active_2_T.user)))
 (let (($x20472 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x18707 (not active_3_L.query)))
 (let (($x20469 (= v_3_ip_pending_owner "none")))
 (let (($x20468 (= v_3_T.control v_2_T.control)))
 (let (($x20467 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x20466 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x20465 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x20464 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x20463 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x20462 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x20461 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x20460 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x20459 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x20458 (= v_3_T.take v_2_T.take)))
 (let (($x20457 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x20456 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x20455 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x20454 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x20453 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x20452 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x20451 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x20450 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x20449 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x20448 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x20447 (= v_3_T.retries v_2_T.retries)))
 (let (($x20446 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x20445 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x20444 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x20443 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x20442 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x20441 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x20440 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x20439 (= v_3_T.irs v_2_T.irs)))
 (let (($x20438 (= v_3_T.iss v_2_T.iss)))
 (let (($x20437 (= v_3_L.control "RESOLVED")))
 (let (($x20436 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x20435 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x20434 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x20433 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x20432 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x20431 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x20430 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x20429 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x61780 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x20427 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x20426 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x20425 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x20424 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x20423 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x20422 (= v_3_L.packet v_2_L.packet)))
 (let (($x20421 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x20420 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x20419 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x20418 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x20417 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x20416 (= v_3_L.payload v_2_L.payload)))
 (let (($x20415 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x20414 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x20413 (= 0 v_3_L.retry_count)))
 (let ((?x27800 (seq.unit (_ bv0 8))))
 (let ((?x16028 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.unit (_ bv3 8))))))))
 (let ((?x98150 (seq.unit (_ bv2 8))))
 (let (($x61705 (= v_3_L.peer_mac (seq.++ ?x98150 ?x16028))))
 (let (($x20411 (= 0 state_3)))
 (let (($x61702 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x61722 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x97315 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x61833 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x61905 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let ((?x20367 (seq.len v_2_L.pending_packet)))
 (let (($x20368 (<= 28 ?x20367)))
 (let (($x41999 (= v_2_L.control "PENDING")))
 (let (($x16105 (= state_2 0)))
 (and $x16105 $x41999 $x20368 $x61905 $x61833 $x97315 $x61722 $x61702 $x20411 $x61705 $x20413 $x20414 $x20415 $x20416 $x20417 $x20418 $x20419 $x20420 $x20421 $x20422 $x20423 $x20424 $x20425 $x20426 $x20427 $x61780 $x20429 $x20430 $x20431 $x20432 $x20433 $x20434 $x20435 $x20436 $x20437 $x20438 $x20439 $x20440 $x20441 $x20442 $x20443 $x20444 $x20445 $x20446 $x20447 $x20448 $x20449 $x20450 $x20451 $x20452 $x20453 $x20454 $x20455 $x20456 $x20457 $x20458 $x20459 $x20460 $x20461 $x20462 $x20463 $x20464 $x20465 $x20466 $x20467 $x20468 $x20469 $x18707 active_3_L.cache $x20472 $x20473 $x20474 $x20475 (= due_3_L.cache (+ 2 v_2_L.cache_ttl_ms)) $x20477 $x20478 $x20479)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x18965 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x27800 (seq.unit (_ bv0 8))))
 (let ((?x12018 (seq.++ ?x27800 ?x18965)))
 (= input_0_L.app.send_data ?x12018)))))
(assert
 (= 12 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x98149 (seq.unit (_ bv192 8))))
 (let ((?x18988 (seq.++ ?x98149 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x27800 (seq.unit (_ bv0 8))))
 (let ((?x83306 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 ?x18988)))))))
 (let ((?x98150 (seq.unit (_ bv2 8))))
 (let ((?x100794 (seq.++ ?x98149 (seq.++ ?x27800 (seq.++ ?x98150 (seq.++ ?x98150 (seq.++ ?x27800 ?x83306)))))))
 (let ((?x80422 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x98150 ?x100794)))))))
 (let ((?x35638 (seq.unit (_ bv1 8))))
 (let ((?x101869 (seq.unit (_ bv4 8))))
 (let ((?x45939 (seq.unit (_ bv6 8))))
 (let ((?x74879 (seq.++ ?x45939 (seq.++ ?x101869 (seq.++ ?x27800 (seq.++ ?x35638 (seq.++ ?x98150 ?x80422)))))))
 (let ((?x102791 (seq.unit (_ bv8 8))))
 (let ((?x13136 (seq.++ ?x45939 (seq.++ ?x27800 (seq.++ ?x35638 (seq.++ ?x102791 (seq.++ ?x27800 ?x74879)))))))
 (let ((?x18923 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x98150 (seq.++ ?x102791 ?x13136)))))))
 (let ((?x57263 (seq.unit (_ bv255 8))))
 (let ((?x93321 (seq.++ ?x57263 (seq.++ ?x57263 (seq.++ ?x57263 (seq.++ ?x98150 (seq.++ ?x27800 ?x18923)))))))
 (let ((?x18925 (seq.++ ?x57263 (seq.++ ?x57263 (seq.++ ?x57263 ?x93321)))))
 (= input_1_L.net.frame_frame ?x18925)))))))))))))))))))
(assert
 (= 29 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x98149 (seq.unit (_ bv192 8))))
(let ((?x45863 (seq.++ ?x98149 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x35638 (seq.unit (_ bv1 8))))
(let ((?x27800 (seq.unit (_ bv0 8))))
(let ((?x64597 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x35638 ?x45863)))))))
(let ((?x98150 (seq.unit (_ bv2 8))))
(let ((?x37439 (seq.++ ?x98149 (seq.++ ?x27800 (seq.++ ?x98150 (seq.++ ?x98150 (seq.++ ?x98150 ?x64597)))))))
(let ((?x77556 (seq.unit (_ bv3 8))))
(let ((?x19049 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x77556 ?x37439)))))))
(let ((?x101869 (seq.unit (_ bv4 8))))
(let ((?x45939 (seq.unit (_ bv6 8))))
(let ((?x19027 (seq.++ ?x45939 (seq.++ ?x101869 (seq.++ ?x27800 (seq.++ ?x98150 (seq.++ ?x98150 ?x19049)))))))
(let ((?x102791 (seq.unit (_ bv8 8))))
(let ((?x67137 (seq.++ ?x45939 (seq.++ ?x27800 (seq.++ ?x35638 (seq.++ ?x102791 (seq.++ ?x27800 ?x19027)))))))
(let ((?x5237 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x77556 (seq.++ ?x102791 ?x67137)))))))
(let ((?x18812 (seq.++ ?x27800 (seq.++ ?x27800 (seq.++ ?x35638 (seq.++ ?x98150 (seq.++ ?x27800 ?x5237)))))))
(let ((?x62119 (seq.++ ?x98150 (seq.++ ?x27800 (seq.++ ?x27800 ?x18812)))))
(= input_2_L.net.frame_frame ?x62119)))))))))))))))))))
(check-sat)

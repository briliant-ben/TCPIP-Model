; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x25299 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x25298 (= due_1_T.user due_0_T.user)))
 (let (($x25297 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x25296 (= due_1_L.cache due_0_L.cache)))
 (let (($x98154 (= due_1_L.query 1000)))
 (let (($x25294 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x25293 (= active_1_T.user active_0_T.user)))
 (let (($x25292 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x25291 (= active_1_L.cache active_0_L.cache)))
 (let (($x25289 (= v_1_ip_pending_owner "UDP")))
 (let (($x23956 (= v_1_T.control "CLOSED")))
 (let (($x80337 (= v_1_T.wire_flags 0)))
 (let (($x98153 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x98152 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x98151 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x98150 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x98149 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x98148 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x98147 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x69274 (= v_1_T.take 0)))
 (let (($x80267 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x77015 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x85870 (= v_1_T.snd_wnd 8)))
 (let (($x98146 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x98145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x98144 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x57008 (= v_1_T.local_window 16)))
 (let (($x77178 (= v_1_T.msl_ms 60000)))
 (let (($x77789 (= v_1_T.user_timeout_ms 30000)))
 (let (($x73386 (= v_1_T.retries 0)))
 (let (($x94479 (= v_1_T.rto_ms 1000)))
 (let (($x78719 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x80224 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x74450 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x75250 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x87926 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x69168 (= v_1_T.irs (_ bv0 32))))
 (let (($x22185 (= v_1_T.iss (_ bv1000 32))))
 (let (($x25257 (= v_1_L.control "PENDING")))
 (let (($x98143 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x98142 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x98141 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x98140 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x98139 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x18899 (not v_1_L.rxudp_require_checksum)))
 (let ((?x57234 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x57237 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x57234)))))
 (let ((?x14604 (seq.unit (_ bv8 8))))
 (let ((?x14610 (seq.unit (_ bv6 8))))
 (let ((?x57241 (seq.++ ?x14610 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x14604 (seq.++ (seq.unit (_ bv9 8)) ?x57237))))))
 (let ((?x14616 (seq.unit (_ bv4 8))))
 (let ((?x1544 (seq.unit (_ bv2 8))))
 (let ((?x57245 (seq.++ ?x1544 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x14616 (seq.++ (seq.unit (_ bv5 8)) ?x57241))))))
 (let ((?x1606 (seq.unit (_ bv1 8))))
 (let ((?x1542 (seq.unit (_ bv0 8))))
 (let ((?x57247 (seq.++ ?x1542 (seq.++ ?x1606 ?x57245))))
 (let ((?x47708 (seq.unit (_ bv25 8))))
 (let ((?x57809 (seq.++ ?x1542 (seq.++ ?x47708 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv167 8)) ?x57247))))))
 (let ((?x25407 (seq.unit (_ bv144 8))))
 (let ((?x25405 (seq.unit (_ bv31 8))))
 (let ((?x25092 (seq.unit (_ bv64 8))))
 (let ((?x25409 (seq.unit (_ bv156 8))))
 (let ((?x57813 (seq.++ ?x25409 (seq.++ ?x25092 (seq.++ ?x25405 (seq.++ ?x25407 ?x57809))))))
 (let ((?x1541 (seq.unit (_ bv192 8))))
 (let ((?x98116 (seq.++ ?x1606 (seq.++ ?x1541 (seq.++ ?x1542 (seq.++ ?x1544 (seq.++ ?x1544 ?x57813)))))))
 (let ((?x98011 (seq.unit (_ bv188 8))))
 (let ((?x98009 (seq.unit (_ bv182 8))))
 (let ((?x98121 (seq.++ ?x98009 (seq.++ ?x98011 (seq.++ ?x1541 (seq.++ ?x1542 (seq.++ ?x1544 ?x98116)))))))
 (let ((?x25052 (seq.unit (_ bv17 8))))
 (let ((?x98126 (seq.++ ?x1542 (seq.++ ?x25092 (seq.++ ?x1542 (seq.++ ?x25092 (seq.++ ?x25052 ?x98121)))))))
 (let ((?x57817 (seq.unit (_ bv45 8))))
 (let ((?x25071 (seq.unit (_ bv69 8))))
 (let ((?x98131 (seq.++ ?x25071 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x57817 (seq.++ ?x1542 ?x98126)))))))
 (let (($x98138 (= v_1_L.pending_packet ?x98131)))
 (let (($x98137 (= v_1_L.ip_checksum 46780)))
 (let (($x98136 (= v_1_L.udp_checksum 30631)))
 (let (($x98135 (= v_1_L.udp_raw_checksum 30631)))
 (let (($x98134 (= v_1_L.ip_length 45)))
 (let (($x98133 (= v_1_L.udp_length 25)))
 (let (($x98132 (= v_1_L.packet ?x98131)))
 (let ((?x1405 (seq.++ ?x1544 (seq.++ ?x1606 (seq.++ ?x1541 (seq.++ ?x1542 (seq.++ ?x1544 ?x1544)))))))
 (let ((?x1407 (seq.++ ?x1541 (seq.++ ?x1542 ?x1405))))
 (let ((?x98067 (seq.++ ?x1542 (seq.++ ?x25092 (seq.++ ?x25052 (seq.++ ?x98009 (seq.++ ?x98011 ?x1407)))))))
 (let ((?x98072 (seq.++ ?x1542 (seq.++ ?x57817 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x25092 ?x98067)))))))
 (let (($x98075 (= v_1_L.ip_wire (seq.++ ?x25071 (seq.++ ?x1542 ?x98072)))))
 (let ((?x57888 (seq.++ ?x1542 (seq.++ ?x25092 (seq.++ ?x25052 (seq.++ ?x1542 (seq.++ ?x1542 ?x1407)))))))
 (let ((?x57893 (seq.++ ?x1542 (seq.++ ?x57817 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x25092 ?x57888)))))))
 (let (($x57896 (= v_1_L.ip_zero (seq.++ ?x25071 (seq.++ ?x1542 ?x57893)))))
 (let (($x57814 (= v_1_L.udp_wire ?x57813)))
 (let ((?x3316 (seq.++ ?x1544 (seq.++ ?x1544 (seq.++ ?x1542 (seq.++ ?x25052 (seq.++ ?x1542 ?x47708)))))))
 (let ((?x5505 (seq.++ ?x1542 (seq.++ ?x1544 (seq.++ ?x1606 (seq.++ ?x1541 (seq.++ ?x1542 ?x3316)))))))
 (let (($x8974 (= v_1_L.pseudoheader (seq.++ ?x1541 ?x5505))))
 (let ((?x47170 (seq.++ ?x25407 (seq.++ ?x1542 (seq.++ ?x47708 (seq.++ ?x1542 (seq.++ ?x1542 ?x57247)))))))
 (let (($x103928 (= v_1_L.udp_zero (seq.++ ?x25409 (seq.++ ?x25092 (seq.++ ?x25405 ?x47170))))))
 (let (($x103128 (= v_1_L.payload ?x57247)))
 (let (($x77925 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x25158 (= 0 v_1_L.retry_count)))
 (let (($x30356 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x25156 (= 0 state_1)))
 (let (($x1510 (not active_0_T.time_wait)))
 (let (($x55856 (or $x1510 (not (<= due_0_T.time_wait 0)))))
 (let (($x1508 (not active_0_T.user)))
 (let (($x51549 (or $x1508 (not (<= due_0_T.user 0)))))
 (let (($x1506 (not active_0_T.rtx)))
 (let (($x104165 (or $x1506 (not (<= due_0_T.rtx 0)))))
 (let (($x1504 (not active_0_L.cache)))
 (let (($x10465 (or $x1504 (not (<= due_0_L.cache 0)))))
 (let (($x1502 (not active_0_L.query)))
 (let (($x13326 (or $x1502 (not (<= due_0_L.query 0)))))
 (let (($x1325 (= state_0 0)))
 (and $x1325 (>= 0 now_0) $x13326 $x10465 $x104165 $x51549 $x55856 $x25156 $x30356 $x25158 $x77925 v_1_L.checksums_enabled $x103128 $x103928 $x8974 $x57814 $x57896 $x98075 $x98132 $x98133 $x98134 $x98135 $x98136 $x98137 $x98138 $x18899 $x98139 (= v_1_L.rxudp_disposition "none") $x98140 $x98141 $x98142 $x98143 (= v_1_L.echo_disposition "none") $x25257 $x22185 $x69168 $x87926 $x75250 $x74450 $x80224 $x78719 (= v_1_T.tx_flags "S") $x94479 $x73386 v_1_T.active_open $x77789 $x77178 $x57008 $x98144 $x98145 $x98146 $x85870 $x77015 $x80267 $x69274 $x98147 $x98148 $x98149 $x98150 $x98151 $x98152 $x98153 $x80337 (= v_1_T.wire_disposition "none") $x23956 $x25289 active_1_L.query $x25291 $x25292 $x25293 $x25294 $x98154 $x25296 $x25297 $x25298 $x25299))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x18910 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x23665 (= due_2_T.user due_1_T.user)))
 (let (($x23664 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x23662 (= due_2_L.query due_1_L.query)))
 (let (($x23661 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x23660 (= active_2_T.user active_1_T.user)))
 (let (($x23659 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x57950 (not active_2_L.query)))
 (let (($x23656 (= v_2_ip_pending_owner "none")))
 (let (($x23655 (= v_2_T.control v_1_T.control)))
 (let (($x23654 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x23653 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x23652 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x23651 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x18907 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x18906 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x18905 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x23650 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x23649 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x23648 (= v_2_T.take v_1_T.take)))
 (let (($x23647 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x23646 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x23645 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x23644 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x23643 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x23642 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x23641 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x23640 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x23639 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x23638 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x23637 (= v_2_T.retries v_1_T.retries)))
 (let (($x23636 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x18902 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x23635 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x23634 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x23633 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x23632 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x23631 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x23630 (= v_2_T.irs v_1_T.irs)))
 (let (($x23629 (= v_2_T.iss v_1_T.iss)))
 (let (($x23628 (= v_2_L.control "RESOLVED")))
 (let (($x23627 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x23626 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x23625 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x23624 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x23623 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x23622 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x18212 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x16633 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x57949 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x16631 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x16612 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x16611 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x16610 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x16605 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x16604 (= v_2_L.packet v_1_L.packet)))
 (let (($x16603 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x16598 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x16597 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x16596 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x16595 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x16590 (= v_2_L.payload v_1_L.payload)))
 (let (($x16589 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x23621 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x23620 (= 0 v_2_L.retry_count)))
 (let ((?x1542 (seq.unit (_ bv0 8))))
 (let ((?x61725 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.unit (_ bv2 8))))))))
 (let ((?x1544 (seq.unit (_ bv2 8))))
 (let ((?x61726 (seq.++ ?x1544 ?x61725)))
 (let (($x57948 (= v_2_L.peer_mac ?x61726)))
 (let (($x23618 (= 0 state_2)))
 (let (($x57947 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x57943 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x57937 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x57543 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x57472 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x23575 (seq.len v_1_L.pending_packet)))
 (let (($x23576 (<= 28 ?x23575)))
 (let (($x25257 (= v_1_L.control "PENDING")))
 (let (($x80581 (= state_1 0)))
 (and $x80581 $x25257 $x23576 $x57472 $x57543 $x57937 $x57943 $x57947 $x23618 $x57948 $x23620 $x23621 $x16589 $x16590 $x16595 $x16596 $x16597 $x16598 $x16603 $x16604 $x16605 $x16610 $x16611 $x16612 $x16631 $x57949 $x16633 $x18212 $x23622 $x23623 $x23624 $x23625 $x23626 $x23627 $x23628 $x23629 $x23630 $x23631 $x23632 $x23633 $x23634 $x23635 $x18902 $x23636 $x23637 $x23638 $x23639 $x23640 $x23641 $x23642 $x23643 $x23644 $x23645 $x23646 $x23647 $x23648 $x23649 $x23650 $x18905 $x18906 $x18907 $x23651 $x23652 $x23653 $x23654 $x23655 $x23656 $x57950 active_2_L.cache $x23659 $x23660 $x23661 $x23662 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x23664 $x23665 $x18910))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x57234 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x57237 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x57234)))))
 (let ((?x14604 (seq.unit (_ bv8 8))))
 (let ((?x14610 (seq.unit (_ bv6 8))))
 (let ((?x57241 (seq.++ ?x14610 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x14604 (seq.++ (seq.unit (_ bv9 8)) ?x57237))))))
 (let ((?x14616 (seq.unit (_ bv4 8))))
 (let ((?x1544 (seq.unit (_ bv2 8))))
 (let ((?x57245 (seq.++ ?x1544 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x14616 (seq.++ (seq.unit (_ bv5 8)) ?x57241))))))
 (let ((?x1606 (seq.unit (_ bv1 8))))
 (let ((?x1542 (seq.unit (_ bv0 8))))
 (let ((?x57247 (seq.++ ?x1542 (seq.++ ?x1606 ?x57245))))
 (= input_0_L.app.send_data ?x57247)))))))))))))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x1541 (seq.unit (_ bv192 8))))
(let ((?x24988 (seq.++ ?x1541 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x1606 (seq.unit (_ bv1 8))))
(let ((?x1542 (seq.unit (_ bv0 8))))
(let ((?x57254 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1606 ?x24988)))))))
(let ((?x1544 (seq.unit (_ bv2 8))))
(let ((?x57258 (seq.++ ?x1541 (seq.++ ?x1542 (seq.++ ?x1544 (seq.++ ?x1544 (seq.++ ?x1544 ?x57254)))))))
(let ((?x57263 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1544 ?x57258)))))))
(let ((?x14616 (seq.unit (_ bv4 8))))
(let ((?x14610 (seq.unit (_ bv6 8))))
(let ((?x57268 (seq.++ ?x14610 (seq.++ ?x14616 (seq.++ ?x1542 (seq.++ ?x1544 (seq.++ ?x1544 ?x57263)))))))
(let ((?x14604 (seq.unit (_ bv8 8))))
(let ((?x57273 (seq.++ ?x14610 (seq.++ ?x1542 (seq.++ ?x1606 (seq.++ ?x14604 (seq.++ ?x1542 ?x57268)))))))
(let ((?x57278 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1544 (seq.++ ?x14604 ?x57273)))))))
(let ((?x57285 (seq.++ ?x1542 (seq.++ ?x1542 (seq.++ ?x1606 (seq.++ ?x1544 (seq.++ ?x1542 ?x57278)))))))
(let ((?x57288 (seq.++ ?x1544 (seq.++ ?x1542 (seq.++ ?x1542 ?x57285)))))
(= input_1_L.net.frame_frame ?x57288))))))))))))))))))
(check-sat)

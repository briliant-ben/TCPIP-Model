; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_T.time_wait () Int)
(declare-fun due_4_T.user () Int)
(declare-fun due_4_T.rtx () Int)
(declare-fun due_4_L.cache () Int)
(declare-fun due_4_L.query () Int)
(declare-fun active_4_T.time_wait () Bool)
(declare-fun active_4_T.user () Bool)
(declare-fun active_4_T.rtx () Bool)
(declare-fun active_4_L.cache () Bool)
(declare-fun active_4_L.query () Bool)
(declare-fun v_4_ip_pending_owner () String)
(declare-fun v_4_T.control () String)
(declare-fun v_4_T.wire_disposition () String)
(declare-fun v_4_T.wire_flags () Int)
(declare-fun v_4_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_4_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_4_T.take () Int)
(declare-fun v_4_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_4_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_4_T.snd_wnd () Int)
(declare-fun v_4_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_T.local_window () Int)
(declare-fun v_4_T.msl_ms () Int)
(declare-fun v_4_T.user_timeout_ms () Int)
(declare-fun v_4_T.active_open () Bool)
(declare-fun v_4_T.retries () Int)
(declare-fun v_4_T.rto_ms () Int)
(declare-fun v_4_T.tx_flags () String)
(declare-fun v_4_T.tx_ack () (_ BitVec 32))
(declare-fun v_4_T.tx_seq () (_ BitVec 32))
(declare-fun v_4_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_4_T.snd_nxt () (_ BitVec 32))
(declare-fun v_4_T.snd_una () (_ BitVec 32))
(declare-fun v_4_T.irs () (_ BitVec 32))
(declare-fun v_4_T.iss () (_ BitVec 32))
(declare-fun v_4_L.control () String)
(declare-fun v_4_L.echo_disposition () String)
(declare-fun v_4_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_4_L.rxudp_disposition () String)
(declare-fun v_4_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_L.rxudp_require_checksum () Bool)
(declare-fun v_4_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_L.ip_checksum () Int)
(declare-fun v_4_L.udp_checksum () Int)
(declare-fun v_4_L.udp_raw_checksum () Int)
(declare-fun v_4_L.ip_length () Int)
(declare-fun v_4_L.udp_length () Int)
(declare-fun v_4_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_4_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_4_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_4_L.checksums_enabled () Bool)
(declare-fun v_4_L.cache_ttl_ms () Int)
(declare-fun v_4_L.retry_count () Int)
(declare-fun v_4_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x49934 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x3804 (= due_1_T.user due_0_T.user)))
 (let (($x3801 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x3800 (= due_1_L.cache due_0_L.cache)))
 (let (($x2484 (= due_1_L.query 1000)))
 (let (($x8769 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x49933 (= active_1_T.user active_0_T.user)))
 (let (($x32980 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x3860 (= active_1_L.cache active_0_L.cache)))
 (let (($x31316 (= v_1_T.control "CLOSED")))
 (let (($x92449 (= v_1_T.wire_flags 0)))
 (let (($x2483 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x63351 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x33711 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x63466 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x34087 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x63357 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x2661 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x56592 (= v_1_T.take 0)))
 (let (($x56593 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x56594 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x92451 (= v_1_T.snd_wnd 8)))
 (let (($x33710 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x63358 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x2657 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x63601 (= v_1_T.local_window 16)))
 (let (($x63602 (= v_1_T.msl_ms 60000)))
 (let (($x2698 (= v_1_T.user_timeout_ms 30000)))
 (let (($x63638 (= v_1_T.retries 0)))
 (let (($x33661 (= v_1_T.rto_ms 1000)))
 (let (($x56598 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x56599 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x56595 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x56596 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x56358 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x75260 (= v_1_T.irs (_ bv0 32))))
 (let (($x92447 (= v_1_T.iss (_ bv1000 32))))
 (let (($x95184 (= v_1_L.control "PENDING")))
 (let (($x2666 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x366 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x33886 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x34044 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x63395 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x31146 (not v_1_L.rxudp_require_checksum)))
 (let (($x2658 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x56610 (= v_1_L.ip_checksum 0)))
 (let (($x56613 (= v_1_L.udp_checksum 0)))
 (let (($x56614 (= v_1_L.udp_raw_checksum 0)))
 (let (($x56615 (= v_1_L.ip_length 0)))
 (let (($x56616 (= v_1_L.udp_length 0)))
 (let (($x33834 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x63245 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x56668 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x56667 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x56666 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x56664 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x56609 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x56605 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x12901 (= 0 v_1_L.retry_count)))
 (let (($x56606 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x32535 (= 0 state_1)))
 (let (($x50288 (not active_0_T.time_wait)))
 (let (($x56600 (or $x50288 (not (<= due_0_T.time_wait 0)))))
 (let (($x52956 (not active_0_T.user)))
 (let (($x56586 (or $x52956 (not (<= due_0_T.user 0)))))
 (let (($x50217 (not active_0_T.rtx)))
 (let (($x56581 (or $x50217 (not (<= due_0_T.rtx 0)))))
 (let (($x53073 (not active_0_L.cache)))
 (let (($x56573 (or $x53073 (not (<= due_0_L.cache 0)))))
 (let (($x34666 (not active_0_L.query)))
 (let (($x56303 (or $x34666 (not (<= due_0_L.query 0)))))
 (let (($x95163 (= state_0 0)))
 (and $x95163 (>= 0 now_0) $x56303 $x56573 $x56581 $x56586 $x56600 $x32535 $x56606 $x12901 $x56605 v_1_L.checksums_enabled $x56609 $x56664 $x56666 $x56667 $x56668 $x63245 $x33834 $x56616 $x56615 $x56614 $x56613 $x56610 $x2658 $x31146 $x63395 (= v_1_L.rxudp_disposition "none") $x34044 $x33886 $x366 $x2666 (= v_1_L.echo_disposition "none") $x95184 $x92447 $x75260 $x56358 $x56596 $x56595 $x56599 $x56598 (= v_1_T.tx_flags "S") $x33661 $x63638 v_1_T.active_open $x2698 $x63602 $x63601 $x2657 $x63358 $x33710 $x92451 $x56594 $x56593 $x56592 $x2661 $x63357 $x34087 $x63466 $x33711 $x63351 $x2483 $x92449 (= v_1_T.wire_disposition "none") $x31316 (= v_1_ip_pending_owner "none") active_1_L.query $x3860 $x32980 $x49933 $x8769 $x2484 $x3800 $x3801 $x3804 $x49934))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x30879 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x30878 (= due_2_T.user due_1_T.user)))
 (let (($x30877 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x30876 (= due_2_L.cache due_1_L.cache)))
 (let (($x30875 (= due_2_L.query due_1_L.query)))
 (let (($x30874 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x30873 (= active_2_T.user active_1_T.user)))
 (let (($x30872 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x30871 (= active_2_L.cache active_1_L.cache)))
 (let (($x30870 (= active_2_L.query active_1_L.query)))
 (let (($x30869 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x30868 (= v_2_T.control v_1_T.control)))
 (let (($x30867 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x30866 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x30865 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x30864 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x30863 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x30862 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x30786 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x30785 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x30784 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x30783 (= v_2_T.take v_1_T.take)))
 (let (($x30782 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x30781 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x30780 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x30779 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x30778 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x30777 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x30776 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x30775 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x30774 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x30773 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x30772 (= v_2_T.retries v_1_T.retries)))
 (let (($x30771 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x30770 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x30769 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x30768 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x30767 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x30766 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x30765 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x30764 (= v_2_T.irs v_1_T.irs)))
 (let (($x30763 (= v_2_T.iss v_1_T.iss)))
 (let (($x30762 (= v_2_L.control "PENDING")))
 (let (($x30761 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x30760 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x30759 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x30758 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x30757 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x30756 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x30755 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x30754 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x30753 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x30752 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x30751 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x30750 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x30749 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x30748 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x30746 (= v_2_L.packet v_1_L.packet)))
 (let (($x30745 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x30744 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x30743 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x30742 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x30741 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x30740 (= v_2_L.payload v_1_L.payload)))
 (let (($x30739 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x30738 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x30737 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x30736 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x30735 (= 0 state_2)))
 (let (($x92459 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x56575 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x63639 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x31844 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x56617 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let (($x95184 (= v_1_L.control "PENDING")))
 (let (($x56608 (= state_1 0)))
 (and $x56608 $x95184 $x56617 $x31844 $x63639 $x56575 $x92459 $x30735 $x30736 $x30737 $x30738 $x30739 $x30740 $x30741 $x30742 $x30743 $x30744 $x30745 $x30746 $x30748 $x30749 $x30750 $x30751 $x30752 $x30753 $x30754 $x30755 $x30756 $x30757 $x30758 $x30759 $x30760 $x30761 $x30762 $x30763 $x30764 $x30765 $x30766 $x30767 $x30768 $x30769 $x30770 $x30771 $x30772 $x30773 $x30774 $x30775 $x30776 $x30777 $x30778 $x30779 $x30780 $x30781 $x30782 $x30783 $x30784 $x30785 $x30786 $x30862 $x30863 $x30864 $x30865 $x30866 $x30867 $x30868 $x30869 $x30870 $x30871 $x30872 $x30873 $x30874 $x30875 $x30876 $x30877 $x30878 $x30879))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x48644 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x48643 (= due_3_T.user due_2_T.user)))
 (let (($x48642 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x48641 (= due_3_L.cache due_2_L.cache)))
 (let (($x56839 (= due_3_L.query 2000)))
 (let (($x48639 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x48638 (= active_3_T.user active_2_T.user)))
 (let (($x48637 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x48636 (= active_3_L.cache active_2_L.cache)))
 (let (($x48634 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x48633 (= v_3_T.control v_2_T.control)))
 (let (($x48632 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x48631 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x48630 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x48629 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x48628 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x48627 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x48626 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x48625 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x48624 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x48623 (= v_3_T.take v_2_T.take)))
 (let (($x48622 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x48621 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x48620 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x48619 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x48618 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x48617 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x48616 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x48615 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x48614 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x48613 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x48612 (= v_3_T.retries v_2_T.retries)))
 (let (($x48611 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x48610 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x48609 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x48608 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x48607 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x48606 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x48605 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x48604 (= v_3_T.irs v_2_T.irs)))
 (let (($x48603 (= v_3_T.iss v_2_T.iss)))
 (let (($x48602 (= v_3_L.control "PENDING")))
 (let (($x48601 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x48600 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x48599 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x48598 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x48597 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x48596 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x48595 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x48594 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x48593 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x48592 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x48591 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x48590 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x48589 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x48588 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x48587 (= v_3_L.packet v_2_L.packet)))
 (let (($x48586 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x48585 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x48584 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x48583 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x48582 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x48581 (= v_3_L.payload v_2_L.payload)))
 (let (($x48580 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x48579 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x48578 (= 1 v_3_L.retry_count)))
 (let (($x48577 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x48576 (= 0 state_3)))
 (let (($x48560 (= 0 v_2_L.retry_count)))
 (let (($x30762 (= v_2_L.control "PENDING")))
 (let (($x2629 (= state_2 0)))
 (and $x2629 $x30762 $x48560 active_2_L.query (= 1000 due_2_L.query) (or (not active_2_L.cache) (not (<= due_2_L.cache due_2_L.query))) (or (not active_2_T.rtx) (<= due_2_L.query due_2_T.rtx)) (or (not active_2_T.user) (<= due_2_L.query due_2_T.user)) (or (not active_2_T.time_wait) (<= due_2_L.query due_2_T.time_wait)) $x48576 $x48577 $x48578 $x48579 $x48580 $x48581 $x48582 $x48583 $x48584 $x48585 $x48586 $x48587 $x48588 $x48589 $x48590 $x48591 $x48592 $x48593 $x48594 $x48595 $x48596 $x48597 $x48598 $x48599 $x48600 $x48601 $x48602 $x48603 $x48604 $x48605 $x48606 $x48607 $x48608 $x48609 $x48610 $x48611 $x48612 $x48613 $x48614 $x48615 $x48616 $x48617 $x48618 $x48619 $x48620 $x48621 $x48622 $x48623 $x48624 $x48625 $x48626 $x48627 $x48628 $x48629 $x48630 $x48631 $x48632 $x48633 $x48634 active_3_L.query $x48636 $x48637 $x48638 $x48639 $x56839 $x48641 $x48642 $x48643 $x48644)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x65369 (= due_4_T.time_wait due_3_T.time_wait)))
 (let (($x32991 (= due_4_T.user due_3_T.user)))
 (let (($x91280 (= due_4_T.rtx due_3_T.rtx)))
 (let (($x51711 (= due_4_L.cache due_3_L.cache)))
 (let (($x125365 (= due_4_L.query due_3_L.query)))
 (let (($x52998 (= active_4_T.time_wait active_3_T.time_wait)))
 (let (($x53289 (= active_4_T.user active_3_T.user)))
 (let (($x55594 (= active_4_T.rtx active_3_T.rtx)))
 (let (($x55593 (= active_4_L.cache active_3_L.cache)))
 (let (($x49925 (not active_4_L.query)))
 (let (($x26840 (= v_4_ip_pending_owner v_3_ip_pending_owner)))
 (let (($x53036 (= v_4_T.control v_3_T.control)))
 (let (($x51714 (= v_4_T.wire_disposition v_3_T.wire_disposition)))
 (let (($x53226 (= v_4_T.wire_flags v_3_T.wire_flags)))
 (let (($x53227 (= v_4_T.wire_packet v_3_T.wire_packet)))
 (let (($x77328 (= v_4_T.wire_ip_zero v_3_T.wire_ip_zero)))
 (let (($x63088 (= v_4_T.wire_tcp v_3_T.wire_tcp)))
 (let (($x53083 (= v_4_T.wire_pseudo v_3_T.wire_pseudo)))
 (let (($x52664 (= v_4_T.wire_tcp_zero v_3_T.wire_tcp_zero)))
 (let (($x55445 (= v_4_T.wire_data v_3_T.wire_data)))
 (let (($x32946 (= v_4_T.rx_chunk v_3_T.rx_chunk)))
 (let (($x53237 (= v_4_T.take v_3_T.take)))
 (let (($x53239 (= v_4_T.snd_wl2 v_3_T.snd_wl2)))
 (let (($x5547 (= v_4_T.snd_wl1 v_3_T.snd_wl1)))
 (let (($x32832 (= v_4_T.snd_wnd v_3_T.snd_wnd)))
 (let (($x91369 (= v_4_T.rcv_buf v_3_T.rcv_buf)))
 (let (($x95190 (= v_4_T.rtx_buf v_3_T.rtx_buf)))
 (let (($x95128 (= v_4_T.snd_buf v_3_T.snd_buf)))
 (let (($x12557 (= v_4_T.local_window v_3_T.local_window)))
 (let (($x12991 (= v_4_T.msl_ms v_3_T.msl_ms)))
 (let (($x91145 (= v_4_T.user_timeout_ms v_3_T.user_timeout_ms)))
 (let (($x91324 (= v_4_T.active_open v_3_T.active_open)))
 (let (($x5475 (= v_4_T.retries v_3_T.retries)))
 (let (($x5538 (= v_4_T.rto_ms v_3_T.rto_ms)))
 (let (($x55446 (= v_4_T.tx_flags v_3_T.tx_flags)))
 (let (($x129 (= v_4_T.tx_ack v_3_T.tx_ack)))
 (let (($x63791 (= v_4_T.tx_seq v_3_T.tx_seq)))
 (let (($x9453 (= v_4_T.rcv_nxt v_3_T.rcv_nxt)))
 (let (($x91340 (= v_4_T.snd_nxt v_3_T.snd_nxt)))
 (let (($x72 (= v_4_T.snd_una v_3_T.snd_una)))
 (let (($x91435 (= v_4_T.irs v_3_T.irs)))
 (let (($x55550 (= v_4_T.iss v_3_T.iss)))
 (let (($x3772 (= v_4_L.control "EMPTY")))
 (let (($x3773 (= v_4_L.echo_disposition v_3_L.echo_disposition)))
 (let (($x53084 (= v_4_L.echo_ip_zero v_3_L.echo_ip_zero)))
 (let (($x25236 (= v_4_L.echo_icmp_wire v_3_L.echo_icmp_wire)))
 (let (($x55373 (= v_4_L.echo_icmp_zero v_3_L.echo_icmp_zero)))
 (let (($x55389 (= v_4_L.echo_reply v_3_L.echo_reply)))
 (let (($x55596 (= v_4_L.rxudp_disposition v_3_L.rxudp_disposition)))
 (let (($x55595 (= v_4_L.rxudp_payload v_3_L.rxudp_payload)))
 (let (($x65500 (= v_4_L.rxudp_require_checksum v_3_L.rxudp_require_checksum)))
 (let (($x55358 (= v_4_L.pending_packet v_3_L.pending_packet)))
 (let (($x213 (= v_4_L.ip_checksum v_3_L.ip_checksum)))
 (let (($x55528 (= v_4_L.udp_checksum v_3_L.udp_checksum)))
 (let (($x12644 (= v_4_L.udp_raw_checksum v_3_L.udp_raw_checksum)))
 (let (($x12747 (= v_4_L.ip_length v_3_L.ip_length)))
 (let (($x91261 (= v_4_L.udp_length v_3_L.udp_length)))
 (let (($x91260 (= v_4_L.packet v_3_L.packet)))
 (let (($x55414 (= v_4_L.ip_wire v_3_L.ip_wire)))
 (let (($x91333 (= v_4_L.ip_zero v_3_L.ip_zero)))
 (let (($x32333 (= v_4_L.udp_wire v_3_L.udp_wire)))
 (let (($x206 (= v_4_L.pseudoheader v_3_L.pseudoheader)))
 (let (($x32279 (= v_4_L.udp_zero v_3_L.udp_zero)))
 (let (($x52814 (= v_4_L.payload v_3_L.payload)))
 (let (($x5476 (= v_4_L.checksums_enabled v_3_L.checksums_enabled)))
 (let (($x5477 (= v_4_L.cache_ttl_ms v_3_L.cache_ttl_ms)))
 (let (($x32982 (= 0 v_4_L.retry_count)))
 (let (($x63480 (= (as seq.empty (Seq (_ BitVec 8))) v_4_L.peer_mac)))
 (let (($x91319 (= 0 state_4)))
 (let ((?x31921 (seq.len v_3_L.pending_packet)))
 (let (($x51717 (= 0 ?x31921)))
 (let (($x48578 (= 1 v_3_L.retry_count)))
 (let (($x48602 (= v_3_L.control "PENDING")))
 (let (($x67284 (= state_3 0)))
 (and $x67284 $x48602 $x48578 $x51717 active_3_L.query (= 2000 due_3_L.query) (or (not active_3_L.cache) (not (<= due_3_L.cache due_3_L.query))) (or (not active_3_T.rtx) (<= due_3_L.query due_3_T.rtx)) (or (not active_3_T.user) (<= due_3_L.query due_3_T.user)) (or (not active_3_T.time_wait) (<= due_3_L.query due_3_T.time_wait)) $x91319 $x63480 $x32982 $x5477 $x5476 $x52814 $x32279 $x206 $x32333 $x91333 $x55414 $x91260 $x91261 $x12747 $x12644 $x55528 $x213 $x55358 $x65500 $x55595 $x55596 $x55389 $x55373 $x25236 $x53084 $x3773 $x3772 $x55550 $x91435 $x72 $x91340 $x9453 $x63791 $x129 $x55446 $x5538 $x5475 $x91324 $x91145 $x12991 $x12557 $x95128 $x95190 $x91369 $x32832 $x5547 $x53239 $x53237 $x32946 $x55445 $x52664 $x53083 $x63088 $x77328 $x53227 $x53226 $x51714 $x53036 $x26840 $x49925 $x55593 $x55594 $x53289 $x52998 $x125365 $x51711 $x91280 $x32991 $x65369))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x50008 (seq.unit (_ bv192 8))))
 (let ((?x50074 (seq.++ ?x50008 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x50074))))
(assert
 (= 1 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x50008 (seq.unit (_ bv192 8))))
 (let ((?x50074 (seq.++ ?x50008 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_1_L.app.resolve_ip ?x50074))))
(assert
 (= 3 choice_2))
(assert
 (= 1000 now_3))
(assert
 (= 26 choice_3))
(assert
 (= 2000 now_4))
(check-sat)

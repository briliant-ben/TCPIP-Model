; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x9924 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x9923 (= due_1_T.user due_0_T.user)))
 (let (($x9920 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x52549 (= due_1_L.cache 60000)))
 (let (($x9919 (= due_1_L.query due_0_L.query)))
 (let (($x43484 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x9918 (= active_1_T.user active_0_T.user)))
 (let (($x25625 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x52548 (not active_1_L.query)))
 (let (($x56660 (= v_1_T.wire_flags 0)))
 (let (($x52547 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x52546 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x52545 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x52544 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x52543 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52542 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x52541 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x32985 (= v_1_T.take 0)))
 (let (($x32984 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x32784 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x63628 (= v_1_T.snd_wnd 8)))
 (let (($x52540 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x52539 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x52538 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x43431 (= v_1_T.local_window 16)))
 (let (($x32785 (= v_1_T.msl_ms 60000)))
 (let (($x32859 (= v_1_T.user_timeout_ms 30000)))
 (let (($x80630 (= v_1_T.retries 0)))
 (let (($x3823 (= v_1_T.rto_ms 1000)))
 (let (($x43426 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x32747 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3858 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x3854 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x3849 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x56653 (= v_1_T.irs (_ bv0 32))))
 (let (($x15814 (= v_1_T.iss (_ bv1000 32))))
 (let (($x9900 (= v_1_L.control "RESOLVED")))
 (let (($x52537 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x52536 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x52535 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x52534 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x52533 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x52532 (not v_1_L.rxudp_require_checksum)))
 (let (($x52531 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x56073 (= v_1_L.ip_checksum 0)))
 (let (($x53127 (= v_1_L.udp_checksum 0)))
 (let (($x43421 (= v_1_L.udp_raw_checksum 0)))
 (let (($x21269 (= v_1_L.ip_length 0)))
 (let (($x45119 (= v_1_L.udp_length 0)))
 (let (($x52530 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x52529 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x52528 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x52527 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x52526 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x52525 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x52524 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x73774 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x9887 (= 0 v_1_L.retry_count)))
 (let ((?x3602 (seq.unit (_ bv0 8))))
 (let ((?x47173 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 (seq.unit (_ bv2 8))))))))
 (let ((?x38321 (seq.unit (_ bv2 8))))
 (let ((?x47174 (seq.++ ?x38321 ?x47173)))
 (let (($x52523 (= v_1_L.peer_mac ?x47174)))
 (let (($x9886 (= 0 state_1)))
 (let (($x38309 (not active_0_T.time_wait)))
 (let (($x52522 (or $x38309 (not (<= due_0_T.time_wait 0)))))
 (let (($x45111 (not active_0_T.user)))
 (let (($x52519 (or $x45111 (not (<= due_0_T.user 0)))))
 (let (($x25596 (not active_0_T.rtx)))
 (let (($x52516 (or $x25596 (not (<= due_0_T.rtx 0)))))
 (let (($x38307 (not active_0_L.cache)))
 (let (($x52513 (or $x38307 (not (<= due_0_L.cache 0)))))
 (let (($x20240 (not active_0_L.query)))
 (let (($x52510 (or $x20240 (not (<= due_0_L.query 0)))))
 (let (($x1019 (= state_0 0)))
 (and $x1019 (>= 0 now_0) $x52510 $x52513 $x52516 $x52519 $x52522 $x9886 $x52523 $x9887 $x73774 v_1_L.checksums_enabled $x52524 $x52525 $x52526 $x52527 $x52528 $x52529 $x52530 $x45119 $x21269 $x43421 $x53127 $x56073 $x52531 $x52532 $x52533 (= v_1_L.rxudp_disposition "none") $x52534 $x52535 $x52536 $x52537 (= v_1_L.echo_disposition "none") $x9900 $x15814 $x56653 $x3849 $x3854 $x3858 $x32747 $x43426 (= v_1_T.tx_flags "S") $x3823 $x80630 v_1_T.active_open $x32859 $x32785 $x43431 $x52538 $x52539 $x52540 $x63628 $x32784 $x32984 $x32985 $x52541 $x52542 $x52543 $x52544 $x52545 $x52546 $x52547 $x56660 (= v_1_T.wire_disposition "none") (= v_1_T.control "CLOSED") (= v_1_ip_pending_owner "none") $x52548 active_1_L.cache $x25625 $x9918 $x43484 $x9919 $x52549 $x9920 $x9923 $x9924)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x47612 (seq.unit (_ bv14 8))))
(let ((?x52396 (seq.++ ?x47612 (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
(let ((?x52388 (seq.unit (_ bv13 8))))
(let ((?x52386 (seq.unit (_ bv12 8))))
(let ((?x52384 (seq.unit (_ bv11 8))))
(let ((?x52382 (seq.unit (_ bv10 8))))
(let ((?x52380 (seq.unit (_ bv9 8))))
(let ((?x52401 (seq.++ ?x52380 (seq.++ ?x52382 (seq.++ ?x52384 (seq.++ ?x52386 (seq.++ ?x52388 ?x52396)))))))
(let ((?x30868 (seq.unit (_ bv8 8))))
(let ((?x52378 (seq.unit (_ bv7 8))))
(let ((?x55813 (seq.unit (_ bv6 8))))
(let ((?x52376 (seq.unit (_ bv5 8))))
(let ((?x45124 (seq.unit (_ bv4 8))))
(let ((?x47616 (seq.++ ?x45124 (seq.++ ?x52376 (seq.++ ?x55813 (seq.++ ?x52378 (seq.++ ?x30868 ?x52401)))))))
(let ((?x52374 (seq.unit (_ bv3 8))))
(let ((?x38321 (seq.unit (_ bv2 8))))
(let ((?x38344 (seq.unit (_ bv1 8))))
(let ((?x3602 (seq.unit (_ bv0 8))))
(let ((?x52408 (seq.++ ?x38344 (seq.++ ?x3602 (seq.++ ?x38344 (seq.++ ?x38321 (seq.++ ?x52374 ?x47616)))))))
(let ((?x38320 (seq.unit (_ bv192 8))))
(let ((?x52413 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x38320 (seq.++ ?x3602 (seq.++ ?x38321 ?x52408)))))))
(let ((?x52418 (seq.++ ?x38321 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 ?x52413)))))))
(let ((?x52420 (seq.++ ?x3602 (seq.++ ?x38321 (seq.++ ?x38320 (seq.++ ?x3602 (seq.++ ?x38321 ?x52418)))))))
(let ((?x52425 (seq.++ ?x38344 (seq.++ ?x38321 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 ?x52420)))))))
(let ((?x52430 (seq.++ ?x30868 (seq.++ ?x3602 (seq.++ ?x55813 (seq.++ ?x45124 (seq.++ ?x3602 ?x52425)))))))
(let ((?x52435 (seq.++ ?x38321 (seq.++ ?x30868 (seq.++ ?x55813 (seq.++ ?x3602 (seq.++ ?x38344 ?x52430)))))))
(let ((?x52440 (seq.++ ?x38321 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 (seq.++ ?x3602 ?x52435)))))))
(let ((?x43448 (seq.unit (_ bv255 8))))
(let ((?x52445 (seq.++ ?x43448 (seq.++ ?x43448 (seq.++ ?x43448 (seq.++ ?x43448 (seq.++ ?x43448 ?x52440)))))))
(let ((?x52446 (seq.++ ?x43448 ?x52445)))
(= input_0_L.net.frame_frame ?x52446))))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x45144 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x51156 (= due_1_T.user due_0_T.user)))
 (let (($x38329 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x43454 (= due_1_L.cache due_0_L.cache)))
 (let (($x40248 (= due_1_L.query 1000)))
 (let (($x84336 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x46840 (= active_1_T.user active_0_T.user)))
 (let (($x38327 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x48580 (= active_1_L.cache active_0_L.cache)))
 (let (($x30825 (= v_1_T.control "CLOSED")))
 (let (($x3517 (= v_1_T.wire_flags 0)))
 (let (($x40247 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x14379 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x125524 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x40307 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x40306 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x40310 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x40309 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x32804 (= v_1_T.take 0)))
 (let (($x53128 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x55358 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x49984 (= v_1_T.snd_wnd 8)))
 (let (($x40308 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x40286 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x97318 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x49985 (= v_1_T.local_window 16)))
 (let (($x52324 (= v_1_T.msl_ms 60000)))
 (let (($x74457 (= v_1_T.user_timeout_ms 30000)))
 (let (($x86241 (= v_1_T.retries 0)))
 (let (($x3563 (= v_1_T.rto_ms 1000)))
 (let (($x32588 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x86239 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3558 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x56028 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x26844 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x56058 (= v_1_T.irs (_ bv0 32))))
 (let (($x3590 (= v_1_T.iss (_ bv1000 32))))
 (let (($x60265 (= v_1_L.control "PENDING")))
 (let (($x40320 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x40318 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x40315 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x40317 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x40316 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x52562 (not v_1_L.rxudp_require_checksum)))
 (let (($x40319 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x3533 (= v_1_L.ip_checksum 0)))
 (let (($x91059 (= v_1_L.udp_checksum 0)))
 (let (($x49901 (= v_1_L.udp_raw_checksum 0)))
 (let (($x8697 (= v_1_L.ip_length 0)))
 (let (($x3568 (= v_1_L.udp_length 0)))
 (let (($x40276 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x40279 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x40278 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x40277 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x40274 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x40273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x40275 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x3536 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x30560 (= 0 v_1_L.retry_count)))
 (let (($x40272 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x96341 (= 0 state_1)))
 (let (($x76059 (not active_0_T.time_wait)))
 (let (($x40271 (or $x76059 (not (<= due_0_T.time_wait 0)))))
 (let (($x80209 (not active_0_T.user)))
 (let (($x40268 (or $x80209 (not (<= due_0_T.user 0)))))
 (let (($x72878 (not active_0_T.rtx)))
 (let (($x40261 (or $x72878 (not (<= due_0_T.rtx 0)))))
 (let (($x77313 (not active_0_L.cache)))
 (let (($x40258 (or $x77313 (not (<= due_0_L.cache 0)))))
 (let (($x68580 (not active_0_L.query)))
 (let (($x40255 (or $x68580 (not (<= due_0_L.query 0)))))
 (let (($x53570 (= state_0 0)))
 (and $x53570 (>= 0 now_0) $x40255 $x40258 $x40261 $x40268 $x40271 $x96341 $x40272 $x30560 $x3536 v_1_L.checksums_enabled $x40275 $x40273 $x40274 $x40277 $x40278 $x40279 $x40276 $x3568 $x8697 $x49901 $x91059 $x3533 $x40319 $x52562 $x40316 (= v_1_L.rxudp_disposition "none") $x40317 $x40315 $x40318 $x40320 (= v_1_L.echo_disposition "none") $x60265 $x3590 $x56058 $x26844 $x56028 $x3558 $x86239 $x32588 (= v_1_T.tx_flags "S") $x3563 $x86241 v_1_T.active_open $x74457 $x52324 $x49985 $x97318 $x40286 $x40308 $x49984 $x55358 $x53128 $x32804 $x40309 $x40310 $x40306 $x40307 $x125524 $x14379 $x40247 $x3517 (= v_1_T.wire_disposition "none") $x30825 (= v_1_ip_pending_owner "none") active_1_L.query $x48580 $x38327 $x46840 $x84336 $x40248 $x43454 $x38329 $x51156 $x45144))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x52491 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x11108 (= due_2_T.user due_1_T.user)))
 (let (($x11107 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x9902 (= due_2_L.cache due_1_L.cache)))
 (let (($x52486 (= due_2_L.query due_1_L.query)))
 (let (($x52485 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x52449 (= active_2_T.user active_1_T.user)))
 (let (($x43473 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x58234 (= active_2_L.cache active_1_L.cache)))
 (let (($x52560 (= active_2_L.query active_1_L.query)))
 (let (($x52559 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x62651 (= v_2_T.control v_1_T.control)))
 (let (($x49921 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x3792 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x9913 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x55878 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x10646 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x10647 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x13047 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x12946 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x11134 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x11133 (= v_2_T.take v_1_T.take)))
 (let (($x5932 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x52573 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x52564 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x52563 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x11173 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x11172 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x11136 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x11135 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x9910 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x53036 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x32760 (= v_2_T.retries v_1_T.retries)))
 (let (($x3789 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x11088 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x11139 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x30834 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x30836 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x52606 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x52605 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x11132 (= v_2_T.irs v_1_T.irs)))
 (let (($x11131 (= v_2_T.iss v_1_T.iss)))
 (let (($x90289 (= v_2_L.control "PENDING")))
 (let (($x57603 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x11181 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x11180 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x11177 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x11176 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x52596 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x52595 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x52496 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x52495 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x52602 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x52601 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x3824 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x3825 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x52988 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x63089 (= v_2_L.packet v_1_L.packet)))
 (let (($x9912 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x56305 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x32758 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x3799 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32860 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x3857 (= v_2_L.payload v_1_L.payload)))
 (let (($x9869 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x9917 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x52610 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x52609 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x10650 (= 0 state_2)))
 (let (($x93999 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x66128 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x62695 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x52290 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x3605 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x60265 (= v_1_L.control "PENDING")))
 (let (($x53072 (= state_1 0)))
 (and $x53072 $x60265 $x3605 $x52290 $x62695 $x66128 $x93999 $x10650 $x52609 $x52610 $x9917 $x9869 $x3857 $x32860 $x3799 $x32758 $x56305 $x9912 $x63089 $x52988 $x3825 $x3824 $x52601 $x52602 $x52495 $x52496 $x52595 $x52596 $x11176 $x11177 $x11180 $x11181 $x57603 $x90289 $x11131 $x11132 $x52605 $x52606 $x30836 $x30834 $x11139 $x11088 $x3789 $x32760 $x53036 $x9910 $x11135 $x11136 $x11172 $x11173 $x52563 $x52564 $x52573 $x5932 $x11133 $x11134 $x12946 $x13047 $x10647 $x10646 $x55878 $x9913 $x3792 $x49921 $x62651 $x52559 $x52560 $x58234 $x43473 $x52449 $x52485 $x52486 $x9902 $x11107 $x11108 $x52491))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x36822 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x36821 (= due_3_T.user due_2_T.user)))
 (let (($x36820 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x36818 (= due_3_L.query due_2_L.query)))
 (let (($x36817 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x36816 (= active_3_T.user active_2_T.user)))
 (let (($x36815 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x32580 (not active_3_L.query)))
 (let (($x36812 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x36811 (= v_3_T.control v_2_T.control)))
 (let (($x36810 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x36809 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x36808 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x36807 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x36806 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x36805 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x36804 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x36803 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x36802 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x36801 (= v_3_T.take v_2_T.take)))
 (let (($x36800 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x36799 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x36798 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x36797 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x36796 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x36795 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x36794 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x36793 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x36792 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x36791 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x36790 (= v_3_T.retries v_2_T.retries)))
 (let (($x36789 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x36788 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x36787 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x36786 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x36785 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x36784 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x36783 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x36782 (= v_3_T.irs v_2_T.irs)))
 (let (($x36781 (= v_3_T.iss v_2_T.iss)))
 (let (($x36780 (= v_3_L.control "RESOLVED")))
 (let (($x36779 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x36778 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x36777 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x36776 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x36775 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x36774 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x36773 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x36772 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x36771 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x36770 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x36769 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x36768 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x36767 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x36766 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x36765 (= v_3_L.packet v_2_L.packet)))
 (let (($x36764 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x36763 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x36762 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x36761 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x36760 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x36759 (= v_3_L.payload v_2_L.payload)))
 (let (($x36758 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x36757 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x36756 (= 0 v_3_L.retry_count)))
 (let ((?x52540 (seq.unit (_ bv0 8))))
 (let ((?x47214 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.unit (_ bv2 8))))))))
 (let ((?x63628 (seq.unit (_ bv2 8))))
 (let ((?x47213 (seq.++ ?x63628 ?x47214)))
 (let (($x40071 (= v_3_L.peer_mac ?x47213)))
 (let (($x36754 (= 0 state_3)))
 (let (($x52313 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 10)))))
 (let (($x3601 (or (not active_2_T.user) (not (<= due_2_T.user 10)))))
 (let (($x40265 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 10)))))
 (let (($x1671 (or (not active_2_L.cache) (not (<= due_2_L.cache 10)))))
 (let (($x74902 (or (not active_2_L.query) (not (<= due_2_L.query 10)))))
 (let ((?x36723 (seq.len v_2_L.pending_packet)))
 (let (($x36733 (= 0 ?x36723)))
 (let (($x90289 (= v_2_L.control "PENDING")))
 (let (($x14400 (= state_2 0)))
 (and $x14400 $x90289 $x36733 $x74902 $x1671 $x40265 $x3601 $x52313 $x36754 $x40071 $x36756 $x36757 $x36758 $x36759 $x36760 $x36761 $x36762 $x36763 $x36764 $x36765 $x36766 $x36767 $x36768 $x36769 $x36770 $x36771 $x36772 $x36773 $x36774 $x36775 $x36776 $x36777 $x36778 $x36779 $x36780 $x36781 $x36782 $x36783 $x36784 $x36785 $x36786 $x36787 $x36788 $x36789 $x36790 $x36791 $x36792 $x36793 $x36794 $x36795 $x36796 $x36797 $x36798 $x36799 $x36800 $x36801 $x36802 $x36803 $x36804 $x36805 $x36806 $x36807 $x36808 $x36809 $x36810 $x36811 $x36812 $x32580 active_3_L.cache $x36815 $x36816 $x36817 $x36818 (= due_3_L.cache (+ 10 v_2_L.cache_ttl_ms)) $x36820 $x36821 $x36822))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x38270 (seq.unit (_ bv192 8))))
 (let ((?x89566 (seq.++ ?x38270 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x89566))))
(assert
 (= 12 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x38270 (seq.unit (_ bv192 8))))
 (let ((?x88541 (seq.++ ?x38270 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x52540 (seq.unit (_ bv0 8))))
 (let ((?x71772 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 ?x88541)))))))
 (let ((?x63628 (seq.unit (_ bv2 8))))
 (let ((?x70015 (seq.++ ?x38270 (seq.++ ?x52540 (seq.++ ?x63628 (seq.++ ?x63628 (seq.++ ?x52540 ?x71772)))))))
 (let ((?x70907 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x63628 ?x70015)))))))
 (let ((?x52474 (seq.unit (_ bv1 8))))
 (let ((?x12765 (seq.unit (_ bv4 8))))
 (let ((?x91301 (seq.unit (_ bv6 8))))
 (let ((?x82791 (seq.++ ?x91301 (seq.++ ?x12765 (seq.++ ?x52540 (seq.++ ?x52474 (seq.++ ?x63628 ?x70907)))))))
 (let ((?x52479 (seq.unit (_ bv8 8))))
 (let ((?x85670 (seq.++ ?x91301 (seq.++ ?x52540 (seq.++ ?x52474 (seq.++ ?x52479 (seq.++ ?x52540 ?x82791)))))))
 (let ((?x67000 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x63628 (seq.++ ?x52479 ?x85670)))))))
 (let ((?x56661 (seq.unit (_ bv255 8))))
 (let ((?x90106 (seq.++ ?x56661 (seq.++ ?x56661 (seq.++ ?x56661 (seq.++ ?x63628 (seq.++ ?x52540 ?x67000)))))))
 (let ((?x89081 (seq.++ ?x56661 (seq.++ ?x56661 (seq.++ ?x56661 ?x90106)))))
 (= input_1_L.net.frame_frame ?x89081)))))))))))))))))))
(assert
 (= 30 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x38270 (seq.unit (_ bv192 8))))
(let ((?x13084 (seq.++ ?x38270 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x52474 (seq.unit (_ bv1 8))))
(let ((?x52540 (seq.unit (_ bv0 8))))
(let ((?x69307 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52474 ?x13084)))))))
(let ((?x63628 (seq.unit (_ bv2 8))))
(let ((?x65619 (seq.++ ?x38270 (seq.++ ?x52540 (seq.++ ?x63628 (seq.++ ?x63628 (seq.++ ?x63628 ?x69307)))))))
(let ((?x81500 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x63628 ?x65619)))))))
(let ((?x12765 (seq.unit (_ bv4 8))))
(let ((?x91301 (seq.unit (_ bv6 8))))
(let ((?x89834 (seq.++ ?x91301 (seq.++ ?x12765 (seq.++ ?x52540 (seq.++ ?x63628 (seq.++ ?x63628 ?x81500)))))))
(let ((?x52479 (seq.unit (_ bv8 8))))
(let ((?x88297 (seq.++ ?x91301 (seq.++ ?x52540 (seq.++ ?x52474 (seq.++ ?x52479 (seq.++ ?x52540 ?x89834)))))))
(let ((?x84368 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x63628 (seq.++ ?x52479 ?x88297)))))))
(let ((?x83250 (seq.++ ?x52540 (seq.++ ?x52540 (seq.++ ?x52474 (seq.++ ?x63628 (seq.++ ?x52540 ?x84368)))))))
(let ((?x83983 (seq.++ ?x63628 (seq.++ ?x52540 (seq.++ ?x52540 ?x83250)))))
(= input_2_L.net.frame_frame ?x83983))))))))))))))))))
(check-sat)

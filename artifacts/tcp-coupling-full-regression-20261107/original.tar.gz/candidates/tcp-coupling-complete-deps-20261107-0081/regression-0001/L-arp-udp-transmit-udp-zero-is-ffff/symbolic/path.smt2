; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x29967 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x57978 (= due_1_T.user due_0_T.user)))
 (let (($x23312 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x23672 (= due_1_L.cache due_0_L.cache)))
 (let (($x9466 (= due_1_L.query 1000)))
 (let (($x23668 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x1402 (= active_1_T.user active_0_T.user)))
 (let (($x3145 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x30580 (= active_1_L.cache active_0_L.cache)))
 (let (($x23532 (= v_1_ip_pending_owner "UDP")))
 (let (($x101362 (= v_1_T.control "CLOSED")))
 (let (($x45862 (= v_1_T.wire_flags 0)))
 (let (($x9467 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x5768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x25269 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x58045 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x58044 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x28832 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x72800 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x7146 (= v_1_T.take 0)))
 (let (($x102825 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x7185 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x44085 (= v_1_T.snd_wnd 8)))
 (let (($x58766 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x18077 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x98101 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x104047 (= v_1_T.local_window 16)))
 (let (($x51701 (= v_1_T.msl_ms 60000)))
 (let (($x103146 (= v_1_T.user_timeout_ms 30000)))
 (let (($x7987 (= v_1_T.retries 0)))
 (let (($x75112 (= v_1_T.rto_ms 1000)))
 (let (($x96753 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x7339 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x102883 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x45824 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x45825 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x45826 (= v_1_T.irs (_ bv0 32))))
 (let (($x45827 (= v_1_T.iss (_ bv1000 32))))
 (let (($x53279 (= v_1_L.control "PENDING")))
 (let (($x58020 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x58019 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x58021 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x102102 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x96745 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x89305 (not v_1_L.rxudp_require_checksum)))
 (let ((?x98066 (seq.unit (_ bv255 8))))
 (let ((?x46121 (seq.unit (_ bv10 8))))
 (let ((?x97958 (seq.++ ?x46121 (seq.++ ?x98066 (seq.++ ?x98066 (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv5 8))))))))
 (let ((?x57285 (seq.unit (_ bv0 8))))
 (let ((?x18212 (seq.unit (_ bv144 8))))
 (let ((?x98607 (seq.unit (_ bv31 8))))
 (let ((?x58005 (seq.unit (_ bv64 8))))
 (let ((?x24898 (seq.unit (_ bv156 8))))
 (let ((?x1412 (seq.++ ?x24898 (seq.++ ?x58005 (seq.++ ?x98607 (seq.++ ?x18212 (seq.++ ?x57285 ?x97958)))))))
 (let ((?x45958 (seq.unit (_ bv2 8))))
 (let ((?x45957 (seq.unit (_ bv192 8))))
 (let ((?x98125 (seq.unit (_ bv1 8))))
 (let ((?x52523 (seq.++ ?x98125 (seq.++ ?x45957 (seq.++ ?x57285 (seq.++ ?x45958 (seq.++ ?x45958 ?x1412)))))))
 (let ((?x57969 (seq.unit (_ bv203 8))))
 (let ((?x57501 (seq.unit (_ bv182 8))))
 (let ((?x8036 (seq.++ ?x57501 (seq.++ ?x57969 (seq.++ ?x45957 (seq.++ ?x57285 (seq.++ ?x45958 ?x52523)))))))
 (let ((?x46148 (seq.unit (_ bv17 8))))
 (let ((?x57771 (seq.++ ?x57285 (seq.++ ?x58005 (seq.++ ?x57285 (seq.++ ?x58005 (seq.++ ?x46148 ?x8036)))))))
 (let ((?x52539 (seq.unit (_ bv30 8))))
 (let ((?x5740 (seq.unit (_ bv69 8))))
 (let ((?x10492 (seq.++ ?x5740 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x52539 (seq.++ ?x57285 ?x57771)))))))
 (let (($x28833 (= v_1_L.pending_packet ?x10492)))
 (let (($x30567 (= v_1_L.ip_checksum 46795)))
 (let (($x1403 (= v_1_L.udp_checksum 65535)))
 (let (($x45901 (= v_1_L.udp_raw_checksum 0)))
 (let (($x1496 (= v_1_L.ip_length 30)))
 (let (($x57331 (= v_1_L.udp_length 10)))
 (let (($x88747 (= v_1_L.packet ?x10492)))
 (let ((?x46168 (seq.++ ?x45958 (seq.++ ?x98125 (seq.++ ?x45957 (seq.++ ?x57285 (seq.++ ?x45958 ?x45958)))))))
 (let ((?x46171 (seq.++ ?x45957 (seq.++ ?x57285 ?x46168))))
 (let ((?x1492 (seq.++ ?x57285 (seq.++ ?x58005 (seq.++ ?x46148 (seq.++ ?x57501 (seq.++ ?x57969 ?x46171)))))))
 (let ((?x57416 (seq.++ ?x57285 (seq.++ ?x52539 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x58005 ?x1492)))))))
 (let (($x91344 (= v_1_L.ip_wire (seq.++ ?x5740 (seq.++ ?x57285 ?x57416)))))
 (let ((?x103019 (seq.++ ?x57285 (seq.++ ?x58005 (seq.++ ?x46148 (seq.++ ?x57285 (seq.++ ?x57285 ?x46171)))))))
 (let ((?x7297 (seq.++ ?x57285 (seq.++ ?x52539 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x58005 ?x103019)))))))
 (let (($x96561 (= v_1_L.ip_zero (seq.++ ?x5740 (seq.++ ?x57285 ?x7297)))))
 (let (($x57964 (= v_1_L.udp_wire ?x1412)))
 (let ((?x100740 (seq.++ ?x45958 (seq.++ ?x45958 (seq.++ ?x57285 (seq.++ ?x46148 (seq.++ ?x57285 ?x46121)))))))
 (let ((?x100747 (seq.++ ?x57285 (seq.++ ?x45958 (seq.++ ?x98125 (seq.++ ?x45957 (seq.++ ?x57285 ?x100740)))))))
 (let (($x100749 (= v_1_L.pseudoheader (seq.++ ?x45957 ?x100747))))
 (let ((?x46156 (seq.++ ?x46121 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x45957 (seq.unit (_ bv5 8))))))))
 (let ((?x46161 (seq.++ ?x24898 (seq.++ ?x58005 (seq.++ ?x98607 (seq.++ ?x18212 (seq.++ ?x57285 ?x46156)))))))
 (let (($x46162 (= v_1_L.udp_zero ?x46161)))
 (let ((?x57008 (seq.++ ?x45957 (seq.unit (_ bv5 8)))))
 (let (($x69088 (= v_1_L.payload ?x57008)))
 (let (($x46017 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x57753 (= 0 v_1_L.retry_count)))
 (let (($x46078 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x9482 (= 0 state_1)))
 (let (($x32900 (not active_0_T.time_wait)))
 (let (($x46077 (or $x32900 (not (<= due_0_T.time_wait 0)))))
 (let (($x97857 (not active_0_T.user)))
 (let (($x46074 (or $x97857 (not (<= due_0_T.user 0)))))
 (let (($x10450 (not active_0_T.rtx)))
 (let (($x46071 (or $x10450 (not (<= due_0_T.rtx 0)))))
 (let (($x58064 (not active_0_L.cache)))
 (let (($x45822 (or $x58064 (not (<= due_0_L.cache 0)))))
 (let (($x58060 (not active_0_L.query)))
 (let (($x45819 (or $x58060 (not (<= due_0_L.query 0)))))
 (let (($x40273 (= state_0 0)))
 (and $x40273 (>= 0 now_0) $x45819 $x45822 $x46071 $x46074 $x46077 $x9482 $x46078 $x57753 $x46017 v_1_L.checksums_enabled $x69088 $x46162 $x100749 $x57964 $x96561 $x91344 $x88747 $x57331 $x1496 $x45901 $x1403 $x30567 $x28833 $x89305 $x96745 (= v_1_L.rxudp_disposition "none") $x102102 $x58021 $x58019 $x58020 (= v_1_L.echo_disposition "none") $x53279 $x45827 $x45826 $x45825 $x45824 $x102883 $x7339 $x96753 (= v_1_T.tx_flags "S") $x75112 $x7987 v_1_T.active_open $x103146 $x51701 $x104047 $x98101 $x18077 $x58766 $x44085 $x7185 $x102825 $x7146 $x72800 $x28832 $x58044 $x58045 $x25269 $x5768 $x9467 $x45862 (= v_1_T.wire_disposition "none") $x101362 $x23532 active_1_L.query $x30580 $x3145 $x1402 $x23668 $x9466 $x23672 $x23312 $x57978 $x29967)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x41344 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x14365 (= due_2_T.user due_1_T.user)))
 (let (($x93951 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x43446 (= due_2_L.query due_1_L.query)))
 (let (($x52414 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x66936 (= active_2_T.user active_1_T.user)))
 (let (($x32295 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x23702 (not active_2_L.query)))
 (let (($x88797 (= v_2_ip_pending_owner "none")))
 (let (($x40331 (= v_2_T.control v_1_T.control)))
 (let (($x41135 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x14379 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x52517 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x62972 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x52598 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x52597 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x53128 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x97318 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x11127 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x88798 (= v_2_T.take v_1_T.take)))
 (let (($x83036 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x86047 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x47617 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x6700 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x41180 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x70372 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x32547 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x41246 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x41293 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x67766 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x41460 (= v_2_T.retries v_1_T.retries)))
 (let (($x6612 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x41144 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x6637 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x41190 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x41307 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x41191 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x41152 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x41098 (= v_2_T.irs v_1_T.irs)))
 (let (($x88319 (= v_2_T.iss v_1_T.iss)))
 (let (($x65841 (= v_2_L.control "RESOLVED")))
 (let (($x41248 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x41239 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x41148 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x41147 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x38327 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x52537 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x40288 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x30585 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x23338 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x6560 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x6634 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x74753 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x41112 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x56655 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x51642 (= v_2_L.packet v_1_L.packet)))
 (let (($x3797 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x25495 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x38306 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x71921 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x13408 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x41130 (= v_2_L.payload v_1_L.payload)))
 (let (($x52661 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x48612 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x14367 (= 0 v_2_L.retry_count)))
 (let ((?x57285 (seq.unit (_ bv0 8))))
 (let ((?x25422 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.unit (_ bv2 8))))))))
 (let ((?x45958 (seq.unit (_ bv2 8))))
 (let ((?x25423 (seq.++ ?x45958 ?x25422)))
 (let (($x23337 (= v_2_L.peer_mac ?x25423)))
 (let (($x32744 (= 0 state_2)))
 (let (($x23592 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x3867 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x41306 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x23497 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x42509 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x52568 (seq.len v_1_L.pending_packet)))
 (let (($x57031 (<= 28 ?x52568)))
 (let (($x53279 (= v_1_L.control "PENDING")))
 (let (($x78602 (= state_1 0)))
 (and $x78602 $x53279 $x57031 $x42509 $x23497 $x41306 $x3867 $x23592 $x32744 $x23337 $x14367 $x48612 $x52661 $x41130 $x13408 $x71921 $x38306 $x25495 $x3797 $x51642 $x56655 $x41112 $x74753 $x6634 $x6560 $x23338 $x30585 $x40288 $x52537 $x38327 $x41147 $x41148 $x41239 $x41248 $x65841 $x88319 $x41098 $x41152 $x41191 $x41307 $x41190 $x6637 $x41144 $x6612 $x41460 $x67766 $x41293 $x41246 $x32547 $x70372 $x41180 $x6700 $x47617 $x86047 $x83036 $x88798 $x11127 $x97318 $x53128 $x52597 $x52598 $x62972 $x52517 $x14379 $x41135 $x40331 $x88797 $x23702 active_2_L.cache $x32295 $x66936 $x52414 $x43446 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x93951 $x14365 $x41344))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x45957 (seq.unit (_ bv192 8))))
 (let ((?x57008 (seq.++ ?x45957 (seq.unit (_ bv5 8)))))
 (= input_0_L.app.send_data ?x57008))))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x45957 (seq.unit (_ bv192 8))))
(let ((?x46010 (seq.++ ?x45957 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x98125 (seq.unit (_ bv1 8))))
(let ((?x57285 (seq.unit (_ bv0 8))))
(let ((?x104165 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x98125 ?x46010)))))))
(let ((?x45958 (seq.unit (_ bv2 8))))
(let ((?x23482 (seq.++ ?x45957 (seq.++ ?x57285 (seq.++ ?x45958 (seq.++ ?x45958 (seq.++ ?x45958 ?x104165)))))))
(let ((?x103116 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x45958 ?x23482)))))))
(let ((?x24986 (seq.unit (_ bv4 8))))
(let ((?x45990 (seq.unit (_ bv6 8))))
(let ((?x8037 (seq.++ ?x45990 (seq.++ ?x24986 (seq.++ ?x57285 (seq.++ ?x45958 (seq.++ ?x45958 ?x103116)))))))
(let ((?x98071 (seq.unit (_ bv8 8))))
(let ((?x66579 (seq.++ ?x45990 (seq.++ ?x57285 (seq.++ ?x98125 (seq.++ ?x98071 (seq.++ ?x57285 ?x8037)))))))
(let ((?x1427 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x45958 (seq.++ ?x98071 ?x66579)))))))
(let ((?x4770 (seq.++ ?x57285 (seq.++ ?x57285 (seq.++ ?x98125 (seq.++ ?x45958 (seq.++ ?x57285 ?x1427)))))))
(let ((?x58052 (seq.++ ?x45958 (seq.++ ?x57285 (seq.++ ?x57285 ?x4770)))))
(= input_1_L.net.frame_frame ?x58052))))))))))))))))))
(check-sat)

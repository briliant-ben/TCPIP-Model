; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x87291 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x52876 (= due_1_T.user due_0_T.user)))
 (let (($x52875 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x63187 (= due_1_L.cache due_0_L.cache)))
 (let (($x96774 (= due_1_L.query 1000)))
 (let (($x41163 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x75066 (= active_1_T.user active_0_T.user)))
 (let (($x63659 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x31927 (= active_1_L.cache active_0_L.cache)))
 (let (($x74475 (= v_1_ip_pending_owner "UDP")))
 (let (($x30430 (= v_1_T.control "CLOSED")))
 (let (($x59206 (= v_1_T.wire_flags 0)))
 (let (($x96773 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x96772 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x96771 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x96770 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x96769 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x96768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x96767 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x47196 (= v_1_T.take 0)))
 (let (($x27157 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x58075 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x34087 (= v_1_T.snd_wnd 8)))
 (let (($x96766 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x96765 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x96764 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3117 (= v_1_T.local_window 16)))
 (let (($x3861 (= v_1_T.msl_ms 60000)))
 (let (($x41348 (= v_1_T.user_timeout_ms 30000)))
 (let (($x40287 (= v_1_T.retries 0)))
 (let (($x56664 (= v_1_T.rto_ms 1000)))
 (let (($x9890 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x59455 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x45476 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x59106 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x58911 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x21460 (= v_1_T.irs (_ bv0 32))))
 (let (($x58912 (= v_1_T.iss (_ bv1000 32))))
 (let (($x35781 (= v_1_L.control "PENDING")))
 (let (($x96763 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x96762 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x96761 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x96760 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x96759 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x30260 (not v_1_L.rxudp_require_checksum)))
 (let ((?x94195 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2283 (seq.unit (_ bv0 8))))
 (let ((?x94196 (seq.++ ?x2283 ?x94195)))
 (let ((?x73487 (seq.unit (_ bv192 8))))
 (let ((?x55816 (seq.unit (_ bv13 8))))
 (let ((?x94313 (seq.++ ?x2283 (seq.++ ?x55816 (seq.++ ?x73487 (seq.++ (seq.unit (_ bv119 8)) ?x94196))))))
 (let ((?x60694 (seq.unit (_ bv144 8))))
 (let ((?x12733 (seq.unit (_ bv31 8))))
 (let ((?x224 (seq.unit (_ bv64 8))))
 (let ((?x12529 (seq.unit (_ bv156 8))))
 (let ((?x94317 (seq.++ ?x12529 (seq.++ ?x224 (seq.++ ?x12733 (seq.++ ?x60694 ?x94313))))))
 (let ((?x85624 (seq.unit (_ bv2 8))))
 (let ((?x103126 (seq.unit (_ bv1 8))))
 (let ((?x96736 (seq.++ ?x103126 (seq.++ ?x73487 (seq.++ ?x2283 (seq.++ ?x85624 (seq.++ ?x85624 ?x94317)))))))
 (let ((?x96632 (seq.unit (_ bv200 8))))
 (let ((?x96630 (seq.unit (_ bv182 8))))
 (let ((?x96741 (seq.++ ?x96630 (seq.++ ?x96632 (seq.++ ?x73487 (seq.++ ?x2283 (seq.++ ?x85624 ?x96736)))))))
 (let ((?x35727 (seq.unit (_ bv17 8))))
 (let ((?x96746 (seq.++ ?x2283 (seq.++ ?x224 (seq.++ ?x2283 (seq.++ ?x224 (seq.++ ?x35727 ?x96741)))))))
 (let ((?x94321 (seq.unit (_ bv33 8))))
 (let ((?x10558 (seq.unit (_ bv69 8))))
 (let ((?x96751 (seq.++ ?x10558 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x94321 (seq.++ ?x2283 ?x96746)))))))
 (let (($x96758 (= v_1_L.pending_packet ?x96751)))
 (let (($x96757 (= v_1_L.ip_checksum 46792)))
 (let (($x96756 (= v_1_L.udp_checksum 49271)))
 (let (($x96755 (= v_1_L.udp_raw_checksum 49271)))
 (let (($x96754 (= v_1_L.ip_length 33)))
 (let (($x96753 (= v_1_L.udp_length 13)))
 (let (($x96752 (= v_1_L.packet ?x96751)))
 (let ((?x3499 (seq.++ ?x85624 (seq.++ ?x103126 (seq.++ ?x73487 (seq.++ ?x2283 (seq.++ ?x85624 ?x85624)))))))
 (let ((?x3335 (seq.++ ?x73487 (seq.++ ?x2283 ?x3499))))
 (let ((?x96688 (seq.++ ?x2283 (seq.++ ?x224 (seq.++ ?x35727 (seq.++ ?x96630 (seq.++ ?x96632 ?x3335)))))))
 (let ((?x96693 (seq.++ ?x2283 (seq.++ ?x94321 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x224 ?x96688)))))))
 (let (($x96696 (= v_1_L.ip_wire (seq.++ ?x10558 (seq.++ ?x2283 ?x96693)))))
 (let ((?x94390 (seq.++ ?x2283 (seq.++ ?x224 (seq.++ ?x35727 (seq.++ ?x2283 (seq.++ ?x2283 ?x3335)))))))
 (let ((?x94395 (seq.++ ?x2283 (seq.++ ?x94321 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x224 ?x94390)))))))
 (let (($x94398 (= v_1_L.ip_zero (seq.++ ?x10558 (seq.++ ?x2283 ?x94395)))))
 (let (($x94318 (= v_1_L.udp_wire ?x94317)))
 (let ((?x3427 (seq.++ ?x85624 (seq.++ ?x85624 (seq.++ ?x2283 (seq.++ ?x35727 (seq.++ ?x2283 ?x55816)))))))
 (let ((?x45048 (seq.++ ?x2283 (seq.++ ?x85624 (seq.++ ?x103126 (seq.++ ?x73487 (seq.++ ?x2283 ?x3427)))))))
 (let (($x64583 (= v_1_L.pseudoheader (seq.++ ?x73487 ?x45048))))
 (let ((?x3370 (seq.++ ?x60694 (seq.++ ?x2283 (seq.++ ?x55816 (seq.++ ?x2283 (seq.++ ?x2283 ?x94196)))))))
 (let (($x3379 (= v_1_L.udp_zero (seq.++ ?x12529 (seq.++ ?x224 (seq.++ ?x12733 ?x3370))))))
 (let (($x6540 (= v_1_L.payload ?x94196)))
 (let (($x59038 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x35769 (= 0 v_1_L.retry_count)))
 (let (($x3381 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x35768 (= 0 state_1)))
 (let (($x35665 (not active_0_T.time_wait)))
 (let (($x56837 (or $x35665 (not (<= due_0_T.time_wait 0)))))
 (let (($x26799 (not active_0_T.user)))
 (let (($x32998 (or $x26799 (not (<= due_0_T.user 0)))))
 (let (($x48315 (not active_0_T.rtx)))
 (let (($x84802 (or $x48315 (not (<= due_0_T.rtx 0)))))
 (let (($x82385 (not active_0_L.cache)))
 (let (($x5534 (or $x82385 (not (<= due_0_L.cache 0)))))
 (let (($x27210 (not active_0_L.query)))
 (let (($x53149 (or $x27210 (not (<= due_0_L.query 0)))))
 (let (($x56163 (= state_0 0)))
 (and $x56163 (>= 0 now_0) $x53149 $x5534 $x84802 $x32998 $x56837 $x35768 $x3381 $x35769 $x59038 v_1_L.checksums_enabled $x6540 $x3379 $x64583 $x94318 $x94398 $x96696 $x96752 $x96753 $x96754 $x96755 $x96756 $x96757 $x96758 $x30260 $x96759 (= v_1_L.rxudp_disposition "none") $x96760 $x96761 $x96762 $x96763 (= v_1_L.echo_disposition "none") $x35781 $x58912 $x21460 $x58911 $x59106 $x45476 $x59455 $x9890 (= v_1_T.tx_flags "S") $x56664 $x40287 v_1_T.active_open $x41348 $x3861 $x3117 $x96764 $x96765 $x96766 $x34087 $x58075 $x27157 $x47196 $x96767 $x96768 $x96769 $x96770 $x96771 $x96772 $x96773 $x59206 (= v_1_T.wire_disposition "none") $x30430 $x74475 active_1_L.query $x31927 $x63659 $x75066 $x41163 $x96774 $x63187 $x52875 $x52876 $x87291))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x30119 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x30118 (= due_2_T.user due_1_T.user)))
 (let (($x30117 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x30115 (= due_2_L.query due_1_L.query)))
 (let (($x30114 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x30113 (= active_2_T.user active_1_T.user)))
 (let (($x30112 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x96485 (not active_2_L.query)))
 (let (($x30109 (= v_2_ip_pending_owner "none")))
 (let (($x30108 (= v_2_T.control v_1_T.control)))
 (let (($x30107 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x30106 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x30105 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x30104 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x30103 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x30102 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x30101 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x30100 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x30099 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x30098 (= v_2_T.take v_1_T.take)))
 (let (($x30097 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x30096 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x30095 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x30094 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x30093 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x30092 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x30091 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x30090 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x30089 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x30088 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x29996 (= v_2_T.retries v_1_T.retries)))
 (let (($x29995 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x29994 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x29993 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x29992 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x29991 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x29990 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x29989 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x29988 (= v_2_T.irs v_1_T.irs)))
 (let (($x29987 (= v_2_T.iss v_1_T.iss)))
 (let (($x29986 (= v_2_L.control "RESOLVED")))
 (let (($x29985 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x29984 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x29983 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x29982 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x29981 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x29980 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x29979 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x29978 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x96484 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x29974 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x29973 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x29972 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x29971 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x29970 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x29969 (= v_2_L.packet v_1_L.packet)))
 (let (($x29968 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x29967 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x29966 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x29965 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x29964 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x29963 (= v_2_L.payload v_1_L.payload)))
 (let (($x29962 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x29961 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x29826 (= 0 v_2_L.retry_count)))
 (let ((?x2283 (seq.unit (_ bv0 8))))
 (let ((?x10552 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.unit (_ bv2 8))))))))
 (let ((?x85624 (seq.unit (_ bv2 8))))
 (let ((?x10516 (seq.++ ?x85624 ?x10552)))
 (let (($x96483 (= v_2_L.peer_mac ?x10516)))
 (let (($x29959 (= 0 state_2)))
 (let (($x96482 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x96478 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x96474 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x96470 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x96613 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x29907 (seq.len v_1_L.pending_packet)))
 (let (($x29908 (<= 28 ?x29907)))
 (let (($x35781 (= v_1_L.control "PENDING")))
 (let (($x47807 (= state_1 0)))
 (and $x47807 $x35781 $x29908 $x96613 $x96470 $x96474 $x96478 $x96482 $x29959 $x96483 $x29826 $x29961 $x29962 $x29963 $x29964 $x29965 $x29966 $x29967 $x29968 $x29969 $x29970 $x29971 $x29972 $x29973 $x29974 $x96484 $x29978 $x29979 $x29980 $x29981 $x29982 $x29983 $x29984 $x29985 $x29986 $x29987 $x29988 $x29989 $x29990 $x29991 $x29992 $x29993 $x29994 $x29995 $x29996 $x30088 $x30089 $x30090 $x30091 $x30092 $x30093 $x30094 $x30095 $x30096 $x30097 $x30098 $x30099 $x30100 $x30101 $x30102 $x30103 $x30104 $x30105 $x30106 $x30107 $x30108 $x30109 $x96485 active_2_L.cache $x30112 $x30113 $x30114 $x30115 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x30117 $x30118 $x30119))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x94195 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2283 (seq.unit (_ bv0 8))))
 (let ((?x94196 (seq.++ ?x2283 ?x94195)))
 (= input_0_L.app.send_data ?x94196)))))
(assert
 (= 27 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x73487 (seq.unit (_ bv192 8))))
(let ((?x2333 (seq.++ ?x73487 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x2283 (seq.unit (_ bv0 8))))
(let ((?x94201 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 ?x2333)))))))
(let ((?x85624 (seq.unit (_ bv2 8))))
(let ((?x94204 (seq.++ ?x73487 (seq.++ ?x2283 (seq.++ ?x85624 (seq.++ ?x85624 (seq.++ ?x2283 ?x94201)))))))
(let ((?x94209 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x85624 ?x94204)))))))
(let ((?x103126 (seq.unit (_ bv1 8))))
(let ((?x34666 (seq.unit (_ bv4 8))))
(let ((?x38360 (seq.unit (_ bv6 8))))
(let ((?x94214 (seq.++ ?x38360 (seq.++ ?x34666 (seq.++ ?x2283 (seq.++ ?x103126 (seq.++ ?x85624 ?x94209)))))))
(let ((?x2315 (seq.unit (_ bv8 8))))
(let ((?x94219 (seq.++ ?x38360 (seq.++ ?x2283 (seq.++ ?x103126 (seq.++ ?x2315 (seq.++ ?x2283 ?x94214)))))))
(let ((?x94224 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x2283 (seq.++ ?x85624 (seq.++ ?x2315 ?x94219)))))))
(let ((?x2310 (seq.unit (_ bv255 8))))
(let ((?x94229 (seq.++ ?x2310 (seq.++ ?x2310 (seq.++ ?x2310 (seq.++ ?x85624 (seq.++ ?x2283 ?x94224)))))))
(let ((?x94232 (seq.++ ?x2310 (seq.++ ?x2310 (seq.++ ?x2310 ?x94229)))))
(= input_1_L.net.frame_frame ?x94232)))))))))))))))))))
(check-sat)

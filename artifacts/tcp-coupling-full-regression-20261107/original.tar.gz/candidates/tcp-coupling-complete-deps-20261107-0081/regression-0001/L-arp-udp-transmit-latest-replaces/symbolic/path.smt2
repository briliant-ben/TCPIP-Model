; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x98688 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x52312 (= due_1_T.user due_0_T.user)))
 (let (($x36812 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x52321 (= due_1_L.cache due_0_L.cache)))
 (let (($x79723 (= due_1_L.query 1000)))
 (let (($x52624 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x3506 (= active_1_T.user active_0_T.user)))
 (let (($x89566 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x74222 (= active_1_L.cache active_0_L.cache)))
 (let (($x97606 (= v_1_ip_pending_owner "UDP")))
 (let (($x50323 (= v_1_T.control "CLOSED")))
 (let (($x50194 (= v_1_T.wire_flags 0)))
 (let (($x41118 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x77633 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x53011 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x87056 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x74940 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x6685 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x6684 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3170 (= v_1_T.take 0)))
 (let (($x3167 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3168 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x3171 (= v_1_T.snd_wnd 8)))
 (let (($x41322 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x41321 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x76179 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3175 (= v_1_T.local_window 16)))
 (let (($x3176 (= v_1_T.msl_ms 60000)))
 (let (($x3177 (= v_1_T.user_timeout_ms 30000)))
 (let (($x3178 (= v_1_T.retries 0)))
 (let (($x32780 (= v_1_T.rto_ms 1000)))
 (let (($x47700 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x47697 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x47698 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x47701 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x47702 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x47703 (= v_1_T.irs (_ bv0 32))))
 (let (($x47704 (= v_1_T.iss (_ bv1000 32))))
 (let (($x30748 (= v_1_L.control "PENDING")))
 (let (($x69370 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x84336 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x41105 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x33844 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x89822 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x12690 (not v_1_L.rxudp_require_checksum)))
 (let ((?x5525 (seq.unit (_ bv9 8))))
 (let ((?x47798 (seq.++ ?x5525 (seq.++ (seq.unit (_ bv95 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv97 8)))))))
 (let ((?x52275 (seq.unit (_ bv0 8))))
 (let ((?x41229 (seq.unit (_ bv144 8))))
 (let ((?x41225 (seq.unit (_ bv31 8))))
 (let ((?x3273 (seq.unit (_ bv64 8))))
 (let ((?x41266 (seq.unit (_ bv156 8))))
 (let ((?x47801 (seq.++ ?x41266 (seq.++ ?x3273 (seq.++ ?x41225 (seq.++ ?x41229 (seq.++ ?x52275 ?x47798)))))))
 (let ((?x25547 (seq.unit (_ bv2 8))))
 (let ((?x52410 (seq.unit (_ bv192 8))))
 (let ((?x35653 (seq.unit (_ bv1 8))))
 (let ((?x41428 (seq.++ ?x35653 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x25547 ?x47801)))))))
 (let ((?x6573 (seq.unit (_ bv204 8))))
 (let ((?x3529 (seq.unit (_ bv182 8))))
 (let ((?x73964 (seq.++ ?x3529 (seq.++ ?x6573 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 ?x41428)))))))
 (let ((?x11095 (seq.unit (_ bv17 8))))
 (let ((?x63592 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x11095 ?x73964)))))))
 (let ((?x9397 (seq.unit (_ bv29 8))))
 (let ((?x70330 (seq.unit (_ bv69 8))))
 (let ((?x41436 (seq.++ ?x70330 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x9397 (seq.++ ?x52275 ?x63592)))))))
 (let (($x60729 (= v_1_L.pending_packet ?x41436)))
 (let (($x41397 (= v_1_L.ip_checksum 46796)))
 (let (($x52504 (= v_1_L.udp_checksum 24327)))
 (let (($x12641 (= v_1_L.udp_raw_checksum 24327)))
 (let (($x11100 (= v_1_L.ip_length 29)))
 (let (($x41174 (= v_1_L.udp_length 9)))
 (let (($x3817 (= v_1_L.packet ?x41436)))
 (let ((?x62576 (seq.++ ?x25547 (seq.++ ?x35653 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 ?x25547)))))))
 (let ((?x51697 (seq.++ ?x52410 (seq.++ ?x52275 ?x62576))))
 (let ((?x60380 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x11095 (seq.++ ?x3529 (seq.++ ?x6573 ?x51697)))))))
 (let ((?x41214 (seq.++ ?x52275 (seq.++ ?x9397 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x3273 ?x60380)))))))
 (let (($x38298 (= v_1_L.ip_wire (seq.++ ?x70330 (seq.++ ?x52275 ?x41214)))))
 (let ((?x9471 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x11095 (seq.++ ?x52275 (seq.++ ?x52275 ?x51697)))))))
 (let ((?x60713 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x3273 ?x9471)))))
 (let (($x47769 (= v_1_L.ip_zero (seq.++ ?x70330 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x9397 ?x60713)))))))
 (let (($x97673 (= v_1_L.udp_wire ?x47801)))
 (let ((?x2658 (seq.++ ?x25547 (seq.++ ?x25547 (seq.++ ?x52275 (seq.++ ?x11095 (seq.++ ?x52275 ?x5525)))))))
 (let ((?x3136 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x35653 (seq.++ ?x52410 (seq.++ ?x52275 ?x2658)))))))
 (let (($x3138 (= v_1_L.pseudoheader (seq.++ ?x52410 ?x3136))))
 (let ((?x2536 (seq.++ ?x52275 (seq.++ ?x5525 (seq.++ ?x52275 (seq.++ ?x52275 (seq.unit (_ bv97 8))))))))
 (let (($x50295 (= v_1_L.udp_zero (seq.++ ?x41266 (seq.++ ?x3273 (seq.++ ?x41225 (seq.++ ?x41229 ?x2536)))))))
 (let ((?x32558 (seq.unit (_ bv97 8))))
 (let (($x32768 (= v_1_L.payload ?x32558)))
 (let (($x3801 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x84207 (= 0 v_1_L.retry_count)))
 (let (($x85714 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x80445 (= 0 state_1)))
 (let (($x12784 (not active_0_T.time_wait)))
 (let (($x69389 (or $x12784 (not (<= due_0_T.time_wait 0)))))
 (let (($x12772 (not active_0_T.user)))
 (let (($x25177 (or $x12772 (not (<= due_0_T.user 0)))))
 (let (($x41182 (not active_0_T.rtx)))
 (let (($x125475 (or $x41182 (not (<= due_0_T.rtx 0)))))
 (let (($x52280 (not active_0_L.cache)))
 (let (($x12855 (or $x52280 (not (<= due_0_L.cache 0)))))
 (let (($x38297 (not active_0_L.query)))
 (let (($x55379 (or $x38297 (not (<= due_0_L.query 0)))))
 (let (($x72 (= state_0 0)))
 (and $x72 (>= 0 now_0) $x55379 $x12855 $x125475 $x25177 $x69389 $x80445 $x85714 $x84207 $x3801 v_1_L.checksums_enabled $x32768 $x50295 $x3138 $x97673 $x47769 $x38298 $x3817 $x41174 $x11100 $x12641 $x52504 $x41397 $x60729 $x12690 $x89822 (= v_1_L.rxudp_disposition "none") $x33844 $x41105 $x84336 $x69370 (= v_1_L.echo_disposition "none") $x30748 $x47704 $x47703 $x47702 $x47701 $x47698 $x47697 $x47700 (= v_1_T.tx_flags "S") $x32780 $x3178 v_1_T.active_open $x3177 $x3176 $x3175 $x76179 $x41321 $x41322 $x3171 $x3168 $x3167 $x3170 $x6684 $x6685 $x74940 $x87056 $x53011 $x77633 $x41118 $x50194 (= v_1_T.wire_disposition "none") $x50323 $x97606 active_1_L.query $x74222 $x89566 $x3506 $x52624 $x79723 $x52321 $x36812 $x52312 $x98688)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3655 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x3654 (= due_2_T.user due_1_T.user)))
 (let (($x3653 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x3652 (= due_2_L.cache due_1_L.cache)))
 (let (($x3651 (= due_2_L.query due_1_L.query)))
 (let (($x3650 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x3649 (= active_2_T.user active_1_T.user)))
 (let (($x3648 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x3647 (= active_2_L.cache active_1_L.cache)))
 (let (($x3646 (= active_2_L.query active_1_L.query)))
 (let (($x3645 (= v_2_ip_pending_owner "UDP")))
 (let (($x3644 (= v_2_T.control v_1_T.control)))
 (let (($x3643 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x3642 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x3641 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x3640 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x3639 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x3638 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x3637 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x3636 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x3635 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x3634 (= v_2_T.take v_1_T.take)))
 (let (($x3633 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x3632 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x3631 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x3630 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x3629 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x3628 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x3627 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x3626 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x3625 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x3624 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x3623 (= v_2_T.retries v_1_T.retries)))
 (let (($x3622 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x3621 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x3620 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32664 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32663 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32662 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x32661 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x32660 (= v_2_T.irs v_1_T.irs)))
 (let (($x32659 (= v_2_T.iss v_1_T.iss)))
 (let (($x32658 (= v_2_L.control "PENDING")))
 (let (($x32657 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x32656 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x32655 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x32654 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x32653 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x32835 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32834 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32850 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let ((?x56835 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x52275 (seq.unit (_ bv0 8))))
 (let ((?x65810 (seq.++ ?x52275 ?x56835)))
 (let ((?x32895 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x9405 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x47732 (seq.unit (_ bv13 8))))
 (let ((?x41229 (seq.unit (_ bv144 8))))
 (let ((?x13418 (seq.++ ?x41229 (seq.++ ?x52275 (seq.++ ?x47732 (seq.++ ?x9405 (seq.++ ?x32895 ?x65810)))))))
 (let ((?x41225 (seq.unit (_ bv31 8))))
 (let ((?x3273 (seq.unit (_ bv64 8))))
 (let ((?x41266 (seq.unit (_ bv156 8))))
 (let ((?x62489 (seq.++ ?x41266 (seq.++ ?x3273 (seq.++ ?x41225 ?x13418)))))
 (let ((?x25547 (seq.unit (_ bv2 8))))
 (let ((?x52410 (seq.unit (_ bv192 8))))
 (let ((?x35653 (seq.unit (_ bv1 8))))
 (let ((?x41314 (seq.++ ?x35653 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x25547 ?x62489)))))))
 (let ((?x13059 (seq.unit (_ bv200 8))))
 (let ((?x3529 (seq.unit (_ bv182 8))))
 (let ((?x35634 (seq.++ ?x3529 (seq.++ ?x13059 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 ?x41314)))))))
 (let ((?x11095 (seq.unit (_ bv17 8))))
 (let ((?x76735 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x11095 ?x35634)))))))
 (let ((?x92462 (seq.unit (_ bv33 8))))
 (let ((?x70330 (seq.unit (_ bv69 8))))
 (let ((?x41327 (seq.++ ?x70330 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x92462 (seq.++ ?x52275 ?x76735)))))))
 (let (($x90345 (= v_2_L.pending_packet ?x41327)))
 (let (($x41092 (= v_2_L.ip_checksum 46792)))
 (let ((?x6661 (ite v_1_L.checksums_enabled 49271 0)))
 (let (($x53167 (= v_2_L.udp_checksum ?x6661)))
 (let (($x6579 (= v_2_L.udp_raw_checksum 49271)))
 (let (($x6578 (= v_2_L.ip_length 33)))
 (let (($x12863 (= v_2_L.udp_length 13)))
 (let (($x32924 (= v_2_L.packet ?x41327)))
 (let ((?x62576 (seq.++ ?x25547 (seq.++ ?x35653 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 ?x25547)))))))
 (let ((?x51697 (seq.++ ?x52410 (seq.++ ?x52275 ?x62576))))
 (let ((?x3522 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x11095 (seq.++ ?x3529 (seq.++ ?x13059 ?x51697)))))))
 (let ((?x49923 (seq.++ ?x52275 (seq.++ ?x92462 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x3273 ?x3522)))))))
 (let (($x77023 (= v_2_L.ip_wire (seq.++ ?x70330 (seq.++ ?x52275 ?x49923)))))
 (let ((?x9471 (seq.++ ?x52275 (seq.++ ?x3273 (seq.++ ?x11095 (seq.++ ?x52275 (seq.++ ?x52275 ?x51697)))))))
 (let ((?x60713 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x3273 ?x9471)))))
 (let (($x47796 (= v_2_L.ip_zero (seq.++ ?x70330 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x92462 ?x60713)))))))
 (let (($x47741 (= v_2_L.udp_wire ?x62489)))
 (let ((?x5528 (seq.++ ?x25547 (seq.++ ?x25547 (seq.++ ?x52275 (seq.++ ?x11095 (seq.++ ?x52275 ?x47732)))))))
 (let ((?x3113 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x35653 (seq.++ ?x52410 (seq.++ ?x52275 ?x5528)))))))
 (let (($x75084 (= v_2_L.pseudoheader (seq.++ ?x52410 ?x3113))))
 (let ((?x56598 (seq.++ ?x41229 (seq.++ ?x52275 (seq.++ ?x47732 (seq.++ ?x52275 (seq.++ ?x52275 ?x65810)))))))
 (let (($x36758 (= v_2_L.udp_zero (seq.++ ?x41266 (seq.++ ?x3273 (seq.++ ?x41225 ?x56598))))))
 (let (($x34052 (= v_2_L.payload ?x65810)))
 (let (($x197 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x65394 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x12822 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x51691 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x52940 (= 0 state_2)))
 (let (($x3804 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x518 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x36796 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x6677 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x3174 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x30748 (= v_1_L.control "PENDING")))
 (let (($x55445 (= state_1 0)))
 (and $x55445 $x30748 $x3174 $x6677 $x36796 $x518 $x3804 $x52940 $x51691 $x12822 $x65394 $x197 $x34052 $x36758 $x75084 $x47741 $x47796 $x77023 $x32924 $x12863 $x6578 $x6579 $x53167 $x41092 $x90345 $x32850 $x32834 $x32835 $x32653 $x32654 $x32655 $x32656 $x32657 $x32658 $x32659 $x32660 $x32661 $x32662 $x32663 $x32664 $x3620 $x3621 $x3622 $x3623 $x3624 $x3625 $x3626 $x3627 $x3628 $x3629 $x3630 $x3631 $x3632 $x3633 $x3634 $x3635 $x3636 $x3637 $x3638 $x3639 $x3640 $x3641 $x3642 $x3643 $x3644 $x3645 $x3646 $x3647 $x3648 $x3649 $x3650 $x3651 $x3652 $x3653 $x3654 $x3655))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x30086 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x30085 (= due_3_T.user due_2_T.user)))
 (let (($x30084 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x30082 (= due_3_L.query due_2_L.query)))
 (let (($x30081 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x30080 (= active_3_T.user active_2_T.user)))
 (let (($x30079 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x65497 (not active_3_L.query)))
 (let (($x30076 (= v_3_ip_pending_owner "none")))
 (let (($x30075 (= v_3_T.control v_2_T.control)))
 (let (($x30074 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x30073 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x30072 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x30071 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x30070 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x30069 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x30068 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x30067 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x30066 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x30065 (= v_3_T.take v_2_T.take)))
 (let (($x30064 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x30063 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x30062 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x30061 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x30060 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x30059 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x30058 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x30057 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x30056 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x30055 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x30054 (= v_3_T.retries v_2_T.retries)))
 (let (($x30053 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x30052 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x30051 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x30050 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x30049 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x30048 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x30047 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x30046 (= v_3_T.irs v_2_T.irs)))
 (let (($x30045 (= v_3_T.iss v_2_T.iss)))
 (let (($x30044 (= v_3_L.control "RESOLVED")))
 (let (($x30043 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x30042 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x30041 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x30040 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x30039 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x30038 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x30037 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x30036 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x25500 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x30034 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x30033 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x30032 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x30031 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x30030 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x30029 (= v_3_L.packet v_2_L.packet)))
 (let (($x30028 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x30027 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x30026 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x30025 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x30024 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x30023 (= v_3_L.payload v_2_L.payload)))
 (let (($x30022 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x30021 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x30020 (= 0 v_3_L.retry_count)))
 (let ((?x52275 (seq.unit (_ bv0 8))))
 (let ((?x9865 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.unit (_ bv2 8))))))))
 (let ((?x25547 (seq.unit (_ bv2 8))))
 (let ((?x51154 (seq.++ ?x25547 ?x9865)))
 (let (($x32868 (= v_3_L.peer_mac ?x51154)))
 (let (($x30018 (= 0 state_3)))
 (let (($x97296 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x3117 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x40333 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x79085 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x56669 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let ((?x29975 (seq.len v_2_L.pending_packet)))
 (let (($x29976 (<= 28 ?x29975)))
 (let (($x32658 (= v_2_L.control "PENDING")))
 (let (($x9443 (= state_2 0)))
 (and $x9443 $x32658 $x29976 $x56669 $x79085 $x40333 $x3117 $x97296 $x30018 $x32868 $x30020 $x30021 $x30022 $x30023 $x30024 $x30025 $x30026 $x30027 $x30028 $x30029 $x30030 $x30031 $x30032 $x30033 $x30034 $x25500 $x30036 $x30037 $x30038 $x30039 $x30040 $x30041 $x30042 $x30043 $x30044 $x30045 $x30046 $x30047 $x30048 $x30049 $x30050 $x30051 $x30052 $x30053 $x30054 $x30055 $x30056 $x30057 $x30058 $x30059 $x30060 $x30061 $x30062 $x30063 $x30064 $x30065 $x30066 $x30067 $x30068 $x30069 $x30070 $x30071 $x30072 $x30073 $x30074 $x30075 $x30076 $x65497 active_3_L.cache $x30079 $x30080 $x30081 $x30082 (= due_3_L.cache (+ 2 v_2_L.cache_ttl_ms)) $x30084 $x30085 $x30086))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x32558 (seq.unit (_ bv97 8))))
 (= input_0_L.app.send_data ?x32558)))
(assert
 (= 20 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x56835 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x52275 (seq.unit (_ bv0 8))))
 (let ((?x65810 (seq.++ ?x52275 ?x56835)))
 (= input_1_L.app.send_data ?x65810)))))
(assert
 (= 29 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x52410 (seq.unit (_ bv192 8))))
(let ((?x35695 (seq.++ ?x52410 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x35653 (seq.unit (_ bv1 8))))
(let ((?x52275 (seq.unit (_ bv0 8))))
(let ((?x41140 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x35653 ?x35695)))))))
(let ((?x25547 (seq.unit (_ bv2 8))))
(let ((?x35643 (seq.++ ?x52410 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x25547 (seq.++ ?x25547 ?x41140)))))))
(let ((?x80178 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x25547 ?x35643)))))))
(let ((?x3786 (seq.unit (_ bv4 8))))
(let ((?x52393 (seq.unit (_ bv6 8))))
(let ((?x52428 (seq.++ ?x52393 (seq.++ ?x3786 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x25547 ?x80178)))))))
(let ((?x35671 (seq.unit (_ bv8 8))))
(let ((?x125524 (seq.++ ?x52393 (seq.++ ?x52275 (seq.++ ?x35653 (seq.++ ?x35671 (seq.++ ?x52275 ?x52428)))))))
(let ((?x32998 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x25547 (seq.++ ?x35671 ?x125524)))))))
(let ((?x52623 (seq.++ ?x52275 (seq.++ ?x52275 (seq.++ ?x35653 (seq.++ ?x25547 (seq.++ ?x52275 ?x32998)))))))
(let ((?x3843 (seq.++ ?x25547 (seq.++ ?x52275 (seq.++ ?x52275 ?x52623)))))
(= input_2_L.net.frame_frame ?x3843))))))))))))))))))
(check-sat)

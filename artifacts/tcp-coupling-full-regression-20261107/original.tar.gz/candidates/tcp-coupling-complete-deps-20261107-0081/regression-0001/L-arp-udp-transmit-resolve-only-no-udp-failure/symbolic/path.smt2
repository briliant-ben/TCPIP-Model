; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x28833 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x30567 (= due_1_T.user due_0_T.user)))
 (let (($x1403 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x45901 (= due_1_L.cache due_0_L.cache)))
 (let (($x98609 (= due_1_L.query 1000)))
 (let (($x57331 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x88747 (= active_1_T.user active_0_T.user)))
 (let (($x91344 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x96561 (= active_1_L.cache active_0_L.cache)))
 (let (($x19136 (= v_1_T.control "CLOSED")))
 (let (($x62177 (= v_1_T.wire_flags 0)))
 (let (($x24899 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x62168 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x62167 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x51642 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x57836 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x62174 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x62173 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x62183 (= v_1_T.take 0)))
 (let (($x62184 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x62182 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x62185 (= v_1_T.snd_wnd 8)))
 (let (($x97907 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x25495 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x57342 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x74126 (= v_1_T.local_window 16)))
 (let (($x1468 (= v_1_T.msl_ms 60000)))
 (let (($x57500 (= v_1_T.user_timeout_ms 30000)))
 (let (($x24859 (= v_1_T.retries 0)))
 (let (($x57499 (= v_1_T.rto_ms 1000)))
 (let (($x62197 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x62198 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x62193 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x62196 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x62199 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x62200 (= v_1_T.irs (_ bv0 32))))
 (let (($x62201 (= v_1_T.iss (_ bv1000 32))))
 (let (($x1445 (= v_1_L.control "PENDING")))
 (let (($x62211 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x62210 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x62209 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x62192 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x62186 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x18966 (not v_1_L.rxudp_require_checksum)))
 (let (($x62172 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x6557 (= v_1_L.ip_checksum 0)))
 (let (($x62207 (= v_1_L.udp_checksum 0)))
 (let (($x62195 (= v_1_L.udp_raw_checksum 0)))
 (let (($x13788 (= v_1_L.ip_length 0)))
 (let (($x3818 (= v_1_L.udp_length 0)))
 (let (($x62171 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x62170 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x62169 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x62166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x62165 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x62161 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x62164 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x52498 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x24865 (= 0 v_1_L.retry_count)))
 (let (($x62163 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x1485 (= 0 state_1)))
 (let (($x7973 (not active_0_T.time_wait)))
 (let (($x62156 (or $x7973 (not (<= due_0_T.time_wait 0)))))
 (let (($x38327 (not active_0_T.user)))
 (let (($x48612 (or $x38327 (not (<= due_0_T.user 0)))))
 (let (($x1474 (not active_0_T.rtx)))
 (let (($x102867 (or $x1474 (not (<= due_0_T.rtx 0)))))
 (let (($x89555 (not active_0_L.cache)))
 (let (($x58058 (or $x89555 (not (<= due_0_L.cache 0)))))
 (let (($x40288 (not active_0_L.query)))
 (let (($x102830 (or $x40288 (not (<= due_0_L.query 0)))))
 (let (($x1542 (= state_0 0)))
 (and $x1542 (>= 0 now_0) $x102830 $x58058 $x102867 $x48612 $x62156 $x1485 $x62163 $x24865 $x52498 v_1_L.checksums_enabled $x62164 $x62161 $x62165 $x62166 $x62169 $x62170 $x62171 $x3818 $x13788 $x62195 $x62207 $x6557 $x62172 $x18966 $x62186 (= v_1_L.rxudp_disposition "none") $x62192 $x62209 $x62210 $x62211 (= v_1_L.echo_disposition "none") $x1445 $x62201 $x62200 $x62199 $x62196 $x62193 $x62198 $x62197 (= v_1_T.tx_flags "S") $x57499 $x24859 v_1_T.active_open $x57500 $x1468 $x74126 $x57342 $x25495 $x97907 $x62185 $x62182 $x62184 $x62183 $x62173 $x62174 $x57836 $x51642 $x62167 $x62168 $x24899 $x62177 (= v_1_T.wire_disposition "none") $x19136 (= v_1_ip_pending_owner "none") active_1_L.query $x96561 $x91344 $x88747 $x57331 $x98609 $x45901 $x1403 $x30567 $x28833))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x18682 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x18681 (= due_2_T.user due_1_T.user)))
 (let (($x18680 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x18679 (= due_2_L.cache due_1_L.cache)))
 (let (($x6621 (= due_2_L.query 2000)))
 (let (($x18677 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x18676 (= active_2_T.user active_1_T.user)))
 (let (($x18675 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x18674 (= active_2_L.cache active_1_L.cache)))
 (let (($x18672 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x18671 (= v_2_T.control v_1_T.control)))
 (let (($x18670 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x18669 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x18668 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x18667 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x18666 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x18665 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x18664 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x18663 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x18662 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x18661 (= v_2_T.take v_1_T.take)))
 (let (($x18660 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x18659 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x18658 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x18657 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x18656 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x18655 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x18654 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x18653 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x18652 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x18651 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x18650 (= v_2_T.retries v_1_T.retries)))
 (let (($x18649 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x18648 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x18647 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x18646 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x18645 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x18644 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x18643 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x18642 (= v_2_T.irs v_1_T.irs)))
 (let (($x18641 (= v_2_T.iss v_1_T.iss)))
 (let (($x18640 (= v_2_L.control "PENDING")))
 (let (($x18639 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x5265 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x5264 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x5263 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x18638 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x18637 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x18636 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x18635 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x18634 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x18633 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x18632 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x18631 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x18630 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x18629 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x18628 (= v_2_L.packet v_1_L.packet)))
 (let (($x18627 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x18626 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x18625 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x18624 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x5260 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x5259 (= v_2_L.payload v_1_L.payload)))
 (let (($x5258 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x18623 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x18622 (= 1 v_2_L.retry_count)))
 (let (($x18621 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x18620 (= 0 state_2)))
 (let (($x24865 (= 0 v_1_L.retry_count)))
 (let (($x1445 (= v_1_L.control "PENDING")))
 (let (($x62194 (= state_1 0)))
 (and $x62194 $x1445 $x24865 active_1_L.query (= 1000 due_1_L.query) (or (not active_1_L.cache) (not (<= due_1_L.cache due_1_L.query))) (or (not active_1_T.rtx) (<= due_1_L.query due_1_T.rtx)) (or (not active_1_T.user) (<= due_1_L.query due_1_T.user)) (or (not active_1_T.time_wait) (<= due_1_L.query due_1_T.time_wait)) $x18620 $x18621 $x18622 $x18623 $x5258 $x5259 $x5260 $x18624 $x18625 $x18626 $x18627 $x18628 $x18629 $x18630 $x18631 $x18632 $x18633 $x18634 $x18635 $x18636 $x18637 $x18638 $x5263 $x5264 $x5265 $x18639 $x18640 $x18641 $x18642 $x18643 $x18644 $x18645 $x18646 $x18647 $x18648 $x18649 $x18650 $x18651 $x18652 $x18653 $x18654 $x18655 $x18656 $x18657 $x18658 $x18659 $x18660 $x18661 $x18662 $x18663 $x18664 $x18665 $x18666 $x18667 $x18668 $x18669 $x18670 $x18671 $x18672 active_2_L.query $x18674 $x18675 $x18676 $x18677 $x6621 $x18679 $x18680 $x18681 $x18682)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x45911 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x14371 (= due_3_T.user due_2_T.user)))
 (let (($x6561 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x89009 (= due_3_L.cache due_2_L.cache)))
 (let (($x23505 (= due_3_L.query due_2_L.query)))
 (let (($x98083 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x90186 (= active_3_T.user active_2_T.user)))
 (let (($x45876 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x45875 (= active_3_L.cache active_2_L.cache)))
 (let (($x62181 (not active_3_L.query)))
 (let (($x46067 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x57560 (= v_3_T.control v_2_T.control)))
 (let (($x57929 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x45890 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x46109 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x46101 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x16623 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x89269 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x57867 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x8969 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x85688 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x45842 (= v_3_T.take v_2_T.take)))
 (let (($x45841 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x6662 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x41358 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x57483 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x57519 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x8965 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x1435 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x100772 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x44086 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x53123 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x96552 (= v_3_T.retries v_2_T.retries)))
 (let (($x46022 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x46026 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x45872 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x23643 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x53019 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x41177 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x1356 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x52852 (= v_3_T.irs v_2_T.irs)))
 (let (($x96775 (= v_3_T.iss v_2_T.iss)))
 (let (($x24878 (= v_3_L.control "EMPTY")))
 (let (($x57977 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x96632 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x62 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x102791 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x100738 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x90384 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x98778 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x58042 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x100827 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x5536 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x23740 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x3120 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x23583 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x100806 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x27800 (= v_3_L.packet v_2_L.packet)))
 (let (($x62759 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x52894 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x45883 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x45882 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x100805 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x100807 (= v_3_L.payload v_2_L.payload)))
 (let (($x31736 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x58043 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x41345 (= 0 v_3_L.retry_count)))
 (let (($x97905 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.peer_mac)))
 (let (($x98037 (= 0 state_3)))
 (let ((?x45868 (seq.len v_2_L.pending_packet)))
 (let (($x100800 (= 0 ?x45868)))
 (let (($x18622 (= 1 v_2_L.retry_count)))
 (let (($x18640 (= v_2_L.control "PENDING")))
 (let (($x41364 (= state_2 0)))
 (and $x41364 $x18640 $x18622 $x100800 active_2_L.query (= 2000 due_2_L.query) (or (not active_2_L.cache) (not (<= due_2_L.cache due_2_L.query))) (or (not active_2_T.rtx) (<= due_2_L.query due_2_T.rtx)) (or (not active_2_T.user) (<= due_2_L.query due_2_T.user)) (or (not active_2_T.time_wait) (<= due_2_L.query due_2_T.time_wait)) $x98037 $x97905 $x41345 $x58043 $x31736 $x100807 $x100805 $x45882 $x45883 $x52894 $x62759 $x27800 $x100806 $x23583 $x3120 $x23740 $x5536 $x100827 $x58042 $x98778 $x90384 $x100738 $x102791 $x62 $x96632 $x57977 $x24878 $x96775 $x52852 $x1356 $x41177 $x53019 $x23643 $x45872 $x46026 $x46022 $x96552 $x53123 $x44086 $x100772 $x1435 $x8965 $x57519 $x57483 $x41358 $x6662 $x45841 $x45842 $x85688 $x8969 $x57867 $x89269 $x16623 $x46101 $x46109 $x45890 $x57929 $x57560 $x46067 $x62181 $x45875 $x45876 $x90186 $x98083 $x23505 $x89009 $x6561 $x14371 $x45911))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x57506 (seq.unit (_ bv192 8))))
 (let ((?x57986 (seq.++ ?x57506 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x57986))))
(assert
 (= 3 choice_1))
(assert
 (= 1000 now_2))
(assert
 (= 26 choice_2))
(assert
 (= 2000 now_3))
(check-sat)

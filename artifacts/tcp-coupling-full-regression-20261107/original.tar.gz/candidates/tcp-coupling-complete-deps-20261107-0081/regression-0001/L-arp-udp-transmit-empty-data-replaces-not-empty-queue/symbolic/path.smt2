; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x1448 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x32888 (= due_1_T.user due_0_T.user)))
 (let (($x6700 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x98082 (= due_1_L.cache due_0_L.cache)))
 (let (($x56305 (= due_1_L.query 1000)))
 (let (($x41180 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x98058 (= active_1_T.user active_0_T.user)))
 (let (($x57270 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x53130 (= active_1_L.cache active_0_L.cache)))
 (let (($x57978 (= v_1_ip_pending_owner "UDP")))
 (let (($x102574 (= v_1_T.control "CLOSED")))
 (let (($x18890 (= v_1_T.wire_flags 0)))
 (let (($x64601 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x101930 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x2277 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x2276 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x2275 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x2274 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x2273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x62146 (= v_1_T.take 0)))
 (let (($x18586 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x18587 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x18868 (= v_1_T.snd_wnd 8)))
 (let (($x2272 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x2271 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x2270 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x18872 (= v_1_T.local_window 16)))
 (let (($x18873 (= v_1_T.msl_ms 60000)))
 (let (($x18874 (= v_1_T.user_timeout_ms 30000)))
 (let (($x18875 (= v_1_T.retries 0)))
 (let (($x38753 (= v_1_T.rto_ms 1000)))
 (let (($x43570 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x43571 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x43577 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x43580 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x43581 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x43582 (= v_1_T.irs (_ bv0 32))))
 (let (($x43583 (= v_1_T.iss (_ bv1000 32))))
 (let (($x7987 (= v_1_L.control "PENDING")))
 (let (($x2269 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x2268 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x2267 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x2266 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x2265 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x102405 (not v_1_L.rxudp_require_checksum)))
 (let ((?x10360 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x45959 (seq.unit (_ bv0 8))))
 (let ((?x37449 (seq.++ ?x45959 ?x10360)))
 (let ((?x18663 (seq.unit (_ bv192 8))))
 (let ((?x18604 (seq.unit (_ bv13 8))))
 (let ((?x62094 (seq.++ ?x45959 (seq.++ ?x18604 (seq.++ ?x18663 (seq.++ (seq.unit (_ bv119 8)) ?x37449))))))
 (let ((?x104125 (seq.unit (_ bv144 8))))
 (let ((?x98096 (seq.unit (_ bv31 8))))
 (let ((?x69074 (seq.unit (_ bv64 8))))
 (let ((?x20256 (seq.unit (_ bv156 8))))
 (let ((?x43597 (seq.++ ?x20256 (seq.++ ?x69074 (seq.++ ?x98096 (seq.++ ?x104125 ?x62094))))))
 (let ((?x46167 (seq.unit (_ bv2 8))))
 (let ((?x62171 (seq.unit (_ bv1 8))))
 (let ((?x10562 (seq.++ ?x62171 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x46167 ?x43597)))))))
 (let ((?x45170 (seq.unit (_ bv200 8))))
 (let ((?x83832 (seq.unit (_ bv182 8))))
 (let ((?x13247 (seq.++ ?x83832 (seq.++ ?x45170 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 ?x10562)))))))
 (let ((?x69561 (seq.unit (_ bv17 8))))
 (let ((?x48592 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x69561 ?x13247)))))))
 (let ((?x18770 (seq.unit (_ bv33 8))))
 (let ((?x72864 (seq.unit (_ bv69 8))))
 (let ((?x102073 (seq.++ ?x72864 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x18770 (seq.++ ?x45959 ?x48592)))))))
 (let (($x2264 (= v_1_L.pending_packet ?x102073)))
 (let (($x2263 (= v_1_L.ip_checksum 46792)))
 (let (($x2262 (= v_1_L.udp_checksum 49271)))
 (let (($x20204 (= v_1_L.udp_raw_checksum 49271)))
 (let (($x37436 (= v_1_L.ip_length 33)))
 (let (($x27455 (= v_1_L.udp_length 13)))
 (let (($x37435 (= v_1_L.packet ?x102073)))
 (let ((?x93341 (seq.++ ?x46167 (seq.++ ?x62171 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 ?x46167)))))))
 (let ((?x93340 (seq.++ ?x18663 (seq.++ ?x45959 ?x93341))))
 (let ((?x41221 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x69561 (seq.++ ?x83832 (seq.++ ?x45170 ?x93340)))))))
 (let ((?x10425 (seq.++ ?x45959 (seq.++ ?x18770 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x69074 ?x41221)))))))
 (let (($x13263 (= v_1_L.ip_wire (seq.++ ?x72864 (seq.++ ?x45959 ?x10425)))))
 (let ((?x43654 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x69561 (seq.++ ?x45959 (seq.++ ?x45959 ?x93340)))))))
 (let ((?x93365 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x69074 ?x43654)))))
 (let (($x97704 (= v_1_L.ip_zero (seq.++ ?x72864 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x18770 ?x93365)))))))
 (let (($x43598 (= v_1_L.udp_wire ?x43597)))
 (let ((?x5246 (seq.++ ?x46167 (seq.++ ?x46167 (seq.++ ?x45959 (seq.++ ?x69561 (seq.++ ?x45959 ?x18604)))))))
 (let ((?x19024 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x62171 (seq.++ ?x18663 (seq.++ ?x45959 ?x5246)))))))
 (let (($x19026 (= v_1_L.pseudoheader (seq.++ ?x18663 ?x19024))))
 (let ((?x43586 (seq.++ ?x104125 (seq.++ ?x45959 (seq.++ ?x18604 (seq.++ ?x45959 (seq.++ ?x45959 ?x37449)))))))
 (let (($x43606 (= v_1_L.udp_zero (seq.++ ?x20256 (seq.++ ?x69074 (seq.++ ?x98096 ?x43586))))))
 (let (($x96639 (= v_1_L.payload ?x37449)))
 (let (($x43496 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x57397 (= 0 v_1_L.retry_count)))
 (let (($x18561 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x41460 (= 0 state_1)))
 (let (($x83230 (not active_0_T.time_wait)))
 (let (($x18699 (or $x83230 (not (<= due_0_T.time_wait 0)))))
 (let (($x57877 (not active_0_T.user)))
 (let (($x18696 (or $x57877 (not (<= due_0_T.user 0)))))
 (let (($x52430 (not active_0_T.rtx)))
 (let (($x18694 (or $x52430 (not (<= due_0_T.rtx 0)))))
 (let (($x23348 (not active_0_L.cache)))
 (let (($x97748 (or $x23348 (not (<= due_0_L.cache 0)))))
 (let (($x8037 (not active_0_L.query)))
 (let (($x18823 (or $x8037 (not (<= due_0_L.query 0)))))
 (let (($x100742 (= state_0 0)))
 (and $x100742 (>= 0 now_0) $x18823 $x97748 $x18694 $x18696 $x18699 $x41460 $x18561 $x57397 $x43496 v_1_L.checksums_enabled $x96639 $x43606 $x19026 $x43598 $x97704 $x13263 $x37435 $x27455 $x37436 $x20204 $x2262 $x2263 $x2264 $x102405 $x2265 (= v_1_L.rxudp_disposition "none") $x2266 $x2267 $x2268 $x2269 (= v_1_L.echo_disposition "none") $x7987 $x43583 $x43582 $x43581 $x43580 $x43577 $x43571 $x43570 (= v_1_T.tx_flags "S") $x38753 $x18875 v_1_T.active_open $x18874 $x18873 $x18872 $x2270 $x2271 $x2272 $x18868 $x18587 $x18586 $x62146 $x2273 $x2274 $x2275 $x2276 $x2277 $x101930 $x64601 $x18890 (= v_1_T.wire_disposition "none") $x102574 $x57978 active_1_L.query $x53130 $x57270 $x98058 $x41180 $x56305 $x98082 $x6700 $x32888 $x1448))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x102243 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x102242 (= due_2_T.user due_1_T.user)))
 (let (($x102241 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x102240 (= due_2_L.cache due_1_L.cache)))
 (let (($x102239 (= due_2_L.query due_1_L.query)))
 (let (($x102238 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x102237 (= active_2_T.user active_1_T.user)))
 (let (($x102236 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x52534 (= active_2_L.cache active_1_L.cache)))
 (let (($x69608 (= active_2_L.query active_1_L.query)))
 (let (($x83097 (= v_2_ip_pending_owner "UDP")))
 (let (($x89961 (= v_2_T.control v_1_T.control)))
 (let (($x86151 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x77358 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x56968 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x56868 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x79523 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x14364 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x41932 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x38319 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x20267 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x69995 (= v_2_T.take v_1_T.take)))
 (let (($x74650 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x56329 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x56080 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x82615 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x67843 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x87913 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x88426 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x73025 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x73024 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x87857 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x88370 (= v_2_T.retries v_1_T.retries)))
 (let (($x82611 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x83823 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x99145 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x9882 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x70487 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x84347 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x78616 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x80668 (= v_2_T.irs v_1_T.irs)))
 (let (($x71 (= v_2_T.iss v_1_T.iss)))
 (let (($x53219 (= v_2_L.control "PENDING")))
 (let (($x3557 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x71022 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x73385 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x71716 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x82616 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x88937 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x89450 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x52531 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let ((?x18928 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49161 0))))))
 (let ((?x18778 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49161 0))))))
 (let ((?x57499 (seq.unit (_ bv8 8))))
 (let ((?x45959 (seq.unit (_ bv0 8))))
 (let ((?x104125 (seq.unit (_ bv144 8))))
 (let ((?x98096 (seq.unit (_ bv31 8))))
 (let ((?x43403 (seq.++ ?x98096 (seq.++ ?x104125 (seq.++ ?x45959 (seq.++ ?x57499 (seq.++ ?x18778 ?x18928)))))))
 (let ((?x69074 (seq.unit (_ bv64 8))))
 (let ((?x20256 (seq.unit (_ bv156 8))))
 (let ((?x18713 (seq.++ ?x20256 (seq.++ ?x69074 ?x43403))))
 (let ((?x46167 (seq.unit (_ bv2 8))))
 (let ((?x18663 (seq.unit (_ bv192 8))))
 (let ((?x62171 (seq.unit (_ bv1 8))))
 (let ((?x10581 (seq.++ ?x62171 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x46167 ?x18713)))))))
 (let ((?x73122 (seq.unit (_ bv205 8))))
 (let ((?x83832 (seq.unit (_ bv182 8))))
 (let ((?x19013 (seq.++ ?x83832 (seq.++ ?x73122 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 ?x10581)))))))
 (let ((?x69561 (seq.unit (_ bv17 8))))
 (let ((?x86142 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x69561 ?x19013)))))))
 (let ((?x43666 (seq.unit (_ bv28 8))))
 (let ((?x72864 (seq.unit (_ bv69 8))))
 (let ((?x72097 (seq.++ ?x72864 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x43666 (seq.++ ?x45959 ?x86142)))))))
 (let (($x93566 (= v_2_L.pending_packet ?x72097)))
 (let (($x17249 (= v_2_L.ip_checksum 46797)))
 (let ((?x18903 (ite v_1_L.checksums_enabled 49161 0)))
 (let (($x45055 (= v_2_L.udp_checksum ?x18903)))
 (let (($x93565 (= v_2_L.udp_raw_checksum 49161)))
 (let (($x94268 (= v_2_L.ip_length 28)))
 (let (($x73627 (= v_2_L.udp_length 8)))
 (let (($x73240 (= v_2_L.packet ?x72097)))
 (let ((?x93341 (seq.++ ?x46167 (seq.++ ?x62171 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 ?x46167)))))))
 (let ((?x93340 (seq.++ ?x18663 (seq.++ ?x45959 ?x93341))))
 (let ((?x47183 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x69561 (seq.++ ?x83832 (seq.++ ?x73122 ?x93340)))))))
 (let ((?x97695 (seq.++ ?x45959 (seq.++ ?x43666 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x69074 ?x47183)))))))
 (let (($x97747 (= v_2_L.ip_wire (seq.++ ?x72864 (seq.++ ?x45959 ?x97695)))))
 (let ((?x43654 (seq.++ ?x45959 (seq.++ ?x69074 (seq.++ ?x69561 (seq.++ ?x45959 (seq.++ ?x45959 ?x93340)))))))
 (let ((?x93365 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x69074 ?x43654)))))
 (let (($x38719 (= v_2_L.ip_zero (seq.++ ?x72864 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x43666 ?x93365)))))))
 (let (($x18844 (= v_2_L.udp_wire ?x18713)))
 (let ((?x62098 (seq.++ ?x46167 (seq.++ ?x46167 (seq.++ ?x45959 (seq.++ ?x69561 (seq.++ ?x45959 ?x57499)))))))
 (let ((?x43635 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x62171 (seq.++ ?x18663 (seq.++ ?x45959 ?x62098)))))))
 (let (($x43637 (= v_2_L.pseudoheader (seq.++ ?x18663 ?x43635))))
 (let ((?x19045 (seq.++ ?x98096 (seq.++ ?x104125 (seq.++ ?x45959 (seq.++ ?x57499 (seq.++ ?x45959 ?x45959)))))))
 (let (($x73534 (= v_2_L.udp_zero (seq.++ ?x20256 (seq.++ ?x69074 ?x19045)))))
 (let (($x43493 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.payload)))
 (let (($x60178 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x84630 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x73907 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x38330 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x3567 (= 0 state_2)))
 (let (($x43494 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x18836 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x43540 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x43544 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x18870 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x7987 (= v_1_L.control "PENDING")))
 (let (($x62095 (= state_1 0)))
 (and $x62095 $x7987 $x18870 $x43544 $x43540 $x18836 $x43494 $x3567 $x38330 $x73907 $x84630 $x60178 $x43493 $x73534 $x43637 $x18844 $x38719 $x97747 $x73240 $x73627 $x94268 $x93565 $x45055 $x17249 $x93566 $x52531 $x89450 $x88937 $x82616 $x71716 $x73385 $x71022 $x3557 $x53219 $x71 $x80668 $x78616 $x84347 $x70487 $x9882 $x99145 $x83823 $x82611 $x88370 $x87857 $x73024 $x73025 $x88426 $x87913 $x67843 $x82615 $x56080 $x56329 $x74650 $x69995 $x20267 $x38319 $x41932 $x14364 $x79523 $x56868 $x56968 $x77358 $x86151 $x89961 $x83097 $x69608 $x52534 $x102236 $x102237 $x102238 $x102239 $x102240 $x102241 $x102242 $x102243))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x45770 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x45771 (= due_3_T.user due_2_T.user)))
 (let (($x45772 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x45774 (= due_3_L.query due_2_L.query)))
 (let (($x68266 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x24877 (= active_3_T.user active_2_T.user)))
 (let (($x80581 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x10482 (not active_3_L.query)))
 (let (($x24974 (= v_3_ip_pending_owner "none")))
 (let (($x24895 (= v_3_T.control v_2_T.control)))
 (let (($x23575 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x23576 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x24937 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x57471 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x63438 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x57469 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x57470 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x104077 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x96467 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x57473 (= v_3_T.take v_2_T.take)))
 (let (($x57474 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x57543 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x45945 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x45944 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x45943 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x45942 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x45941 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x45940 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x45939 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x45938 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x45937 (= v_3_T.retries v_2_T.retries)))
 (let (($x45936 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x45935 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x45934 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x45933 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x45932 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x45931 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x45930 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x1505 (= v_3_T.irs v_2_T.irs)))
 (let (($x1507 (= v_3_T.iss v_2_T.iss)))
 (let (($x1509 (= v_3_L.control "RESOLVED")))
 (let (($x1511 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x98155 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x25299 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x25298 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x25297 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x25296 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x98154 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x25294 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x10481 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x25292 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x25291 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x25289 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x24936 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x23956 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x63575 (= v_3_L.packet v_2_L.packet)))
 (let (($x80337 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x98153 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x98152 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x98151 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x98150 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x98149 (= v_3_L.payload v_2_L.payload)))
 (let (($x98148 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x98147 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x69274 (= 0 v_3_L.retry_count)))
 (let ((?x45959 (seq.unit (_ bv0 8))))
 (let ((?x57375 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.unit (_ bv2 8))))))))
 (let ((?x46167 (seq.unit (_ bv2 8))))
 (let ((?x57370 (seq.++ ?x46167 ?x57375)))
 (let (($x4783 (= v_3_L.peer_mac ?x57370)))
 (let (($x77015 (= 0 state_3)))
 (let (($x18757 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 6)))))
 (let (($x76179 (or (not active_2_T.user) (not (<= due_2_T.user 6)))))
 (let (($x18600 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 6)))))
 (let (($x43681 (or (not active_2_L.cache) (not (<= due_2_L.cache 6)))))
 (let (($x70787 (or (not active_2_L.query) (not (<= due_2_L.query 6)))))
 (let ((?x57309 (seq.len v_2_L.pending_packet)))
 (let (($x57313 (<= 28 ?x57309)))
 (let (($x53219 (= v_2_L.control "PENDING")))
 (let (($x93363 (= state_2 0)))
 (and $x93363 $x53219 $x57313 $x70787 $x43681 $x18600 $x76179 $x18757 $x77015 $x4783 $x69274 $x98147 $x98148 $x98149 $x98150 $x98151 $x98152 $x98153 $x80337 $x63575 $x23956 $x24936 $x25289 $x25291 $x25292 $x10481 $x25294 $x98154 $x25296 $x25297 $x25298 $x25299 $x98155 $x1511 $x1509 $x1507 $x1505 $x45930 $x45931 $x45932 $x45933 $x45934 $x45935 $x45936 $x45937 $x45938 $x45939 $x45940 $x45941 $x45942 $x45943 $x45944 $x45945 $x57543 $x57474 $x57473 $x96467 $x104077 $x57470 $x57469 $x63438 $x57471 $x24937 $x23576 $x23575 $x24895 $x24974 $x10482 active_3_L.cache $x80581 $x24877 $x68266 $x45774 (= due_3_L.cache (+ 6 v_2_L.cache_ttl_ms)) $x45772 $x45771 $x45770))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x10360 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x45959 (seq.unit (_ bv0 8))))
 (let ((?x37449 (seq.++ ?x45959 ?x10360)))
 (= input_0_L.app.send_data ?x37449)))))
(assert
 (= 20 choice_1))
(assert
 (= 5 now_2))
(assert
 (= input_1_L.app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 29 choice_2))
(assert
 (= 6 now_3))
(assert
 (let ((?x18663 (seq.unit (_ bv192 8))))
(let ((?x98505 (seq.++ ?x18663 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x62171 (seq.unit (_ bv1 8))))
(let ((?x45959 (seq.unit (_ bv0 8))))
(let ((?x79378 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x62171 ?x98505)))))))
(let ((?x46167 (seq.unit (_ bv2 8))))
(let ((?x86562 (seq.++ ?x18663 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x46167 (seq.++ ?x46167 ?x79378)))))))
(let ((?x13265 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x46167 ?x86562)))))))
(let ((?x74126 (seq.unit (_ bv4 8))))
(let ((?x57500 (seq.unit (_ bv6 8))))
(let ((?x80298 (seq.++ ?x57500 (seq.++ ?x74126 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x46167 ?x13265)))))))
(let ((?x57499 (seq.unit (_ bv8 8))))
(let ((?x88413 (seq.++ ?x57500 (seq.++ ?x45959 (seq.++ ?x62171 (seq.++ ?x57499 (seq.++ ?x45959 ?x80298)))))))
(let ((?x13104 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x46167 (seq.++ ?x57499 ?x88413)))))))
(let ((?x13130 (seq.++ ?x45959 (seq.++ ?x45959 (seq.++ ?x62171 (seq.++ ?x46167 (seq.++ ?x45959 ?x13104)))))))
(let ((?x10626 (seq.++ ?x46167 (seq.++ ?x45959 (seq.++ ?x45959 ?x13130)))))
(= input_2_L.net.frame_frame ?x10626))))))))))))))))))
(check-sat)

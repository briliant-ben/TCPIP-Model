; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x12901 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x56606 (= due_1_T.user due_0_T.user)))
 (let (($x32535 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x63651 (= due_1_L.cache 60000)))
 (let (($x56588 (= due_1_L.query due_0_L.query)))
 (let (($x56587 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x7149 (= active_1_T.user active_0_T.user)))
 (let (($x50288 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x53569 (not active_1_L.query)))
 (let (($x26035 (= v_1_T.control "CLOSED")))
 (let (($x56154 (= v_1_T.wire_flags 0)))
 (let (($x8700 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x30551 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x49928 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x49918 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x49910 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x91191 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x30552 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x56158 (= v_1_T.take 0)))
 (let (($x56159 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x46809 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x46810 (= v_1_T.snd_wnd 8)))
 (let (($x55503 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x48576 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x32981 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x49925 (= v_1_T.local_window 16)))
 (let (($x56635 (= v_1_T.msl_ms 60000)))
 (let (($x55593 (= v_1_T.user_timeout_ms 30000)))
 (let (($x95161 (= v_1_T.retries 0)))
 (let (($x55594 (= v_1_T.rto_ms 1000)))
 (let (($x53289 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x32540 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x52998 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x32857 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x125365 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x95162 (= v_1_T.irs (_ bv0 32))))
 (let (($x61331 (= v_1_T.iss (_ bv1000 32))))
 (let (($x30875 (= v_1_L.control "RESOLVED")))
 (let (($x32601 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x48581 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x48583 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x48591 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x91279 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x25865 (not v_1_L.rxudp_require_checksum)))
 (let (($x48599 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x46823 (= v_1_L.ip_checksum 0)))
 (let (($x46824 (= v_1_L.udp_checksum 0)))
 (let (($x46827 (= v_1_L.udp_raw_checksum 0)))
 (let (($x46834 (= v_1_L.ip_length 0)))
 (let (($x46832 (= v_1_L.udp_length 0)))
 (let (($x53191 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x48598 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x53571 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x48597 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x48593 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x53192 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x48600 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x46839 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x30785 (= 0 v_1_L.retry_count)))
 (let ((?x48622 (seq.unit (_ bv0 8))))
 (let ((?x3595 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.unit (_ bv2 8))))))))
 (let ((?x48623 (seq.unit (_ bv2 8))))
 (let ((?x32577 (seq.++ ?x48623 ?x3595)))
 (let (($x49979 (= v_1_L.peer_mac ?x32577)))
 (let (($x30784 (= 0 state_1)))
 (let (($x3516 (not active_0_T.time_wait)))
 (let (($x77328 (or $x3516 (not (<= due_0_T.time_wait 0)))))
 (let (($x32999 (not active_0_T.user)))
 (let (($x63088 (or $x32999 (not (<= due_0_T.user 0)))))
 (let (($x3573 (not active_0_T.rtx)))
 (let (($x30574 (or $x3573 (not (<= due_0_T.rtx 0)))))
 (let (($x32906 (not active_0_L.cache)))
 (let (($x56316 (or $x32906 (not (<= due_0_L.cache 0)))))
 (let (($x49911 (not active_0_L.query)))
 (let (($x56140 (or $x49911 (not (<= due_0_L.query 0)))))
 (let (($x32855 (= state_0 0)))
 (and $x32855 (>= 0 now_0) $x56140 $x56316 $x30574 $x63088 $x77328 $x30784 $x49979 $x30785 $x46839 v_1_L.checksums_enabled $x48600 $x53192 $x48593 $x48597 $x53571 $x48598 $x53191 $x46832 $x46834 $x46827 $x46824 $x46823 $x48599 $x25865 $x91279 (= v_1_L.rxudp_disposition "none") $x48591 $x48583 $x48581 $x32601 (= v_1_L.echo_disposition "none") $x30875 $x61331 $x95162 $x125365 $x32857 $x52998 $x32540 $x53289 (= v_1_T.tx_flags "S") $x55594 $x95161 v_1_T.active_open $x55593 $x56635 $x49925 $x32981 $x48576 $x55503 $x46810 $x46809 $x56159 $x56158 $x30552 $x91191 $x49910 $x49918 $x49928 $x30551 $x8700 $x56154 (= v_1_T.wire_disposition "none") $x26035 (= v_1_ip_pending_owner "none") $x53569 active_1_L.cache $x50288 $x7149 $x56587 $x56588 $x63651 $x32535 $x56606 $x12901))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x25624 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x25623 (= due_2_T.user due_1_T.user)))
 (let (($x25622 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x25621 (= due_2_L.cache due_1_L.cache)))
 (let (($x25620 (= due_2_L.query due_1_L.query)))
 (let (($x25619 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x25618 (= active_2_T.user active_1_T.user)))
 (let (($x25617 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x46837 (not active_2_L.cache)))
 (let (($x25615 (= active_2_L.query active_1_L.query)))
 (let (($x25614 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x25613 (= v_2_T.control v_1_T.control)))
 (let (($x25612 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x25611 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x25610 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x25609 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x25608 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x25607 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x25606 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x25605 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x25604 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x25603 (= v_2_T.take v_1_T.take)))
 (let (($x25602 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x25601 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x25600 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x25599 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x25598 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x25597 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x25596 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x25595 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x25594 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x25593 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x25592 (= v_2_T.retries v_1_T.retries)))
 (let (($x25591 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x25590 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x25589 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x25588 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x25587 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x25586 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x25585 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x25584 (= v_2_T.irs v_1_T.irs)))
 (let (($x25583 (= v_2_T.iss v_1_T.iss)))
 (let (($x25582 (= v_2_L.control "EMPTY")))
 (let (($x25581 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x25580 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x25579 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x25578 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x25577 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x25576 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x25575 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x25574 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x25573 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x25572 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x25571 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x25570 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x25569 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x25568 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x25567 (= v_2_L.packet v_1_L.packet)))
 (let (($x25566 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x25565 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x25564 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x25563 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x25562 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x25561 (= v_2_L.payload v_1_L.payload)))
 (let (($x25560 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x25559 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x25558 (= 0 v_2_L.retry_count)))
 (let (($x46836 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.peer_mac)))
 (let (($x25556 (= 0 state_2)))
 (let (($x30875 (= v_1_L.control "RESOLVED")))
 (let (($x56171 (= state_1 0)))
 (and $x56171 $x30875 active_1_L.cache (= 60000 due_1_L.cache) (or (not active_1_L.query) (<= due_1_L.cache due_1_L.query)) (or (not active_1_T.rtx) (<= due_1_L.cache due_1_T.rtx)) (or (not active_1_T.user) (<= due_1_L.cache due_1_T.user)) (or (not active_1_T.time_wait) (<= due_1_L.cache due_1_T.time_wait)) $x25556 $x46836 $x25558 $x25559 $x25560 $x25561 $x25562 $x25563 $x25564 $x25565 $x25566 $x25567 $x25568 $x25569 $x25570 $x25571 $x25572 $x25573 $x25574 $x25575 $x25576 $x25577 $x25578 $x25579 $x25580 $x25581 $x25582 $x25583 $x25584 $x25585 $x25586 $x25587 $x25588 $x25589 $x25590 $x25591 $x25592 $x25593 $x25594 $x25595 $x25596 $x25597 $x25598 $x25599 $x25600 $x25601 $x25602 $x25603 $x25604 $x25605 $x25606 $x25607 $x25608 $x25609 $x25610 $x25611 $x25612 $x25613 $x25614 $x25615 $x46837 $x25617 $x25618 $x25619 $x25620 $x25621 $x25622 $x25623 $x25624)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x45180 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x45179 (= due_3_T.user due_2_T.user)))
 (let (($x45178 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x45177 (= due_3_L.cache due_2_L.cache)))
 (let (($x46842 (= due_3_L.query 61000)))
 (let (($x45175 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x45174 (= active_3_T.user active_2_T.user)))
 (let (($x45173 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x45172 (= active_3_L.cache active_2_L.cache)))
 (let (($x45170 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x45169 (= v_3_T.control v_2_T.control)))
 (let (($x45168 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x45167 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x45166 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x45165 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x45164 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x45163 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x45162 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x45161 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x45160 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x45159 (= v_3_T.take v_2_T.take)))
 (let (($x45158 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x45157 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x45156 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x45155 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x45154 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x45153 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x45152 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x45151 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x45150 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x45149 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x45148 (= v_3_T.retries v_2_T.retries)))
 (let (($x45147 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x45146 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x45145 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x45144 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x45143 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x45142 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x45141 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x45140 (= v_3_T.irs v_2_T.irs)))
 (let (($x45139 (= v_3_T.iss v_2_T.iss)))
 (let (($x45138 (= v_3_L.control "PENDING")))
 (let (($x45137 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x45136 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x45135 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x45134 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x45133 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x45132 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x45131 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x45130 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x45129 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x45128 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x45127 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x45126 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x45125 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x45124 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x45123 (= v_3_L.packet v_2_L.packet)))
 (let (($x45122 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x45121 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x45120 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x45119 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x45118 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x45117 (= v_3_L.payload v_2_L.payload)))
 (let (($x45116 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x45115 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x45114 (= 0 v_3_L.retry_count)))
 (let (($x45113 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x45112 (= 0 state_3)))
 (let (($x46841 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 60000)))))
 (let (($x46857 (or (not active_2_T.user) (not (<= due_2_T.user 60000)))))
 (let (($x46859 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 60000)))))
 (let (($x46837 (not active_2_L.cache)))
 (let (($x46863 (or $x46837 (not (<= due_2_L.cache 60000)))))
 (let (($x56118 (or (not active_2_L.query) (not (<= due_2_L.query 60000)))))
 (let (($x25582 (= v_2_L.control "EMPTY")))
 (let (($x61330 (= state_2 0)))
 (and $x61330 $x25582 $x56118 $x46863 $x46859 $x46857 $x46841 $x45112 $x45113 $x45114 $x45115 $x45116 $x45117 $x45118 $x45119 $x45120 $x45121 $x45122 $x45123 $x45124 $x45125 $x45126 $x45127 $x45128 $x45129 $x45130 $x45131 $x45132 $x45133 $x45134 $x45135 $x45136 $x45137 $x45138 $x45139 $x45140 $x45141 $x45142 $x45143 $x45144 $x45145 $x45146 $x45147 $x45148 $x45149 $x45150 $x45151 $x45152 $x45153 $x45154 $x45155 $x45156 $x45157 $x45158 $x45159 $x45160 $x45161 $x45162 $x45163 $x45164 $x45165 $x45166 $x45167 $x45168 $x45169 $x45170 active_3_L.query $x45172 $x45173 $x45174 $x45175 $x46842 $x45177 $x45178 $x45179 $x45180))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x32963 (seq.unit (_ bv192 8))))
 (let ((?x3787 (seq.++ ?x32963 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x30736 (seq.unit (_ bv1 8))))
 (let ((?x48622 (seq.unit (_ bv0 8))))
 (let ((?x72363 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x30736 ?x3787)))))))
 (let ((?x48623 (seq.unit (_ bv2 8))))
 (let ((?x66885 (seq.++ ?x32963 (seq.++ ?x48622 (seq.++ ?x48623 (seq.++ ?x48623 (seq.++ ?x48623 ?x72363)))))))
 (let ((?x13676 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48623 ?x66885)))))))
 (let ((?x50203 (seq.unit (_ bv4 8))))
 (let ((?x97517 (seq.unit (_ bv6 8))))
 (let ((?x77361 (seq.++ ?x97517 (seq.++ ?x50203 (seq.++ ?x48622 (seq.++ ?x48623 (seq.++ ?x48623 ?x13676)))))))
 (let ((?x32600 (seq.unit (_ bv8 8))))
 (let ((?x66612 (seq.++ ?x97517 (seq.++ ?x48622 (seq.++ ?x30736 (seq.++ ?x32600 (seq.++ ?x48622 ?x77361)))))))
 (let ((?x89875 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x48623 (seq.++ ?x32600 ?x66612)))))))
 (let ((?x88852 (seq.++ ?x48622 (seq.++ ?x48622 (seq.++ ?x30736 (seq.++ ?x48623 (seq.++ ?x48622 ?x89875)))))))
 (let ((?x87827 (seq.++ ?x48623 (seq.++ ?x48622 (seq.++ ?x48622 ?x88852)))))
 (= input_0_L.net.frame_frame ?x87827))))))))))))))))))
(assert
 (= 4 choice_1))
(assert
 (= 60000 now_2))
(assert
 (= 0 choice_2))
(assert
 (= 60000 now_3))
(assert
 (let ((?x32963 (seq.unit (_ bv192 8))))
(let ((?x30835 (seq.++ ?x32963 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x30835))))
(check-sat)

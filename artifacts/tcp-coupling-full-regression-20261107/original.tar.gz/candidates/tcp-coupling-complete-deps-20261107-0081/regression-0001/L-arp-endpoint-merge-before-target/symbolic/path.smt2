; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x51722 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x52943 (= due_1_T.user due_0_T.user)))
 (let (($x51721 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x56627 (= due_1_L.cache 60000)))
 (let (($x51720 (= due_1_L.query due_0_L.query)))
 (let (($x12836 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x51719 (= active_1_T.user active_0_T.user)))
 (let (($x53032 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x56630 (not active_1_L.query)))
 (let (($x95526 (= v_1_T.control "CLOSED")))
 (let (($x32868 (= v_1_T.wire_flags 0)))
 (let (($x56629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x80632 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x56622 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x56621 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x53178 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x3818 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x3817 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3833 (= v_1_T.take 0)))
 (let (($x3836 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3838 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x32874 (= v_1_T.snd_wnd 8)))
 (let (($x56656 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x56655 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x80633 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x32870 (= v_1_T.local_window 16)))
 (let (($x32871 (= v_1_T.msl_ms 60000)))
 (let (($x3782 (= v_1_T.user_timeout_ms 30000)))
 (let (($x85801 (= v_1_T.retries 0)))
 (let (($x66313 (= v_1_T.rto_ms 1000)))
 (let (($x32744 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x32746 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x32994 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x12949 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x12687 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x32552 (= v_1_T.irs (_ bv0 32))))
 (let (($x32609 (= v_1_T.iss (_ bv1000 32))))
 (let (($x12597 (= v_1_L.control "RESOLVED")))
 (let (($x56642 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x56643 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x3832 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x3831 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x3815 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x95370 (not v_1_L.rxudp_require_checksum)))
 (let (($x75756 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x32750 (= v_1_L.ip_checksum 0)))
 (let (($x32666 (= v_1_L.udp_checksum 0)))
 (let (($x32751 (= v_1_L.udp_raw_checksum 0)))
 (let (($x32752 (= v_1_L.ip_length 0)))
 (let (($x32753 (= v_1_L.udp_length 0)))
 (let (($x75755 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x53190 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x56651 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x56648 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x56647 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x52893 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x32973 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x3861 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x56027 (= 0 v_1_L.retry_count)))
 (let ((?x3522 (seq.unit (_ bv0 8))))
 (let ((?x53571 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.unit (_ bv2 8))))))))
 (let ((?x3516 (seq.unit (_ bv2 8))))
 (let ((?x53572 (seq.++ ?x3516 ?x53571)))
 (let (($x3848 (= v_1_L.peer_mac ?x53572)))
 (let (($x78855 (= 0 state_1)))
 (let (($x97326 (not active_0_T.time_wait)))
 (let (($x3847 (or $x97326 (not (<= due_0_T.time_wait 0)))))
 (let (($x12633 (not active_0_T.user)))
 (let (($x56633 (or $x12633 (not (<= due_0_T.user 0)))))
 (let (($x8769 (not active_0_T.rtx)))
 (let (($x3804 (or $x8769 (not (<= due_0_T.rtx 0)))))
 (let (($x97611 (not active_0_L.cache)))
 (let (($x32980 (or $x97611 (not (<= due_0_L.cache 0)))))
 (let (($x52938 (not active_0_L.query)))
 (let (($x3864 (or $x52938 (not (<= due_0_L.query 0)))))
 (let (($x5514 (= state_0 0)))
 (and $x5514 (>= 0 now_0) $x3864 $x32980 $x3804 $x56633 $x3847 $x78855 $x3848 $x56027 $x3861 v_1_L.checksums_enabled $x32973 $x52893 $x56647 $x56648 $x56651 $x53190 $x75755 $x32753 $x32752 $x32751 $x32666 $x32750 $x75756 $x95370 $x3815 (= v_1_L.rxudp_disposition "none") $x3831 $x3832 $x56643 $x56642 (= v_1_L.echo_disposition "none") $x12597 $x32609 $x32552 $x12687 $x12949 $x32994 $x32746 $x32744 (= v_1_T.tx_flags "S") $x66313 $x85801 v_1_T.active_open $x3782 $x32871 $x32870 $x80633 $x56655 $x56656 $x32874 $x3838 $x3836 $x3833 $x3817 $x3818 $x53178 $x56621 $x56622 $x80632 $x56629 $x32868 (= v_1_T.wire_disposition "none") $x95526 (= v_1_ip_pending_owner "none") $x56630 active_1_L.cache $x53032 $x51719 $x12836 $x51720 $x56627 $x51721 $x52943 $x51722))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x95198 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x95197 (= due_2_T.user due_1_T.user)))
 (let (($x95196 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x95194 (= due_2_L.query due_1_L.query)))
 (let (($x95193 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x95192 (= active_2_T.user active_1_T.user)))
 (let (($x95191 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x95189 (= active_2_L.query active_1_L.query)))
 (let (($x95188 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x95187 (= v_2_T.control v_1_T.control)))
 (let (($x95186 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x95185 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x95184 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x95183 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x95182 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x95181 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x95180 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x95179 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x95178 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x95177 (= v_2_T.take v_1_T.take)))
 (let (($x95176 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x95175 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x95174 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x95173 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x95172 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x95171 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x95170 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x95169 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x95168 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x95167 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x95166 (= v_2_T.retries v_1_T.retries)))
 (let (($x95165 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x95164 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x95163 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x95162 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x95161 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x95160 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x95159 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x95158 (= v_2_T.irs v_1_T.irs)))
 (let (($x95157 (= v_2_T.iss v_1_T.iss)))
 (let (($x95156 (= v_2_L.control "RESOLVED")))
 (let (($x95155 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x95154 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x95153 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x95152 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x95151 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x95150 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x95149 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x95148 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x95147 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x95146 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x95145 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x95144 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x95143 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x95142 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x95141 (= v_2_L.packet v_1_L.packet)))
 (let (($x95140 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x95139 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x95138 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x95137 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x95136 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x95135 (= v_2_L.payload v_1_L.payload)))
 (let (($x95134 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x95133 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x95132 (= v_2_L.retry_count v_1_L.retry_count)))
 (let ((?x3522 (seq.unit (_ bv0 8))))
 (let ((?x32665 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.unit (_ bv3 8))))))))
 (let ((?x3516 (seq.unit (_ bv2 8))))
 (let (($x56637 (= v_2_L.peer_mac (seq.++ ?x3516 ?x32665))))
 (let (($x95130 (= 0 state_2)))
 (let (($x56632 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x56624 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x87679 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x3812 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x56630 (not active_1_L.query)))
 (let (($x3813 (or $x56630 (not (<= due_1_L.query 10)))))
 (let (($x12597 (= v_1_L.control "RESOLVED")))
 (let (($x32743 (= state_1 0)))
 (and $x32743 $x12597 $x3813 $x3812 $x87679 $x56624 $x56632 $x95130 $x56637 $x95132 $x95133 $x95134 $x95135 $x95136 $x95137 $x95138 $x95139 $x95140 $x95141 $x95142 $x95143 $x95144 $x95145 $x95146 $x95147 $x95148 $x95149 $x95150 $x95151 $x95152 $x95153 $x95154 $x95155 $x95156 $x95157 $x95158 $x95159 $x95160 $x95161 $x95162 $x95163 $x95164 $x95165 $x95166 $x95167 $x95168 $x95169 $x95170 $x95171 $x95172 $x95173 $x95174 $x95175 $x95176 $x95177 $x95178 $x95179 $x95180 $x95181 $x95182 $x95183 $x95184 $x95185 $x95186 $x95187 $x95188 $x95189 active_2_L.cache $x95191 $x95192 $x95193 $x95194 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x95196 $x95197 $x95198))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x49969 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x49968 (= due_3_T.user due_2_T.user)))
 (let (($x50163 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x50162 (= due_3_L.cache due_2_L.cache)))
 (let (($x3588 (= due_3_L.query due_2_L.query)))
 (let (($x50311 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x50125 (= active_3_T.user active_2_T.user)))
 (let (($x50124 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x49992 (= active_3_L.cache active_2_L.cache)))
 (let (($x49991 (= active_3_L.query active_2_L.query)))
 (let (($x49985 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x49984 (= v_3_T.control v_2_T.control)))
 (let (($x50143 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x50142 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x50075 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x50074 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x50009 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x50008 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x50135 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x50134 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x50353 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x50352 (= v_3_T.take v_2_T.take)))
 (let (($x50077 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x50076 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x52883 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x12856 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x50316 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x50119 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x49978 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x50288 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x50217 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x50313 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x51698 (= v_3_T.retries v_2_T.retries)))
 (let (($x3499 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x50195 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x50194 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x49998 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x49997 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x50295 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x50291 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x49999 (= v_3_T.irs v_2_T.irs)))
 (let (($x50145 (= v_3_T.iss v_2_T.iss)))
 (let (($x49951 (= v_3_L.control "RESOLVED")))
 (let (($x49950 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x50098 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x50097 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x49953 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x49952 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x49994 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x49993 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x50001 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x50000 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x51700 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x34993 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x51674 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x8736 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x50126 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x50139 (= v_3_L.packet v_2_L.packet)))
 (let (($x8707 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x52928 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x50148 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x50225 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x49959 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x49958 (= v_3_L.payload v_2_L.payload)))
 (let (($x50156 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x50219 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x50206 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x50205 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x50203 (= 0 state_3)))
 (let (($x32878 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x3794 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x32879 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x81329 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x32877 (or (not active_2_L.query) (not (<= due_2_L.query 20)))))
 (let (($x95156 (= v_2_L.control "RESOLVED")))
 (let (($x3856 (= state_2 0)))
 (and $x3856 $x95156 $x32877 $x81329 $x32879 $x3794 $x32878 $x50203 $x50205 $x50206 $x50219 $x50156 $x49958 $x49959 $x50225 $x50148 $x52928 $x8707 $x50139 $x50126 $x8736 $x51674 $x34993 $x51700 $x50000 $x50001 $x49993 $x49994 $x49952 $x49953 $x50097 $x50098 $x49950 $x49951 $x50145 $x49999 $x50291 $x50295 $x49997 $x49998 $x50194 $x50195 $x3499 $x51698 $x50313 $x50217 $x50288 $x49978 $x50119 $x50316 $x12856 $x52883 $x50076 $x50077 $x50352 $x50353 $x50134 $x50135 $x50008 $x50009 $x50074 $x50075 $x50142 $x50143 $x49984 $x49985 $x49991 $x49992 $x50124 $x50125 $x50311 $x3588 $x50162 $x50163 $x49968 $x49969))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x3527 (seq.unit (_ bv192 8))))
 (let ((?x32608 (seq.++ ?x3527 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x3522 (seq.unit (_ bv0 8))))
 (let ((?x30858 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 ?x32608)))))))
 (let ((?x3516 (seq.unit (_ bv2 8))))
 (let ((?x12992 (seq.++ ?x3527 (seq.++ ?x3522 (seq.++ ?x3516 (seq.++ ?x3516 (seq.++ ?x3522 ?x30858)))))))
 (let ((?x55504 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3516 ?x12992)))))))
 (let ((?x3565 (seq.unit (_ bv1 8))))
 (let ((?x52966 (seq.unit (_ bv4 8))))
 (let ((?x3602 (seq.unit (_ bv6 8))))
 (let ((?x55529 (seq.++ ?x3602 (seq.++ ?x52966 (seq.++ ?x3522 (seq.++ ?x3565 (seq.++ ?x3516 ?x55504)))))))
 (let ((?x32601 (seq.unit (_ bv8 8))))
 (let ((?x65368 (seq.++ ?x3602 (seq.++ ?x3522 (seq.++ ?x3565 (seq.++ ?x32601 (seq.++ ?x3522 ?x55529)))))))
 (let ((?x34793 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3516 (seq.++ ?x32601 ?x65368)))))))
 (let ((?x32592 (seq.unit (_ bv255 8))))
 (let ((?x12997 (seq.++ ?x32592 (seq.++ ?x32592 (seq.++ ?x32592 (seq.++ ?x3516 (seq.++ ?x3522 ?x34793)))))))
 (let ((?x53275 (seq.++ ?x32592 (seq.++ ?x32592 (seq.++ ?x32592 ?x12997)))))
 (= input_0_L.net.frame_frame ?x53275)))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x3527 (seq.unit (_ bv192 8))))
 (let ((?x208 (seq.++ ?x3527 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x3522 (seq.unit (_ bv0 8))))
 (let ((?x12598 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 ?x208)))))))
 (let ((?x3516 (seq.unit (_ bv2 8))))
 (let ((?x91475 (seq.++ ?x3527 (seq.++ ?x3522 (seq.++ ?x3516 (seq.++ ?x3516 (seq.++ ?x3522 ?x12598)))))))
 (let ((?x52909 (seq.unit (_ bv3 8))))
 (let ((?x12615 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x52909 ?x91475)))))))
 (let ((?x3565 (seq.unit (_ bv1 8))))
 (let ((?x52966 (seq.unit (_ bv4 8))))
 (let ((?x3602 (seq.unit (_ bv6 8))))
 (let ((?x91146 (seq.++ ?x3602 (seq.++ ?x52966 (seq.++ ?x3522 (seq.++ ?x3565 (seq.++ ?x3516 ?x12615)))))))
 (let ((?x32601 (seq.unit (_ bv8 8))))
 (let ((?x55505 (seq.++ ?x3602 (seq.++ ?x3522 (seq.++ ?x3565 (seq.++ ?x32601 (seq.++ ?x3522 ?x91146)))))))
 (let ((?x55503 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x3522 (seq.++ ?x52909 (seq.++ ?x32601 ?x55505)))))))
 (let ((?x32592 (seq.unit (_ bv255 8))))
 (let ((?x53235 (seq.++ ?x32592 (seq.++ ?x32592 (seq.++ ?x32592 (seq.++ ?x3516 (seq.++ ?x3522 ?x55503)))))))
 (let ((?x12941 (seq.++ ?x32592 (seq.++ ?x32592 (seq.++ ?x32592 ?x53235)))))
 (= input_1_L.net.frame_frame ?x12941))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x3527 (seq.unit (_ bv192 8))))
(let ((?x3510 (seq.++ ?x3527 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x3510))))
(check-sat)

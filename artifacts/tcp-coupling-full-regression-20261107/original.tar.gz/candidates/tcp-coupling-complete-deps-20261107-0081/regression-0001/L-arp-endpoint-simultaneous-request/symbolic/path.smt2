; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x51705 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x53076 (= due_1_T.user due_0_T.user)))
 (let (($x12823 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x51704 (= due_1_L.cache due_0_L.cache)))
 (let (($x26705 (= due_1_L.query 1000)))
 (let (($x63313 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x51703 (= active_1_T.user active_0_T.user)))
 (let (($x53053 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x63125 (= active_1_L.cache active_0_L.cache)))
 (let (($x33106 (= v_1_T.control "CLOSED")))
 (let (($x68755 (= v_1_T.wire_flags 0)))
 (let (($x63806 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x9516 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x125462 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x8768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x8771 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x63774 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x72979 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3578 (= v_1_T.take 0)))
 (let (($x3579 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3581 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x56989 (= v_1_T.snd_wnd 8)))
 (let (($x86096 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x83882 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x52772 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x8684 (= v_1_T.local_window 16)))
 (let (($x3513 (= v_1_T.msl_ms 60000)))
 (let (($x65528 (= v_1_T.user_timeout_ms 30000)))
 (let (($x3509 (= v_1_T.retries 0)))
 (let (($x3510 (= v_1_T.rto_ms 1000)))
 (let (($x3515 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x3516 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3521 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x3522 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x3527 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x3528 (= v_1_T.irs (_ bv0 32))))
 (let (($x3529 (= v_1_T.iss (_ bv1000 32))))
 (let (($x51676 (= v_1_L.control "PENDING")))
 (let (($x86094 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x84658 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x77039 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x8683 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x84659 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x93934 (not v_1_L.rxudp_require_checksum)))
 (let (($x12859 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x3544 (= v_1_L.ip_checksum 0)))
 (let (($x3547 (= v_1_L.udp_checksum 0)))
 (let (($x3550 (= v_1_L.udp_raw_checksum 0)))
 (let (($x3551 (= v_1_L.ip_length 0)))
 (let (($x3555 (= v_1_L.udp_length 0)))
 (let (($x90999 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x53358 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x12648 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x3549 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x3548 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x3559 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x3560 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x52773 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x51668 (= 0 v_1_L.retry_count)))
 (let (($x97321 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x97606 (= 0 state_1)))
 (let (($x12633 (not active_0_T.time_wait)))
 (let (($x8678 (or $x12633 (not (<= due_0_T.time_wait 0)))))
 (let (($x52938 (not active_0_T.user)))
 (let (($x8769 (or $x52938 (not (<= due_0_T.user 0)))))
 (let (($x30802 (not active_0_T.rtx)))
 (let (($x8679 (or $x30802 (not (<= due_0_T.rtx 0)))))
 (let (($x12687 (not active_0_L.cache)))
 (let (($x74456 (or $x12687 (not (<= due_0_L.cache 0)))))
 (let (($x12943 (not active_0_L.query)))
 (let (($x32609 (or $x12943 (not (<= due_0_L.query 0)))))
 (let (($x53176 (= state_0 0)))
 (and $x53176 (>= 0 now_0) $x32609 $x74456 $x8679 $x8769 $x8678 $x97606 $x97321 $x51668 $x52773 v_1_L.checksums_enabled $x3560 $x3559 $x3548 $x3549 $x12648 $x53358 $x90999 $x3555 $x3551 $x3550 $x3547 $x3544 $x12859 $x93934 $x84659 (= v_1_L.rxudp_disposition "none") $x8683 $x77039 $x84658 $x86094 (= v_1_L.echo_disposition "none") $x51676 $x3529 $x3528 $x3527 $x3522 $x3521 $x3516 $x3515 (= v_1_T.tx_flags "S") $x3510 $x3509 v_1_T.active_open $x65528 $x3513 $x8684 $x52772 $x83882 $x86096 $x56989 $x3581 $x3579 $x3578 $x72979 $x63774 $x8771 $x8768 $x125462 $x9516 $x63806 $x68755 (= v_1_T.wire_disposition "none") $x33106 (= v_1_ip_pending_owner "none") active_1_L.query $x63125 $x53053 $x51703 $x63313 $x26705 $x51704 $x12823 $x53076 $x51705))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x12892 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x12695 (= due_2_T.user due_1_T.user)))
 (let (($x32943 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x32718 (= due_2_L.query due_1_L.query)))
 (let (($x32717 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x32911 (= active_2_T.user active_1_T.user)))
 (let (($x32910 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x2398 (not active_2_L.query)))
 (let (($x32636 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x32635 (= v_2_T.control v_1_T.control)))
 (let (($x32907 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x32906 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x32620 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x52661 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x13060 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x12949 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x32688 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x32687 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x32947 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x32946 (= v_2_T.take v_1_T.take)))
 (let (($x32571 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x32570 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x52911 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x65459 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x32785 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x32784 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x5533 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x52833 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x52893 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x52821 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x32622 (= v_2_T.retries v_1_T.retries)))
 (let (($x32621 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x32682 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x32681 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32771 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32648 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32647 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x12646 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x13085 (= v_2_T.irs v_1_T.irs)))
 (let (($x32893 (= v_2_T.iss v_1_T.iss)))
 (let (($x32892 (= v_2_L.control "RESOLVED")))
 (let (($x32925 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x32924 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x32799 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x32798 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x32696 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x32695 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32686 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32685 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x32833 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x32832 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x32801 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x32800 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x52805 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x5546 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x1708 (= v_2_L.packet v_1_L.packet)))
 (let (($x8680 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x32805 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x32804 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x32949 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32948 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x32730 (= v_2_L.payload v_1_L.payload)))
 (let (($x32729 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x32797 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x32796 (= 0 v_2_L.retry_count)))
 (let ((?x52950 (seq.unit (_ bv0 8))))
 (let ((?x3562 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.unit (_ bv3 8))))))))
 (let ((?x53092 (seq.unit (_ bv2 8))))
 (let (($x53073 (= v_2_L.peer_mac (seq.++ ?x53092 ?x3562))))
 (let (($x52789 (= 0 state_2)))
 (let (($x31844 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x12612 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x3618 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x91019 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x32585 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x32641 (seq.len v_1_L.pending_packet)))
 (let (($x32564 (= 0 ?x32641)))
 (let (($x51676 (= v_1_L.control "PENDING")))
 (let (($x68719 (= state_1 0)))
 (and $x68719 $x51676 $x32564 $x32585 $x91019 $x3618 $x12612 $x31844 $x52789 $x53073 $x32796 $x32797 $x32729 $x32730 $x32948 $x32949 $x32804 $x32805 $x8680 $x1708 $x5546 $x52805 $x32800 $x32801 $x32832 $x32833 $x32685 $x32686 $x32695 $x32696 $x32798 $x32799 $x32924 $x32925 $x32892 $x32893 $x13085 $x12646 $x32647 $x32648 $x32771 $x32681 $x32682 $x32621 $x32622 $x52821 $x52893 $x52833 $x5533 $x32784 $x32785 $x65459 $x52911 $x32570 $x32571 $x32946 $x32947 $x32687 $x32688 $x12949 $x13060 $x52661 $x32620 $x32906 $x32907 $x32635 $x32636 $x2398 active_2_L.cache $x32910 $x32911 $x32717 $x32718 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x32943 $x12695 $x12892)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x8786 (seq.unit (_ bv192 8))))
 (let ((?x12650 (seq.++ ?x8786 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x12650))))
(assert
 (= 28 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x8786 (seq.unit (_ bv192 8))))
(let ((?x8735 (seq.++ ?x8786 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x52950 (seq.unit (_ bv0 8))))
(let ((?x49908 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 ?x8735)))))))
(let ((?x53092 (seq.unit (_ bv2 8))))
(let ((?x49913 (seq.++ ?x8786 (seq.++ ?x52950 (seq.++ ?x53092 (seq.++ ?x53092 (seq.++ ?x52950 ?x49908)))))))
(let ((?x49903 (seq.unit (_ bv3 8))))
(let ((?x49918 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x49903 ?x49913)))))))
(let ((?x13026 (seq.unit (_ bv1 8))))
(let ((?x7176 (seq.unit (_ bv4 8))))
(let ((?x97425 (seq.unit (_ bv6 8))))
(let ((?x49923 (seq.++ ?x97425 (seq.++ ?x7176 (seq.++ ?x52950 (seq.++ ?x13026 (seq.++ ?x53092 ?x49918)))))))
(let ((?x63651 (seq.unit (_ bv8 8))))
(let ((?x49928 (seq.++ ?x97425 (seq.++ ?x52950 (seq.++ ?x13026 (seq.++ ?x63651 (seq.++ ?x52950 ?x49923)))))))
(let ((?x49933 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x52950 (seq.++ ?x49903 (seq.++ ?x63651 ?x49928)))))))
(let ((?x13039 (seq.unit (_ bv255 8))))
(let ((?x49938 (seq.++ ?x13039 (seq.++ ?x13039 (seq.++ ?x13039 (seq.++ ?x53092 (seq.++ ?x52950 ?x49933)))))))
(let ((?x49941 (seq.++ ?x13039 (seq.++ ?x13039 (seq.++ ?x13039 ?x49938)))))
(= input_1_L.net.frame_frame ?x49941))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x30551 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x49928 (= due_1_T.user due_0_T.user)))
 (let (($x49918 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x55842 (= due_1_L.cache 60000)))
 (let (($x91191 (= due_1_L.query due_0_L.query)))
 (let (($x30552 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x56158 (= active_1_T.user active_0_T.user)))
 (let (($x56159 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x3856 (not active_1_L.query)))
 (let (($x58610 (= v_1_T.control "CLOSED")))
 (let (($x55859 (= v_1_T.wire_flags 0)))
 (let (($x45155 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x55798 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x55800 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x55802 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x55801 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x55839 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x55794 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x97827 (= v_1_T.take 0)))
 (let (($x97828 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x97830 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x55864 (= v_1_T.snd_wnd 8)))
 (let (($x55793 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x12941 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x97810 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x55862 (= v_1_T.local_window 16)))
 (let (($x51151 (= v_1_T.msl_ms 60000)))
 (let (($x55786 (= v_1_T.user_timeout_ms 30000)))
 (let (($x55787 (= v_1_T.retries 0)))
 (let (($x55788 (= v_1_T.rto_ms 1000)))
 (let (($x45132 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x12644 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x91463 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x45133 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x55392 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x48578 (= v_1_T.irs (_ bv0 32))))
 (let (($x45134 (= v_1_T.iss (_ bv1000 32))))
 (let (($x53571 (= v_1_L.control "RESOLVED")))
 (let (($x97809 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x55828 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x55827 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x55815 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x55814 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x58448 (not v_1_L.rxudp_require_checksum)))
 (let (($x97824 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x55795 (= v_1_L.ip_checksum 0)))
 (let (($x55796 (= v_1_L.udp_checksum 0)))
 (let (($x55797 (= v_1_L.udp_raw_checksum 0)))
 (let (($x55799 (= v_1_L.ip_length 0)))
 (let (($x55803 (= v_1_L.udp_length 0)))
 (let (($x97823 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x97807 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x47005 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x47004 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x14376 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x55823 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x55820 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x55818 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x53275 (= 0 v_1_L.retry_count)))
 (let ((?x56107 (seq.unit (_ bv0 8))))
 (let ((?x52769 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.unit (_ bv2 8))))))))
 (let ((?x53569 (seq.unit (_ bv2 8))))
 (let ((?x3831 (seq.++ ?x53569 ?x52769)))
 (let (($x55819 (= v_1_L.peer_mac ?x3831)))
 (let (($x3618 (= 0 state_1)))
 (let (($x45168 (not active_0_T.time_wait)))
 (let (($x45130 (or $x45168 (not (<= due_0_T.time_wait 0)))))
 (let (($x30579 (not active_0_T.user)))
 (let (($x97839 (or $x30579 (not (<= due_0_T.user 0)))))
 (let (($x32982 (not active_0_T.rtx)))
 (let (($x55805 (or $x32982 (not (<= due_0_T.rtx 0)))))
 (let (($x45166 (not active_0_L.cache)))
 (let (($x97796 (or $x45166 (not (<= due_0_L.cache 0)))))
 (let (($x65368 (not active_0_L.query)))
 (let (($x30555 (or $x65368 (not (<= due_0_L.query 0)))))
 (let (($x46837 (= state_0 0)))
 (and $x46837 (>= 0 now_0) $x30555 $x97796 $x55805 $x97839 $x45130 $x3618 $x55819 $x53275 $x55818 v_1_L.checksums_enabled $x55820 $x55823 $x14376 $x47004 $x47005 $x97807 $x97823 $x55803 $x55799 $x55797 $x55796 $x55795 $x97824 $x58448 $x55814 (= v_1_L.rxudp_disposition "none") $x55815 $x55827 $x55828 $x97809 (= v_1_L.echo_disposition "none") $x53571 $x45134 $x48578 $x55392 $x45133 $x91463 $x12644 $x45132 (= v_1_T.tx_flags "S") $x55788 $x55787 v_1_T.active_open $x55786 $x51151 $x55862 $x97810 $x12941 $x55793 $x55864 $x97830 $x97828 $x97827 $x55794 $x55839 $x55801 $x55802 $x55800 $x55798 $x45155 $x55859 (= v_1_T.wire_disposition "none") $x58610 (= v_1_ip_pending_owner "none") $x3856 active_1_L.cache $x56159 $x56158 $x30552 $x91191 $x55842 $x49918 $x49928 $x30551))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x58276 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x58275 (= due_2_T.user due_1_T.user)))
 (let (($x58274 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x58272 (= due_2_L.query due_1_L.query)))
 (let (($x58271 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x58270 (= active_2_T.user active_1_T.user)))
 (let (($x58269 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x58267 (= active_2_L.query active_1_L.query)))
 (let (($x58266 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x58265 (= v_2_T.control v_1_T.control)))
 (let (($x58264 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x58263 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x58262 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x58261 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x58260 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x58259 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x58258 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x58257 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x58256 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x58255 (= v_2_T.take v_1_T.take)))
 (let (($x58254 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x58253 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x58252 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x58251 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x58250 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x58249 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x58248 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x58247 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x58246 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x58245 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x58244 (= v_2_T.retries v_1_T.retries)))
 (let (($x58243 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x58242 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x58241 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x58240 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x58239 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x58238 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x58237 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x58236 (= v_2_T.irs v_1_T.irs)))
 (let (($x58235 (= v_2_T.iss v_1_T.iss)))
 (let (($x58234 (= v_2_L.control "RESOLVED")))
 (let (($x58233 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x58232 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x58231 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x58230 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x58229 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x58228 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x58227 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x58226 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x58225 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x58224 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x58223 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x58222 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x58221 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x58220 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x58219 (= v_2_L.packet v_1_L.packet)))
 (let (($x58218 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x58217 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x58216 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x58215 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x58214 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x58213 (= v_2_L.payload v_1_L.payload)))
 (let (($x58212 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x58211 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x58210 (= v_2_L.retry_count v_1_L.retry_count)))
 (let ((?x56107 (seq.unit (_ bv0 8))))
 (let ((?x97805 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.unit (_ bv3 8))))))))
 (let ((?x53569 (seq.unit (_ bv2 8))))
 (let (($x97785 (= v_2_L.peer_mac (seq.++ ?x53569 ?x97805))))
 (let (($x58208 (= 0 state_2)))
 (let (($x97784 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 59999)))))
 (let (($x97780 (or (not active_1_T.user) (not (<= due_1_T.user 59999)))))
 (let (($x45118 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 59999)))))
 (let (($x55835 (or (not active_1_L.cache) (not (<= due_1_L.cache 59999)))))
 (let (($x3856 (not active_1_L.query)))
 (let (($x57117 (or $x3856 (not (<= due_1_L.query 59999)))))
 (let (($x53571 (= v_1_L.control "RESOLVED")))
 (let (($x55876 (= state_1 0)))
 (and $x55876 $x53571 $x57117 $x55835 $x45118 $x97780 $x97784 $x58208 $x97785 $x58210 $x58211 $x58212 $x58213 $x58214 $x58215 $x58216 $x58217 $x58218 $x58219 $x58220 $x58221 $x58222 $x58223 $x58224 $x58225 $x58226 $x58227 $x58228 $x58229 $x58230 $x58231 $x58232 $x58233 $x58234 $x58235 $x58236 $x58237 $x58238 $x58239 $x58240 $x58241 $x58242 $x58243 $x58244 $x58245 $x58246 $x58247 $x58248 $x58249 $x58250 $x58251 $x58252 $x58253 $x58254 $x58255 $x58256 $x58257 $x58258 $x58259 $x58260 $x58261 $x58262 $x58263 $x58264 $x58265 $x58266 $x58267 active_2_L.cache $x58269 $x58270 $x58271 $x58272 (= due_2_L.cache (+ 59999 v_1_L.cache_ttl_ms)) $x58274 $x58275 $x58276))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x43486 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x43485 (= due_3_T.user due_2_T.user)))
 (let (($x43484 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x43483 (= due_3_L.cache due_2_L.cache)))
 (let (($x43482 (= due_3_L.query due_2_L.query)))
 (let (($x43481 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x43480 (= active_3_T.user active_2_T.user)))
 (let (($x43479 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x43478 (= active_3_L.cache active_2_L.cache)))
 (let (($x43477 (= active_3_L.query active_2_L.query)))
 (let (($x43476 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x43475 (= v_3_T.control v_2_T.control)))
 (let (($x43474 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x43473 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x43472 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x43471 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x43470 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x43469 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x43468 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x43467 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x43466 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x43465 (= v_3_T.take v_2_T.take)))
 (let (($x43464 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x43463 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x43462 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x43461 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x43460 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x43459 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x43458 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x43457 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x43456 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x43455 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x43454 (= v_3_T.retries v_2_T.retries)))
 (let (($x43453 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x43452 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x43451 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x43450 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x43449 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x43448 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x43447 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x43446 (= v_3_T.irs v_2_T.irs)))
 (let (($x43445 (= v_3_T.iss v_2_T.iss)))
 (let (($x43444 (= v_3_L.control "RESOLVED")))
 (let (($x43443 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x43442 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x43441 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x43440 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x43439 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x43438 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x43437 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x43436 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x43435 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x43434 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x43433 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x43432 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x43431 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x43430 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x43429 (= v_3_L.packet v_2_L.packet)))
 (let (($x43428 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x43427 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x43426 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x43425 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x43424 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x43423 (= v_3_L.payload v_2_L.payload)))
 (let (($x43422 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x43421 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x43420 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x43419 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x43418 (= 0 state_3)))
 (let (($x45161 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 60001)))))
 (let (($x55885 (or (not active_2_T.user) (not (<= due_2_T.user 60001)))))
 (let (($x53084 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 60001)))))
 (let (($x55875 (or (not active_2_L.cache) (not (<= due_2_L.cache 60001)))))
 (let (($x63628 (or (not active_2_L.query) (not (<= due_2_L.query 60001)))))
 (let (($x58234 (= v_2_L.control "RESOLVED")))
 (let (($x97847 (= state_2 0)))
 (and $x97847 $x58234 $x63628 $x55875 $x53084 $x55885 $x45161 $x43418 $x43419 $x43420 $x43421 $x43422 $x43423 $x43424 $x43425 $x43426 $x43427 $x43428 $x43429 $x43430 $x43431 $x43432 $x43433 $x43434 $x43435 $x43436 $x43437 $x43438 $x43439 $x43440 $x43441 $x43442 $x43443 $x43444 $x43445 $x43446 $x43447 $x43448 $x43449 $x43450 $x43451 $x43452 $x43453 $x43454 $x43455 $x43456 $x43457 $x43458 $x43459 $x43460 $x43461 $x43462 $x43463 $x43464 $x43465 $x43466 $x43467 $x43468 $x43469 $x43470 $x43471 $x43472 $x43473 $x43474 $x43475 $x43476 $x43477 $x43478 $x43479 $x43480 $x43481 $x43482 $x43483 $x43484 $x43485 $x43486))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x50134 (seq.unit (_ bv192 8))))
 (let ((?x56123 (seq.++ ?x50134 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x30483 (seq.unit (_ bv1 8))))
 (let ((?x56107 (seq.unit (_ bv0 8))))
 (let ((?x32962 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x30483 ?x56123)))))))
 (let ((?x53569 (seq.unit (_ bv2 8))))
 (let ((?x90307 (seq.++ ?x50134 (seq.++ ?x56107 (seq.++ ?x53569 (seq.++ ?x53569 (seq.++ ?x53569 ?x32962)))))))
 (let ((?x75870 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x53569 ?x90307)))))))
 (let ((?x25596 (seq.unit (_ bv4 8))))
 (let ((?x25595 (seq.unit (_ bv6 8))))
 (let ((?x76381 (seq.++ ?x25595 (seq.++ ?x25596 (seq.++ ?x56107 (seq.++ ?x53569 (seq.++ ?x53569 ?x75870)))))))
 (let ((?x25594 (seq.unit (_ bv8 8))))
 (let ((?x77766 (seq.++ ?x25595 (seq.++ ?x56107 (seq.++ ?x30483 (seq.++ ?x25594 (seq.++ ?x56107 ?x76381)))))))
 (let ((?x67245 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x53569 (seq.++ ?x25594 ?x77766)))))))
 (let ((?x56709 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x30483 (seq.++ ?x53569 (seq.++ ?x56107 ?x67245)))))))
 (let ((?x72403 (seq.++ ?x53569 (seq.++ ?x56107 (seq.++ ?x56107 ?x56709)))))
 (= input_0_L.net.frame_frame ?x72403))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 59999 now_2))
(assert
 (let ((?x50134 (seq.unit (_ bv192 8))))
 (let ((?x61304 (seq.++ ?x50134 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x56107 (seq.unit (_ bv0 8))))
 (let ((?x61306 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 ?x61304)))))))
 (let ((?x53569 (seq.unit (_ bv2 8))))
 (let ((?x53036 (seq.++ ?x50134 (seq.++ ?x56107 (seq.++ ?x53569 (seq.++ ?x53569 (seq.++ ?x56107 ?x61306)))))))
 (let ((?x74902 (seq.unit (_ bv3 8))))
 (let ((?x90296 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x74902 ?x53036)))))))
 (let ((?x30483 (seq.unit (_ bv1 8))))
 (let ((?x25596 (seq.unit (_ bv4 8))))
 (let ((?x25595 (seq.unit (_ bv6 8))))
 (let ((?x46808 (seq.++ ?x25595 (seq.++ ?x25596 (seq.++ ?x56107 (seq.++ ?x30483 (seq.++ ?x53569 ?x90296)))))))
 (let ((?x25594 (seq.unit (_ bv8 8))))
 (let ((?x89956 (seq.++ ?x25595 (seq.++ ?x56107 (seq.++ ?x30483 (seq.++ ?x25594 (seq.++ ?x56107 ?x46808)))))))
 (let ((?x67787 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x56107 (seq.++ ?x74902 (seq.++ ?x25594 ?x89956)))))))
 (let ((?x30481 (seq.unit (_ bv255 8))))
 (let ((?x30870 (seq.++ ?x30481 (seq.++ ?x30481 (seq.++ ?x30481 (seq.++ ?x53569 (seq.++ ?x56107 ?x67787)))))))
 (let ((?x56169 (seq.++ ?x30481 (seq.++ ?x30481 (seq.++ ?x30481 ?x30870)))))
 (= input_1_L.net.frame_frame ?x56169))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 60001 now_3))
(assert
 (let ((?x50134 (seq.unit (_ bv192 8))))
(let ((?x56100 (seq.++ ?x50134 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_L.app.resolve_ip ?x56100))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x102874 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x37464 (= due_1_T.user due_0_T.user)))
 (let (($x102873 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x37463 (= due_1_L.cache due_0_L.cache)))
 (let (($x13017 (= due_1_L.query 1000)))
 (let (($x37462 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x9917 (= active_1_T.user active_0_T.user)))
 (let (($x37461 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x52610 (= active_1_L.cache active_0_L.cache)))
 (let (($x36127 (= v_1_T.control "CLOSED")))
 (let (($x64558 (= v_1_T.wire_flags 0)))
 (let (($x26644 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x12988 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x52793 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x12682 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x12573 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52993 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x12837 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x27495 (= v_1_T.take 0)))
 (let (($x27285 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x58214 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x90378 (= v_1_T.snd_wnd 8)))
 (let (($x63790 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x12533 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x12932 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x27290 (= v_1_T.local_window 16)))
 (let (($x27300 (= v_1_T.msl_ms 60000)))
 (let (($x82886 (= v_1_T.user_timeout_ms 30000)))
 (let (($x7265 (= v_1_T.retries 0)))
 (let (($x7266 (= v_1_T.rto_ms 1000)))
 (let (($x7264 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x7267 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x7268 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x7269 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x7270 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x7275 (= v_1_T.irs (_ bv0 32))))
 (let (($x7276 (= v_1_T.iss (_ bv1000 32))))
 (let (($x78721 (= v_1_L.control "PENDING")))
 (let (($x30859 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x52921 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63662 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x55394 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x2386 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x35957 (not v_1_L.rxudp_require_checksum)))
 (let (($x12963 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x7291 (= v_1_L.ip_checksum 0)))
 (let (($x7292 (= v_1_L.udp_checksum 0)))
 (let (($x7295 (= v_1_L.udp_raw_checksum 0)))
 (let (($x7298 (= v_1_L.ip_length 0)))
 (let (($x7299 (= v_1_L.udp_length 0)))
 (let (($x63184 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x65398 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x55448 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x52992 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x52813 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x32776 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x32787 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x97267 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x41103 (= 0 v_1_L.retry_count)))
 (let (($x32786 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x45456 (= 0 state_1)))
 (let (($x42480 (not active_0_T.time_wait)))
 (let (($x12872 (or $x42480 (not (<= due_0_T.time_wait 0)))))
 (let (($x64592 (not active_0_T.user)))
 (let (($x63169 (or $x64592 (not (<= due_0_T.user 0)))))
 (let (($x41163 (not active_0_T.rtx)))
 (let (($x52876 (or $x41163 (not (<= due_0_T.rtx 0)))))
 (let (($x535 (not active_0_L.cache)))
 (let (($x63659 (or $x535 (not (<= due_0_L.cache 0)))))
 (let (($x64590 (not active_0_L.query)))
 (let (($x55369 (or $x64590 (not (<= due_0_L.query 0)))))
 (let (($x102037 (= state_0 0)))
 (and $x102037 (>= 0 now_0) $x55369 $x63659 $x52876 $x63169 $x12872 $x45456 $x32786 $x41103 $x97267 v_1_L.checksums_enabled $x32787 $x32776 $x52813 $x52992 $x55448 $x65398 $x63184 $x7299 $x7298 $x7295 $x7292 $x7291 $x12963 $x35957 $x2386 (= v_1_L.rxudp_disposition "none") $x55394 $x63662 $x52921 $x30859 (= v_1_L.echo_disposition "none") $x78721 $x7276 $x7275 $x7270 $x7269 $x7268 $x7267 $x7264 (= v_1_T.tx_flags "S") $x7266 $x7265 v_1_T.active_open $x82886 $x27300 $x27290 $x12932 $x12533 $x63790 $x90378 $x58214 $x27285 $x27495 $x12837 $x52993 $x12573 $x12682 $x52793 $x12988 $x26644 $x64558 (= v_1_T.wire_disposition "none") $x36127 (= v_1_ip_pending_owner "none") active_1_L.query $x52610 $x37461 $x9917 $x37462 $x13017 $x37463 $x102873 $x37464 $x102874))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x35795 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x35794 (= due_2_T.user due_1_T.user)))
 (let (($x35793 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x35792 (= due_2_L.cache due_1_L.cache)))
 (let (($x35791 (= due_2_L.query due_1_L.query)))
 (let (($x35790 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x35789 (= active_2_T.user active_1_T.user)))
 (let (($x35788 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x35787 (= active_2_L.cache active_1_L.cache)))
 (let (($x35786 (= active_2_L.query active_1_L.query)))
 (let (($x35785 (= v_2_ip_pending_owner "UDP")))
 (let (($x35784 (= v_2_T.control v_1_T.control)))
 (let (($x35783 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x35782 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x35781 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x35780 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x35779 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x35778 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x35777 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x35776 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x35775 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x35774 (= v_2_T.take v_1_T.take)))
 (let (($x35773 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x35772 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x35771 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x35770 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x35769 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x35768 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x35767 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x35766 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x35765 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x35764 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x35763 (= v_2_T.retries v_1_T.retries)))
 (let (($x35762 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x35761 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x35760 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x35759 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x35758 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x35757 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x35756 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x35755 (= v_2_T.irs v_1_T.irs)))
 (let (($x35754 (= v_2_T.iss v_1_T.iss)))
 (let (($x35753 (= v_2_L.control "PENDING")))
 (let (($x35752 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x35751 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x35750 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x35749 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x35748 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x35747 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x35746 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x35745 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let ((?x77534 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x102909 (seq.unit (_ bv0 8))))
 (let ((?x74286 (seq.++ ?x102909 ?x77534)))
 (let ((?x10558 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x81475 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_L.checksums_enabled 49271 0))))))
 (let ((?x52792 (seq.unit (_ bv13 8))))
 (let ((?x10512 (seq.unit (_ bv144 8))))
 (let ((?x70859 (seq.++ ?x10512 (seq.++ ?x102909 (seq.++ ?x52792 (seq.++ ?x81475 (seq.++ ?x10558 ?x74286)))))))
 (let ((?x10515 (seq.unit (_ bv31 8))))
 (let ((?x83274 (seq.unit (_ bv64 8))))
 (let ((?x4786 (seq.unit (_ bv156 8))))
 (let ((?x10609 (seq.++ ?x4786 (seq.++ ?x83274 (seq.++ ?x10515 ?x70859)))))
 (let ((?x102995 (seq.unit (_ bv2 8))))
 (let ((?x35701 (seq.unit (_ bv192 8))))
 (let ((?x11107 (seq.unit (_ bv1 8))))
 (let ((?x87316 (seq.++ ?x11107 (seq.++ ?x35701 (seq.++ ?x102909 (seq.++ ?x102995 (seq.++ ?x102995 ?x10609)))))))
 (let ((?x72109 (seq.unit (_ bv200 8))))
 (let ((?x13128 (seq.unit (_ bv182 8))))
 (let ((?x224 (seq.++ ?x13128 (seq.++ ?x72109 (seq.++ ?x35701 (seq.++ ?x102909 (seq.++ ?x102995 ?x87316)))))))
 (let ((?x79726 (seq.unit (_ bv17 8))))
 (let ((?x79483 (seq.++ ?x102909 (seq.++ ?x83274 (seq.++ ?x102909 (seq.++ ?x83274 (seq.++ ?x79726 ?x224)))))))
 (let ((?x66491 (seq.unit (_ bv33 8))))
 (let ((?x75966 (seq.unit (_ bv69 8))))
 (let ((?x80727 (seq.++ ?x75966 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x66491 (seq.++ ?x102909 ?x79483)))))))
 (let (($x72175 (= v_2_L.pending_packet ?x80727)))
 (let (($x74787 (= v_2_L.ip_checksum 46792)))
 (let ((?x55867 (ite v_1_L.checksums_enabled 49271 0)))
 (let (($x71961 (= v_2_L.udp_checksum ?x55867)))
 (let (($x74446 (= v_2_L.udp_raw_checksum 49271)))
 (let (($x86373 (= v_2_L.ip_length 33)))
 (let (($x77890 (= v_2_L.udp_length 13)))
 (let (($x59737 (= v_2_L.packet ?x80727)))
 (let ((?x52986 (seq.++ ?x102995 (seq.++ ?x11107 (seq.++ ?x35701 (seq.++ ?x102909 (seq.++ ?x102995 ?x102995)))))))
 (let ((?x7312 (seq.++ ?x35701 (seq.++ ?x102909 ?x52986))))
 (let ((?x4794 (seq.++ ?x102909 (seq.++ ?x83274 (seq.++ ?x79726 (seq.++ ?x13128 (seq.++ ?x72109 ?x7312)))))))
 (let ((?x79484 (seq.++ ?x102909 (seq.++ ?x66491 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x83274 ?x4794)))))))
 (let (($x102005 (= v_2_L.ip_wire (seq.++ ?x75966 (seq.++ ?x102909 ?x79484)))))
 (let ((?x10492 (seq.++ ?x102909 (seq.++ ?x83274 (seq.++ ?x79726 (seq.++ ?x102909 (seq.++ ?x102909 ?x7312)))))))
 (let ((?x89009 (seq.++ ?x102909 (seq.++ ?x66491 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x83274 ?x10492)))))))
 (let (($x88978 (= v_2_L.ip_zero (seq.++ ?x75966 (seq.++ ?x102909 ?x89009)))))
 (let (($x84577 (= v_2_L.udp_wire ?x10609)))
 (let ((?x59404 (seq.++ ?x102995 (seq.++ ?x102995 (seq.++ ?x102909 (seq.++ ?x79726 (seq.++ ?x102909 ?x52792)))))))
 (let ((?x1205 (seq.++ ?x102909 (seq.++ ?x102995 (seq.++ ?x11107 (seq.++ ?x35701 (seq.++ ?x102909 ?x59404)))))))
 (let (($x64561 (= v_2_L.pseudoheader (seq.++ ?x35701 ?x1205))))
 (let ((?x27295 (seq.++ ?x10512 (seq.++ ?x102909 (seq.++ ?x52792 (seq.++ ?x102909 (seq.++ ?x102909 ?x74286)))))))
 (let (($x63779 (= v_2_L.udp_zero (seq.++ ?x4786 (seq.++ ?x83274 (seq.++ ?x10515 ?x27295))))))
 (let (($x12528 (= v_2_L.payload ?x74286)))
 (let (($x35731 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x35730 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x35729 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x35728 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x35727 (= 0 state_2)))
 (let (($x30799 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 5)))))
 (let (($x12630 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x7300 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x11236 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x63593 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x78721 (= v_1_L.control "PENDING")))
 (let (($x27289 (= state_1 0)))
 (and $x27289 $x78721 $x63593 $x11236 $x7300 $x12630 $x30799 $x35727 $x35728 $x35729 $x35730 $x35731 $x12528 $x63779 $x64561 $x84577 $x88978 $x102005 $x59737 $x77890 $x86373 $x74446 $x71961 $x74787 $x72175 $x35745 $x35746 $x35747 $x35748 $x35749 $x35750 $x35751 $x35752 $x35753 $x35754 $x35755 $x35756 $x35757 $x35758 $x35759 $x35760 $x35761 $x35762 $x35763 $x35764 $x35765 $x35766 $x35767 $x35768 $x35769 $x35770 $x35771 $x35772 $x35773 $x35774 $x35775 $x35776 $x35777 $x35778 $x35779 $x35780 $x35781 $x35782 $x35783 $x35784 $x35785 $x35786 $x35787 $x35788 $x35789 $x35790 $x35791 $x35792 $x35793 $x35794 $x35795))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x30474 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x30473 (= due_3_T.user due_2_T.user)))
 (let (($x30472 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x30470 (= due_3_L.query due_2_L.query)))
 (let (($x30469 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x30440 (= active_3_T.user active_2_T.user)))
 (let (($x30468 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x13133 (not active_3_L.query)))
 (let (($x2336 (= v_3_ip_pending_owner "none")))
 (let (($x2335 (= v_3_T.control v_2_T.control)))
 (let (($x2334 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x2333 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x2332 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x2331 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x2330 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x2329 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x2328 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x2327 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x2326 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x2325 (= v_3_T.take v_2_T.take)))
 (let (($x2324 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x2323 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x2322 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x2321 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x2320 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x2319 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x2318 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x2317 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x2316 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x2315 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x2314 (= v_3_T.retries v_2_T.retries)))
 (let (($x2313 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x2312 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x2311 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x2310 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x2309 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x2308 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x2307 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x2306 (= v_3_T.irs v_2_T.irs)))
 (let (($x2305 (= v_3_T.iss v_2_T.iss)))
 (let (($x2304 (= v_3_L.control "RESOLVED")))
 (let (($x2303 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x2302 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x2301 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x2300 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x2299 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x2298 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x2297 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x2296 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x73929 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x2294 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x2293 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x2292 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x2291 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x2290 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x2289 (= v_3_L.packet v_2_L.packet)))
 (let (($x2288 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x2287 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x2286 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x2285 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x2284 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x2283 (= v_3_L.payload v_2_L.payload)))
 (let (($x2282 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x2281 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x2280 (= 0 v_3_L.retry_count)))
 (let ((?x102909 (seq.unit (_ bv0 8))))
 (let ((?x458 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.unit (_ bv2 8))))))))
 (let ((?x102995 (seq.unit (_ bv2 8))))
 (let ((?x101886 (seq.++ ?x102995 ?x458)))
 (let (($x59974 (= v_3_L.peer_mac ?x101886)))
 (let (($x2278 (= 0 state_3)))
 (let (($x10526 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 10)))))
 (let (($x4792 (or (not active_2_T.user) (not (<= due_2_T.user 10)))))
 (let (($x82182 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 10)))))
 (let (($x4769 (or (not active_2_L.cache) (not (<= due_2_L.cache 10)))))
 (let (($x73371 (or (not active_2_L.query) (not (<= due_2_L.query 10)))))
 (let ((?x2235 (seq.len v_2_L.pending_packet)))
 (let (($x2236 (<= 28 ?x2235)))
 (let (($x35753 (= v_2_L.control "PENDING")))
 (let (($x63190 (= state_2 0)))
 (and $x63190 $x35753 $x2236 $x73371 $x4769 $x82182 $x4792 $x10526 $x2278 $x59974 $x2280 $x2281 $x2282 $x2283 $x2284 $x2285 $x2286 $x2287 $x2288 $x2289 $x2290 $x2291 $x2292 $x2293 $x2294 $x73929 $x2296 $x2297 $x2298 $x2299 $x2300 $x2301 $x2302 $x2303 $x2304 $x2305 $x2306 $x2307 $x2308 $x2309 $x2310 $x2311 $x2312 $x2313 $x2314 $x2315 $x2316 $x2317 $x2318 $x2319 $x2320 $x2321 $x2322 $x2323 $x2324 $x2325 $x2326 $x2327 $x2328 $x2329 $x2330 $x2331 $x2332 $x2333 $x2334 $x2335 $x2336 $x13133 active_3_L.cache $x30468 $x30440 $x30469 $x30470 (= due_3_L.cache (+ 10 v_2_L.cache_ttl_ms)) $x30472 $x30473 $x30474))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x35701 (seq.unit (_ bv192 8))))
 (let ((?x47178 (seq.++ ?x35701 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x47178))))
(assert
 (= 20 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x77534 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x102909 (seq.unit (_ bv0 8))))
 (let ((?x74286 (seq.++ ?x102909 ?x77534)))
 (= input_1_L.app.send_data ?x74286)))))
(assert
 (= 29 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x35701 (seq.unit (_ bv192 8))))
(let ((?x13182 (seq.++ ?x35701 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x11107 (seq.unit (_ bv1 8))))
(let ((?x102909 (seq.unit (_ bv0 8))))
(let ((?x10381 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x11107 ?x13182)))))))
(let ((?x102995 (seq.unit (_ bv2 8))))
(let ((?x8337 (seq.++ ?x35701 (seq.++ ?x102909 (seq.++ ?x102995 (seq.++ ?x102995 (seq.++ ?x102995 ?x10381)))))))
(let ((?x67200 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102995 ?x8337)))))))
(let ((?x10543 (seq.unit (_ bv4 8))))
(let ((?x45455 (seq.unit (_ bv6 8))))
(let ((?x30493 (seq.++ ?x45455 (seq.++ ?x10543 (seq.++ ?x102909 (seq.++ ?x102995 (seq.++ ?x102995 ?x67200)))))))
(let ((?x52488 (seq.unit (_ bv8 8))))
(let ((?x83898 (seq.++ ?x45455 (seq.++ ?x102909 (seq.++ ?x11107 (seq.++ ?x52488 (seq.++ ?x102909 ?x30493)))))))
(let ((?x87734 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x102995 (seq.++ ?x52488 ?x83898)))))))
(let ((?x84197 (seq.++ ?x102909 (seq.++ ?x102909 (seq.++ ?x11107 (seq.++ ?x102995 (seq.++ ?x102909 ?x87734)))))))
(let ((?x10530 (seq.++ ?x102995 (seq.++ ?x102909 (seq.++ ?x102909 ?x84197)))))
(= input_2_L.net.frame_frame ?x10530))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x62337 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x24832 (= due_1_T.user due_0_T.user)))
 (let (($x92964 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x62336 (= due_1_L.cache due_0_L.cache)))
 (let (($x93891 (= due_1_L.query due_0_L.query)))
 (let (($x92963 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x62339 (= active_1_T.user active_0_T.user)))
 (let (($x63486 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x92962 (= active_1_L.cache active_0_L.cache)))
 (let (($x62333 (= active_1_L.query active_0_L.query)))
 (let (($x11302 (= v_1_T.control "CLOSED")))
 (let (($x12549 (= v_1_T.wire_flags 0)))
 (let (($x52865 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x52864 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x52863 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x52862 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x52861 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x52860 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x52859 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x12562 (= v_1_T.take 0)))
 (let (($x12563 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x12564 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x12565 (= v_1_T.snd_wnd 8)))
 (let (($x52858 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x52857 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x52856 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x34888 (= v_1_T.local_window 16)))
 (let (($x53884 (= v_1_T.msl_ms 60000)))
 (let (($x60709 (= v_1_T.user_timeout_ms 30000)))
 (let (($x62608 (= v_1_T.retries 0)))
 (let (($x53885 (= v_1_T.rto_ms 1000)))
 (let (($x1747 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x53886 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x60710 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x26885 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x53887 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x2428 (= v_1_T.irs (_ bv0 32))))
 (let (($x97393 (= v_1_T.iss (_ bv1000 32))))
 (let (($x55498 (= v_1_L.control "EMPTY")))
 (let (($x52855 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x52854 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x52853 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x52852 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x91125 (= v_1_L.rxudp_disposition "deliver")))
 (let (($x52851 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x10948 (not v_1_L.rxudp_require_checksum)))
 (let (($x52848 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x12572 (= v_1_L.ip_checksum 0)))
 (let (($x12566 (= v_1_L.udp_checksum 0)))
 (let (($x12567 (= v_1_L.udp_raw_checksum 0)))
 (let (($x12568 (= v_1_L.ip_length 0)))
 (let (($x12581 (= v_1_L.udp_length 0)))
 (let (($x52847 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x52846 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x52845 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x52844 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x52843 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x52842 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x52841 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x12601 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x12596 (= v_1_L.retry_count 0)))
 (let (($x52840 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x65063 (= 0 state_1)))
 (let (($x53921 (not active_0_T.time_wait)))
 (let (($x52839 (or $x53921 (not (<= due_0_T.time_wait 0)))))
 (let (($x62636 (not active_0_T.user)))
 (let (($x52836 (or $x62636 (not (<= due_0_T.user 0)))))
 (let (($x98639 (not active_0_T.rtx)))
 (let (($x52833 (or $x98639 (not (<= due_0_T.rtx 0)))))
 (let (($x53919 (not active_0_L.cache)))
 (let (($x52830 (or $x53919 (not (<= due_0_L.cache 0)))))
 (let (($x62364 (not active_0_L.query)))
 (let (($x52827 (or $x62364 (not (<= due_0_L.query 0)))))
 (let (($x125500 (= state_0 0)))
 (and $x125500 (>= 0 now_0) $x52827 $x52830 $x52833 $x52836 $x52839 $x65063 $x52840 $x12596 $x12601 v_1_L.checksums_enabled $x52841 $x52842 $x52843 $x52844 $x52845 $x52846 $x52847 $x12581 $x12568 $x12567 $x12566 $x12572 $x52848 $x10948 $x52851 $x91125 $x52852 $x52853 $x52854 $x52855 (= v_1_L.echo_disposition "none") $x55498 $x97393 $x2428 $x53887 $x26885 $x60710 $x53886 $x1747 (= v_1_T.tx_flags "S") $x53885 $x62608 v_1_T.active_open $x60709 $x53884 $x34888 $x52856 $x52857 $x52858 $x12565 $x12564 $x12563 $x12562 $x52859 $x52860 $x52861 $x52862 $x52863 $x52864 $x52865 $x12549 (= v_1_T.wire_disposition "none") $x11302 (= v_1_ip_pending_owner "none") $x62333 $x92962 $x63486 $x62339 $x92963 $x93891 $x62336 $x92964 $x24832 $x62337))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x11268 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x11267 (= due_2_T.user due_1_T.user)))
 (let (($x11266 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x11265 (= due_2_L.cache due_1_L.cache)))
 (let (($x11264 (= due_2_L.query due_1_L.query)))
 (let (($x11263 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x11262 (= active_2_T.user active_1_T.user)))
 (let (($x11261 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x11260 (= active_2_L.cache active_1_L.cache)))
 (let (($x11259 (= active_2_L.query active_1_L.query)))
 (let (($x11258 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x11257 (= v_2_T.control v_1_T.control)))
 (let (($x11256 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x11255 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x11254 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x11253 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x11252 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x11251 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x11250 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x11249 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x11248 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x11247 (= v_2_T.take v_1_T.take)))
 (let (($x11246 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x11245 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x11244 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x11243 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x11242 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x11241 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x11240 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x11239 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x11238 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x11237 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x11236 (= v_2_T.retries v_1_T.retries)))
 (let (($x11235 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x11234 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x11233 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x11232 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x11231 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x11230 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x11229 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x11228 (= v_2_T.irs v_1_T.irs)))
 (let (($x11227 (= v_2_T.iss v_1_T.iss)))
 (let (($x11226 (= v_2_L.control "EMPTY")))
 (let (($x11225 (= v_2_L.echo_disposition "reply")))
 (let ((?x53932 (seq.unit (_ bv192 8))))
 (let ((?x53934 (seq.++ ?x53932 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x112 (seq.unit (_ bv1 8))))
 (let ((?x53933 (seq.unit (_ bv2 8))))
 (let ((?x62666 (seq.unit (_ bv0 8))))
 (let ((?x11116 (seq.++ ?x62666 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x112 ?x53934)))))))
 (let ((?x91518 (seq.unit (_ bv64 8))))
 (let ((?x11121 (seq.++ ?x91518 (seq.++ ?x62666 (seq.++ ?x91518 (seq.++ ?x112 (seq.++ ?x62666 ?x11116)))))))
 (let ((?x11123 (seq.++ ?x62666 (seq.++ ?x62666 ?x11121))))
 (let ((?x52649 (seq.unit (_ bv28 8))))
 (let ((?x55379 (seq.unit (_ bv69 8))))
 (let (($x53120 (= v_2_L.echo_ip_zero (seq.++ ?x55379 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x52649 ?x11123)))))))
 (let ((?x52726 (seq.unit (_ bv18 8))))
 (let ((?x63776 (seq.++ ?x52726 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x52724 (seq.unit (_ bv254 8))))
 (let ((?x53060 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ (seq.unit (_ bv65 8)) (seq.++ ?x52724 ?x63776))))))
 (let (($x53119 (= v_2_L.echo_icmp_wire ?x53060)))
 (let (($x53118 (= v_2_L.echo_icmp_zero (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x62666 ?x63776)))))))
 (let ((?x53101 (seq.++ ?x112 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x53933 ?x53060)))))))
 (let ((?x52720 (seq.unit (_ bv221 8))))
 (let ((?x52651 (seq.unit (_ bv182 8))))
 (let ((?x53106 (seq.++ ?x52651 (seq.++ ?x52720 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 ?x53101)))))))
 (let ((?x53111 (seq.++ ?x62666 (seq.++ ?x91518 (seq.++ ?x62666 (seq.++ ?x91518 (seq.++ ?x112 ?x53106)))))))
 (let ((?x53116 (seq.++ ?x55379 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x52649 (seq.++ ?x62666 ?x53111)))))))
 (let (($x53117 (= v_2_L.echo_reply ?x53116)))
 (let (($x11220 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x11219 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x11218 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x11217 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x11216 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x11215 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x11214 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x11213 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x11212 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x11211 (= v_2_L.packet v_1_L.packet)))
 (let (($x11210 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x11209 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x11208 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x11207 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x11206 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x11205 (= v_2_L.payload v_1_L.payload)))
 (let (($x11204 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x11203 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x11202 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x11201 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x11200 (= 0 state_2)))
 (let (($x26705 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x63201 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x13069 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x1245 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x12724 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x55498 (= v_1_L.control "EMPTY")))
 (let (($x32188 (= state_1 0)))
 (and $x32188 $x55498 $x12724 $x1245 $x13069 $x63201 $x26705 $x11200 $x11201 $x11202 $x11203 $x11204 $x11205 $x11206 $x11207 $x11208 $x11209 $x11210 $x11211 $x11212 $x11213 $x11214 $x11215 $x11216 $x11217 $x11218 $x11219 $x11220 $x53117 $x53118 $x53119 $x53120 $x11225 $x11226 $x11227 $x11228 $x11229 $x11230 $x11231 $x11232 $x11233 $x11234 $x11235 $x11236 $x11237 $x11238 $x11239 $x11240 $x11241 $x11242 $x11243 $x11244 $x11245 $x11246 $x11247 $x11248 $x11249 $x11250 $x11251 $x11252 $x11253 $x11254 $x11255 $x11256 $x11257 $x11258 $x11259 $x11260 $x11261 $x11262 $x11263 $x11264 $x11265 $x11266 $x11267 $x11268)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 35 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x52657 (seq.unit (_ bv165 8))))
 (let ((?x52662 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 ?x52657)))))))
 (let ((?x52667 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 ?x52662)))))))
 (let ((?x52672 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 (seq.++ ?x52657 ?x52667)))))))
 (let ((?x53932 (seq.unit (_ bv192 8))))
 (let ((?x52676 (seq.++ ?x53932 (seq.++ (seq.unit (_ bv9 8)) (seq.++ ?x52657 (seq.++ ?x52657 ?x52672))))))
 (let ((?x14359 (seq.unit (_ bv8 8))))
 (let ((?x62666 (seq.unit (_ bv0 8))))
 (let ((?x91518 (seq.unit (_ bv64 8))))
 (let ((?x19829 (seq.unit (_ bv156 8))))
 (let ((?x19827 (seq.unit (_ bv144 8))))
 (let ((?x52681 (seq.++ ?x19827 (seq.++ ?x19829 (seq.++ ?x91518 (seq.++ ?x62666 (seq.++ ?x14359 ?x52676)))))))
 (let ((?x19825 (seq.unit (_ bv31 8))))
 (let ((?x112 (seq.unit (_ bv1 8))))
 (let ((?x53933 (seq.unit (_ bv2 8))))
 (let ((?x52686 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x112 (seq.++ ?x19825 ?x52681)))))))
 (let ((?x52653 (seq.unit (_ bv205 8))))
 (let ((?x52691 (seq.++ ?x52653 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x53933 ?x52686)))))))
 (let ((?x52651 (seq.unit (_ bv182 8))))
 (let ((?x91520 (seq.unit (_ bv17 8))))
 (let ((?x52696 (seq.++ ?x91518 (seq.++ ?x62666 (seq.++ ?x91518 (seq.++ ?x91520 (seq.++ ?x52651 ?x52691)))))))
 (let ((?x52649 (seq.unit (_ bv28 8))))
 (let ((?x52701 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x52649 (seq.++ ?x62666 (seq.++ ?x62666 ?x52696)))))))
 (let ((?x55379 (seq.unit (_ bv69 8))))
 (let ((?x52706 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x14359 (seq.++ ?x62666 (seq.++ ?x55379 ?x52701)))))))
 (let ((?x52711 (seq.++ ?x112 (seq.++ ?x53933 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x62666 ?x52706)))))))
 (let ((?x52716 (seq.++ ?x53933 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x62666 ?x52711)))))))
 (= input_0_L.net.frame_frame ?x52716)))))))))))))))))))))))))))))
(assert
 (= 54 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x52732 (seq.unit (_ bv126 8))))
(let ((?x52737 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 ?x52732)))))))
(let ((?x52742 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 ?x52737)))))))
(let ((?x52747 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 (seq.++ ?x52732 ?x52742)))))))
(let ((?x52653 (seq.unit (_ bv205 8))))
(let ((?x52730 (seq.unit (_ bv171 8))))
(let ((?x52728 (seq.unit (_ bv52 8))))
(let ((?x52752 (seq.++ ?x52728 (seq.++ ?x52730 (seq.++ ?x52653 (seq.++ ?x52732 (seq.++ ?x52732 ?x52747)))))))
(let ((?x52726 (seq.unit (_ bv18 8))))
(let ((?x52724 (seq.unit (_ bv254 8))))
(let ((?x52722 (seq.unit (_ bv57 8))))
(let ((?x62666 (seq.unit (_ bv0 8))))
(let ((?x14359 (seq.unit (_ bv8 8))))
(let ((?x52757 (seq.++ ?x14359 (seq.++ ?x62666 (seq.++ ?x52722 (seq.++ ?x52724 (seq.++ ?x52726 ?x52752)))))))
(let ((?x112 (seq.unit (_ bv1 8))))
(let ((?x53933 (seq.unit (_ bv2 8))))
(let ((?x53932 (seq.unit (_ bv192 8))))
(let ((?x52762 (seq.++ ?x53933 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x112 ?x52757)))))))
(let ((?x52720 (seq.unit (_ bv221 8))))
(let ((?x52651 (seq.unit (_ bv182 8))))
(let ((?x52767 (seq.++ ?x52651 (seq.++ ?x52720 (seq.++ ?x53932 (seq.++ ?x62666 (seq.++ ?x53933 ?x52762)))))))
(let ((?x91518 (seq.unit (_ bv64 8))))
(let ((?x52772 (seq.++ ?x62666 (seq.++ ?x91518 (seq.++ ?x62666 (seq.++ ?x91518 (seq.++ ?x112 ?x52767)))))))
(let ((?x52649 (seq.unit (_ bv28 8))))
(let ((?x55379 (seq.unit (_ bv69 8))))
(let ((?x52777 (seq.++ ?x55379 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x52649 (seq.++ ?x62666 ?x52772)))))))
(let ((?x52782 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x53933 (seq.++ ?x14359 (seq.++ ?x62666 ?x52777)))))))
(let ((?x52787 (seq.++ ?x62666 (seq.++ ?x112 (seq.++ ?x53933 (seq.++ ?x62666 (seq.++ ?x62666 ?x52782)))))))
(let ((?x52791 (seq.++ ?x53933 (seq.++ ?x62666 (seq.++ ?x62666 (seq.++ ?x62666 ?x52787))))))
(= input_1_L.net.frame_frame ?x52791)))))))))))))))))))))))))))))))
(check-sat)

import sys,os,json,time,subprocess,resource
from pathlib import Path
p=Path("/home/blxu/protocol-flow");out=p/"candidates/exact-backend-validation-20261107-0028";w=out/"workspace"
def save(n,v):(out/n).write_text(json.dumps(v,indent=2))
def status(**kw):save("status.json",dict(status="running",pid=os.getpid(),production_modified=False,proposal="0027",**kw))
status(stage="actual_candidate_tests",started_at=time.time())
CHECK="""import sys,json,unittest
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import protocol_lab.symbolic as symbolic
original=symbolic.check
records=[]
def observed(*a,**kw):
 if kw.get('out')is None:kw['out']=Path(sys.argv[2])/('actual-check-'+str(len(records)))
 r=original(*a,**kw);records.append(r);Path(sys.argv[2]+'/actual-check-reports.json').write_text(json.dumps(records,indent=2));return r
symbolic.check=observed
suite=unittest.defaultTestLoader.discover(sys.argv[1]+'/tests',pattern='test_solver_preprocessing.py')
r=unittest.TextTestRunner(verbosity=2).run(suite)
Path(sys.argv[2]+'/tests-result.json').write_text(json.dumps(dict(tests=r.testsRun,errors=len(r.errors),failures=len(r.failures),skips=len(r.skipped))))
raise SystemExit(not r.wasSuccessful())
"""
try:
 with(out/"tests.log").open("w")as log:r=subprocess.run([str(p/"releases/udp-transmit-1b13a36f/venv/bin/python"),"-c",CHECK,str(w),str(out)],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=240,env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"})
 results=json.loads((out/"tests-result.json").read_text())if(out/"tests-result.json").exists()else{}
 save("status.json",dict(status="controller_review_required",stage="finished",pid=os.getpid(),returncode=r.returncode,tests=results,production_modified=False,known_review_findings_pending=True,old_UNKNOWN_unchanged=True,finished_at=time.time()))
except Exception as error:save("status.json",dict(status="validation_stopped",stage="stopped",pid=os.getpid(),error_type=type(error).__name__,production_modified=False));raise

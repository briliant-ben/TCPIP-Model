"""Explicit exact-v1 solver preprocessing, SAT model conversion, and verifier policy binding tests."""
from pathlib import Path
import copy, json, tempfile, unittest
from unittest.mock import Mock
import z3
from protocol_lab.ir import CLOCK_SEMANTICS, load, ModelError
from protocol_lab.symbolic import Encoding, check, replay
from protocol_lab.pipeline.task import load_task, inputs, freeze_inputs, read, write, sha
from protocol_lab.pipeline import runner

ROOT=Path(__file__).resolve().parents[1]
MODEL=ROOT/'model/icmp-echo.json'
FLOW=ROOT/'flows/icmp-echo.json'

def tiny_model(overlap=False, invariant=False):
    transitions=[{"id":"t0","event":"go","from":"S0","to":"S1","guard":True,"actions":[{"set":{"var":"x","value":1}}]}]
    if overlap:
        transitions.append({"id":"t1","event":"go","from":"S0","to":"S1","guard":True,"actions":[{"set":{"var":"x","value":2}}]})
    return {
      "ir_version":"0.1",
      "semantics":CLOCK_SEMANTICS,
      "variables":{"x":{"type":"int","initial":0}},
      "states":["S0","S1"],
      "initial_state":"S0",
      "scope":{"terminal_states":[]},
      "timers":{},
      "messages":{},
      "events":{"go":{"origin":"external","fields":{}}},
      "transitions":transitions,
      "invariants":[{"id":"x0","assert":{"op":"eq","args":[{"var":"x"},0]}}] if invariant else [],
    }

def retained(out, workspace, task_file):
    t=load_task(task_file, workspace)
    snapshot=inputs(task_file, workspace, t)
    out.mkdir(parents=True, exist_ok=False)
    frozen=freeze_inputs(snapshot, workspace, out)
    write(out/'request.json', {"task":t,"workspace":str(workspace),"task_file":str(task_file),"expected_task_sha256":None,"execution_workspace":str(out/frozen['workspace']),"execution_tool_root":str(out/frozen['tool'].parent)})
    stages={}
    for name in runner.STAGES:
        if name=='formal':
            data={"backend":"z3-bmc","status":"bounded_pass","solver_timeout_ms":t['formal'].get('solver_timeout_ms',10000),"solver_preprocess":t['formal'].get('solver_preprocess','none'),"depth":t['formal'].get('depth',0),"invariants":[]}
            (out/'stages/formal/queries').mkdir(parents=True, exist_ok=True)
            write(out/'stages/formal/queries/result.json', data)
            stages[name]={"schema":"spec-flow-stage-v1","stage":name,"status":"pass","classification":None,"data":data}
        elif name in ('sources','ir'):
            stages[name]={"schema":"spec-flow-stage-v1","stage":name,"status":"pass","classification":None,"data":{}}
        else:
            stages[name]={"schema":"spec-flow-stage-v1","stage":name,"status":"unknown","classification":"not_exercised","data":{}}
        folder=out/'stages'/name; folder.mkdir(parents=True, exist_ok=True)
        write(folder/'result.json', stages[name])
    flow={"schema":"spec-flow-run-v1","run_id":"test","task_id":t['id'],"task_sha256":sha(task_file),"execution_status":"completed","assessment":runner.assess(stages),"finalized":True,"scope":t['scope'],"expected_task_sha256":None,"task_pin_matched":False,"input_hashes":snapshot,"source_snapshot":frozen,"request_sha256":sha(out/'request.json'),"stages":stages,"workers":{},"environment":{},"observation_kind":"test","pcap_evidence":False,"protocol_correctness_proved":False,"generator_correctness_proved":False,"english_to_ir_correctness_proved":False,"whole_goal_complete":False,"outputs":{}}
    write(out/'flow.json', flow)
    flow['outputs']={p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p!=out/'flow.json'}
    write(out/'flow.json', flow)
    return out

class SolverPreprocessingTests(unittest.TestCase):
    def test_default_none_unchanged_and_unsupported_policy_rejected(self):
        enc=Encoding(tiny_model(),1,[],fixed_choices=[0])
        self.assertEqual(enc.solver_preprocess,'none')
        self.assertEqual(enc.solver_tactics,())
        self.assertIsInstance(enc.solver,z3.Solver)
        with self.assertRaises(ModelError):
            Encoding(tiny_model(),1,[],fixed_choices=[0],solver_preprocess='bogus')
        with self.assertRaises(ModelError):
            Encoding(tiny_model(),1,[],byte_encoding='length',solver_preprocess='exact-v1')

    def test_sat_model_converter_reconstructs_invariant_counterexample(self):
        model=tiny_model(invariant=True)
        enc=Encoding(model,1,[],fixed_choices=[0],solver_preprocess='exact-v1')
        inv=enc.expr(model['invariants'][0]['assert'], enc.frames[1])
        enc.solver.add(z3.Not(inv))
        self.assertEqual(enc.solve(),z3.sat)
        witness=enc.witness(enc.solver.model())
        self.assertEqual(witness['steps'][0]['after']['variables']['x'],1)
        result=replay(model,witness)
        self.assertEqual(result['status'],'runtime_rejected')
        self.assertEqual(result['step'],0)

    def test_exact_witness_replay_uses_reconstructed_variables(self):
        model=tiny_model()
        enc=Encoding(model,1,[],fixed_choices=[0],solver_preprocess='exact-v1')
        self.assertEqual(enc.solve(),z3.sat)
        witness=enc.witness(enc.solver.model())
        self.assertIn('initial',witness)
        self.assertEqual(witness['steps'][0]['after']['variables']['x'],1)
        self.assertEqual(replay(model,witness)['status'],'match')

    def test_rule_overlap_exists_and_conflict_witness_replays_as_runtime_rejected(self):
        model=tiny_model(overlap=True)
        query=Encoding(model,1,[],solver_preprocess='exact-v1')
        query.solver.add(z3.Or(*query.conflicts))
        self.assertEqual(query.solve(),z3.sat)
        witness_enc=Encoding(model,1,[],fixed_choices=[0],solver_preprocess='exact-v1')
        witness_enc.solver.add(z3.Or(*witness_enc.conflicts))
        self.assertEqual(witness_enc.solve(),z3.sat)
        result=replay(model,witness_enc.witness(witness_enc.solver.model()))
        self.assertEqual(result['status'],'runtime_rejected')
        self.assertEqual(result['step'],0)

    def test_recursive_checksum_definition_survives_preprocessing(self):
        model=load(MODEL)
        enc=Encoding(model,1,[],fixed_choices=[0],solver_preprocess='exact-v1')
        names=[n for n,v in model['variables'].items() if v['type']=='bytes']
        self.assertTrue(names)
        term=enc.expr({"op":"bytes_internet_checksum16","args":[{"var":names[0]}]}, enc.frames[0])
        enc.solver.add(term>=0)
        smt=enc.solver.to_smt2()
        self.assertIn('define-fun-rec',smt)

    def test_forced_unknown_and_z3_exception_remain_unknown(self):
        enc=Encoding(tiny_model(),1,[],fixed_choices=[0],solver_preprocess='exact-v1')
        enc.solver.check=Mock(return_value=z3.unknown)
        enc.solver.reason_unknown=Mock(return_value='forced-unknown')
        self.assertEqual(enc.solve(),z3.unknown)
        self.assertEqual(enc.reason_unknown(),'forced-unknown')
        enc.solver.check=Mock(side_effect=z3.Z3Exception('forced-exception'))
        self.assertEqual(enc.solve(),z3.unknown)
        self.assertIn('forced-exception',enc.reason_unknown())

    def test_actual_icmp_all_input_depth2_60s_exact_v1(self):
        model=load(MODEL)
        report=check(model,2,[],solver_timeout_ms=60000,solver_preprocess='exact-v1')
        self.assertEqual(report['depth'],2)
        self.assertEqual(report['solver_timeout_ms'],60000)
        self.assertEqual(report['solver_preprocess'],'exact-v1')
        self.assertEqual(report['solver_tactics'],['propagate-values','solve-eqs','simplify','smt'])
        self.assertEqual(len(report['invariants']),2)
        self.assertIn(report['status'],('bounded_pass','counterexample','conflict','unknown'))
        if report['status']=='counterexample':
            self.assertEqual(report['replay']['status'],'match')
        if report['status']=='unknown':
            self.assertIn('reason',report)

    def test_task_policy_admission_and_v4_rejection(self):
        task=json.loads(FLOW.read_text())
        with tempfile.NamedTemporaryFile(mode='w+',suffix='.json',dir=ROOT) as file:
            def admit(value):
                file.seek(0); file.truncate(); json.dump(value,file); file.flush(); return load_task(file.name,ROOT)
            self.assertEqual(admit(copy.deepcopy(task))['formal']['solver_preprocess'],'exact-v1')
            bad=copy.deepcopy(task); bad['formal']['solver_preprocess']='bogus'
            with self.assertRaises(ValueError): admit(bad)
            v4=copy.deepcopy(task); v4['schema']='spec-flow-task-v4'; v4['formal']={'strategy':'sequence-invariant-induction','solver_preprocess':'exact-v1'}
            with self.assertRaises(ValueError): admit(v4)

    def test_rehashed_policy_tamper_is_rejected_by_verifier(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            out=Path(tmp)/'run'
            retained(out,ROOT,FLOW)
            self.assertEqual(runner.verify(out,ROOT)['status'],'retained_evidence_consistent')
            q=read(out/'stages/formal/queries/result.json'); q['solver_preprocess']='none'; write(out/'stages/formal/queries/result.json',q)
            s=read(out/'stages/formal/result.json'); s['data']['solver_preprocess']='none'; write(out/'stages/formal/result.json',s)
            flow=read(out/'flow.json'); flow['stages']['formal']['data']['solver_preprocess']='none'
            flow['outputs']={p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p!=out/'flow.json'}
            write(out/'flow.json',flow)
            with self.assertRaises(ValueError):
                runner.verify(out,ROOT)

if __name__=='__main__':
    unittest.main()

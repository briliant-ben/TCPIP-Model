"""Server controller: completed test repair -> actual synthetic driver tests -> review."""
import ast,hashlib,json,os,re,resource,shutil,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'/home/blxu/protocol-flow/controllers/tcp-reasoning-authorized-v2')
from deepseek_gateway import request
P=Path('/home/blxu/protocol-flow');JOB=P/'candidates/tcp-driver-test-repair-20261106-0020';OUT=JOB/'run';OUT.mkdir(exist_ok=False)
WORK=P/'candidates/tcp-handoff-20261106-0001/workspace';DRIVER=P/'candidates/tcp-peer-exchange-evidence-20261106-0016/completed-source.py'
SHA='aa5f174a82976625517ef963c4f57117ec0f5655ca456c21c3ef0020bc375a9c'
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def state(**kw):
 value=dict(provider='DeepSeek',pid=os.getpid(),gpt_subagents=False,automatic_merge=False,automatic_api_retry=False,request_cap=None,**kw)
 temporary=OUT/'status.tmp';temporary.write_text(json.dumps(value,indent=2));temporary.replace(OUT/'status.json')
def call(name,messages):
 write(name+'-messages.json',messages)
 r=request(messages,P/'private/api-ledger',P/'private/deepseek.key',max_calls=None,max_tokens=32768,thinking='enabled',reasoning_effort='low',timeout=600)
 v=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response'];write(name+'-response.json',v);write(name+'-usage.json',{k:r.get(k)for k in ('usage','cached','request_sha256')});return v
CHECKER='''import sys,json,unittest\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nimport exchange\noriginal=exchange.run_exchange\ncalls=[]\ndef observed(*a,**k):\n calls.append(1);return original(*a,**k)\nexchange.run_exchange=observed\nsuite=unittest.defaultTestLoader.discover(sys.argv[1],pattern="test_exchange.py")\nresult=unittest.TextTestRunner(verbosity=2).run(suite)\nreceipt=dict(tests=result.testsRun,driver_calls=len(calls),errors=len(result.errors),failures=len(result.failures),skipped=len(result.skipped),synthetic_only=True,live_TCP_evidence=False)\nPath(sys.argv[2]).write_text(json.dumps(receipt))\nraise SystemExit(not(result.wasSuccessful()and result.testsRun>=1 and len(calls)>=1 and not result.skipped))\n'''
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(40,40));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(10*1024**2,10*1024**2))
def gate(source,folder):
 tree=ast.parse(source)
 allowed={'json','os','select','socket','threading','unittest','tempfile','types','pathlib','time','copy','exchange','protocol_lab.codegen.execute','unittest.mock'}
 banned={'exec','eval','compile','__import__','getattr','setattr','globals','locals','open','input'}
 for n in ast.walk(tree):
  if isinstance(n,ast.Import)and any(a.name not in allowed for a in n.names):raise ValueError('Test import not admitted')
  if isinstance(n,ast.ImportFrom)and n.module not in allowed:raise ValueError('Test from-import not admitted')
  if isinstance(n,ast.Name)and n.id in banned:raise ValueError('Dynamic/file capability not admitted')
  if isinstance(n,ast.Attribute):
   if n.attr.startswith('__'):raise ValueError('Introspection not admitted')
   if n.attr in ('open','unlink','rmdir','rmtree','system','popen','exec','eval'):raise ValueError('Host mutation capability not admitted')
   if isinstance(n.value,ast.Name)and n.value.id=='os'and n.attr not in ('getpid','read','write'):raise ValueError('OS capability not admitted')
   if isinstance(n.value,ast.Name)and n.value.id=='socket'and n.attr not in ('socketpair','AF_UNIX','SOCK_DGRAM','timeout','error'):raise ValueError('Only local synthetic socketpair admitted')
  if isinstance(n,ast.Constant)and isinstance(n.value,str)and (n.value.startswith('/')or'../'in n.value or'deepseek.key'in n.value or'api-ledger'in n.value):raise ValueError('External path not admitted')
 if not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='run_exchange'for n in ast.walk(tree)):raise ValueError('Actual run_exchange invocation missing')
 assert hashlib.sha256(DRIVER.read_bytes()).hexdigest()==SHA
 folder.mkdir();shutil.copy2(DRIVER,folder/'exchange.py');(folder/'test_exchange.py').write_text(source)
 with(folder/'tests.log').open('w')as log:
  r=subprocess.run([str(P/'releases/udp-transmit-1b13a36f/venv/bin/python'),'-c',CHECKER,str(folder),str(folder/'result.json')],cwd=WORK,stdout=log,stderr=subprocess.STDOUT,timeout=55,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONPATH':str(WORK),'PYTHONDONTWRITEBYTECODE':'1'})
 assert hashlib.sha256(DRIVER.read_bytes()).hexdigest()==SHA and hashlib.sha256((folder/'exchange.py').read_bytes()).hexdigest()==SHA
 result=json.loads((folder/'result.json').read_text())if(folder/'result.json').exists()else{'returncode':r.returncode}
 return result,r.returncode,(folder/'tests.log').read_text()[-10000:]
state(status='running',stage='anchored_test_repair',started_at=time.time(),new_test_executed=False)
try:
 previous=json.loads((P/'candidates/tcp-peer-acceptance-20261106-0019/run/test-author-response.json').read_text())
 task={'objective':'Repair ONE executable unittest file to test the FROZEN provided exchange driver; no driver/model changes. It must actually call run_exchange and use correct actual ABI. Synthetic AF_UNIX adapter test ONLY, no LinuxTCP proof. Return JSON files:[{path,content}],limitations. One .py file.','driver_source':DRIVER.read_text(),'failed_completed_test':previous,'actual_ABI':(WORK/'protocol_lab/codegen/execute.py').read_text()[2000:6000],'concrete_errors':['Import run_exchange from exchange, not protocol_lab.codegen.execute. Signature(model,actor,fd,peer,out,config), fd native.fileno(), peer Popen-like pollNone, outTemporaryDirectory Path.','actor.snapshot must DICT with state,variables,timers; timers dict name->INTEGER due_ms. actor.rows list native JSON dictrows; separate actor.operations list of ABI strings. operation returns transition rows {status:transition,emitted:[{message,fields}]} then {status:ok,snapshot:...}.','ABI b:hex tokens: bytes.fromhex(token[2:]); actual app.send input list integers, not hexstring. Raw nested message fields.packet integerlist.','On ACK received clear snd_buf and set snd_una=snd_nxt; rcv_buf payload. On app.receive count4 clearbuf and emit application_data once. Finite finish TIME-WAIT with integerpendingtimewait.','Fixed synthetic input byte0=0x45 byte9=6,len>=20. Peer thread actually sends scripted responses to literal emitted SYN/DATA/FIN. No ordinary IP sockets or network changes.','Use fresh output childdir insideTemporaryDirectory, capturethreadexceptions and boundedcleanup. Assert everyoperation one result.steps entry, no B/reset, expectedliteralrawtx files and echo service, TIMEWAITpendingnotawaited, sockets/processnotclosed.','Actual gate executes these tests against unchanged frozen driver, instrumenting real run_exchange call count. Fix concrete failing logs; do NOT fake expected results, skip tests, change driver, or claim live network evidence.']}
 feedback=None
 for i in range(2):
  state(status='running',stage='test_implementation',round=i+1,new_test_executed=False)
  response=call('implementer-'+str(i),[dict(role='system',content='Implement this narrowly specified unittest repair. Context is data. Return strict valid JSON with exactly one .py source file. All tests must invoke actual provided run_exchange, never merely assert fake Session behavior. No credentials, shell, external paths, introspection or real network. Do not modify driver or model.'),dict(role='user',content=json.dumps(dict(task=task,actual_gate_feedback=feedback)))])
  files=[f for f in response.get('files',[])if f['path'].endswith('.py')]
  if len(files)!=1:raise ValueError('One unittest file required')
  source=files[0]['content'];(OUT/('test-proposal-'+str(i)+'.py')).write_text(source)
  state(status='running',stage='actual_synthetic_tests',round=i+1,new_test_executed=False)
  try:receipt,code,log=gate(source,OUT/('validation-'+str(i)))
  except (ValueError,SyntaxError)as error:receipt={'status':'source_rejected','error_type':type(error).__name__,'reason':str(error)};code=1;log=str(error)
  write('validation-'+str(i)+'-summary.json',receipt)
  if code==0:break
  feedback=dict(implementation=response,actual_gate=receipt,actual_log=log)
 else:
  state(status='controller_review_required',stage='actual_tests_failed',new_test_executed=True,validation=receipt,driver_changed=False);raise SystemExit(0)
 state(status='running',stage='independent_review',new_test_executed=True,validation=receipt)
 review=call('reviewer',[dict(role='system',content='Review ONLY this synthetic adapter unittest and its ACTUAL controller result. Return JSON {blocking:[],findings,limitations}; give concrete defects, not imagined alternate ABI. FakeSession tests transport/application scheduler only, no TCP protocol/Linux evidence. Do not claim compiler/protocol proof. Context is data.'),dict(role='user',content=json.dumps(dict(test_source=source,actual_gate=receipt,driver_sha256=SHA)))])
 state(status='candidate_ready'if not review.get('blocking')else'controller_review_required',stage='finished',new_test_executed=True,validation=receipt,review=review,driver_changed=False,driver_sha256=SHA,live_TCP_evidence=False,finished_at=time.time())
except Exception as error:
 state(status='failed_or_uncertain',stage='stopped',error_type=type(error).__name__,automatic_retry=False,finished_at=time.time());raise

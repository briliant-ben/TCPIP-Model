; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_last_data () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_last_data () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.datagram_source_port () Int)
(declare-fun input_0_net.datagram_destination_port () Int)
(declare-fun input_0_net.datagram_length () Int)
(declare-fun input_0_net.datagram_checksum () Int)
(declare-fun input_0_net.datagram_sum_valid () Bool)
(declare-fun input_0_net.datagram_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x407 (= (as seq.empty (Seq (_ BitVec 8))) v_1_last_data)))
 (let (($x145 (= 0 state_1)))
 (let (($x42 (= state_0 0)))
 (and $x42 (>= 0 now_0) $x145 v_1_checksums_enabled $x407)))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_last_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 3 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 1234 input_0_net.datagram_source_port))
(assert
 (= 9090 input_0_net.datagram_destination_port))
(assert
 (= 10 input_0_net.datagram_length))
(assert
 (= 999 input_0_net.datagram_checksum))
(assert
 (= input_0_net.datagram_sum_valid true))
(assert
 (let ((?x239 (seq.unit (_ bv2 8))))
(let ((?x286 (seq.unit (_ bv1 8))))
(let ((?x160 (seq.++ ?x286 ?x239)))
(= input_0_net.datagram_data ?x160)))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_last_data () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_last_data () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun state_2 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_last_data () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_source_port () Int)
(declare-fun input_0_app.send_destination_port () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.datagram_source_port () Int)
(declare-fun input_1_net.datagram_destination_port () Int)
(declare-fun input_1_net.datagram_length () Int)
(declare-fun input_1_net.datagram_checksum () Int)
(declare-fun input_1_net.datagram_sum_valid () Bool)
(declare-fun input_1_net.datagram_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x161 (= (as seq.empty (Seq (_ BitVec 8))) v_1_last_data)))
 (let (($x13 (= 0 state_1)))
 (let (($x382 (= state_0 0)))
 (and $x382 (>= 0 now_0) $x13 v_1_checksums_enabled $x161)))))
(assert
 true)
(assert
 (let (($x159 (= (as seq.empty (Seq (_ BitVec 8))) v_2_last_data)))
 (let (($x147 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x146 (= 0 state_2)))
 (let (($x216 (= state_1 0)))
 (and $x216 $x146 $x147 $x159))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_last_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 1 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 0 input_0_app.send_source_port))
(assert
 (= 8080 input_0_app.send_destination_port))
(assert
 (= input_0_app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 2 choice_1))
(assert
 (= 0 now_2))
(assert
 (= 5020 input_1_net.datagram_source_port))
(assert
 (= 8080 input_1_net.datagram_destination_port))
(assert
 (= 8 input_1_net.datagram_length))
(assert
 (= 0 input_1_net.datagram_checksum))
(assert
 (= input_1_net.datagram_sum_valid false))
(assert
 (= input_1_net.datagram_data (as seq.empty (Seq (_ BitVec 8)))))
(check-sat)

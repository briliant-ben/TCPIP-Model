; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_last_data () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_last_data () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun state_2 () Int)
(declare-fun v_3_last_data () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun state_3 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_last_data () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_source_port () Int)
(declare-fun input_0_app.send_destination_port () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.datagram_source_port () Int)
(declare-fun input_1_net.datagram_destination_port () Int)
(declare-fun input_1_net.datagram_length () Int)
(declare-fun input_1_net.datagram_checksum () Int)
(declare-fun input_1_net.datagram_sum_valid () Bool)
(declare-fun input_1_net.datagram_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.datagram_source_port () Int)
(declare-fun input_2_net.datagram_destination_port () Int)
(declare-fun input_2_net.datagram_length () Int)
(declare-fun input_2_net.datagram_checksum () Int)
(declare-fun input_2_net.datagram_sum_valid () Bool)
(declare-fun input_2_net.datagram_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x212 (= (as seq.empty (Seq (_ BitVec 8))) v_1_last_data)))
 (let (($x76 (= 0 state_1)))
 (let (($x22 (= state_0 0)))
 (and $x22 (>= 0 now_0) $x76 v_1_checksums_enabled $x212)))))
(assert
 true)
(assert
 (let ((?x368 (seq.unit (_ bv0 8))))
 (let ((?x375 (seq.++ ?x368 (seq.++ (seq.unit (_ bv255 8)) (seq.unit (_ bv10 8))))))
 (let (($x341 (= v_2_last_data ?x375)))
 (let (($x195 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x194 (= 0 state_2)))
 (let (($x129 (= state_1 0)))
 (and $x129 $x194 $x195 $x341))))))))
(assert
 true)
(assert
 true)
(assert
 (let ((?x368 (seq.unit (_ bv0 8))))
 (let ((?x375 (seq.++ ?x368 (seq.++ (seq.unit (_ bv255 8)) (seq.unit (_ bv10 8))))))
 (let (($x345 (= v_3_last_data ?x375)))
 (let (($x310 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x309 (= 0 state_3)))
 (let (($x230 (= state_2 0)))
 (and $x230 $x309 $x310 $x345))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_last_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 1 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 4242 input_0_app.send_source_port))
(assert
 (= 8080 input_0_app.send_destination_port))
(assert
 (let ((?x368 (seq.unit (_ bv0 8))))
 (let ((?x375 (seq.++ ?x368 (seq.++ (seq.unit (_ bv255 8)) (seq.unit (_ bv10 8))))))
 (= input_0_app.send_data ?x375))))
(assert
 (= 2 choice_1))
(assert
 (= 0 now_2))
(assert
 (= 4242 input_1_net.datagram_source_port))
(assert
 (= 8080 input_1_net.datagram_destination_port))
(assert
 (= 11 input_1_net.datagram_length))
(assert
 (= 51234 input_1_net.datagram_checksum))
(assert
 (= input_1_net.datagram_sum_valid true))
(assert
 (let ((?x368 (seq.unit (_ bv0 8))))
 (let ((?x373 (seq.unit (_ bv10 8))))
 (let ((?x371 (seq.unit (_ bv255 8))))
 (let ((?x391 (seq.++ ?x371 (seq.++ ?x373 (seq.++ ?x368 (seq.++ ?x368 (seq.++ ?x368 ?x368)))))))
 (let ((?x392 (seq.++ ?x368 ?x391)))
 (= input_1_net.datagram_data ?x392)))))))
(assert
 (= 2 choice_2))
(assert
 (= 0 now_3))
(assert
 (= 4242 input_2_net.datagram_source_port))
(assert
 (= 8080 input_2_net.datagram_destination_port))
(assert
 (= 11 input_2_net.datagram_length))
(assert
 (= 51234 input_2_net.datagram_checksum))
(assert
 (= input_2_net.datagram_sum_valid true))
(assert
 (let ((?x368 (seq.unit (_ bv0 8))))
(let ((?x373 (seq.unit (_ bv10 8))))
(let ((?x371 (seq.unit (_ bv255 8))))
(let ((?x391 (seq.++ ?x371 (seq.++ ?x373 (seq.++ ?x368 (seq.++ ?x368 (seq.++ ?x368 ?x368)))))))
(let ((?x392 (seq.++ ?x368 ?x391)))
(= input_2_net.datagram_data ?x392)))))))
(check-sat)

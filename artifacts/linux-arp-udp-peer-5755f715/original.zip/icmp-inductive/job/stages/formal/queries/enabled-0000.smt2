; benchmark generated from python API
(set-info :status unknown)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(declare-fun now_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(assert
 true)
(assert
 true)
(assert
 (>= now_0 0))
(assert
 true)
(assert
 (let (($x75 (= v_1_disposition "drop_short")))
 (let (($x532 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x445 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_wire)))
 (let (($x561 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_zero)))
 (let (($x497 (= (as seq.empty (Seq (_ BitVec 8))) v_1_reply)))
 (let ((?x64 (seq.len input_0_net.packet_packet)))
 (let (($x66 (>= 27 ?x64)))
 (let (($x63 (>= now_1 now_0)))
 (and $x63 $x66 $x497 $x561 $x445 $x532 $x75))))))))))
(assert
 (let ((?x827 (seq.len v_0_reply)))
 (>= 1500 ?x827)))
(assert
 (let ((?x827 (seq.len v_0_reply)))
(let (($x830 (= 0 ?x827)))
(or (= v_0_disposition "reply") $x830))))
(check-sat)

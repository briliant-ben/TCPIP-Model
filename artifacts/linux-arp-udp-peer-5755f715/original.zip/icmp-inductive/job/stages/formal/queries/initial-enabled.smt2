; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_reply))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_icmp_zero))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_icmp_wire))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_ip_zero))
(assert
 (= v_0_disposition "none"))
(assert
 (let (($x348 (= v_1_disposition v_0_disposition)))
(let (($x347 (= v_1_ip_zero v_0_ip_zero)))
(let (($x346 (= v_1_icmp_wire v_0_icmp_wire)))
(let (($x345 (= v_1_icmp_zero v_0_icmp_zero)))
(let (($x344 (= v_1_reply v_0_reply)))
(let (($x343 (= now_1 now_0)))
(let (($x342 (= state_1 state_0)))
(and $x342 $x343 $x344 $x345 $x346 $x347 $x348)))))))))
(check-sat)

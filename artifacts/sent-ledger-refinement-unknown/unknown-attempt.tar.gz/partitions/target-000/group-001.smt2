; benchmark generated from python API
(set-info :status unknown)
(declare-fun v_0_snd_buf () Int)
(declare-fun v_0_rtx_buf () Int)
(declare-fun v_0_rcv_buf () Int)
(declare-fun v_0_rx_chunk () Int)
(declare-fun v_0_rx_slot_00 () Int)
(declare-fun v_0_rx_slot_01 () Int)
(declare-fun v_0_rx_slot_02 () Int)
(declare-fun v_0_rx_slot_03 () Int)
(declare-fun v_0_rx_slot_04 () Int)
(declare-fun v_0_rx_slot_05 () Int)
(declare-fun v_0_rx_slot_06 () Int)
(declare-fun v_0_rx_slot_07 () Int)
(declare-fun v_0_rx_slot_08 () Int)
(declare-fun v_0_rx_slot_09 () Int)
(declare-fun v_0_rx_slot_10 () Int)
(declare-fun v_0_rx_slot_11 () Int)
(declare-fun v_0_rx_slot_12 () Int)
(declare-fun v_0_rx_slot_13 () Int)
(declare-fun v_0_rx_slot_14 () Int)
(declare-fun v_0_rx_slot_15 () Int)
(declare-fun v_1_snd_buf () Int)
(declare-fun v_1_rtx_buf () Int)
(declare-fun v_1_rcv_buf () Int)
(declare-fun v_1_rx_chunk () Int)
(declare-fun v_1_rx_slot_00 () Int)
(declare-fun v_1_rx_slot_01 () Int)
(declare-fun v_1_rx_slot_02 () Int)
(declare-fun v_1_rx_slot_03 () Int)
(declare-fun v_1_rx_slot_04 () Int)
(declare-fun v_1_rx_slot_05 () Int)
(declare-fun v_1_rx_slot_06 () Int)
(declare-fun v_1_rx_slot_07 () Int)
(declare-fun v_1_rx_slot_08 () Int)
(declare-fun v_1_rx_slot_09 () Int)
(declare-fun v_1_rx_slot_10 () Int)
(declare-fun v_1_rx_slot_11 () Int)
(declare-fun v_1_rx_slot_12 () Int)
(declare-fun v_1_rx_slot_13 () Int)
(declare-fun v_1_rx_slot_14 () Int)
(declare-fun v_1_rx_slot_15 () Int)
(declare-fun v_0_iss () Int)
(declare-fun v_0_irs () Int)
(declare-fun v_0_snd_una () Int)
(declare-fun v_0_snd_nxt () Int)
(declare-fun v_0_rcv_nxt () Int)
(declare-fun v_0_tx_seq () Int)
(declare-fun v_0_tx_ack () Int)
(declare-fun v_0_snd_wl1 () Int)
(declare-fun v_0_snd_wl2 () Int)
(declare-fun v_0_fin_seq () Int)
(declare-fun v_0_rx_fin_seq () Int)
(declare-fun v_0_rtt_end () Int)
(declare-fun v_0_cc_before_una () Int)
(declare-fun v_0_fr_before_una () Int)
(declare-fun v_0_fr_before_nxt () Int)
(declare-fun v_0_lt_before_nxt () Int)
(declare-fun v_0_choice_before_nxt () Int)
(declare-fun v_0_cb_before_nxt () Int)
(declare-fun v_0_cb_append_end () Int)
(declare-fun v_0_cb_end_00 () Int)
(declare-fun v_0_cb_end_01 () Int)
(declare-fun v_0_cb_end_02 () Int)
(declare-fun v_0_cb_end_03 () Int)
(declare-fun v_0_cb_end_04 () Int)
(declare-fun v_0_cb_end_05 () Int)
(declare-fun v_0_cb_end_06 () Int)
(declare-fun v_0_cb_end_07 () Int)
(declare-fun v_0_cb_end_08 () Int)
(declare-fun v_0_cb_end_09 () Int)
(declare-fun v_0_cb_end_10 () Int)
(declare-fun v_0_cb_end_11 () Int)
(declare-fun v_0_cb_end_12 () Int)
(declare-fun v_0_cb_end_13 () Int)
(declare-fun v_0_cb_end_14 () Int)
(declare-fun v_0_cb_end_15 () Int)
(declare-fun v_1_iss () Int)
(declare-fun v_1_irs () Int)
(declare-fun v_1_snd_una () Int)
(declare-fun v_1_snd_nxt () Int)
(declare-fun v_1_rcv_nxt () Int)
(declare-fun v_1_tx_seq () Int)
(declare-fun v_1_tx_ack () Int)
(declare-fun v_1_snd_wl1 () Int)
(declare-fun v_1_snd_wl2 () Int)
(declare-fun v_1_fin_seq () Int)
(declare-fun v_1_rx_fin_seq () Int)
(declare-fun v_1_rtt_end () Int)
(declare-fun v_1_cc_before_una () Int)
(declare-fun v_1_fr_before_una () Int)
(declare-fun v_1_fr_before_nxt () Int)
(declare-fun v_1_lt_before_nxt () Int)
(declare-fun v_1_choice_before_nxt () Int)
(declare-fun v_1_cb_before_nxt () Int)
(declare-fun v_1_cb_append_end () Int)
(declare-fun v_1_cb_end_00 () Int)
(declare-fun v_1_cb_end_01 () Int)
(declare-fun v_1_cb_end_02 () Int)
(declare-fun v_1_cb_end_03 () Int)
(declare-fun v_1_cb_end_04 () Int)
(declare-fun v_1_cb_end_05 () Int)
(declare-fun v_1_cb_end_06 () Int)
(declare-fun v_1_cb_end_07 () Int)
(declare-fun v_1_cb_end_08 () Int)
(declare-fun v_1_cb_end_09 () Int)
(declare-fun v_1_cb_end_10 () Int)
(declare-fun v_1_cb_end_11 () Int)
(declare-fun v_1_cb_end_12 () Int)
(declare-fun v_1_cb_end_13 () Int)
(declare-fun v_1_cb_end_14 () Int)
(declare-fun v_1_cb_end_15 () Int)
(declare-fun now_0 () Int)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_delack () Int)
(declare-fun active_0_delack () Bool)
(declare-fun due_0_persist () Int)
(declare-fun active_0_persist () Bool)
(declare-fun input_0_app.send_data () Int)
(declare-fun input_0_net.data_data () Int)
(declare-fun input_0_net.fin_segment_data () Int)
(declare-fun input_0_net.syn_seq () Int)
(declare-fun input_0_net.synack_seq () Int)
(declare-fun input_0_net.synack_ack () Int)
(declare-fun input_0_net.ack_seq () Int)
(declare-fun input_0_net.ack_ack () Int)
(declare-fun input_0_net.fin_seq () Int)
(declare-fun input_0_net.fin_ack () Int)
(declare-fun input_0_net.rst_seq () Int)
(declare-fun input_0_net.rstack_seq () Int)
(declare-fun input_0_net.rstack_ack () Int)
(declare-fun input_0_net.data_seq () Int)
(declare-fun input_0_net.data_ack () Int)
(declare-fun input_0_net.fin_segment_seq () Int)
(declare-fun input_0_net.fin_segment_ack () Int)
(declare-fun v_0_persist_interval_ms () Int)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_persist_active () Bool)
(declare-fun v_0_fin_sent () Bool)
(declare-fun v_0_snd_wnd () Int)
(declare-fun now_1 () Int)
(declare-fun due_1_persist () Int)
(declare-fun due_1_delack () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_persist () Bool)
(declare-fun active_1_delack () Bool)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_cb_done_15 () Bool)
(declare-fun v_0_cb_length_15 () Int)
(declare-fun v_1_cb_length_15 () Int)
(declare-fun v_1_cb_done_14 () Bool)
(declare-fun v_0_cb_length_14 () Int)
(declare-fun v_1_cb_length_14 () Int)
(declare-fun v_1_cb_done_13 () Bool)
(declare-fun v_0_cb_length_13 () Int)
(declare-fun v_1_cb_length_13 () Int)
(declare-fun v_1_cb_done_12 () Bool)
(declare-fun v_0_cb_length_12 () Int)
(declare-fun v_1_cb_length_12 () Int)
(declare-fun v_1_cb_done_11 () Bool)
(declare-fun v_0_cb_length_11 () Int)
(declare-fun v_1_cb_length_11 () Int)
(declare-fun v_1_cb_done_10 () Bool)
(declare-fun v_0_cb_length_10 () Int)
(declare-fun v_1_cb_length_10 () Int)
(declare-fun v_1_cb_done_09 () Bool)
(declare-fun v_0_cb_length_09 () Int)
(declare-fun v_1_cb_length_09 () Int)
(declare-fun v_1_cb_done_08 () Bool)
(declare-fun v_0_cb_length_08 () Int)
(declare-fun v_1_cb_length_08 () Int)
(declare-fun v_1_cb_done_07 () Bool)
(declare-fun v_0_cb_length_07 () Int)
(declare-fun v_1_cb_length_07 () Int)
(declare-fun v_1_cb_done_06 () Bool)
(declare-fun v_0_cb_length_06 () Int)
(declare-fun v_1_cb_length_06 () Int)
(declare-fun v_1_cb_done_05 () Bool)
(declare-fun v_0_cb_length_05 () Int)
(declare-fun v_1_cb_length_05 () Int)
(declare-fun v_1_cb_done_04 () Bool)
(declare-fun v_0_cb_length_04 () Int)
(declare-fun v_1_cb_length_04 () Int)
(declare-fun v_1_cb_done_03 () Bool)
(declare-fun v_0_cb_length_03 () Int)
(declare-fun v_1_cb_length_03 () Int)
(declare-fun v_1_cb_done_02 () Bool)
(declare-fun v_0_cb_length_02 () Int)
(declare-fun v_1_cb_length_02 () Int)
(declare-fun v_1_cb_done_01 () Bool)
(declare-fun v_0_cb_length_01 () Int)
(declare-fun v_1_cb_length_01 () Int)
(declare-fun v_1_cb_done_00 () Bool)
(declare-fun v_0_cb_length_00 () Int)
(declare-fun v_1_cb_length_00 () Int)
(declare-fun v_1_cb_is_new () Bool)
(declare-fun v_1_cb_drop_step () Int)
(declare-fun v_0_cb_abandoned_total () Int)
(declare-fun v_1_cb_abandoned_total () Int)
(declare-fun v_0_cb_acked_total () Int)
(declare-fun v_1_cb_acked_total () Int)
(declare-fun v_0_cb_emitted_total () Int)
(declare-fun v_1_cb_emitted_total () Int)
(declare-fun v_1_cb_partial_prefix () Int)
(declare-fun v_1_cb_live_total () Int)
(declare-fun v_1_cb_step_bytes () Int)
(declare-fun v_1_cb_retired_count () Int)
(declare-fun v_1_cb_append_length () Int)
(declare-fun v_1_cb_new_count () Int)
(declare-fun v_0_cb_count () Int)
(declare-fun v_1_cb_count () Int)
(declare-fun v_0_cb_tail () Int)
(declare-fun v_1_cb_tail () Int)
(declare-fun v_0_cb_head () Int)
(declare-fun v_1_cb_head () Int)
(declare-fun v_0_svc_abandoned_bytes () Int)
(declare-fun v_1_svc_abandoned_bytes () Int)
(declare-fun v_0_svc_acked_bytes () Int)
(declare-fun v_1_svc_acked_bytes () Int)
(declare-fun v_0_svc_written_bytes () Int)
(declare-fun v_1_svc_written_bytes () Int)
(declare-fun v_1_svc_drop_step () Int)
(declare-fun v_1_svc_ack_step () Int)
(declare-fun v_1_svc_accept_step () Int)
(declare-fun v_1_svc_before_total () Int)
(declare-fun v_1_sched_packets () Int)
(declare-fun v_1_sched_bytes () Int)
(declare-fun v_1_sched_cause () Int)
(declare-fun v_0_sched_at_ms () Int)
(declare-fun v_1_sched_at_ms () Int)
(declare-fun v_1_sched_open () Bool)
(declare-fun v_0_choice_before_flight () Int)
(declare-fun v_1_choice_before_flight () Int)
(declare-fun v_0_choice_limit () Int)
(declare-fun v_1_choice_limit () Int)
(declare-fun v_0_choice_count () Int)
(declare-fun v_1_choice_count () Int)
(declare-fun v_1_choice_used () Bool)
(declare-fun v_0_lt_epoch_bytes () Int)
(declare-fun v_1_lt_loss_flight () Int)
(declare-fun v_1_lt_before_window () Int)
(declare-fun v_1_lt_before_flight () Int)
(declare-fun v_0_cc_cwnd () Int)
(declare-fun v_1_lt_before_cwnd () Int)
(declare-fun v_1_lt_before_bytes () Int)
(declare-fun v_0_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_bytes () Int)
(declare-fun v_1_lt_take () Int)
(declare-fun v_1_lt_emitted () Bool)
(declare-fun v_1_lt_eligible () Bool)
(declare-fun v_0_idle_restart_count () Int)
(declare-fun v_1_idle_restart_count () Int)
(declare-fun v_0_cc_ssthresh () Int)
(declare-fun v_1_idle_before_threshold () Int)
(declare-fun v_1_idle_before_rto () Int)
(declare-fun v_1_idle_before_cwnd () Int)
(declare-fun v_0_idle_last_data_ms () Int)
(declare-fun v_0_idle_data_valid () Bool)
(declare-fun v_1_idle_elapsed_ms () Int)
(declare-fun v_1_idle_restart () Bool)
(declare-fun v_1_idle_data_emitted () Bool)
(declare-fun v_1_idle_event_ms () Int)
(declare-fun v_1_idle_last_data_ms () Int)
(declare-fun v_1_idle_data_valid () Bool)
(declare-fun v_0_fr_entries () Int)
(declare-fun v_1_fr_entries () Int)
(declare-fun v_1_fr_emit_count () Int)
(declare-fun v_1_fr_retransmitted () Bool)
(declare-fun v_1_fr_exited () Bool)
(declare-fun v_1_fr_extra () Bool)
(declare-fun v_1_fr_entered () Bool)
(declare-fun v_1_fr_duplicate () Bool)
(declare-fun v_0_retries () Int)
(declare-fun v_1_fr_before_retries () Int)
(declare-fun v_1_fr_before_rto () Int)
(declare-fun v_1_fr_before_flight () Int)
(declare-fun v_0_fr_active () Bool)
(declare-fun v_1_fr_was_active () Bool)
(declare-fun v_0_fr_last_window () Int)
(declare-fun v_1_fr_last_window () Int)
(declare-fun v_0_fr_window_valid () Bool)
(declare-fun v_1_fr_window_valid () Bool)
(declare-fun v_0_fr_dupacks () Int)
(declare-fun v_1_fr_dupacks () Int)
(declare-fun v_1_fr_active () Bool)
(declare-fun v_1_fr_before_window_valid () Bool)
(declare-fun v_1_fr_before_wire_window () Int)
(declare-fun v_1_fr_window_ignored () Bool)
(declare-fun v_0_cc_rto_15 () Bool)
(declare-fun v_1_cc_rto_15 () Bool)
(declare-fun v_0_cc_rto_14 () Bool)
(declare-fun v_1_cc_rto_14 () Bool)
(declare-fun v_0_cc_rto_13 () Bool)
(declare-fun v_1_cc_rto_13 () Bool)
(declare-fun v_0_cc_rto_12 () Bool)
(declare-fun v_1_cc_rto_12 () Bool)
(declare-fun v_0_cc_rto_11 () Bool)
(declare-fun v_1_cc_rto_11 () Bool)
(declare-fun v_0_cc_rto_10 () Bool)
(declare-fun v_1_cc_rto_10 () Bool)
(declare-fun v_0_cc_rto_09 () Bool)
(declare-fun v_1_cc_rto_09 () Bool)
(declare-fun v_0_cc_rto_08 () Bool)
(declare-fun v_1_cc_rto_08 () Bool)
(declare-fun v_0_cc_rto_07 () Bool)
(declare-fun v_1_cc_rto_07 () Bool)
(declare-fun v_0_cc_rto_06 () Bool)
(declare-fun v_1_cc_rto_06 () Bool)
(declare-fun v_0_cc_rto_05 () Bool)
(declare-fun v_1_cc_rto_05 () Bool)
(declare-fun v_0_cc_rto_04 () Bool)
(declare-fun v_1_cc_rto_04 () Bool)
(declare-fun v_0_cc_rto_03 () Bool)
(declare-fun v_1_cc_rto_03 () Bool)
(declare-fun v_0_cc_rto_02 () Bool)
(declare-fun v_1_cc_rto_02 () Bool)
(declare-fun v_0_cc_rto_01 () Bool)
(declare-fun v_1_cc_rto_01 () Bool)
(declare-fun v_0_cc_rto_00 () Bool)
(declare-fun v_1_cc_rto_00 () Bool)
(declare-fun v_1_cc_new_sent () Int)
(declare-fun v_1_cc_send_budget () Int)
(declare-fun v_1_cc_before_cwnd () Int)
(declare-fun v_1_cc_growth () Int)
(declare-fun v_0_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_changed () Bool)
(declare-fun v_1_cc_loss () Bool)
(declare-fun v_1_cc_before_window () Int)
(declare-fun v_1_cc_before_persist () Bool)
(declare-fun v_1_cc_before_flight () Int)
(declare-fun v_1_cc_acked () Int)
(declare-fun v_0_cc_ca_credit () Int)
(declare-fun v_1_cc_ca_credit () Int)
(declare-fun v_1_cc_ssthresh () Int)
(declare-fun v_1_cc_cwnd () Int)
(declare-fun v_0_cc_initial_threshold () Int)
(declare-fun v_1_cc_initial_threshold () Int)
(declare-fun v_0_cc_initial_window () Int)
(declare-fun v_1_cc_initial_window () Int)
(declare-fun v_0_persist_elapsed_ms () Int)
(declare-fun v_1_persist_elapsed_ms () Int)
(declare-fun v_0_persist_probes () Int)
(declare-fun v_1_persist_probes () Int)
(declare-fun v_0_persist_deadline_ms () Int)
(declare-fun v_1_persist_deadline_ms () Int)
(declare-fun v_0_persist_last_ms () Int)
(declare-fun v_1_persist_last_ms () Int)
(declare-fun v_0_persist_since_ms () Int)
(declare-fun v_1_persist_since_ms () Int)
(declare-fun v_0_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_interval_ms () Int)
(declare-fun v_1_persist_probe_new () Bool)
(declare-fun v_1_persist_probe_sent () Bool)
(declare-fun v_1_persist_first () Bool)
(declare-fun v_1_persist_was_active () Bool)
(declare-fun v_1_persist_start () Bool)
(declare-fun v_1_persist_eligible () Bool)
(declare-fun v_1_persist_active () Bool)
(declare-fun v_1_ack_defer_now () Bool)
(declare-fun v_1_ack_defer_candidate () Bool)
(declare-fun v_0_ack_rmss () Int)
(declare-fun v_1_ack_rmss () Int)
(declare-fun v_0_ack_delay_ms () Int)
(declare-fun v_1_ack_delay_ms () Int)
(declare-fun v_0_ack_full_segments () Int)
(declare-fun v_1_ack_full_segments () Int)
(declare-fun v_0_ack_bytes () Int)
(declare-fun v_1_ack_bytes () Int)
(declare-fun v_0_ack_since_ms () Int)
(declare-fun v_1_ack_since_ms () Int)
(declare-fun v_0_ack_pending () Bool)
(declare-fun v_1_ack_pending () Bool)
(declare-fun v_1_syn_timeout_eligible () Bool)
(declare-fun v_1_tx_syn_pending () Bool)
(declare-fun v_1_tx_syn_time () Int)
(declare-fun v_1_tx_waiting () Bool)
(declare-fun v_0_tx_is_fin () Bool)
(declare-fun v_1_tx_is_fin () Bool)
(declare-fun v_0_tx_previous_rto () Int)
(declare-fun v_1_tx_previous_rto () Int)
(declare-fun v_0_tx_elapsed () Int)
(declare-fun v_1_tx_elapsed () Int)
(declare-fun v_1_tx_retransmitted () Bool)
(declare-fun v_0_tx_max_previous () Int)
(declare-fun v_1_tx_max_previous () Int)
(declare-fun v_0_tx_eligible () Int)
(declare-fun v_1_tx_eligible () Int)
(declare-fun v_0_tx_emit_count () Int)
(declare-fun v_1_tx_emit_count () Int)
(declare-fun v_0_tx_fin_time () Int)
(declare-fun v_0_fin_acknowledged () Bool)
(declare-fun v_1_tx_fin_time () Int)
(declare-fun v_0_tx_time_15 () Int)
(declare-fun v_1_tx_time_15 () Int)
(declare-fun v_0_tx_time_14 () Int)
(declare-fun v_1_tx_time_14 () Int)
(declare-fun v_0_tx_time_13 () Int)
(declare-fun v_1_tx_time_13 () Int)
(declare-fun v_0_tx_time_12 () Int)
(declare-fun v_1_tx_time_12 () Int)
(declare-fun v_0_tx_time_11 () Int)
(declare-fun v_1_tx_time_11 () Int)
(declare-fun v_0_tx_time_10 () Int)
(declare-fun v_1_tx_time_10 () Int)
(declare-fun v_0_tx_time_09 () Int)
(declare-fun v_1_tx_time_09 () Int)
(declare-fun v_0_tx_time_08 () Int)
(declare-fun v_1_tx_time_08 () Int)
(declare-fun v_0_tx_time_07 () Int)
(declare-fun v_1_tx_time_07 () Int)
(declare-fun v_0_tx_time_06 () Int)
(declare-fun v_1_tx_time_06 () Int)
(declare-fun v_0_tx_time_05 () Int)
(declare-fun v_1_tx_time_05 () Int)
(declare-fun v_0_tx_time_04 () Int)
(declare-fun v_1_tx_time_04 () Int)
(declare-fun v_0_tx_time_03 () Int)
(declare-fun v_1_tx_time_03 () Int)
(declare-fun v_0_tx_time_02 () Int)
(declare-fun v_1_tx_time_02 () Int)
(declare-fun v_0_tx_time_01 () Int)
(declare-fun v_1_tx_time_01 () Int)
(declare-fun v_0_tx_time_00 () Int)
(declare-fun v_1_tx_time_00 () Int)
(declare-fun v_0_rto_base_ms () Int)
(declare-fun v_1_rto_base_ms () Int)
(declare-fun v_0_rtt_samples () Int)
(declare-fun v_1_rtt_samples () Int)
(declare-fun v_0_rtt_last_ms () Int)
(declare-fun v_1_rtt_last_ms () Int)
(declare-fun v_1_rtt_sample_was_ambiguous () Bool)
(declare-fun v_1_rtt_sample_used () Bool)
(declare-fun v_1_rtt_start_new () Bool)
(declare-fun v_0_rtt_remaining () Int)
(declare-fun v_1_rtt_remaining () Int)
(declare-fun v_0_rtt_start_ms () Int)
(declare-fun v_1_rtt_start_ms () Int)
(declare-fun v_0_rtt_sample_at_ms () Int)
(declare-fun v_1_rtt_sample_at_ms () Int)
(declare-fun v_0_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_ambiguous () Bool)
(declare-fun v_0_rtt_active () Bool)
(declare-fun v_1_rtt_active () Bool)
(declare-fun v_0_rtt_previous_measured () Bool)
(declare-fun v_1_rtt_previous_measured () Bool)
(declare-fun v_0_rtt_measured () Bool)
(declare-fun v_1_rtt_measured () Bool)
(declare-fun v_0_rtt_previous_var () Real)
(declare-fun v_1_rtt_previous_var () Real)
(declare-fun v_0_rtt_previous_srtt () Real)
(declare-fun v_1_rtt_previous_srtt () Real)
(declare-fun v_0_rtt_error_ms () Real)
(declare-fun v_1_rtt_error_ms () Real)
(declare-fun v_0_rttvar_ms () Real)
(declare-fun v_1_rttvar_ms () Real)
(declare-fun v_0_srtt_ms () Real)
(declare-fun v_1_srtt_ms () Real)
(declare-fun v_0_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_consumed () Bool)
(declare-fun v_0_rx_fin_done () Bool)
(declare-fun v_1_rx_fin_done () Bool)
(declare-fun v_0_rx_fin_offset () Int)
(declare-fun v_1_rx_fin_offset () Int)
(declare-fun v_0_rx_fin_pending () Bool)
(declare-fun v_1_rx_fin_pending () Bool)
(declare-fun v_1_fin_acknowledged () Bool)
(declare-fun v_1_fin_sent () Bool)
(declare-fun v_0_fin_requested () Bool)
(declare-fun v_1_fin_requested () Bool)
(declare-fun v_0_ack_window_update () Bool)
(declare-fun v_1_ack_window_update () Bool)
(declare-fun v_0_ack_advance () Bool)
(declare-fun v_1_ack_advance () Bool)
(declare-fun v_0_ack_is_future () Bool)
(declare-fun v_1_ack_is_future () Bool)
(declare-fun v_0_ack_is_new () Bool)
(declare-fun v_1_ack_is_new () Bool)
(declare-fun v_0_ack_delta () Int)
(declare-fun v_1_ack_delta () Int)
(declare-fun v_0_seg_acceptable () Bool)
(declare-fun v_1_seg_acceptable () Bool)
(declare-fun v_0_rx_acceptable () Bool)
(declare-fun v_1_rx_acceptable () Bool)
(declare-fun v_0_rx_advance () Int)
(declare-fun v_1_rx_advance () Int)
(declare-fun v_0_take () Int)
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_1_local_window () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_0_tx_flags () String)
(declare-fun v_1_tx_flags () String)
(declare-fun v_0_rtt_sample_was_ambiguous () Bool)
(declare-fun v_0_rtt_sample_used () Bool)
(declare-fun v_0_tx_retransmitted () Bool)
(declare-fun v_0_tx_waiting () Bool)
(declare-fun v_0_tx_syn_time () Int)
(declare-fun v_0_tx_syn_pending () Bool)
(declare-fun v_0_persist_probe_sent () Bool)
(declare-fun v_0_cc_acked () Int)
(declare-fun v_0_cc_growth () Int)
(declare-fun v_0_cc_send_budget () Int)
(declare-fun v_0_cc_new_sent () Int)
(declare-fun v_0_fr_emit_count () Int)
(declare-fun v_0_fr_before_retries () Int)
(declare-fun v_0_fr_before_rto () Int)
(declare-fun v_0_fr_entered () Bool)
(declare-fun v_0_fr_retransmitted () Bool)
(declare-fun v_0_fr_before_window_valid () Bool)
(declare-fun v_0_fr_before_wire_window () Int)
(declare-fun v_0_fr_window_ignored () Bool)
(declare-fun v_0_fr_exited () Bool)
(declare-fun v_0_idle_elapsed_ms () Int)
(declare-fun v_0_idle_event_ms () Int)
(declare-fun v_0_idle_data_emitted () Bool)
(declare-fun v_0_idle_before_threshold () Int)
(declare-fun v_0_idle_before_cwnd () Int)
(declare-fun v_0_idle_before_rto () Int)
(declare-fun v_0_idle_restart () Bool)
(declare-fun v_0_lt_loss_flight () Int)
(declare-fun v_0_lt_take () Int)
(declare-fun v_0_lt_before_flight () Int)
(declare-fun v_0_lt_before_cwnd () Int)
(declare-fun v_0_fr_duplicate () Bool)
(declare-fun v_0_lt_emitted () Bool)
(declare-fun v_0_lt_before_bytes () Int)
(declare-fun v_0_fr_before_flight () Int)
(declare-fun v_0_choice_used () Bool)
(declare-fun v_0_sched_bytes () Int)
(declare-fun v_0_sched_packets () Int)
(declare-fun v_0_sched_cause () Int)
(declare-fun v_0_sched_open () Bool)
(declare-fun v_0_svc_drop_step () Int)
(declare-fun v_0_svc_ack_step () Int)
(declare-fun v_0_svc_accept_step () Int)
(declare-fun v_0_cb_new_count () Int)
(declare-fun v_0_cb_live_total () Int)
(declare-fun v_0_cb_drop_step () Int)
(declare-fun v_0_cb_step_bytes () Int)
(declare-fun v_0_cb_partial_prefix () Int)
(declare-fun choice_0 () Int)
(declare-fun state_0 () Int)
(declare-fun state_1 () Int)
(assert
 (>= v_0_snd_buf 0))
(assert
 (>= v_0_rtx_buf 0))
(assert
 (>= v_0_rcv_buf 0))
(assert
 (>= v_0_rx_chunk 0))
(assert
 (>= v_0_rx_slot_00 0))
(assert
 (>= v_0_rx_slot_01 0))
(assert
 (>= v_0_rx_slot_02 0))
(assert
 (>= v_0_rx_slot_03 0))
(assert
 (>= v_0_rx_slot_04 0))
(assert
 (>= v_0_rx_slot_05 0))
(assert
 (>= v_0_rx_slot_06 0))
(assert
 (>= v_0_rx_slot_07 0))
(assert
 (>= v_0_rx_slot_08 0))
(assert
 (>= v_0_rx_slot_09 0))
(assert
 (>= v_0_rx_slot_10 0))
(assert
 (>= v_0_rx_slot_11 0))
(assert
 (>= v_0_rx_slot_12 0))
(assert
 (>= v_0_rx_slot_13 0))
(assert
 (>= v_0_rx_slot_14 0))
(assert
 (>= v_0_rx_slot_15 0))
(assert
 (>= v_1_snd_buf 0))
(assert
 (>= v_1_rtx_buf 0))
(assert
 (>= v_1_rcv_buf 0))
(assert
 (>= v_1_rx_chunk 0))
(assert
 (>= v_1_rx_slot_00 0))
(assert
 (>= v_1_rx_slot_01 0))
(assert
 (>= v_1_rx_slot_02 0))
(assert
 (>= v_1_rx_slot_03 0))
(assert
 (>= v_1_rx_slot_04 0))
(assert
 (>= v_1_rx_slot_05 0))
(assert
 (>= v_1_rx_slot_06 0))
(assert
 (>= v_1_rx_slot_07 0))
(assert
 (>= v_1_rx_slot_08 0))
(assert
 (>= v_1_rx_slot_09 0))
(assert
 (>= v_1_rx_slot_10 0))
(assert
 (>= v_1_rx_slot_11 0))
(assert
 (>= v_1_rx_slot_12 0))
(assert
 (>= v_1_rx_slot_13 0))
(assert
 (>= v_1_rx_slot_14 0))
(assert
 (>= v_1_rx_slot_15 0))
(assert
 (>= v_0_iss 0))
(assert
 (not (<= 4294967296 v_0_iss)))
(assert
 (>= v_0_irs 0))
(assert
 (not (<= 4294967296 v_0_irs)))
(assert
 (>= v_0_snd_una 0))
(assert
 (not (<= 4294967296 v_0_snd_una)))
(assert
 (>= v_0_snd_nxt 0))
(assert
 (not (<= 4294967296 v_0_snd_nxt)))
(assert
 (>= v_0_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_0_rcv_nxt)))
(assert
 (>= v_0_tx_seq 0))
(assert
 (not (<= 4294967296 v_0_tx_seq)))
(assert
 (>= v_0_tx_ack 0))
(assert
 (not (<= 4294967296 v_0_tx_ack)))
(assert
 (>= v_0_snd_wl1 0))
(assert
 (not (<= 4294967296 v_0_snd_wl1)))
(assert
 (>= v_0_snd_wl2 0))
(assert
 (not (<= 4294967296 v_0_snd_wl2)))
(assert
 (>= v_0_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_fin_seq)))
(assert
 (>= v_0_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_rx_fin_seq)))
(assert
 (>= v_0_rtt_end 0))
(assert
 (not (<= 4294967296 v_0_rtt_end)))
(assert
 (>= v_0_cc_before_una 0))
(assert
 (not (<= 4294967296 v_0_cc_before_una)))
(assert
 (>= v_0_fr_before_una 0))
(assert
 (not (<= 4294967296 v_0_fr_before_una)))
(assert
 (>= v_0_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_fr_before_nxt)))
(assert
 (>= v_0_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_lt_before_nxt)))
(assert
 (>= v_0_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_choice_before_nxt)))
(assert
 (>= v_0_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_cb_before_nxt)))
(assert
 (>= v_0_cb_append_end 0))
(assert
 (not (<= 4294967296 v_0_cb_append_end)))
(assert
 (>= v_0_cb_end_00 0))
(assert
 (not (<= 4294967296 v_0_cb_end_00)))
(assert
 (>= v_0_cb_end_01 0))
(assert
 (not (<= 4294967296 v_0_cb_end_01)))
(assert
 (>= v_0_cb_end_02 0))
(assert
 (not (<= 4294967296 v_0_cb_end_02)))
(assert
 (>= v_0_cb_end_03 0))
(assert
 (not (<= 4294967296 v_0_cb_end_03)))
(assert
 (>= v_0_cb_end_04 0))
(assert
 (not (<= 4294967296 v_0_cb_end_04)))
(assert
 (>= v_0_cb_end_05 0))
(assert
 (not (<= 4294967296 v_0_cb_end_05)))
(assert
 (>= v_0_cb_end_06 0))
(assert
 (not (<= 4294967296 v_0_cb_end_06)))
(assert
 (>= v_0_cb_end_07 0))
(assert
 (not (<= 4294967296 v_0_cb_end_07)))
(assert
 (>= v_0_cb_end_08 0))
(assert
 (not (<= 4294967296 v_0_cb_end_08)))
(assert
 (>= v_0_cb_end_09 0))
(assert
 (not (<= 4294967296 v_0_cb_end_09)))
(assert
 (>= v_0_cb_end_10 0))
(assert
 (not (<= 4294967296 v_0_cb_end_10)))
(assert
 (>= v_0_cb_end_11 0))
(assert
 (not (<= 4294967296 v_0_cb_end_11)))
(assert
 (>= v_0_cb_end_12 0))
(assert
 (not (<= 4294967296 v_0_cb_end_12)))
(assert
 (>= v_0_cb_end_13 0))
(assert
 (not (<= 4294967296 v_0_cb_end_13)))
(assert
 (>= v_0_cb_end_14 0))
(assert
 (not (<= 4294967296 v_0_cb_end_14)))
(assert
 (>= v_0_cb_end_15 0))
(assert
 (not (<= 4294967296 v_0_cb_end_15)))
(assert
 (>= v_1_iss 0))
(assert
 (not (<= 4294967296 v_1_iss)))
(assert
 (>= v_1_irs 0))
(assert
 (not (<= 4294967296 v_1_irs)))
(assert
 (>= v_1_snd_una 0))
(assert
 (not (<= 4294967296 v_1_snd_una)))
(assert
 (>= v_1_snd_nxt 0))
(assert
 (not (<= 4294967296 v_1_snd_nxt)))
(assert
 (>= v_1_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_1_rcv_nxt)))
(assert
 (>= v_1_tx_seq 0))
(assert
 (not (<= 4294967296 v_1_tx_seq)))
(assert
 (>= v_1_tx_ack 0))
(assert
 (not (<= 4294967296 v_1_tx_ack)))
(assert
 (>= v_1_snd_wl1 0))
(assert
 (not (<= 4294967296 v_1_snd_wl1)))
(assert
 (>= v_1_snd_wl2 0))
(assert
 (not (<= 4294967296 v_1_snd_wl2)))
(assert
 (>= v_1_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_fin_seq)))
(assert
 (>= v_1_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_rx_fin_seq)))
(assert
 (>= v_1_rtt_end 0))
(assert
 (not (<= 4294967296 v_1_rtt_end)))
(assert
 (>= v_1_cc_before_una 0))
(assert
 (not (<= 4294967296 v_1_cc_before_una)))
(assert
 (>= v_1_fr_before_una 0))
(assert
 (not (<= 4294967296 v_1_fr_before_una)))
(assert
 (>= v_1_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_fr_before_nxt)))
(assert
 (>= v_1_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_lt_before_nxt)))
(assert
 (>= v_1_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_choice_before_nxt)))
(assert
 (>= v_1_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_cb_before_nxt)))
(assert
 (>= v_1_cb_append_end 0))
(assert
 (not (<= 4294967296 v_1_cb_append_end)))
(assert
 (>= v_1_cb_end_00 0))
(assert
 (not (<= 4294967296 v_1_cb_end_00)))
(assert
 (>= v_1_cb_end_01 0))
(assert
 (not (<= 4294967296 v_1_cb_end_01)))
(assert
 (>= v_1_cb_end_02 0))
(assert
 (not (<= 4294967296 v_1_cb_end_02)))
(assert
 (>= v_1_cb_end_03 0))
(assert
 (not (<= 4294967296 v_1_cb_end_03)))
(assert
 (>= v_1_cb_end_04 0))
(assert
 (not (<= 4294967296 v_1_cb_end_04)))
(assert
 (>= v_1_cb_end_05 0))
(assert
 (not (<= 4294967296 v_1_cb_end_05)))
(assert
 (>= v_1_cb_end_06 0))
(assert
 (not (<= 4294967296 v_1_cb_end_06)))
(assert
 (>= v_1_cb_end_07 0))
(assert
 (not (<= 4294967296 v_1_cb_end_07)))
(assert
 (>= v_1_cb_end_08 0))
(assert
 (not (<= 4294967296 v_1_cb_end_08)))
(assert
 (>= v_1_cb_end_09 0))
(assert
 (not (<= 4294967296 v_1_cb_end_09)))
(assert
 (>= v_1_cb_end_10 0))
(assert
 (not (<= 4294967296 v_1_cb_end_10)))
(assert
 (>= v_1_cb_end_11 0))
(assert
 (not (<= 4294967296 v_1_cb_end_11)))
(assert
 (>= v_1_cb_end_12 0))
(assert
 (not (<= 4294967296 v_1_cb_end_12)))
(assert
 (>= v_1_cb_end_13 0))
(assert
 (not (<= 4294967296 v_1_cb_end_13)))
(assert
 (>= v_1_cb_end_14 0))
(assert
 (not (<= 4294967296 v_1_cb_end_14)))
(assert
 (>= v_1_cb_end_15 0))
(assert
 (not (<= 4294967296 v_1_cb_end_15)))
(assert
 true)
(assert
 true)
(assert
 (>= now_0 0))
(assert
 (let (($x370 (not active_0_rtx)))
 (or $x370 (>= due_0_rtx now_0))))
(assert
 (let (($x375 (not active_0_user)))
 (or $x375 (>= due_0_user now_0))))
(assert
 (let (($x380 (not active_0_time_wait)))
 (or $x380 (>= due_0_time_wait now_0))))
(assert
 (let (($x385 (not active_0_delack)))
 (or $x385 (>= due_0_delack now_0))))
(assert
 (let (($x390 (not active_0_persist)))
 (or $x390 (>= due_0_persist now_0))))
(assert
 (>= input_0_app.send_data 0))
(assert
 (>= input_0_net.data_data 0))
(assert
 (>= input_0_net.fin_segment_data 0))
(assert
 (>= input_0_net.syn_seq 0))
(assert
 (not (<= 4294967296 input_0_net.syn_seq)))
(assert
 (>= input_0_net.synack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.synack_seq)))
(assert
 (>= input_0_net.synack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.synack_ack)))
(assert
 (>= input_0_net.ack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.ack_seq)))
(assert
 (>= input_0_net.ack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.ack_ack)))
(assert
 (>= input_0_net.fin_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_seq)))
(assert
 (>= input_0_net.fin_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_ack)))
(assert
 (>= input_0_net.rst_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rst_seq)))
(assert
 (>= input_0_net.rstack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_seq)))
(assert
 (>= input_0_net.rstack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_ack)))
(assert
 (>= input_0_net.data_seq 0))
(assert
 (not (<= 4294967296 input_0_net.data_seq)))
(assert
 (>= input_0_net.data_ack 0))
(assert
 (not (<= 4294967296 input_0_net.data_ack)))
(assert
 (>= input_0_net.fin_segment_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_seq)))
(assert
 (>= input_0_net.fin_segment_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_ack)))
(assert
 (let (($x801 (not v_0_persist_active)))
 (let (($x610 (= 0 v_0_rtx_buf)))
 (let (($x611 (or v_0_persist_active $x610)))
 (let (($x608 (>= 1 v_0_rtx_buf)))
 (let (($x607 (<= 1 (+ v_0_rtx_buf v_0_snd_buf input_0_app.send_data))))
 (let (($x605 (not v_0_fin_sent)))
 (let (($x604 (= 0 v_0_snd_wnd)))
 (let (($x802 (and $x604 $x605 $x607 $x608 $x611 $x801)))
 (let ((?x814 (ite $x802 v_0_rto_ms v_0_persist_interval_ms)))
 (let ((?x831 (+ now_1 ?x814)))
 (let (($x1324 (= due_1_delack due_0_delack)))
 (let (($x1322 (= due_1_time_wait due_0_time_wait)))
 (let (($x1320 (= due_1_user due_0_user)))
 (let ((?x1316 (+ now_1 v_0_rto_ms)))
 (let (($x1300 (<= 1 v_0_rtx_buf)))
 (let (($x612 (and $x604 $x605 $x607 $x608 $x611)))
 (let (($x613 (not $x612)))
 (let (($x1302 (and v_0_persist_active $x613 $x1300 (not (and $x613 active_0_rtx)))))
 (let (($x1314 (= active_1_persist (and $x604 $x605 $x607 $x608 $x611 (or active_0_persist $x802)))))
 (let (($x1310 (= active_1_delack active_0_delack)))
 (let (($x1308 (= active_1_time_wait active_0_time_wait)))
 (let (($x1306 (= active_1_user active_0_user)))
 (let (($x1297 (not v_1_cb_done_15)))
 (let ((?x1097 (ite (<= 0 input_0_app.send_data) input_0_app.send_data 0)))
 (let ((?x1103 (+ ?x1097 (* (- 1) input_0_app.send_data))))
 (let ((?x1105 (ite (<= 0 ?x1103) ?x1103 0)))
 (let (($x1119 (<= 1 ?x1105)))
 (let (($x1291 (not v_1_cb_done_14)))
 (let (($x1285 (not v_1_cb_done_13)))
 (let (($x1279 (not v_1_cb_done_12)))
 (let (($x1273 (not v_1_cb_done_11)))
 (let (($x1267 (not v_1_cb_done_10)))
 (let (($x1261 (not v_1_cb_done_09)))
 (let (($x1255 (not v_1_cb_done_08)))
 (let (($x1249 (not v_1_cb_done_07)))
 (let (($x1243 (not v_1_cb_done_06)))
 (let (($x1237 (not v_1_cb_done_05)))
 (let (($x1231 (not v_1_cb_done_04)))
 (let (($x1225 (not v_1_cb_done_03)))
 (let (($x1219 (not v_1_cb_done_02)))
 (let (($x1213 (not v_1_cb_done_01)))
 (let (($x1207 (not v_1_cb_done_00)))
 (let (($x1201 (not v_1_cb_is_new)))
 (let (($x1199 (= v_1_cb_append_end 0)))
 (let (($x1198 (= v_1_cb_before_nxt v_0_snd_nxt)))
 (let ((?x1192 (+ v_0_cb_length_00 v_0_cb_length_01 v_0_cb_length_02 v_0_cb_length_03 v_0_cb_length_04 v_0_cb_length_05 v_0_cb_length_06 v_0_cb_length_07 v_0_cb_length_08 v_0_cb_length_09 v_0_cb_length_10 v_0_cb_length_11 v_0_cb_length_12 v_0_cb_length_13 v_0_cb_length_14 v_0_cb_length_15)))
 (let ((?x1193 (ite $x1119 ?x1192 0)))
 (let (($x1189 (= v_1_cb_acked_total v_0_cb_acked_total)))
 (let (($x1186 (= v_1_cb_emitted_total v_0_cb_emitted_total)))
 (let ((?x881 (- 1)))
 (let ((?x882 (* ?x881 v_0_rtx_buf)))
 (let ((?x1178 (ite $x1119 0 v_0_cb_length_15)))
 (let ((?x1176 (ite $x1119 0 v_0_cb_length_14)))
 (let ((?x1174 (ite $x1119 0 v_0_cb_length_13)))
 (let ((?x1172 (ite $x1119 0 v_0_cb_length_12)))
 (let ((?x1170 (ite $x1119 0 v_0_cb_length_11)))
 (let ((?x1168 (ite $x1119 0 v_0_cb_length_10)))
 (let ((?x1166 (ite $x1119 0 v_0_cb_length_09)))
 (let ((?x1164 (ite $x1119 0 v_0_cb_length_08)))
 (let ((?x1162 (ite $x1119 0 v_0_cb_length_07)))
 (let ((?x1160 (ite $x1119 0 v_0_cb_length_06)))
 (let ((?x1158 (ite $x1119 0 v_0_cb_length_05)))
 (let ((?x1156 (ite $x1119 0 v_0_cb_length_04)))
 (let ((?x1154 (ite $x1119 0 v_0_cb_length_03)))
 (let ((?x1152 (ite $x1119 0 v_0_cb_length_02)))
 (let ((?x1150 (ite $x1119 0 v_0_cb_length_01)))
 (let ((?x1148 (ite $x1119 0 v_0_cb_length_00)))
 (let ((?x1182 (+ ?x1148 ?x1150 ?x1152 ?x1154 ?x1156 ?x1158 ?x1160 ?x1162 ?x1164 ?x1166 ?x1168 ?x1170 ?x1172 ?x1174 ?x1176 ?x1178 ?x882)))
 (let ((?x1179 (+ ?x1148 ?x1150 ?x1152 ?x1154 ?x1156 ?x1158 ?x1160 ?x1162 ?x1164 ?x1166 ?x1168 ?x1170 ?x1172 ?x1174 ?x1176 ?x1178)))
 (let (($x1145 (= v_1_cb_step_bytes 0)))
 (let (($x1143 (= v_1_cb_retired_count 0)))
 (let (($x1141 (= v_1_cb_append_length 0)))
 (let (($x1139 (= v_1_cb_new_count 0)))
 (let ((?x1129 (ite $x1119 0 v_0_cb_tail)))
 (let ((?x1125 (ite $x1119 0 (ite (<= 16 v_0_cb_head) (+ (- 16) v_0_cb_head) v_0_cb_head))))
 (let (($x1113 (= v_1_svc_acked_bytes v_0_svc_acked_bytes)))
 (let (($x1085 (= v_1_sched_at_ms v_0_sched_at_ms)))
 (let (($x1082 (not v_1_sched_open)))
 (let (($x1080 (= v_1_choice_before_flight v_0_choice_before_flight)))
 (let (($x1077 (= v_1_choice_before_nxt v_0_choice_before_nxt)))
 (let (($x1076 (= v_1_choice_limit v_0_choice_limit)))
 (let (($x1073 (= v_1_choice_count v_0_choice_count)))
 (let (($x1070 (not v_1_choice_used)))
 (let (($x1064 (= v_1_lt_before_window v_0_snd_wnd)))
 (let (($x1062 (= v_1_lt_before_flight v_0_rtx_buf)))
 (let (($x1060 (= v_1_lt_before_nxt v_0_snd_nxt)))
 (let (($x1059 (= v_1_lt_before_cwnd v_0_cc_cwnd)))
 (let (($x1057 (= v_1_lt_before_bytes v_0_lt_epoch_bytes)))
 (let (($x1055 (= v_1_lt_epoch_packets (ite (or $x610 $x612) 0 v_0_lt_epoch_packets))))
 (let (($x1045 (not v_1_lt_emitted)))
 (let (($x1043 (not v_1_lt_eligible)))
 (let (($x1041 (= v_1_idle_restart_count v_0_idle_restart_count)))
 (let (($x1038 (= v_1_idle_before_threshold v_0_cc_ssthresh)))
 (let (($x1036 (= v_1_idle_before_rto v_0_rto_ms)))
 (let (($x1034 (= v_1_idle_before_cwnd v_0_cc_cwnd)))
 (let ((?x1031 (ite v_0_idle_data_valid (+ now_1 (* ?x881 v_0_idle_last_data_ms)) 0)))
 (let (($x1027 (not v_1_idle_restart)))
 (let (($x1025 (not v_1_idle_data_emitted)))
 (let (($x1023 (= v_1_idle_event_ms now_1)))
 (let (($x1021 (= v_1_idle_last_data_ms v_0_idle_last_data_ms)))
 (let (($x1018 (= v_1_idle_data_valid v_0_idle_data_valid)))
 (let (($x1015 (= v_1_fr_entries v_0_fr_entries)))
 (let (($x1012 (= v_1_fr_emit_count 0)))
 (let (($x1010 (not v_1_fr_retransmitted)))
 (let (($x1008 (not v_1_fr_exited)))
 (let (($x1006 (not v_1_fr_extra)))
 (let (($x1004 (not v_1_fr_entered)))
 (let (($x1002 (not v_1_fr_duplicate)))
 (let (($x1000 (= v_1_fr_before_retries v_0_retries)))
 (let (($x998 (= v_1_fr_before_rto v_0_rto_ms)))
 (let (($x996 (= v_1_fr_before_flight v_0_rtx_buf)))
 (let (($x994 (= v_1_fr_before_nxt v_0_snd_nxt)))
 (let (($x993 (= v_1_fr_before_una v_0_snd_una)))
 (let (($x992 (= v_1_fr_was_active v_0_fr_active)))
 (let (($x990 (= v_1_fr_last_window v_0_fr_last_window)))
 (let (($x988 (= v_1_fr_window_valid v_0_fr_window_valid)))
 (let (($x976 (= v_1_fr_before_window_valid v_0_fr_window_valid)))
 (let (($x973 (= v_1_fr_before_wire_window v_0_fr_last_window)))
 (let (($x970 (not v_1_fr_window_ignored)))
 (let ((?x883 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd) ?x882)))
 (let (($x877 (= v_1_cc_before_cwnd v_0_cc_cwnd)))
 (let (($x873 (= v_1_cc_threshold_updates v_0_cc_threshold_updates)))
 (let (($x870 (not v_1_cc_threshold_changed)))
 (let (($x868 (not v_1_cc_loss)))
 (let (($x866 (= v_1_cc_before_window v_0_snd_wnd)))
 (let (($x864 (= v_1_cc_before_persist v_0_persist_active)))
 (let (($x862 (= v_1_cc_before_una v_0_snd_una)))
 (let (($x861 (= v_1_cc_before_flight v_0_rtx_buf)))
 (let (($x857 (= v_1_cc_ca_credit v_0_cc_ca_credit)))
 (let (($x854 (= v_1_cc_ssthresh v_0_cc_ssthresh)))
 (let (($x851 (= v_1_cc_cwnd v_0_cc_cwnd)))
 (let (($x848 (= v_1_cc_initial_threshold v_0_cc_initial_threshold)))
 (let (($x845 (= v_1_cc_initial_window v_0_cc_initial_window)))
 (let (($x842 (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)))
 (let (($x835 (= v_1_persist_deadline_ms (ite $x612 (ite $x802 ?x831 v_0_persist_deadline_ms) 0))))
 (let (($x825 (= v_1_persist_since_ms (ite $x612 (ite $x802 now_1 v_0_persist_since_ms) 0))))
 (let (($x820 (= v_1_persist_previous_interval_ms v_0_persist_previous_interval_ms)))
 (let (($x811 (not v_1_persist_probe_new)))
 (let (($x809 (not v_1_persist_probe_sent)))
 (let (($x807 (not v_1_persist_first)))
 (let (($x805 (= v_1_persist_was_active v_0_persist_active)))
 (let (($x795 (not v_1_ack_defer_now)))
 (let (($x793 (not v_1_ack_defer_candidate)))
 (let (($x791 (= v_1_ack_rmss v_0_ack_rmss)))
 (let (($x788 (= v_1_ack_delay_ms v_0_ack_delay_ms)))
 (let (($x785 (= v_1_ack_full_segments v_0_ack_full_segments)))
 (let (($x782 (= v_1_ack_bytes v_0_ack_bytes)))
 (let (($x779 (= v_1_ack_since_ms v_0_ack_since_ms)))
 (let (($x776 (= v_1_ack_pending v_0_ack_pending)))
 (let (($x773 (not v_1_syn_timeout_eligible)))
 (let (($x771 (not v_1_tx_syn_pending)))
 (let (($x769 (= v_1_tx_syn_time 0)))
 (let (($x767 (not v_1_tx_waiting)))
 (let (($x765 (= v_1_tx_is_fin v_0_tx_is_fin)))
 (let (($x762 (= v_1_tx_previous_rto v_0_tx_previous_rto)))
 (let (($x759 (= v_1_tx_elapsed v_0_tx_elapsed)))
 (let (($x756 (not v_1_tx_retransmitted)))
 (let (($x754 (= v_1_tx_max_previous v_0_tx_max_previous)))
 (let (($x751 (= v_1_tx_eligible v_0_tx_eligible)))
 (let (($x748 (= v_1_tx_emit_count v_0_tx_emit_count)))
 (let ((?x744 (ite (and v_0_fin_sent (not v_0_fin_acknowledged)) v_0_tx_fin_time 0)))
 (let (($x745 (= v_1_tx_fin_time ?x744)))
 (let (($x739 (= v_1_tx_time_15 (ite (>= 15 v_0_rtx_buf) 0 v_0_tx_time_15))))
 (let (($x733 (= v_1_tx_time_14 (ite (>= 14 v_0_rtx_buf) 0 v_0_tx_time_14))))
 (let (($x727 (= v_1_tx_time_13 (ite (>= 13 v_0_rtx_buf) 0 v_0_tx_time_13))))
 (let (($x721 (= v_1_tx_time_12 (ite (>= 12 v_0_rtx_buf) 0 v_0_tx_time_12))))
 (let (($x715 (= v_1_tx_time_11 (ite (>= 11 v_0_rtx_buf) 0 v_0_tx_time_11))))
 (let (($x709 (= v_1_tx_time_10 (ite (>= 10 v_0_rtx_buf) 0 v_0_tx_time_10))))
 (let (($x703 (= v_1_tx_time_09 (ite (>= 9 v_0_rtx_buf) 0 v_0_tx_time_09))))
 (let (($x697 (= v_1_tx_time_08 (ite (>= 8 v_0_rtx_buf) 0 v_0_tx_time_08))))
 (let (($x691 (= v_1_tx_time_07 (ite (>= 7 v_0_rtx_buf) 0 v_0_tx_time_07))))
 (let (($x685 (= v_1_tx_time_06 (ite (>= 6 v_0_rtx_buf) 0 v_0_tx_time_06))))
 (let (($x679 (= v_1_tx_time_05 (ite (>= 5 v_0_rtx_buf) 0 v_0_tx_time_05))))
 (let (($x673 (= v_1_tx_time_04 (ite (>= 4 v_0_rtx_buf) 0 v_0_tx_time_04))))
 (let (($x667 (= v_1_tx_time_03 (ite (>= 3 v_0_rtx_buf) 0 v_0_tx_time_03))))
 (let (($x661 (= v_1_tx_time_02 (ite (>= 2 v_0_rtx_buf) 0 v_0_tx_time_02))))
 (let (($x651 (= v_1_tx_time_00 (ite (>= 0 v_0_rtx_buf) 0 v_0_tx_time_00))))
 (let (($x646 (= v_1_rto_base_ms v_0_rto_base_ms)))
 (let (($x643 (= v_1_rtt_samples v_0_rtt_samples)))
 (let (($x640 (= v_1_rtt_last_ms v_0_rtt_last_ms)))
 (let (($x637 (not v_1_rtt_sample_was_ambiguous)))
 (let (($x635 (not v_1_rtt_sample_used)))
 (let (($x633 (not v_1_rtt_start_new)))
 (let (($x627 (= v_1_rtt_end v_0_rtt_end)))
 (let (($x626 (= v_1_rtt_start_ms v_0_rtt_start_ms)))
 (let (($x623 (= v_1_rtt_sample_at_ms v_0_rtt_sample_at_ms)))
 (let (($x602 (= v_1_rtt_previous_measured v_0_rtt_previous_measured)))
 (let (($x599 (= v_1_rtt_measured v_0_rtt_measured)))
 (let (($x596 (= v_1_rtt_previous_var v_0_rtt_previous_var)))
 (let (($x593 (= v_1_rtt_previous_srtt v_0_rtt_previous_srtt)))
 (let (($x590 (= v_1_rtt_error_ms v_0_rtt_error_ms)))
 (let (($x587 (= v_1_rttvar_ms v_0_rttvar_ms)))
 (let (($x584 (= v_1_srtt_ms v_0_srtt_ms)))
 (let (($x581 (= v_1_rx_fin_consumed v_0_rx_fin_consumed)))
 (let (($x578 (= v_1_rx_fin_done v_0_rx_fin_done)))
 (let (($x575 (= v_1_rx_fin_offset v_0_rx_fin_offset)))
 (let (($x572 (= v_1_rx_fin_seq v_0_rx_fin_seq)))
 (let (($x571 (= v_1_rx_fin_pending v_0_rx_fin_pending)))
 (let (($x568 (= v_1_fin_acknowledged v_0_fin_acknowledged)))
 (let (($x565 (= v_1_fin_seq v_0_fin_seq)))
 (let (($x564 (= v_1_fin_sent v_0_fin_sent)))
 (let (($x561 (= v_1_fin_requested v_0_fin_requested)))
 (let (($x558 (= v_1_ack_window_update v_0_ack_window_update)))
 (let (($x555 (= v_1_ack_advance v_0_ack_advance)))
 (let (($x552 (= v_1_ack_is_future v_0_ack_is_future)))
 (let (($x549 (= v_1_ack_is_new v_0_ack_is_new)))
 (let (($x546 (= v_1_ack_delta v_0_ack_delta)))
 (let (($x543 (= v_1_seg_acceptable v_0_seg_acceptable)))
 (let (($x540 (= v_1_rx_acceptable v_0_rx_acceptable)))
 (let (($x537 (= v_1_rx_advance v_0_rx_advance)))
 (let (($x534 (= v_1_rx_slot_15 v_0_rx_slot_15)))
 (let (($x533 (= v_1_rx_slot_14 v_0_rx_slot_14)))
 (let (($x532 (= v_1_rx_slot_13 v_0_rx_slot_13)))
 (let (($x531 (= v_1_rx_slot_12 v_0_rx_slot_12)))
 (let (($x530 (= v_1_rx_slot_11 v_0_rx_slot_11)))
 (let (($x529 (= v_1_rx_slot_10 v_0_rx_slot_10)))
 (let (($x528 (= v_1_rx_slot_09 v_0_rx_slot_09)))
 (let (($x527 (= v_1_rx_slot_08 v_0_rx_slot_08)))
 (let (($x526 (= v_1_rx_slot_07 v_0_rx_slot_07)))
 (let (($x525 (= v_1_rx_slot_06 v_0_rx_slot_06)))
 (let (($x524 (= v_1_rx_slot_05 v_0_rx_slot_05)))
 (let (($x523 (= v_1_rx_slot_04 v_0_rx_slot_04)))
 (let (($x522 (= v_1_rx_slot_03 v_0_rx_slot_03)))
 (let (($x521 (= v_1_rx_slot_02 v_0_rx_slot_02)))
 (let (($x520 (= v_1_rx_slot_01 v_0_rx_slot_01)))
 (let (($x519 (= v_1_rx_slot_00 v_0_rx_slot_00)))
 (let (($x518 (= v_1_rx_chunk v_0_rx_chunk)))
 (let (($x517 (= v_1_take v_0_take)))
 (let (($x514 (= v_1_snd_wl2 v_0_snd_wl2)))
 (let (($x513 (= v_1_snd_wl1 v_0_snd_wl1)))
 (let (($x512 (= v_1_snd_wnd v_0_snd_wnd)))
 (let (($x509 (= v_1_rcv_buf v_0_rcv_buf)))
 (let (($x508 (= v_1_rtx_buf v_0_rtx_buf)))
 (let (($x505 (= v_1_local_window v_0_local_window)))
 (let (($x502 (= v_1_msl_ms v_0_msl_ms)))
 (let (($x499 (= v_1_user_timeout_ms v_0_user_timeout_ms)))
 (let (($x496 (= v_1_active_open v_0_active_open)))
 (let (($x493 (= v_1_retries v_0_retries)))
 (let (($x490 (= v_1_rto_ms v_0_rto_ms)))
 (let (($x487 (= v_1_tx_flags v_0_tx_flags)))
 (let (($x484 (= v_1_tx_ack v_0_tx_ack)))
 (let (($x483 (= v_1_tx_seq v_0_tx_seq)))
 (let (($x482 (= v_1_rcv_nxt v_0_rcv_nxt)))
 (let (($x481 (= v_1_snd_nxt v_0_snd_nxt)))
 (let (($x480 (= v_1_snd_una v_0_snd_una)))
 (let (($x479 (= v_1_irs v_0_irs)))
 (let (($x478 (= v_1_iss v_0_iss)))
 (and (>= now_1 now_0) (<= 1 input_0_app.send_data) (>= 16 (+ v_0_snd_buf v_0_rtx_buf input_0_app.send_data)) (or (not active_0_rtx) (not (<= due_0_rtx now_1))) (or (not active_0_user) (not (<= due_0_user now_1))) (or (not active_0_time_wait) (not (<= due_0_time_wait now_1))) (or (not active_0_delack) (not (<= due_0_delack now_1))) (or (not active_0_persist) (not (<= due_0_persist now_1))) $x478 $x479 $x480 $x481 $x482 $x483 $x484 $x487 $x490 $x493 $x496 $x499 $x502 $x505 (= v_1_snd_buf (+ v_0_snd_buf input_0_app.send_data)) $x508 $x509 $x512 $x513 $x514 $x517 $x518 $x519 $x520 $x521 $x522 $x523 $x524 $x525 $x526 $x527 $x528 $x529 $x530 $x531 $x532 $x533 $x534 $x537 $x540 $x543 $x546 $x549 $x552 $x555 $x558 $x561 $x564 $x565 $x568 $x571 $x572 $x575 $x578 $x581 $x584 $x587 $x590 $x593 $x596 $x599 $x602 (= v_1_rtt_active (and $x613 v_0_rtt_active)) (= v_1_rtt_ambiguous (and $x613 v_0_rtt_ambiguous)) $x623 $x626 $x627 (= v_1_rtt_remaining (ite $x612 0 v_0_rtt_remaining)) $x633 $x635 $x637 $x640 $x643 $x646 $x651 (= v_1_tx_time_01 (ite $x608 0 v_0_tx_time_01)) $x661 $x667 $x673 $x679 $x685 $x691 $x697 $x703 $x709 $x715 $x721 $x727 $x733 $x739 $x745 $x748 $x751 $x754 $x756 $x759 $x762 $x765 $x767 $x769 $x771 $x773 $x776 $x779 $x782 $x785 $x788 $x791 $x793 $x795 (= v_1_persist_active $x612) (= v_1_persist_eligible $x612) (= v_1_persist_start $x802) $x805 $x807 $x809 $x811 (= v_1_persist_interval_ms (ite $x612 ?x814 1000)) $x820 $x825 (= v_1_persist_last_ms (ite $x612 v_0_persist_last_ms 0)) $x835 (= v_1_persist_probes (ite $x612 v_0_persist_probes 0)) $x842 $x845 $x848 $x851 $x854 $x857 (= 0 v_1_cc_acked) $x861 $x862 $x864 $x866 $x868 $x870 $x873 (= 0 v_1_cc_growth) $x877 (= v_1_cc_send_budget (ite (<= 0 ?x883) ?x883 0)) (= 0 v_1_cc_new_sent) (= v_1_cc_rto_00 (and (not (>= 0 v_0_rtx_buf)) v_0_cc_rto_00)) (= v_1_cc_rto_01 (and (not $x608) v_0_cc_rto_01)) (= v_1_cc_rto_02 (and (not (>= 2 v_0_rtx_buf)) v_0_cc_rto_02)) (= v_1_cc_rto_03 (and (not (>= 3 v_0_rtx_buf)) v_0_cc_rto_03)) (= v_1_cc_rto_04 (and (not (>= 4 v_0_rtx_buf)) v_0_cc_rto_04)) (= v_1_cc_rto_05 (and (not (>= 5 v_0_rtx_buf)) v_0_cc_rto_05)) (= v_1_cc_rto_06 (and (not (>= 6 v_0_rtx_buf)) v_0_cc_rto_06)) (= v_1_cc_rto_07 (and (not (>= 7 v_0_rtx_buf)) v_0_cc_rto_07)) (= v_1_cc_rto_08 (and (not (>= 8 v_0_rtx_buf)) v_0_cc_rto_08)) (= v_1_cc_rto_09 (and (not (>= 9 v_0_rtx_buf)) v_0_cc_rto_09)) (= v_1_cc_rto_10 (and (not (>= 10 v_0_rtx_buf)) v_0_cc_rto_10)) (= v_1_cc_rto_11 (and (not (>= 11 v_0_rtx_buf)) v_0_cc_rto_11)) (= v_1_cc_rto_12 (and (not (>= 12 v_0_rtx_buf)) v_0_cc_rto_12)) (= v_1_cc_rto_13 (and (not (>= 13 v_0_rtx_buf)) v_0_cc_rto_13)) (= v_1_cc_rto_14 (and (not (>= 14 v_0_rtx_buf)) v_0_cc_rto_14)) (= v_1_cc_rto_15 (and (not (>= 15 v_0_rtx_buf)) v_0_cc_rto_15)) $x970 $x973 $x976 (= v_1_fr_active (and (not (or $x610 $x612)) v_0_fr_active)) (= v_1_fr_dupacks (ite (or $x610 $x612) 0 v_0_fr_dupacks)) $x988 $x990 $x992 $x993 $x994 $x996 $x998 $x1000 $x1002 $x1004 $x1006 $x1008 $x1010 $x1012 $x1015 $x1018 $x1021 $x1023 $x1025 $x1027 (= v_1_idle_elapsed_ms ?x1031) $x1034 $x1036 $x1038 $x1041 $x1043 $x1045 (= 0 v_1_lt_take) (= v_1_lt_epoch_bytes (ite (or $x610 $x612) 0 v_0_lt_epoch_bytes)) $x1055 $x1057 $x1059 $x1060 $x1062 $x1064 (= v_1_lt_loss_flight (+ v_0_rtx_buf (* ?x881 v_0_lt_epoch_bytes))) $x1070 $x1073 $x1076 $x1077 $x1080 $x1082 $x1085 (= 0 v_1_sched_cause) (= 0 v_1_sched_bytes) (= 0 v_1_sched_packets) (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf)) (= v_1_svc_accept_step ?x1097) (= 0 v_1_svc_ack_step) (= v_1_svc_drop_step ?x1105) (= v_1_svc_written_bytes (+ v_0_svc_written_bytes ?x1097)) $x1113 (= v_1_svc_abandoned_bytes (+ v_0_svc_abandoned_bytes ?x1105)) (= v_1_cb_head ?x1125) (= v_1_cb_tail (ite (<= 16 ?x1129) (+ (- 16) ?x1129) ?x1129)) (= v_1_cb_count (ite $x1119 0 v_0_cb_count)) $x1139 $x1141 $x1143 $x1145 (= v_1_cb_live_total ?x1179) (= v_1_cb_partial_prefix ?x1182) $x1186 $x1189 (= v_1_cb_abandoned_total (+ v_0_cb_abandoned_total ?x1193)) (= v_1_cb_drop_step ?x1193) $x1198 $x1199 $x1201 (= v_1_cb_length_00 ?x1148) (= v_1_cb_end_00 (ite $x1119 0 v_0_cb_end_00)) $x1207 (= v_1_cb_length_01 ?x1150) (= v_1_cb_end_01 (ite $x1119 0 v_0_cb_end_01)) $x1213 (= v_1_cb_length_02 ?x1152) (= v_1_cb_end_02 (ite $x1119 0 v_0_cb_end_02)) $x1219 (= v_1_cb_length_03 ?x1154) (= v_1_cb_end_03 (ite $x1119 0 v_0_cb_end_03)) $x1225 (= v_1_cb_length_04 ?x1156) (= v_1_cb_end_04 (ite $x1119 0 v_0_cb_end_04)) $x1231 (= v_1_cb_length_05 ?x1158) (= v_1_cb_end_05 (ite $x1119 0 v_0_cb_end_05)) $x1237 (= v_1_cb_length_06 ?x1160) (= v_1_cb_end_06 (ite $x1119 0 v_0_cb_end_06)) $x1243 (= v_1_cb_length_07 ?x1162) (= v_1_cb_end_07 (ite $x1119 0 v_0_cb_end_07)) $x1249 (= v_1_cb_length_08 ?x1164) (= v_1_cb_end_08 (ite $x1119 0 v_0_cb_end_08)) $x1255 (= v_1_cb_length_09 ?x1166) (= v_1_cb_end_09 (ite $x1119 0 v_0_cb_end_09)) $x1261 (= v_1_cb_length_10 ?x1168) (= v_1_cb_end_10 (ite $x1119 0 v_0_cb_end_10)) $x1267 (= v_1_cb_length_11 ?x1170) (= v_1_cb_end_11 (ite $x1119 0 v_0_cb_end_11)) $x1273 (= v_1_cb_length_12 ?x1172) (= v_1_cb_end_12 (ite $x1119 0 v_0_cb_end_12)) $x1279 (= v_1_cb_length_13 ?x1174) (= v_1_cb_end_13 (ite $x1119 0 v_0_cb_end_13)) $x1285 (= v_1_cb_length_14 ?x1176) (= v_1_cb_end_14 (ite $x1119 0 v_0_cb_end_14)) $x1291 (= v_1_cb_length_15 ?x1178) (= v_1_cb_end_15 (ite $x1119 0 v_0_cb_end_15)) $x1297 (= active_1_rtx (or (and $x613 active_0_rtx) $x1302)) $x1306 $x1308 $x1310 $x1314 (= due_1_rtx (ite $x1302 ?x1316 due_0_rtx)) $x1320 $x1322 $x1324 (= due_1_persist (ite $x802 ?x831 due_0_persist)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_user))
(assert
 (not active_0_time_wait))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (<= 1000 v_0_rto_ms))
(assert
 (<= 0 v_0_retries))
(assert
 (<= 1 v_0_msl_ms))
(assert
 (<= 1 v_0_user_timeout_ms))
(assert
 true)
(assert
 (let ((?x1093 (+ v_0_snd_buf v_0_rtx_buf)))
 (>= 16 ?x1093)))
(assert
 (>= 16 v_0_rcv_buf))
(assert
 (and (<= 0 v_0_snd_wnd) (>= 65535 v_0_snd_wnd)))
(assert
 (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf))))
(assert
 (>= 1 v_0_rx_slot_00))
(assert
 (let (($x1345 (= 0 v_0_rx_slot_00)))
 (let (($x1344 (not (>= v_0_rcv_buf 16))))
 (or $x1344 $x1345))))
(assert
 (>= 1 v_0_rx_slot_01))
(assert
 (let (($x1350 (= 0 v_0_rx_slot_01)))
 (let (($x1349 (not (>= v_0_rcv_buf 15))))
 (or $x1349 $x1350))))
(assert
 (>= 1 v_0_rx_slot_02))
(assert
 (let (($x1355 (= 0 v_0_rx_slot_02)))
 (let (($x1354 (not (>= v_0_rcv_buf 14))))
 (or $x1354 $x1355))))
(assert
 (>= 1 v_0_rx_slot_03))
(assert
 (let (($x1360 (= 0 v_0_rx_slot_03)))
 (let (($x1359 (not (>= v_0_rcv_buf 13))))
 (or $x1359 $x1360))))
(assert
 (>= 1 v_0_rx_slot_04))
(assert
 (let (($x1365 (= 0 v_0_rx_slot_04)))
 (let (($x1364 (not (>= v_0_rcv_buf 12))))
 (or $x1364 $x1365))))
(assert
 (>= 1 v_0_rx_slot_05))
(assert
 (let (($x1370 (= 0 v_0_rx_slot_05)))
 (let (($x1369 (not (>= v_0_rcv_buf 11))))
 (or $x1369 $x1370))))
(assert
 (>= 1 v_0_rx_slot_06))
(assert
 (let (($x1375 (= 0 v_0_rx_slot_06)))
 (let (($x1374 (not (>= v_0_rcv_buf 10))))
 (or $x1374 $x1375))))
(assert
 (>= 1 v_0_rx_slot_07))
(assert
 (let (($x1380 (= 0 v_0_rx_slot_07)))
 (let (($x1379 (not (>= v_0_rcv_buf 9))))
 (or $x1379 $x1380))))
(assert
 (>= 1 v_0_rx_slot_08))
(assert
 (let (($x1385 (= 0 v_0_rx_slot_08)))
 (let (($x1384 (not (>= v_0_rcv_buf 8))))
 (or $x1384 $x1385))))
(assert
 (>= 1 v_0_rx_slot_09))
(assert
 (let (($x1390 (= 0 v_0_rx_slot_09)))
 (let (($x1389 (not (>= v_0_rcv_buf 7))))
 (or $x1389 $x1390))))
(assert
 (>= 1 v_0_rx_slot_10))
(assert
 (let (($x1395 (= 0 v_0_rx_slot_10)))
 (let (($x1394 (not (>= v_0_rcv_buf 6))))
 (or $x1394 $x1395))))
(assert
 (>= 1 v_0_rx_slot_11))
(assert
 (let (($x1400 (= 0 v_0_rx_slot_11)))
 (let (($x1399 (not (>= v_0_rcv_buf 5))))
 (or $x1399 $x1400))))
(assert
 (>= 1 v_0_rx_slot_12))
(assert
 (let (($x1405 (= 0 v_0_rx_slot_12)))
 (let (($x1404 (not (>= v_0_rcv_buf 4))))
 (or $x1404 $x1405))))
(assert
 (>= 1 v_0_rx_slot_13))
(assert
 (let (($x1410 (= 0 v_0_rx_slot_13)))
 (let (($x1409 (not (>= v_0_rcv_buf 3))))
 (or $x1409 $x1410))))
(assert
 (>= 1 v_0_rx_slot_14))
(assert
 (let (($x1415 (= 0 v_0_rx_slot_14)))
 (let (($x1414 (not (>= v_0_rcv_buf 2))))
 (or $x1414 $x1415))))
(assert
 (>= 1 v_0_rx_slot_15))
(assert
 (let (($x1420 (= 0 v_0_rx_slot_15)))
 (let (($x1419 (not (>= v_0_rcv_buf 1))))
 (or $x1419 $x1420))))
(assert
 (= 0 v_0_rx_slot_00))
(assert
 (let ((?x1422 (+ v_0_rcv_buf v_0_rx_slot_00 v_0_rx_slot_01 v_0_rx_slot_02 v_0_rx_slot_03 v_0_rx_slot_04 v_0_rx_slot_05 v_0_rx_slot_06 v_0_rx_slot_07 v_0_rx_slot_08 v_0_rx_slot_09 v_0_rx_slot_10 v_0_rx_slot_11 v_0_rx_slot_12 v_0_rx_slot_13 v_0_rx_slot_14 v_0_rx_slot_15)))
 (>= 16 ?x1422)))
(assert
 (and (<= 0 v_0_rx_advance) (>= 16 v_0_rx_advance)))
(assert
 (= v_0_rx_chunk v_0_rx_advance))
(assert
 (and (<= 0 v_0_ack_delta) (>= 4294967295 v_0_ack_delta)))
(assert
 true)
(assert
 (let ((?x1434 (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)) 4294967296)))
 (= v_0_snd_nxt ?x1434)))
(assert
 (not v_0_fin_sent))
(assert
 (not v_0_fin_requested))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not v_0_rx_fin_done))
(assert
 (let (($x1439 (<= 1 v_0_rx_fin_offset)))
 (let (($x1437 (not v_0_rx_fin_done)))
 (let (($x1442 (and $x1437 $x1439 (<= v_0_rx_fin_offset (+ (- 1) v_0_local_window)))))
 (let (($x1438 (not v_0_rx_fin_pending)))
 (or $x1438 $x1442))))))
(assert
 (let (($x1445 (>= 15 v_0_rx_fin_offset)))
 (and (<= 0 v_0_rx_fin_offset) $x1445 (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset)))))
(assert
 (let (($x1438 (not v_0_rx_fin_pending)))
 (or $x1438 (= v_0_rx_fin_seq (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)))))
(assert
 (let (($x1437 (not v_0_rx_fin_done)))
 (or $x1437 (= v_0_rcv_nxt (mod (+ 1 v_0_rx_fin_seq) 4294967296)))))
(assert
 (let (($x1345 (= 0 v_0_rx_slot_00)))
 (or (not (and v_0_rx_fin_pending (>= 0 v_0_rx_fin_offset))) $x1345)))
(assert
 (let (($x1350 (= 0 v_0_rx_slot_01)))
 (or (not (and v_0_rx_fin_pending (>= 1 v_0_rx_fin_offset))) $x1350)))
(assert
 (let (($x1355 (= 0 v_0_rx_slot_02)))
 (or (not (and v_0_rx_fin_pending (>= 2 v_0_rx_fin_offset))) $x1355)))
(assert
 (let (($x1360 (= 0 v_0_rx_slot_03)))
 (or (not (and v_0_rx_fin_pending (>= 3 v_0_rx_fin_offset))) $x1360)))
(assert
 (let (($x1365 (= 0 v_0_rx_slot_04)))
 (or (not (and v_0_rx_fin_pending (>= 4 v_0_rx_fin_offset))) $x1365)))
(assert
 (let (($x1370 (= 0 v_0_rx_slot_05)))
 (or (not (and v_0_rx_fin_pending (>= 5 v_0_rx_fin_offset))) $x1370)))
(assert
 (let (($x1375 (= 0 v_0_rx_slot_06)))
 (or (not (and v_0_rx_fin_pending (>= 6 v_0_rx_fin_offset))) $x1375)))
(assert
 (let (($x1380 (= 0 v_0_rx_slot_07)))
 (or (not (and v_0_rx_fin_pending (>= 7 v_0_rx_fin_offset))) $x1380)))
(assert
 (let (($x1385 (= 0 v_0_rx_slot_08)))
 (or (not (and v_0_rx_fin_pending (>= 8 v_0_rx_fin_offset))) $x1385)))
(assert
 (let (($x1390 (= 0 v_0_rx_slot_09)))
 (or (not (and v_0_rx_fin_pending (>= 9 v_0_rx_fin_offset))) $x1390)))
(assert
 (let (($x1395 (= 0 v_0_rx_slot_10)))
 (or (not (and v_0_rx_fin_pending (>= 10 v_0_rx_fin_offset))) $x1395)))
(assert
 (let (($x1400 (= 0 v_0_rx_slot_11)))
 (or (not (and v_0_rx_fin_pending (>= 11 v_0_rx_fin_offset))) $x1400)))
(assert
 (let (($x1405 (= 0 v_0_rx_slot_12)))
 (or (not (and v_0_rx_fin_pending (>= 12 v_0_rx_fin_offset))) $x1405)))
(assert
 (let (($x1410 (= 0 v_0_rx_slot_13)))
 (or (not (and v_0_rx_fin_pending (>= 13 v_0_rx_fin_offset))) $x1410)))
(assert
 (let (($x1415 (= 0 v_0_rx_slot_14)))
 (or (not (and v_0_rx_fin_pending (>= 14 v_0_rx_fin_offset))) $x1415)))
(assert
 (let (($x1420 (= 0 v_0_rx_slot_15)))
 (or (not (and v_0_rx_fin_pending (>= 15 v_0_rx_fin_offset))) $x1420)))
(assert
 (<= 0.0 v_0_srtt_ms))
(assert
 (<= 0.0 v_0_rttvar_ms))
(assert
 (<= 0.0 v_0_rtt_error_ms))
(assert
 (<= 0.0 v_0_rtt_previous_srtt))
(assert
 (<= 0.0 v_0_rtt_previous_var))
(assert
 (<= 0 v_0_rtt_start_ms))
(assert
 (<= 0 v_0_rtt_last_ms))
(assert
 (<= 0 v_0_rtt_samples))
(assert
 (and (<= 1000 v_0_rto_base_ms) (>= 60000 v_0_rto_base_ms) (>= v_0_rto_ms v_0_rto_base_ms) (>= 60000 v_0_rto_ms)))
(assert
 (let ((?x1540 (* 4.0 v_0_rttvar_ms)))
 (let ((?x1535 (- 1.0)))
 (let ((?x1543 (+ (* ?x1535 v_0_srtt_ms) (* ?x1535 (ite (<= v_0_rttvar_ms (/ 1.0 4.0)) 1.0 ?x1540)))))
 (let ((?x1544 (to_int ?x1543)))
 (let ((?x881 (- 1)))
 (let ((?x1548 (ite (<= ?x1544 (- 1000)) (* ?x881 ?x1544) 1000)))
 (= v_0_rto_base_ms (ite v_0_rtt_measured (ite (<= 60000 ?x1548) 60000 ?x1548) 1000)))))))))
(assert
 (= v_0_rtt_measured (<= 1 v_0_rtt_samples)))
(assert
 (let ((?x1561 (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296)))
 (let (($x1566 (and (<= v_0_rtt_start_ms now_0) (<= 1 v_0_rtt_remaining) (>= 4 v_0_rtt_remaining) (>= ?x1561 v_0_rtt_remaining) (<= ?x1561 (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296)))))
 (let (($x1555 (not v_0_rtt_active)))
 (or $x1555 $x1566)))))
(assert
 (let (($x1568 (= 0 v_0_rtt_remaining)))
 (or v_0_rtt_active $x1568)))
(assert
 true)
(assert
 (let (($x1576 (= v_0_rtt_last_ms (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms)))))
 (let (($x1573 (not v_0_rtt_sample_was_ambiguous)))
 (let (($x1571 (not v_0_rtt_sample_used)))
 (or $x1571 (and $x1573 v_0_rtt_measured $x1576))))))
(assert
 (and (<= 0 v_0_rtt_sample_at_ms) (<= v_0_rtt_sample_at_ms now_0)))
(assert
 (let ((?x1585 (to_real v_0_rtt_last_ms)))
 (let ((?x1605 (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt) (* (/ 1.0 8.0) ?x1585))))
 (let ((?x1587 (+ v_0_rtt_previous_srtt (* (- 1.0) ?x1585))))
 (let ((?x1591 (ite (>= ?x1587 0.0) ?x1587 (+ (* (- 1.0) v_0_rtt_previous_srtt) ?x1585))))
 (let ((?x1538 (/ 1.0 4.0)))
 (let ((?x1597 (ite v_0_rtt_previous_measured (+ (* (/ 3.0 4.0) v_0_rtt_previous_var) (* ?x1538 ?x1591)) (* (/ 1.0 2.0) ?x1585))))
 (let (($x1608 (and (= v_0_rttvar_ms ?x1597) (= v_0_srtt_ms (ite v_0_rtt_previous_measured ?x1605 ?x1585)))))
 (let (($x1571 (not v_0_rtt_sample_used)))
 (or $x1571 $x1608))))))))))
(assert
 (and (<= 0 v_0_tx_time_00) (<= v_0_tx_time_00 now_0) (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00))))
(assert
 (and (<= 0 v_0_tx_time_01) (<= v_0_tx_time_01 now_0) (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))))
(assert
 (and (<= 0 v_0_tx_time_02) (<= v_0_tx_time_02 now_0) (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))))
(assert
 (and (<= 0 v_0_tx_time_03) (<= v_0_tx_time_03 now_0) (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))))
(assert
 (and (<= 0 v_0_tx_time_04) (<= v_0_tx_time_04 now_0) (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))))
(assert
 (and (<= 0 v_0_tx_time_05) (<= v_0_tx_time_05 now_0) (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))))
(assert
 (and (<= 0 v_0_tx_time_06) (<= v_0_tx_time_06 now_0) (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))))
(assert
 (and (<= 0 v_0_tx_time_07) (<= v_0_tx_time_07 now_0) (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))))
(assert
 (and (<= 0 v_0_tx_time_08) (<= v_0_tx_time_08 now_0) (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))))
(assert
 (and (<= 0 v_0_tx_time_09) (<= v_0_tx_time_09 now_0) (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))))
(assert
 (and (<= 0 v_0_tx_time_10) (<= v_0_tx_time_10 now_0) (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))))
(assert
 (and (<= 0 v_0_tx_time_11) (<= v_0_tx_time_11 now_0) (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))))
(assert
 (and (<= 0 v_0_tx_time_12) (<= v_0_tx_time_12 now_0) (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))))
(assert
 (and (<= 0 v_0_tx_time_13) (<= v_0_tx_time_13 now_0) (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))))
(assert
 (and (<= 0 v_0_tx_time_14) (<= v_0_tx_time_14 now_0) (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))))
(assert
 (and (<= 0 v_0_tx_time_15) (<= v_0_tx_time_15 now_0) (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))))
(assert
 (and (<= 0 v_0_tx_fin_time) (<= v_0_tx_fin_time now_0)))
(assert
 (and (<= 0 v_0_tx_emit_count) (>= 4 v_0_tx_emit_count)))
(assert
 (and (<= 0 v_0_tx_eligible) (>= 4 v_0_tx_eligible)))
(assert
 (and (<= 0 v_0_tx_elapsed) (<= 0 v_0_tx_max_previous) (<= v_0_tx_max_previous now_0) (<= 1000 v_0_tx_previous_rto) (>= 60000 v_0_tx_previous_rto)))
(assert
 (let (($x1712 (and (>= v_0_tx_elapsed v_0_tx_previous_rto) (<= 1 v_0_tx_emit_count) (or (not v_0_tx_is_fin) (= 1 v_0_tx_emit_count)))))
 (let (($x1706 (not v_0_tx_retransmitted)))
 (or $x1706 $x1712))))
(assert
 (let (($x1706 (not v_0_tx_retransmitted)))
 (or $x1706 (not v_0_tx_waiting))))
(assert
 (and (<= 0 v_0_tx_syn_time) (<= v_0_tx_syn_time now_0)))
(assert
 (not v_0_tx_syn_pending))
(assert
 (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time)))
(assert
 true)
(assert
 (and (<= 1 v_0_ack_delay_ms) (>= 499 v_0_ack_delay_ms) (= 4 v_0_ack_rmss)))
(assert
 (= v_0_ack_pending active_0_delack))
(assert
 (and (<= 0 v_0_ack_bytes) (>= 7 v_0_ack_bytes) (<= 0 v_0_ack_full_segments) (>= 1 v_0_ack_full_segments)))
(assert
 (and (<= 0 v_0_ack_since_ms) (<= v_0_ack_since_ms now_0)))
(assert
 (let (($x1739 (not v_0_ack_pending)))
 (or $x1739 (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))))
(assert
 (let (($x1746 (and (= 0 v_0_ack_bytes) (= 0 v_0_ack_full_segments) (= 0 v_0_ack_since_ms))))
 (or v_0_ack_pending $x1746)))
(assert
 (let (($x370 (not active_0_rtx)))
 (let (($x608 (>= 1 v_0_rtx_buf)))
 (let (($x605 (not v_0_fin_sent)))
 (let (($x604 (= 0 v_0_snd_wnd)))
 (let (($x801 (not v_0_persist_active)))
 (let (($x1756 (or $x801 (and $x604 $x605 (<= 1 (+ v_0_rtx_buf v_0_snd_buf)) $x608 $x370))))
 (let (($x1751 (and (<= 1 (+ v_0_rtx_buf (ite v_0_fin_sent 1 0))) $x801)))
 (let (($x1748 (= v_0_persist_active active_0_persist)))
 (and $x1748 (= active_0_rtx $x1751) $x1756))))))))))
(assert
 (let (($x801 (not v_0_persist_active)))
 (or $x801 (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))))
(assert
 (and (<= 1000 v_0_persist_interval_ms) (>= 60000 v_0_persist_interval_ms) (<= 1000 v_0_persist_previous_interval_ms) (>= 60000 v_0_persist_previous_interval_ms) (<= 0 v_0_persist_probes) (<= 0 v_0_persist_elapsed_ms)))
(assert
 (and (<= 0 v_0_persist_since_ms) (<= v_0_persist_since_ms now_0) (<= 0 v_0_persist_last_ms) (<= v_0_persist_last_ms now_0) (<= 0 v_0_persist_deadline_ms)))
(assert
 (let (($x1773 (= 0 v_0_persist_probes)))
 (let ((?x1775 (+ (ite $x1773 v_0_persist_since_ms v_0_persist_last_ms) v_0_persist_interval_ms)))
 (let (($x801 (not v_0_persist_active)))
 (or $x801 (= v_0_persist_deadline_ms ?x1775))))))
(assert
 (let (($x1781 (= 1 v_0_rtx_buf)))
 (let (($x1779 (not v_0_persist_probe_sent)))
 (or $x1779 (and (>= v_0_persist_elapsed_ms v_0_persist_previous_interval_ms) $x1781)))))
(assert
 (let (($x1787 (= v_0_tx_time_00 v_0_persist_last_ms)))
 (let (($x1781 (= 1 v_0_rtx_buf)))
 (or (not (and v_0_persist_active (<= 1 v_0_persist_probes) $x1781)) $x1787))))
(assert
 (let (($x1773 (= 0 v_0_persist_probes)))
 (let (($x1792 (and (= 0 v_0_persist_since_ms) (= 0 v_0_persist_last_ms) (= 0 v_0_persist_deadline_ms) $x1773)))
 (or v_0_persist_active $x1792))))
(assert
 (and (<= 4 v_0_cc_initial_window) (>= 16 v_0_cc_initial_window) (<= 8 v_0_cc_initial_threshold)))
(assert
 (and (<= 4 v_0_cc_cwnd) (<= 8 v_0_cc_ssthresh) (<= 0 v_0_cc_ca_credit) (not (>= v_0_cc_ca_credit v_0_cc_cwnd)) (<= 0 v_0_cc_growth) (>= 4 v_0_cc_growth) (<= 0 v_0_cc_acked) (>= 16 v_0_cc_acked) (<= 0 v_0_cc_threshold_updates)))
(assert
 (and (<= 0 v_0_cc_new_sent) (<= v_0_cc_new_sent v_0_cc_send_budget)))
(assert
 (let (($x648 (>= 0 v_0_rtx_buf)))
 (let (($x890 (not $x648)))
 (let (($x1816 (not v_0_cc_rto_00)))
 (or $x1816 $x890)))))
(assert
 (let (($x608 (>= 1 v_0_rtx_buf)))
 (let (($x895 (not $x608)))
 (let (($x1818 (not v_0_cc_rto_01)))
 (or $x1818 $x895)))))
(assert
 (let (($x658 (>= 2 v_0_rtx_buf)))
 (let (($x900 (not $x658)))
 (let (($x1820 (not v_0_cc_rto_02)))
 (or $x1820 $x900)))))
(assert
 (let (($x664 (>= 3 v_0_rtx_buf)))
 (let (($x905 (not $x664)))
 (let (($x1822 (not v_0_cc_rto_03)))
 (or $x1822 $x905)))))
(assert
 (let (($x670 (>= 4 v_0_rtx_buf)))
 (let (($x910 (not $x670)))
 (let (($x1824 (not v_0_cc_rto_04)))
 (or $x1824 $x910)))))
(assert
 (let (($x676 (>= 5 v_0_rtx_buf)))
 (let (($x915 (not $x676)))
 (let (($x1826 (not v_0_cc_rto_05)))
 (or $x1826 $x915)))))
(assert
 (let (($x682 (>= 6 v_0_rtx_buf)))
 (let (($x920 (not $x682)))
 (let (($x1828 (not v_0_cc_rto_06)))
 (or $x1828 $x920)))))
(assert
 (let (($x688 (>= 7 v_0_rtx_buf)))
 (let (($x925 (not $x688)))
 (let (($x1830 (not v_0_cc_rto_07)))
 (or $x1830 $x925)))))
(assert
 (let (($x694 (>= 8 v_0_rtx_buf)))
 (let (($x930 (not $x694)))
 (let (($x1832 (not v_0_cc_rto_08)))
 (or $x1832 $x930)))))
(assert
 (let (($x700 (>= 9 v_0_rtx_buf)))
 (let (($x935 (not $x700)))
 (let (($x1834 (not v_0_cc_rto_09)))
 (or $x1834 $x935)))))
(assert
 (let (($x706 (>= 10 v_0_rtx_buf)))
 (let (($x940 (not $x706)))
 (let (($x1836 (not v_0_cc_rto_10)))
 (or $x1836 $x940)))))
(assert
 (let (($x712 (>= 11 v_0_rtx_buf)))
 (let (($x945 (not $x712)))
 (let (($x1838 (not v_0_cc_rto_11)))
 (or $x1838 $x945)))))
(assert
 (let (($x718 (>= 12 v_0_rtx_buf)))
 (let (($x950 (not $x718)))
 (let (($x1840 (not v_0_cc_rto_12)))
 (or $x1840 $x950)))))
(assert
 (let (($x724 (>= 13 v_0_rtx_buf)))
 (let (($x955 (not $x724)))
 (let (($x1842 (not v_0_cc_rto_13)))
 (or $x1842 $x955)))))
(assert
 (let (($x730 (>= 14 v_0_rtx_buf)))
 (let (($x960 (not $x730)))
 (let (($x1844 (not v_0_cc_rto_14)))
 (or $x1844 $x960)))))
(assert
 (let (($x736 (>= 15 v_0_rtx_buf)))
 (let (($x965 (not $x736)))
 (let (($x1846 (not v_0_cc_rto_15)))
 (or $x1846 $x965)))))
(assert
 (and (<= 0 v_0_fr_dupacks) (<= 0 v_0_fr_entries) (<= 0 v_0_fr_emit_count) (>= 4 v_0_fr_emit_count) (<= 0 v_0_fr_last_window) (>= 65535 v_0_fr_last_window)))
(assert
 (let (($x801 (not v_0_persist_active)))
 (let (($x1300 (<= 1 v_0_rtx_buf)))
 (let (($x1856 (not v_0_fr_active)))
 (or $x1856 (and (<= 3 v_0_fr_dupacks) $x1300 $x801))))))
(assert
 (let (($x1706 (not v_0_tx_retransmitted)))
 (let (($x1869 (= v_0_retries v_0_fr_before_retries)))
 (let (($x1867 (= v_0_rto_ms v_0_fr_before_rto)))
 (let (($x1865 (= v_0_snd_nxt v_0_fr_before_nxt)))
 (let (($x1870 (and v_0_fr_entered (= 3 v_0_fr_dupacks) (<= 1 v_0_fr_emit_count) $x1865 $x1867 $x1869 $x1706)))
 (let (($x1861 (not v_0_fr_retransmitted)))
 (or $x1861 $x1870))))))))
(assert
 (let (($x1878 (and (= v_0_fr_last_window v_0_fr_before_wire_window) (= v_0_fr_window_valid v_0_fr_before_window_valid))))
 (or (not v_0_fr_window_ignored) $x1878)))
(assert
 (let (($x1880 (not v_0_fr_entered)))
 (or v_0_fr_retransmitted $x1880)))
(assert
 (let (($x1880 (not v_0_fr_entered)))
 (or $x1880 (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))))
(assert
 (let (($x1886 (not v_0_fr_exited)))
 (or $x1886 (and (= v_0_cc_cwnd v_0_cc_ssthresh) (= 0 v_0_cc_ca_credit)))))
(assert
 (and (<= 0 v_0_idle_last_data_ms) (<= v_0_idle_last_data_ms v_0_idle_event_ms) (<= v_0_idle_event_ms now_0) (<= 0 v_0_idle_elapsed_ms) (<= 0 v_0_idle_restart_count)))
(assert
 (or (not v_0_idle_data_emitted) (= v_0_idle_last_data_ms v_0_idle_event_ms)))
(assert
 (let (($x1888 (= 0 v_0_cc_ca_credit)))
 (let (($x1913 (= v_0_cc_ssthresh v_0_idle_before_threshold)))
 (let ((?x1910 (ite (<= v_0_cc_initial_window v_0_idle_before_cwnd) v_0_cc_initial_window v_0_idle_before_cwnd)))
 (let (($x1914 (and (not (>= v_0_idle_before_rto v_0_idle_elapsed_ms)) (= v_0_cc_cwnd ?x1910) $x1913 $x1888)))
 (let (($x1904 (not v_0_idle_restart)))
 (or $x1904 $x1914)))))))
(assert
 (and (<= 0 v_0_lt_epoch_bytes) (>= 8 v_0_lt_epoch_bytes) (<= v_0_lt_epoch_bytes v_0_rtx_buf) (<= 0 v_0_lt_epoch_packets) (>= 2 v_0_lt_epoch_packets) (<= v_0_lt_epoch_packets v_0_fr_dupacks) (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets) (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets)) (<= 0 v_0_lt_loss_flight)))
(assert
 (let (($x1937 (= v_0_cc_cwnd v_0_lt_before_cwnd)))
 (let (($x605 (not v_0_fin_sent)))
 (let (($x1856 (not v_0_fr_active)))
 (let (($x1947 (and v_0_fr_duplicate (<= 1 v_0_fr_dupacks) (>= 2 v_0_fr_dupacks) $x1856 $x605 (<= 1 v_0_lt_take) (>= 4 v_0_lt_take) $x1937 (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take)) (<= v_0_rtx_buf v_0_snd_wnd) (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd)) (= v_0_snd_nxt (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)))))
 (let (($x1929 (not v_0_lt_emitted)))
 (or $x1929 $x1947)))))))
(assert
 (let (($x1953 (= v_0_lt_loss_flight (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes)))))
 (let (($x1880 (not v_0_fr_entered)))
 (or $x1880 $x1953))))
(assert
 (and (<= 0 v_0_choice_count) (>= 4 v_0_choice_count) (<= 0 v_0_choice_limit) (>= 4 v_0_choice_limit)))
(assert
 (let ((?x1968 (mod (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)))
 (let (($x1965 (= v_0_cc_new_sent v_0_choice_count)))
 (let (($x1964 (= v_0_take v_0_choice_count)))
 (let (($x1972 (and (<= 1 v_0_choice_count) (<= v_0_choice_count v_0_choice_limit) $x1964 $x1965 (<= v_0_choice_count v_0_cc_send_budget) (= v_0_snd_nxt ?x1968) (= v_0_rtx_buf (+ v_0_choice_before_flight v_0_choice_count)))))
 (let (($x1961 (not v_0_choice_used)))
 (or $x1961 $x1972)))))))
(assert
 (and (<= 0 v_0_sched_packets) (<= v_0_sched_packets v_0_sched_bytes) (<= v_0_sched_bytes (* 4 v_0_sched_packets)) (>= 16 (+ v_0_sched_bytes v_0_snd_buf))))
(assert
 (let (($x1986 (not v_0_sched_open)))
 (and (<= 0 v_0_sched_at_ms) (<= v_0_sched_at_ms now_0) (or $x1986 (= 1 v_0_sched_cause) (= 2 v_0_sched_cause)))))
(assert
 (let (($x1961 (not v_0_choice_used)))
 (or $x1961 (and v_0_sched_open (= v_0_sched_at_ms v_0_idle_event_ms)))))
(assert
 (let ((?x1998 (+ v_0_svc_acked_bytes v_0_svc_abandoned_bytes v_0_snd_buf v_0_rtx_buf)))
 (and (<= 0 v_0_svc_written_bytes) (<= 0 v_0_svc_acked_bytes) (<= 0 v_0_svc_abandoned_bytes) (= v_0_svc_written_bytes ?x1998))))
(assert
 (let (($x2002 (= v_0_svc_ack_step v_0_cc_acked)))
 (and $x2002 (<= 0 v_0_svc_accept_step) (<= 0 v_0_svc_ack_step) (<= 0 v_0_svc_drop_step))))
(assert
 (let ((?x2016 (+ v_0_cb_head v_0_cb_count)))
 (let (($x2020 (= v_0_cb_tail (ite (<= 16 ?x2016) (+ (- 16) v_0_cb_head v_0_cb_count) ?x2016))))
 (and (<= 0 v_0_cb_head) (not (<= 16 v_0_cb_head)) (<= 0 v_0_cb_tail) (not (<= 16 v_0_cb_tail)) (<= 0 v_0_cb_count) (<= v_0_cb_count v_0_rtx_buf) $x2020 (<= 0 v_0_cb_new_count) (>= 1 v_0_cb_new_count)))))
(assert
 (let ((?x1192 (+ v_0_cb_length_00 v_0_cb_length_01 v_0_cb_length_02 v_0_cb_length_03 v_0_cb_length_04 v_0_cb_length_05 v_0_cb_length_06 v_0_cb_length_07 v_0_cb_length_08 v_0_cb_length_09 v_0_cb_length_10 v_0_cb_length_11 v_0_cb_length_12 v_0_cb_length_13 v_0_cb_length_14 v_0_cb_length_15)))
 (let (($x2040 (= v_0_cb_emitted_total (+ v_0_cb_acked_total v_0_cb_abandoned_total v_0_cb_live_total))))
 (and (<= 0 v_0_cb_emitted_total) (<= 0 v_0_cb_acked_total) (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix) v_0_svc_acked_bytes) (<= v_0_cb_emitted_total v_0_svc_written_bytes) (<= 0 v_0_cb_abandoned_total) (<= 0 v_0_cb_step_bytes) (>= 19 v_0_cb_step_bytes) (<= 0 v_0_cb_drop_step) $x2040 (= v_0_cb_live_total ?x1192)))))
(assert
 (let (($x2044 (= v_0_cb_partial_prefix (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf)))))
 (and $x2044 (<= 0 v_0_cb_partial_prefix) (>= 3 v_0_cb_partial_prefix))))
(assert
 (<= (+ v_0_cb_emitted_total v_0_snd_buf) v_0_svc_written_bytes))
(assert
 (let ((?x881 (- 1)))
 (let ((?x2054 (* ?x881 v_0_cb_head)))
 (let ((?x2056 (ite (>= 0 v_0_cb_head) ?x2054 (+ 16 ?x2054))))
 (let (($x2057 (>= ?x2056 v_0_cb_count)))
 (let (($x2059 (not $x2057)))
 (let (($x2081 (or (not (and $x2059 (<= 1 ?x2056))) (= v_0_cb_end_00 (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)))))
 (let ((?x2071 (mod (+ v_0_snd_una v_0_cb_length_00 (* ?x881 v_0_cb_partial_prefix)) 4294967296)))
 (let (($x2073 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_00)) (= v_0_cb_end_00 ?x2071))))
 (let (($x2058 (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00)) $x2057)))
 (and $x2058 (or $x2059 (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00))) (or (not (and $x2059 (= 0 v_0_cb_head))) $x2073) $x2081)))))))))))
(assert
 (let ((?x2090 (ite (>= 1 v_0_cb_head) (+ 1 (* (- 1) v_0_cb_head)) (+ 17 (* (- 1) v_0_cb_head)))))
 (let (($x2091 (>= ?x2090 v_0_cb_count)))
 (let (($x2093 (not $x2091)))
 (let (($x2114 (or (not (and $x2093 (<= 1 ?x2090))) (= v_0_cb_end_01 (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2105 (= v_0_cb_end_01 (mod (+ v_0_snd_una v_0_cb_length_01 ?x2069) 4294967296))))
 (let (($x2107 (or (not (and $x2093 (= 1 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_01)) $x2105))))
 (let (($x2092 (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01)) $x2091)))
 (and $x2092 (or $x2093 (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01))) $x2107 $x2114)))))))))))
(assert
 (let ((?x2120 (ite (>= 2 v_0_cb_head) (+ 2 (* (- 1) v_0_cb_head)) (+ 18 (* (- 1) v_0_cb_head)))))
 (let (($x2121 (>= ?x2120 v_0_cb_count)))
 (let (($x2126 (not $x2121)))
 (let (($x2147 (or (not (and $x2126 (<= 1 ?x2120))) (= v_0_cb_end_02 (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2138 (= v_0_cb_end_02 (mod (+ v_0_snd_una v_0_cb_length_02 ?x2069) 4294967296))))
 (let (($x2140 (or (not (and $x2126 (= 2 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_02)) $x2138))))
 (let (($x2125 (or $x2121 (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)))))
 (and $x2125 (or $x2126 (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02))) $x2140 $x2147)))))))))))
(assert
 (let ((?x2155 (ite (>= 3 v_0_cb_head) (+ 3 (* (- 1) v_0_cb_head)) (+ 19 (* (- 1) v_0_cb_head)))))
 (let (($x2156 (>= ?x2155 v_0_cb_count)))
 (let (($x2158 (not $x2156)))
 (let (($x2179 (or (not (and $x2158 (<= 1 ?x2155))) (= v_0_cb_end_03 (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2170 (= v_0_cb_end_03 (mod (+ v_0_snd_una v_0_cb_length_03 ?x2069) 4294967296))))
 (let (($x2172 (or (not (and $x2158 (= 3 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_03)) $x2170))))
 (let (($x2157 (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03)) $x2156)))
 (and $x2157 (or $x2158 (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03))) $x2172 $x2179)))))))))))
(assert
 (let ((?x2185 (ite (>= 4 v_0_cb_head) (+ 4 (* (- 1) v_0_cb_head)) (+ 20 (* (- 1) v_0_cb_head)))))
 (let (($x2186 (>= ?x2185 v_0_cb_count)))
 (let (($x2191 (not $x2186)))
 (let (($x2212 (or (not (and $x2191 (<= 1 ?x2185))) (= v_0_cb_end_04 (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2203 (= v_0_cb_end_04 (mod (+ v_0_snd_una v_0_cb_length_04 ?x2069) 4294967296))))
 (let (($x2205 (or (not (and $x2191 (= 4 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_04)) $x2203))))
 (let (($x2190 (or $x2186 (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04)))))
 (and $x2190 (or $x2191 (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04))) $x2205 $x2212)))))))))))
(assert
 (let ((?x2218 (ite (>= 5 v_0_cb_head) (+ 5 (* (- 1) v_0_cb_head)) (+ 21 (* (- 1) v_0_cb_head)))))
 (let (($x2219 (>= ?x2218 v_0_cb_count)))
 (let (($x2224 (not $x2219)))
 (let (($x2245 (or (not (and $x2224 (<= 1 ?x2218))) (= v_0_cb_end_05 (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2236 (= v_0_cb_end_05 (mod (+ v_0_snd_una v_0_cb_length_05 ?x2069) 4294967296))))
 (let (($x2238 (or (not (and $x2224 (= 5 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_05)) $x2236))))
 (let (($x2223 (or $x2219 (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))))
 (and $x2223 (or $x2224 (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05))) $x2238 $x2245)))))))))))
(assert
 (let ((?x2254 (ite (>= 6 v_0_cb_head) (+ 6 (* (- 1) v_0_cb_head)) (+ 22 (* (- 1) v_0_cb_head)))))
 (let (($x2255 (>= ?x2254 v_0_cb_count)))
 (let (($x2257 (not $x2255)))
 (let (($x2278 (or (not (and $x2257 (<= 1 ?x2254))) (= v_0_cb_end_06 (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2269 (= v_0_cb_end_06 (mod (+ v_0_snd_una v_0_cb_length_06 ?x2069) 4294967296))))
 (let (($x2271 (or (not (and $x2257 (= 6 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_06)) $x2269))))
 (let (($x2256 (or (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06)) $x2255)))
 (and $x2256 (or $x2257 (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06))) $x2271 $x2278)))))))))))
(assert
 (let ((?x2284 (ite (>= 7 v_0_cb_head) (+ 7 (* (- 1) v_0_cb_head)) (+ 23 (* (- 1) v_0_cb_head)))))
 (let (($x2285 (>= ?x2284 v_0_cb_count)))
 (let (($x2290 (not $x2285)))
 (let (($x2311 (or (not (and $x2290 (<= 1 ?x2284))) (= v_0_cb_end_07 (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2302 (= v_0_cb_end_07 (mod (+ v_0_snd_una v_0_cb_length_07 ?x2069) 4294967296))))
 (let (($x2304 (or (not (and $x2290 (= 7 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_07)) $x2302))))
 (let (($x2289 (or $x2285 (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))))
 (and $x2289 (or $x2290 (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07))) $x2304 $x2311)))))))))))
(assert
 (let ((?x2320 (ite (>= 8 v_0_cb_head) (+ 8 (* (- 1) v_0_cb_head)) (+ 24 (* (- 1) v_0_cb_head)))))
 (let (($x2321 (>= ?x2320 v_0_cb_count)))
 (let (($x2323 (not $x2321)))
 (let (($x2344 (or (not (and $x2323 (<= 1 ?x2320))) (= v_0_cb_end_08 (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2335 (= v_0_cb_end_08 (mod (+ v_0_snd_una v_0_cb_length_08 ?x2069) 4294967296))))
 (let (($x2337 (or (not (and $x2323 (= 8 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_08)) $x2335))))
 (let (($x2322 (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08)) $x2321)))
 (and $x2322 (or $x2323 (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08))) $x2337 $x2344)))))))))))
(assert
 (let ((?x2350 (ite (>= 9 v_0_cb_head) (+ 9 (* (- 1) v_0_cb_head)) (+ 25 (* (- 1) v_0_cb_head)))))
 (let (($x2351 (>= ?x2350 v_0_cb_count)))
 (let (($x2356 (not $x2351)))
 (let (($x2377 (or (not (and $x2356 (<= 1 ?x2350))) (= v_0_cb_end_09 (mod (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2368 (= v_0_cb_end_09 (mod (+ v_0_snd_una v_0_cb_length_09 ?x2069) 4294967296))))
 (let (($x2370 (or (not (and $x2356 (= 9 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09)) $x2368))))
 (let (($x2355 (or $x2351 (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09)))))
 (and $x2355 (or $x2356 (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09))) $x2370 $x2377)))))))))))
(assert
 (let ((?x2383 (ite (>= 10 v_0_cb_head) (+ 10 (* (- 1) v_0_cb_head)) (+ 26 (* (- 1) v_0_cb_head)))))
 (let (($x2384 (>= ?x2383 v_0_cb_count)))
 (let (($x2389 (not $x2384)))
 (let (($x2410 (or (not (and $x2389 (<= 1 ?x2383))) (= v_0_cb_end_10 (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2401 (= v_0_cb_end_10 (mod (+ v_0_snd_una v_0_cb_length_10 ?x2069) 4294967296))))
 (let (($x2403 (or (not (and $x2389 (= 10 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_10)) $x2401))))
 (let (($x2388 (or $x2384 (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10)))))
 (and $x2388 (or $x2389 (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10))) $x2403 $x2410)))))))))))
(assert
 (let ((?x2419 (ite (>= 11 v_0_cb_head) (+ 11 (* (- 1) v_0_cb_head)) (+ 27 (* (- 1) v_0_cb_head)))))
 (let (($x2420 (>= ?x2419 v_0_cb_count)))
 (let (($x2422 (not $x2420)))
 (let (($x2443 (or (not (and $x2422 (<= 1 ?x2419))) (= v_0_cb_end_11 (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2434 (= v_0_cb_end_11 (mod (+ v_0_snd_una v_0_cb_length_11 ?x2069) 4294967296))))
 (let (($x2436 (or (not (and $x2422 (= 11 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_11)) $x2434))))
 (let (($x2421 (or (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)) $x2420)))
 (and $x2421 (or $x2422 (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11))) $x2436 $x2443)))))))))))
(assert
 (let ((?x2449 (ite (>= 12 v_0_cb_head) (+ 12 (* (- 1) v_0_cb_head)) (+ 28 (* (- 1) v_0_cb_head)))))
 (let (($x2450 (>= ?x2449 v_0_cb_count)))
 (let (($x2455 (not $x2450)))
 (let (($x2476 (or (not (and $x2455 (<= 1 ?x2449))) (= v_0_cb_end_12 (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2467 (= v_0_cb_end_12 (mod (+ v_0_snd_una v_0_cb_length_12 ?x2069) 4294967296))))
 (let (($x2469 (or (not (and $x2455 (= 12 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_12)) $x2467))))
 (let (($x2454 (or $x2450 (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12)))))
 (and $x2454 (or $x2455 (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12))) $x2469 $x2476)))))))))))
(assert
 (let ((?x2485 (ite (>= 13 v_0_cb_head) (+ 13 (* (- 1) v_0_cb_head)) (+ 29 (* (- 1) v_0_cb_head)))))
 (let (($x2486 (>= ?x2485 v_0_cb_count)))
 (let (($x2488 (not $x2486)))
 (let (($x2509 (or (not (and $x2488 (<= 1 ?x2485))) (= v_0_cb_end_13 (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2500 (= v_0_cb_end_13 (mod (+ v_0_snd_una v_0_cb_length_13 ?x2069) 4294967296))))
 (let (($x2502 (or (not (and $x2488 (= 13 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_13)) $x2500))))
 (let (($x2487 (or (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)) $x2486)))
 (and $x2487 (or $x2488 (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13))) $x2502 $x2509)))))))))))
(assert
 (let ((?x2515 (ite (>= 14 v_0_cb_head) (+ 14 (* (- 1) v_0_cb_head)) (+ 30 (* (- 1) v_0_cb_head)))))
 (let (($x2516 (>= ?x2515 v_0_cb_count)))
 (let (($x2521 (not $x2516)))
 (let (($x2542 (or (not (and $x2521 (<= 1 ?x2515))) (= v_0_cb_end_14 (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2533 (= v_0_cb_end_14 (mod (+ v_0_snd_una v_0_cb_length_14 ?x2069) 4294967296))))
 (let (($x2535 (or (not (and $x2521 (= 14 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_14)) $x2533))))
 (let (($x2520 (or $x2516 (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14)))))
 (and $x2520 (or $x2521 (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14))) $x2535 $x2542)))))))))))
(assert
 (let ((?x2551 (ite (>= 15 v_0_cb_head) (+ 15 (* (- 1) v_0_cb_head)) (+ 31 (* (- 1) v_0_cb_head)))))
 (let (($x2552 (>= ?x2551 v_0_cb_count)))
 (let (($x2554 (not $x2552)))
 (let (($x2575 (or (not (and $x2554 (<= 1 ?x2551))) (= v_0_cb_end_15 (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))))
 (let ((?x881 (- 1)))
 (let ((?x2069 (* ?x881 v_0_cb_partial_prefix)))
 (let (($x2566 (= v_0_cb_end_15 (mod (+ v_0_snd_una v_0_cb_length_15 ?x2069) 4294967296))))
 (let (($x2568 (or (not (and $x2554 (= 15 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_15)) $x2566))))
 (let (($x2553 (or (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)) $x2552)))
 (and $x2553 (or $x2554 (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15))) $x2568 $x2575)))))))))))
(assert
 (= 78 choice_0))
(assert
 (= 4 state_0))
(assert
 (= 4 state_1))
(assert
 (or (not (<= 0 v_1_snd_wnd)) (not (>= 65535 v_1_snd_wnd)) (not (= v_1_local_window (+ 16 (* (- 1) v_1_rcv_buf)))) (not (>= 1 v_1_rx_slot_00)) (not (or (not (>= v_1_rcv_buf 16)) (= 0 v_1_rx_slot_00))) (not (>= 1 v_1_rx_slot_01)) (not (or (not (>= v_1_rcv_buf 15)) (= 0 v_1_rx_slot_01))) (not (>= 1 v_1_rx_slot_02))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun v_0_snd_buf () Int)
(declare-fun v_0_rtx_buf () Int)
(declare-fun v_0_rcv_buf () Int)
(declare-fun v_0_rx_chunk () Int)
(declare-fun v_0_rx_slot_00 () Int)
(declare-fun v_0_rx_slot_01 () Int)
(declare-fun v_0_rx_slot_02 () Int)
(declare-fun v_0_rx_slot_03 () Int)
(declare-fun v_0_rx_slot_04 () Int)
(declare-fun v_0_rx_slot_05 () Int)
(declare-fun v_0_rx_slot_06 () Int)
(declare-fun v_0_rx_slot_07 () Int)
(declare-fun v_0_rx_slot_08 () Int)
(declare-fun v_0_rx_slot_09 () Int)
(declare-fun v_0_rx_slot_10 () Int)
(declare-fun v_0_rx_slot_11 () Int)
(declare-fun v_0_rx_slot_12 () Int)
(declare-fun v_0_rx_slot_13 () Int)
(declare-fun v_0_rx_slot_14 () Int)
(declare-fun v_0_rx_slot_15 () Int)
(declare-fun v_1_snd_buf () Int)
(declare-fun v_1_rtx_buf () Int)
(declare-fun v_1_rcv_buf () Int)
(declare-fun v_1_rx_chunk () Int)
(declare-fun v_1_rx_slot_00 () Int)
(declare-fun v_1_rx_slot_01 () Int)
(declare-fun v_1_rx_slot_02 () Int)
(declare-fun v_1_rx_slot_03 () Int)
(declare-fun v_1_rx_slot_04 () Int)
(declare-fun v_1_rx_slot_05 () Int)
(declare-fun v_1_rx_slot_06 () Int)
(declare-fun v_1_rx_slot_07 () Int)
(declare-fun v_1_rx_slot_08 () Int)
(declare-fun v_1_rx_slot_09 () Int)
(declare-fun v_1_rx_slot_10 () Int)
(declare-fun v_1_rx_slot_11 () Int)
(declare-fun v_1_rx_slot_12 () Int)
(declare-fun v_1_rx_slot_13 () Int)
(declare-fun v_1_rx_slot_14 () Int)
(declare-fun v_1_rx_slot_15 () Int)
(declare-fun v_0_iss () Int)
(declare-fun v_0_irs () Int)
(declare-fun v_0_snd_una () Int)
(declare-fun v_0_snd_nxt () Int)
(declare-fun v_0_rcv_nxt () Int)
(declare-fun v_0_tx_seq () Int)
(declare-fun v_0_tx_ack () Int)
(declare-fun v_0_snd_wl1 () Int)
(declare-fun v_0_snd_wl2 () Int)
(declare-fun v_0_fin_seq () Int)
(declare-fun v_0_rx_fin_seq () Int)
(declare-fun v_0_rtt_end () Int)
(declare-fun v_0_cc_before_una () Int)
(declare-fun v_0_fr_before_una () Int)
(declare-fun v_0_fr_before_nxt () Int)
(declare-fun v_0_lt_before_nxt () Int)
(declare-fun v_0_choice_before_nxt () Int)
(declare-fun v_0_cb_before_nxt () Int)
(declare-fun v_0_cb_append_end () Int)
(declare-fun v_0_cb_end_00 () Int)
(declare-fun v_0_cb_end_01 () Int)
(declare-fun v_0_cb_end_02 () Int)
(declare-fun v_0_cb_end_03 () Int)
(declare-fun v_0_cb_end_04 () Int)
(declare-fun v_0_cb_end_05 () Int)
(declare-fun v_0_cb_end_06 () Int)
(declare-fun v_0_cb_end_07 () Int)
(declare-fun v_0_cb_end_08 () Int)
(declare-fun v_0_cb_end_09 () Int)
(declare-fun v_0_cb_end_10 () Int)
(declare-fun v_0_cb_end_11 () Int)
(declare-fun v_0_cb_end_12 () Int)
(declare-fun v_0_cb_end_13 () Int)
(declare-fun v_0_cb_end_14 () Int)
(declare-fun v_0_cb_end_15 () Int)
(declare-fun v_1_iss () Int)
(declare-fun v_1_irs () Int)
(declare-fun v_1_snd_una () Int)
(declare-fun v_1_snd_nxt () Int)
(declare-fun v_1_rcv_nxt () Int)
(declare-fun v_1_tx_seq () Int)
(declare-fun v_1_tx_ack () Int)
(declare-fun v_1_snd_wl1 () Int)
(declare-fun v_1_snd_wl2 () Int)
(declare-fun v_1_fin_seq () Int)
(declare-fun v_1_rx_fin_seq () Int)
(declare-fun v_1_rtt_end () Int)
(declare-fun v_1_cc_before_una () Int)
(declare-fun v_1_fr_before_una () Int)
(declare-fun v_1_fr_before_nxt () Int)
(declare-fun v_1_lt_before_nxt () Int)
(declare-fun v_1_choice_before_nxt () Int)
(declare-fun v_1_cb_before_nxt () Int)
(declare-fun v_1_cb_append_end () Int)
(declare-fun v_1_cb_end_00 () Int)
(declare-fun v_1_cb_end_01 () Int)
(declare-fun v_1_cb_end_02 () Int)
(declare-fun v_1_cb_end_03 () Int)
(declare-fun v_1_cb_end_04 () Int)
(declare-fun v_1_cb_end_05 () Int)
(declare-fun v_1_cb_end_06 () Int)
(declare-fun v_1_cb_end_07 () Int)
(declare-fun v_1_cb_end_08 () Int)
(declare-fun v_1_cb_end_09 () Int)
(declare-fun v_1_cb_end_10 () Int)
(declare-fun v_1_cb_end_11 () Int)
(declare-fun v_1_cb_end_12 () Int)
(declare-fun v_1_cb_end_13 () Int)
(declare-fun v_1_cb_end_14 () Int)
(declare-fun v_1_cb_end_15 () Int)
(declare-fun now_0 () Int)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_delack () Int)
(declare-fun active_0_delack () Bool)
(declare-fun due_0_persist () Int)
(declare-fun active_0_persist () Bool)
(declare-fun input_0_app.send_data () Int)
(declare-fun input_0_net.data_data () Int)
(declare-fun input_0_net.fin_segment_data () Int)
(declare-fun input_0_net.syn_seq () Int)
(declare-fun input_0_net.synack_seq () Int)
(declare-fun input_0_net.synack_ack () Int)
(declare-fun input_0_net.ack_seq () Int)
(declare-fun input_0_net.ack_ack () Int)
(declare-fun input_0_net.fin_seq () Int)
(declare-fun input_0_net.fin_ack () Int)
(declare-fun input_0_net.rst_seq () Int)
(declare-fun input_0_net.rstack_seq () Int)
(declare-fun input_0_net.rstack_ack () Int)
(declare-fun input_0_net.data_seq () Int)
(declare-fun input_0_net.data_ack () Int)
(declare-fun input_0_net.fin_segment_seq () Int)
(declare-fun input_0_net.fin_segment_ack () Int)
(declare-fun v_0_persist_interval_ms () Int)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_persist_active () Bool)
(declare-fun v_0_fin_sent () Bool)
(declare-fun v_0_snd_wnd () Int)
(declare-fun now_1 () Int)
(declare-fun due_1_persist () Int)
(declare-fun due_1_delack () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_persist () Bool)
(declare-fun active_1_delack () Bool)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_cb_done_15 () Bool)
(declare-fun v_0_cb_length_15 () Int)
(declare-fun v_1_cb_length_15 () Int)
(declare-fun v_1_cb_done_14 () Bool)
(declare-fun v_0_cb_length_14 () Int)
(declare-fun v_1_cb_length_14 () Int)
(declare-fun v_1_cb_done_13 () Bool)
(declare-fun v_0_cb_length_13 () Int)
(declare-fun v_1_cb_length_13 () Int)
(declare-fun v_1_cb_done_12 () Bool)
(declare-fun v_0_cb_length_12 () Int)
(declare-fun v_1_cb_length_12 () Int)
(declare-fun v_1_cb_done_11 () Bool)
(declare-fun v_0_cb_length_11 () Int)
(declare-fun v_1_cb_length_11 () Int)
(declare-fun v_1_cb_done_10 () Bool)
(declare-fun v_0_cb_length_10 () Int)
(declare-fun v_1_cb_length_10 () Int)
(declare-fun v_1_cb_done_09 () Bool)
(declare-fun v_0_cb_length_09 () Int)
(declare-fun v_1_cb_length_09 () Int)
(declare-fun v_1_cb_done_08 () Bool)
(declare-fun v_0_cb_length_08 () Int)
(declare-fun v_1_cb_length_08 () Int)
(declare-fun v_1_cb_done_07 () Bool)
(declare-fun v_0_cb_length_07 () Int)
(declare-fun v_1_cb_length_07 () Int)
(declare-fun v_1_cb_done_06 () Bool)
(declare-fun v_0_cb_length_06 () Int)
(declare-fun v_1_cb_length_06 () Int)
(declare-fun v_1_cb_done_05 () Bool)
(declare-fun v_0_cb_length_05 () Int)
(declare-fun v_1_cb_length_05 () Int)
(declare-fun v_1_cb_done_04 () Bool)
(declare-fun v_0_cb_length_04 () Int)
(declare-fun v_1_cb_length_04 () Int)
(declare-fun v_1_cb_done_03 () Bool)
(declare-fun v_0_cb_length_03 () Int)
(declare-fun v_1_cb_length_03 () Int)
(declare-fun v_1_cb_done_02 () Bool)
(declare-fun v_0_cb_length_02 () Int)
(declare-fun v_1_cb_length_02 () Int)
(declare-fun v_1_cb_done_01 () Bool)
(declare-fun v_0_cb_length_01 () Int)
(declare-fun v_1_cb_length_01 () Int)
(declare-fun v_1_cb_done_00 () Bool)
(declare-fun v_0_cb_length_00 () Int)
(declare-fun v_1_cb_length_00 () Int)
(declare-fun v_1_cb_is_new () Bool)
(declare-fun v_1_cb_drop_step () Int)
(declare-fun v_0_cb_abandoned_total () Int)
(declare-fun v_1_cb_abandoned_total () Int)
(declare-fun v_0_cb_acked_total () Int)
(declare-fun v_1_cb_acked_total () Int)
(declare-fun v_0_cb_emitted_total () Int)
(declare-fun v_1_cb_emitted_total () Int)
(declare-fun v_1_cb_partial_prefix () Int)
(declare-fun v_1_cb_live_total () Int)
(declare-fun v_1_cb_step_bytes () Int)
(declare-fun v_1_cb_retired_count () Int)
(declare-fun v_1_cb_append_length () Int)
(declare-fun v_1_cb_new_count () Int)
(declare-fun v_0_cb_count () Int)
(declare-fun v_1_cb_count () Int)
(declare-fun v_0_cb_tail () Int)
(declare-fun v_1_cb_tail () Int)
(declare-fun v_0_cb_head () Int)
(declare-fun v_1_cb_head () Int)
(declare-fun v_0_svc_abandoned_bytes () Int)
(declare-fun v_1_svc_abandoned_bytes () Int)
(declare-fun v_0_svc_acked_bytes () Int)
(declare-fun v_1_svc_acked_bytes () Int)
(declare-fun v_0_svc_written_bytes () Int)
(declare-fun v_1_svc_written_bytes () Int)
(declare-fun v_1_svc_drop_step () Int)
(declare-fun v_1_svc_ack_step () Int)
(declare-fun v_1_svc_accept_step () Int)
(declare-fun v_1_svc_before_total () Int)
(declare-fun v_1_sched_packets () Int)
(declare-fun v_1_sched_bytes () Int)
(declare-fun v_1_sched_cause () Int)
(declare-fun v_0_sched_at_ms () Int)
(declare-fun v_1_sched_at_ms () Int)
(declare-fun v_1_sched_open () Bool)
(declare-fun v_0_choice_before_flight () Int)
(declare-fun v_1_choice_before_flight () Int)
(declare-fun v_0_choice_limit () Int)
(declare-fun v_1_choice_limit () Int)
(declare-fun v_0_choice_count () Int)
(declare-fun v_1_choice_count () Int)
(declare-fun v_1_choice_used () Bool)
(declare-fun v_0_lt_epoch_bytes () Int)
(declare-fun v_1_lt_loss_flight () Int)
(declare-fun v_1_lt_before_window () Int)
(declare-fun v_1_lt_before_flight () Int)
(declare-fun v_0_cc_cwnd () Int)
(declare-fun v_1_lt_before_cwnd () Int)
(declare-fun v_1_lt_before_bytes () Int)
(declare-fun v_0_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_bytes () Int)
(declare-fun v_1_lt_take () Int)
(declare-fun v_1_lt_emitted () Bool)
(declare-fun v_1_lt_eligible () Bool)
(declare-fun v_0_idle_restart_count () Int)
(declare-fun v_1_idle_restart_count () Int)
(declare-fun v_0_cc_ssthresh () Int)
(declare-fun v_1_idle_before_threshold () Int)
(declare-fun v_1_idle_before_rto () Int)
(declare-fun v_1_idle_before_cwnd () Int)
(declare-fun v_0_idle_last_data_ms () Int)
(declare-fun v_0_idle_data_valid () Bool)
(declare-fun v_1_idle_elapsed_ms () Int)
(declare-fun v_1_idle_restart () Bool)
(declare-fun v_1_idle_data_emitted () Bool)
(declare-fun v_1_idle_event_ms () Int)
(declare-fun v_1_idle_last_data_ms () Int)
(declare-fun v_1_idle_data_valid () Bool)
(declare-fun v_0_fr_entries () Int)
(declare-fun v_1_fr_entries () Int)
(declare-fun v_1_fr_emit_count () Int)
(declare-fun v_1_fr_retransmitted () Bool)
(declare-fun v_1_fr_exited () Bool)
(declare-fun v_1_fr_extra () Bool)
(declare-fun v_1_fr_entered () Bool)
(declare-fun v_1_fr_duplicate () Bool)
(declare-fun v_0_retries () Int)
(declare-fun v_1_fr_before_retries () Int)
(declare-fun v_1_fr_before_rto () Int)
(declare-fun v_1_fr_before_flight () Int)
(declare-fun v_0_fr_active () Bool)
(declare-fun v_1_fr_was_active () Bool)
(declare-fun v_0_fr_last_window () Int)
(declare-fun v_1_fr_last_window () Int)
(declare-fun v_0_fr_window_valid () Bool)
(declare-fun v_1_fr_window_valid () Bool)
(declare-fun v_0_fr_dupacks () Int)
(declare-fun v_1_fr_dupacks () Int)
(declare-fun v_1_fr_active () Bool)
(declare-fun v_1_fr_before_window_valid () Bool)
(declare-fun v_1_fr_before_wire_window () Int)
(declare-fun v_1_fr_window_ignored () Bool)
(declare-fun v_0_cc_rto_15 () Bool)
(declare-fun v_1_cc_rto_15 () Bool)
(declare-fun v_0_cc_rto_14 () Bool)
(declare-fun v_1_cc_rto_14 () Bool)
(declare-fun v_0_cc_rto_13 () Bool)
(declare-fun v_1_cc_rto_13 () Bool)
(declare-fun v_0_cc_rto_12 () Bool)
(declare-fun v_1_cc_rto_12 () Bool)
(declare-fun v_0_cc_rto_11 () Bool)
(declare-fun v_1_cc_rto_11 () Bool)
(declare-fun v_0_cc_rto_10 () Bool)
(declare-fun v_1_cc_rto_10 () Bool)
(declare-fun v_0_cc_rto_09 () Bool)
(declare-fun v_1_cc_rto_09 () Bool)
(declare-fun v_0_cc_rto_08 () Bool)
(declare-fun v_1_cc_rto_08 () Bool)
(declare-fun v_0_cc_rto_07 () Bool)
(declare-fun v_1_cc_rto_07 () Bool)
(declare-fun v_0_cc_rto_06 () Bool)
(declare-fun v_1_cc_rto_06 () Bool)
(declare-fun v_0_cc_rto_05 () Bool)
(declare-fun v_1_cc_rto_05 () Bool)
(declare-fun v_0_cc_rto_04 () Bool)
(declare-fun v_1_cc_rto_04 () Bool)
(declare-fun v_0_cc_rto_03 () Bool)
(declare-fun v_1_cc_rto_03 () Bool)
(declare-fun v_0_cc_rto_02 () Bool)
(declare-fun v_1_cc_rto_02 () Bool)
(declare-fun v_0_cc_rto_01 () Bool)
(declare-fun v_1_cc_rto_01 () Bool)
(declare-fun v_0_cc_rto_00 () Bool)
(declare-fun v_1_cc_rto_00 () Bool)
(declare-fun v_1_cc_new_sent () Int)
(declare-fun v_1_cc_send_budget () Int)
(declare-fun v_1_cc_before_cwnd () Int)
(declare-fun v_1_cc_growth () Int)
(declare-fun v_0_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_changed () Bool)
(declare-fun v_1_cc_loss () Bool)
(declare-fun v_1_cc_before_window () Int)
(declare-fun v_1_cc_before_persist () Bool)
(declare-fun v_1_cc_before_flight () Int)
(declare-fun v_1_cc_acked () Int)
(declare-fun v_0_cc_ca_credit () Int)
(declare-fun v_1_cc_ca_credit () Int)
(declare-fun v_1_cc_ssthresh () Int)
(declare-fun v_1_cc_cwnd () Int)
(declare-fun v_0_cc_initial_threshold () Int)
(declare-fun v_1_cc_initial_threshold () Int)
(declare-fun v_0_cc_initial_window () Int)
(declare-fun v_1_cc_initial_window () Int)
(declare-fun v_0_persist_elapsed_ms () Int)
(declare-fun v_1_persist_elapsed_ms () Int)
(declare-fun v_0_persist_probes () Int)
(declare-fun v_1_persist_probes () Int)
(declare-fun v_0_persist_deadline_ms () Int)
(declare-fun v_1_persist_deadline_ms () Int)
(declare-fun v_0_persist_last_ms () Int)
(declare-fun v_1_persist_last_ms () Int)
(declare-fun v_0_persist_since_ms () Int)
(declare-fun v_1_persist_since_ms () Int)
(declare-fun v_0_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_interval_ms () Int)
(declare-fun v_1_persist_probe_new () Bool)
(declare-fun v_1_persist_probe_sent () Bool)
(declare-fun v_1_persist_first () Bool)
(declare-fun v_1_persist_was_active () Bool)
(declare-fun v_1_persist_start () Bool)
(declare-fun v_1_persist_eligible () Bool)
(declare-fun v_1_persist_active () Bool)
(declare-fun v_1_ack_defer_now () Bool)
(declare-fun v_1_ack_defer_candidate () Bool)
(declare-fun v_0_ack_rmss () Int)
(declare-fun v_1_ack_rmss () Int)
(declare-fun v_0_ack_delay_ms () Int)
(declare-fun v_1_ack_delay_ms () Int)
(declare-fun v_0_ack_full_segments () Int)
(declare-fun v_1_ack_full_segments () Int)
(declare-fun v_0_ack_bytes () Int)
(declare-fun v_1_ack_bytes () Int)
(declare-fun v_0_ack_since_ms () Int)
(declare-fun v_1_ack_since_ms () Int)
(declare-fun v_0_ack_pending () Bool)
(declare-fun v_1_ack_pending () Bool)
(declare-fun v_1_syn_timeout_eligible () Bool)
(declare-fun v_1_tx_syn_pending () Bool)
(declare-fun v_1_tx_syn_time () Int)
(declare-fun v_1_tx_waiting () Bool)
(declare-fun v_0_tx_is_fin () Bool)
(declare-fun v_1_tx_is_fin () Bool)
(declare-fun v_0_tx_previous_rto () Int)
(declare-fun v_1_tx_previous_rto () Int)
(declare-fun v_0_tx_elapsed () Int)
(declare-fun v_1_tx_elapsed () Int)
(declare-fun v_1_tx_retransmitted () Bool)
(declare-fun v_0_tx_max_previous () Int)
(declare-fun v_1_tx_max_previous () Int)
(declare-fun v_0_tx_eligible () Int)
(declare-fun v_1_tx_eligible () Int)
(declare-fun v_0_tx_emit_count () Int)
(declare-fun v_1_tx_emit_count () Int)
(declare-fun v_0_tx_fin_time () Int)
(declare-fun v_0_fin_acknowledged () Bool)
(declare-fun v_1_tx_fin_time () Int)
(declare-fun v_0_tx_time_15 () Int)
(declare-fun v_1_tx_time_15 () Int)
(declare-fun v_0_tx_time_14 () Int)
(declare-fun v_1_tx_time_14 () Int)
(declare-fun v_0_tx_time_13 () Int)
(declare-fun v_1_tx_time_13 () Int)
(declare-fun v_0_tx_time_12 () Int)
(declare-fun v_1_tx_time_12 () Int)
(declare-fun v_0_tx_time_11 () Int)
(declare-fun v_1_tx_time_11 () Int)
(declare-fun v_0_tx_time_10 () Int)
(declare-fun v_1_tx_time_10 () Int)
(declare-fun v_0_tx_time_09 () Int)
(declare-fun v_1_tx_time_09 () Int)
(declare-fun v_0_tx_time_08 () Int)
(declare-fun v_1_tx_time_08 () Int)
(declare-fun v_0_tx_time_07 () Int)
(declare-fun v_1_tx_time_07 () Int)
(declare-fun v_0_tx_time_06 () Int)
(declare-fun v_1_tx_time_06 () Int)
(declare-fun v_0_tx_time_05 () Int)
(declare-fun v_1_tx_time_05 () Int)
(declare-fun v_0_tx_time_04 () Int)
(declare-fun v_1_tx_time_04 () Int)
(declare-fun v_0_tx_time_03 () Int)
(declare-fun v_1_tx_time_03 () Int)
(declare-fun v_0_tx_time_02 () Int)
(declare-fun v_1_tx_time_02 () Int)
(declare-fun v_0_tx_time_01 () Int)
(declare-fun v_1_tx_time_01 () Int)
(declare-fun v_0_tx_time_00 () Int)
(declare-fun v_1_tx_time_00 () Int)
(declare-fun v_0_rto_base_ms () Int)
(declare-fun v_1_rto_base_ms () Int)
(declare-fun v_0_rtt_samples () Int)
(declare-fun v_1_rtt_samples () Int)
(declare-fun v_0_rtt_last_ms () Int)
(declare-fun v_1_rtt_last_ms () Int)
(declare-fun v_1_rtt_sample_was_ambiguous () Bool)
(declare-fun v_1_rtt_sample_used () Bool)
(declare-fun v_1_rtt_start_new () Bool)
(declare-fun v_0_rtt_remaining () Int)
(declare-fun v_1_rtt_remaining () Int)
(declare-fun v_0_rtt_start_ms () Int)
(declare-fun v_1_rtt_start_ms () Int)
(declare-fun v_0_rtt_sample_at_ms () Int)
(declare-fun v_1_rtt_sample_at_ms () Int)
(declare-fun v_0_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_ambiguous () Bool)
(declare-fun v_0_rtt_active () Bool)
(declare-fun v_1_rtt_active () Bool)
(declare-fun v_0_rtt_previous_measured () Bool)
(declare-fun v_1_rtt_previous_measured () Bool)
(declare-fun v_0_rtt_measured () Bool)
(declare-fun v_1_rtt_measured () Bool)
(declare-fun v_0_rtt_previous_var () Real)
(declare-fun v_1_rtt_previous_var () Real)
(declare-fun v_0_rtt_previous_srtt () Real)
(declare-fun v_1_rtt_previous_srtt () Real)
(declare-fun v_0_rtt_error_ms () Real)
(declare-fun v_1_rtt_error_ms () Real)
(declare-fun v_0_rttvar_ms () Real)
(declare-fun v_1_rttvar_ms () Real)
(declare-fun v_0_srtt_ms () Real)
(declare-fun v_1_srtt_ms () Real)
(declare-fun v_0_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_consumed () Bool)
(declare-fun v_0_rx_fin_done () Bool)
(declare-fun v_1_rx_fin_done () Bool)
(declare-fun v_0_rx_fin_offset () Int)
(declare-fun v_1_rx_fin_offset () Int)
(declare-fun v_0_rx_fin_pending () Bool)
(declare-fun v_1_rx_fin_pending () Bool)
(declare-fun v_1_fin_acknowledged () Bool)
(declare-fun v_1_fin_sent () Bool)
(declare-fun v_0_fin_requested () Bool)
(declare-fun v_1_fin_requested () Bool)
(declare-fun v_0_ack_window_update () Bool)
(declare-fun v_1_ack_window_update () Bool)
(declare-fun v_0_ack_advance () Bool)
(declare-fun v_1_ack_advance () Bool)
(declare-fun v_0_ack_is_future () Bool)
(declare-fun v_1_ack_is_future () Bool)
(declare-fun v_0_ack_is_new () Bool)
(declare-fun v_1_ack_is_new () Bool)
(declare-fun v_0_ack_delta () Int)
(declare-fun v_1_ack_delta () Int)
(declare-fun v_0_seg_acceptable () Bool)
(declare-fun v_1_seg_acceptable () Bool)
(declare-fun v_0_rx_acceptable () Bool)
(declare-fun v_1_rx_acceptable () Bool)
(declare-fun v_0_rx_advance () Int)
(declare-fun v_1_rx_advance () Int)
(declare-fun v_0_take () Int)
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_1_local_window () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_0_tx_flags () String)
(declare-fun v_1_tx_flags () String)
(declare-fun v_0_rtt_sample_was_ambiguous () Bool)
(declare-fun v_0_rtt_sample_used () Bool)
(declare-fun v_0_tx_retransmitted () Bool)
(declare-fun v_0_tx_waiting () Bool)
(declare-fun v_0_tx_syn_time () Int)
(declare-fun v_0_tx_syn_pending () Bool)
(declare-fun v_0_persist_probe_sent () Bool)
(declare-fun v_0_cc_acked () Int)
(declare-fun v_0_cc_growth () Int)
(declare-fun v_0_cc_send_budget () Int)
(declare-fun v_0_cc_new_sent () Int)
(declare-fun v_0_fr_emit_count () Int)
(declare-fun v_0_fr_before_retries () Int)
(declare-fun v_0_fr_before_rto () Int)
(declare-fun v_0_fr_entered () Bool)
(declare-fun v_0_fr_retransmitted () Bool)
(declare-fun v_0_fr_before_window_valid () Bool)
(declare-fun v_0_fr_before_wire_window () Int)
(declare-fun v_0_fr_window_ignored () Bool)
(declare-fun v_0_fr_exited () Bool)
(declare-fun v_0_idle_elapsed_ms () Int)
(declare-fun v_0_idle_event_ms () Int)
(declare-fun v_0_idle_data_emitted () Bool)
(declare-fun v_0_idle_before_threshold () Int)
(declare-fun v_0_idle_before_cwnd () Int)
(declare-fun v_0_idle_before_rto () Int)
(declare-fun v_0_idle_restart () Bool)
(declare-fun v_0_lt_loss_flight () Int)
(declare-fun v_0_lt_take () Int)
(declare-fun v_0_lt_before_flight () Int)
(declare-fun v_0_lt_before_cwnd () Int)
(declare-fun v_0_fr_duplicate () Bool)
(declare-fun v_0_lt_emitted () Bool)
(declare-fun v_0_lt_before_bytes () Int)
(declare-fun v_0_fr_before_flight () Int)
(declare-fun v_0_choice_used () Bool)
(declare-fun v_0_sched_bytes () Int)
(declare-fun v_0_sched_packets () Int)
(declare-fun v_0_sched_cause () Int)
(declare-fun v_0_sched_open () Bool)
(declare-fun v_0_svc_drop_step () Int)
(declare-fun v_0_svc_ack_step () Int)
(declare-fun v_0_svc_accept_step () Int)
(declare-fun v_0_cb_new_count () Int)
(declare-fun v_0_cb_live_total () Int)
(declare-fun v_0_cb_drop_step () Int)
(declare-fun v_0_cb_step_bytes () Int)
(declare-fun v_0_cb_partial_prefix () Int)
(declare-fun choice_0 () Int)
(declare-fun state_0 () Int)
(declare-fun state_1 () Int)
(assert
 (>= v_0_snd_buf 0))
(assert
 (>= v_0_rtx_buf 0))
(assert
 (>= v_0_rcv_buf 0))
(assert
 (>= v_0_rx_chunk 0))
(assert
 (>= v_0_rx_slot_00 0))
(assert
 (>= v_0_rx_slot_01 0))
(assert
 (>= v_0_rx_slot_02 0))
(assert
 (>= v_0_rx_slot_03 0))
(assert
 (>= v_0_rx_slot_04 0))
(assert
 (>= v_0_rx_slot_05 0))
(assert
 (>= v_0_rx_slot_06 0))
(assert
 (>= v_0_rx_slot_07 0))
(assert
 (>= v_0_rx_slot_08 0))
(assert
 (>= v_0_rx_slot_09 0))
(assert
 (>= v_0_rx_slot_10 0))
(assert
 (>= v_0_rx_slot_11 0))
(assert
 (>= v_0_rx_slot_12 0))
(assert
 (>= v_0_rx_slot_13 0))
(assert
 (>= v_0_rx_slot_14 0))
(assert
 (>= v_0_rx_slot_15 0))
(assert
 (>= v_1_snd_buf 0))
(assert
 (>= v_1_rtx_buf 0))
(assert
 (>= v_1_rcv_buf 0))
(assert
 (>= v_1_rx_chunk 0))
(assert
 (>= v_1_rx_slot_00 0))
(assert
 (>= v_1_rx_slot_01 0))
(assert
 (>= v_1_rx_slot_02 0))
(assert
 (>= v_1_rx_slot_03 0))
(assert
 (>= v_1_rx_slot_04 0))
(assert
 (>= v_1_rx_slot_05 0))
(assert
 (>= v_1_rx_slot_06 0))
(assert
 (>= v_1_rx_slot_07 0))
(assert
 (>= v_1_rx_slot_08 0))
(assert
 (>= v_1_rx_slot_09 0))
(assert
 (>= v_1_rx_slot_10 0))
(assert
 (>= v_1_rx_slot_11 0))
(assert
 (>= v_1_rx_slot_12 0))
(assert
 (>= v_1_rx_slot_13 0))
(assert
 (>= v_1_rx_slot_14 0))
(assert
 (>= v_1_rx_slot_15 0))
(assert
 (>= v_0_iss 0))
(assert
 (not (<= 4294967296 v_0_iss)))
(assert
 (>= v_0_irs 0))
(assert
 (not (<= 4294967296 v_0_irs)))
(assert
 (>= v_0_snd_una 0))
(assert
 (not (<= 4294967296 v_0_snd_una)))
(assert
 (>= v_0_snd_nxt 0))
(assert
 (not (<= 4294967296 v_0_snd_nxt)))
(assert
 (>= v_0_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_0_rcv_nxt)))
(assert
 (>= v_0_tx_seq 0))
(assert
 (not (<= 4294967296 v_0_tx_seq)))
(assert
 (>= v_0_tx_ack 0))
(assert
 (not (<= 4294967296 v_0_tx_ack)))
(assert
 (>= v_0_snd_wl1 0))
(assert
 (not (<= 4294967296 v_0_snd_wl1)))
(assert
 (>= v_0_snd_wl2 0))
(assert
 (not (<= 4294967296 v_0_snd_wl2)))
(assert
 (>= v_0_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_fin_seq)))
(assert
 (>= v_0_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_rx_fin_seq)))
(assert
 (>= v_0_rtt_end 0))
(assert
 (not (<= 4294967296 v_0_rtt_end)))
(assert
 (>= v_0_cc_before_una 0))
(assert
 (not (<= 4294967296 v_0_cc_before_una)))
(assert
 (>= v_0_fr_before_una 0))
(assert
 (not (<= 4294967296 v_0_fr_before_una)))
(assert
 (>= v_0_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_fr_before_nxt)))
(assert
 (>= v_0_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_lt_before_nxt)))
(assert
 (>= v_0_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_choice_before_nxt)))
(assert
 (>= v_0_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_cb_before_nxt)))
(assert
 (>= v_0_cb_append_end 0))
(assert
 (not (<= 4294967296 v_0_cb_append_end)))
(assert
 (>= v_0_cb_end_00 0))
(assert
 (not (<= 4294967296 v_0_cb_end_00)))
(assert
 (>= v_0_cb_end_01 0))
(assert
 (not (<= 4294967296 v_0_cb_end_01)))
(assert
 (>= v_0_cb_end_02 0))
(assert
 (not (<= 4294967296 v_0_cb_end_02)))
(assert
 (>= v_0_cb_end_03 0))
(assert
 (not (<= 4294967296 v_0_cb_end_03)))
(assert
 (>= v_0_cb_end_04 0))
(assert
 (not (<= 4294967296 v_0_cb_end_04)))
(assert
 (>= v_0_cb_end_05 0))
(assert
 (not (<= 4294967296 v_0_cb_end_05)))
(assert
 (>= v_0_cb_end_06 0))
(assert
 (not (<= 4294967296 v_0_cb_end_06)))
(assert
 (>= v_0_cb_end_07 0))
(assert
 (not (<= 4294967296 v_0_cb_end_07)))
(assert
 (>= v_0_cb_end_08 0))
(assert
 (not (<= 4294967296 v_0_cb_end_08)))
(assert
 (>= v_0_cb_end_09 0))
(assert
 (not (<= 4294967296 v_0_cb_end_09)))
(assert
 (>= v_0_cb_end_10 0))
(assert
 (not (<= 4294967296 v_0_cb_end_10)))
(assert
 (>= v_0_cb_end_11 0))
(assert
 (not (<= 4294967296 v_0_cb_end_11)))
(assert
 (>= v_0_cb_end_12 0))
(assert
 (not (<= 4294967296 v_0_cb_end_12)))
(assert
 (>= v_0_cb_end_13 0))
(assert
 (not (<= 4294967296 v_0_cb_end_13)))
(assert
 (>= v_0_cb_end_14 0))
(assert
 (not (<= 4294967296 v_0_cb_end_14)))
(assert
 (>= v_0_cb_end_15 0))
(assert
 (not (<= 4294967296 v_0_cb_end_15)))
(assert
 (>= v_1_iss 0))
(assert
 (not (<= 4294967296 v_1_iss)))
(assert
 (>= v_1_irs 0))
(assert
 (not (<= 4294967296 v_1_irs)))
(assert
 (>= v_1_snd_una 0))
(assert
 (not (<= 4294967296 v_1_snd_una)))
(assert
 (>= v_1_snd_nxt 0))
(assert
 (not (<= 4294967296 v_1_snd_nxt)))
(assert
 (>= v_1_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_1_rcv_nxt)))
(assert
 (>= v_1_tx_seq 0))
(assert
 (not (<= 4294967296 v_1_tx_seq)))
(assert
 (>= v_1_tx_ack 0))
(assert
 (not (<= 4294967296 v_1_tx_ack)))
(assert
 (>= v_1_snd_wl1 0))
(assert
 (not (<= 4294967296 v_1_snd_wl1)))
(assert
 (>= v_1_snd_wl2 0))
(assert
 (not (<= 4294967296 v_1_snd_wl2)))
(assert
 (>= v_1_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_fin_seq)))
(assert
 (>= v_1_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_rx_fin_seq)))
(assert
 (>= v_1_rtt_end 0))
(assert
 (not (<= 4294967296 v_1_rtt_end)))
(assert
 (>= v_1_cc_before_una 0))
(assert
 (not (<= 4294967296 v_1_cc_before_una)))
(assert
 (>= v_1_fr_before_una 0))
(assert
 (not (<= 4294967296 v_1_fr_before_una)))
(assert
 (>= v_1_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_fr_before_nxt)))
(assert
 (>= v_1_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_lt_before_nxt)))
(assert
 (>= v_1_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_choice_before_nxt)))
(assert
 (>= v_1_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_cb_before_nxt)))
(assert
 (>= v_1_cb_append_end 0))
(assert
 (not (<= 4294967296 v_1_cb_append_end)))
(assert
 (>= v_1_cb_end_00 0))
(assert
 (not (<= 4294967296 v_1_cb_end_00)))
(assert
 (>= v_1_cb_end_01 0))
(assert
 (not (<= 4294967296 v_1_cb_end_01)))
(assert
 (>= v_1_cb_end_02 0))
(assert
 (not (<= 4294967296 v_1_cb_end_02)))
(assert
 (>= v_1_cb_end_03 0))
(assert
 (not (<= 4294967296 v_1_cb_end_03)))
(assert
 (>= v_1_cb_end_04 0))
(assert
 (not (<= 4294967296 v_1_cb_end_04)))
(assert
 (>= v_1_cb_end_05 0))
(assert
 (not (<= 4294967296 v_1_cb_end_05)))
(assert
 (>= v_1_cb_end_06 0))
(assert
 (not (<= 4294967296 v_1_cb_end_06)))
(assert
 (>= v_1_cb_end_07 0))
(assert
 (not (<= 4294967296 v_1_cb_end_07)))
(assert
 (>= v_1_cb_end_08 0))
(assert
 (not (<= 4294967296 v_1_cb_end_08)))
(assert
 (>= v_1_cb_end_09 0))
(assert
 (not (<= 4294967296 v_1_cb_end_09)))
(assert
 (>= v_1_cb_end_10 0))
(assert
 (not (<= 4294967296 v_1_cb_end_10)))
(assert
 (>= v_1_cb_end_11 0))
(assert
 (not (<= 4294967296 v_1_cb_end_11)))
(assert
 (>= v_1_cb_end_12 0))
(assert
 (not (<= 4294967296 v_1_cb_end_12)))
(assert
 (>= v_1_cb_end_13 0))
(assert
 (not (<= 4294967296 v_1_cb_end_13)))
(assert
 (>= v_1_cb_end_14 0))
(assert
 (not (<= 4294967296 v_1_cb_end_14)))
(assert
 (>= v_1_cb_end_15 0))
(assert
 (not (<= 4294967296 v_1_cb_end_15)))
(assert
 true)
(assert
 true)
(assert
 (>= now_0 0))
(assert
 (let (($x370 (not active_0_rtx)))
 (or $x370 (>= due_0_rtx now_0))))
(assert
 (let (($x375 (not active_0_user)))
 (or $x375 (>= due_0_user now_0))))
(assert
 (let (($x380 (not active_0_time_wait)))
 (or $x380 (>= due_0_time_wait now_0))))
(assert
 (let (($x385 (not active_0_delack)))
 (or $x385 (>= due_0_delack now_0))))
(assert
 (let (($x390 (not active_0_persist)))
 (or $x390 (>= due_0_persist now_0))))
(assert
 (>= input_0_app.send_data 0))
(assert
 (>= input_0_net.data_data 0))
(assert
 (>= input_0_net.fin_segment_data 0))
(assert
 (>= input_0_net.syn_seq 0))
(assert
 (not (<= 4294967296 input_0_net.syn_seq)))
(assert
 (>= input_0_net.synack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.synack_seq)))
(assert
 (>= input_0_net.synack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.synack_ack)))
(assert
 (>= input_0_net.ack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.ack_seq)))
(assert
 (>= input_0_net.ack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.ack_ack)))
(assert
 (>= input_0_net.fin_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_seq)))
(assert
 (>= input_0_net.fin_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_ack)))
(assert
 (>= input_0_net.rst_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rst_seq)))
(assert
 (>= input_0_net.rstack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_seq)))
(assert
 (>= input_0_net.rstack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_ack)))
(assert
 (>= input_0_net.data_seq 0))
(assert
 (not (<= 4294967296 input_0_net.data_seq)))
(assert
 (>= input_0_net.data_ack 0))
(assert
 (not (<= 4294967296 input_0_net.data_ack)))
(assert
 (>= input_0_net.fin_segment_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_seq)))
(assert
 (>= input_0_net.fin_segment_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_ack)))
(assert
 (let (($x802 (not v_0_persist_active)))
 (let (($x611 (= 0 v_0_rtx_buf)))
 (let (($x612 (or v_0_persist_active $x611)))
 (let (($x609 (>= 1 v_0_rtx_buf)))
 (let (($x608 (<= 1 (+ v_0_rtx_buf v_0_snd_buf input_0_app.send_data))))
 (let (($x606 (not v_0_fin_sent)))
 (let (($x605 (= 0 v_0_snd_wnd)))
 (let (($x803 (and $x605 $x606 $x608 $x609 $x612 $x802)))
 (let ((?x815 (ite $x803 v_0_rto_ms v_0_persist_interval_ms)))
 (let ((?x832 (+ now_1 ?x815)))
 (let (($x1325 (= due_1_delack due_0_delack)))
 (let (($x1323 (= due_1_time_wait due_0_time_wait)))
 (let (($x1321 (= due_1_user due_0_user)))
 (let ((?x1317 (+ now_1 v_0_rto_ms)))
 (let (($x1300 (<= 1 v_0_rtx_buf)))
 (let (($x613 (and $x605 $x606 $x608 $x609 $x612)))
 (let (($x614 (not $x613)))
 (let (($x1303 (and v_0_persist_active $x614 $x1300 (not (and $x614 active_0_rtx)))))
 (let (($x1315 (= active_1_persist (and $x605 $x606 $x608 $x609 $x612 (or active_0_persist $x803)))))
 (let (($x1311 (= active_1_delack active_0_delack)))
 (let (($x1309 (= active_1_time_wait active_0_time_wait)))
 (let (($x1307 (= active_1_user active_0_user)))
 (let (($x1298 (not v_1_cb_done_15)))
 (let ((?x1098 (ite (<= 0 input_0_app.send_data) input_0_app.send_data 0)))
 (let ((?x1104 (+ ?x1098 (* (- 1) input_0_app.send_data))))
 (let ((?x1106 (ite (<= 0 ?x1104) ?x1104 0)))
 (let (($x1120 (<= 1 ?x1106)))
 (let (($x1292 (not v_1_cb_done_14)))
 (let (($x1286 (not v_1_cb_done_13)))
 (let (($x1280 (not v_1_cb_done_12)))
 (let (($x1274 (not v_1_cb_done_11)))
 (let (($x1268 (not v_1_cb_done_10)))
 (let (($x1262 (not v_1_cb_done_09)))
 (let (($x1256 (not v_1_cb_done_08)))
 (let (($x1250 (not v_1_cb_done_07)))
 (let (($x1244 (not v_1_cb_done_06)))
 (let (($x1238 (not v_1_cb_done_05)))
 (let (($x1232 (not v_1_cb_done_04)))
 (let (($x1226 (not v_1_cb_done_03)))
 (let (($x1220 (not v_1_cb_done_02)))
 (let (($x1214 (not v_1_cb_done_01)))
 (let (($x1208 (not v_1_cb_done_00)))
 (let (($x1202 (not v_1_cb_is_new)))
 (let (($x1200 (= v_1_cb_append_end 0)))
 (let (($x1199 (= v_1_cb_before_nxt v_0_snd_nxt)))
 (let ((?x1193 (+ v_0_cb_length_00 v_0_cb_length_01 v_0_cb_length_02 v_0_cb_length_03 v_0_cb_length_04 v_0_cb_length_05 v_0_cb_length_06 v_0_cb_length_07 v_0_cb_length_08 v_0_cb_length_09 v_0_cb_length_10 v_0_cb_length_11 v_0_cb_length_12 v_0_cb_length_13 v_0_cb_length_14 v_0_cb_length_15)))
 (let ((?x1194 (ite $x1120 ?x1193 0)))
 (let (($x1190 (= v_1_cb_acked_total v_0_cb_acked_total)))
 (let (($x1187 (= v_1_cb_emitted_total v_0_cb_emitted_total)))
 (let ((?x882 (- 1)))
 (let ((?x883 (* ?x882 v_0_rtx_buf)))
 (let ((?x1179 (ite $x1120 0 v_0_cb_length_15)))
 (let ((?x1177 (ite $x1120 0 v_0_cb_length_14)))
 (let ((?x1175 (ite $x1120 0 v_0_cb_length_13)))
 (let ((?x1173 (ite $x1120 0 v_0_cb_length_12)))
 (let ((?x1171 (ite $x1120 0 v_0_cb_length_11)))
 (let ((?x1169 (ite $x1120 0 v_0_cb_length_10)))
 (let ((?x1167 (ite $x1120 0 v_0_cb_length_09)))
 (let ((?x1165 (ite $x1120 0 v_0_cb_length_08)))
 (let ((?x1163 (ite $x1120 0 v_0_cb_length_07)))
 (let ((?x1161 (ite $x1120 0 v_0_cb_length_06)))
 (let ((?x1159 (ite $x1120 0 v_0_cb_length_05)))
 (let ((?x1157 (ite $x1120 0 v_0_cb_length_04)))
 (let ((?x1155 (ite $x1120 0 v_0_cb_length_03)))
 (let ((?x1153 (ite $x1120 0 v_0_cb_length_02)))
 (let ((?x1151 (ite $x1120 0 v_0_cb_length_01)))
 (let ((?x1149 (ite $x1120 0 v_0_cb_length_00)))
 (let ((?x1183 (+ ?x1149 ?x1151 ?x1153 ?x1155 ?x1157 ?x1159 ?x1161 ?x1163 ?x1165 ?x1167 ?x1169 ?x1171 ?x1173 ?x1175 ?x1177 ?x1179 ?x883)))
 (let ((?x1180 (+ ?x1149 ?x1151 ?x1153 ?x1155 ?x1157 ?x1159 ?x1161 ?x1163 ?x1165 ?x1167 ?x1169 ?x1171 ?x1173 ?x1175 ?x1177 ?x1179)))
 (let (($x1146 (= v_1_cb_step_bytes 0)))
 (let (($x1144 (= v_1_cb_retired_count 0)))
 (let (($x1142 (= v_1_cb_append_length 0)))
 (let (($x1140 (= v_1_cb_new_count 0)))
 (let ((?x1130 (ite $x1120 0 v_0_cb_tail)))
 (let ((?x1126 (ite $x1120 0 (ite (<= 16 v_0_cb_head) (+ (- 16) v_0_cb_head) v_0_cb_head))))
 (let (($x1114 (= v_1_svc_acked_bytes v_0_svc_acked_bytes)))
 (let (($x1086 (= v_1_sched_at_ms v_0_sched_at_ms)))
 (let (($x1083 (not v_1_sched_open)))
 (let (($x1081 (= v_1_choice_before_flight v_0_choice_before_flight)))
 (let (($x1078 (= v_1_choice_before_nxt v_0_choice_before_nxt)))
 (let (($x1077 (= v_1_choice_limit v_0_choice_limit)))
 (let (($x1074 (= v_1_choice_count v_0_choice_count)))
 (let (($x1071 (not v_1_choice_used)))
 (let (($x1065 (= v_1_lt_before_window v_0_snd_wnd)))
 (let (($x1063 (= v_1_lt_before_flight v_0_rtx_buf)))
 (let (($x1061 (= v_1_lt_before_nxt v_0_snd_nxt)))
 (let (($x1060 (= v_1_lt_before_cwnd v_0_cc_cwnd)))
 (let (($x1058 (= v_1_lt_before_bytes v_0_lt_epoch_bytes)))
 (let (($x1056 (= v_1_lt_epoch_packets (ite (or $x611 $x613) 0 v_0_lt_epoch_packets))))
 (let (($x1046 (not v_1_lt_emitted)))
 (let (($x1044 (not v_1_lt_eligible)))
 (let (($x1042 (= v_1_idle_restart_count v_0_idle_restart_count)))
 (let (($x1039 (= v_1_idle_before_threshold v_0_cc_ssthresh)))
 (let (($x1037 (= v_1_idle_before_rto v_0_rto_ms)))
 (let (($x1035 (= v_1_idle_before_cwnd v_0_cc_cwnd)))
 (let ((?x1032 (ite v_0_idle_data_valid (+ now_1 (* ?x882 v_0_idle_last_data_ms)) 0)))
 (let (($x1028 (not v_1_idle_restart)))
 (let (($x1026 (not v_1_idle_data_emitted)))
 (let (($x1024 (= v_1_idle_event_ms now_1)))
 (let (($x1022 (= v_1_idle_last_data_ms v_0_idle_last_data_ms)))
 (let (($x1019 (= v_1_idle_data_valid v_0_idle_data_valid)))
 (let (($x1016 (= v_1_fr_entries v_0_fr_entries)))
 (let (($x1013 (= v_1_fr_emit_count 0)))
 (let (($x1011 (not v_1_fr_retransmitted)))
 (let (($x1009 (not v_1_fr_exited)))
 (let (($x1007 (not v_1_fr_extra)))
 (let (($x1005 (not v_1_fr_entered)))
 (let (($x1003 (not v_1_fr_duplicate)))
 (let (($x1001 (= v_1_fr_before_retries v_0_retries)))
 (let (($x999 (= v_1_fr_before_rto v_0_rto_ms)))
 (let (($x997 (= v_1_fr_before_flight v_0_rtx_buf)))
 (let (($x995 (= v_1_fr_before_nxt v_0_snd_nxt)))
 (let (($x994 (= v_1_fr_before_una v_0_snd_una)))
 (let (($x993 (= v_1_fr_was_active v_0_fr_active)))
 (let (($x991 (= v_1_fr_last_window v_0_fr_last_window)))
 (let (($x989 (= v_1_fr_window_valid v_0_fr_window_valid)))
 (let (($x977 (= v_1_fr_before_window_valid v_0_fr_window_valid)))
 (let (($x974 (= v_1_fr_before_wire_window v_0_fr_last_window)))
 (let (($x971 (not v_1_fr_window_ignored)))
 (let ((?x884 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd) ?x883)))
 (let (($x878 (= v_1_cc_before_cwnd v_0_cc_cwnd)))
 (let (($x874 (= v_1_cc_threshold_updates v_0_cc_threshold_updates)))
 (let (($x871 (not v_1_cc_threshold_changed)))
 (let (($x869 (not v_1_cc_loss)))
 (let (($x867 (= v_1_cc_before_window v_0_snd_wnd)))
 (let (($x865 (= v_1_cc_before_persist v_0_persist_active)))
 (let (($x863 (= v_1_cc_before_una v_0_snd_una)))
 (let (($x862 (= v_1_cc_before_flight v_0_rtx_buf)))
 (let (($x858 (= v_1_cc_ca_credit v_0_cc_ca_credit)))
 (let (($x855 (= v_1_cc_ssthresh v_0_cc_ssthresh)))
 (let (($x852 (= v_1_cc_cwnd v_0_cc_cwnd)))
 (let (($x849 (= v_1_cc_initial_threshold v_0_cc_initial_threshold)))
 (let (($x846 (= v_1_cc_initial_window v_0_cc_initial_window)))
 (let (($x843 (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)))
 (let (($x836 (= v_1_persist_deadline_ms (ite $x613 (ite $x803 ?x832 v_0_persist_deadline_ms) 0))))
 (let (($x826 (= v_1_persist_since_ms (ite $x613 (ite $x803 now_1 v_0_persist_since_ms) 0))))
 (let (($x821 (= v_1_persist_previous_interval_ms v_0_persist_previous_interval_ms)))
 (let (($x812 (not v_1_persist_probe_new)))
 (let (($x810 (not v_1_persist_probe_sent)))
 (let (($x808 (not v_1_persist_first)))
 (let (($x806 (= v_1_persist_was_active v_0_persist_active)))
 (let (($x796 (not v_1_ack_defer_now)))
 (let (($x794 (not v_1_ack_defer_candidate)))
 (let (($x792 (= v_1_ack_rmss v_0_ack_rmss)))
 (let (($x789 (= v_1_ack_delay_ms v_0_ack_delay_ms)))
 (let (($x786 (= v_1_ack_full_segments v_0_ack_full_segments)))
 (let (($x783 (= v_1_ack_bytes v_0_ack_bytes)))
 (let (($x780 (= v_1_ack_since_ms v_0_ack_since_ms)))
 (let (($x777 (= v_1_ack_pending v_0_ack_pending)))
 (let (($x774 (not v_1_syn_timeout_eligible)))
 (let (($x772 (not v_1_tx_syn_pending)))
 (let (($x770 (= v_1_tx_syn_time 0)))
 (let (($x768 (not v_1_tx_waiting)))
 (let (($x766 (= v_1_tx_is_fin v_0_tx_is_fin)))
 (let (($x763 (= v_1_tx_previous_rto v_0_tx_previous_rto)))
 (let (($x760 (= v_1_tx_elapsed v_0_tx_elapsed)))
 (let (($x757 (not v_1_tx_retransmitted)))
 (let (($x755 (= v_1_tx_max_previous v_0_tx_max_previous)))
 (let (($x752 (= v_1_tx_eligible v_0_tx_eligible)))
 (let (($x749 (= v_1_tx_emit_count v_0_tx_emit_count)))
 (let ((?x745 (ite (and v_0_fin_sent (not v_0_fin_acknowledged)) v_0_tx_fin_time 0)))
 (let (($x746 (= v_1_tx_fin_time ?x745)))
 (let (($x740 (= v_1_tx_time_15 (ite (>= 15 v_0_rtx_buf) 0 v_0_tx_time_15))))
 (let (($x734 (= v_1_tx_time_14 (ite (>= 14 v_0_rtx_buf) 0 v_0_tx_time_14))))
 (let (($x728 (= v_1_tx_time_13 (ite (>= 13 v_0_rtx_buf) 0 v_0_tx_time_13))))
 (let (($x722 (= v_1_tx_time_12 (ite (>= 12 v_0_rtx_buf) 0 v_0_tx_time_12))))
 (let (($x716 (= v_1_tx_time_11 (ite (>= 11 v_0_rtx_buf) 0 v_0_tx_time_11))))
 (let (($x710 (= v_1_tx_time_10 (ite (>= 10 v_0_rtx_buf) 0 v_0_tx_time_10))))
 (let (($x704 (= v_1_tx_time_09 (ite (>= 9 v_0_rtx_buf) 0 v_0_tx_time_09))))
 (let (($x698 (= v_1_tx_time_08 (ite (>= 8 v_0_rtx_buf) 0 v_0_tx_time_08))))
 (let (($x692 (= v_1_tx_time_07 (ite (>= 7 v_0_rtx_buf) 0 v_0_tx_time_07))))
 (let (($x686 (= v_1_tx_time_06 (ite (>= 6 v_0_rtx_buf) 0 v_0_tx_time_06))))
 (let (($x680 (= v_1_tx_time_05 (ite (>= 5 v_0_rtx_buf) 0 v_0_tx_time_05))))
 (let (($x674 (= v_1_tx_time_04 (ite (>= 4 v_0_rtx_buf) 0 v_0_tx_time_04))))
 (let (($x668 (= v_1_tx_time_03 (ite (>= 3 v_0_rtx_buf) 0 v_0_tx_time_03))))
 (let (($x662 (= v_1_tx_time_02 (ite (>= 2 v_0_rtx_buf) 0 v_0_tx_time_02))))
 (let (($x652 (= v_1_tx_time_00 (ite (>= 0 v_0_rtx_buf) 0 v_0_tx_time_00))))
 (let (($x647 (= v_1_rto_base_ms v_0_rto_base_ms)))
 (let (($x644 (= v_1_rtt_samples v_0_rtt_samples)))
 (let (($x641 (= v_1_rtt_last_ms v_0_rtt_last_ms)))
 (let (($x638 (not v_1_rtt_sample_was_ambiguous)))
 (let (($x636 (not v_1_rtt_sample_used)))
 (let (($x634 (not v_1_rtt_start_new)))
 (let (($x628 (= v_1_rtt_end v_0_rtt_end)))
 (let (($x627 (= v_1_rtt_start_ms v_0_rtt_start_ms)))
 (let (($x624 (= v_1_rtt_sample_at_ms v_0_rtt_sample_at_ms)))
 (let (($x603 (= v_1_rtt_previous_measured v_0_rtt_previous_measured)))
 (let (($x600 (= v_1_rtt_measured v_0_rtt_measured)))
 (let (($x597 (= v_1_rtt_previous_var v_0_rtt_previous_var)))
 (let (($x594 (= v_1_rtt_previous_srtt v_0_rtt_previous_srtt)))
 (let (($x591 (= v_1_rtt_error_ms v_0_rtt_error_ms)))
 (let (($x588 (= v_1_rttvar_ms v_0_rttvar_ms)))
 (let (($x585 (= v_1_srtt_ms v_0_srtt_ms)))
 (let (($x582 (= v_1_rx_fin_consumed v_0_rx_fin_consumed)))
 (let (($x579 (= v_1_rx_fin_done v_0_rx_fin_done)))
 (let (($x576 (= v_1_rx_fin_offset v_0_rx_fin_offset)))
 (let (($x573 (= v_1_rx_fin_seq v_0_rx_fin_seq)))
 (let (($x572 (= v_1_rx_fin_pending v_0_rx_fin_pending)))
 (let (($x569 (= v_1_fin_acknowledged v_0_fin_acknowledged)))
 (let (($x566 (= v_1_fin_seq v_0_fin_seq)))
 (let (($x565 (= v_1_fin_sent v_0_fin_sent)))
 (let (($x562 (= v_1_fin_requested v_0_fin_requested)))
 (let (($x560 (= v_1_ack_window_update v_0_ack_window_update)))
 (let (($x557 (= v_1_ack_advance v_0_ack_advance)))
 (let (($x554 (= v_1_ack_is_future v_0_ack_is_future)))
 (let (($x551 (= v_1_ack_is_new v_0_ack_is_new)))
 (let (($x548 (= v_1_ack_delta v_0_ack_delta)))
 (let (($x545 (= v_1_seg_acceptable v_0_seg_acceptable)))
 (let (($x542 (= v_1_rx_acceptable v_0_rx_acceptable)))
 (let (($x539 (= v_1_rx_advance v_0_rx_advance)))
 (let (($x536 (= v_1_rx_slot_15 v_0_rx_slot_15)))
 (let (($x535 (= v_1_rx_slot_14 v_0_rx_slot_14)))
 (let (($x534 (= v_1_rx_slot_13 v_0_rx_slot_13)))
 (let (($x533 (= v_1_rx_slot_12 v_0_rx_slot_12)))
 (let (($x532 (= v_1_rx_slot_11 v_0_rx_slot_11)))
 (let (($x531 (= v_1_rx_slot_10 v_0_rx_slot_10)))
 (let (($x530 (= v_1_rx_slot_09 v_0_rx_slot_09)))
 (let (($x529 (= v_1_rx_slot_08 v_0_rx_slot_08)))
 (let (($x528 (= v_1_rx_slot_07 v_0_rx_slot_07)))
 (let (($x527 (= v_1_rx_slot_06 v_0_rx_slot_06)))
 (let (($x526 (= v_1_rx_slot_05 v_0_rx_slot_05)))
 (let (($x525 (= v_1_rx_slot_04 v_0_rx_slot_04)))
 (let (($x524 (= v_1_rx_slot_03 v_0_rx_slot_03)))
 (let (($x523 (= v_1_rx_slot_02 v_0_rx_slot_02)))
 (let (($x522 (= v_1_rx_slot_01 v_0_rx_slot_01)))
 (let (($x521 (= v_1_rx_slot_00 v_0_rx_slot_00)))
 (let (($x520 (= v_1_rx_chunk v_0_rx_chunk)))
 (let (($x519 (= v_1_take v_0_take)))
 (let (($x516 (= v_1_snd_wl2 v_0_snd_wl2)))
 (let (($x515 (= v_1_snd_wl1 v_0_snd_wl1)))
 (let (($x514 (= v_1_snd_wnd v_0_snd_wnd)))
 (let (($x511 (= v_1_rcv_buf v_0_rcv_buf)))
 (let (($x510 (= v_1_rtx_buf v_0_rtx_buf)))
 (let (($x507 (= v_1_local_window v_0_local_window)))
 (let (($x504 (= v_1_msl_ms v_0_msl_ms)))
 (let (($x501 (= v_1_user_timeout_ms v_0_user_timeout_ms)))
 (let (($x498 (= v_1_active_open v_0_active_open)))
 (let (($x495 (= v_1_retries v_0_retries)))
 (let (($x492 (= v_1_rto_ms v_0_rto_ms)))
 (let (($x489 (= v_1_tx_flags v_0_tx_flags)))
 (let (($x486 (= v_1_tx_ack v_0_tx_ack)))
 (let (($x485 (= v_1_tx_seq v_0_tx_seq)))
 (let (($x484 (= v_1_rcv_nxt v_0_rcv_nxt)))
 (let (($x483 (= v_1_snd_nxt v_0_snd_nxt)))
 (let (($x482 (= v_1_snd_una v_0_snd_una)))
 (let (($x481 (= v_1_irs v_0_irs)))
 (let (($x480 (= v_1_iss v_0_iss)))
 (let (($x459 (not v_0_fin_requested)))
 (and (>= now_1 now_0) $x459 (<= 1 input_0_app.send_data) (>= 16 (+ v_0_snd_buf v_0_rtx_buf input_0_app.send_data)) (or (not active_0_rtx) (not (<= due_0_rtx now_1))) (or (not active_0_user) (not (<= due_0_user now_1))) (or (not active_0_time_wait) (not (<= due_0_time_wait now_1))) (or (not active_0_delack) (not (<= due_0_delack now_1))) (or (not active_0_persist) (not (<= due_0_persist now_1))) $x480 $x481 $x482 $x483 $x484 $x485 $x486 $x489 $x492 $x495 $x498 $x501 $x504 $x507 (= v_1_snd_buf (+ v_0_snd_buf input_0_app.send_data)) $x510 $x511 $x514 $x515 $x516 $x519 $x520 $x521 $x522 $x523 $x524 $x525 $x526 $x527 $x528 $x529 $x530 $x531 $x532 $x533 $x534 $x535 $x536 $x539 $x542 $x545 $x548 $x551 $x554 $x557 $x560 $x562 $x565 $x566 $x569 $x572 $x573 $x576 $x579 $x582 $x585 $x588 $x591 $x594 $x597 $x600 $x603 (= v_1_rtt_active (and $x614 v_0_rtt_active)) (= v_1_rtt_ambiguous (and $x614 v_0_rtt_ambiguous)) $x624 $x627 $x628 (= v_1_rtt_remaining (ite $x613 0 v_0_rtt_remaining)) $x634 $x636 $x638 $x641 $x644 $x647 $x652 (= v_1_tx_time_01 (ite $x609 0 v_0_tx_time_01)) $x662 $x668 $x674 $x680 $x686 $x692 $x698 $x704 $x710 $x716 $x722 $x728 $x734 $x740 $x746 $x749 $x752 $x755 $x757 $x760 $x763 $x766 $x768 $x770 $x772 $x774 $x777 $x780 $x783 $x786 $x789 $x792 $x794 $x796 (= v_1_persist_active $x613) (= v_1_persist_eligible $x613) (= v_1_persist_start $x803) $x806 $x808 $x810 $x812 (= v_1_persist_interval_ms (ite $x613 ?x815 1000)) $x821 $x826 (= v_1_persist_last_ms (ite $x613 v_0_persist_last_ms 0)) $x836 (= v_1_persist_probes (ite $x613 v_0_persist_probes 0)) $x843 $x846 $x849 $x852 $x855 $x858 (= 0 v_1_cc_acked) $x862 $x863 $x865 $x867 $x869 $x871 $x874 (= 0 v_1_cc_growth) $x878 (= v_1_cc_send_budget (ite (<= 0 ?x884) ?x884 0)) (= 0 v_1_cc_new_sent) (= v_1_cc_rto_00 (and (not (>= 0 v_0_rtx_buf)) v_0_cc_rto_00)) (= v_1_cc_rto_01 (and (not $x609) v_0_cc_rto_01)) (= v_1_cc_rto_02 (and (not (>= 2 v_0_rtx_buf)) v_0_cc_rto_02)) (= v_1_cc_rto_03 (and (not (>= 3 v_0_rtx_buf)) v_0_cc_rto_03)) (= v_1_cc_rto_04 (and (not (>= 4 v_0_rtx_buf)) v_0_cc_rto_04)) (= v_1_cc_rto_05 (and (not (>= 5 v_0_rtx_buf)) v_0_cc_rto_05)) (= v_1_cc_rto_06 (and (not (>= 6 v_0_rtx_buf)) v_0_cc_rto_06)) (= v_1_cc_rto_07 (and (not (>= 7 v_0_rtx_buf)) v_0_cc_rto_07)) (= v_1_cc_rto_08 (and (not (>= 8 v_0_rtx_buf)) v_0_cc_rto_08)) (= v_1_cc_rto_09 (and (not (>= 9 v_0_rtx_buf)) v_0_cc_rto_09)) (= v_1_cc_rto_10 (and (not (>= 10 v_0_rtx_buf)) v_0_cc_rto_10)) (= v_1_cc_rto_11 (and (not (>= 11 v_0_rtx_buf)) v_0_cc_rto_11)) (= v_1_cc_rto_12 (and (not (>= 12 v_0_rtx_buf)) v_0_cc_rto_12)) (= v_1_cc_rto_13 (and (not (>= 13 v_0_rtx_buf)) v_0_cc_rto_13)) (= v_1_cc_rto_14 (and (not (>= 14 v_0_rtx_buf)) v_0_cc_rto_14)) (= v_1_cc_rto_15 (and (not (>= 15 v_0_rtx_buf)) v_0_cc_rto_15)) $x971 $x974 $x977 (= v_1_fr_active (and (not (or $x611 $x613)) v_0_fr_active)) (= v_1_fr_dupacks (ite (or $x611 $x613) 0 v_0_fr_dupacks)) $x989 $x991 $x993 $x994 $x995 $x997 $x999 $x1001 $x1003 $x1005 $x1007 $x1009 $x1011 $x1013 $x1016 $x1019 $x1022 $x1024 $x1026 $x1028 (= v_1_idle_elapsed_ms ?x1032) $x1035 $x1037 $x1039 $x1042 $x1044 $x1046 (= 0 v_1_lt_take) (= v_1_lt_epoch_bytes (ite (or $x611 $x613) 0 v_0_lt_epoch_bytes)) $x1056 $x1058 $x1060 $x1061 $x1063 $x1065 (= v_1_lt_loss_flight (+ v_0_rtx_buf (* ?x882 v_0_lt_epoch_bytes))) $x1071 $x1074 $x1077 $x1078 $x1081 $x1083 $x1086 (= 0 v_1_sched_cause) (= 0 v_1_sched_bytes) (= 0 v_1_sched_packets) (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf)) (= v_1_svc_accept_step ?x1098) (= 0 v_1_svc_ack_step) (= v_1_svc_drop_step ?x1106) (= v_1_svc_written_bytes (+ v_0_svc_written_bytes ?x1098)) $x1114 (= v_1_svc_abandoned_bytes (+ v_0_svc_abandoned_bytes ?x1106)) (= v_1_cb_head ?x1126) (= v_1_cb_tail (ite (<= 16 ?x1130) (+ (- 16) ?x1130) ?x1130)) (= v_1_cb_count (ite $x1120 0 v_0_cb_count)) $x1140 $x1142 $x1144 $x1146 (= v_1_cb_live_total ?x1180) (= v_1_cb_partial_prefix ?x1183) $x1187 $x1190 (= v_1_cb_abandoned_total (+ v_0_cb_abandoned_total ?x1194)) (= v_1_cb_drop_step ?x1194) $x1199 $x1200 $x1202 (= v_1_cb_length_00 ?x1149) (= v_1_cb_end_00 (ite $x1120 0 v_0_cb_end_00)) $x1208 (= v_1_cb_length_01 ?x1151) (= v_1_cb_end_01 (ite $x1120 0 v_0_cb_end_01)) $x1214 (= v_1_cb_length_02 ?x1153) (= v_1_cb_end_02 (ite $x1120 0 v_0_cb_end_02)) $x1220 (= v_1_cb_length_03 ?x1155) (= v_1_cb_end_03 (ite $x1120 0 v_0_cb_end_03)) $x1226 (= v_1_cb_length_04 ?x1157) (= v_1_cb_end_04 (ite $x1120 0 v_0_cb_end_04)) $x1232 (= v_1_cb_length_05 ?x1159) (= v_1_cb_end_05 (ite $x1120 0 v_0_cb_end_05)) $x1238 (= v_1_cb_length_06 ?x1161) (= v_1_cb_end_06 (ite $x1120 0 v_0_cb_end_06)) $x1244 (= v_1_cb_length_07 ?x1163) (= v_1_cb_end_07 (ite $x1120 0 v_0_cb_end_07)) $x1250 (= v_1_cb_length_08 ?x1165) (= v_1_cb_end_08 (ite $x1120 0 v_0_cb_end_08)) $x1256 (= v_1_cb_length_09 ?x1167) (= v_1_cb_end_09 (ite $x1120 0 v_0_cb_end_09)) $x1262 (= v_1_cb_length_10 ?x1169) (= v_1_cb_end_10 (ite $x1120 0 v_0_cb_end_10)) $x1268 (= v_1_cb_length_11 ?x1171) (= v_1_cb_end_11 (ite $x1120 0 v_0_cb_end_11)) $x1274 (= v_1_cb_length_12 ?x1173) (= v_1_cb_end_12 (ite $x1120 0 v_0_cb_end_12)) $x1280 (= v_1_cb_length_13 ?x1175) (= v_1_cb_end_13 (ite $x1120 0 v_0_cb_end_13)) $x1286 (= v_1_cb_length_14 ?x1177) (= v_1_cb_end_14 (ite $x1120 0 v_0_cb_end_14)) $x1292 (= v_1_cb_length_15 ?x1179) (= v_1_cb_end_15 (ite $x1120 0 v_0_cb_end_15)) $x1298 (= active_1_rtx (or $x1303 (and $x614 active_0_rtx))) $x1307 $x1309 $x1311 $x1315 (= due_1_rtx (ite $x1303 ?x1317 due_0_rtx)) $x1321 $x1323 $x1325 (= due_1_persist (ite $x803 ?x832 due_0_persist))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_user))
(assert
 (not active_0_time_wait))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (<= 1000 v_0_rto_ms))
(assert
 (<= 0 v_0_retries))
(assert
 (<= 1 v_0_msl_ms))
(assert
 (<= 1 v_0_user_timeout_ms))
(assert
 true)
(assert
 (let ((?x1094 (+ v_0_snd_buf v_0_rtx_buf)))
 (>= 16 ?x1094)))
(assert
 (>= 16 v_0_rcv_buf))
(assert
 (and (<= 0 v_0_snd_wnd) (>= 65535 v_0_snd_wnd)))
(assert
 (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf))))
(assert
 (>= 1 v_0_rx_slot_00))
(assert
 (let (($x1346 (= 0 v_0_rx_slot_00)))
 (let (($x1345 (not (>= v_0_rcv_buf 16))))
 (or $x1345 $x1346))))
(assert
 (>= 1 v_0_rx_slot_01))
(assert
 (let (($x1351 (= 0 v_0_rx_slot_01)))
 (let (($x1350 (not (>= v_0_rcv_buf 15))))
 (or $x1350 $x1351))))
(assert
 (>= 1 v_0_rx_slot_02))
(assert
 (let (($x1356 (= 0 v_0_rx_slot_02)))
 (let (($x1355 (not (>= v_0_rcv_buf 14))))
 (or $x1355 $x1356))))
(assert
 (>= 1 v_0_rx_slot_03))
(assert
 (let (($x1361 (= 0 v_0_rx_slot_03)))
 (let (($x1360 (not (>= v_0_rcv_buf 13))))
 (or $x1360 $x1361))))
(assert
 (>= 1 v_0_rx_slot_04))
(assert
 (let (($x1366 (= 0 v_0_rx_slot_04)))
 (let (($x1365 (not (>= v_0_rcv_buf 12))))
 (or $x1365 $x1366))))
(assert
 (>= 1 v_0_rx_slot_05))
(assert
 (let (($x1371 (= 0 v_0_rx_slot_05)))
 (let (($x1370 (not (>= v_0_rcv_buf 11))))
 (or $x1370 $x1371))))
(assert
 (>= 1 v_0_rx_slot_06))
(assert
 (let (($x1376 (= 0 v_0_rx_slot_06)))
 (let (($x1375 (not (>= v_0_rcv_buf 10))))
 (or $x1375 $x1376))))
(assert
 (>= 1 v_0_rx_slot_07))
(assert
 (let (($x1381 (= 0 v_0_rx_slot_07)))
 (let (($x1380 (not (>= v_0_rcv_buf 9))))
 (or $x1380 $x1381))))
(assert
 (>= 1 v_0_rx_slot_08))
(assert
 (let (($x1386 (= 0 v_0_rx_slot_08)))
 (let (($x1385 (not (>= v_0_rcv_buf 8))))
 (or $x1385 $x1386))))
(assert
 (>= 1 v_0_rx_slot_09))
(assert
 (let (($x1391 (= 0 v_0_rx_slot_09)))
 (let (($x1390 (not (>= v_0_rcv_buf 7))))
 (or $x1390 $x1391))))
(assert
 (>= 1 v_0_rx_slot_10))
(assert
 (let (($x1396 (= 0 v_0_rx_slot_10)))
 (let (($x1395 (not (>= v_0_rcv_buf 6))))
 (or $x1395 $x1396))))
(assert
 (>= 1 v_0_rx_slot_11))
(assert
 (let (($x1401 (= 0 v_0_rx_slot_11)))
 (let (($x1400 (not (>= v_0_rcv_buf 5))))
 (or $x1400 $x1401))))
(assert
 (>= 1 v_0_rx_slot_12))
(assert
 (let (($x1406 (= 0 v_0_rx_slot_12)))
 (let (($x1405 (not (>= v_0_rcv_buf 4))))
 (or $x1405 $x1406))))
(assert
 (>= 1 v_0_rx_slot_13))
(assert
 (let (($x1411 (= 0 v_0_rx_slot_13)))
 (let (($x1410 (not (>= v_0_rcv_buf 3))))
 (or $x1410 $x1411))))
(assert
 (>= 1 v_0_rx_slot_14))
(assert
 (let (($x1416 (= 0 v_0_rx_slot_14)))
 (let (($x1415 (not (>= v_0_rcv_buf 2))))
 (or $x1415 $x1416))))
(assert
 (>= 1 v_0_rx_slot_15))
(assert
 (let (($x1421 (= 0 v_0_rx_slot_15)))
 (let (($x1420 (not (>= v_0_rcv_buf 1))))
 (or $x1420 $x1421))))
(assert
 (= 0 v_0_rx_slot_00))
(assert
 (let ((?x1423 (+ v_0_rcv_buf v_0_rx_slot_00 v_0_rx_slot_01 v_0_rx_slot_02 v_0_rx_slot_03 v_0_rx_slot_04 v_0_rx_slot_05 v_0_rx_slot_06 v_0_rx_slot_07 v_0_rx_slot_08 v_0_rx_slot_09 v_0_rx_slot_10 v_0_rx_slot_11 v_0_rx_slot_12 v_0_rx_slot_13 v_0_rx_slot_14 v_0_rx_slot_15)))
 (>= 16 ?x1423)))
(assert
 (and (<= 0 v_0_rx_advance) (>= 16 v_0_rx_advance)))
(assert
 (= v_0_rx_chunk v_0_rx_advance))
(assert
 (and (<= 0 v_0_ack_delta) (>= 4294967295 v_0_ack_delta)))
(assert
 true)
(assert
 (let ((?x1435 (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)) 4294967296)))
 (= v_0_snd_nxt ?x1435)))
(assert
 (not v_0_fin_sent))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x1421 (= 0 v_0_rx_slot_15)))
 (let (($x1416 (= 0 v_0_rx_slot_14)))
 (let (($x1411 (= 0 v_0_rx_slot_13)))
 (let (($x1406 (= 0 v_0_rx_slot_12)))
 (let (($x1401 (= 0 v_0_rx_slot_11)))
 (let (($x1396 (= 0 v_0_rx_slot_10)))
 (let (($x1391 (= 0 v_0_rx_slot_09)))
 (let (($x1386 (= 0 v_0_rx_slot_08)))
 (let (($x1381 (= 0 v_0_rx_slot_07)))
 (let (($x1376 (= 0 v_0_rx_slot_06)))
 (let (($x1371 (= 0 v_0_rx_slot_05)))
 (let (($x1366 (= 0 v_0_rx_slot_04)))
 (let (($x1361 (= 0 v_0_rx_slot_03)))
 (let (($x1356 (= 0 v_0_rx_slot_02)))
 (let (($x1351 (= 0 v_0_rx_slot_01)))
 (let (($x1346 (= 0 v_0_rx_slot_00)))
 (and $x1346 $x1351 $x1356 $x1361 $x1366 $x1371 $x1376 $x1381 $x1386 $x1391 $x1396 $x1401 $x1406 $x1411 $x1416 $x1421))))))))))))))))))
(assert
 v_0_rx_fin_done)
(assert
 (not v_0_rx_fin_pending))
(assert
 (let (($x1440 (>= 15 v_0_rx_fin_offset)))
 (and (<= 0 v_0_rx_fin_offset) $x1440 (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset)))))
(assert
 (let (($x1438 (not v_0_rx_fin_pending)))
 (or $x1438 (= v_0_rx_fin_seq (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)))))
(assert
 (let (($x1448 (not v_0_rx_fin_done)))
 (or $x1448 (= v_0_rcv_nxt (mod (+ 1 v_0_rx_fin_seq) 4294967296)))))
(assert
 (let (($x1346 (= 0 v_0_rx_slot_00)))
 (or (not (and v_0_rx_fin_pending (>= 0 v_0_rx_fin_offset))) $x1346)))
(assert
 (let (($x1351 (= 0 v_0_rx_slot_01)))
 (or (not (and v_0_rx_fin_pending (>= 1 v_0_rx_fin_offset))) $x1351)))
(assert
 (let (($x1356 (= 0 v_0_rx_slot_02)))
 (or (not (and v_0_rx_fin_pending (>= 2 v_0_rx_fin_offset))) $x1356)))
(assert
 (let (($x1361 (= 0 v_0_rx_slot_03)))
 (or (not (and v_0_rx_fin_pending (>= 3 v_0_rx_fin_offset))) $x1361)))
(assert
 (let (($x1366 (= 0 v_0_rx_slot_04)))
 (or (not (and v_0_rx_fin_pending (>= 4 v_0_rx_fin_offset))) $x1366)))
(assert
 (let (($x1371 (= 0 v_0_rx_slot_05)))
 (or (not (and v_0_rx_fin_pending (>= 5 v_0_rx_fin_offset))) $x1371)))
(assert
 (let (($x1376 (= 0 v_0_rx_slot_06)))
 (or (not (and v_0_rx_fin_pending (>= 6 v_0_rx_fin_offset))) $x1376)))
(assert
 (let (($x1381 (= 0 v_0_rx_slot_07)))
 (or (not (and v_0_rx_fin_pending (>= 7 v_0_rx_fin_offset))) $x1381)))
(assert
 (let (($x1386 (= 0 v_0_rx_slot_08)))
 (or (not (and v_0_rx_fin_pending (>= 8 v_0_rx_fin_offset))) $x1386)))
(assert
 (let (($x1391 (= 0 v_0_rx_slot_09)))
 (or (not (and v_0_rx_fin_pending (>= 9 v_0_rx_fin_offset))) $x1391)))
(assert
 (let (($x1396 (= 0 v_0_rx_slot_10)))
 (or (not (and v_0_rx_fin_pending (>= 10 v_0_rx_fin_offset))) $x1396)))
(assert
 (let (($x1401 (= 0 v_0_rx_slot_11)))
 (or (not (and v_0_rx_fin_pending (>= 11 v_0_rx_fin_offset))) $x1401)))
(assert
 (let (($x1406 (= 0 v_0_rx_slot_12)))
 (or (not (and v_0_rx_fin_pending (>= 12 v_0_rx_fin_offset))) $x1406)))
(assert
 (let (($x1411 (= 0 v_0_rx_slot_13)))
 (or (not (and v_0_rx_fin_pending (>= 13 v_0_rx_fin_offset))) $x1411)))
(assert
 (let (($x1416 (= 0 v_0_rx_slot_14)))
 (or (not (and v_0_rx_fin_pending (>= 14 v_0_rx_fin_offset))) $x1416)))
(assert
 (let (($x1421 (= 0 v_0_rx_slot_15)))
 (or (not (and v_0_rx_fin_pending (>= 15 v_0_rx_fin_offset))) $x1421)))
(assert
 (<= 0.0 v_0_srtt_ms))
(assert
 (<= 0.0 v_0_rttvar_ms))
(assert
 (<= 0.0 v_0_rtt_error_ms))
(assert
 (<= 0.0 v_0_rtt_previous_srtt))
(assert
 (<= 0.0 v_0_rtt_previous_var))
(assert
 (<= 0 v_0_rtt_start_ms))
(assert
 (<= 0 v_0_rtt_last_ms))
(assert
 (<= 0 v_0_rtt_samples))
(assert
 (and (<= 1000 v_0_rto_base_ms) (>= 60000 v_0_rto_base_ms) (>= v_0_rto_ms v_0_rto_base_ms) (>= 60000 v_0_rto_ms)))
(assert
 (let ((?x1537 (* 4.0 v_0_rttvar_ms)))
 (let ((?x1532 (- 1.0)))
 (let ((?x1540 (+ (* ?x1532 v_0_srtt_ms) (* ?x1532 (ite (<= v_0_rttvar_ms (/ 1.0 4.0)) 1.0 ?x1537)))))
 (let ((?x1541 (to_int ?x1540)))
 (let ((?x882 (- 1)))
 (let ((?x1545 (ite (<= ?x1541 (- 1000)) (* ?x882 ?x1541) 1000)))
 (= v_0_rto_base_ms (ite v_0_rtt_measured (ite (<= 60000 ?x1545) 60000 ?x1545) 1000)))))))))
(assert
 (= v_0_rtt_measured (<= 1 v_0_rtt_samples)))
(assert
 (let ((?x1558 (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296)))
 (let (($x1563 (and (<= v_0_rtt_start_ms now_0) (<= 1 v_0_rtt_remaining) (>= 4 v_0_rtt_remaining) (>= ?x1558 v_0_rtt_remaining) (<= ?x1558 (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296)))))
 (let (($x1552 (not v_0_rtt_active)))
 (or $x1552 $x1563)))))
(assert
 (let (($x1565 (= 0 v_0_rtt_remaining)))
 (or v_0_rtt_active $x1565)))
(assert
 true)
(assert
 (let (($x1573 (= v_0_rtt_last_ms (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms)))))
 (let (($x1570 (not v_0_rtt_sample_was_ambiguous)))
 (let (($x1568 (not v_0_rtt_sample_used)))
 (or $x1568 (and $x1570 v_0_rtt_measured $x1573))))))
(assert
 (and (<= 0 v_0_rtt_sample_at_ms) (<= v_0_rtt_sample_at_ms now_0)))
(assert
 (let ((?x1582 (to_real v_0_rtt_last_ms)))
 (let ((?x1602 (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt) (* (/ 1.0 8.0) ?x1582))))
 (let ((?x1584 (+ v_0_rtt_previous_srtt (* (- 1.0) ?x1582))))
 (let ((?x1588 (ite (>= ?x1584 0.0) ?x1584 (+ (* (- 1.0) v_0_rtt_previous_srtt) ?x1582))))
 (let ((?x1535 (/ 1.0 4.0)))
 (let ((?x1594 (ite v_0_rtt_previous_measured (+ (* (/ 3.0 4.0) v_0_rtt_previous_var) (* ?x1535 ?x1588)) (* (/ 1.0 2.0) ?x1582))))
 (let (($x1605 (and (= v_0_rttvar_ms ?x1594) (= v_0_srtt_ms (ite v_0_rtt_previous_measured ?x1602 ?x1582)))))
 (let (($x1568 (not v_0_rtt_sample_used)))
 (or $x1568 $x1605))))))))))
(assert
 (and (<= 0 v_0_tx_time_00) (<= v_0_tx_time_00 now_0) (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00))))
(assert
 (and (<= 0 v_0_tx_time_01) (<= v_0_tx_time_01 now_0) (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))))
(assert
 (and (<= 0 v_0_tx_time_02) (<= v_0_tx_time_02 now_0) (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))))
(assert
 (and (<= 0 v_0_tx_time_03) (<= v_0_tx_time_03 now_0) (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))))
(assert
 (and (<= 0 v_0_tx_time_04) (<= v_0_tx_time_04 now_0) (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))))
(assert
 (and (<= 0 v_0_tx_time_05) (<= v_0_tx_time_05 now_0) (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))))
(assert
 (and (<= 0 v_0_tx_time_06) (<= v_0_tx_time_06 now_0) (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))))
(assert
 (and (<= 0 v_0_tx_time_07) (<= v_0_tx_time_07 now_0) (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))))
(assert
 (and (<= 0 v_0_tx_time_08) (<= v_0_tx_time_08 now_0) (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))))
(assert
 (and (<= 0 v_0_tx_time_09) (<= v_0_tx_time_09 now_0) (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))))
(assert
 (and (<= 0 v_0_tx_time_10) (<= v_0_tx_time_10 now_0) (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))))
(assert
 (and (<= 0 v_0_tx_time_11) (<= v_0_tx_time_11 now_0) (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))))
(assert
 (and (<= 0 v_0_tx_time_12) (<= v_0_tx_time_12 now_0) (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))))
(assert
 (and (<= 0 v_0_tx_time_13) (<= v_0_tx_time_13 now_0) (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))))
(assert
 (and (<= 0 v_0_tx_time_14) (<= v_0_tx_time_14 now_0) (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))))
(assert
 (and (<= 0 v_0_tx_time_15) (<= v_0_tx_time_15 now_0) (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))))
(assert
 (and (<= 0 v_0_tx_fin_time) (<= v_0_tx_fin_time now_0)))
(assert
 (and (<= 0 v_0_tx_emit_count) (>= 4 v_0_tx_emit_count)))
(assert
 (and (<= 0 v_0_tx_eligible) (>= 4 v_0_tx_eligible)))
(assert
 (and (<= 0 v_0_tx_elapsed) (<= 0 v_0_tx_max_previous) (<= v_0_tx_max_previous now_0) (<= 1000 v_0_tx_previous_rto) (>= 60000 v_0_tx_previous_rto)))
(assert
 (let (($x1709 (and (>= v_0_tx_elapsed v_0_tx_previous_rto) (<= 1 v_0_tx_emit_count) (or (not v_0_tx_is_fin) (= 1 v_0_tx_emit_count)))))
 (let (($x1703 (not v_0_tx_retransmitted)))
 (or $x1703 $x1709))))
(assert
 (let (($x1703 (not v_0_tx_retransmitted)))
 (or $x1703 (not v_0_tx_waiting))))
(assert
 (and (<= 0 v_0_tx_syn_time) (<= v_0_tx_syn_time now_0)))
(assert
 (not v_0_tx_syn_pending))
(assert
 (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time)))
(assert
 true)
(assert
 (and (<= 1 v_0_ack_delay_ms) (>= 499 v_0_ack_delay_ms) (= 4 v_0_ack_rmss)))
(assert
 (= v_0_ack_pending active_0_delack))
(assert
 (and (<= 0 v_0_ack_bytes) (>= 7 v_0_ack_bytes) (<= 0 v_0_ack_full_segments) (>= 1 v_0_ack_full_segments)))
(assert
 (and (<= 0 v_0_ack_since_ms) (<= v_0_ack_since_ms now_0)))
(assert
 (not v_0_ack_pending))
(assert
 (let (($x1740 (and (= 0 v_0_ack_bytes) (= 0 v_0_ack_full_segments) (= 0 v_0_ack_since_ms))))
 (or v_0_ack_pending $x1740)))
(assert
 (let (($x370 (not active_0_rtx)))
 (let (($x609 (>= 1 v_0_rtx_buf)))
 (let (($x606 (not v_0_fin_sent)))
 (let (($x605 (= 0 v_0_snd_wnd)))
 (let (($x802 (not v_0_persist_active)))
 (let (($x1750 (or $x802 (and $x605 $x606 (<= 1 (+ v_0_rtx_buf v_0_snd_buf)) $x609 $x370))))
 (let (($x1745 (and (<= 1 (+ v_0_rtx_buf (ite v_0_fin_sent 1 0))) $x802)))
 (let (($x1742 (= v_0_persist_active active_0_persist)))
 (and $x1742 (= active_0_rtx $x1745) $x1750))))))))))
(assert
 (let (($x802 (not v_0_persist_active)))
 (or $x802 (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))))
(assert
 (and (<= 1000 v_0_persist_interval_ms) (>= 60000 v_0_persist_interval_ms) (<= 1000 v_0_persist_previous_interval_ms) (>= 60000 v_0_persist_previous_interval_ms) (<= 0 v_0_persist_probes) (<= 0 v_0_persist_elapsed_ms)))
(assert
 (and (<= 0 v_0_persist_since_ms) (<= v_0_persist_since_ms now_0) (<= 0 v_0_persist_last_ms) (<= v_0_persist_last_ms now_0) (<= 0 v_0_persist_deadline_ms)))
(assert
 (let (($x1767 (= 0 v_0_persist_probes)))
 (let ((?x1769 (+ (ite $x1767 v_0_persist_since_ms v_0_persist_last_ms) v_0_persist_interval_ms)))
 (let (($x802 (not v_0_persist_active)))
 (or $x802 (= v_0_persist_deadline_ms ?x1769))))))
(assert
 (let (($x1775 (= 1 v_0_rtx_buf)))
 (let (($x1773 (not v_0_persist_probe_sent)))
 (or $x1773 (and (>= v_0_persist_elapsed_ms v_0_persist_previous_interval_ms) $x1775)))))
(assert
 (let (($x1781 (= v_0_tx_time_00 v_0_persist_last_ms)))
 (let (($x1775 (= 1 v_0_rtx_buf)))
 (or (not (and v_0_persist_active (<= 1 v_0_persist_probes) $x1775)) $x1781))))
(assert
 (let (($x1767 (= 0 v_0_persist_probes)))
 (let (($x1786 (and (= 0 v_0_persist_since_ms) (= 0 v_0_persist_last_ms) (= 0 v_0_persist_deadline_ms) $x1767)))
 (or v_0_persist_active $x1786))))
(assert
 (and (<= 4 v_0_cc_initial_window) (>= 16 v_0_cc_initial_window) (<= 8 v_0_cc_initial_threshold)))
(assert
 (and (<= 4 v_0_cc_cwnd) (<= 8 v_0_cc_ssthresh) (<= 0 v_0_cc_ca_credit) (not (>= v_0_cc_ca_credit v_0_cc_cwnd)) (<= 0 v_0_cc_growth) (>= 4 v_0_cc_growth) (<= 0 v_0_cc_acked) (>= 16 v_0_cc_acked) (<= 0 v_0_cc_threshold_updates)))
(assert
 (and (<= 0 v_0_cc_new_sent) (<= v_0_cc_new_sent v_0_cc_send_budget)))
(assert
 (let (($x649 (>= 0 v_0_rtx_buf)))
 (let (($x891 (not $x649)))
 (let (($x1810 (not v_0_cc_rto_00)))
 (or $x1810 $x891)))))
(assert
 (let (($x609 (>= 1 v_0_rtx_buf)))
 (let (($x896 (not $x609)))
 (let (($x1812 (not v_0_cc_rto_01)))
 (or $x1812 $x896)))))
(assert
 (let (($x659 (>= 2 v_0_rtx_buf)))
 (let (($x901 (not $x659)))
 (let (($x1814 (not v_0_cc_rto_02)))
 (or $x1814 $x901)))))
(assert
 (let (($x665 (>= 3 v_0_rtx_buf)))
 (let (($x906 (not $x665)))
 (let (($x1816 (not v_0_cc_rto_03)))
 (or $x1816 $x906)))))
(assert
 (let (($x671 (>= 4 v_0_rtx_buf)))
 (let (($x911 (not $x671)))
 (let (($x1818 (not v_0_cc_rto_04)))
 (or $x1818 $x911)))))
(assert
 (let (($x677 (>= 5 v_0_rtx_buf)))
 (let (($x916 (not $x677)))
 (let (($x1820 (not v_0_cc_rto_05)))
 (or $x1820 $x916)))))
(assert
 (let (($x683 (>= 6 v_0_rtx_buf)))
 (let (($x921 (not $x683)))
 (let (($x1822 (not v_0_cc_rto_06)))
 (or $x1822 $x921)))))
(assert
 (let (($x689 (>= 7 v_0_rtx_buf)))
 (let (($x926 (not $x689)))
 (let (($x1824 (not v_0_cc_rto_07)))
 (or $x1824 $x926)))))
(assert
 (let (($x695 (>= 8 v_0_rtx_buf)))
 (let (($x931 (not $x695)))
 (let (($x1826 (not v_0_cc_rto_08)))
 (or $x1826 $x931)))))
(assert
 (let (($x701 (>= 9 v_0_rtx_buf)))
 (let (($x936 (not $x701)))
 (let (($x1828 (not v_0_cc_rto_09)))
 (or $x1828 $x936)))))
(assert
 (let (($x707 (>= 10 v_0_rtx_buf)))
 (let (($x941 (not $x707)))
 (let (($x1830 (not v_0_cc_rto_10)))
 (or $x1830 $x941)))))
(assert
 (let (($x713 (>= 11 v_0_rtx_buf)))
 (let (($x946 (not $x713)))
 (let (($x1832 (not v_0_cc_rto_11)))
 (or $x1832 $x946)))))
(assert
 (let (($x719 (>= 12 v_0_rtx_buf)))
 (let (($x951 (not $x719)))
 (let (($x1834 (not v_0_cc_rto_12)))
 (or $x1834 $x951)))))
(assert
 (let (($x725 (>= 13 v_0_rtx_buf)))
 (let (($x956 (not $x725)))
 (let (($x1836 (not v_0_cc_rto_13)))
 (or $x1836 $x956)))))
(assert
 (let (($x731 (>= 14 v_0_rtx_buf)))
 (let (($x961 (not $x731)))
 (let (($x1838 (not v_0_cc_rto_14)))
 (or $x1838 $x961)))))
(assert
 (let (($x737 (>= 15 v_0_rtx_buf)))
 (let (($x966 (not $x737)))
 (let (($x1840 (not v_0_cc_rto_15)))
 (or $x1840 $x966)))))
(assert
 (and (<= 0 v_0_fr_dupacks) (<= 0 v_0_fr_entries) (<= 0 v_0_fr_emit_count) (>= 4 v_0_fr_emit_count) (<= 0 v_0_fr_last_window) (>= 65535 v_0_fr_last_window)))
(assert
 (let (($x802 (not v_0_persist_active)))
 (let (($x1300 (<= 1 v_0_rtx_buf)))
 (let (($x1850 (not v_0_fr_active)))
 (or $x1850 (and (<= 3 v_0_fr_dupacks) $x1300 $x802))))))
(assert
 (let (($x1703 (not v_0_tx_retransmitted)))
 (let (($x1863 (= v_0_retries v_0_fr_before_retries)))
 (let (($x1861 (= v_0_rto_ms v_0_fr_before_rto)))
 (let (($x1859 (= v_0_snd_nxt v_0_fr_before_nxt)))
 (let (($x1864 (and v_0_fr_entered (= 3 v_0_fr_dupacks) (<= 1 v_0_fr_emit_count) $x1859 $x1861 $x1863 $x1703)))
 (let (($x1855 (not v_0_fr_retransmitted)))
 (or $x1855 $x1864))))))))
(assert
 (let (($x1872 (and (= v_0_fr_last_window v_0_fr_before_wire_window) (= v_0_fr_window_valid v_0_fr_before_window_valid))))
 (or (not v_0_fr_window_ignored) $x1872)))
(assert
 (let (($x1874 (not v_0_fr_entered)))
 (or v_0_fr_retransmitted $x1874)))
(assert
 (let (($x1874 (not v_0_fr_entered)))
 (or $x1874 (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))))
(assert
 (let (($x1880 (not v_0_fr_exited)))
 (or $x1880 (and (= v_0_cc_cwnd v_0_cc_ssthresh) (= 0 v_0_cc_ca_credit)))))
(assert
 (and (<= 0 v_0_idle_last_data_ms) (<= v_0_idle_last_data_ms v_0_idle_event_ms) (<= v_0_idle_event_ms now_0) (<= 0 v_0_idle_elapsed_ms) (<= 0 v_0_idle_restart_count)))
(assert
 (or (not v_0_idle_data_emitted) (= v_0_idle_last_data_ms v_0_idle_event_ms)))
(assert
 (let (($x1882 (= 0 v_0_cc_ca_credit)))
 (let (($x1907 (= v_0_cc_ssthresh v_0_idle_before_threshold)))
 (let ((?x1904 (ite (<= v_0_cc_initial_window v_0_idle_before_cwnd) v_0_cc_initial_window v_0_idle_before_cwnd)))
 (let (($x1908 (and (not (>= v_0_idle_before_rto v_0_idle_elapsed_ms)) (= v_0_cc_cwnd ?x1904) $x1907 $x1882)))
 (let (($x1898 (not v_0_idle_restart)))
 (or $x1898 $x1908)))))))
(assert
 (and (<= 0 v_0_lt_epoch_bytes) (>= 8 v_0_lt_epoch_bytes) (<= v_0_lt_epoch_bytes v_0_rtx_buf) (<= 0 v_0_lt_epoch_packets) (>= 2 v_0_lt_epoch_packets) (<= v_0_lt_epoch_packets v_0_fr_dupacks) (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets) (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets)) (<= 0 v_0_lt_loss_flight)))
(assert
 (let (($x1931 (= v_0_cc_cwnd v_0_lt_before_cwnd)))
 (let (($x606 (not v_0_fin_sent)))
 (let (($x1850 (not v_0_fr_active)))
 (let (($x1941 (and v_0_fr_duplicate (<= 1 v_0_fr_dupacks) (>= 2 v_0_fr_dupacks) $x1850 $x606 (<= 1 v_0_lt_take) (>= 4 v_0_lt_take) $x1931 (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take)) (<= v_0_rtx_buf v_0_snd_wnd) (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd)) (= v_0_snd_nxt (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)))))
 (let (($x1923 (not v_0_lt_emitted)))
 (or $x1923 $x1941)))))))
(assert
 (let (($x1947 (= v_0_lt_loss_flight (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes)))))
 (let (($x1874 (not v_0_fr_entered)))
 (or $x1874 $x1947))))
(assert
 (and (<= 0 v_0_choice_count) (>= 4 v_0_choice_count) (<= 0 v_0_choice_limit) (>= 4 v_0_choice_limit)))
(assert
 (let ((?x1962 (mod (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)))
 (let (($x1959 (= v_0_cc_new_sent v_0_choice_count)))
 (let (($x1958 (= v_0_take v_0_choice_count)))
 (let (($x1966 (and (<= 1 v_0_choice_count) (<= v_0_choice_count v_0_choice_limit) $x1958 $x1959 (<= v_0_choice_count v_0_cc_send_budget) (= v_0_snd_nxt ?x1962) (= v_0_rtx_buf (+ v_0_choice_before_flight v_0_choice_count)))))
 (let (($x1955 (not v_0_choice_used)))
 (or $x1955 $x1966)))))))
(assert
 (and (<= 0 v_0_sched_packets) (<= v_0_sched_packets v_0_sched_bytes) (<= v_0_sched_bytes (* 4 v_0_sched_packets)) (>= 16 (+ v_0_sched_bytes v_0_snd_buf))))
(assert
 (let (($x1980 (not v_0_sched_open)))
 (and (<= 0 v_0_sched_at_ms) (<= v_0_sched_at_ms now_0) (or $x1980 (= 1 v_0_sched_cause) (= 2 v_0_sched_cause)))))
(assert
 (let (($x1955 (not v_0_choice_used)))
 (or $x1955 (and v_0_sched_open (= v_0_sched_at_ms v_0_idle_event_ms)))))
(assert
 (let ((?x1992 (+ v_0_svc_acked_bytes v_0_svc_abandoned_bytes v_0_snd_buf v_0_rtx_buf)))
 (and (<= 0 v_0_svc_written_bytes) (<= 0 v_0_svc_acked_bytes) (<= 0 v_0_svc_abandoned_bytes) (= v_0_svc_written_bytes ?x1992))))
(assert
 (let (($x1996 (= v_0_svc_ack_step v_0_cc_acked)))
 (and $x1996 (<= 0 v_0_svc_accept_step) (<= 0 v_0_svc_ack_step) (<= 0 v_0_svc_drop_step))))
(assert
 (let ((?x2010 (+ v_0_cb_head v_0_cb_count)))
 (let (($x2014 (= v_0_cb_tail (ite (<= 16 ?x2010) (+ (- 16) v_0_cb_head v_0_cb_count) ?x2010))))
 (and (<= 0 v_0_cb_head) (not (<= 16 v_0_cb_head)) (<= 0 v_0_cb_tail) (not (<= 16 v_0_cb_tail)) (<= 0 v_0_cb_count) (<= v_0_cb_count v_0_rtx_buf) $x2014 (<= 0 v_0_cb_new_count) (>= 1 v_0_cb_new_count)))))
(assert
 (let ((?x1193 (+ v_0_cb_length_00 v_0_cb_length_01 v_0_cb_length_02 v_0_cb_length_03 v_0_cb_length_04 v_0_cb_length_05 v_0_cb_length_06 v_0_cb_length_07 v_0_cb_length_08 v_0_cb_length_09 v_0_cb_length_10 v_0_cb_length_11 v_0_cb_length_12 v_0_cb_length_13 v_0_cb_length_14 v_0_cb_length_15)))
 (let (($x2034 (= v_0_cb_emitted_total (+ v_0_cb_acked_total v_0_cb_abandoned_total v_0_cb_live_total))))
 (and (<= 0 v_0_cb_emitted_total) (<= 0 v_0_cb_acked_total) (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix) v_0_svc_acked_bytes) (<= v_0_cb_emitted_total v_0_svc_written_bytes) (<= 0 v_0_cb_abandoned_total) (<= 0 v_0_cb_step_bytes) (>= 19 v_0_cb_step_bytes) (<= 0 v_0_cb_drop_step) $x2034 (= v_0_cb_live_total ?x1193)))))
(assert
 (let (($x2038 (= v_0_cb_partial_prefix (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf)))))
 (and $x2038 (<= 0 v_0_cb_partial_prefix) (>= 3 v_0_cb_partial_prefix))))
(assert
 (<= (+ v_0_cb_emitted_total v_0_snd_buf) v_0_svc_written_bytes))
(assert
 (let ((?x882 (- 1)))
 (let ((?x2048 (* ?x882 v_0_cb_head)))
 (let ((?x2050 (ite (>= 0 v_0_cb_head) ?x2048 (+ 16 ?x2048))))
 (let (($x2051 (>= ?x2050 v_0_cb_count)))
 (let (($x2053 (not $x2051)))
 (let (($x2075 (or (not (and $x2053 (<= 1 ?x2050))) (= v_0_cb_end_00 (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)))))
 (let ((?x2065 (mod (+ v_0_snd_una v_0_cb_length_00 (* ?x882 v_0_cb_partial_prefix)) 4294967296)))
 (let (($x2067 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_00)) (= v_0_cb_end_00 ?x2065))))
 (let (($x2052 (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00)) $x2051)))
 (and $x2052 (or $x2053 (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00))) (or (not (and $x2053 (= 0 v_0_cb_head))) $x2067) $x2075)))))))))))
(assert
 (let ((?x2084 (ite (>= 1 v_0_cb_head) (+ 1 (* (- 1) v_0_cb_head)) (+ 17 (* (- 1) v_0_cb_head)))))
 (let (($x2085 (>= ?x2084 v_0_cb_count)))
 (let (($x2087 (not $x2085)))
 (let (($x2108 (or (not (and $x2087 (<= 1 ?x2084))) (= v_0_cb_end_01 (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2099 (= v_0_cb_end_01 (mod (+ v_0_snd_una v_0_cb_length_01 ?x2063) 4294967296))))
 (let (($x2101 (or (not (and $x2087 (= 1 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_01)) $x2099))))
 (let (($x2086 (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01)) $x2085)))
 (and $x2086 (or $x2087 (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01))) $x2101 $x2108)))))))))))
(assert
 (let ((?x2117 (ite (>= 2 v_0_cb_head) (+ 2 (* (- 1) v_0_cb_head)) (+ 18 (* (- 1) v_0_cb_head)))))
 (let (($x2118 (>= ?x2117 v_0_cb_count)))
 (let (($x2120 (not $x2118)))
 (let (($x2141 (or (not (and $x2120 (<= 1 ?x2117))) (= v_0_cb_end_02 (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2132 (= v_0_cb_end_02 (mod (+ v_0_snd_una v_0_cb_length_02 ?x2063) 4294967296))))
 (let (($x2134 (or (not (and $x2120 (= 2 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_02)) $x2132))))
 (let (($x2119 (or (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)) $x2118)))
 (and $x2119 (or $x2120 (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02))) $x2134 $x2141)))))))))))
(assert
 (let ((?x2149 (ite (>= 3 v_0_cb_head) (+ 3 (* (- 1) v_0_cb_head)) (+ 19 (* (- 1) v_0_cb_head)))))
 (let (($x2150 (>= ?x2149 v_0_cb_count)))
 (let (($x2152 (not $x2150)))
 (let (($x2173 (or (not (and $x2152 (<= 1 ?x2149))) (= v_0_cb_end_03 (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2164 (= v_0_cb_end_03 (mod (+ v_0_snd_una v_0_cb_length_03 ?x2063) 4294967296))))
 (let (($x2166 (or (not (and $x2152 (= 3 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_03)) $x2164))))
 (let (($x2151 (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03)) $x2150)))
 (and $x2151 (or $x2152 (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03))) $x2166 $x2173)))))))))))
(assert
 (let ((?x2179 (ite (>= 4 v_0_cb_head) (+ 4 (* (- 1) v_0_cb_head)) (+ 20 (* (- 1) v_0_cb_head)))))
 (let (($x2180 (>= ?x2179 v_0_cb_count)))
 (let (($x2185 (not $x2180)))
 (let (($x2206 (or (not (and $x2185 (<= 1 ?x2179))) (= v_0_cb_end_04 (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2197 (= v_0_cb_end_04 (mod (+ v_0_snd_una v_0_cb_length_04 ?x2063) 4294967296))))
 (let (($x2199 (or (not (and $x2185 (= 4 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_04)) $x2197))))
 (let (($x2184 (or $x2180 (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04)))))
 (and $x2184 (or $x2185 (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04))) $x2199 $x2206)))))))))))
(assert
 (let ((?x2212 (ite (>= 5 v_0_cb_head) (+ 5 (* (- 1) v_0_cb_head)) (+ 21 (* (- 1) v_0_cb_head)))))
 (let (($x2213 (>= ?x2212 v_0_cb_count)))
 (let (($x2218 (not $x2213)))
 (let (($x2239 (or (not (and $x2218 (<= 1 ?x2212))) (= v_0_cb_end_05 (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2230 (= v_0_cb_end_05 (mod (+ v_0_snd_una v_0_cb_length_05 ?x2063) 4294967296))))
 (let (($x2232 (or (not (and $x2218 (= 5 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_05)) $x2230))))
 (let (($x2217 (or $x2213 (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))))
 (and $x2217 (or $x2218 (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05))) $x2232 $x2239)))))))))))
(assert
 (let ((?x2245 (ite (>= 6 v_0_cb_head) (+ 6 (* (- 1) v_0_cb_head)) (+ 22 (* (- 1) v_0_cb_head)))))
 (let (($x2246 (>= ?x2245 v_0_cb_count)))
 (let (($x2251 (not $x2246)))
 (let (($x2272 (or (not (and $x2251 (<= 1 ?x2245))) (= v_0_cb_end_06 (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2263 (= v_0_cb_end_06 (mod (+ v_0_snd_una v_0_cb_length_06 ?x2063) 4294967296))))
 (let (($x2265 (or (not (and $x2251 (= 6 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_06)) $x2263))))
 (let (($x2250 (or $x2246 (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06)))))
 (and $x2250 (or $x2251 (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06))) $x2265 $x2272)))))))))))
(assert
 (let ((?x2278 (ite (>= 7 v_0_cb_head) (+ 7 (* (- 1) v_0_cb_head)) (+ 23 (* (- 1) v_0_cb_head)))))
 (let (($x2279 (>= ?x2278 v_0_cb_count)))
 (let (($x2284 (not $x2279)))
 (let (($x2305 (or (not (and $x2284 (<= 1 ?x2278))) (= v_0_cb_end_07 (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2296 (= v_0_cb_end_07 (mod (+ v_0_snd_una v_0_cb_length_07 ?x2063) 4294967296))))
 (let (($x2298 (or (not (and $x2284 (= 7 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_07)) $x2296))))
 (let (($x2283 (or $x2279 (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))))
 (and $x2283 (or $x2284 (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07))) $x2298 $x2305)))))))))))
(assert
 (let ((?x2314 (ite (>= 8 v_0_cb_head) (+ 8 (* (- 1) v_0_cb_head)) (+ 24 (* (- 1) v_0_cb_head)))))
 (let (($x2315 (>= ?x2314 v_0_cb_count)))
 (let (($x2317 (not $x2315)))
 (let (($x2338 (or (not (and $x2317 (<= 1 ?x2314))) (= v_0_cb_end_08 (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2329 (= v_0_cb_end_08 (mod (+ v_0_snd_una v_0_cb_length_08 ?x2063) 4294967296))))
 (let (($x2331 (or (not (and $x2317 (= 8 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_08)) $x2329))))
 (let (($x2316 (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08)) $x2315)))
 (and $x2316 (or $x2317 (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08))) $x2331 $x2338)))))))))))
(assert
 (let ((?x2344 (ite (>= 9 v_0_cb_head) (+ 9 (* (- 1) v_0_cb_head)) (+ 25 (* (- 1) v_0_cb_head)))))
 (let (($x2345 (>= ?x2344 v_0_cb_count)))
 (let (($x2350 (not $x2345)))
 (let (($x2371 (or (not (and $x2350 (<= 1 ?x2344))) (= v_0_cb_end_09 (mod (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2362 (= v_0_cb_end_09 (mod (+ v_0_snd_una v_0_cb_length_09 ?x2063) 4294967296))))
 (let (($x2364 (or (not (and $x2350 (= 9 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09)) $x2362))))
 (let (($x2349 (or $x2345 (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09)))))
 (and $x2349 (or $x2350 (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09))) $x2364 $x2371)))))))))))
(assert
 (let ((?x2377 (ite (>= 10 v_0_cb_head) (+ 10 (* (- 1) v_0_cb_head)) (+ 26 (* (- 1) v_0_cb_head)))))
 (let (($x2378 (>= ?x2377 v_0_cb_count)))
 (let (($x2383 (not $x2378)))
 (let (($x2404 (or (not (and $x2383 (<= 1 ?x2377))) (= v_0_cb_end_10 (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2395 (= v_0_cb_end_10 (mod (+ v_0_snd_una v_0_cb_length_10 ?x2063) 4294967296))))
 (let (($x2397 (or (not (and $x2383 (= 10 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_10)) $x2395))))
 (let (($x2382 (or $x2378 (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10)))))
 (and $x2382 (or $x2383 (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10))) $x2397 $x2404)))))))))))
(assert
 (let ((?x2413 (ite (>= 11 v_0_cb_head) (+ 11 (* (- 1) v_0_cb_head)) (+ 27 (* (- 1) v_0_cb_head)))))
 (let (($x2414 (>= ?x2413 v_0_cb_count)))
 (let (($x2416 (not $x2414)))
 (let (($x2437 (or (not (and $x2416 (<= 1 ?x2413))) (= v_0_cb_end_11 (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2428 (= v_0_cb_end_11 (mod (+ v_0_snd_una v_0_cb_length_11 ?x2063) 4294967296))))
 (let (($x2430 (or (not (and $x2416 (= 11 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_11)) $x2428))))
 (let (($x2415 (or (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)) $x2414)))
 (and $x2415 (or $x2416 (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11))) $x2430 $x2437)))))))))))
(assert
 (let ((?x2443 (ite (>= 12 v_0_cb_head) (+ 12 (* (- 1) v_0_cb_head)) (+ 28 (* (- 1) v_0_cb_head)))))
 (let (($x2444 (>= ?x2443 v_0_cb_count)))
 (let (($x2449 (not $x2444)))
 (let (($x2470 (or (not (and $x2449 (<= 1 ?x2443))) (= v_0_cb_end_12 (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2461 (= v_0_cb_end_12 (mod (+ v_0_snd_una v_0_cb_length_12 ?x2063) 4294967296))))
 (let (($x2463 (or (not (and $x2449 (= 12 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_12)) $x2461))))
 (let (($x2448 (or $x2444 (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12)))))
 (and $x2448 (or $x2449 (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12))) $x2463 $x2470)))))))))))
(assert
 (let ((?x2479 (ite (>= 13 v_0_cb_head) (+ 13 (* (- 1) v_0_cb_head)) (+ 29 (* (- 1) v_0_cb_head)))))
 (let (($x2480 (>= ?x2479 v_0_cb_count)))
 (let (($x2482 (not $x2480)))
 (let (($x2503 (or (not (and $x2482 (<= 1 ?x2479))) (= v_0_cb_end_13 (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2494 (= v_0_cb_end_13 (mod (+ v_0_snd_una v_0_cb_length_13 ?x2063) 4294967296))))
 (let (($x2496 (or (not (and $x2482 (= 13 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_13)) $x2494))))
 (let (($x2481 (or (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)) $x2480)))
 (and $x2481 (or $x2482 (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13))) $x2496 $x2503)))))))))))
(assert
 (let ((?x2509 (ite (>= 14 v_0_cb_head) (+ 14 (* (- 1) v_0_cb_head)) (+ 30 (* (- 1) v_0_cb_head)))))
 (let (($x2510 (>= ?x2509 v_0_cb_count)))
 (let (($x2515 (not $x2510)))
 (let (($x2536 (or (not (and $x2515 (<= 1 ?x2509))) (= v_0_cb_end_14 (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2527 (= v_0_cb_end_14 (mod (+ v_0_snd_una v_0_cb_length_14 ?x2063) 4294967296))))
 (let (($x2529 (or (not (and $x2515 (= 14 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_14)) $x2527))))
 (let (($x2514 (or $x2510 (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14)))))
 (and $x2514 (or $x2515 (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14))) $x2529 $x2536)))))))))))
(assert
 (let ((?x2542 (ite (>= 15 v_0_cb_head) (+ 15 (* (- 1) v_0_cb_head)) (+ 31 (* (- 1) v_0_cb_head)))))
 (let (($x2543 (>= ?x2542 v_0_cb_count)))
 (let (($x2548 (not $x2543)))
 (let (($x2569 (or (not (and $x2548 (<= 1 ?x2542))) (= v_0_cb_end_15 (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))))
 (let ((?x882 (- 1)))
 (let ((?x2063 (* ?x882 v_0_cb_partial_prefix)))
 (let (($x2560 (= v_0_cb_end_15 (mod (+ v_0_snd_una v_0_cb_length_15 ?x2063) 4294967296))))
 (let (($x2562 (or (not (and $x2548 (= 15 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_15)) $x2560))))
 (let (($x2547 (or $x2543 (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)))))
 (and $x2547 (or $x2548 (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15))) $x2562 $x2569)))))))))))
(assert
 (= 107 choice_0))
(assert
 (= 7 state_0))
(assert
 (= 7 state_1))
(assert
 (or (not (or (not v_1_cc_rto_11) (not (>= 11 v_1_rtx_buf)))) (not (or (not v_1_cc_rto_12) (not (>= 12 v_1_rtx_buf)))) (not (or (not v_1_cc_rto_13) (not (>= 13 v_1_rtx_buf)))) (not (or (not v_1_cc_rto_14) (not (>= 14 v_1_rtx_buf)))) (not (or (not v_1_cc_rto_15) (not (>= 15 v_1_rtx_buf)))) (not (<= 0 v_1_fr_dupacks)) (not (<= 0 v_1_fr_entries)) (not (<= 0 v_1_fr_emit_count))))
(check-sat)

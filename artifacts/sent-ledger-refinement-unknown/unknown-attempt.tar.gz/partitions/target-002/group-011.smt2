; benchmark generated from python API
(set-info :status unknown)
(declare-fun v_0_snd_buf () Int)
(declare-fun v_0_rtx_buf () Int)
(declare-fun v_0_rcv_buf () Int)
(declare-fun v_0_rx_chunk () Int)
(declare-fun v_0_rx_slot_00 () Int)
(declare-fun v_0_rx_slot_01 () Int)
(declare-fun v_0_rx_slot_02 () Int)
(declare-fun v_0_rx_slot_03 () Int)
(declare-fun v_0_rx_slot_04 () Int)
(declare-fun v_0_rx_slot_05 () Int)
(declare-fun v_0_rx_slot_06 () Int)
(declare-fun v_0_rx_slot_07 () Int)
(declare-fun v_0_rx_slot_08 () Int)
(declare-fun v_0_rx_slot_09 () Int)
(declare-fun v_0_rx_slot_10 () Int)
(declare-fun v_0_rx_slot_11 () Int)
(declare-fun v_0_rx_slot_12 () Int)
(declare-fun v_0_rx_slot_13 () Int)
(declare-fun v_0_rx_slot_14 () Int)
(declare-fun v_0_rx_slot_15 () Int)
(declare-fun v_1_snd_buf () Int)
(declare-fun v_1_rtx_buf () Int)
(declare-fun v_1_rcv_buf () Int)
(declare-fun v_1_rx_chunk () Int)
(declare-fun v_1_rx_slot_00 () Int)
(declare-fun v_1_rx_slot_01 () Int)
(declare-fun v_1_rx_slot_02 () Int)
(declare-fun v_1_rx_slot_03 () Int)
(declare-fun v_1_rx_slot_04 () Int)
(declare-fun v_1_rx_slot_05 () Int)
(declare-fun v_1_rx_slot_06 () Int)
(declare-fun v_1_rx_slot_07 () Int)
(declare-fun v_1_rx_slot_08 () Int)
(declare-fun v_1_rx_slot_09 () Int)
(declare-fun v_1_rx_slot_10 () Int)
(declare-fun v_1_rx_slot_11 () Int)
(declare-fun v_1_rx_slot_12 () Int)
(declare-fun v_1_rx_slot_13 () Int)
(declare-fun v_1_rx_slot_14 () Int)
(declare-fun v_1_rx_slot_15 () Int)
(declare-fun v_0_iss () Int)
(declare-fun v_0_irs () Int)
(declare-fun v_0_snd_una () Int)
(declare-fun v_0_snd_nxt () Int)
(declare-fun v_0_rcv_nxt () Int)
(declare-fun v_0_tx_seq () Int)
(declare-fun v_0_tx_ack () Int)
(declare-fun v_0_snd_wl1 () Int)
(declare-fun v_0_snd_wl2 () Int)
(declare-fun v_0_fin_seq () Int)
(declare-fun v_0_rx_fin_seq () Int)
(declare-fun v_0_rtt_end () Int)
(declare-fun v_0_cc_before_una () Int)
(declare-fun v_0_fr_before_una () Int)
(declare-fun v_0_fr_before_nxt () Int)
(declare-fun v_0_lt_before_nxt () Int)
(declare-fun v_0_choice_before_nxt () Int)
(declare-fun v_0_cb_before_nxt () Int)
(declare-fun v_0_cb_append_end () Int)
(declare-fun v_0_cb_end_00 () Int)
(declare-fun v_0_cb_end_01 () Int)
(declare-fun v_0_cb_end_02 () Int)
(declare-fun v_0_cb_end_03 () Int)
(declare-fun v_0_cb_end_04 () Int)
(declare-fun v_0_cb_end_05 () Int)
(declare-fun v_0_cb_end_06 () Int)
(declare-fun v_0_cb_end_07 () Int)
(declare-fun v_0_cb_end_08 () Int)
(declare-fun v_0_cb_end_09 () Int)
(declare-fun v_0_cb_end_10 () Int)
(declare-fun v_0_cb_end_11 () Int)
(declare-fun v_0_cb_end_12 () Int)
(declare-fun v_0_cb_end_13 () Int)
(declare-fun v_0_cb_end_14 () Int)
(declare-fun v_0_cb_end_15 () Int)
(declare-fun v_1_iss () Int)
(declare-fun v_1_irs () Int)
(declare-fun v_1_snd_una () Int)
(declare-fun v_1_snd_nxt () Int)
(declare-fun v_1_rcv_nxt () Int)
(declare-fun v_1_tx_seq () Int)
(declare-fun v_1_tx_ack () Int)
(declare-fun v_1_snd_wl1 () Int)
(declare-fun v_1_snd_wl2 () Int)
(declare-fun v_1_fin_seq () Int)
(declare-fun v_1_rx_fin_seq () Int)
(declare-fun v_1_rtt_end () Int)
(declare-fun v_1_cc_before_una () Int)
(declare-fun v_1_fr_before_una () Int)
(declare-fun v_1_fr_before_nxt () Int)
(declare-fun v_1_lt_before_nxt () Int)
(declare-fun v_1_choice_before_nxt () Int)
(declare-fun v_1_cb_before_nxt () Int)
(declare-fun v_1_cb_append_end () Int)
(declare-fun v_1_cb_end_00 () Int)
(declare-fun v_1_cb_end_01 () Int)
(declare-fun v_1_cb_end_02 () Int)
(declare-fun v_1_cb_end_03 () Int)
(declare-fun v_1_cb_end_04 () Int)
(declare-fun v_1_cb_end_05 () Int)
(declare-fun v_1_cb_end_06 () Int)
(declare-fun v_1_cb_end_07 () Int)
(declare-fun v_1_cb_end_08 () Int)
(declare-fun v_1_cb_end_09 () Int)
(declare-fun v_1_cb_end_10 () Int)
(declare-fun v_1_cb_end_11 () Int)
(declare-fun v_1_cb_end_12 () Int)
(declare-fun v_1_cb_end_13 () Int)
(declare-fun v_1_cb_end_14 () Int)
(declare-fun v_1_cb_end_15 () Int)
(declare-fun now_0 () Int)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_delack () Int)
(declare-fun active_0_delack () Bool)
(declare-fun due_0_persist () Int)
(declare-fun active_0_persist () Bool)
(declare-fun input_0_app.send_data () Int)
(declare-fun input_0_net.data_data () Int)
(declare-fun input_0_net.fin_segment_data () Int)
(declare-fun input_0_net.syn_seq () Int)
(declare-fun input_0_net.synack_seq () Int)
(declare-fun input_0_net.synack_ack () Int)
(declare-fun input_0_net.ack_seq () Int)
(declare-fun input_0_net.ack_ack () Int)
(declare-fun input_0_net.fin_seq () Int)
(declare-fun input_0_net.fin_ack () Int)
(declare-fun input_0_net.rst_seq () Int)
(declare-fun input_0_net.rstack_seq () Int)
(declare-fun input_0_net.rstack_ack () Int)
(declare-fun input_0_net.data_seq () Int)
(declare-fun input_0_net.data_ack () Int)
(declare-fun input_0_net.fin_segment_seq () Int)
(declare-fun input_0_net.fin_segment_ack () Int)
(declare-fun v_0_persist_interval_ms () Int)
(declare-fun v_0_rto_ms () Int)
(declare-fun now_1 () Int)
(declare-fun v_0_tx_time_00 () Int)
(declare-fun v_0_tx_time_01 () Int)
(declare-fun v_0_tx_time_02 () Int)
(declare-fun v_0_tx_time_03 () Int)
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_persist_active () Bool)
(declare-fun v_0_fin_sent () Bool)
(declare-fun due_1_persist () Int)
(declare-fun due_1_delack () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_persist () Bool)
(declare-fun active_1_delack () Bool)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_cb_done_15 () Bool)
(declare-fun v_0_cb_tail () Int)
(declare-fun v_0_cb_length_15 () Int)
(declare-fun v_1_cb_length_15 () Int)
(declare-fun v_1_cb_done_14 () Bool)
(declare-fun v_0_cb_length_14 () Int)
(declare-fun v_1_cb_length_14 () Int)
(declare-fun v_1_cb_done_13 () Bool)
(declare-fun v_0_cb_length_13 () Int)
(declare-fun v_1_cb_length_13 () Int)
(declare-fun v_1_cb_done_12 () Bool)
(declare-fun v_0_cb_length_12 () Int)
(declare-fun v_1_cb_length_12 () Int)
(declare-fun v_1_cb_done_11 () Bool)
(declare-fun v_0_cb_length_11 () Int)
(declare-fun v_1_cb_length_11 () Int)
(declare-fun v_1_cb_done_10 () Bool)
(declare-fun v_0_cb_length_10 () Int)
(declare-fun v_1_cb_length_10 () Int)
(declare-fun v_1_cb_done_09 () Bool)
(declare-fun v_0_cb_length_09 () Int)
(declare-fun v_1_cb_length_09 () Int)
(declare-fun v_1_cb_done_08 () Bool)
(declare-fun v_0_cb_length_08 () Int)
(declare-fun v_1_cb_length_08 () Int)
(declare-fun v_1_cb_done_07 () Bool)
(declare-fun v_0_cb_length_07 () Int)
(declare-fun v_1_cb_length_07 () Int)
(declare-fun v_1_cb_done_06 () Bool)
(declare-fun v_0_cb_length_06 () Int)
(declare-fun v_1_cb_length_06 () Int)
(declare-fun v_1_cb_done_05 () Bool)
(declare-fun v_0_cb_length_05 () Int)
(declare-fun v_1_cb_length_05 () Int)
(declare-fun v_1_cb_done_04 () Bool)
(declare-fun v_0_cb_length_04 () Int)
(declare-fun v_1_cb_length_04 () Int)
(declare-fun v_1_cb_done_03 () Bool)
(declare-fun v_0_cb_length_03 () Int)
(declare-fun v_1_cb_length_03 () Int)
(declare-fun v_1_cb_done_02 () Bool)
(declare-fun v_0_cb_length_02 () Int)
(declare-fun v_1_cb_length_02 () Int)
(declare-fun v_1_cb_done_01 () Bool)
(declare-fun v_0_cb_length_01 () Int)
(declare-fun v_1_cb_length_01 () Int)
(declare-fun v_1_cb_done_00 () Bool)
(declare-fun v_0_cb_length_00 () Int)
(declare-fun v_1_cb_length_00 () Int)
(declare-fun v_1_cb_is_new () Bool)
(declare-fun v_1_cb_drop_step () Int)
(declare-fun v_0_cb_abandoned_total () Int)
(declare-fun v_1_cb_abandoned_total () Int)
(declare-fun v_0_cb_acked_total () Int)
(declare-fun v_1_cb_acked_total () Int)
(declare-fun v_0_cb_emitted_total () Int)
(declare-fun v_1_cb_emitted_total () Int)
(declare-fun v_1_cb_partial_prefix () Int)
(declare-fun v_1_cb_live_total () Int)
(declare-fun v_1_cb_step_bytes () Int)
(declare-fun v_1_cb_retired_count () Int)
(declare-fun v_1_cb_append_length () Int)
(declare-fun v_1_cb_new_count () Int)
(declare-fun v_0_cb_count () Int)
(declare-fun v_1_cb_count () Int)
(declare-fun v_1_cb_tail () Int)
(declare-fun v_0_cb_head () Int)
(declare-fun v_1_cb_head () Int)
(declare-fun v_0_svc_abandoned_bytes () Int)
(declare-fun v_1_svc_abandoned_bytes () Int)
(declare-fun v_0_svc_acked_bytes () Int)
(declare-fun v_1_svc_acked_bytes () Int)
(declare-fun v_0_svc_written_bytes () Int)
(declare-fun v_1_svc_written_bytes () Int)
(declare-fun v_1_svc_drop_step () Int)
(declare-fun v_1_svc_ack_step () Int)
(declare-fun v_1_svc_accept_step () Int)
(declare-fun v_1_svc_before_total () Int)
(declare-fun v_1_sched_packets () Int)
(declare-fun v_1_sched_bytes () Int)
(declare-fun v_1_sched_cause () Int)
(declare-fun v_0_sched_at_ms () Int)
(declare-fun v_1_sched_at_ms () Int)
(declare-fun v_1_sched_open () Bool)
(declare-fun v_0_choice_before_flight () Int)
(declare-fun v_1_choice_before_flight () Int)
(declare-fun v_0_choice_limit () Int)
(declare-fun v_1_choice_limit () Int)
(declare-fun v_0_choice_count () Int)
(declare-fun v_1_choice_count () Int)
(declare-fun v_1_choice_used () Bool)
(declare-fun v_0_lt_epoch_bytes () Int)
(declare-fun v_1_lt_loss_flight () Int)
(declare-fun v_1_lt_before_window () Int)
(declare-fun v_1_lt_before_flight () Int)
(declare-fun v_0_cc_cwnd () Int)
(declare-fun v_1_lt_before_cwnd () Int)
(declare-fun v_1_lt_before_bytes () Int)
(declare-fun v_0_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_bytes () Int)
(declare-fun v_1_lt_take () Int)
(declare-fun v_1_lt_emitted () Bool)
(declare-fun v_1_lt_eligible () Bool)
(declare-fun v_0_idle_restart_count () Int)
(declare-fun v_1_idle_restart_count () Int)
(declare-fun v_0_cc_ssthresh () Int)
(declare-fun v_1_idle_before_threshold () Int)
(declare-fun v_1_idle_before_rto () Int)
(declare-fun v_1_idle_before_cwnd () Int)
(declare-fun v_0_idle_last_data_ms () Int)
(declare-fun v_0_idle_data_valid () Bool)
(declare-fun v_1_idle_elapsed_ms () Int)
(declare-fun v_1_idle_restart () Bool)
(declare-fun v_1_idle_data_emitted () Bool)
(declare-fun v_1_idle_event_ms () Int)
(declare-fun v_1_idle_last_data_ms () Int)
(declare-fun v_1_idle_data_valid () Bool)
(declare-fun v_0_fr_entries () Int)
(declare-fun v_1_fr_entries () Int)
(declare-fun v_1_fr_emit_count () Int)
(declare-fun v_1_fr_retransmitted () Bool)
(declare-fun v_1_fr_exited () Bool)
(declare-fun v_1_fr_extra () Bool)
(declare-fun v_1_fr_entered () Bool)
(declare-fun v_1_fr_duplicate () Bool)
(declare-fun v_0_retries () Int)
(declare-fun v_1_fr_before_retries () Int)
(declare-fun v_1_fr_before_rto () Int)
(declare-fun v_1_fr_before_flight () Int)
(declare-fun v_0_fr_active () Bool)
(declare-fun v_1_fr_was_active () Bool)
(declare-fun v_0_fr_last_window () Int)
(declare-fun v_1_fr_last_window () Int)
(declare-fun v_0_fr_window_valid () Bool)
(declare-fun v_1_fr_window_valid () Bool)
(declare-fun v_0_fr_dupacks () Int)
(declare-fun v_1_fr_dupacks () Int)
(declare-fun v_1_fr_active () Bool)
(declare-fun v_1_fr_before_window_valid () Bool)
(declare-fun v_1_fr_before_wire_window () Int)
(declare-fun v_1_fr_window_ignored () Bool)
(declare-fun v_0_cc_rto_15 () Bool)
(declare-fun v_1_cc_rto_15 () Bool)
(declare-fun v_0_cc_rto_14 () Bool)
(declare-fun v_1_cc_rto_14 () Bool)
(declare-fun v_0_cc_rto_13 () Bool)
(declare-fun v_1_cc_rto_13 () Bool)
(declare-fun v_0_cc_rto_12 () Bool)
(declare-fun v_1_cc_rto_12 () Bool)
(declare-fun v_0_cc_rto_11 () Bool)
(declare-fun v_1_cc_rto_11 () Bool)
(declare-fun v_0_cc_rto_10 () Bool)
(declare-fun v_1_cc_rto_10 () Bool)
(declare-fun v_0_cc_rto_09 () Bool)
(declare-fun v_1_cc_rto_09 () Bool)
(declare-fun v_0_cc_rto_08 () Bool)
(declare-fun v_1_cc_rto_08 () Bool)
(declare-fun v_0_cc_rto_07 () Bool)
(declare-fun v_1_cc_rto_07 () Bool)
(declare-fun v_0_cc_rto_06 () Bool)
(declare-fun v_1_cc_rto_06 () Bool)
(declare-fun v_0_cc_rto_05 () Bool)
(declare-fun v_1_cc_rto_05 () Bool)
(declare-fun v_0_cc_rto_04 () Bool)
(declare-fun v_1_cc_rto_04 () Bool)
(declare-fun v_0_cc_rto_03 () Bool)
(declare-fun v_1_cc_rto_03 () Bool)
(declare-fun v_0_cc_rto_02 () Bool)
(declare-fun v_1_cc_rto_02 () Bool)
(declare-fun v_0_cc_rto_01 () Bool)
(declare-fun v_1_cc_rto_01 () Bool)
(declare-fun v_0_cc_rto_00 () Bool)
(declare-fun v_1_cc_rto_00 () Bool)
(declare-fun v_1_cc_new_sent () Int)
(declare-fun v_1_cc_send_budget () Int)
(declare-fun v_1_cc_before_cwnd () Int)
(declare-fun v_1_cc_growth () Int)
(declare-fun v_0_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_changed () Bool)
(declare-fun v_1_cc_loss () Bool)
(declare-fun v_1_cc_before_window () Int)
(declare-fun v_1_cc_before_persist () Bool)
(declare-fun v_1_cc_before_flight () Int)
(declare-fun v_1_cc_acked () Int)
(declare-fun v_0_cc_ca_credit () Int)
(declare-fun v_1_cc_ca_credit () Int)
(declare-fun v_1_cc_ssthresh () Int)
(declare-fun v_1_cc_cwnd () Int)
(declare-fun v_0_cc_initial_threshold () Int)
(declare-fun v_1_cc_initial_threshold () Int)
(declare-fun v_0_cc_initial_window () Int)
(declare-fun v_1_cc_initial_window () Int)
(declare-fun v_0_persist_elapsed_ms () Int)
(declare-fun v_1_persist_elapsed_ms () Int)
(declare-fun v_0_persist_probes () Int)
(declare-fun v_1_persist_probes () Int)
(declare-fun v_0_persist_deadline_ms () Int)
(declare-fun v_1_persist_deadline_ms () Int)
(declare-fun v_0_persist_last_ms () Int)
(declare-fun v_1_persist_last_ms () Int)
(declare-fun v_0_persist_since_ms () Int)
(declare-fun v_1_persist_since_ms () Int)
(declare-fun v_0_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_interval_ms () Int)
(declare-fun v_1_persist_probe_new () Bool)
(declare-fun v_1_persist_probe_sent () Bool)
(declare-fun v_1_persist_first () Bool)
(declare-fun v_1_persist_was_active () Bool)
(declare-fun v_1_persist_start () Bool)
(declare-fun v_1_persist_eligible () Bool)
(declare-fun v_1_persist_active () Bool)
(declare-fun v_1_ack_defer_now () Bool)
(declare-fun v_1_ack_defer_candidate () Bool)
(declare-fun v_0_ack_rmss () Int)
(declare-fun v_1_ack_rmss () Int)
(declare-fun v_0_ack_delay_ms () Int)
(declare-fun v_1_ack_delay_ms () Int)
(declare-fun v_0_ack_full_segments () Int)
(declare-fun v_1_ack_full_segments () Int)
(declare-fun v_0_ack_bytes () Int)
(declare-fun v_1_ack_bytes () Int)
(declare-fun v_0_ack_since_ms () Int)
(declare-fun v_1_ack_since_ms () Int)
(declare-fun v_0_ack_pending () Bool)
(declare-fun v_1_ack_pending () Bool)
(declare-fun v_1_syn_timeout_eligible () Bool)
(declare-fun v_1_tx_syn_pending () Bool)
(declare-fun v_1_tx_syn_time () Int)
(declare-fun v_1_tx_waiting () Bool)
(declare-fun v_1_tx_is_fin () Bool)
(declare-fun v_1_tx_previous_rto () Int)
(declare-fun v_1_tx_elapsed () Int)
(declare-fun v_1_tx_retransmitted () Bool)
(declare-fun v_1_tx_max_previous () Int)
(declare-fun v_1_tx_eligible () Int)
(declare-fun v_1_tx_emit_count () Int)
(declare-fun v_0_tx_fin_time () Int)
(declare-fun v_0_fin_acknowledged () Bool)
(declare-fun v_1_tx_fin_time () Int)
(declare-fun v_0_tx_time_15 () Int)
(declare-fun v_1_tx_time_15 () Int)
(declare-fun v_0_tx_time_14 () Int)
(declare-fun v_1_tx_time_14 () Int)
(declare-fun v_0_tx_time_13 () Int)
(declare-fun v_1_tx_time_13 () Int)
(declare-fun v_0_tx_time_12 () Int)
(declare-fun v_1_tx_time_12 () Int)
(declare-fun v_0_tx_time_11 () Int)
(declare-fun v_1_tx_time_11 () Int)
(declare-fun v_0_tx_time_10 () Int)
(declare-fun v_1_tx_time_10 () Int)
(declare-fun v_0_tx_time_09 () Int)
(declare-fun v_1_tx_time_09 () Int)
(declare-fun v_0_tx_time_08 () Int)
(declare-fun v_1_tx_time_08 () Int)
(declare-fun v_0_tx_time_07 () Int)
(declare-fun v_1_tx_time_07 () Int)
(declare-fun v_0_tx_time_06 () Int)
(declare-fun v_1_tx_time_06 () Int)
(declare-fun v_0_tx_time_05 () Int)
(declare-fun v_1_tx_time_05 () Int)
(declare-fun v_0_tx_time_04 () Int)
(declare-fun v_1_tx_time_04 () Int)
(declare-fun v_1_tx_time_03 () Int)
(declare-fun v_1_tx_time_02 () Int)
(declare-fun v_1_tx_time_01 () Int)
(declare-fun v_1_tx_time_00 () Int)
(declare-fun v_0_rto_base_ms () Int)
(declare-fun v_1_rto_base_ms () Int)
(declare-fun v_0_rtt_samples () Int)
(declare-fun v_1_rtt_samples () Int)
(declare-fun v_0_rtt_last_ms () Int)
(declare-fun v_1_rtt_last_ms () Int)
(declare-fun v_1_rtt_sample_was_ambiguous () Bool)
(declare-fun v_1_rtt_sample_used () Bool)
(declare-fun v_1_rtt_start_new () Bool)
(declare-fun v_0_rtt_remaining () Int)
(declare-fun v_1_rtt_remaining () Int)
(declare-fun v_0_rtt_start_ms () Int)
(declare-fun v_1_rtt_start_ms () Int)
(declare-fun v_0_rtt_sample_at_ms () Int)
(declare-fun v_1_rtt_sample_at_ms () Int)
(declare-fun v_0_rtt_active () Bool)
(declare-fun v_0_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_active () Bool)
(declare-fun v_0_rtt_previous_measured () Bool)
(declare-fun v_1_rtt_previous_measured () Bool)
(declare-fun v_0_rtt_measured () Bool)
(declare-fun v_1_rtt_measured () Bool)
(declare-fun v_0_rtt_previous_var () Real)
(declare-fun v_1_rtt_previous_var () Real)
(declare-fun v_0_rtt_previous_srtt () Real)
(declare-fun v_1_rtt_previous_srtt () Real)
(declare-fun v_0_rtt_error_ms () Real)
(declare-fun v_1_rtt_error_ms () Real)
(declare-fun v_0_rttvar_ms () Real)
(declare-fun v_1_rttvar_ms () Real)
(declare-fun v_0_srtt_ms () Real)
(declare-fun v_1_srtt_ms () Real)
(declare-fun v_0_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_consumed () Bool)
(declare-fun v_0_rx_fin_done () Bool)
(declare-fun v_1_rx_fin_done () Bool)
(declare-fun v_0_rx_fin_offset () Int)
(declare-fun v_1_rx_fin_offset () Int)
(declare-fun v_0_rx_fin_pending () Bool)
(declare-fun v_1_rx_fin_pending () Bool)
(declare-fun v_1_fin_acknowledged () Bool)
(declare-fun v_1_fin_sent () Bool)
(declare-fun v_0_fin_requested () Bool)
(declare-fun v_1_fin_requested () Bool)
(declare-fun v_0_ack_window_update () Bool)
(declare-fun v_1_ack_window_update () Bool)
(declare-fun v_0_ack_advance () Bool)
(declare-fun v_1_ack_advance () Bool)
(declare-fun v_0_ack_is_future () Bool)
(declare-fun v_1_ack_is_future () Bool)
(declare-fun v_0_ack_is_new () Bool)
(declare-fun v_1_ack_is_new () Bool)
(declare-fun v_0_ack_delta () Int)
(declare-fun v_1_ack_delta () Int)
(declare-fun v_0_seg_acceptable () Bool)
(declare-fun v_1_seg_acceptable () Bool)
(declare-fun v_0_rx_acceptable () Bool)
(declare-fun v_1_rx_acceptable () Bool)
(declare-fun v_0_rx_advance () Int)
(declare-fun v_1_rx_advance () Int)
(declare-fun v_0_take () Int)
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_1_local_window () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_0_tx_flags () String)
(declare-fun v_1_tx_flags () String)
(declare-fun v_0_rtt_sample_was_ambiguous () Bool)
(declare-fun v_0_rtt_sample_used () Bool)
(declare-fun v_0_tx_emit_count () Int)
(declare-fun v_0_tx_eligible () Int)
(declare-fun v_0_tx_previous_rto () Int)
(declare-fun v_0_tx_max_previous () Int)
(declare-fun v_0_tx_elapsed () Int)
(declare-fun v_0_tx_is_fin () Bool)
(declare-fun v_0_tx_retransmitted () Bool)
(declare-fun v_0_tx_waiting () Bool)
(declare-fun v_0_tx_syn_time () Int)
(declare-fun v_0_tx_syn_pending () Bool)
(declare-fun v_0_persist_probe_sent () Bool)
(declare-fun v_0_cc_acked () Int)
(declare-fun v_0_cc_growth () Int)
(declare-fun v_0_cc_send_budget () Int)
(declare-fun v_0_cc_new_sent () Int)
(declare-fun v_0_fr_emit_count () Int)
(declare-fun v_0_fr_before_retries () Int)
(declare-fun v_0_fr_before_rto () Int)
(declare-fun v_0_fr_entered () Bool)
(declare-fun v_0_fr_retransmitted () Bool)
(declare-fun v_0_fr_before_window_valid () Bool)
(declare-fun v_0_fr_before_wire_window () Int)
(declare-fun v_0_fr_window_ignored () Bool)
(declare-fun v_0_fr_exited () Bool)
(declare-fun v_0_idle_elapsed_ms () Int)
(declare-fun v_0_idle_event_ms () Int)
(declare-fun v_0_idle_data_emitted () Bool)
(declare-fun v_0_idle_before_threshold () Int)
(declare-fun v_0_idle_before_cwnd () Int)
(declare-fun v_0_idle_before_rto () Int)
(declare-fun v_0_idle_restart () Bool)
(declare-fun v_0_lt_loss_flight () Int)
(declare-fun v_0_lt_take () Int)
(declare-fun v_0_lt_before_flight () Int)
(declare-fun v_0_lt_before_cwnd () Int)
(declare-fun v_0_fr_duplicate () Bool)
(declare-fun v_0_lt_emitted () Bool)
(declare-fun v_0_lt_before_bytes () Int)
(declare-fun v_0_fr_before_flight () Int)
(declare-fun v_0_choice_used () Bool)
(declare-fun v_0_sched_bytes () Int)
(declare-fun v_0_sched_packets () Int)
(declare-fun v_0_sched_cause () Int)
(declare-fun v_0_sched_open () Bool)
(declare-fun v_0_svc_drop_step () Int)
(declare-fun v_0_svc_ack_step () Int)
(declare-fun v_0_svc_accept_step () Int)
(declare-fun v_0_cb_new_count () Int)
(declare-fun v_0_cb_live_total () Int)
(declare-fun v_0_cb_drop_step () Int)
(declare-fun v_0_cb_step_bytes () Int)
(declare-fun v_0_cb_partial_prefix () Int)
(declare-fun choice_0 () Int)
(declare-fun state_0 () Int)
(declare-fun state_1 () Int)
(assert
 (>= v_0_snd_buf 0))
(assert
 (>= v_0_rtx_buf 0))
(assert
 (>= v_0_rcv_buf 0))
(assert
 (>= v_0_rx_chunk 0))
(assert
 (>= v_0_rx_slot_00 0))
(assert
 (>= v_0_rx_slot_01 0))
(assert
 (>= v_0_rx_slot_02 0))
(assert
 (>= v_0_rx_slot_03 0))
(assert
 (>= v_0_rx_slot_04 0))
(assert
 (>= v_0_rx_slot_05 0))
(assert
 (>= v_0_rx_slot_06 0))
(assert
 (>= v_0_rx_slot_07 0))
(assert
 (>= v_0_rx_slot_08 0))
(assert
 (>= v_0_rx_slot_09 0))
(assert
 (>= v_0_rx_slot_10 0))
(assert
 (>= v_0_rx_slot_11 0))
(assert
 (>= v_0_rx_slot_12 0))
(assert
 (>= v_0_rx_slot_13 0))
(assert
 (>= v_0_rx_slot_14 0))
(assert
 (>= v_0_rx_slot_15 0))
(assert
 (>= v_1_snd_buf 0))
(assert
 (>= v_1_rtx_buf 0))
(assert
 (>= v_1_rcv_buf 0))
(assert
 (>= v_1_rx_chunk 0))
(assert
 (>= v_1_rx_slot_00 0))
(assert
 (>= v_1_rx_slot_01 0))
(assert
 (>= v_1_rx_slot_02 0))
(assert
 (>= v_1_rx_slot_03 0))
(assert
 (>= v_1_rx_slot_04 0))
(assert
 (>= v_1_rx_slot_05 0))
(assert
 (>= v_1_rx_slot_06 0))
(assert
 (>= v_1_rx_slot_07 0))
(assert
 (>= v_1_rx_slot_08 0))
(assert
 (>= v_1_rx_slot_09 0))
(assert
 (>= v_1_rx_slot_10 0))
(assert
 (>= v_1_rx_slot_11 0))
(assert
 (>= v_1_rx_slot_12 0))
(assert
 (>= v_1_rx_slot_13 0))
(assert
 (>= v_1_rx_slot_14 0))
(assert
 (>= v_1_rx_slot_15 0))
(assert
 (>= v_0_iss 0))
(assert
 (not (<= 4294967296 v_0_iss)))
(assert
 (>= v_0_irs 0))
(assert
 (not (<= 4294967296 v_0_irs)))
(assert
 (>= v_0_snd_una 0))
(assert
 (not (<= 4294967296 v_0_snd_una)))
(assert
 (>= v_0_snd_nxt 0))
(assert
 (not (<= 4294967296 v_0_snd_nxt)))
(assert
 (>= v_0_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_0_rcv_nxt)))
(assert
 (>= v_0_tx_seq 0))
(assert
 (not (<= 4294967296 v_0_tx_seq)))
(assert
 (>= v_0_tx_ack 0))
(assert
 (not (<= 4294967296 v_0_tx_ack)))
(assert
 (>= v_0_snd_wl1 0))
(assert
 (not (<= 4294967296 v_0_snd_wl1)))
(assert
 (>= v_0_snd_wl2 0))
(assert
 (not (<= 4294967296 v_0_snd_wl2)))
(assert
 (>= v_0_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_fin_seq)))
(assert
 (>= v_0_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_rx_fin_seq)))
(assert
 (>= v_0_rtt_end 0))
(assert
 (not (<= 4294967296 v_0_rtt_end)))
(assert
 (>= v_0_cc_before_una 0))
(assert
 (not (<= 4294967296 v_0_cc_before_una)))
(assert
 (>= v_0_fr_before_una 0))
(assert
 (not (<= 4294967296 v_0_fr_before_una)))
(assert
 (>= v_0_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_fr_before_nxt)))
(assert
 (>= v_0_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_lt_before_nxt)))
(assert
 (>= v_0_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_choice_before_nxt)))
(assert
 (>= v_0_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_cb_before_nxt)))
(assert
 (>= v_0_cb_append_end 0))
(assert
 (not (<= 4294967296 v_0_cb_append_end)))
(assert
 (>= v_0_cb_end_00 0))
(assert
 (not (<= 4294967296 v_0_cb_end_00)))
(assert
 (>= v_0_cb_end_01 0))
(assert
 (not (<= 4294967296 v_0_cb_end_01)))
(assert
 (>= v_0_cb_end_02 0))
(assert
 (not (<= 4294967296 v_0_cb_end_02)))
(assert
 (>= v_0_cb_end_03 0))
(assert
 (not (<= 4294967296 v_0_cb_end_03)))
(assert
 (>= v_0_cb_end_04 0))
(assert
 (not (<= 4294967296 v_0_cb_end_04)))
(assert
 (>= v_0_cb_end_05 0))
(assert
 (not (<= 4294967296 v_0_cb_end_05)))
(assert
 (>= v_0_cb_end_06 0))
(assert
 (not (<= 4294967296 v_0_cb_end_06)))
(assert
 (>= v_0_cb_end_07 0))
(assert
 (not (<= 4294967296 v_0_cb_end_07)))
(assert
 (>= v_0_cb_end_08 0))
(assert
 (not (<= 4294967296 v_0_cb_end_08)))
(assert
 (>= v_0_cb_end_09 0))
(assert
 (not (<= 4294967296 v_0_cb_end_09)))
(assert
 (>= v_0_cb_end_10 0))
(assert
 (not (<= 4294967296 v_0_cb_end_10)))
(assert
 (>= v_0_cb_end_11 0))
(assert
 (not (<= 4294967296 v_0_cb_end_11)))
(assert
 (>= v_0_cb_end_12 0))
(assert
 (not (<= 4294967296 v_0_cb_end_12)))
(assert
 (>= v_0_cb_end_13 0))
(assert
 (not (<= 4294967296 v_0_cb_end_13)))
(assert
 (>= v_0_cb_end_14 0))
(assert
 (not (<= 4294967296 v_0_cb_end_14)))
(assert
 (>= v_0_cb_end_15 0))
(assert
 (not (<= 4294967296 v_0_cb_end_15)))
(assert
 (>= v_1_iss 0))
(assert
 (not (<= 4294967296 v_1_iss)))
(assert
 (>= v_1_irs 0))
(assert
 (not (<= 4294967296 v_1_irs)))
(assert
 (>= v_1_snd_una 0))
(assert
 (not (<= 4294967296 v_1_snd_una)))
(assert
 (>= v_1_snd_nxt 0))
(assert
 (not (<= 4294967296 v_1_snd_nxt)))
(assert
 (>= v_1_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_1_rcv_nxt)))
(assert
 (>= v_1_tx_seq 0))
(assert
 (not (<= 4294967296 v_1_tx_seq)))
(assert
 (>= v_1_tx_ack 0))
(assert
 (not (<= 4294967296 v_1_tx_ack)))
(assert
 (>= v_1_snd_wl1 0))
(assert
 (not (<= 4294967296 v_1_snd_wl1)))
(assert
 (>= v_1_snd_wl2 0))
(assert
 (not (<= 4294967296 v_1_snd_wl2)))
(assert
 (>= v_1_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_fin_seq)))
(assert
 (>= v_1_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_rx_fin_seq)))
(assert
 (>= v_1_rtt_end 0))
(assert
 (not (<= 4294967296 v_1_rtt_end)))
(assert
 (>= v_1_cc_before_una 0))
(assert
 (not (<= 4294967296 v_1_cc_before_una)))
(assert
 (>= v_1_fr_before_una 0))
(assert
 (not (<= 4294967296 v_1_fr_before_una)))
(assert
 (>= v_1_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_fr_before_nxt)))
(assert
 (>= v_1_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_lt_before_nxt)))
(assert
 (>= v_1_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_choice_before_nxt)))
(assert
 (>= v_1_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_cb_before_nxt)))
(assert
 (>= v_1_cb_append_end 0))
(assert
 (not (<= 4294967296 v_1_cb_append_end)))
(assert
 (>= v_1_cb_end_00 0))
(assert
 (not (<= 4294967296 v_1_cb_end_00)))
(assert
 (>= v_1_cb_end_01 0))
(assert
 (not (<= 4294967296 v_1_cb_end_01)))
(assert
 (>= v_1_cb_end_02 0))
(assert
 (not (<= 4294967296 v_1_cb_end_02)))
(assert
 (>= v_1_cb_end_03 0))
(assert
 (not (<= 4294967296 v_1_cb_end_03)))
(assert
 (>= v_1_cb_end_04 0))
(assert
 (not (<= 4294967296 v_1_cb_end_04)))
(assert
 (>= v_1_cb_end_05 0))
(assert
 (not (<= 4294967296 v_1_cb_end_05)))
(assert
 (>= v_1_cb_end_06 0))
(assert
 (not (<= 4294967296 v_1_cb_end_06)))
(assert
 (>= v_1_cb_end_07 0))
(assert
 (not (<= 4294967296 v_1_cb_end_07)))
(assert
 (>= v_1_cb_end_08 0))
(assert
 (not (<= 4294967296 v_1_cb_end_08)))
(assert
 (>= v_1_cb_end_09 0))
(assert
 (not (<= 4294967296 v_1_cb_end_09)))
(assert
 (>= v_1_cb_end_10 0))
(assert
 (not (<= 4294967296 v_1_cb_end_10)))
(assert
 (>= v_1_cb_end_11 0))
(assert
 (not (<= 4294967296 v_1_cb_end_11)))
(assert
 (>= v_1_cb_end_12 0))
(assert
 (not (<= 4294967296 v_1_cb_end_12)))
(assert
 (>= v_1_cb_end_13 0))
(assert
 (not (<= 4294967296 v_1_cb_end_13)))
(assert
 (>= v_1_cb_end_14 0))
(assert
 (not (<= 4294967296 v_1_cb_end_14)))
(assert
 (>= v_1_cb_end_15 0))
(assert
 (not (<= 4294967296 v_1_cb_end_15)))
(assert
 true)
(assert
 true)
(assert
 (>= now_0 0))
(assert
 (let (($x370 (not active_0_rtx)))
 (or $x370 (>= due_0_rtx now_0))))
(assert
 (let (($x375 (not active_0_user)))
 (or $x375 (>= due_0_user now_0))))
(assert
 (let (($x380 (not active_0_time_wait)))
 (or $x380 (>= due_0_time_wait now_0))))
(assert
 (let (($x385 (not active_0_delack)))
 (or $x385 (>= due_0_delack now_0))))
(assert
 (let (($x390 (not active_0_persist)))
 (or $x390 (>= due_0_persist now_0))))
(assert
 (>= input_0_app.send_data 0))
(assert
 (>= input_0_net.data_data 0))
(assert
 (>= input_0_net.fin_segment_data 0))
(assert
 (>= input_0_net.syn_seq 0))
(assert
 (not (<= 4294967296 input_0_net.syn_seq)))
(assert
 (>= input_0_net.synack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.synack_seq)))
(assert
 (>= input_0_net.synack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.synack_ack)))
(assert
 (>= input_0_net.ack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.ack_seq)))
(assert
 (>= input_0_net.ack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.ack_ack)))
(assert
 (>= input_0_net.fin_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_seq)))
(assert
 (>= input_0_net.fin_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_ack)))
(assert
 (>= input_0_net.rst_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rst_seq)))
(assert
 (>= input_0_net.rstack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_seq)))
(assert
 (>= input_0_net.rstack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_ack)))
(assert
 (>= input_0_net.data_seq 0))
(assert
 (not (<= 4294967296 input_0_net.data_seq)))
(assert
 (>= input_0_net.data_ack 0))
(assert
 (not (<= 4294967296 input_0_net.data_ack)))
(assert
 (>= input_0_net.fin_segment_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_seq)))
(assert
 (>= input_0_net.fin_segment_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_ack)))
(assert
 (let ((?x522 (ite (>= v_0_rto_ms 30000) 60000 (* 2 v_0_rto_ms))))
 (let (($x492 (<= (+ v_0_tx_time_00 v_0_rto_ms) now_1)))
 (let (($x459 (<= 1 v_0_rtx_buf)))
 (let (($x497 (<= (+ v_0_tx_time_01 v_0_rto_ms) now_1)))
 (let (($x494 (<= 2 v_0_rtx_buf)))
 (let ((?x512 (ite (and $x459 $x492 $x494 $x497) 2 (ite (and $x459 $x492) 1 0))))
 (let (($x502 (<= (+ v_0_tx_time_02 v_0_rto_ms) now_1)))
 (let (($x499 (<= 3 v_0_rtx_buf)))
 (let (($x507 (and $x459 $x492 $x494 $x497 $x499 $x502 (<= 4 v_0_rtx_buf) (<= (+ v_0_tx_time_03 v_0_rto_ms) now_1))))
 (let ((?x514 (ite $x507 4 (ite (and $x459 $x492 $x494 $x497 $x499 $x502) 3 ?x512))))
 (let (($x485 (<= v_0_rtx_buf v_0_snd_wnd)))
 (let ((?x486 (ite $x485 v_0_rtx_buf v_0_snd_wnd)))
 (let ((?x488 (ite (<= 4 ?x486) 4 ?x486)))
 (let ((?x516 (ite (<= ?x488 ?x514) ?x488 ?x514)))
 (let (($x517 (<= 1 ?x516)))
 (let ((?x523 (ite $x517 ?x522 v_0_rto_ms)))
 (let (($x891 (not v_0_persist_active)))
 (let (($x644 (= 0 v_0_rtx_buf)))
 (let (($x645 (or v_0_persist_active $x644)))
 (let (($x642 (>= 1 v_0_rtx_buf)))
 (let (($x641 (<= 1 (+ v_0_rtx_buf v_0_snd_buf))))
 (let (($x639 (not v_0_fin_sent)))
 (let (($x638 (= 0 v_0_snd_wnd)))
 (let (($x892 (and $x638 $x639 $x641 $x642 $x645 $x891)))
 (let ((?x904 (ite $x892 ?x523 v_0_persist_interval_ms)))
 (let ((?x921 (+ now_1 ?x904)))
 (let (($x1496 (= due_1_delack due_0_delack)))
 (let (($x1494 (= due_1_time_wait due_0_time_wait)))
 (let (($x1492 (= due_1_user due_0_user)))
 (let ((?x1487 (ite $x517 ?x522 (+ (ite $x517 now_1 v_0_tx_time_00) ?x523 (* (- 1) now_1)))))
 (let (($x646 (and $x638 $x639 $x641 $x642 $x645)))
 (let (($x647 (not $x646)))
 (let (($x1469 (and v_0_persist_active $x647 $x459 $x638 $x639 $x641 $x642 $x645)))
 (let (($x1482 (= active_1_persist (and $x638 $x639 $x641 $x642 $x645 (or active_0_persist $x892)))))
 (let (($x1475 (= active_1_time_wait active_0_time_wait)))
 (let (($x1473 (= active_1_user active_0_user)))
 (let (($x1467 (not v_1_cb_done_15)))
 (let ((?x663 (ite (<= 0 ?x516) ?x516 0)))
 (let (($x660 (<= v_0_rtx_buf 0)))
 (let ((?x661 (ite $x660 0 v_0_rtx_buf)))
 (let ((?x665 (ite (<= ?x661 ?x663) ?x661 ?x663)))
 (let (($x1262 (= v_0_snd_una v_0_snd_nxt)))
 (let (($x1156 (<= 1 ?x665)))
 (let (($x1263 (and $x517 $x1156 $x1262)))
 (let ((?x1368 (ite $x1263 (mod (+ v_0_snd_una ?x665) 4294967296) 0)))
 (let (($x1345 (and $x517 $x1156 $x1262 (= 15 v_0_cb_tail))))
 (let ((?x1277 (ite $x1263 ?x665 0)))
 (let ((?x1347 (ite $x1345 ?x1277 v_0_cb_length_15)))
 (let (($x1461 (not v_1_cb_done_14)))
 (let (($x1459 (= v_1_cb_end_14 (ite (and $x517 $x1156 $x1262 (= 14 v_0_cb_tail)) ?x1368 v_0_cb_end_14))))
 (let (($x1341 (and $x517 $x1156 $x1262 (= 14 v_0_cb_tail))))
 (let ((?x1343 (ite $x1341 ?x1277 v_0_cb_length_14)))
 (let (($x1455 (not v_1_cb_done_13)))
 (let (($x1453 (= v_1_cb_end_13 (ite (and $x517 $x1156 $x1262 (= 13 v_0_cb_tail)) ?x1368 v_0_cb_end_13))))
 (let (($x1337 (and $x517 $x1156 $x1262 (= 13 v_0_cb_tail))))
 (let ((?x1339 (ite $x1337 ?x1277 v_0_cb_length_13)))
 (let (($x1449 (not v_1_cb_done_12)))
 (let (($x1447 (= v_1_cb_end_12 (ite (and $x517 $x1156 $x1262 (= 12 v_0_cb_tail)) ?x1368 v_0_cb_end_12))))
 (let (($x1333 (and $x517 $x1156 $x1262 (= 12 v_0_cb_tail))))
 (let ((?x1335 (ite $x1333 ?x1277 v_0_cb_length_12)))
 (let (($x1443 (not v_1_cb_done_11)))
 (let (($x1441 (= v_1_cb_end_11 (ite (and $x517 $x1156 $x1262 (= 11 v_0_cb_tail)) ?x1368 v_0_cb_end_11))))
 (let (($x1329 (and $x517 $x1156 $x1262 (= 11 v_0_cb_tail))))
 (let ((?x1331 (ite $x1329 ?x1277 v_0_cb_length_11)))
 (let (($x1437 (not v_1_cb_done_10)))
 (let (($x1435 (= v_1_cb_end_10 (ite (and $x517 $x1156 $x1262 (= 10 v_0_cb_tail)) ?x1368 v_0_cb_end_10))))
 (let (($x1325 (and $x517 $x1156 $x1262 (= 10 v_0_cb_tail))))
 (let ((?x1327 (ite $x1325 ?x1277 v_0_cb_length_10)))
 (let (($x1431 (not v_1_cb_done_09)))
 (let (($x1429 (= v_1_cb_end_09 (ite (and $x517 $x1156 $x1262 (= 9 v_0_cb_tail)) ?x1368 v_0_cb_end_09))))
 (let (($x1321 (and $x517 $x1156 $x1262 (= 9 v_0_cb_tail))))
 (let ((?x1323 (ite $x1321 ?x1277 v_0_cb_length_09)))
 (let (($x1425 (not v_1_cb_done_08)))
 (let (($x1423 (= v_1_cb_end_08 (ite (and $x517 $x1156 $x1262 (= 8 v_0_cb_tail)) ?x1368 v_0_cb_end_08))))
 (let (($x1317 (and $x517 $x1156 $x1262 (= 8 v_0_cb_tail))))
 (let ((?x1319 (ite $x1317 ?x1277 v_0_cb_length_08)))
 (let (($x1419 (not v_1_cb_done_07)))
 (let (($x1417 (= v_1_cb_end_07 (ite (and $x517 $x1156 $x1262 (= 7 v_0_cb_tail)) ?x1368 v_0_cb_end_07))))
 (let (($x1313 (and $x517 $x1156 $x1262 (= 7 v_0_cb_tail))))
 (let ((?x1315 (ite $x1313 ?x1277 v_0_cb_length_07)))
 (let (($x1413 (not v_1_cb_done_06)))
 (let (($x1411 (= v_1_cb_end_06 (ite (and $x517 $x1156 $x1262 (= 6 v_0_cb_tail)) ?x1368 v_0_cb_end_06))))
 (let (($x1309 (and $x517 $x1156 $x1262 (= 6 v_0_cb_tail))))
 (let ((?x1311 (ite $x1309 ?x1277 v_0_cb_length_06)))
 (let (($x1407 (not v_1_cb_done_05)))
 (let (($x1405 (= v_1_cb_end_05 (ite (and $x517 $x1156 $x1262 (= 5 v_0_cb_tail)) ?x1368 v_0_cb_end_05))))
 (let (($x1305 (and $x517 $x1156 $x1262 (= 5 v_0_cb_tail))))
 (let ((?x1307 (ite $x1305 ?x1277 v_0_cb_length_05)))
 (let (($x1401 (not v_1_cb_done_04)))
 (let (($x1399 (= v_1_cb_end_04 (ite (and $x517 $x1156 $x1262 (= 4 v_0_cb_tail)) ?x1368 v_0_cb_end_04))))
 (let (($x1301 (and $x517 $x1156 $x1262 (= 4 v_0_cb_tail))))
 (let ((?x1303 (ite $x1301 ?x1277 v_0_cb_length_04)))
 (let (($x1395 (not v_1_cb_done_03)))
 (let (($x1393 (= v_1_cb_end_03 (ite (and $x517 $x1156 $x1262 (= 3 v_0_cb_tail)) ?x1368 v_0_cb_end_03))))
 (let (($x1297 (and $x517 $x1156 $x1262 (= 3 v_0_cb_tail))))
 (let ((?x1299 (ite $x1297 ?x1277 v_0_cb_length_03)))
 (let (($x1389 (not v_1_cb_done_02)))
 (let (($x1387 (= v_1_cb_end_02 (ite (and $x517 $x1156 $x1262 (= 2 v_0_cb_tail)) ?x1368 v_0_cb_end_02))))
 (let (($x1293 (and $x517 $x1156 $x1262 (= 2 v_0_cb_tail))))
 (let ((?x1295 (ite $x1293 ?x1277 v_0_cb_length_02)))
 (let (($x1383 (not v_1_cb_done_01)))
 (let (($x1381 (= v_1_cb_end_01 (ite (and $x517 $x1156 $x1262 (= 1 v_0_cb_tail)) ?x1368 v_0_cb_end_01))))
 (let (($x1289 (and $x517 $x1156 $x1262 (= 1 v_0_cb_tail))))
 (let ((?x1291 (ite $x1289 ?x1277 v_0_cb_length_01)))
 (let (($x1377 (not v_1_cb_done_00)))
 (let (($x1375 (= v_1_cb_end_00 (ite (and $x517 $x1156 $x1262 (= 0 v_0_cb_tail)) ?x1368 v_0_cb_end_00))))
 (let (($x1285 (and $x517 $x1156 $x1262 (= 0 v_0_cb_tail))))
 (let ((?x1287 (ite $x1285 ?x1277 v_0_cb_length_00)))
 (let (($x1371 (not v_1_cb_is_new)))
 (let (($x1365 (= v_1_cb_before_nxt v_0_snd_nxt)))
 (let (($x1364 (= v_1_cb_drop_step 0)))
 (let (($x1362 (= v_1_cb_abandoned_total v_0_cb_abandoned_total)))
 (let (($x1359 (= v_1_cb_acked_total v_0_cb_acked_total)))
 (let ((?x653 (- 1)))
 (let ((?x990 (* ?x653 v_0_rtx_buf)))
 (let ((?x1351 (+ ?x1287 ?x1291 ?x1295 ?x1299 ?x1303 ?x1307 ?x1311 ?x1315 ?x1319 ?x1323 ?x1327 ?x1331 ?x1335 ?x1339 ?x1343 ?x1347 ?x990)))
 (let ((?x1348 (+ ?x1287 ?x1291 ?x1295 ?x1299 ?x1303 ?x1307 ?x1311 ?x1315 ?x1319 ?x1323 ?x1327 ?x1331 ?x1335 ?x1339 ?x1343 ?x1347)))
 (let (($x1282 (= v_1_cb_step_bytes 0)))
 (let (($x1280 (= v_1_cb_retired_count 0)))
 (let ((?x1264 (ite $x1263 1 0)))
 (let ((?x1265 (+ v_0_cb_tail ?x1264)))
 (let (($x1269 (= v_1_cb_tail (ite (<= 16 ?x1265) (+ (- 16) v_0_cb_tail ?x1264) ?x1265))))
 (let (($x1259 (= v_1_cb_head (ite (<= 16 v_0_cb_head) (+ (- 16) v_0_cb_head) v_0_cb_head))))
 (let (($x1252 (= v_1_svc_abandoned_bytes v_0_svc_abandoned_bytes)))
 (let (($x1249 (= v_1_svc_acked_bytes v_0_svc_acked_bytes)))
 (let (($x1246 (= v_1_svc_written_bytes v_0_svc_written_bytes)))
 (let (($x1243 (= v_1_svc_drop_step 0)))
 (let (($x1228 (= v_1_sched_at_ms v_0_sched_at_ms)))
 (let (($x1225 (not v_1_sched_open)))
 (let (($x1223 (= v_1_choice_before_flight v_0_choice_before_flight)))
 (let (($x1220 (= v_1_choice_before_nxt v_0_choice_before_nxt)))
 (let (($x1219 (= v_1_choice_limit v_0_choice_limit)))
 (let (($x1216 (= v_1_choice_count v_0_choice_count)))
 (let (($x1213 (not v_1_choice_used)))
 (let (($x1207 (= v_1_lt_before_window v_0_snd_wnd)))
 (let (($x1205 (= v_1_lt_before_flight v_0_rtx_buf)))
 (let (($x1203 (= v_1_lt_before_nxt v_0_snd_nxt)))
 (let (($x1202 (= v_1_lt_before_cwnd v_0_cc_cwnd)))
 (let (($x1200 (= v_1_lt_before_bytes v_0_lt_epoch_bytes)))
 (let (($x461 (<= 1 v_0_snd_wnd)))
 (let (($x940 (and $x459 $x461 $x517)))
 (let (($x1191 (or $x644 $x646 $x940)))
 (let (($x1187 (not v_1_lt_emitted)))
 (let (($x1185 (not v_1_lt_eligible)))
 (let (($x1183 (= v_1_idle_restart_count v_0_idle_restart_count)))
 (let (($x1180 (= v_1_idle_before_threshold v_0_cc_ssthresh)))
 (let (($x1178 (= v_1_idle_before_rto v_0_rto_ms)))
 (let (($x1176 (= v_1_idle_before_cwnd v_0_cc_cwnd)))
 (let ((?x1173 (ite v_0_idle_data_valid (+ now_1 (* ?x653 v_0_idle_last_data_ms)) 0)))
 (let (($x1169 (not v_1_idle_restart)))
 (let (($x1165 (= v_1_idle_event_ms now_1)))
 (let (($x1163 (= v_1_idle_last_data_ms (ite (and $x517 $x1156) now_1 v_0_idle_last_data_ms))))
 (let (($x1153 (= v_1_fr_entries v_0_fr_entries)))
 (let (($x1150 (= v_1_fr_emit_count 0)))
 (let (($x1148 (not v_1_fr_retransmitted)))
 (let (($x1146 (not v_1_fr_exited)))
 (let (($x1144 (not v_1_fr_extra)))
 (let (($x1142 (not v_1_fr_entered)))
 (let (($x1140 (not v_1_fr_duplicate)))
 (let (($x1138 (= v_1_fr_before_retries v_0_retries)))
 (let (($x1136 (= v_1_fr_before_rto v_0_rto_ms)))
 (let (($x1134 (= v_1_fr_before_flight v_0_rtx_buf)))
 (let (($x1132 (= v_1_fr_before_nxt v_0_snd_nxt)))
 (let (($x1131 (= v_1_fr_before_una v_0_snd_una)))
 (let (($x1130 (= v_1_fr_was_active v_0_fr_active)))
 (let (($x1128 (= v_1_fr_last_window v_0_fr_last_window)))
 (let (($x1126 (= v_1_fr_window_valid v_0_fr_window_valid)))
 (let (($x1114 (= v_1_fr_before_window_valid v_0_fr_window_valid)))
 (let (($x1111 (= v_1_fr_before_wire_window v_0_fr_last_window)))
 (let (($x1108 (not v_1_fr_window_ignored)))
 (let (($x808 (>= 15 v_0_rtx_buf)))
 (let (($x1101 (not $x808)))
 (let (($x1106 (= v_1_cc_rto_15 (and $x1101 (or v_0_cc_rto_15 (and $x459 $x461 $x517 (<= 16 ?x516)))))))
 (let (($x800 (>= 14 v_0_rtx_buf)))
 (let (($x1094 (not $x800)))
 (let (($x1099 (= v_1_cc_rto_14 (and $x1094 (or v_0_cc_rto_14 (and $x459 $x461 $x517 (<= 15 ?x516)))))))
 (let (($x792 (>= 13 v_0_rtx_buf)))
 (let (($x1087 (not $x792)))
 (let (($x1092 (= v_1_cc_rto_13 (and $x1087 (or v_0_cc_rto_13 (and $x459 $x461 $x517 (<= 14 ?x516)))))))
 (let (($x784 (>= 12 v_0_rtx_buf)))
 (let (($x1080 (not $x784)))
 (let (($x1085 (= v_1_cc_rto_12 (and $x1080 (or v_0_cc_rto_12 (and $x459 $x461 $x517 (<= 13 ?x516)))))))
 (let (($x776 (>= 11 v_0_rtx_buf)))
 (let (($x1073 (not $x776)))
 (let (($x1078 (= v_1_cc_rto_11 (and $x1073 (or v_0_cc_rto_11 (and $x459 $x461 $x517 (<= 12 ?x516)))))))
 (let (($x768 (>= 10 v_0_rtx_buf)))
 (let (($x1066 (not $x768)))
 (let (($x1071 (= v_1_cc_rto_10 (and $x1066 (or v_0_cc_rto_10 (and $x459 $x461 $x517 (<= 11 ?x516)))))))
 (let (($x760 (>= 9 v_0_rtx_buf)))
 (let (($x1059 (not $x760)))
 (let (($x1064 (= v_1_cc_rto_09 (and $x1059 (or v_0_cc_rto_09 (and $x459 $x461 $x517 (<= 10 ?x516)))))))
 (let (($x752 (>= 8 v_0_rtx_buf)))
 (let (($x1052 (not $x752)))
 (let (($x1057 (= v_1_cc_rto_08 (and $x1052 (or v_0_cc_rto_08 (and $x459 $x461 $x517 (<= 9 ?x516)))))))
 (let (($x744 (>= 7 v_0_rtx_buf)))
 (let (($x1045 (not $x744)))
 (let (($x1050 (= v_1_cc_rto_07 (and $x1045 (or v_0_cc_rto_07 (and $x459 $x461 $x517 (<= 8 ?x516)))))))
 (let (($x736 (>= 6 v_0_rtx_buf)))
 (let (($x1038 (not $x736)))
 (let (($x1043 (= v_1_cc_rto_06 (and $x1038 (or v_0_cc_rto_06 (and $x459 $x461 $x517 (<= 7 ?x516)))))))
 (let (($x728 (>= 5 v_0_rtx_buf)))
 (let (($x1031 (not $x728)))
 (let (($x1036 (= v_1_cc_rto_05 (and $x1031 (or v_0_cc_rto_05 (and $x459 $x461 $x517 (<= 6 ?x516)))))))
 (let (($x720 (>= 4 v_0_rtx_buf)))
 (let (($x1024 (not $x720)))
 (let (($x1029 (= v_1_cc_rto_04 (and $x1024 (or v_0_cc_rto_04 (and $x459 $x461 $x517 (<= 5 ?x516)))))))
 (let (($x714 (>= 3 v_0_rtx_buf)))
 (let (($x1017 (not $x714)))
 (let (($x1022 (= v_1_cc_rto_03 (and $x1017 (or v_0_cc_rto_03 (and $x459 $x461 $x517 (<= 4 ?x516)))))))
 (let (($x708 (>= 2 v_0_rtx_buf)))
 (let (($x1010 (not $x708)))
 (let (($x1015 (= v_1_cc_rto_02 (and $x1010 (or v_0_cc_rto_02 (and $x459 $x461 $x517 (<= 3 ?x516)))))))
 (let (($x1003 (not $x642)))
 (let (($x1008 (= v_1_cc_rto_01 (and $x1003 (or v_0_cc_rto_01 (and $x459 $x461 $x517 (<= 2 ?x516)))))))
 (let (($x1001 (= v_1_cc_rto_00 (and (not (>= 0 v_0_rtx_buf)) (or v_0_cc_rto_00 $x940)))))
 (let ((?x991 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd) ?x990)))
 (let (($x986 (= v_1_cc_before_cwnd v_0_cc_cwnd)))
 (let ((?x981 (+ v_0_cc_threshold_updates (ite (and $x459 $x461 $x517 (not v_0_cc_rto_00)) 1 0))))
 (let (($x946 (not v_0_cc_rto_00)))
 (let (($x947 (and $x459 $x461 $x517 $x946)))
 (let (($x973 (= v_1_cc_before_window v_0_snd_wnd)))
 (let (($x971 (= v_1_cc_before_persist v_0_persist_active)))
 (let (($x969 (= v_1_cc_before_una v_0_snd_una)))
 (let (($x968 (= v_1_cc_before_flight v_0_rtx_buf)))
 (let ((?x955 (+ v_0_rtx_buf (to_int (* (- (/ 1.0 2.0)) (to_real v_0_rtx_buf))))))
 (let (($x960 (= v_1_cc_ssthresh (ite $x947 (ite (<= 8 ?x955) ?x955 8) v_0_cc_ssthresh))))
 (let (($x938 (= v_1_cc_initial_threshold v_0_cc_initial_threshold)))
 (let (($x935 (= v_1_cc_initial_window v_0_cc_initial_window)))
 (let (($x932 (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)))
 (let (($x925 (= v_1_persist_deadline_ms (ite $x646 (ite $x892 ?x921 v_0_persist_deadline_ms) 0))))
 (let (($x915 (= v_1_persist_since_ms (ite $x646 (ite $x892 now_1 v_0_persist_since_ms) 0))))
 (let (($x910 (= v_1_persist_previous_interval_ms v_0_persist_previous_interval_ms)))
 (let (($x901 (not v_1_persist_probe_new)))
 (let (($x899 (not v_1_persist_probe_sent)))
 (let (($x897 (not v_1_persist_first)))
 (let (($x895 (= v_1_persist_was_active v_0_persist_active)))
 (let (($x885 (not v_1_ack_defer_now)))
 (let (($x883 (not v_1_ack_defer_candidate)))
 (let (($x881 (= v_1_ack_rmss v_0_ack_rmss)))
 (let (($x878 (= v_1_ack_delay_ms v_0_ack_delay_ms)))
 (let (($x858 (not v_1_syn_timeout_eligible)))
 (let (($x856 (not v_1_tx_syn_pending)))
 (let (($x854 (= v_1_tx_syn_time 0)))
 (let (($x849 (not v_1_tx_is_fin)))
 (let (($x847 (= v_1_tx_previous_rto v_0_rto_ms)))
 (let ((?x828 (ite (and $x517 (<= 0 v_0_tx_time_00)) v_0_tx_time_00 0)))
 (let ((?x831 (ite (and (<= 2 ?x516) (>= v_0_tx_time_01 ?x828)) v_0_tx_time_01 ?x828)))
 (let ((?x834 (ite (and (<= 3 ?x516) (>= v_0_tx_time_02 ?x831)) v_0_tx_time_02 ?x831)))
 (let ((?x837 (ite (and (<= 4 ?x516) (>= v_0_tx_time_03 ?x834)) v_0_tx_time_03 ?x834)))
 (let ((?x819 (ite (and v_0_fin_sent (not v_0_fin_acknowledged)) v_0_tx_fin_time 0)))
 (let (($x820 (= v_1_tx_fin_time ?x819)))
 (let (($x814 (= v_1_tx_time_15 (ite $x808 0 (ite (<= 16 ?x516) now_1 v_0_tx_time_15)))))
 (let (($x806 (= v_1_tx_time_14 (ite $x800 0 (ite (<= 15 ?x516) now_1 v_0_tx_time_14)))))
 (let (($x798 (= v_1_tx_time_13 (ite $x792 0 (ite (<= 14 ?x516) now_1 v_0_tx_time_13)))))
 (let (($x790 (= v_1_tx_time_12 (ite $x784 0 (ite (<= 13 ?x516) now_1 v_0_tx_time_12)))))
 (let (($x782 (= v_1_tx_time_11 (ite $x776 0 (ite (<= 12 ?x516) now_1 v_0_tx_time_11)))))
 (let (($x774 (= v_1_tx_time_10 (ite $x768 0 (ite (<= 11 ?x516) now_1 v_0_tx_time_10)))))
 (let (($x766 (= v_1_tx_time_09 (ite $x760 0 (ite (<= 10 ?x516) now_1 v_0_tx_time_09)))))
 (let (($x758 (= v_1_tx_time_08 (ite $x752 0 (ite (<= 9 ?x516) now_1 v_0_tx_time_08)))))
 (let (($x750 (= v_1_tx_time_07 (ite $x744 0 (ite (<= 8 ?x516) now_1 v_0_tx_time_07)))))
 (let (($x742 (= v_1_tx_time_06 (ite $x736 0 (ite (<= 7 ?x516) now_1 v_0_tx_time_06)))))
 (let (($x734 (= v_1_tx_time_05 (ite $x728 0 (ite (<= 6 ?x516) now_1 v_0_tx_time_05)))))
 (let (($x726 (= v_1_tx_time_04 (ite $x720 0 (ite (<= 5 ?x516) now_1 v_0_tx_time_04)))))
 (let (($x718 (= v_1_tx_time_03 (ite $x714 0 (ite (<= 4 ?x516) now_1 v_0_tx_time_03)))))
 (let (($x712 (= v_1_tx_time_02 (ite $x708 0 (ite (<= 3 ?x516) now_1 v_0_tx_time_02)))))
 (let (($x706 (= v_1_tx_time_01 (ite $x642 0 (ite (<= 2 ?x516) now_1 v_0_tx_time_01)))))
 (let (($x701 (= v_1_tx_time_00 (ite (>= 0 v_0_rtx_buf) 0 (ite $x517 now_1 v_0_tx_time_00)))))
 (let (($x696 (= v_1_rto_base_ms v_0_rto_base_ms)))
 (let (($x693 (= v_1_rtt_samples v_0_rtt_samples)))
 (let (($x690 (= v_1_rtt_last_ms v_0_rtt_last_ms)))
 (let (($x687 (not v_1_rtt_sample_was_ambiguous)))
 (let (($x685 (not v_1_rtt_sample_used)))
 (let (($x683 (not v_1_rtt_start_new)))
 (let (($x678 (= v_1_rtt_end v_0_rtt_end)))
 (let (($x677 (= v_1_rtt_start_ms v_0_rtt_start_ms)))
 (let (($x674 (= v_1_rtt_sample_at_ms v_0_rtt_sample_at_ms)))
 (let ((?x656 (mod (+ v_0_rtt_end (* ?x653 v_0_snd_una)) 4294967296)))
 (let (($x668 (and v_0_rtt_active (<= (+ ?x656 (* ?x653 v_0_rtt_remaining)) (+ ?x653 ?x665)))))
 (let (($x636 (= v_1_rtt_previous_measured v_0_rtt_previous_measured)))
 (let (($x633 (= v_1_rtt_measured v_0_rtt_measured)))
 (let (($x630 (= v_1_rtt_previous_var v_0_rtt_previous_var)))
 (let (($x627 (= v_1_rtt_previous_srtt v_0_rtt_previous_srtt)))
 (let (($x624 (= v_1_rtt_error_ms v_0_rtt_error_ms)))
 (let (($x621 (= v_1_rttvar_ms v_0_rttvar_ms)))
 (let (($x618 (= v_1_srtt_ms v_0_srtt_ms)))
 (let (($x615 (= v_1_rx_fin_consumed v_0_rx_fin_consumed)))
 (let (($x612 (= v_1_rx_fin_done v_0_rx_fin_done)))
 (let (($x609 (= v_1_rx_fin_offset v_0_rx_fin_offset)))
 (let (($x606 (= v_1_rx_fin_seq v_0_rx_fin_seq)))
 (let (($x605 (= v_1_rx_fin_pending v_0_rx_fin_pending)))
 (let (($x602 (= v_1_fin_acknowledged v_0_fin_acknowledged)))
 (let (($x599 (= v_1_fin_seq v_0_fin_seq)))
 (let (($x598 (= v_1_fin_sent v_0_fin_sent)))
 (let (($x595 (= v_1_fin_requested v_0_fin_requested)))
 (let (($x592 (= v_1_ack_window_update v_0_ack_window_update)))
 (let (($x589 (= v_1_ack_advance v_0_ack_advance)))
 (let (($x586 (= v_1_ack_is_future v_0_ack_is_future)))
 (let (($x583 (= v_1_ack_is_new v_0_ack_is_new)))
 (let (($x580 (= v_1_ack_delta v_0_ack_delta)))
 (let (($x577 (= v_1_seg_acceptable v_0_seg_acceptable)))
 (let (($x574 (= v_1_rx_acceptable v_0_rx_acceptable)))
 (let (($x571 (= v_1_rx_advance v_0_rx_advance)))
 (let (($x568 (= v_1_rx_slot_15 v_0_rx_slot_15)))
 (let (($x567 (= v_1_rx_slot_14 v_0_rx_slot_14)))
 (let (($x566 (= v_1_rx_slot_13 v_0_rx_slot_13)))
 (let (($x565 (= v_1_rx_slot_12 v_0_rx_slot_12)))
 (let (($x564 (= v_1_rx_slot_11 v_0_rx_slot_11)))
 (let (($x563 (= v_1_rx_slot_10 v_0_rx_slot_10)))
 (let (($x562 (= v_1_rx_slot_09 v_0_rx_slot_09)))
 (let (($x561 (= v_1_rx_slot_08 v_0_rx_slot_08)))
 (let (($x560 (= v_1_rx_slot_07 v_0_rx_slot_07)))
 (let (($x559 (= v_1_rx_slot_06 v_0_rx_slot_06)))
 (let (($x558 (= v_1_rx_slot_05 v_0_rx_slot_05)))
 (let (($x557 (= v_1_rx_slot_04 v_0_rx_slot_04)))
 (let (($x556 (= v_1_rx_slot_03 v_0_rx_slot_03)))
 (let (($x555 (= v_1_rx_slot_02 v_0_rx_slot_02)))
 (let (($x554 (= v_1_rx_slot_01 v_0_rx_slot_01)))
 (let (($x553 (= v_1_rx_slot_00 v_0_rx_slot_00)))
 (let (($x552 (= v_1_rx_chunk v_0_rx_chunk)))
 (let (($x551 (= v_1_take v_0_take)))
 (let (($x548 (= v_1_snd_wl2 v_0_snd_wl2)))
 (let (($x547 (= v_1_snd_wl1 v_0_snd_wl1)))
 (let (($x546 (= v_1_snd_wnd v_0_snd_wnd)))
 (let (($x544 (= v_1_rcv_buf v_0_rcv_buf)))
 (let (($x543 (= v_1_rtx_buf v_0_rtx_buf)))
 (let (($x542 (= v_1_snd_buf v_0_snd_buf)))
 (let (($x541 (= v_1_local_window v_0_local_window)))
 (let (($x538 (= v_1_msl_ms v_0_msl_ms)))
 (let (($x535 (= v_1_user_timeout_ms v_0_user_timeout_ms)))
 (let (($x532 (= v_1_active_open v_0_active_open)))
 (let (($x482 (= v_1_tx_flags v_0_tx_flags)))
 (let (($x479 (= v_1_tx_ack v_0_tx_ack)))
 (let (($x478 (= v_1_tx_seq v_0_tx_seq)))
 (let (($x477 (= v_1_rcv_nxt v_0_rcv_nxt)))
 (let (($x476 (= v_1_snd_nxt v_0_snd_nxt)))
 (let (($x475 (= v_1_snd_una v_0_snd_una)))
 (let (($x474 (= v_1_irs v_0_irs)))
 (let (($x473 (= v_1_iss v_0_iss)))
 (let (($x462 (= now_1 due_0_rtx)))
 (and (>= now_1 now_0) $x459 $x461 active_0_rtx $x462 (or (not active_0_user) (<= due_0_rtx due_0_user)) (or (not active_0_time_wait) (<= due_0_rtx due_0_time_wait)) (or (not active_0_delack) (not (<= due_0_delack due_0_rtx))) (or (not active_0_persist) (not (<= due_0_persist due_0_rtx))) $x473 $x474 $x475 $x476 $x477 $x478 $x479 $x482 (= v_1_rto_ms ?x523) (= v_1_retries (ite $x517 (+ 1 v_0_retries) v_0_retries)) $x532 $x535 $x538 $x541 $x542 $x543 $x544 $x546 $x547 $x548 $x551 $x552 $x553 $x554 $x555 $x556 $x557 $x558 $x559 $x560 $x561 $x562 $x563 $x564 $x565 $x566 $x567 $x568 $x571 $x574 $x577 $x580 $x583 $x586 $x589 $x592 $x595 $x598 $x599 $x602 $x605 $x606 $x609 $x612 $x615 $x618 $x621 $x624 $x627 $x630 $x633 $x636 (= v_1_rtt_active (and $x647 v_0_rtt_active)) (= v_1_rtt_ambiguous (and $x647 (or v_0_rtt_ambiguous $x668))) $x674 $x677 $x678 (= v_1_rtt_remaining (ite $x646 0 v_0_rtt_remaining)) $x683 $x685 $x687 $x690 $x693 $x696 $x701 $x706 $x712 $x718 $x726 $x734 $x742 $x750 $x758 $x766 $x774 $x782 $x790 $x798 $x806 $x814 $x820 (= v_1_tx_emit_count ?x516) (= v_1_tx_eligible ?x514) (= v_1_tx_max_previous ?x837) (= v_1_tx_retransmitted $x517) (= v_1_tx_elapsed (ite $x517 (+ now_1 (* ?x653 ?x837)) 0)) $x847 $x849 (not (= $x517 v_1_tx_waiting)) $x854 $x856 $x858 (= v_1_ack_pending (and (not $x517) v_0_ack_pending)) (= v_1_ack_since_ms (ite $x517 0 v_0_ack_since_ms)) (= v_1_ack_bytes (ite $x517 0 v_0_ack_bytes)) (= v_1_ack_full_segments (ite $x517 0 v_0_ack_full_segments)) $x878 $x881 $x883 $x885 (= v_1_persist_active $x646) (= v_1_persist_eligible $x646) (= v_1_persist_start $x892) $x895 $x897 $x899 $x901 (= v_1_persist_interval_ms (ite $x646 ?x904 1000)) $x910 $x915 (= v_1_persist_last_ms (ite $x646 v_0_persist_last_ms 0)) $x925 (= v_1_persist_probes (ite $x646 v_0_persist_probes 0)) $x932 $x935 $x938 (= v_1_cc_cwnd (ite $x940 4 v_0_cc_cwnd)) $x960 (= v_1_cc_ca_credit (ite $x940 0 v_0_cc_ca_credit)) (= 0 v_1_cc_acked) $x968 $x969 $x971 $x973 (= v_1_cc_loss $x940) (= v_1_cc_threshold_changed $x947) (= v_1_cc_threshold_updates ?x981) (= 0 v_1_cc_growth) $x986 (= v_1_cc_send_budget (ite (<= 0 ?x991) ?x991 0)) (= 0 v_1_cc_new_sent) $x1001 $x1008 $x1015 $x1022 $x1029 $x1036 $x1043 $x1050 $x1057 $x1064 $x1071 $x1078 $x1085 $x1092 $x1099 $x1106 $x1108 $x1111 $x1114 (= v_1_fr_active (and (not (or $x644 $x940 $x646)) v_0_fr_active)) (= v_1_fr_dupacks (ite (or $x644 $x940 $x646) 0 v_0_fr_dupacks)) $x1126 $x1128 $x1130 $x1131 $x1132 $x1134 $x1136 $x1138 $x1140 $x1142 $x1144 $x1146 $x1148 $x1150 $x1153 (= v_1_idle_data_valid (or v_0_idle_data_valid (and $x517 $x1156))) $x1163 $x1165 (= v_1_idle_data_emitted (and $x517 $x1156)) $x1169 (= v_1_idle_elapsed_ms ?x1173) $x1176 $x1178 $x1180 $x1183 $x1185 $x1187 (= 0 v_1_lt_take) (= v_1_lt_epoch_bytes (ite $x1191 0 v_0_lt_epoch_bytes)) (= v_1_lt_epoch_packets (ite $x1191 0 v_0_lt_epoch_packets)) $x1200 $x1202 $x1203 $x1205 $x1207 (= v_1_lt_loss_flight (+ v_0_rtx_buf (* ?x653 v_0_lt_epoch_bytes))) $x1213 $x1216 $x1219 $x1220 $x1223 $x1225 $x1228 (= 0 v_1_sched_cause) (= 0 v_1_sched_bytes) (= 0 v_1_sched_packets) (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf)) (= 0 v_1_svc_accept_step) (= 0 v_1_svc_ack_step) $x1243 $x1246 $x1249 $x1252 $x1259 $x1269 (= v_1_cb_count (+ v_0_cb_count ?x1264)) (= v_1_cb_new_count ?x1264) (= v_1_cb_append_length ?x1277) $x1280 $x1282 (= v_1_cb_live_total ?x1348) (= v_1_cb_partial_prefix ?x1351) (= v_1_cb_emitted_total (+ v_0_cb_emitted_total ?x1277)) $x1359 $x1362 $x1364 $x1365 (= v_1_cb_append_end ?x1368) $x1371 (= v_1_cb_length_00 ?x1287) $x1375 $x1377 (= v_1_cb_length_01 ?x1291) $x1381 $x1383 (= v_1_cb_length_02 ?x1295) $x1387 $x1389 (= v_1_cb_length_03 ?x1299) $x1393 $x1395 (= v_1_cb_length_04 ?x1303) $x1399 $x1401 (= v_1_cb_length_05 ?x1307) $x1405 $x1407 (= v_1_cb_length_06 ?x1311) $x1411 $x1413 (= v_1_cb_length_07 ?x1315) $x1417 $x1419 (= v_1_cb_length_08 ?x1319) $x1423 $x1425 (= v_1_cb_length_09 ?x1323) $x1429 $x1431 (= v_1_cb_length_10 ?x1327) $x1435 $x1437 (= v_1_cb_length_11 ?x1331) $x1441 $x1443 (= v_1_cb_length_12 ?x1335) $x1447 $x1449 (= v_1_cb_length_13 ?x1339) $x1453 $x1455 (= v_1_cb_length_14 ?x1343) $x1459 $x1461 (= v_1_cb_length_15 ?x1347) (= v_1_cb_end_15 (ite $x1345 ?x1368 v_0_cb_end_15)) $x1467 (= active_1_rtx (or $x1469 $x647)) $x1473 $x1475 (= active_1_delack (and (not $x517) active_0_delack)) $x1482 (= due_1_rtx (ite $x1469 (+ now_1 ?x523) (+ now_1 ?x1487))) $x1492 $x1494 $x1496 (= due_1_persist (ite $x892 ?x921 due_0_persist)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_user))
(assert
 (not active_0_time_wait))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (<= 1000 v_0_rto_ms))
(assert
 (<= 0 v_0_retries))
(assert
 (<= 1 v_0_msl_ms))
(assert
 (<= 1 v_0_user_timeout_ms))
(assert
 true)
(assert
 (let ((?x1236 (+ v_0_snd_buf v_0_rtx_buf)))
 (>= 16 ?x1236)))
(assert
 (>= 16 v_0_rcv_buf))
(assert
 (and (<= 0 v_0_snd_wnd) (>= 65535 v_0_snd_wnd)))
(assert
 (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf))))
(assert
 (>= 1 v_0_rx_slot_00))
(assert
 (let (($x1517 (= 0 v_0_rx_slot_00)))
 (let (($x1516 (not (>= v_0_rcv_buf 16))))
 (or $x1516 $x1517))))
(assert
 (>= 1 v_0_rx_slot_01))
(assert
 (let (($x1522 (= 0 v_0_rx_slot_01)))
 (let (($x1521 (not (>= v_0_rcv_buf 15))))
 (or $x1521 $x1522))))
(assert
 (>= 1 v_0_rx_slot_02))
(assert
 (let (($x1527 (= 0 v_0_rx_slot_02)))
 (let (($x1526 (not (>= v_0_rcv_buf 14))))
 (or $x1526 $x1527))))
(assert
 (>= 1 v_0_rx_slot_03))
(assert
 (let (($x1532 (= 0 v_0_rx_slot_03)))
 (let (($x1531 (not (>= v_0_rcv_buf 13))))
 (or $x1531 $x1532))))
(assert
 (>= 1 v_0_rx_slot_04))
(assert
 (let (($x1537 (= 0 v_0_rx_slot_04)))
 (let (($x1536 (not (>= v_0_rcv_buf 12))))
 (or $x1536 $x1537))))
(assert
 (>= 1 v_0_rx_slot_05))
(assert
 (let (($x1542 (= 0 v_0_rx_slot_05)))
 (let (($x1541 (not (>= v_0_rcv_buf 11))))
 (or $x1541 $x1542))))
(assert
 (>= 1 v_0_rx_slot_06))
(assert
 (let (($x1547 (= 0 v_0_rx_slot_06)))
 (let (($x1546 (not (>= v_0_rcv_buf 10))))
 (or $x1546 $x1547))))
(assert
 (>= 1 v_0_rx_slot_07))
(assert
 (let (($x1552 (= 0 v_0_rx_slot_07)))
 (let (($x1551 (not (>= v_0_rcv_buf 9))))
 (or $x1551 $x1552))))
(assert
 (>= 1 v_0_rx_slot_08))
(assert
 (let (($x1557 (= 0 v_0_rx_slot_08)))
 (let (($x1556 (not (>= v_0_rcv_buf 8))))
 (or $x1556 $x1557))))
(assert
 (>= 1 v_0_rx_slot_09))
(assert
 (let (($x1562 (= 0 v_0_rx_slot_09)))
 (let (($x1561 (not (>= v_0_rcv_buf 7))))
 (or $x1561 $x1562))))
(assert
 (>= 1 v_0_rx_slot_10))
(assert
 (let (($x1567 (= 0 v_0_rx_slot_10)))
 (let (($x1566 (not (>= v_0_rcv_buf 6))))
 (or $x1566 $x1567))))
(assert
 (>= 1 v_0_rx_slot_11))
(assert
 (let (($x1572 (= 0 v_0_rx_slot_11)))
 (let (($x1571 (not (>= v_0_rcv_buf 5))))
 (or $x1571 $x1572))))
(assert
 (>= 1 v_0_rx_slot_12))
(assert
 (let (($x1577 (= 0 v_0_rx_slot_12)))
 (let (($x1576 (not (>= v_0_rcv_buf 4))))
 (or $x1576 $x1577))))
(assert
 (>= 1 v_0_rx_slot_13))
(assert
 (let (($x1582 (= 0 v_0_rx_slot_13)))
 (let (($x1581 (not (>= v_0_rcv_buf 3))))
 (or $x1581 $x1582))))
(assert
 (>= 1 v_0_rx_slot_14))
(assert
 (let (($x1587 (= 0 v_0_rx_slot_14)))
 (let (($x1586 (not (>= v_0_rcv_buf 2))))
 (or $x1586 $x1587))))
(assert
 (>= 1 v_0_rx_slot_15))
(assert
 (let (($x1592 (= 0 v_0_rx_slot_15)))
 (let (($x1591 (not (>= v_0_rcv_buf 1))))
 (or $x1591 $x1592))))
(assert
 (= 0 v_0_rx_slot_00))
(assert
 (let ((?x1594 (+ v_0_rcv_buf v_0_rx_slot_00 v_0_rx_slot_01 v_0_rx_slot_02 v_0_rx_slot_03 v_0_rx_slot_04 v_0_rx_slot_05 v_0_rx_slot_06 v_0_rx_slot_07 v_0_rx_slot_08 v_0_rx_slot_09 v_0_rx_slot_10 v_0_rx_slot_11 v_0_rx_slot_12 v_0_rx_slot_13 v_0_rx_slot_14 v_0_rx_slot_15)))
 (>= 16 ?x1594)))
(assert
 (and (<= 0 v_0_rx_advance) (>= 16 v_0_rx_advance)))
(assert
 (= v_0_rx_chunk v_0_rx_advance))
(assert
 (and (<= 0 v_0_ack_delta) (>= 4294967295 v_0_ack_delta)))
(assert
 true)
(assert
 (let ((?x1606 (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)) 4294967296)))
 (= v_0_snd_nxt ?x1606)))
(assert
 (not v_0_fin_sent))
(assert
 (not v_0_fin_requested))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not v_0_rx_fin_done))
(assert
 (let (($x1611 (<= 1 v_0_rx_fin_offset)))
 (let (($x1609 (not v_0_rx_fin_done)))
 (let (($x1614 (and $x1609 $x1611 (<= v_0_rx_fin_offset (+ (- 1) v_0_local_window)))))
 (let (($x1610 (not v_0_rx_fin_pending)))
 (or $x1610 $x1614))))))
(assert
 (let (($x1617 (>= 15 v_0_rx_fin_offset)))
 (and (<= 0 v_0_rx_fin_offset) $x1617 (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset)))))
(assert
 (let (($x1610 (not v_0_rx_fin_pending)))
 (or $x1610 (= v_0_rx_fin_seq (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)))))
(assert
 (let (($x1609 (not v_0_rx_fin_done)))
 (or $x1609 (= v_0_rcv_nxt (mod (+ 1 v_0_rx_fin_seq) 4294967296)))))
(assert
 (let (($x1517 (= 0 v_0_rx_slot_00)))
 (or (not (and v_0_rx_fin_pending (>= 0 v_0_rx_fin_offset))) $x1517)))
(assert
 (let (($x1522 (= 0 v_0_rx_slot_01)))
 (or (not (and v_0_rx_fin_pending (>= 1 v_0_rx_fin_offset))) $x1522)))
(assert
 (let (($x1527 (= 0 v_0_rx_slot_02)))
 (or (not (and v_0_rx_fin_pending (>= 2 v_0_rx_fin_offset))) $x1527)))
(assert
 (let (($x1532 (= 0 v_0_rx_slot_03)))
 (or (not (and v_0_rx_fin_pending (>= 3 v_0_rx_fin_offset))) $x1532)))
(assert
 (let (($x1537 (= 0 v_0_rx_slot_04)))
 (or (not (and v_0_rx_fin_pending (>= 4 v_0_rx_fin_offset))) $x1537)))
(assert
 (let (($x1542 (= 0 v_0_rx_slot_05)))
 (or (not (and v_0_rx_fin_pending (>= 5 v_0_rx_fin_offset))) $x1542)))
(assert
 (let (($x1547 (= 0 v_0_rx_slot_06)))
 (or (not (and v_0_rx_fin_pending (>= 6 v_0_rx_fin_offset))) $x1547)))
(assert
 (let (($x1552 (= 0 v_0_rx_slot_07)))
 (or (not (and v_0_rx_fin_pending (>= 7 v_0_rx_fin_offset))) $x1552)))
(assert
 (let (($x1557 (= 0 v_0_rx_slot_08)))
 (or (not (and v_0_rx_fin_pending (>= 8 v_0_rx_fin_offset))) $x1557)))
(assert
 (let (($x1562 (= 0 v_0_rx_slot_09)))
 (or (not (and v_0_rx_fin_pending (>= 9 v_0_rx_fin_offset))) $x1562)))
(assert
 (let (($x1567 (= 0 v_0_rx_slot_10)))
 (or (not (and v_0_rx_fin_pending (>= 10 v_0_rx_fin_offset))) $x1567)))
(assert
 (let (($x1572 (= 0 v_0_rx_slot_11)))
 (or (not (and v_0_rx_fin_pending (>= 11 v_0_rx_fin_offset))) $x1572)))
(assert
 (let (($x1577 (= 0 v_0_rx_slot_12)))
 (or (not (and v_0_rx_fin_pending (>= 12 v_0_rx_fin_offset))) $x1577)))
(assert
 (let (($x1582 (= 0 v_0_rx_slot_13)))
 (or (not (and v_0_rx_fin_pending (>= 13 v_0_rx_fin_offset))) $x1582)))
(assert
 (let (($x1587 (= 0 v_0_rx_slot_14)))
 (or (not (and v_0_rx_fin_pending (>= 14 v_0_rx_fin_offset))) $x1587)))
(assert
 (let (($x1592 (= 0 v_0_rx_slot_15)))
 (or (not (and v_0_rx_fin_pending (>= 15 v_0_rx_fin_offset))) $x1592)))
(assert
 (<= 0.0 v_0_srtt_ms))
(assert
 (<= 0.0 v_0_rttvar_ms))
(assert
 (<= 0.0 v_0_rtt_error_ms))
(assert
 (<= 0.0 v_0_rtt_previous_srtt))
(assert
 (<= 0.0 v_0_rtt_previous_var))
(assert
 (<= 0 v_0_rtt_start_ms))
(assert
 (<= 0 v_0_rtt_last_ms))
(assert
 (<= 0 v_0_rtt_samples))
(assert
 (and (<= 1000 v_0_rto_base_ms) (>= 60000 v_0_rto_base_ms) (>= v_0_rto_ms v_0_rto_base_ms) (>= 60000 v_0_rto_ms)))
(assert
 (let ((?x1710 (* 4.0 v_0_rttvar_ms)))
 (let ((?x1705 (- 1.0)))
 (let ((?x1713 (+ (* ?x1705 v_0_srtt_ms) (* ?x1705 (ite (<= v_0_rttvar_ms (/ 1.0 4.0)) 1.0 ?x1710)))))
 (let ((?x1714 (to_int ?x1713)))
 (let ((?x653 (- 1)))
 (let ((?x1718 (ite (<= ?x1714 (- 1000)) (* ?x653 ?x1714) 1000)))
 (= v_0_rto_base_ms (ite v_0_rtt_measured (ite (<= 60000 ?x1718) 60000 ?x1718) 1000)))))))))
(assert
 (= v_0_rtt_measured (<= 1 v_0_rtt_samples)))
(assert
 (let ((?x656 (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296)))
 (let (($x1733 (and (<= v_0_rtt_start_ms now_0) (<= 1 v_0_rtt_remaining) (>= 4 v_0_rtt_remaining) (>= ?x656 v_0_rtt_remaining) (<= ?x656 (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296)))))
 (let (($x1725 (not v_0_rtt_active)))
 (or $x1725 $x1733)))))
(assert
 (let (($x1735 (= 0 v_0_rtt_remaining)))
 (or v_0_rtt_active $x1735)))
(assert
 true)
(assert
 (let (($x1743 (= v_0_rtt_last_ms (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms)))))
 (let (($x1740 (not v_0_rtt_sample_was_ambiguous)))
 (let (($x1738 (not v_0_rtt_sample_used)))
 (or $x1738 (and $x1740 v_0_rtt_measured $x1743))))))
(assert
 (and (<= 0 v_0_rtt_sample_at_ms) (<= v_0_rtt_sample_at_ms now_0)))
(assert
 (let ((?x1752 (to_real v_0_rtt_last_ms)))
 (let ((?x1770 (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt) (* (/ 1.0 8.0) ?x1752))))
 (let ((?x1754 (+ v_0_rtt_previous_srtt (* (- 1.0) ?x1752))))
 (let ((?x1758 (ite (>= ?x1754 0.0) ?x1754 (+ (* (- 1.0) v_0_rtt_previous_srtt) ?x1752))))
 (let ((?x1708 (/ 1.0 4.0)))
 (let ((?x1762 (ite v_0_rtt_previous_measured (+ (* (/ 3.0 4.0) v_0_rtt_previous_var) (* ?x1708 ?x1758)) (* (/ 1.0 2.0) ?x1752))))
 (let (($x1773 (and (= v_0_rttvar_ms ?x1762) (= v_0_srtt_ms (ite v_0_rtt_previous_measured ?x1770 ?x1752)))))
 (let (($x1738 (not v_0_rtt_sample_used)))
 (or $x1738 $x1773))))))))))
(assert
 (let (($x826 (<= 0 v_0_tx_time_00)))
 (and $x826 (<= v_0_tx_time_00 now_0) (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00)))))
(assert
 (and (<= 0 v_0_tx_time_01) (<= v_0_tx_time_01 now_0) (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))))
(assert
 (and (<= 0 v_0_tx_time_02) (<= v_0_tx_time_02 now_0) (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))))
(assert
 (and (<= 0 v_0_tx_time_03) (<= v_0_tx_time_03 now_0) (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))))
(assert
 (and (<= 0 v_0_tx_time_04) (<= v_0_tx_time_04 now_0) (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))))
(assert
 (and (<= 0 v_0_tx_time_05) (<= v_0_tx_time_05 now_0) (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))))
(assert
 (and (<= 0 v_0_tx_time_06) (<= v_0_tx_time_06 now_0) (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))))
(assert
 (and (<= 0 v_0_tx_time_07) (<= v_0_tx_time_07 now_0) (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))))
(assert
 (and (<= 0 v_0_tx_time_08) (<= v_0_tx_time_08 now_0) (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))))
(assert
 (and (<= 0 v_0_tx_time_09) (<= v_0_tx_time_09 now_0) (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))))
(assert
 (and (<= 0 v_0_tx_time_10) (<= v_0_tx_time_10 now_0) (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))))
(assert
 (and (<= 0 v_0_tx_time_11) (<= v_0_tx_time_11 now_0) (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))))
(assert
 (and (<= 0 v_0_tx_time_12) (<= v_0_tx_time_12 now_0) (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))))
(assert
 (and (<= 0 v_0_tx_time_13) (<= v_0_tx_time_13 now_0) (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))))
(assert
 (and (<= 0 v_0_tx_time_14) (<= v_0_tx_time_14 now_0) (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))))
(assert
 (and (<= 0 v_0_tx_time_15) (<= v_0_tx_time_15 now_0) (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))))
(assert
 (and (<= 0 v_0_tx_fin_time) (<= v_0_tx_fin_time now_0)))
(assert
 (and (<= 0 v_0_tx_emit_count) (>= 4 v_0_tx_emit_count)))
(assert
 (and (<= 0 v_0_tx_eligible) (>= 4 v_0_tx_eligible)))
(assert
 (and (<= 0 v_0_tx_elapsed) (<= 0 v_0_tx_max_previous) (<= v_0_tx_max_previous now_0) (<= 1000 v_0_tx_previous_rto) (>= 60000 v_0_tx_previous_rto)))
(assert
 (let (($x1882 (and (>= v_0_tx_elapsed v_0_tx_previous_rto) (<= 1 v_0_tx_emit_count) (or (not v_0_tx_is_fin) (= 1 v_0_tx_emit_count)))))
 (let (($x1875 (not v_0_tx_retransmitted)))
 (or $x1875 $x1882))))
(assert
 (let (($x1875 (not v_0_tx_retransmitted)))
 (or $x1875 (not v_0_tx_waiting))))
(assert
 (and (<= 0 v_0_tx_syn_time) (<= v_0_tx_syn_time now_0)))
(assert
 (not v_0_tx_syn_pending))
(assert
 (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time)))
(assert
 true)
(assert
 (and (<= 1 v_0_ack_delay_ms) (>= 499 v_0_ack_delay_ms) (= 4 v_0_ack_rmss)))
(assert
 (= v_0_ack_pending active_0_delack))
(assert
 (and (<= 0 v_0_ack_bytes) (>= 7 v_0_ack_bytes) (<= 0 v_0_ack_full_segments) (>= 1 v_0_ack_full_segments)))
(assert
 (and (<= 0 v_0_ack_since_ms) (<= v_0_ack_since_ms now_0)))
(assert
 (let (($x1909 (not v_0_ack_pending)))
 (or $x1909 (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))))
(assert
 (let (($x1916 (and (= 0 v_0_ack_bytes) (= 0 v_0_ack_full_segments) (= 0 v_0_ack_since_ms))))
 (or v_0_ack_pending $x1916)))
(assert
 (let (($x370 (not active_0_rtx)))
 (let (($x642 (>= 1 v_0_rtx_buf)))
 (let (($x641 (<= 1 (+ v_0_rtx_buf v_0_snd_buf))))
 (let (($x639 (not v_0_fin_sent)))
 (let (($x638 (= 0 v_0_snd_wnd)))
 (let (($x891 (not v_0_persist_active)))
 (let (($x1921 (and (<= 1 (+ v_0_rtx_buf (ite v_0_fin_sent 1 0))) $x891)))
 (let (($x1918 (= v_0_persist_active active_0_persist)))
 (and $x1918 (= active_0_rtx $x1921) (or $x891 (and $x638 $x639 $x641 $x642 $x370))))))))))))
(assert
 (let (($x891 (not v_0_persist_active)))
 (or $x891 (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))))
(assert
 (and (<= 1000 v_0_persist_interval_ms) (>= 60000 v_0_persist_interval_ms) (<= 1000 v_0_persist_previous_interval_ms) (>= 60000 v_0_persist_previous_interval_ms) (<= 0 v_0_persist_probes) (<= 0 v_0_persist_elapsed_ms)))
(assert
 (and (<= 0 v_0_persist_since_ms) (<= v_0_persist_since_ms now_0) (<= 0 v_0_persist_last_ms) (<= v_0_persist_last_ms now_0) (<= 0 v_0_persist_deadline_ms)))
(assert
 (let (($x1941 (= 0 v_0_persist_probes)))
 (let ((?x1943 (+ (ite $x1941 v_0_persist_since_ms v_0_persist_last_ms) v_0_persist_interval_ms)))
 (let (($x891 (not v_0_persist_active)))
 (or $x891 (= v_0_persist_deadline_ms ?x1943))))))
(assert
 (let (($x1949 (= 1 v_0_rtx_buf)))
 (let (($x1947 (not v_0_persist_probe_sent)))
 (or $x1947 (and (>= v_0_persist_elapsed_ms v_0_persist_previous_interval_ms) $x1949)))))
(assert
 (let (($x1955 (= v_0_tx_time_00 v_0_persist_last_ms)))
 (let (($x1949 (= 1 v_0_rtx_buf)))
 (or (not (and v_0_persist_active (<= 1 v_0_persist_probes) $x1949)) $x1955))))
(assert
 (let (($x1941 (= 0 v_0_persist_probes)))
 (let (($x1960 (and (= 0 v_0_persist_since_ms) (= 0 v_0_persist_last_ms) (= 0 v_0_persist_deadline_ms) $x1941)))
 (or v_0_persist_active $x1960))))
(assert
 (and (<= 4 v_0_cc_initial_window) (>= 16 v_0_cc_initial_window) (<= 8 v_0_cc_initial_threshold)))
(assert
 (and (<= 4 v_0_cc_cwnd) (<= 8 v_0_cc_ssthresh) (<= 0 v_0_cc_ca_credit) (not (>= v_0_cc_ca_credit v_0_cc_cwnd)) (<= 0 v_0_cc_growth) (>= 4 v_0_cc_growth) (<= 0 v_0_cc_acked) (>= 16 v_0_cc_acked) (<= 0 v_0_cc_threshold_updates)))
(assert
 (and (<= 0 v_0_cc_new_sent) (<= v_0_cc_new_sent v_0_cc_send_budget)))
(assert
 (let (($x698 (>= 0 v_0_rtx_buf)))
 (let (($x998 (not $x698)))
 (let (($x946 (not v_0_cc_rto_00)))
 (or $x946 $x998)))))
(assert
 (let (($x642 (>= 1 v_0_rtx_buf)))
 (let (($x1003 (not $x642)))
 (let (($x1985 (not v_0_cc_rto_01)))
 (or $x1985 $x1003)))))
(assert
 (let (($x708 (>= 2 v_0_rtx_buf)))
 (let (($x1010 (not $x708)))
 (let (($x1987 (not v_0_cc_rto_02)))
 (or $x1987 $x1010)))))
(assert
 (let (($x714 (>= 3 v_0_rtx_buf)))
 (let (($x1017 (not $x714)))
 (let (($x1989 (not v_0_cc_rto_03)))
 (or $x1989 $x1017)))))
(assert
 (let (($x720 (>= 4 v_0_rtx_buf)))
 (let (($x1024 (not $x720)))
 (let (($x1991 (not v_0_cc_rto_04)))
 (or $x1991 $x1024)))))
(assert
 (let (($x728 (>= 5 v_0_rtx_buf)))
 (let (($x1031 (not $x728)))
 (let (($x1993 (not v_0_cc_rto_05)))
 (or $x1993 $x1031)))))
(assert
 (let (($x736 (>= 6 v_0_rtx_buf)))
 (let (($x1038 (not $x736)))
 (let (($x1995 (not v_0_cc_rto_06)))
 (or $x1995 $x1038)))))
(assert
 (let (($x744 (>= 7 v_0_rtx_buf)))
 (let (($x1045 (not $x744)))
 (let (($x1997 (not v_0_cc_rto_07)))
 (or $x1997 $x1045)))))
(assert
 (let (($x752 (>= 8 v_0_rtx_buf)))
 (let (($x1052 (not $x752)))
 (let (($x1999 (not v_0_cc_rto_08)))
 (or $x1999 $x1052)))))
(assert
 (let (($x760 (>= 9 v_0_rtx_buf)))
 (let (($x1059 (not $x760)))
 (let (($x2001 (not v_0_cc_rto_09)))
 (or $x2001 $x1059)))))
(assert
 (let (($x768 (>= 10 v_0_rtx_buf)))
 (let (($x1066 (not $x768)))
 (let (($x2003 (not v_0_cc_rto_10)))
 (or $x2003 $x1066)))))
(assert
 (let (($x776 (>= 11 v_0_rtx_buf)))
 (let (($x1073 (not $x776)))
 (let (($x2005 (not v_0_cc_rto_11)))
 (or $x2005 $x1073)))))
(assert
 (let (($x784 (>= 12 v_0_rtx_buf)))
 (let (($x1080 (not $x784)))
 (let (($x2007 (not v_0_cc_rto_12)))
 (or $x2007 $x1080)))))
(assert
 (let (($x792 (>= 13 v_0_rtx_buf)))
 (let (($x1087 (not $x792)))
 (let (($x2009 (not v_0_cc_rto_13)))
 (or $x2009 $x1087)))))
(assert
 (let (($x800 (>= 14 v_0_rtx_buf)))
 (let (($x1094 (not $x800)))
 (let (($x2011 (not v_0_cc_rto_14)))
 (or $x2011 $x1094)))))
(assert
 (let (($x808 (>= 15 v_0_rtx_buf)))
 (let (($x1101 (not $x808)))
 (let (($x2013 (not v_0_cc_rto_15)))
 (or $x2013 $x1101)))))
(assert
 (and (<= 0 v_0_fr_dupacks) (<= 0 v_0_fr_entries) (<= 0 v_0_fr_emit_count) (>= 4 v_0_fr_emit_count) (<= 0 v_0_fr_last_window) (>= 65535 v_0_fr_last_window)))
(assert
 (let (($x891 (not v_0_persist_active)))
 (let (($x459 (<= 1 v_0_rtx_buf)))
 (let (($x2023 (not v_0_fr_active)))
 (or $x2023 (and (<= 3 v_0_fr_dupacks) $x459 $x891))))))
(assert
 (let (($x1875 (not v_0_tx_retransmitted)))
 (let (($x2036 (= v_0_retries v_0_fr_before_retries)))
 (let (($x2034 (= v_0_rto_ms v_0_fr_before_rto)))
 (let (($x2032 (= v_0_snd_nxt v_0_fr_before_nxt)))
 (let (($x2037 (and v_0_fr_entered (= 3 v_0_fr_dupacks) (<= 1 v_0_fr_emit_count) $x2032 $x2034 $x2036 $x1875)))
 (let (($x2028 (not v_0_fr_retransmitted)))
 (or $x2028 $x2037))))))))
(assert
 (let (($x2045 (and (= v_0_fr_last_window v_0_fr_before_wire_window) (= v_0_fr_window_valid v_0_fr_before_window_valid))))
 (or (not v_0_fr_window_ignored) $x2045)))
(assert
 (let (($x2047 (not v_0_fr_entered)))
 (or v_0_fr_retransmitted $x2047)))
(assert
 (let (($x2047 (not v_0_fr_entered)))
 (or $x2047 (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))))
(assert
 (let (($x2053 (not v_0_fr_exited)))
 (or $x2053 (and (= v_0_cc_cwnd v_0_cc_ssthresh) (= 0 v_0_cc_ca_credit)))))
(assert
 (and (<= 0 v_0_idle_last_data_ms) (<= v_0_idle_last_data_ms v_0_idle_event_ms) (<= v_0_idle_event_ms now_0) (<= 0 v_0_idle_elapsed_ms) (<= 0 v_0_idle_restart_count)))
(assert
 (or (not v_0_idle_data_emitted) (= v_0_idle_last_data_ms v_0_idle_event_ms)))
(assert
 (let (($x2055 (= 0 v_0_cc_ca_credit)))
 (let (($x2080 (= v_0_cc_ssthresh v_0_idle_before_threshold)))
 (let ((?x2077 (ite (<= v_0_cc_initial_window v_0_idle_before_cwnd) v_0_cc_initial_window v_0_idle_before_cwnd)))
 (let (($x2081 (and (not (>= v_0_idle_before_rto v_0_idle_elapsed_ms)) (= v_0_cc_cwnd ?x2077) $x2080 $x2055)))
 (let (($x2071 (not v_0_idle_restart)))
 (or $x2071 $x2081)))))))
(assert
 (and (<= 0 v_0_lt_epoch_bytes) (>= 8 v_0_lt_epoch_bytes) (<= v_0_lt_epoch_bytes v_0_rtx_buf) (<= 0 v_0_lt_epoch_packets) (>= 2 v_0_lt_epoch_packets) (<= v_0_lt_epoch_packets v_0_fr_dupacks) (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets) (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets)) (<= 0 v_0_lt_loss_flight)))
(assert
 (let (($x485 (<= v_0_rtx_buf v_0_snd_wnd)))
 (let (($x2104 (= v_0_cc_cwnd v_0_lt_before_cwnd)))
 (let (($x639 (not v_0_fin_sent)))
 (let (($x2023 (not v_0_fr_active)))
 (let (($x2113 (and v_0_fr_duplicate (<= 1 v_0_fr_dupacks) (>= 2 v_0_fr_dupacks) $x2023 $x639 (<= 1 v_0_lt_take) (>= 4 v_0_lt_take) $x2104 (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take)) $x485 (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd)) (= v_0_snd_nxt (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)))))
 (let (($x2096 (not v_0_lt_emitted)))
 (or $x2096 $x2113))))))))
(assert
 (let (($x2119 (= v_0_lt_loss_flight (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes)))))
 (let (($x2047 (not v_0_fr_entered)))
 (or $x2047 $x2119))))
(assert
 (and (<= 0 v_0_choice_count) (>= 4 v_0_choice_count) (<= 0 v_0_choice_limit) (>= 4 v_0_choice_limit)))
(assert
 (let ((?x2134 (mod (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)))
 (let (($x2131 (= v_0_cc_new_sent v_0_choice_count)))
 (let (($x2130 (= v_0_take v_0_choice_count)))
 (let (($x2138 (and (<= 1 v_0_choice_count) (<= v_0_choice_count v_0_choice_limit) $x2130 $x2131 (<= v_0_choice_count v_0_cc_send_budget) (= v_0_snd_nxt ?x2134) (= v_0_rtx_buf (+ v_0_choice_before_flight v_0_choice_count)))))
 (let (($x2127 (not v_0_choice_used)))
 (or $x2127 $x2138)))))))
(assert
 (and (<= 0 v_0_sched_packets) (<= v_0_sched_packets v_0_sched_bytes) (<= v_0_sched_bytes (* 4 v_0_sched_packets)) (>= 16 (+ v_0_sched_bytes v_0_snd_buf))))
(assert
 (let (($x2152 (not v_0_sched_open)))
 (and (<= 0 v_0_sched_at_ms) (<= v_0_sched_at_ms now_0) (or $x2152 (= 1 v_0_sched_cause) (= 2 v_0_sched_cause)))))
(assert
 (let (($x2127 (not v_0_choice_used)))
 (or $x2127 (and v_0_sched_open (= v_0_sched_at_ms v_0_idle_event_ms)))))
(assert
 (let ((?x2164 (+ v_0_svc_acked_bytes v_0_svc_abandoned_bytes v_0_snd_buf v_0_rtx_buf)))
 (and (<= 0 v_0_svc_written_bytes) (<= 0 v_0_svc_acked_bytes) (<= 0 v_0_svc_abandoned_bytes) (= v_0_svc_written_bytes ?x2164))))
(assert
 (let (($x2168 (= v_0_svc_ack_step v_0_cc_acked)))
 (and $x2168 (<= 0 v_0_svc_accept_step) (<= 0 v_0_svc_ack_step) (<= 0 v_0_svc_drop_step))))
(assert
 (let ((?x2182 (+ v_0_cb_head v_0_cb_count)))
 (let (($x2186 (= v_0_cb_tail (ite (<= 16 ?x2182) (+ (- 16) v_0_cb_head v_0_cb_count) ?x2182))))
 (and (<= 0 v_0_cb_head) (not (<= 16 v_0_cb_head)) (<= 0 v_0_cb_tail) (not (<= 16 v_0_cb_tail)) (<= 0 v_0_cb_count) (<= v_0_cb_count v_0_rtx_buf) $x2186 (<= 0 v_0_cb_new_count) (>= 1 v_0_cb_new_count)))))
(assert
 (let ((?x2207 (+ v_0_cb_length_00 v_0_cb_length_01 v_0_cb_length_02 v_0_cb_length_03 v_0_cb_length_04 v_0_cb_length_05 v_0_cb_length_06 v_0_cb_length_07 v_0_cb_length_08 v_0_cb_length_09 v_0_cb_length_10 v_0_cb_length_11 v_0_cb_length_12 v_0_cb_length_13 v_0_cb_length_14 v_0_cb_length_15)))
 (let (($x2206 (= v_0_cb_emitted_total (+ v_0_cb_acked_total v_0_cb_abandoned_total v_0_cb_live_total))))
 (and (<= 0 v_0_cb_emitted_total) (<= 0 v_0_cb_acked_total) (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix) v_0_svc_acked_bytes) (<= v_0_cb_emitted_total v_0_svc_written_bytes) (<= 0 v_0_cb_abandoned_total) (<= 0 v_0_cb_step_bytes) (>= 19 v_0_cb_step_bytes) (<= 0 v_0_cb_drop_step) $x2206 (= v_0_cb_live_total ?x2207)))))
(assert
 (let (($x2211 (= v_0_cb_partial_prefix (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf)))))
 (and $x2211 (<= 0 v_0_cb_partial_prefix) (>= 3 v_0_cb_partial_prefix))))
(assert
 (<= (+ v_0_cb_emitted_total v_0_snd_buf) v_0_svc_written_bytes))
(assert
 (let ((?x653 (- 1)))
 (let ((?x2218 (* ?x653 v_0_cb_head)))
 (let ((?x2220 (ite (>= 0 v_0_cb_head) ?x2218 (+ 16 ?x2218))))
 (let (($x2221 (>= ?x2220 v_0_cb_count)))
 (let (($x2226 (not $x2221)))
 (let (($x2248 (or (not (and $x2226 (<= 1 ?x2220))) (= v_0_cb_end_00 (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)))))
 (let ((?x2238 (mod (+ v_0_snd_una v_0_cb_length_00 (* ?x653 v_0_cb_partial_prefix)) 4294967296)))
 (let (($x2240 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_00)) (= v_0_cb_end_00 ?x2238))))
 (let (($x2225 (or $x2221 (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00)))))
 (and $x2225 (or $x2226 (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00))) (or (not (and $x2226 (= 0 v_0_cb_head))) $x2240) $x2248)))))))))))
(assert
 (let ((?x2257 (ite (>= 1 v_0_cb_head) (+ 1 (* (- 1) v_0_cb_head)) (+ 17 (* (- 1) v_0_cb_head)))))
 (let (($x2258 (>= ?x2257 v_0_cb_count)))
 (let (($x2260 (not $x2258)))
 (let (($x2281 (or (not (and $x2260 (<= 1 ?x2257))) (= v_0_cb_end_01 (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2272 (= v_0_cb_end_01 (mod (+ v_0_snd_una v_0_cb_length_01 ?x2236) 4294967296))))
 (let (($x2274 (or (not (and $x2260 (= 1 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_01)) $x2272))))
 (let (($x2259 (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01)) $x2258)))
 (and $x2259 (or $x2260 (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01))) $x2274 $x2281)))))))))))
(assert
 (let ((?x2290 (ite (>= 2 v_0_cb_head) (+ 2 (* (- 1) v_0_cb_head)) (+ 18 (* (- 1) v_0_cb_head)))))
 (let (($x2291 (>= ?x2290 v_0_cb_count)))
 (let (($x2293 (not $x2291)))
 (let (($x2314 (or (not (and $x2293 (<= 1 ?x2290))) (= v_0_cb_end_02 (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2305 (= v_0_cb_end_02 (mod (+ v_0_snd_una v_0_cb_length_02 ?x2236) 4294967296))))
 (let (($x2307 (or (not (and $x2293 (= 2 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_02)) $x2305))))
 (let (($x2292 (or (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)) $x2291)))
 (and $x2292 (or $x2293 (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02))) $x2307 $x2314)))))))))))
(assert
 (let ((?x2322 (ite (>= 3 v_0_cb_head) (+ 3 (* (- 1) v_0_cb_head)) (+ 19 (* (- 1) v_0_cb_head)))))
 (let (($x2323 (>= ?x2322 v_0_cb_count)))
 (let (($x2325 (not $x2323)))
 (let (($x2346 (or (not (and $x2325 (<= 1 ?x2322))) (= v_0_cb_end_03 (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2337 (= v_0_cb_end_03 (mod (+ v_0_snd_una v_0_cb_length_03 ?x2236) 4294967296))))
 (let (($x2339 (or (not (and $x2325 (= 3 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_03)) $x2337))))
 (let (($x2324 (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03)) $x2323)))
 (and $x2324 (or $x2325 (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03))) $x2339 $x2346)))))))))))
(assert
 (let ((?x2352 (ite (>= 4 v_0_cb_head) (+ 4 (* (- 1) v_0_cb_head)) (+ 20 (* (- 1) v_0_cb_head)))))
 (let (($x2353 (>= ?x2352 v_0_cb_count)))
 (let (($x2358 (not $x2353)))
 (let (($x2379 (or (not (and $x2358 (<= 1 ?x2352))) (= v_0_cb_end_04 (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2370 (= v_0_cb_end_04 (mod (+ v_0_snd_una v_0_cb_length_04 ?x2236) 4294967296))))
 (let (($x2372 (or (not (and $x2358 (= 4 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_04)) $x2370))))
 (let (($x2357 (or $x2353 (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04)))))
 (and $x2357 (or $x2358 (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04))) $x2372 $x2379)))))))))))
(assert
 (let ((?x2385 (ite (>= 5 v_0_cb_head) (+ 5 (* (- 1) v_0_cb_head)) (+ 21 (* (- 1) v_0_cb_head)))))
 (let (($x2386 (>= ?x2385 v_0_cb_count)))
 (let (($x2391 (not $x2386)))
 (let (($x2412 (or (not (and $x2391 (<= 1 ?x2385))) (= v_0_cb_end_05 (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2403 (= v_0_cb_end_05 (mod (+ v_0_snd_una v_0_cb_length_05 ?x2236) 4294967296))))
 (let (($x2405 (or (not (and $x2391 (= 5 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_05)) $x2403))))
 (let (($x2390 (or $x2386 (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))))
 (and $x2390 (or $x2391 (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05))) $x2405 $x2412)))))))))))
(assert
 (let ((?x2421 (ite (>= 6 v_0_cb_head) (+ 6 (* (- 1) v_0_cb_head)) (+ 22 (* (- 1) v_0_cb_head)))))
 (let (($x2422 (>= ?x2421 v_0_cb_count)))
 (let (($x2424 (not $x2422)))
 (let (($x2445 (or (not (and $x2424 (<= 1 ?x2421))) (= v_0_cb_end_06 (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2436 (= v_0_cb_end_06 (mod (+ v_0_snd_una v_0_cb_length_06 ?x2236) 4294967296))))
 (let (($x2438 (or (not (and $x2424 (= 6 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_06)) $x2436))))
 (let (($x2423 (or (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06)) $x2422)))
 (and $x2423 (or $x2424 (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06))) $x2438 $x2445)))))))))))
(assert
 (let ((?x2451 (ite (>= 7 v_0_cb_head) (+ 7 (* (- 1) v_0_cb_head)) (+ 23 (* (- 1) v_0_cb_head)))))
 (let (($x2452 (>= ?x2451 v_0_cb_count)))
 (let (($x2457 (not $x2452)))
 (let (($x2478 (or (not (and $x2457 (<= 1 ?x2451))) (= v_0_cb_end_07 (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2469 (= v_0_cb_end_07 (mod (+ v_0_snd_una v_0_cb_length_07 ?x2236) 4294967296))))
 (let (($x2471 (or (not (and $x2457 (= 7 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_07)) $x2469))))
 (let (($x2456 (or $x2452 (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))))
 (and $x2456 (or $x2457 (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07))) $x2471 $x2478)))))))))))
(assert
 (let ((?x2487 (ite (>= 8 v_0_cb_head) (+ 8 (* (- 1) v_0_cb_head)) (+ 24 (* (- 1) v_0_cb_head)))))
 (let (($x2488 (>= ?x2487 v_0_cb_count)))
 (let (($x2490 (not $x2488)))
 (let (($x2511 (or (not (and $x2490 (<= 1 ?x2487))) (= v_0_cb_end_08 (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2502 (= v_0_cb_end_08 (mod (+ v_0_snd_una v_0_cb_length_08 ?x2236) 4294967296))))
 (let (($x2504 (or (not (and $x2490 (= 8 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_08)) $x2502))))
 (let (($x2489 (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08)) $x2488)))
 (and $x2489 (or $x2490 (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08))) $x2504 $x2511)))))))))))
(assert
 (let ((?x2517 (ite (>= 9 v_0_cb_head) (+ 9 (* (- 1) v_0_cb_head)) (+ 25 (* (- 1) v_0_cb_head)))))
 (let (($x2518 (>= ?x2517 v_0_cb_count)))
 (let (($x2523 (not $x2518)))
 (let (($x2544 (or (not (and $x2523 (<= 1 ?x2517))) (= v_0_cb_end_09 (mod (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2535 (= v_0_cb_end_09 (mod (+ v_0_snd_una v_0_cb_length_09 ?x2236) 4294967296))))
 (let (($x2537 (or (not (and $x2523 (= 9 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09)) $x2535))))
 (let (($x2522 (or $x2518 (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09)))))
 (and $x2522 (or $x2523 (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09))) $x2537 $x2544)))))))))))
(assert
 (let ((?x2550 (ite (>= 10 v_0_cb_head) (+ 10 (* (- 1) v_0_cb_head)) (+ 26 (* (- 1) v_0_cb_head)))))
 (let (($x2551 (>= ?x2550 v_0_cb_count)))
 (let (($x2556 (not $x2551)))
 (let (($x2577 (or (not (and $x2556 (<= 1 ?x2550))) (= v_0_cb_end_10 (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2568 (= v_0_cb_end_10 (mod (+ v_0_snd_una v_0_cb_length_10 ?x2236) 4294967296))))
 (let (($x2570 (or (not (and $x2556 (= 10 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_10)) $x2568))))
 (let (($x2555 (or $x2551 (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10)))))
 (and $x2555 (or $x2556 (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10))) $x2570 $x2577)))))))))))
(assert
 (let ((?x2583 (ite (>= 11 v_0_cb_head) (+ 11 (* (- 1) v_0_cb_head)) (+ 27 (* (- 1) v_0_cb_head)))))
 (let (($x2584 (>= ?x2583 v_0_cb_count)))
 (let (($x2589 (not $x2584)))
 (let (($x2610 (or (not (and $x2589 (<= 1 ?x2583))) (= v_0_cb_end_11 (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2601 (= v_0_cb_end_11 (mod (+ v_0_snd_una v_0_cb_length_11 ?x2236) 4294967296))))
 (let (($x2603 (or (not (and $x2589 (= 11 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_11)) $x2601))))
 (let (($x2588 (or $x2584 (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)))))
 (and $x2588 (or $x2589 (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11))) $x2603 $x2610)))))))))))
(assert
 (let ((?x2616 (ite (>= 12 v_0_cb_head) (+ 12 (* (- 1) v_0_cb_head)) (+ 28 (* (- 1) v_0_cb_head)))))
 (let (($x2617 (>= ?x2616 v_0_cb_count)))
 (let (($x2622 (not $x2617)))
 (let (($x2643 (or (not (and $x2622 (<= 1 ?x2616))) (= v_0_cb_end_12 (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2634 (= v_0_cb_end_12 (mod (+ v_0_snd_una v_0_cb_length_12 ?x2236) 4294967296))))
 (let (($x2636 (or (not (and $x2622 (= 12 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_12)) $x2634))))
 (let (($x2621 (or $x2617 (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12)))))
 (and $x2621 (or $x2622 (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12))) $x2636 $x2643)))))))))))
(assert
 (let ((?x2649 (ite (>= 13 v_0_cb_head) (+ 13 (* (- 1) v_0_cb_head)) (+ 29 (* (- 1) v_0_cb_head)))))
 (let (($x2650 (>= ?x2649 v_0_cb_count)))
 (let (($x2655 (not $x2650)))
 (let (($x2676 (or (not (and $x2655 (<= 1 ?x2649))) (= v_0_cb_end_13 (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2667 (= v_0_cb_end_13 (mod (+ v_0_snd_una v_0_cb_length_13 ?x2236) 4294967296))))
 (let (($x2669 (or (not (and $x2655 (= 13 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_13)) $x2667))))
 (let (($x2654 (or $x2650 (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)))))
 (and $x2654 (or $x2655 (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13))) $x2669 $x2676)))))))))))
(assert
 (let ((?x2682 (ite (>= 14 v_0_cb_head) (+ 14 (* (- 1) v_0_cb_head)) (+ 30 (* (- 1) v_0_cb_head)))))
 (let (($x2683 (>= ?x2682 v_0_cb_count)))
 (let (($x2688 (not $x2683)))
 (let (($x2709 (or (not (and $x2688 (<= 1 ?x2682))) (= v_0_cb_end_14 (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2700 (= v_0_cb_end_14 (mod (+ v_0_snd_una v_0_cb_length_14 ?x2236) 4294967296))))
 (let (($x2702 (or (not (and $x2688 (= 14 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_14)) $x2700))))
 (let (($x2687 (or $x2683 (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14)))))
 (and $x2687 (or $x2688 (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14))) $x2702 $x2709)))))))))))
(assert
 (let ((?x2718 (ite (>= 15 v_0_cb_head) (+ 15 (* (- 1) v_0_cb_head)) (+ 31 (* (- 1) v_0_cb_head)))))
 (let (($x2719 (>= ?x2718 v_0_cb_count)))
 (let (($x2721 (not $x2719)))
 (let (($x2742 (or (not (and $x2721 (<= 1 ?x2718))) (= v_0_cb_end_15 (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))))
 (let ((?x653 (- 1)))
 (let ((?x2236 (* ?x653 v_0_cb_partial_prefix)))
 (let (($x2733 (= v_0_cb_end_15 (mod (+ v_0_snd_una v_0_cb_length_15 ?x2236) 4294967296))))
 (let (($x2735 (or (not (and $x2721 (= 15 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_15)) $x2733))))
 (let (($x2720 (or (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)) $x2719)))
 (and $x2720 (or $x2721 (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15))) $x2735 $x2742)))))))))))
(assert
 (= 88 choice_0))
(assert
 (= 4 state_0))
(assert
 (= 4 state_1))
(assert
 (let ((?x2797 (to_real v_1_rtt_last_ms)))
(let ((?x2811 (+ (* (/ 7.0 8.0) v_1_rtt_previous_srtt) (* (/ 1.0 8.0) ?x2797))))
(let ((?x2799 (+ v_1_rtt_previous_srtt (* (- 1.0) ?x2797))))
(let ((?x2803 (ite (>= ?x2799 0.0) ?x2799 (+ (* (- 1.0) v_1_rtt_previous_srtt) ?x2797))))
(let ((?x1708 (/ 1.0 4.0)))
(let ((?x2807 (ite v_1_rtt_previous_measured (+ (* (/ 3.0 4.0) v_1_rtt_previous_var) (* ?x1708 ?x2803)) (* (/ 1.0 2.0) ?x2797))))
(let (($x2814 (and (= v_1_rttvar_ms ?x2807) (= v_1_srtt_ms (ite v_1_rtt_previous_measured ?x2811 ?x2797)))))
(let (($x685 (not v_1_rtt_sample_used)))
(let (($x2788 (= v_1_rtt_last_ms (+ v_1_rtt_sample_at_ms (* (- 1) v_1_rtt_start_ms)))))
(let (($x687 (not v_1_rtt_sample_was_ambiguous)))
(let ((?x2775 (mod (+ v_1_rtt_end (* (- 1) v_1_snd_una)) 4294967296)))
(let (($x2780 (and (<= v_1_rtt_start_ms now_1) (<= 1 v_1_rtt_remaining) (>= 4 v_1_rtt_remaining) (>= ?x2775 v_1_rtt_remaining) (<= ?x2775 (mod (+ v_1_snd_nxt (* (- 1) v_1_snd_una)) 4294967296)))))
(let (($x2769 (not v_1_rtt_active)))
(let ((?x1705 (- 1.0)))
(let ((?x2755 (* ?x1705 (ite (<= v_1_rttvar_ms ?x1708) 1.0 (* 4.0 v_1_rttvar_ms)))))
(let ((?x2757 (to_int (+ (* ?x1705 v_1_srtt_ms) ?x2755))))
(let ((?x653 (- 1)))
(let ((?x2760 (ite (<= ?x2757 (- 1000)) (* ?x653 ?x2757) 1000)))
(let (($x2764 (= v_1_rto_base_ms (ite v_1_rtt_measured (ite (<= 60000 ?x2760) 60000 ?x2760) 1000))))
(or (not $x2764) (not (= v_1_rtt_measured (<= 1 v_1_rtt_samples))) (not (or $x2769 $x2780)) (not (or v_1_rtt_active (= 0 v_1_rtt_remaining))) (not (or $x685 (and $x687 v_1_rtt_measured $x2788))) (not (<= 0 v_1_rtt_sample_at_ms)) (not (<= v_1_rtt_sample_at_ms now_1)) (not (or $x685 $x2814)))))))))))))))))))))))
(check-sat)

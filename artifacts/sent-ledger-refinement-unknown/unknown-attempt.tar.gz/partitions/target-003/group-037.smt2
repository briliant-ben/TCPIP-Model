; benchmark generated from python API
(set-info :status unknown)
(declare-fun v_0_snd_buf () Int)
(declare-fun v_0_rtx_buf () Int)
(declare-fun v_0_rcv_buf () Int)
(declare-fun v_0_rx_chunk () Int)
(declare-fun v_0_rx_slot_00 () Int)
(declare-fun v_0_rx_slot_01 () Int)
(declare-fun v_0_rx_slot_02 () Int)
(declare-fun v_0_rx_slot_03 () Int)
(declare-fun v_0_rx_slot_04 () Int)
(declare-fun v_0_rx_slot_05 () Int)
(declare-fun v_0_rx_slot_06 () Int)
(declare-fun v_0_rx_slot_07 () Int)
(declare-fun v_0_rx_slot_08 () Int)
(declare-fun v_0_rx_slot_09 () Int)
(declare-fun v_0_rx_slot_10 () Int)
(declare-fun v_0_rx_slot_11 () Int)
(declare-fun v_0_rx_slot_12 () Int)
(declare-fun v_0_rx_slot_13 () Int)
(declare-fun v_0_rx_slot_14 () Int)
(declare-fun v_0_rx_slot_15 () Int)
(declare-fun v_1_snd_buf () Int)
(declare-fun v_1_rtx_buf () Int)
(declare-fun v_1_rcv_buf () Int)
(declare-fun v_1_rx_chunk () Int)
(declare-fun v_1_rx_slot_00 () Int)
(declare-fun v_1_rx_slot_01 () Int)
(declare-fun v_1_rx_slot_02 () Int)
(declare-fun v_1_rx_slot_03 () Int)
(declare-fun v_1_rx_slot_04 () Int)
(declare-fun v_1_rx_slot_05 () Int)
(declare-fun v_1_rx_slot_06 () Int)
(declare-fun v_1_rx_slot_07 () Int)
(declare-fun v_1_rx_slot_08 () Int)
(declare-fun v_1_rx_slot_09 () Int)
(declare-fun v_1_rx_slot_10 () Int)
(declare-fun v_1_rx_slot_11 () Int)
(declare-fun v_1_rx_slot_12 () Int)
(declare-fun v_1_rx_slot_13 () Int)
(declare-fun v_1_rx_slot_14 () Int)
(declare-fun v_1_rx_slot_15 () Int)
(declare-fun v_0_iss () Int)
(declare-fun v_0_irs () Int)
(declare-fun v_0_snd_una () Int)
(declare-fun v_0_snd_nxt () Int)
(declare-fun v_0_rcv_nxt () Int)
(declare-fun v_0_tx_seq () Int)
(declare-fun v_0_tx_ack () Int)
(declare-fun v_0_snd_wl1 () Int)
(declare-fun v_0_snd_wl2 () Int)
(declare-fun v_0_fin_seq () Int)
(declare-fun v_0_rx_fin_seq () Int)
(declare-fun v_0_rtt_end () Int)
(declare-fun v_0_cc_before_una () Int)
(declare-fun v_0_fr_before_una () Int)
(declare-fun v_0_fr_before_nxt () Int)
(declare-fun v_0_lt_before_nxt () Int)
(declare-fun v_0_choice_before_nxt () Int)
(declare-fun v_0_cb_before_nxt () Int)
(declare-fun v_0_cb_append_end () Int)
(declare-fun v_0_cb_end_00 () Int)
(declare-fun v_0_cb_end_01 () Int)
(declare-fun v_0_cb_end_02 () Int)
(declare-fun v_0_cb_end_03 () Int)
(declare-fun v_0_cb_end_04 () Int)
(declare-fun v_0_cb_end_05 () Int)
(declare-fun v_0_cb_end_06 () Int)
(declare-fun v_0_cb_end_07 () Int)
(declare-fun v_0_cb_end_08 () Int)
(declare-fun v_0_cb_end_09 () Int)
(declare-fun v_0_cb_end_10 () Int)
(declare-fun v_0_cb_end_11 () Int)
(declare-fun v_0_cb_end_12 () Int)
(declare-fun v_0_cb_end_13 () Int)
(declare-fun v_0_cb_end_14 () Int)
(declare-fun v_0_cb_end_15 () Int)
(declare-fun v_1_iss () Int)
(declare-fun v_1_irs () Int)
(declare-fun v_1_snd_una () Int)
(declare-fun v_1_snd_nxt () Int)
(declare-fun v_1_rcv_nxt () Int)
(declare-fun v_1_tx_seq () Int)
(declare-fun v_1_tx_ack () Int)
(declare-fun v_1_snd_wl1 () Int)
(declare-fun v_1_snd_wl2 () Int)
(declare-fun v_1_fin_seq () Int)
(declare-fun v_1_rx_fin_seq () Int)
(declare-fun v_1_rtt_end () Int)
(declare-fun v_1_cc_before_una () Int)
(declare-fun v_1_fr_before_una () Int)
(declare-fun v_1_fr_before_nxt () Int)
(declare-fun v_1_lt_before_nxt () Int)
(declare-fun v_1_choice_before_nxt () Int)
(declare-fun v_1_cb_before_nxt () Int)
(declare-fun v_1_cb_append_end () Int)
(declare-fun v_1_cb_end_00 () Int)
(declare-fun v_1_cb_end_01 () Int)
(declare-fun v_1_cb_end_02 () Int)
(declare-fun v_1_cb_end_03 () Int)
(declare-fun v_1_cb_end_04 () Int)
(declare-fun v_1_cb_end_05 () Int)
(declare-fun v_1_cb_end_06 () Int)
(declare-fun v_1_cb_end_07 () Int)
(declare-fun v_1_cb_end_08 () Int)
(declare-fun v_1_cb_end_09 () Int)
(declare-fun v_1_cb_end_10 () Int)
(declare-fun v_1_cb_end_11 () Int)
(declare-fun v_1_cb_end_12 () Int)
(declare-fun v_1_cb_end_13 () Int)
(declare-fun v_1_cb_end_14 () Int)
(declare-fun v_1_cb_end_15 () Int)
(declare-fun now_0 () Int)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_delack () Int)
(declare-fun active_0_delack () Bool)
(declare-fun due_0_persist () Int)
(declare-fun active_0_persist () Bool)
(declare-fun input_0_app.send_data () Int)
(declare-fun input_0_net.data_data () Int)
(declare-fun input_0_net.fin_segment_data () Int)
(declare-fun input_0_net.syn_seq () Int)
(declare-fun input_0_net.synack_seq () Int)
(declare-fun input_0_net.synack_ack () Int)
(declare-fun input_0_net.ack_seq () Int)
(declare-fun input_0_net.ack_ack () Int)
(declare-fun input_0_net.fin_seq () Int)
(declare-fun input_0_net.fin_ack () Int)
(declare-fun input_0_net.rst_seq () Int)
(declare-fun input_0_net.rstack_seq () Int)
(declare-fun input_0_net.rstack_ack () Int)
(declare-fun input_0_net.data_seq () Int)
(declare-fun input_0_net.data_ack () Int)
(declare-fun input_0_net.fin_segment_seq () Int)
(declare-fun input_0_net.fin_segment_ack () Int)
(declare-fun v_0_persist_interval_ms () Int)
(declare-fun v_0_rto_ms () Int)
(declare-fun now_1 () Int)
(declare-fun v_0_tx_time_00 () Int)
(declare-fun v_0_tx_time_01 () Int)
(declare-fun v_0_tx_time_02 () Int)
(declare-fun v_0_tx_time_03 () Int)
(declare-fun v_0_persist_active () Bool)
(declare-fun v_0_fin_sent () Bool)
(declare-fun v_0_snd_wnd () Int)
(declare-fun due_1_persist () Int)
(declare-fun due_1_delack () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_persist () Bool)
(declare-fun active_1_delack () Bool)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_cb_done_15 () Bool)
(declare-fun v_0_cb_tail () Int)
(declare-fun v_0_cb_length_15 () Int)
(declare-fun v_1_cb_length_15 () Int)
(declare-fun v_1_cb_done_14 () Bool)
(declare-fun v_0_cb_length_14 () Int)
(declare-fun v_1_cb_length_14 () Int)
(declare-fun v_1_cb_done_13 () Bool)
(declare-fun v_0_cb_length_13 () Int)
(declare-fun v_1_cb_length_13 () Int)
(declare-fun v_1_cb_done_12 () Bool)
(declare-fun v_0_cb_length_12 () Int)
(declare-fun v_1_cb_length_12 () Int)
(declare-fun v_1_cb_done_11 () Bool)
(declare-fun v_0_cb_length_11 () Int)
(declare-fun v_1_cb_length_11 () Int)
(declare-fun v_1_cb_done_10 () Bool)
(declare-fun v_0_cb_length_10 () Int)
(declare-fun v_1_cb_length_10 () Int)
(declare-fun v_1_cb_done_09 () Bool)
(declare-fun v_0_cb_length_09 () Int)
(declare-fun v_1_cb_length_09 () Int)
(declare-fun v_1_cb_done_08 () Bool)
(declare-fun v_0_cb_length_08 () Int)
(declare-fun v_1_cb_length_08 () Int)
(declare-fun v_1_cb_done_07 () Bool)
(declare-fun v_0_cb_length_07 () Int)
(declare-fun v_1_cb_length_07 () Int)
(declare-fun v_1_cb_done_06 () Bool)
(declare-fun v_0_cb_length_06 () Int)
(declare-fun v_1_cb_length_06 () Int)
(declare-fun v_1_cb_done_05 () Bool)
(declare-fun v_0_cb_length_05 () Int)
(declare-fun v_1_cb_length_05 () Int)
(declare-fun v_1_cb_done_04 () Bool)
(declare-fun v_0_cb_length_04 () Int)
(declare-fun v_1_cb_length_04 () Int)
(declare-fun v_1_cb_done_03 () Bool)
(declare-fun v_0_cb_length_03 () Int)
(declare-fun v_1_cb_length_03 () Int)
(declare-fun v_1_cb_done_02 () Bool)
(declare-fun v_0_cb_length_02 () Int)
(declare-fun v_1_cb_length_02 () Int)
(declare-fun v_1_cb_done_01 () Bool)
(declare-fun v_0_cb_length_01 () Int)
(declare-fun v_1_cb_length_01 () Int)
(declare-fun v_1_cb_done_00 () Bool)
(declare-fun v_0_cb_length_00 () Int)
(declare-fun v_1_cb_length_00 () Int)
(declare-fun v_1_cb_is_new () Bool)
(declare-fun v_1_cb_drop_step () Int)
(declare-fun v_0_cb_abandoned_total () Int)
(declare-fun v_1_cb_abandoned_total () Int)
(declare-fun v_0_cb_acked_total () Int)
(declare-fun v_1_cb_acked_total () Int)
(declare-fun v_0_cb_emitted_total () Int)
(declare-fun v_1_cb_emitted_total () Int)
(declare-fun v_1_cb_partial_prefix () Int)
(declare-fun v_1_cb_live_total () Int)
(declare-fun v_1_cb_step_bytes () Int)
(declare-fun v_1_cb_retired_count () Int)
(declare-fun v_1_cb_append_length () Int)
(declare-fun v_1_cb_new_count () Int)
(declare-fun v_0_cb_count () Int)
(declare-fun v_1_cb_count () Int)
(declare-fun v_1_cb_tail () Int)
(declare-fun v_0_cb_head () Int)
(declare-fun v_1_cb_head () Int)
(declare-fun v_0_svc_abandoned_bytes () Int)
(declare-fun v_1_svc_abandoned_bytes () Int)
(declare-fun v_0_svc_acked_bytes () Int)
(declare-fun v_1_svc_acked_bytes () Int)
(declare-fun v_0_svc_written_bytes () Int)
(declare-fun v_1_svc_written_bytes () Int)
(declare-fun v_1_svc_drop_step () Int)
(declare-fun v_1_svc_ack_step () Int)
(declare-fun v_1_svc_accept_step () Int)
(declare-fun v_1_svc_before_total () Int)
(declare-fun v_1_sched_packets () Int)
(declare-fun v_1_sched_bytes () Int)
(declare-fun v_1_sched_cause () Int)
(declare-fun v_0_sched_at_ms () Int)
(declare-fun v_1_sched_at_ms () Int)
(declare-fun v_1_sched_open () Bool)
(declare-fun v_0_choice_before_flight () Int)
(declare-fun v_1_choice_before_flight () Int)
(declare-fun v_0_choice_limit () Int)
(declare-fun v_1_choice_limit () Int)
(declare-fun v_0_choice_count () Int)
(declare-fun v_1_choice_count () Int)
(declare-fun v_1_choice_used () Bool)
(declare-fun v_0_lt_epoch_bytes () Int)
(declare-fun v_1_lt_loss_flight () Int)
(declare-fun v_1_lt_before_window () Int)
(declare-fun v_1_lt_before_flight () Int)
(declare-fun v_0_cc_cwnd () Int)
(declare-fun v_1_lt_before_cwnd () Int)
(declare-fun v_1_lt_before_bytes () Int)
(declare-fun v_0_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_bytes () Int)
(declare-fun v_1_lt_take () Int)
(declare-fun v_1_lt_emitted () Bool)
(declare-fun v_1_lt_eligible () Bool)
(declare-fun v_0_idle_restart_count () Int)
(declare-fun v_1_idle_restart_count () Int)
(declare-fun v_0_cc_ssthresh () Int)
(declare-fun v_1_idle_before_threshold () Int)
(declare-fun v_1_idle_before_rto () Int)
(declare-fun v_1_idle_before_cwnd () Int)
(declare-fun v_0_idle_last_data_ms () Int)
(declare-fun v_0_idle_data_valid () Bool)
(declare-fun v_1_idle_elapsed_ms () Int)
(declare-fun v_1_idle_restart () Bool)
(declare-fun v_1_idle_data_emitted () Bool)
(declare-fun v_1_idle_event_ms () Int)
(declare-fun v_1_idle_last_data_ms () Int)
(declare-fun v_1_idle_data_valid () Bool)
(declare-fun v_0_fr_entries () Int)
(declare-fun v_1_fr_entries () Int)
(declare-fun v_1_fr_emit_count () Int)
(declare-fun v_1_fr_retransmitted () Bool)
(declare-fun v_1_fr_exited () Bool)
(declare-fun v_1_fr_extra () Bool)
(declare-fun v_1_fr_entered () Bool)
(declare-fun v_1_fr_duplicate () Bool)
(declare-fun v_0_retries () Int)
(declare-fun v_1_fr_before_retries () Int)
(declare-fun v_1_fr_before_rto () Int)
(declare-fun v_1_fr_before_flight () Int)
(declare-fun v_0_fr_active () Bool)
(declare-fun v_1_fr_was_active () Bool)
(declare-fun v_0_fr_last_window () Int)
(declare-fun v_1_fr_last_window () Int)
(declare-fun v_0_fr_window_valid () Bool)
(declare-fun v_1_fr_window_valid () Bool)
(declare-fun v_0_fr_dupacks () Int)
(declare-fun v_1_fr_dupacks () Int)
(declare-fun v_1_fr_active () Bool)
(declare-fun v_1_fr_before_window_valid () Bool)
(declare-fun v_1_fr_before_wire_window () Int)
(declare-fun v_1_fr_window_ignored () Bool)
(declare-fun v_0_cc_rto_15 () Bool)
(declare-fun v_1_cc_rto_15 () Bool)
(declare-fun v_0_cc_rto_14 () Bool)
(declare-fun v_1_cc_rto_14 () Bool)
(declare-fun v_0_cc_rto_13 () Bool)
(declare-fun v_1_cc_rto_13 () Bool)
(declare-fun v_0_cc_rto_12 () Bool)
(declare-fun v_1_cc_rto_12 () Bool)
(declare-fun v_0_cc_rto_11 () Bool)
(declare-fun v_1_cc_rto_11 () Bool)
(declare-fun v_0_cc_rto_10 () Bool)
(declare-fun v_1_cc_rto_10 () Bool)
(declare-fun v_0_cc_rto_09 () Bool)
(declare-fun v_1_cc_rto_09 () Bool)
(declare-fun v_0_cc_rto_08 () Bool)
(declare-fun v_1_cc_rto_08 () Bool)
(declare-fun v_0_cc_rto_07 () Bool)
(declare-fun v_1_cc_rto_07 () Bool)
(declare-fun v_0_cc_rto_06 () Bool)
(declare-fun v_1_cc_rto_06 () Bool)
(declare-fun v_0_cc_rto_05 () Bool)
(declare-fun v_1_cc_rto_05 () Bool)
(declare-fun v_0_cc_rto_04 () Bool)
(declare-fun v_1_cc_rto_04 () Bool)
(declare-fun v_0_cc_rto_03 () Bool)
(declare-fun v_1_cc_rto_03 () Bool)
(declare-fun v_0_cc_rto_02 () Bool)
(declare-fun v_1_cc_rto_02 () Bool)
(declare-fun v_0_cc_rto_01 () Bool)
(declare-fun v_1_cc_rto_01 () Bool)
(declare-fun v_0_cc_rto_00 () Bool)
(declare-fun v_1_cc_rto_00 () Bool)
(declare-fun v_1_cc_new_sent () Int)
(declare-fun v_1_cc_send_budget () Int)
(declare-fun v_1_cc_before_cwnd () Int)
(declare-fun v_1_cc_growth () Int)
(declare-fun v_0_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_changed () Bool)
(declare-fun v_1_cc_loss () Bool)
(declare-fun v_1_cc_before_window () Int)
(declare-fun v_1_cc_before_persist () Bool)
(declare-fun v_1_cc_before_flight () Int)
(declare-fun v_1_cc_acked () Int)
(declare-fun v_0_cc_ca_credit () Int)
(declare-fun v_1_cc_ca_credit () Int)
(declare-fun v_1_cc_ssthresh () Int)
(declare-fun v_1_cc_cwnd () Int)
(declare-fun v_0_cc_initial_threshold () Int)
(declare-fun v_1_cc_initial_threshold () Int)
(declare-fun v_0_cc_initial_window () Int)
(declare-fun v_1_cc_initial_window () Int)
(declare-fun v_0_persist_elapsed_ms () Int)
(declare-fun v_1_persist_elapsed_ms () Int)
(declare-fun v_0_persist_probes () Int)
(declare-fun v_1_persist_probes () Int)
(declare-fun v_0_persist_deadline_ms () Int)
(declare-fun v_1_persist_deadline_ms () Int)
(declare-fun v_0_persist_last_ms () Int)
(declare-fun v_1_persist_last_ms () Int)
(declare-fun v_0_persist_since_ms () Int)
(declare-fun v_1_persist_since_ms () Int)
(declare-fun v_0_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_interval_ms () Int)
(declare-fun v_1_persist_probe_new () Bool)
(declare-fun v_1_persist_probe_sent () Bool)
(declare-fun v_1_persist_first () Bool)
(declare-fun v_1_persist_was_active () Bool)
(declare-fun v_1_persist_start () Bool)
(declare-fun v_1_persist_eligible () Bool)
(declare-fun v_1_persist_active () Bool)
(declare-fun v_1_ack_defer_now () Bool)
(declare-fun v_1_ack_defer_candidate () Bool)
(declare-fun v_0_ack_rmss () Int)
(declare-fun v_1_ack_rmss () Int)
(declare-fun v_0_ack_delay_ms () Int)
(declare-fun v_1_ack_delay_ms () Int)
(declare-fun v_0_ack_full_segments () Int)
(declare-fun v_1_ack_full_segments () Int)
(declare-fun v_0_ack_bytes () Int)
(declare-fun v_1_ack_bytes () Int)
(declare-fun v_0_ack_since_ms () Int)
(declare-fun v_1_ack_since_ms () Int)
(declare-fun v_0_ack_pending () Bool)
(declare-fun v_1_ack_pending () Bool)
(declare-fun v_1_syn_timeout_eligible () Bool)
(declare-fun v_1_tx_syn_pending () Bool)
(declare-fun v_1_tx_syn_time () Int)
(declare-fun v_1_tx_waiting () Bool)
(declare-fun v_1_tx_is_fin () Bool)
(declare-fun v_1_tx_previous_rto () Int)
(declare-fun v_1_tx_elapsed () Int)
(declare-fun v_1_tx_retransmitted () Bool)
(declare-fun v_1_tx_max_previous () Int)
(declare-fun v_1_tx_eligible () Int)
(declare-fun v_1_tx_emit_count () Int)
(declare-fun v_0_tx_fin_time () Int)
(declare-fun v_0_fin_acknowledged () Bool)
(declare-fun v_1_tx_fin_time () Int)
(declare-fun v_0_tx_time_15 () Int)
(declare-fun v_1_tx_time_15 () Int)
(declare-fun v_0_tx_time_14 () Int)
(declare-fun v_1_tx_time_14 () Int)
(declare-fun v_0_tx_time_13 () Int)
(declare-fun v_1_tx_time_13 () Int)
(declare-fun v_0_tx_time_12 () Int)
(declare-fun v_1_tx_time_12 () Int)
(declare-fun v_0_tx_time_11 () Int)
(declare-fun v_1_tx_time_11 () Int)
(declare-fun v_0_tx_time_10 () Int)
(declare-fun v_1_tx_time_10 () Int)
(declare-fun v_0_tx_time_09 () Int)
(declare-fun v_1_tx_time_09 () Int)
(declare-fun v_0_tx_time_08 () Int)
(declare-fun v_1_tx_time_08 () Int)
(declare-fun v_0_tx_time_07 () Int)
(declare-fun v_1_tx_time_07 () Int)
(declare-fun v_0_tx_time_06 () Int)
(declare-fun v_1_tx_time_06 () Int)
(declare-fun v_0_tx_time_05 () Int)
(declare-fun v_1_tx_time_05 () Int)
(declare-fun v_0_tx_time_04 () Int)
(declare-fun v_1_tx_time_04 () Int)
(declare-fun v_1_tx_time_03 () Int)
(declare-fun v_1_tx_time_02 () Int)
(declare-fun v_1_tx_time_01 () Int)
(declare-fun v_1_tx_time_00 () Int)
(declare-fun v_0_rto_base_ms () Int)
(declare-fun v_1_rto_base_ms () Int)
(declare-fun v_0_rtt_samples () Int)
(declare-fun v_1_rtt_samples () Int)
(declare-fun v_0_rtt_last_ms () Int)
(declare-fun v_1_rtt_last_ms () Int)
(declare-fun v_1_rtt_sample_was_ambiguous () Bool)
(declare-fun v_1_rtt_sample_used () Bool)
(declare-fun v_1_rtt_start_new () Bool)
(declare-fun v_0_rtt_remaining () Int)
(declare-fun v_1_rtt_remaining () Int)
(declare-fun v_0_rtt_start_ms () Int)
(declare-fun v_1_rtt_start_ms () Int)
(declare-fun v_0_rtt_sample_at_ms () Int)
(declare-fun v_1_rtt_sample_at_ms () Int)
(declare-fun v_0_rtt_active () Bool)
(declare-fun v_0_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_active () Bool)
(declare-fun v_0_rtt_previous_measured () Bool)
(declare-fun v_1_rtt_previous_measured () Bool)
(declare-fun v_0_rtt_measured () Bool)
(declare-fun v_1_rtt_measured () Bool)
(declare-fun v_0_rtt_previous_var () Real)
(declare-fun v_1_rtt_previous_var () Real)
(declare-fun v_0_rtt_previous_srtt () Real)
(declare-fun v_1_rtt_previous_srtt () Real)
(declare-fun v_0_rtt_error_ms () Real)
(declare-fun v_1_rtt_error_ms () Real)
(declare-fun v_0_rttvar_ms () Real)
(declare-fun v_1_rttvar_ms () Real)
(declare-fun v_0_srtt_ms () Real)
(declare-fun v_1_srtt_ms () Real)
(declare-fun v_0_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_consumed () Bool)
(declare-fun v_0_rx_fin_done () Bool)
(declare-fun v_1_rx_fin_done () Bool)
(declare-fun v_0_rx_fin_offset () Int)
(declare-fun v_1_rx_fin_offset () Int)
(declare-fun v_0_rx_fin_pending () Bool)
(declare-fun v_1_rx_fin_pending () Bool)
(declare-fun v_1_fin_acknowledged () Bool)
(declare-fun v_1_fin_sent () Bool)
(declare-fun v_0_fin_requested () Bool)
(declare-fun v_1_fin_requested () Bool)
(declare-fun v_0_ack_window_update () Bool)
(declare-fun v_1_ack_window_update () Bool)
(declare-fun v_0_ack_advance () Bool)
(declare-fun v_1_ack_advance () Bool)
(declare-fun v_0_ack_is_future () Bool)
(declare-fun v_1_ack_is_future () Bool)
(declare-fun v_0_ack_is_new () Bool)
(declare-fun v_1_ack_is_new () Bool)
(declare-fun v_0_ack_delta () Int)
(declare-fun v_1_ack_delta () Int)
(declare-fun v_0_seg_acceptable () Bool)
(declare-fun v_1_seg_acceptable () Bool)
(declare-fun v_0_rx_acceptable () Bool)
(declare-fun v_1_rx_acceptable () Bool)
(declare-fun v_0_rx_advance () Int)
(declare-fun v_1_rx_advance () Int)
(declare-fun v_0_take () Int)
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_1_local_window () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_0_tx_flags () String)
(declare-fun v_1_tx_flags () String)
(declare-fun v_0_rtt_sample_was_ambiguous () Bool)
(declare-fun v_0_rtt_sample_used () Bool)
(declare-fun v_0_tx_emit_count () Int)
(declare-fun v_0_tx_eligible () Int)
(declare-fun v_0_tx_previous_rto () Int)
(declare-fun v_0_tx_max_previous () Int)
(declare-fun v_0_tx_elapsed () Int)
(declare-fun v_0_tx_is_fin () Bool)
(declare-fun v_0_tx_retransmitted () Bool)
(declare-fun v_0_tx_waiting () Bool)
(declare-fun v_0_tx_syn_time () Int)
(declare-fun v_0_tx_syn_pending () Bool)
(declare-fun v_0_persist_probe_sent () Bool)
(declare-fun v_0_cc_acked () Int)
(declare-fun v_0_cc_growth () Int)
(declare-fun v_0_cc_send_budget () Int)
(declare-fun v_0_cc_new_sent () Int)
(declare-fun v_0_fr_emit_count () Int)
(declare-fun v_0_fr_before_retries () Int)
(declare-fun v_0_fr_before_rto () Int)
(declare-fun v_0_fr_entered () Bool)
(declare-fun v_0_fr_retransmitted () Bool)
(declare-fun v_0_fr_before_window_valid () Bool)
(declare-fun v_0_fr_before_wire_window () Int)
(declare-fun v_0_fr_window_ignored () Bool)
(declare-fun v_0_fr_exited () Bool)
(declare-fun v_0_idle_elapsed_ms () Int)
(declare-fun v_0_idle_event_ms () Int)
(declare-fun v_0_idle_data_emitted () Bool)
(declare-fun v_0_idle_before_threshold () Int)
(declare-fun v_0_idle_before_cwnd () Int)
(declare-fun v_0_idle_before_rto () Int)
(declare-fun v_0_idle_restart () Bool)
(declare-fun v_0_lt_loss_flight () Int)
(declare-fun v_0_lt_take () Int)
(declare-fun v_0_lt_before_flight () Int)
(declare-fun v_0_lt_before_cwnd () Int)
(declare-fun v_0_fr_duplicate () Bool)
(declare-fun v_0_lt_emitted () Bool)
(declare-fun v_0_lt_before_bytes () Int)
(declare-fun v_0_fr_before_flight () Int)
(declare-fun v_0_choice_used () Bool)
(declare-fun v_0_sched_bytes () Int)
(declare-fun v_0_sched_packets () Int)
(declare-fun v_0_sched_cause () Int)
(declare-fun v_0_sched_open () Bool)
(declare-fun v_0_svc_drop_step () Int)
(declare-fun v_0_svc_ack_step () Int)
(declare-fun v_0_svc_accept_step () Int)
(declare-fun v_0_cb_new_count () Int)
(declare-fun v_0_cb_live_total () Int)
(declare-fun v_0_cb_drop_step () Int)
(declare-fun v_0_cb_step_bytes () Int)
(declare-fun v_0_cb_partial_prefix () Int)
(declare-fun choice_0 () Int)
(declare-fun state_0 () Int)
(declare-fun state_1 () Int)
(assert
 (>= v_0_snd_buf 0))
(assert
 (>= v_0_rtx_buf 0))
(assert
 (>= v_0_rcv_buf 0))
(assert
 (>= v_0_rx_chunk 0))
(assert
 (>= v_0_rx_slot_00 0))
(assert
 (>= v_0_rx_slot_01 0))
(assert
 (>= v_0_rx_slot_02 0))
(assert
 (>= v_0_rx_slot_03 0))
(assert
 (>= v_0_rx_slot_04 0))
(assert
 (>= v_0_rx_slot_05 0))
(assert
 (>= v_0_rx_slot_06 0))
(assert
 (>= v_0_rx_slot_07 0))
(assert
 (>= v_0_rx_slot_08 0))
(assert
 (>= v_0_rx_slot_09 0))
(assert
 (>= v_0_rx_slot_10 0))
(assert
 (>= v_0_rx_slot_11 0))
(assert
 (>= v_0_rx_slot_12 0))
(assert
 (>= v_0_rx_slot_13 0))
(assert
 (>= v_0_rx_slot_14 0))
(assert
 (>= v_0_rx_slot_15 0))
(assert
 (>= v_1_snd_buf 0))
(assert
 (>= v_1_rtx_buf 0))
(assert
 (>= v_1_rcv_buf 0))
(assert
 (>= v_1_rx_chunk 0))
(assert
 (>= v_1_rx_slot_00 0))
(assert
 (>= v_1_rx_slot_01 0))
(assert
 (>= v_1_rx_slot_02 0))
(assert
 (>= v_1_rx_slot_03 0))
(assert
 (>= v_1_rx_slot_04 0))
(assert
 (>= v_1_rx_slot_05 0))
(assert
 (>= v_1_rx_slot_06 0))
(assert
 (>= v_1_rx_slot_07 0))
(assert
 (>= v_1_rx_slot_08 0))
(assert
 (>= v_1_rx_slot_09 0))
(assert
 (>= v_1_rx_slot_10 0))
(assert
 (>= v_1_rx_slot_11 0))
(assert
 (>= v_1_rx_slot_12 0))
(assert
 (>= v_1_rx_slot_13 0))
(assert
 (>= v_1_rx_slot_14 0))
(assert
 (>= v_1_rx_slot_15 0))
(assert
 (>= v_0_iss 0))
(assert
 (not (<= 4294967296 v_0_iss)))
(assert
 (>= v_0_irs 0))
(assert
 (not (<= 4294967296 v_0_irs)))
(assert
 (>= v_0_snd_una 0))
(assert
 (not (<= 4294967296 v_0_snd_una)))
(assert
 (>= v_0_snd_nxt 0))
(assert
 (not (<= 4294967296 v_0_snd_nxt)))
(assert
 (>= v_0_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_0_rcv_nxt)))
(assert
 (>= v_0_tx_seq 0))
(assert
 (not (<= 4294967296 v_0_tx_seq)))
(assert
 (>= v_0_tx_ack 0))
(assert
 (not (<= 4294967296 v_0_tx_ack)))
(assert
 (>= v_0_snd_wl1 0))
(assert
 (not (<= 4294967296 v_0_snd_wl1)))
(assert
 (>= v_0_snd_wl2 0))
(assert
 (not (<= 4294967296 v_0_snd_wl2)))
(assert
 (>= v_0_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_fin_seq)))
(assert
 (>= v_0_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_0_rx_fin_seq)))
(assert
 (>= v_0_rtt_end 0))
(assert
 (not (<= 4294967296 v_0_rtt_end)))
(assert
 (>= v_0_cc_before_una 0))
(assert
 (not (<= 4294967296 v_0_cc_before_una)))
(assert
 (>= v_0_fr_before_una 0))
(assert
 (not (<= 4294967296 v_0_fr_before_una)))
(assert
 (>= v_0_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_fr_before_nxt)))
(assert
 (>= v_0_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_lt_before_nxt)))
(assert
 (>= v_0_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_choice_before_nxt)))
(assert
 (>= v_0_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_0_cb_before_nxt)))
(assert
 (>= v_0_cb_append_end 0))
(assert
 (not (<= 4294967296 v_0_cb_append_end)))
(assert
 (>= v_0_cb_end_00 0))
(assert
 (not (<= 4294967296 v_0_cb_end_00)))
(assert
 (>= v_0_cb_end_01 0))
(assert
 (not (<= 4294967296 v_0_cb_end_01)))
(assert
 (>= v_0_cb_end_02 0))
(assert
 (not (<= 4294967296 v_0_cb_end_02)))
(assert
 (>= v_0_cb_end_03 0))
(assert
 (not (<= 4294967296 v_0_cb_end_03)))
(assert
 (>= v_0_cb_end_04 0))
(assert
 (not (<= 4294967296 v_0_cb_end_04)))
(assert
 (>= v_0_cb_end_05 0))
(assert
 (not (<= 4294967296 v_0_cb_end_05)))
(assert
 (>= v_0_cb_end_06 0))
(assert
 (not (<= 4294967296 v_0_cb_end_06)))
(assert
 (>= v_0_cb_end_07 0))
(assert
 (not (<= 4294967296 v_0_cb_end_07)))
(assert
 (>= v_0_cb_end_08 0))
(assert
 (not (<= 4294967296 v_0_cb_end_08)))
(assert
 (>= v_0_cb_end_09 0))
(assert
 (not (<= 4294967296 v_0_cb_end_09)))
(assert
 (>= v_0_cb_end_10 0))
(assert
 (not (<= 4294967296 v_0_cb_end_10)))
(assert
 (>= v_0_cb_end_11 0))
(assert
 (not (<= 4294967296 v_0_cb_end_11)))
(assert
 (>= v_0_cb_end_12 0))
(assert
 (not (<= 4294967296 v_0_cb_end_12)))
(assert
 (>= v_0_cb_end_13 0))
(assert
 (not (<= 4294967296 v_0_cb_end_13)))
(assert
 (>= v_0_cb_end_14 0))
(assert
 (not (<= 4294967296 v_0_cb_end_14)))
(assert
 (>= v_0_cb_end_15 0))
(assert
 (not (<= 4294967296 v_0_cb_end_15)))
(assert
 (>= v_1_iss 0))
(assert
 (not (<= 4294967296 v_1_iss)))
(assert
 (>= v_1_irs 0))
(assert
 (not (<= 4294967296 v_1_irs)))
(assert
 (>= v_1_snd_una 0))
(assert
 (not (<= 4294967296 v_1_snd_una)))
(assert
 (>= v_1_snd_nxt 0))
(assert
 (not (<= 4294967296 v_1_snd_nxt)))
(assert
 (>= v_1_rcv_nxt 0))
(assert
 (not (<= 4294967296 v_1_rcv_nxt)))
(assert
 (>= v_1_tx_seq 0))
(assert
 (not (<= 4294967296 v_1_tx_seq)))
(assert
 (>= v_1_tx_ack 0))
(assert
 (not (<= 4294967296 v_1_tx_ack)))
(assert
 (>= v_1_snd_wl1 0))
(assert
 (not (<= 4294967296 v_1_snd_wl1)))
(assert
 (>= v_1_snd_wl2 0))
(assert
 (not (<= 4294967296 v_1_snd_wl2)))
(assert
 (>= v_1_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_fin_seq)))
(assert
 (>= v_1_rx_fin_seq 0))
(assert
 (not (<= 4294967296 v_1_rx_fin_seq)))
(assert
 (>= v_1_rtt_end 0))
(assert
 (not (<= 4294967296 v_1_rtt_end)))
(assert
 (>= v_1_cc_before_una 0))
(assert
 (not (<= 4294967296 v_1_cc_before_una)))
(assert
 (>= v_1_fr_before_una 0))
(assert
 (not (<= 4294967296 v_1_fr_before_una)))
(assert
 (>= v_1_fr_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_fr_before_nxt)))
(assert
 (>= v_1_lt_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_lt_before_nxt)))
(assert
 (>= v_1_choice_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_choice_before_nxt)))
(assert
 (>= v_1_cb_before_nxt 0))
(assert
 (not (<= 4294967296 v_1_cb_before_nxt)))
(assert
 (>= v_1_cb_append_end 0))
(assert
 (not (<= 4294967296 v_1_cb_append_end)))
(assert
 (>= v_1_cb_end_00 0))
(assert
 (not (<= 4294967296 v_1_cb_end_00)))
(assert
 (>= v_1_cb_end_01 0))
(assert
 (not (<= 4294967296 v_1_cb_end_01)))
(assert
 (>= v_1_cb_end_02 0))
(assert
 (not (<= 4294967296 v_1_cb_end_02)))
(assert
 (>= v_1_cb_end_03 0))
(assert
 (not (<= 4294967296 v_1_cb_end_03)))
(assert
 (>= v_1_cb_end_04 0))
(assert
 (not (<= 4294967296 v_1_cb_end_04)))
(assert
 (>= v_1_cb_end_05 0))
(assert
 (not (<= 4294967296 v_1_cb_end_05)))
(assert
 (>= v_1_cb_end_06 0))
(assert
 (not (<= 4294967296 v_1_cb_end_06)))
(assert
 (>= v_1_cb_end_07 0))
(assert
 (not (<= 4294967296 v_1_cb_end_07)))
(assert
 (>= v_1_cb_end_08 0))
(assert
 (not (<= 4294967296 v_1_cb_end_08)))
(assert
 (>= v_1_cb_end_09 0))
(assert
 (not (<= 4294967296 v_1_cb_end_09)))
(assert
 (>= v_1_cb_end_10 0))
(assert
 (not (<= 4294967296 v_1_cb_end_10)))
(assert
 (>= v_1_cb_end_11 0))
(assert
 (not (<= 4294967296 v_1_cb_end_11)))
(assert
 (>= v_1_cb_end_12 0))
(assert
 (not (<= 4294967296 v_1_cb_end_12)))
(assert
 (>= v_1_cb_end_13 0))
(assert
 (not (<= 4294967296 v_1_cb_end_13)))
(assert
 (>= v_1_cb_end_14 0))
(assert
 (not (<= 4294967296 v_1_cb_end_14)))
(assert
 (>= v_1_cb_end_15 0))
(assert
 (not (<= 4294967296 v_1_cb_end_15)))
(assert
 true)
(assert
 true)
(assert
 (>= now_0 0))
(assert
 (let (($x370 (not active_0_rtx)))
 (or $x370 (>= due_0_rtx now_0))))
(assert
 (let (($x375 (not active_0_user)))
 (or $x375 (>= due_0_user now_0))))
(assert
 (let (($x380 (not active_0_time_wait)))
 (or $x380 (>= due_0_time_wait now_0))))
(assert
 (let (($x385 (not active_0_delack)))
 (or $x385 (>= due_0_delack now_0))))
(assert
 (let (($x390 (not active_0_persist)))
 (or $x390 (>= due_0_persist now_0))))
(assert
 (>= input_0_app.send_data 0))
(assert
 (>= input_0_net.data_data 0))
(assert
 (>= input_0_net.fin_segment_data 0))
(assert
 (>= input_0_net.syn_seq 0))
(assert
 (not (<= 4294967296 input_0_net.syn_seq)))
(assert
 (>= input_0_net.synack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.synack_seq)))
(assert
 (>= input_0_net.synack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.synack_ack)))
(assert
 (>= input_0_net.ack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.ack_seq)))
(assert
 (>= input_0_net.ack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.ack_ack)))
(assert
 (>= input_0_net.fin_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_seq)))
(assert
 (>= input_0_net.fin_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_ack)))
(assert
 (>= input_0_net.rst_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rst_seq)))
(assert
 (>= input_0_net.rstack_seq 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_seq)))
(assert
 (>= input_0_net.rstack_ack 0))
(assert
 (not (<= 4294967296 input_0_net.rstack_ack)))
(assert
 (>= input_0_net.data_seq 0))
(assert
 (not (<= 4294967296 input_0_net.data_seq)))
(assert
 (>= input_0_net.data_ack 0))
(assert
 (not (<= 4294967296 input_0_net.data_ack)))
(assert
 (>= input_0_net.fin_segment_seq 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_seq)))
(assert
 (>= input_0_net.fin_segment_ack 0))
(assert
 (not (<= 4294967296 input_0_net.fin_segment_ack)))
(assert
 (let ((?x518 (ite (>= v_0_rto_ms 30000) 60000 (* 2 v_0_rto_ms))))
 (let (($x487 (<= (+ v_0_tx_time_00 v_0_rto_ms) now_1)))
 (let (($x459 (<= 1 v_0_rtx_buf)))
 (let (($x492 (<= (+ v_0_tx_time_01 v_0_rto_ms) now_1)))
 (let (($x489 (<= 2 v_0_rtx_buf)))
 (let ((?x508 (ite (and $x459 $x487 $x489 $x492) 2 (ite (and $x459 $x487) 1 0))))
 (let (($x497 (<= (+ v_0_tx_time_02 v_0_rto_ms) now_1)))
 (let (($x494 (<= 3 v_0_rtx_buf)))
 (let (($x503 (and $x459 $x487 $x489 $x492 $x494 $x497 (<= 4 v_0_rtx_buf) (<= (+ v_0_tx_time_03 v_0_rto_ms) now_1))))
 (let ((?x510 (ite $x503 4 (ite (and $x459 $x487 $x489 $x492 $x494 $x497) 3 ?x508))))
 (let ((?x512 (ite (<= 1 ?x510) 1 ?x510)))
 (let (($x513 (<= 1 ?x512)))
 (let ((?x519 (ite $x513 ?x518 v_0_rto_ms)))
 (let (($x886 (not v_0_persist_active)))
 (let (($x639 (= 0 v_0_rtx_buf)))
 (let (($x640 (or v_0_persist_active $x639)))
 (let (($x637 (>= 1 v_0_rtx_buf)))
 (let (($x636 (<= 1 (+ v_0_rtx_buf v_0_snd_buf))))
 (let (($x634 (not v_0_fin_sent)))
 (let (($x461 (= 0 v_0_snd_wnd)))
 (let (($x887 (and $x461 $x634 $x636 $x637 $x640 $x886)))
 (let ((?x899 (ite $x887 ?x519 v_0_persist_interval_ms)))
 (let ((?x916 (+ now_1 ?x899)))
 (let (($x1492 (= due_1_delack due_0_delack)))
 (let (($x1490 (= due_1_time_wait due_0_time_wait)))
 (let (($x1488 (= due_1_user due_0_user)))
 (let ((?x1483 (ite $x513 ?x518 (+ (ite $x513 now_1 v_0_tx_time_00) ?x519 (* (- 1) now_1)))))
 (let (($x641 (and $x461 $x634 $x636 $x637 $x640)))
 (let (($x642 (not $x641)))
 (let (($x1465 (and v_0_persist_active $x642 $x459 $x461 $x634 $x636 $x637 $x640)))
 (let (($x1478 (= active_1_persist (and $x461 $x634 $x636 $x637 $x640 (or active_0_persist $x887)))))
 (let (($x1471 (= active_1_time_wait active_0_time_wait)))
 (let (($x1469 (= active_1_user active_0_user)))
 (let (($x1463 (not v_1_cb_done_15)))
 (let ((?x658 (ite (<= 0 ?x512) ?x512 0)))
 (let (($x655 (<= v_0_rtx_buf 0)))
 (let ((?x656 (ite $x655 0 v_0_rtx_buf)))
 (let ((?x660 (ite (<= ?x656 ?x658) ?x656 ?x658)))
 (let (($x1258 (= v_0_snd_una v_0_snd_nxt)))
 (let (($x1152 (<= 1 ?x660)))
 (let (($x1259 (and $x513 $x1152 $x1258)))
 (let ((?x1364 (ite $x1259 (mod (+ v_0_snd_una ?x660) 4294967296) 0)))
 (let (($x1341 (and $x513 $x1152 $x1258 (= 15 v_0_cb_tail))))
 (let ((?x1273 (ite $x1259 ?x660 0)))
 (let ((?x1343 (ite $x1341 ?x1273 v_0_cb_length_15)))
 (let (($x1457 (not v_1_cb_done_14)))
 (let (($x1455 (= v_1_cb_end_14 (ite (and $x513 $x1152 $x1258 (= 14 v_0_cb_tail)) ?x1364 v_0_cb_end_14))))
 (let (($x1337 (and $x513 $x1152 $x1258 (= 14 v_0_cb_tail))))
 (let ((?x1339 (ite $x1337 ?x1273 v_0_cb_length_14)))
 (let (($x1451 (not v_1_cb_done_13)))
 (let (($x1449 (= v_1_cb_end_13 (ite (and $x513 $x1152 $x1258 (= 13 v_0_cb_tail)) ?x1364 v_0_cb_end_13))))
 (let (($x1333 (and $x513 $x1152 $x1258 (= 13 v_0_cb_tail))))
 (let ((?x1335 (ite $x1333 ?x1273 v_0_cb_length_13)))
 (let (($x1445 (not v_1_cb_done_12)))
 (let (($x1443 (= v_1_cb_end_12 (ite (and $x513 $x1152 $x1258 (= 12 v_0_cb_tail)) ?x1364 v_0_cb_end_12))))
 (let (($x1329 (and $x513 $x1152 $x1258 (= 12 v_0_cb_tail))))
 (let ((?x1331 (ite $x1329 ?x1273 v_0_cb_length_12)))
 (let (($x1439 (not v_1_cb_done_11)))
 (let (($x1437 (= v_1_cb_end_11 (ite (and $x513 $x1152 $x1258 (= 11 v_0_cb_tail)) ?x1364 v_0_cb_end_11))))
 (let (($x1325 (and $x513 $x1152 $x1258 (= 11 v_0_cb_tail))))
 (let ((?x1327 (ite $x1325 ?x1273 v_0_cb_length_11)))
 (let (($x1433 (not v_1_cb_done_10)))
 (let (($x1431 (= v_1_cb_end_10 (ite (and $x513 $x1152 $x1258 (= 10 v_0_cb_tail)) ?x1364 v_0_cb_end_10))))
 (let (($x1321 (and $x513 $x1152 $x1258 (= 10 v_0_cb_tail))))
 (let ((?x1323 (ite $x1321 ?x1273 v_0_cb_length_10)))
 (let (($x1427 (not v_1_cb_done_09)))
 (let (($x1425 (= v_1_cb_end_09 (ite (and $x513 $x1152 $x1258 (= 9 v_0_cb_tail)) ?x1364 v_0_cb_end_09))))
 (let (($x1317 (and $x513 $x1152 $x1258 (= 9 v_0_cb_tail))))
 (let ((?x1319 (ite $x1317 ?x1273 v_0_cb_length_09)))
 (let (($x1421 (not v_1_cb_done_08)))
 (let (($x1419 (= v_1_cb_end_08 (ite (and $x513 $x1152 $x1258 (= 8 v_0_cb_tail)) ?x1364 v_0_cb_end_08))))
 (let (($x1313 (and $x513 $x1152 $x1258 (= 8 v_0_cb_tail))))
 (let ((?x1315 (ite $x1313 ?x1273 v_0_cb_length_08)))
 (let (($x1415 (not v_1_cb_done_07)))
 (let (($x1413 (= v_1_cb_end_07 (ite (and $x513 $x1152 $x1258 (= 7 v_0_cb_tail)) ?x1364 v_0_cb_end_07))))
 (let (($x1309 (and $x513 $x1152 $x1258 (= 7 v_0_cb_tail))))
 (let ((?x1311 (ite $x1309 ?x1273 v_0_cb_length_07)))
 (let (($x1409 (not v_1_cb_done_06)))
 (let (($x1407 (= v_1_cb_end_06 (ite (and $x513 $x1152 $x1258 (= 6 v_0_cb_tail)) ?x1364 v_0_cb_end_06))))
 (let (($x1305 (and $x513 $x1152 $x1258 (= 6 v_0_cb_tail))))
 (let ((?x1307 (ite $x1305 ?x1273 v_0_cb_length_06)))
 (let (($x1403 (not v_1_cb_done_05)))
 (let (($x1401 (= v_1_cb_end_05 (ite (and $x513 $x1152 $x1258 (= 5 v_0_cb_tail)) ?x1364 v_0_cb_end_05))))
 (let (($x1301 (and $x513 $x1152 $x1258 (= 5 v_0_cb_tail))))
 (let ((?x1303 (ite $x1301 ?x1273 v_0_cb_length_05)))
 (let (($x1397 (not v_1_cb_done_04)))
 (let (($x1395 (= v_1_cb_end_04 (ite (and $x513 $x1152 $x1258 (= 4 v_0_cb_tail)) ?x1364 v_0_cb_end_04))))
 (let (($x1297 (and $x513 $x1152 $x1258 (= 4 v_0_cb_tail))))
 (let ((?x1299 (ite $x1297 ?x1273 v_0_cb_length_04)))
 (let (($x1391 (not v_1_cb_done_03)))
 (let (($x1389 (= v_1_cb_end_03 (ite (and $x513 $x1152 $x1258 (= 3 v_0_cb_tail)) ?x1364 v_0_cb_end_03))))
 (let (($x1293 (and $x513 $x1152 $x1258 (= 3 v_0_cb_tail))))
 (let ((?x1295 (ite $x1293 ?x1273 v_0_cb_length_03)))
 (let (($x1385 (not v_1_cb_done_02)))
 (let (($x1383 (= v_1_cb_end_02 (ite (and $x513 $x1152 $x1258 (= 2 v_0_cb_tail)) ?x1364 v_0_cb_end_02))))
 (let (($x1289 (and $x513 $x1152 $x1258 (= 2 v_0_cb_tail))))
 (let ((?x1291 (ite $x1289 ?x1273 v_0_cb_length_02)))
 (let (($x1379 (not v_1_cb_done_01)))
 (let (($x1377 (= v_1_cb_end_01 (ite (and $x513 $x1152 $x1258 (= 1 v_0_cb_tail)) ?x1364 v_0_cb_end_01))))
 (let (($x1285 (and $x513 $x1152 $x1258 (= 1 v_0_cb_tail))))
 (let ((?x1287 (ite $x1285 ?x1273 v_0_cb_length_01)))
 (let (($x1373 (not v_1_cb_done_00)))
 (let (($x1371 (= v_1_cb_end_00 (ite (and $x513 $x1152 $x1258 (= 0 v_0_cb_tail)) ?x1364 v_0_cb_end_00))))
 (let (($x1281 (and $x513 $x1152 $x1258 (= 0 v_0_cb_tail))))
 (let ((?x1283 (ite $x1281 ?x1273 v_0_cb_length_00)))
 (let (($x1367 (not v_1_cb_is_new)))
 (let (($x1361 (= v_1_cb_before_nxt v_0_snd_nxt)))
 (let (($x1360 (= v_1_cb_drop_step 0)))
 (let (($x1358 (= v_1_cb_abandoned_total v_0_cb_abandoned_total)))
 (let (($x1355 (= v_1_cb_acked_total v_0_cb_acked_total)))
 (let ((?x648 (- 1)))
 (let ((?x986 (* ?x648 v_0_rtx_buf)))
 (let ((?x1347 (+ ?x1283 ?x1287 ?x1291 ?x1295 ?x1299 ?x1303 ?x1307 ?x1311 ?x1315 ?x1319 ?x1323 ?x1327 ?x1331 ?x1335 ?x1339 ?x1343 ?x986)))
 (let ((?x1344 (+ ?x1283 ?x1287 ?x1291 ?x1295 ?x1299 ?x1303 ?x1307 ?x1311 ?x1315 ?x1319 ?x1323 ?x1327 ?x1331 ?x1335 ?x1339 ?x1343)))
 (let (($x1278 (= v_1_cb_step_bytes 0)))
 (let (($x1276 (= v_1_cb_retired_count 0)))
 (let ((?x1260 (ite $x1259 1 0)))
 (let ((?x1261 (+ v_0_cb_tail ?x1260)))
 (let (($x1265 (= v_1_cb_tail (ite (<= 16 ?x1261) (+ (- 16) v_0_cb_tail ?x1260) ?x1261))))
 (let (($x1255 (= v_1_cb_head (ite (<= 16 v_0_cb_head) (+ (- 16) v_0_cb_head) v_0_cb_head))))
 (let (($x1248 (= v_1_svc_abandoned_bytes v_0_svc_abandoned_bytes)))
 (let (($x1245 (= v_1_svc_acked_bytes v_0_svc_acked_bytes)))
 (let (($x1242 (= v_1_svc_written_bytes v_0_svc_written_bytes)))
 (let (($x1239 (= v_1_svc_drop_step 0)))
 (let (($x1224 (= v_1_sched_at_ms v_0_sched_at_ms)))
 (let (($x1221 (not v_1_sched_open)))
 (let (($x1219 (= v_1_choice_before_flight v_0_choice_before_flight)))
 (let (($x1216 (= v_1_choice_before_nxt v_0_choice_before_nxt)))
 (let (($x1215 (= v_1_choice_limit v_0_choice_limit)))
 (let (($x1212 (= v_1_choice_count v_0_choice_count)))
 (let (($x1209 (not v_1_choice_used)))
 (let (($x1203 (= v_1_lt_before_window v_0_snd_wnd)))
 (let (($x1201 (= v_1_lt_before_flight v_0_rtx_buf)))
 (let (($x1199 (= v_1_lt_before_nxt v_0_snd_nxt)))
 (let (($x1198 (= v_1_lt_before_cwnd v_0_cc_cwnd)))
 (let (($x1196 (= v_1_lt_before_bytes v_0_lt_epoch_bytes)))
 (let (($x935 (<= 1 v_0_snd_wnd)))
 (let (($x936 (and $x459 $x935 $x513)))
 (let (($x1187 (or $x639 $x641 $x936)))
 (let (($x1183 (not v_1_lt_emitted)))
 (let (($x1181 (not v_1_lt_eligible)))
 (let (($x1179 (= v_1_idle_restart_count v_0_idle_restart_count)))
 (let (($x1176 (= v_1_idle_before_threshold v_0_cc_ssthresh)))
 (let (($x1174 (= v_1_idle_before_rto v_0_rto_ms)))
 (let (($x1172 (= v_1_idle_before_cwnd v_0_cc_cwnd)))
 (let ((?x1169 (ite v_0_idle_data_valid (+ now_1 (* ?x648 v_0_idle_last_data_ms)) 0)))
 (let (($x1165 (not v_1_idle_restart)))
 (let (($x1161 (= v_1_idle_event_ms now_1)))
 (let (($x1159 (= v_1_idle_last_data_ms (ite (and $x513 $x1152) now_1 v_0_idle_last_data_ms))))
 (let (($x1149 (= v_1_fr_entries v_0_fr_entries)))
 (let (($x1146 (= v_1_fr_emit_count 0)))
 (let (($x1144 (not v_1_fr_retransmitted)))
 (let (($x1142 (not v_1_fr_exited)))
 (let (($x1140 (not v_1_fr_extra)))
 (let (($x1138 (not v_1_fr_entered)))
 (let (($x1136 (not v_1_fr_duplicate)))
 (let (($x1134 (= v_1_fr_before_retries v_0_retries)))
 (let (($x1132 (= v_1_fr_before_rto v_0_rto_ms)))
 (let (($x1130 (= v_1_fr_before_flight v_0_rtx_buf)))
 (let (($x1128 (= v_1_fr_before_nxt v_0_snd_nxt)))
 (let (($x1127 (= v_1_fr_before_una v_0_snd_una)))
 (let (($x1126 (= v_1_fr_was_active v_0_fr_active)))
 (let (($x1124 (= v_1_fr_last_window v_0_fr_last_window)))
 (let (($x1122 (= v_1_fr_window_valid v_0_fr_window_valid)))
 (let (($x1110 (= v_1_fr_before_window_valid v_0_fr_window_valid)))
 (let (($x1107 (= v_1_fr_before_wire_window v_0_fr_last_window)))
 (let (($x1104 (not v_1_fr_window_ignored)))
 (let (($x803 (>= 15 v_0_rtx_buf)))
 (let (($x1097 (not $x803)))
 (let (($x1102 (= v_1_cc_rto_15 (and $x1097 (or v_0_cc_rto_15 (and $x459 $x935 $x513 (<= 16 ?x512)))))))
 (let (($x795 (>= 14 v_0_rtx_buf)))
 (let (($x1090 (not $x795)))
 (let (($x1095 (= v_1_cc_rto_14 (and $x1090 (or v_0_cc_rto_14 (and $x459 $x935 $x513 (<= 15 ?x512)))))))
 (let (($x787 (>= 13 v_0_rtx_buf)))
 (let (($x1083 (not $x787)))
 (let (($x1088 (= v_1_cc_rto_13 (and $x1083 (or v_0_cc_rto_13 (and $x459 $x935 $x513 (<= 14 ?x512)))))))
 (let (($x779 (>= 12 v_0_rtx_buf)))
 (let (($x1076 (not $x779)))
 (let (($x1081 (= v_1_cc_rto_12 (and $x1076 (or v_0_cc_rto_12 (and $x459 $x935 $x513 (<= 13 ?x512)))))))
 (let (($x771 (>= 11 v_0_rtx_buf)))
 (let (($x1069 (not $x771)))
 (let (($x1074 (= v_1_cc_rto_11 (and $x1069 (or v_0_cc_rto_11 (and $x459 $x935 $x513 (<= 12 ?x512)))))))
 (let (($x763 (>= 10 v_0_rtx_buf)))
 (let (($x1062 (not $x763)))
 (let (($x1067 (= v_1_cc_rto_10 (and $x1062 (or v_0_cc_rto_10 (and $x459 $x935 $x513 (<= 11 ?x512)))))))
 (let (($x755 (>= 9 v_0_rtx_buf)))
 (let (($x1055 (not $x755)))
 (let (($x1060 (= v_1_cc_rto_09 (and $x1055 (or v_0_cc_rto_09 (and $x459 $x935 $x513 (<= 10 ?x512)))))))
 (let (($x747 (>= 8 v_0_rtx_buf)))
 (let (($x1048 (not $x747)))
 (let (($x1053 (= v_1_cc_rto_08 (and $x1048 (or v_0_cc_rto_08 (and $x459 $x935 $x513 (<= 9 ?x512)))))))
 (let (($x739 (>= 7 v_0_rtx_buf)))
 (let (($x1041 (not $x739)))
 (let (($x1046 (= v_1_cc_rto_07 (and $x1041 (or v_0_cc_rto_07 (and $x459 $x935 $x513 (<= 8 ?x512)))))))
 (let (($x731 (>= 6 v_0_rtx_buf)))
 (let (($x1034 (not $x731)))
 (let (($x1039 (= v_1_cc_rto_06 (and $x1034 (or v_0_cc_rto_06 (and $x459 $x935 $x513 (<= 7 ?x512)))))))
 (let (($x723 (>= 5 v_0_rtx_buf)))
 (let (($x1027 (not $x723)))
 (let (($x1032 (= v_1_cc_rto_05 (and $x1027 (or v_0_cc_rto_05 (and $x459 $x935 $x513 (<= 6 ?x512)))))))
 (let (($x715 (>= 4 v_0_rtx_buf)))
 (let (($x1020 (not $x715)))
 (let (($x1025 (= v_1_cc_rto_04 (and $x1020 (or v_0_cc_rto_04 (and $x459 $x935 $x513 (<= 5 ?x512)))))))
 (let (($x709 (>= 3 v_0_rtx_buf)))
 (let (($x1013 (not $x709)))
 (let (($x1018 (= v_1_cc_rto_03 (and $x1013 (or v_0_cc_rto_03 (and $x459 $x935 $x513 (<= 4 ?x512)))))))
 (let (($x703 (>= 2 v_0_rtx_buf)))
 (let (($x1006 (not $x703)))
 (let (($x1011 (= v_1_cc_rto_02 (and $x1006 (or v_0_cc_rto_02 (and $x459 $x935 $x513 (<= 3 ?x512)))))))
 (let (($x999 (not $x637)))
 (let (($x1004 (= v_1_cc_rto_01 (and $x999 (or v_0_cc_rto_01 (and $x459 $x935 $x513 (<= 2 ?x512)))))))
 (let (($x997 (= v_1_cc_rto_00 (and (not (>= 0 v_0_rtx_buf)) (or v_0_cc_rto_00 $x936)))))
 (let ((?x987 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd) ?x986)))
 (let (($x982 (= v_1_cc_before_cwnd v_0_cc_cwnd)))
 (let ((?x977 (+ v_0_cc_threshold_updates (ite (and $x459 $x935 $x513 (not v_0_cc_rto_00)) 1 0))))
 (let (($x942 (not v_0_cc_rto_00)))
 (let (($x943 (and $x459 $x935 $x513 $x942)))
 (let (($x969 (= v_1_cc_before_window v_0_snd_wnd)))
 (let (($x967 (= v_1_cc_before_persist v_0_persist_active)))
 (let (($x965 (= v_1_cc_before_una v_0_snd_una)))
 (let (($x964 (= v_1_cc_before_flight v_0_rtx_buf)))
 (let ((?x951 (+ v_0_rtx_buf (to_int (* (- (/ 1.0 2.0)) (to_real v_0_rtx_buf))))))
 (let (($x956 (= v_1_cc_ssthresh (ite $x943 (ite (<= 8 ?x951) ?x951 8) v_0_cc_ssthresh))))
 (let (($x933 (= v_1_cc_initial_threshold v_0_cc_initial_threshold)))
 (let (($x930 (= v_1_cc_initial_window v_0_cc_initial_window)))
 (let (($x927 (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)))
 (let (($x920 (= v_1_persist_deadline_ms (ite $x641 (ite $x887 ?x916 v_0_persist_deadline_ms) 0))))
 (let (($x910 (= v_1_persist_since_ms (ite $x641 (ite $x887 now_1 v_0_persist_since_ms) 0))))
 (let (($x905 (= v_1_persist_previous_interval_ms v_0_persist_previous_interval_ms)))
 (let (($x896 (not v_1_persist_probe_new)))
 (let (($x894 (not v_1_persist_probe_sent)))
 (let (($x892 (not v_1_persist_first)))
 (let (($x890 (= v_1_persist_was_active v_0_persist_active)))
 (let (($x880 (not v_1_ack_defer_now)))
 (let (($x878 (not v_1_ack_defer_candidate)))
 (let (($x876 (= v_1_ack_rmss v_0_ack_rmss)))
 (let (($x873 (= v_1_ack_delay_ms v_0_ack_delay_ms)))
 (let (($x853 (not v_1_syn_timeout_eligible)))
 (let (($x851 (not v_1_tx_syn_pending)))
 (let (($x849 (= v_1_tx_syn_time 0)))
 (let (($x844 (not v_1_tx_is_fin)))
 (let (($x842 (= v_1_tx_previous_rto v_0_rto_ms)))
 (let ((?x823 (ite (and $x513 (<= 0 v_0_tx_time_00)) v_0_tx_time_00 0)))
 (let ((?x826 (ite (and (<= 2 ?x512) (>= v_0_tx_time_01 ?x823)) v_0_tx_time_01 ?x823)))
 (let ((?x829 (ite (and (<= 3 ?x512) (>= v_0_tx_time_02 ?x826)) v_0_tx_time_02 ?x826)))
 (let ((?x832 (ite (and (<= 4 ?x512) (>= v_0_tx_time_03 ?x829)) v_0_tx_time_03 ?x829)))
 (let ((?x814 (ite (and v_0_fin_sent (not v_0_fin_acknowledged)) v_0_tx_fin_time 0)))
 (let (($x815 (= v_1_tx_fin_time ?x814)))
 (let (($x809 (= v_1_tx_time_15 (ite $x803 0 (ite (<= 16 ?x512) now_1 v_0_tx_time_15)))))
 (let (($x801 (= v_1_tx_time_14 (ite $x795 0 (ite (<= 15 ?x512) now_1 v_0_tx_time_14)))))
 (let (($x793 (= v_1_tx_time_13 (ite $x787 0 (ite (<= 14 ?x512) now_1 v_0_tx_time_13)))))
 (let (($x785 (= v_1_tx_time_12 (ite $x779 0 (ite (<= 13 ?x512) now_1 v_0_tx_time_12)))))
 (let (($x777 (= v_1_tx_time_11 (ite $x771 0 (ite (<= 12 ?x512) now_1 v_0_tx_time_11)))))
 (let (($x769 (= v_1_tx_time_10 (ite $x763 0 (ite (<= 11 ?x512) now_1 v_0_tx_time_10)))))
 (let (($x761 (= v_1_tx_time_09 (ite $x755 0 (ite (<= 10 ?x512) now_1 v_0_tx_time_09)))))
 (let (($x753 (= v_1_tx_time_08 (ite $x747 0 (ite (<= 9 ?x512) now_1 v_0_tx_time_08)))))
 (let (($x745 (= v_1_tx_time_07 (ite $x739 0 (ite (<= 8 ?x512) now_1 v_0_tx_time_07)))))
 (let (($x737 (= v_1_tx_time_06 (ite $x731 0 (ite (<= 7 ?x512) now_1 v_0_tx_time_06)))))
 (let (($x729 (= v_1_tx_time_05 (ite $x723 0 (ite (<= 6 ?x512) now_1 v_0_tx_time_05)))))
 (let (($x721 (= v_1_tx_time_04 (ite $x715 0 (ite (<= 5 ?x512) now_1 v_0_tx_time_04)))))
 (let (($x713 (= v_1_tx_time_03 (ite $x709 0 (ite (<= 4 ?x512) now_1 v_0_tx_time_03)))))
 (let (($x707 (= v_1_tx_time_02 (ite $x703 0 (ite (<= 3 ?x512) now_1 v_0_tx_time_02)))))
 (let (($x701 (= v_1_tx_time_01 (ite $x637 0 (ite (<= 2 ?x512) now_1 v_0_tx_time_01)))))
 (let (($x696 (= v_1_tx_time_00 (ite (>= 0 v_0_rtx_buf) 0 (ite $x513 now_1 v_0_tx_time_00)))))
 (let (($x691 (= v_1_rto_base_ms v_0_rto_base_ms)))
 (let (($x688 (= v_1_rtt_samples v_0_rtt_samples)))
 (let (($x685 (= v_1_rtt_last_ms v_0_rtt_last_ms)))
 (let (($x682 (not v_1_rtt_sample_was_ambiguous)))
 (let (($x680 (not v_1_rtt_sample_used)))
 (let (($x678 (not v_1_rtt_start_new)))
 (let (($x673 (= v_1_rtt_end v_0_rtt_end)))
 (let (($x672 (= v_1_rtt_start_ms v_0_rtt_start_ms)))
 (let (($x669 (= v_1_rtt_sample_at_ms v_0_rtt_sample_at_ms)))
 (let ((?x651 (mod (+ v_0_rtt_end (* ?x648 v_0_snd_una)) 4294967296)))
 (let (($x663 (and v_0_rtt_active (<= (+ ?x651 (* ?x648 v_0_rtt_remaining)) (+ ?x648 ?x660)))))
 (let (($x632 (= v_1_rtt_previous_measured v_0_rtt_previous_measured)))
 (let (($x629 (= v_1_rtt_measured v_0_rtt_measured)))
 (let (($x626 (= v_1_rtt_previous_var v_0_rtt_previous_var)))
 (let (($x623 (= v_1_rtt_previous_srtt v_0_rtt_previous_srtt)))
 (let (($x620 (= v_1_rtt_error_ms v_0_rtt_error_ms)))
 (let (($x617 (= v_1_rttvar_ms v_0_rttvar_ms)))
 (let (($x614 (= v_1_srtt_ms v_0_srtt_ms)))
 (let (($x611 (= v_1_rx_fin_consumed v_0_rx_fin_consumed)))
 (let (($x608 (= v_1_rx_fin_done v_0_rx_fin_done)))
 (let (($x605 (= v_1_rx_fin_offset v_0_rx_fin_offset)))
 (let (($x602 (= v_1_rx_fin_seq v_0_rx_fin_seq)))
 (let (($x601 (= v_1_rx_fin_pending v_0_rx_fin_pending)))
 (let (($x598 (= v_1_fin_acknowledged v_0_fin_acknowledged)))
 (let (($x595 (= v_1_fin_seq v_0_fin_seq)))
 (let (($x594 (= v_1_fin_sent v_0_fin_sent)))
 (let (($x591 (= v_1_fin_requested v_0_fin_requested)))
 (let (($x588 (= v_1_ack_window_update v_0_ack_window_update)))
 (let (($x585 (= v_1_ack_advance v_0_ack_advance)))
 (let (($x582 (= v_1_ack_is_future v_0_ack_is_future)))
 (let (($x579 (= v_1_ack_is_new v_0_ack_is_new)))
 (let (($x576 (= v_1_ack_delta v_0_ack_delta)))
 (let (($x573 (= v_1_seg_acceptable v_0_seg_acceptable)))
 (let (($x570 (= v_1_rx_acceptable v_0_rx_acceptable)))
 (let (($x567 (= v_1_rx_advance v_0_rx_advance)))
 (let (($x564 (= v_1_rx_slot_15 v_0_rx_slot_15)))
 (let (($x563 (= v_1_rx_slot_14 v_0_rx_slot_14)))
 (let (($x562 (= v_1_rx_slot_13 v_0_rx_slot_13)))
 (let (($x561 (= v_1_rx_slot_12 v_0_rx_slot_12)))
 (let (($x560 (= v_1_rx_slot_11 v_0_rx_slot_11)))
 (let (($x559 (= v_1_rx_slot_10 v_0_rx_slot_10)))
 (let (($x558 (= v_1_rx_slot_09 v_0_rx_slot_09)))
 (let (($x557 (= v_1_rx_slot_08 v_0_rx_slot_08)))
 (let (($x556 (= v_1_rx_slot_07 v_0_rx_slot_07)))
 (let (($x555 (= v_1_rx_slot_06 v_0_rx_slot_06)))
 (let (($x554 (= v_1_rx_slot_05 v_0_rx_slot_05)))
 (let (($x553 (= v_1_rx_slot_04 v_0_rx_slot_04)))
 (let (($x552 (= v_1_rx_slot_03 v_0_rx_slot_03)))
 (let (($x551 (= v_1_rx_slot_02 v_0_rx_slot_02)))
 (let (($x550 (= v_1_rx_slot_01 v_0_rx_slot_01)))
 (let (($x549 (= v_1_rx_slot_00 v_0_rx_slot_00)))
 (let (($x548 (= v_1_rx_chunk v_0_rx_chunk)))
 (let (($x547 (= v_1_take v_0_take)))
 (let (($x544 (= v_1_snd_wl2 v_0_snd_wl2)))
 (let (($x543 (= v_1_snd_wl1 v_0_snd_wl1)))
 (let (($x542 (= v_1_snd_wnd v_0_snd_wnd)))
 (let (($x540 (= v_1_rcv_buf v_0_rcv_buf)))
 (let (($x539 (= v_1_rtx_buf v_0_rtx_buf)))
 (let (($x538 (= v_1_snd_buf v_0_snd_buf)))
 (let (($x537 (= v_1_local_window v_0_local_window)))
 (let (($x534 (= v_1_msl_ms v_0_msl_ms)))
 (let (($x531 (= v_1_user_timeout_ms v_0_user_timeout_ms)))
 (let (($x528 (= v_1_active_open v_0_active_open)))
 (let (($x482 (= v_1_tx_flags v_0_tx_flags)))
 (let (($x479 (= v_1_tx_ack v_0_tx_ack)))
 (let (($x478 (= v_1_tx_seq v_0_tx_seq)))
 (let (($x477 (= v_1_rcv_nxt v_0_rcv_nxt)))
 (let (($x476 (= v_1_snd_nxt v_0_snd_nxt)))
 (let (($x475 (= v_1_snd_una v_0_snd_una)))
 (let (($x474 (= v_1_irs v_0_irs)))
 (let (($x473 (= v_1_iss v_0_iss)))
 (let (($x462 (= now_1 due_0_rtx)))
 (and (>= now_1 now_0) $x459 $x461 active_0_rtx $x462 (or (not active_0_user) (<= due_0_rtx due_0_user)) (or (not active_0_time_wait) (<= due_0_rtx due_0_time_wait)) (or (not active_0_delack) (not (<= due_0_delack due_0_rtx))) (or (not active_0_persist) (not (<= due_0_persist due_0_rtx))) $x473 $x474 $x475 $x476 $x477 $x478 $x479 $x482 (= v_1_rto_ms ?x519) (= v_1_retries (ite $x513 (+ 1 v_0_retries) v_0_retries)) $x528 $x531 $x534 $x537 $x538 $x539 $x540 $x542 $x543 $x544 $x547 $x548 $x549 $x550 $x551 $x552 $x553 $x554 $x555 $x556 $x557 $x558 $x559 $x560 $x561 $x562 $x563 $x564 $x567 $x570 $x573 $x576 $x579 $x582 $x585 $x588 $x591 $x594 $x595 $x598 $x601 $x602 $x605 $x608 $x611 $x614 $x617 $x620 $x623 $x626 $x629 $x632 (= v_1_rtt_active (and $x642 v_0_rtt_active)) (= v_1_rtt_ambiguous (and $x642 (or v_0_rtt_ambiguous $x663))) $x669 $x672 $x673 (= v_1_rtt_remaining (ite $x641 0 v_0_rtt_remaining)) $x678 $x680 $x682 $x685 $x688 $x691 $x696 $x701 $x707 $x713 $x721 $x729 $x737 $x745 $x753 $x761 $x769 $x777 $x785 $x793 $x801 $x809 $x815 (= v_1_tx_emit_count ?x512) (= v_1_tx_eligible ?x510) (= v_1_tx_max_previous ?x832) (= v_1_tx_retransmitted $x513) (= v_1_tx_elapsed (ite $x513 (+ now_1 (* ?x648 ?x832)) 0)) $x842 $x844 (not (= $x513 v_1_tx_waiting)) $x849 $x851 $x853 (= v_1_ack_pending (and (not $x513) v_0_ack_pending)) (= v_1_ack_since_ms (ite $x513 0 v_0_ack_since_ms)) (= v_1_ack_bytes (ite $x513 0 v_0_ack_bytes)) (= v_1_ack_full_segments (ite $x513 0 v_0_ack_full_segments)) $x873 $x876 $x878 $x880 (= v_1_persist_active $x641) (= v_1_persist_eligible $x641) (= v_1_persist_start $x887) $x890 $x892 $x894 $x896 (= v_1_persist_interval_ms (ite $x641 ?x899 1000)) $x905 $x910 (= v_1_persist_last_ms (ite $x641 v_0_persist_last_ms 0)) $x920 (= v_1_persist_probes (ite $x641 v_0_persist_probes 0)) $x927 $x930 $x933 (= v_1_cc_cwnd (ite $x936 4 v_0_cc_cwnd)) $x956 (= v_1_cc_ca_credit (ite $x936 0 v_0_cc_ca_credit)) (= 0 v_1_cc_acked) $x964 $x965 $x967 $x969 (= v_1_cc_loss $x936) (= v_1_cc_threshold_changed $x943) (= v_1_cc_threshold_updates ?x977) (= 0 v_1_cc_growth) $x982 (= v_1_cc_send_budget (ite (<= 0 ?x987) ?x987 0)) (= 0 v_1_cc_new_sent) $x997 $x1004 $x1011 $x1018 $x1025 $x1032 $x1039 $x1046 $x1053 $x1060 $x1067 $x1074 $x1081 $x1088 $x1095 $x1102 $x1104 $x1107 $x1110 (= v_1_fr_active (and (not (or $x639 $x936 $x641)) v_0_fr_active)) (= v_1_fr_dupacks (ite (or $x639 $x936 $x641) 0 v_0_fr_dupacks)) $x1122 $x1124 $x1126 $x1127 $x1128 $x1130 $x1132 $x1134 $x1136 $x1138 $x1140 $x1142 $x1144 $x1146 $x1149 (= v_1_idle_data_valid (or v_0_idle_data_valid (and $x513 $x1152))) $x1159 $x1161 (= v_1_idle_data_emitted (and $x513 $x1152)) $x1165 (= v_1_idle_elapsed_ms ?x1169) $x1172 $x1174 $x1176 $x1179 $x1181 $x1183 (= 0 v_1_lt_take) (= v_1_lt_epoch_bytes (ite $x1187 0 v_0_lt_epoch_bytes)) (= v_1_lt_epoch_packets (ite $x1187 0 v_0_lt_epoch_packets)) $x1196 $x1198 $x1199 $x1201 $x1203 (= v_1_lt_loss_flight (+ v_0_rtx_buf (* ?x648 v_0_lt_epoch_bytes))) $x1209 $x1212 $x1215 $x1216 $x1219 $x1221 $x1224 (= 0 v_1_sched_cause) (= 0 v_1_sched_bytes) (= 0 v_1_sched_packets) (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf)) (= 0 v_1_svc_accept_step) (= 0 v_1_svc_ack_step) $x1239 $x1242 $x1245 $x1248 $x1255 $x1265 (= v_1_cb_count (+ v_0_cb_count ?x1260)) (= v_1_cb_new_count ?x1260) (= v_1_cb_append_length ?x1273) $x1276 $x1278 (= v_1_cb_live_total ?x1344) (= v_1_cb_partial_prefix ?x1347) (= v_1_cb_emitted_total (+ v_0_cb_emitted_total ?x1273)) $x1355 $x1358 $x1360 $x1361 (= v_1_cb_append_end ?x1364) $x1367 (= v_1_cb_length_00 ?x1283) $x1371 $x1373 (= v_1_cb_length_01 ?x1287) $x1377 $x1379 (= v_1_cb_length_02 ?x1291) $x1383 $x1385 (= v_1_cb_length_03 ?x1295) $x1389 $x1391 (= v_1_cb_length_04 ?x1299) $x1395 $x1397 (= v_1_cb_length_05 ?x1303) $x1401 $x1403 (= v_1_cb_length_06 ?x1307) $x1407 $x1409 (= v_1_cb_length_07 ?x1311) $x1413 $x1415 (= v_1_cb_length_08 ?x1315) $x1419 $x1421 (= v_1_cb_length_09 ?x1319) $x1425 $x1427 (= v_1_cb_length_10 ?x1323) $x1431 $x1433 (= v_1_cb_length_11 ?x1327) $x1437 $x1439 (= v_1_cb_length_12 ?x1331) $x1443 $x1445 (= v_1_cb_length_13 ?x1335) $x1449 $x1451 (= v_1_cb_length_14 ?x1339) $x1455 $x1457 (= v_1_cb_length_15 ?x1343) (= v_1_cb_end_15 (ite $x1341 ?x1364 v_0_cb_end_15)) $x1463 (= active_1_rtx (or $x642 $x1465)) $x1469 $x1471 (= active_1_delack (and (not $x513) active_0_delack)) $x1478 (= due_1_rtx (ite $x1465 (+ now_1 ?x519) (+ now_1 ?x1483))) $x1488 $x1490 $x1492 (= due_1_persist (ite $x887 ?x916 due_0_persist))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_user))
(assert
 (not active_0_time_wait))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (<= 1000 v_0_rto_ms))
(assert
 (<= 0 v_0_retries))
(assert
 (<= 1 v_0_msl_ms))
(assert
 (<= 1 v_0_user_timeout_ms))
(assert
 true)
(assert
 (let ((?x1232 (+ v_0_snd_buf v_0_rtx_buf)))
 (>= 16 ?x1232)))
(assert
 (>= 16 v_0_rcv_buf))
(assert
 (and (<= 0 v_0_snd_wnd) (>= 65535 v_0_snd_wnd)))
(assert
 (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf))))
(assert
 (>= 1 v_0_rx_slot_00))
(assert
 (let (($x1513 (= 0 v_0_rx_slot_00)))
 (let (($x1512 (not (>= v_0_rcv_buf 16))))
 (or $x1512 $x1513))))
(assert
 (>= 1 v_0_rx_slot_01))
(assert
 (let (($x1518 (= 0 v_0_rx_slot_01)))
 (let (($x1517 (not (>= v_0_rcv_buf 15))))
 (or $x1517 $x1518))))
(assert
 (>= 1 v_0_rx_slot_02))
(assert
 (let (($x1523 (= 0 v_0_rx_slot_02)))
 (let (($x1522 (not (>= v_0_rcv_buf 14))))
 (or $x1522 $x1523))))
(assert
 (>= 1 v_0_rx_slot_03))
(assert
 (let (($x1528 (= 0 v_0_rx_slot_03)))
 (let (($x1527 (not (>= v_0_rcv_buf 13))))
 (or $x1527 $x1528))))
(assert
 (>= 1 v_0_rx_slot_04))
(assert
 (let (($x1533 (= 0 v_0_rx_slot_04)))
 (let (($x1532 (not (>= v_0_rcv_buf 12))))
 (or $x1532 $x1533))))
(assert
 (>= 1 v_0_rx_slot_05))
(assert
 (let (($x1538 (= 0 v_0_rx_slot_05)))
 (let (($x1537 (not (>= v_0_rcv_buf 11))))
 (or $x1537 $x1538))))
(assert
 (>= 1 v_0_rx_slot_06))
(assert
 (let (($x1543 (= 0 v_0_rx_slot_06)))
 (let (($x1542 (not (>= v_0_rcv_buf 10))))
 (or $x1542 $x1543))))
(assert
 (>= 1 v_0_rx_slot_07))
(assert
 (let (($x1548 (= 0 v_0_rx_slot_07)))
 (let (($x1547 (not (>= v_0_rcv_buf 9))))
 (or $x1547 $x1548))))
(assert
 (>= 1 v_0_rx_slot_08))
(assert
 (let (($x1553 (= 0 v_0_rx_slot_08)))
 (let (($x1552 (not (>= v_0_rcv_buf 8))))
 (or $x1552 $x1553))))
(assert
 (>= 1 v_0_rx_slot_09))
(assert
 (let (($x1558 (= 0 v_0_rx_slot_09)))
 (let (($x1557 (not (>= v_0_rcv_buf 7))))
 (or $x1557 $x1558))))
(assert
 (>= 1 v_0_rx_slot_10))
(assert
 (let (($x1563 (= 0 v_0_rx_slot_10)))
 (let (($x1562 (not (>= v_0_rcv_buf 6))))
 (or $x1562 $x1563))))
(assert
 (>= 1 v_0_rx_slot_11))
(assert
 (let (($x1568 (= 0 v_0_rx_slot_11)))
 (let (($x1567 (not (>= v_0_rcv_buf 5))))
 (or $x1567 $x1568))))
(assert
 (>= 1 v_0_rx_slot_12))
(assert
 (let (($x1573 (= 0 v_0_rx_slot_12)))
 (let (($x1572 (not (>= v_0_rcv_buf 4))))
 (or $x1572 $x1573))))
(assert
 (>= 1 v_0_rx_slot_13))
(assert
 (let (($x1578 (= 0 v_0_rx_slot_13)))
 (let (($x1577 (not (>= v_0_rcv_buf 3))))
 (or $x1577 $x1578))))
(assert
 (>= 1 v_0_rx_slot_14))
(assert
 (let (($x1583 (= 0 v_0_rx_slot_14)))
 (let (($x1582 (not (>= v_0_rcv_buf 2))))
 (or $x1582 $x1583))))
(assert
 (>= 1 v_0_rx_slot_15))
(assert
 (let (($x1588 (= 0 v_0_rx_slot_15)))
 (let (($x1587 (not (>= v_0_rcv_buf 1))))
 (or $x1587 $x1588))))
(assert
 (= 0 v_0_rx_slot_00))
(assert
 (let ((?x1590 (+ v_0_rcv_buf v_0_rx_slot_00 v_0_rx_slot_01 v_0_rx_slot_02 v_0_rx_slot_03 v_0_rx_slot_04 v_0_rx_slot_05 v_0_rx_slot_06 v_0_rx_slot_07 v_0_rx_slot_08 v_0_rx_slot_09 v_0_rx_slot_10 v_0_rx_slot_11 v_0_rx_slot_12 v_0_rx_slot_13 v_0_rx_slot_14 v_0_rx_slot_15)))
 (>= 16 ?x1590)))
(assert
 (and (<= 0 v_0_rx_advance) (>= 16 v_0_rx_advance)))
(assert
 (= v_0_rx_chunk v_0_rx_advance))
(assert
 (and (<= 0 v_0_ack_delta) (>= 4294967295 v_0_ack_delta)))
(assert
 true)
(assert
 (let ((?x1602 (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)) 4294967296)))
 (= v_0_snd_nxt ?x1602)))
(assert
 (not v_0_fin_sent))
(assert
 (not v_0_fin_requested))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not v_0_rx_fin_done))
(assert
 (let (($x1607 (<= 1 v_0_rx_fin_offset)))
 (let (($x1605 (not v_0_rx_fin_done)))
 (let (($x1610 (and $x1605 $x1607 (<= v_0_rx_fin_offset (+ (- 1) v_0_local_window)))))
 (let (($x1606 (not v_0_rx_fin_pending)))
 (or $x1606 $x1610))))))
(assert
 (let (($x1613 (>= 15 v_0_rx_fin_offset)))
 (and (<= 0 v_0_rx_fin_offset) $x1613 (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset)))))
(assert
 (let (($x1606 (not v_0_rx_fin_pending)))
 (or $x1606 (= v_0_rx_fin_seq (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)))))
(assert
 (let (($x1605 (not v_0_rx_fin_done)))
 (or $x1605 (= v_0_rcv_nxt (mod (+ 1 v_0_rx_fin_seq) 4294967296)))))
(assert
 (let (($x1513 (= 0 v_0_rx_slot_00)))
 (or (not (and v_0_rx_fin_pending (>= 0 v_0_rx_fin_offset))) $x1513)))
(assert
 (let (($x1518 (= 0 v_0_rx_slot_01)))
 (or (not (and v_0_rx_fin_pending (>= 1 v_0_rx_fin_offset))) $x1518)))
(assert
 (let (($x1523 (= 0 v_0_rx_slot_02)))
 (or (not (and v_0_rx_fin_pending (>= 2 v_0_rx_fin_offset))) $x1523)))
(assert
 (let (($x1528 (= 0 v_0_rx_slot_03)))
 (or (not (and v_0_rx_fin_pending (>= 3 v_0_rx_fin_offset))) $x1528)))
(assert
 (let (($x1533 (= 0 v_0_rx_slot_04)))
 (or (not (and v_0_rx_fin_pending (>= 4 v_0_rx_fin_offset))) $x1533)))
(assert
 (let (($x1538 (= 0 v_0_rx_slot_05)))
 (or (not (and v_0_rx_fin_pending (>= 5 v_0_rx_fin_offset))) $x1538)))
(assert
 (let (($x1543 (= 0 v_0_rx_slot_06)))
 (or (not (and v_0_rx_fin_pending (>= 6 v_0_rx_fin_offset))) $x1543)))
(assert
 (let (($x1548 (= 0 v_0_rx_slot_07)))
 (or (not (and v_0_rx_fin_pending (>= 7 v_0_rx_fin_offset))) $x1548)))
(assert
 (let (($x1553 (= 0 v_0_rx_slot_08)))
 (or (not (and v_0_rx_fin_pending (>= 8 v_0_rx_fin_offset))) $x1553)))
(assert
 (let (($x1558 (= 0 v_0_rx_slot_09)))
 (or (not (and v_0_rx_fin_pending (>= 9 v_0_rx_fin_offset))) $x1558)))
(assert
 (let (($x1563 (= 0 v_0_rx_slot_10)))
 (or (not (and v_0_rx_fin_pending (>= 10 v_0_rx_fin_offset))) $x1563)))
(assert
 (let (($x1568 (= 0 v_0_rx_slot_11)))
 (or (not (and v_0_rx_fin_pending (>= 11 v_0_rx_fin_offset))) $x1568)))
(assert
 (let (($x1573 (= 0 v_0_rx_slot_12)))
 (or (not (and v_0_rx_fin_pending (>= 12 v_0_rx_fin_offset))) $x1573)))
(assert
 (let (($x1578 (= 0 v_0_rx_slot_13)))
 (or (not (and v_0_rx_fin_pending (>= 13 v_0_rx_fin_offset))) $x1578)))
(assert
 (let (($x1583 (= 0 v_0_rx_slot_14)))
 (or (not (and v_0_rx_fin_pending (>= 14 v_0_rx_fin_offset))) $x1583)))
(assert
 (let (($x1588 (= 0 v_0_rx_slot_15)))
 (or (not (and v_0_rx_fin_pending (>= 15 v_0_rx_fin_offset))) $x1588)))
(assert
 (<= 0.0 v_0_srtt_ms))
(assert
 (<= 0.0 v_0_rttvar_ms))
(assert
 (<= 0.0 v_0_rtt_error_ms))
(assert
 (<= 0.0 v_0_rtt_previous_srtt))
(assert
 (<= 0.0 v_0_rtt_previous_var))
(assert
 (<= 0 v_0_rtt_start_ms))
(assert
 (<= 0 v_0_rtt_last_ms))
(assert
 (<= 0 v_0_rtt_samples))
(assert
 (and (<= 1000 v_0_rto_base_ms) (>= 60000 v_0_rto_base_ms) (>= v_0_rto_ms v_0_rto_base_ms) (>= 60000 v_0_rto_ms)))
(assert
 (let ((?x1706 (* 4.0 v_0_rttvar_ms)))
 (let ((?x1701 (- 1.0)))
 (let ((?x1709 (+ (* ?x1701 v_0_srtt_ms) (* ?x1701 (ite (<= v_0_rttvar_ms (/ 1.0 4.0)) 1.0 ?x1706)))))
 (let ((?x1710 (to_int ?x1709)))
 (let ((?x648 (- 1)))
 (let ((?x1714 (ite (<= ?x1710 (- 1000)) (* ?x648 ?x1710) 1000)))
 (= v_0_rto_base_ms (ite v_0_rtt_measured (ite (<= 60000 ?x1714) 60000 ?x1714) 1000)))))))))
(assert
 (= v_0_rtt_measured (<= 1 v_0_rtt_samples)))
(assert
 (let ((?x651 (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296)))
 (let (($x1729 (and (<= v_0_rtt_start_ms now_0) (<= 1 v_0_rtt_remaining) (>= 4 v_0_rtt_remaining) (>= ?x651 v_0_rtt_remaining) (<= ?x651 (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296)))))
 (let (($x1721 (not v_0_rtt_active)))
 (or $x1721 $x1729)))))
(assert
 (let (($x1731 (= 0 v_0_rtt_remaining)))
 (or v_0_rtt_active $x1731)))
(assert
 true)
(assert
 (let (($x1739 (= v_0_rtt_last_ms (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms)))))
 (let (($x1736 (not v_0_rtt_sample_was_ambiguous)))
 (let (($x1734 (not v_0_rtt_sample_used)))
 (or $x1734 (and $x1736 v_0_rtt_measured $x1739))))))
(assert
 (and (<= 0 v_0_rtt_sample_at_ms) (<= v_0_rtt_sample_at_ms now_0)))
(assert
 (let ((?x1748 (to_real v_0_rtt_last_ms)))
 (let ((?x1766 (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt) (* (/ 1.0 8.0) ?x1748))))
 (let ((?x1750 (+ v_0_rtt_previous_srtt (* (- 1.0) ?x1748))))
 (let ((?x1754 (ite (>= ?x1750 0.0) ?x1750 (+ (* (- 1.0) v_0_rtt_previous_srtt) ?x1748))))
 (let ((?x1704 (/ 1.0 4.0)))
 (let ((?x1758 (ite v_0_rtt_previous_measured (+ (* (/ 3.0 4.0) v_0_rtt_previous_var) (* ?x1704 ?x1754)) (* (/ 1.0 2.0) ?x1748))))
 (let (($x1769 (and (= v_0_rttvar_ms ?x1758) (= v_0_srtt_ms (ite v_0_rtt_previous_measured ?x1766 ?x1748)))))
 (let (($x1734 (not v_0_rtt_sample_used)))
 (or $x1734 $x1769))))))))))
(assert
 (let (($x821 (<= 0 v_0_tx_time_00)))
 (and $x821 (<= v_0_tx_time_00 now_0) (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00)))))
(assert
 (and (<= 0 v_0_tx_time_01) (<= v_0_tx_time_01 now_0) (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))))
(assert
 (and (<= 0 v_0_tx_time_02) (<= v_0_tx_time_02 now_0) (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))))
(assert
 (and (<= 0 v_0_tx_time_03) (<= v_0_tx_time_03 now_0) (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))))
(assert
 (and (<= 0 v_0_tx_time_04) (<= v_0_tx_time_04 now_0) (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))))
(assert
 (and (<= 0 v_0_tx_time_05) (<= v_0_tx_time_05 now_0) (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))))
(assert
 (and (<= 0 v_0_tx_time_06) (<= v_0_tx_time_06 now_0) (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))))
(assert
 (and (<= 0 v_0_tx_time_07) (<= v_0_tx_time_07 now_0) (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))))
(assert
 (and (<= 0 v_0_tx_time_08) (<= v_0_tx_time_08 now_0) (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))))
(assert
 (and (<= 0 v_0_tx_time_09) (<= v_0_tx_time_09 now_0) (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))))
(assert
 (and (<= 0 v_0_tx_time_10) (<= v_0_tx_time_10 now_0) (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))))
(assert
 (and (<= 0 v_0_tx_time_11) (<= v_0_tx_time_11 now_0) (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))))
(assert
 (and (<= 0 v_0_tx_time_12) (<= v_0_tx_time_12 now_0) (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))))
(assert
 (and (<= 0 v_0_tx_time_13) (<= v_0_tx_time_13 now_0) (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))))
(assert
 (and (<= 0 v_0_tx_time_14) (<= v_0_tx_time_14 now_0) (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))))
(assert
 (and (<= 0 v_0_tx_time_15) (<= v_0_tx_time_15 now_0) (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))))
(assert
 (and (<= 0 v_0_tx_fin_time) (<= v_0_tx_fin_time now_0)))
(assert
 (and (<= 0 v_0_tx_emit_count) (>= 4 v_0_tx_emit_count)))
(assert
 (and (<= 0 v_0_tx_eligible) (>= 4 v_0_tx_eligible)))
(assert
 (and (<= 0 v_0_tx_elapsed) (<= 0 v_0_tx_max_previous) (<= v_0_tx_max_previous now_0) (<= 1000 v_0_tx_previous_rto) (>= 60000 v_0_tx_previous_rto)))
(assert
 (let (($x1878 (and (>= v_0_tx_elapsed v_0_tx_previous_rto) (<= 1 v_0_tx_emit_count) (or (not v_0_tx_is_fin) (= 1 v_0_tx_emit_count)))))
 (let (($x1871 (not v_0_tx_retransmitted)))
 (or $x1871 $x1878))))
(assert
 (let (($x1871 (not v_0_tx_retransmitted)))
 (or $x1871 (not v_0_tx_waiting))))
(assert
 (and (<= 0 v_0_tx_syn_time) (<= v_0_tx_syn_time now_0)))
(assert
 (not v_0_tx_syn_pending))
(assert
 (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time)))
(assert
 true)
(assert
 (and (<= 1 v_0_ack_delay_ms) (>= 499 v_0_ack_delay_ms) (= 4 v_0_ack_rmss)))
(assert
 (= v_0_ack_pending active_0_delack))
(assert
 (and (<= 0 v_0_ack_bytes) (>= 7 v_0_ack_bytes) (<= 0 v_0_ack_full_segments) (>= 1 v_0_ack_full_segments)))
(assert
 (and (<= 0 v_0_ack_since_ms) (<= v_0_ack_since_ms now_0)))
(assert
 (let (($x1905 (not v_0_ack_pending)))
 (or $x1905 (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))))
(assert
 (let (($x1912 (and (= 0 v_0_ack_bytes) (= 0 v_0_ack_full_segments) (= 0 v_0_ack_since_ms))))
 (or v_0_ack_pending $x1912)))
(assert
 (let (($x370 (not active_0_rtx)))
 (let (($x637 (>= 1 v_0_rtx_buf)))
 (let (($x636 (<= 1 (+ v_0_rtx_buf v_0_snd_buf))))
 (let (($x634 (not v_0_fin_sent)))
 (let (($x461 (= 0 v_0_snd_wnd)))
 (let (($x886 (not v_0_persist_active)))
 (let (($x1917 (and (<= 1 (+ v_0_rtx_buf (ite v_0_fin_sent 1 0))) $x886)))
 (let (($x1914 (= v_0_persist_active active_0_persist)))
 (and $x1914 (= active_0_rtx $x1917) (or $x886 (and $x461 $x634 $x636 $x637 $x370))))))))))))
(assert
 (let (($x886 (not v_0_persist_active)))
 (or $x886 (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))))
(assert
 (and (<= 1000 v_0_persist_interval_ms) (>= 60000 v_0_persist_interval_ms) (<= 1000 v_0_persist_previous_interval_ms) (>= 60000 v_0_persist_previous_interval_ms) (<= 0 v_0_persist_probes) (<= 0 v_0_persist_elapsed_ms)))
(assert
 (and (<= 0 v_0_persist_since_ms) (<= v_0_persist_since_ms now_0) (<= 0 v_0_persist_last_ms) (<= v_0_persist_last_ms now_0) (<= 0 v_0_persist_deadline_ms)))
(assert
 (let (($x1937 (= 0 v_0_persist_probes)))
 (let ((?x1939 (+ (ite $x1937 v_0_persist_since_ms v_0_persist_last_ms) v_0_persist_interval_ms)))
 (let (($x886 (not v_0_persist_active)))
 (or $x886 (= v_0_persist_deadline_ms ?x1939))))))
(assert
 (let (($x1945 (= 1 v_0_rtx_buf)))
 (let (($x1943 (not v_0_persist_probe_sent)))
 (or $x1943 (and (>= v_0_persist_elapsed_ms v_0_persist_previous_interval_ms) $x1945)))))
(assert
 (let (($x1951 (= v_0_tx_time_00 v_0_persist_last_ms)))
 (let (($x1945 (= 1 v_0_rtx_buf)))
 (or (not (and v_0_persist_active (<= 1 v_0_persist_probes) $x1945)) $x1951))))
(assert
 (let (($x1937 (= 0 v_0_persist_probes)))
 (let (($x1956 (and (= 0 v_0_persist_since_ms) (= 0 v_0_persist_last_ms) (= 0 v_0_persist_deadline_ms) $x1937)))
 (or v_0_persist_active $x1956))))
(assert
 (and (<= 4 v_0_cc_initial_window) (>= 16 v_0_cc_initial_window) (<= 8 v_0_cc_initial_threshold)))
(assert
 (and (<= 4 v_0_cc_cwnd) (<= 8 v_0_cc_ssthresh) (<= 0 v_0_cc_ca_credit) (not (>= v_0_cc_ca_credit v_0_cc_cwnd)) (<= 0 v_0_cc_growth) (>= 4 v_0_cc_growth) (<= 0 v_0_cc_acked) (>= 16 v_0_cc_acked) (<= 0 v_0_cc_threshold_updates)))
(assert
 (and (<= 0 v_0_cc_new_sent) (<= v_0_cc_new_sent v_0_cc_send_budget)))
(assert
 (let (($x693 (>= 0 v_0_rtx_buf)))
 (let (($x994 (not $x693)))
 (let (($x942 (not v_0_cc_rto_00)))
 (or $x942 $x994)))))
(assert
 (let (($x637 (>= 1 v_0_rtx_buf)))
 (let (($x999 (not $x637)))
 (let (($x1981 (not v_0_cc_rto_01)))
 (or $x1981 $x999)))))
(assert
 (let (($x703 (>= 2 v_0_rtx_buf)))
 (let (($x1006 (not $x703)))
 (let (($x1983 (not v_0_cc_rto_02)))
 (or $x1983 $x1006)))))
(assert
 (let (($x709 (>= 3 v_0_rtx_buf)))
 (let (($x1013 (not $x709)))
 (let (($x1985 (not v_0_cc_rto_03)))
 (or $x1985 $x1013)))))
(assert
 (let (($x715 (>= 4 v_0_rtx_buf)))
 (let (($x1020 (not $x715)))
 (let (($x1987 (not v_0_cc_rto_04)))
 (or $x1987 $x1020)))))
(assert
 (let (($x723 (>= 5 v_0_rtx_buf)))
 (let (($x1027 (not $x723)))
 (let (($x1989 (not v_0_cc_rto_05)))
 (or $x1989 $x1027)))))
(assert
 (let (($x731 (>= 6 v_0_rtx_buf)))
 (let (($x1034 (not $x731)))
 (let (($x1991 (not v_0_cc_rto_06)))
 (or $x1991 $x1034)))))
(assert
 (let (($x739 (>= 7 v_0_rtx_buf)))
 (let (($x1041 (not $x739)))
 (let (($x1993 (not v_0_cc_rto_07)))
 (or $x1993 $x1041)))))
(assert
 (let (($x747 (>= 8 v_0_rtx_buf)))
 (let (($x1048 (not $x747)))
 (let (($x1995 (not v_0_cc_rto_08)))
 (or $x1995 $x1048)))))
(assert
 (let (($x755 (>= 9 v_0_rtx_buf)))
 (let (($x1055 (not $x755)))
 (let (($x1997 (not v_0_cc_rto_09)))
 (or $x1997 $x1055)))))
(assert
 (let (($x763 (>= 10 v_0_rtx_buf)))
 (let (($x1062 (not $x763)))
 (let (($x1999 (not v_0_cc_rto_10)))
 (or $x1999 $x1062)))))
(assert
 (let (($x771 (>= 11 v_0_rtx_buf)))
 (let (($x1069 (not $x771)))
 (let (($x2001 (not v_0_cc_rto_11)))
 (or $x2001 $x1069)))))
(assert
 (let (($x779 (>= 12 v_0_rtx_buf)))
 (let (($x1076 (not $x779)))
 (let (($x2003 (not v_0_cc_rto_12)))
 (or $x2003 $x1076)))))
(assert
 (let (($x787 (>= 13 v_0_rtx_buf)))
 (let (($x1083 (not $x787)))
 (let (($x2005 (not v_0_cc_rto_13)))
 (or $x2005 $x1083)))))
(assert
 (let (($x795 (>= 14 v_0_rtx_buf)))
 (let (($x1090 (not $x795)))
 (let (($x2007 (not v_0_cc_rto_14)))
 (or $x2007 $x1090)))))
(assert
 (let (($x803 (>= 15 v_0_rtx_buf)))
 (let (($x1097 (not $x803)))
 (let (($x2009 (not v_0_cc_rto_15)))
 (or $x2009 $x1097)))))
(assert
 (and (<= 0 v_0_fr_dupacks) (<= 0 v_0_fr_entries) (<= 0 v_0_fr_emit_count) (>= 4 v_0_fr_emit_count) (<= 0 v_0_fr_last_window) (>= 65535 v_0_fr_last_window)))
(assert
 (let (($x886 (not v_0_persist_active)))
 (let (($x459 (<= 1 v_0_rtx_buf)))
 (let (($x2019 (not v_0_fr_active)))
 (or $x2019 (and (<= 3 v_0_fr_dupacks) $x459 $x886))))))
(assert
 (let (($x1871 (not v_0_tx_retransmitted)))
 (let (($x2032 (= v_0_retries v_0_fr_before_retries)))
 (let (($x2030 (= v_0_rto_ms v_0_fr_before_rto)))
 (let (($x2028 (= v_0_snd_nxt v_0_fr_before_nxt)))
 (let (($x2033 (and v_0_fr_entered (= 3 v_0_fr_dupacks) (<= 1 v_0_fr_emit_count) $x2028 $x2030 $x2032 $x1871)))
 (let (($x2024 (not v_0_fr_retransmitted)))
 (or $x2024 $x2033))))))))
(assert
 (let (($x2041 (and (= v_0_fr_last_window v_0_fr_before_wire_window) (= v_0_fr_window_valid v_0_fr_before_window_valid))))
 (or (not v_0_fr_window_ignored) $x2041)))
(assert
 (let (($x2043 (not v_0_fr_entered)))
 (or v_0_fr_retransmitted $x2043)))
(assert
 (let (($x2043 (not v_0_fr_entered)))
 (or $x2043 (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))))
(assert
 (let (($x2049 (not v_0_fr_exited)))
 (or $x2049 (and (= v_0_cc_cwnd v_0_cc_ssthresh) (= 0 v_0_cc_ca_credit)))))
(assert
 (and (<= 0 v_0_idle_last_data_ms) (<= v_0_idle_last_data_ms v_0_idle_event_ms) (<= v_0_idle_event_ms now_0) (<= 0 v_0_idle_elapsed_ms) (<= 0 v_0_idle_restart_count)))
(assert
 (or (not v_0_idle_data_emitted) (= v_0_idle_last_data_ms v_0_idle_event_ms)))
(assert
 (let (($x2051 (= 0 v_0_cc_ca_credit)))
 (let (($x2076 (= v_0_cc_ssthresh v_0_idle_before_threshold)))
 (let ((?x2073 (ite (<= v_0_cc_initial_window v_0_idle_before_cwnd) v_0_cc_initial_window v_0_idle_before_cwnd)))
 (let (($x2077 (and (not (>= v_0_idle_before_rto v_0_idle_elapsed_ms)) (= v_0_cc_cwnd ?x2073) $x2076 $x2051)))
 (let (($x2067 (not v_0_idle_restart)))
 (or $x2067 $x2077)))))))
(assert
 (and (<= 0 v_0_lt_epoch_bytes) (>= 8 v_0_lt_epoch_bytes) (<= v_0_lt_epoch_bytes v_0_rtx_buf) (<= 0 v_0_lt_epoch_packets) (>= 2 v_0_lt_epoch_packets) (<= v_0_lt_epoch_packets v_0_fr_dupacks) (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets) (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets)) (<= 0 v_0_lt_loss_flight)))
(assert
 (let (($x2100 (= v_0_cc_cwnd v_0_lt_before_cwnd)))
 (let (($x634 (not v_0_fin_sent)))
 (let (($x2019 (not v_0_fr_active)))
 (let (($x2110 (and v_0_fr_duplicate (<= 1 v_0_fr_dupacks) (>= 2 v_0_fr_dupacks) $x2019 $x634 (<= 1 v_0_lt_take) (>= 4 v_0_lt_take) $x2100 (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take)) (<= v_0_rtx_buf v_0_snd_wnd) (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd)) (= v_0_snd_nxt (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)))))
 (let (($x2092 (not v_0_lt_emitted)))
 (or $x2092 $x2110)))))))
(assert
 (let (($x2116 (= v_0_lt_loss_flight (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes)))))
 (let (($x2043 (not v_0_fr_entered)))
 (or $x2043 $x2116))))
(assert
 (and (<= 0 v_0_choice_count) (>= 4 v_0_choice_count) (<= 0 v_0_choice_limit) (>= 4 v_0_choice_limit)))
(assert
 (let ((?x2131 (mod (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)))
 (let (($x2128 (= v_0_cc_new_sent v_0_choice_count)))
 (let (($x2127 (= v_0_take v_0_choice_count)))
 (let (($x2135 (and (<= 1 v_0_choice_count) (<= v_0_choice_count v_0_choice_limit) $x2127 $x2128 (<= v_0_choice_count v_0_cc_send_budget) (= v_0_snd_nxt ?x2131) (= v_0_rtx_buf (+ v_0_choice_before_flight v_0_choice_count)))))
 (let (($x2124 (not v_0_choice_used)))
 (or $x2124 $x2135)))))))
(assert
 (and (<= 0 v_0_sched_packets) (<= v_0_sched_packets v_0_sched_bytes) (<= v_0_sched_bytes (* 4 v_0_sched_packets)) (>= 16 (+ v_0_sched_bytes v_0_snd_buf))))
(assert
 (let (($x2149 (not v_0_sched_open)))
 (and (<= 0 v_0_sched_at_ms) (<= v_0_sched_at_ms now_0) (or $x2149 (= 1 v_0_sched_cause) (= 2 v_0_sched_cause)))))
(assert
 (let (($x2124 (not v_0_choice_used)))
 (or $x2124 (and v_0_sched_open (= v_0_sched_at_ms v_0_idle_event_ms)))))
(assert
 (let ((?x2161 (+ v_0_svc_acked_bytes v_0_svc_abandoned_bytes v_0_snd_buf v_0_rtx_buf)))
 (and (<= 0 v_0_svc_written_bytes) (<= 0 v_0_svc_acked_bytes) (<= 0 v_0_svc_abandoned_bytes) (= v_0_svc_written_bytes ?x2161))))
(assert
 (let (($x2165 (= v_0_svc_ack_step v_0_cc_acked)))
 (and $x2165 (<= 0 v_0_svc_accept_step) (<= 0 v_0_svc_ack_step) (<= 0 v_0_svc_drop_step))))
(assert
 (let ((?x2179 (+ v_0_cb_head v_0_cb_count)))
 (let (($x2183 (= v_0_cb_tail (ite (<= 16 ?x2179) (+ (- 16) v_0_cb_head v_0_cb_count) ?x2179))))
 (and (<= 0 v_0_cb_head) (not (<= 16 v_0_cb_head)) (<= 0 v_0_cb_tail) (not (<= 16 v_0_cb_tail)) (<= 0 v_0_cb_count) (<= v_0_cb_count v_0_rtx_buf) $x2183 (<= 0 v_0_cb_new_count) (>= 1 v_0_cb_new_count)))))
(assert
 (let ((?x2204 (+ v_0_cb_length_00 v_0_cb_length_01 v_0_cb_length_02 v_0_cb_length_03 v_0_cb_length_04 v_0_cb_length_05 v_0_cb_length_06 v_0_cb_length_07 v_0_cb_length_08 v_0_cb_length_09 v_0_cb_length_10 v_0_cb_length_11 v_0_cb_length_12 v_0_cb_length_13 v_0_cb_length_14 v_0_cb_length_15)))
 (let (($x2203 (= v_0_cb_emitted_total (+ v_0_cb_acked_total v_0_cb_abandoned_total v_0_cb_live_total))))
 (and (<= 0 v_0_cb_emitted_total) (<= 0 v_0_cb_acked_total) (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix) v_0_svc_acked_bytes) (<= v_0_cb_emitted_total v_0_svc_written_bytes) (<= 0 v_0_cb_abandoned_total) (<= 0 v_0_cb_step_bytes) (>= 19 v_0_cb_step_bytes) (<= 0 v_0_cb_drop_step) $x2203 (= v_0_cb_live_total ?x2204)))))
(assert
 (let (($x2208 (= v_0_cb_partial_prefix (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf)))))
 (and $x2208 (<= 0 v_0_cb_partial_prefix) (>= 3 v_0_cb_partial_prefix))))
(assert
 (<= (+ v_0_cb_emitted_total v_0_snd_buf) v_0_svc_written_bytes))
(assert
 (let ((?x648 (- 1)))
 (let ((?x2218 (* ?x648 v_0_cb_head)))
 (let ((?x2220 (ite (>= 0 v_0_cb_head) ?x2218 (+ 16 ?x2218))))
 (let (($x2221 (>= ?x2220 v_0_cb_count)))
 (let (($x2223 (not $x2221)))
 (let (($x2245 (or (not (and $x2223 (<= 1 ?x2220))) (= v_0_cb_end_00 (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)))))
 (let ((?x2235 (mod (+ v_0_snd_una v_0_cb_length_00 (* ?x648 v_0_cb_partial_prefix)) 4294967296)))
 (let (($x2237 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_00)) (= v_0_cb_end_00 ?x2235))))
 (let (($x2222 (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00)) $x2221)))
 (and $x2222 (or $x2223 (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00))) (or (not (and $x2223 (= 0 v_0_cb_head))) $x2237) $x2245)))))))))))
(assert
 (let ((?x2251 (ite (>= 1 v_0_cb_head) (+ 1 (* (- 1) v_0_cb_head)) (+ 17 (* (- 1) v_0_cb_head)))))
 (let (($x2252 (>= ?x2251 v_0_cb_count)))
 (let (($x2257 (not $x2252)))
 (let (($x2278 (or (not (and $x2257 (<= 1 ?x2251))) (= v_0_cb_end_01 (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2269 (= v_0_cb_end_01 (mod (+ v_0_snd_una v_0_cb_length_01 ?x2233) 4294967296))))
 (let (($x2271 (or (not (and $x2257 (= 1 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_01)) $x2269))))
 (let (($x2256 (or $x2252 (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01)))))
 (and $x2256 (or $x2257 (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01))) $x2271 $x2278)))))))))))
(assert
 (let ((?x2284 (ite (>= 2 v_0_cb_head) (+ 2 (* (- 1) v_0_cb_head)) (+ 18 (* (- 1) v_0_cb_head)))))
 (let (($x2285 (>= ?x2284 v_0_cb_count)))
 (let (($x2290 (not $x2285)))
 (let (($x2311 (or (not (and $x2290 (<= 1 ?x2284))) (= v_0_cb_end_02 (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2302 (= v_0_cb_end_02 (mod (+ v_0_snd_una v_0_cb_length_02 ?x2233) 4294967296))))
 (let (($x2304 (or (not (and $x2290 (= 2 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_02)) $x2302))))
 (let (($x2289 (or $x2285 (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)))))
 (and $x2289 (or $x2290 (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02))) $x2304 $x2311)))))))))))
(assert
 (let ((?x2316 (ite (>= 3 v_0_cb_head) (+ 3 (* (- 1) v_0_cb_head)) (+ 19 (* (- 1) v_0_cb_head)))))
 (let (($x2317 (>= ?x2316 v_0_cb_count)))
 (let (($x2322 (not $x2317)))
 (let (($x2343 (or (not (and $x2322 (<= 1 ?x2316))) (= v_0_cb_end_03 (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2334 (= v_0_cb_end_03 (mod (+ v_0_snd_una v_0_cb_length_03 ?x2233) 4294967296))))
 (let (($x2336 (or (not (and $x2322 (= 3 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_03)) $x2334))))
 (let (($x2321 (or $x2317 (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03)))))
 (and $x2321 (or $x2322 (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03))) $x2336 $x2343)))))))))))
(assert
 (let ((?x2352 (ite (>= 4 v_0_cb_head) (+ 4 (* (- 1) v_0_cb_head)) (+ 20 (* (- 1) v_0_cb_head)))))
 (let (($x2353 (>= ?x2352 v_0_cb_count)))
 (let (($x2355 (not $x2353)))
 (let (($x2376 (or (not (and $x2355 (<= 1 ?x2352))) (= v_0_cb_end_04 (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2367 (= v_0_cb_end_04 (mod (+ v_0_snd_una v_0_cb_length_04 ?x2233) 4294967296))))
 (let (($x2369 (or (not (and $x2355 (= 4 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_04)) $x2367))))
 (let (($x2354 (or (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04)) $x2353)))
 (and $x2354 (or $x2355 (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04))) $x2369 $x2376)))))))))))
(assert
 (let ((?x2382 (ite (>= 5 v_0_cb_head) (+ 5 (* (- 1) v_0_cb_head)) (+ 21 (* (- 1) v_0_cb_head)))))
 (let (($x2383 (>= ?x2382 v_0_cb_count)))
 (let (($x2388 (not $x2383)))
 (let (($x2409 (or (not (and $x2388 (<= 1 ?x2382))) (= v_0_cb_end_05 (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2400 (= v_0_cb_end_05 (mod (+ v_0_snd_una v_0_cb_length_05 ?x2233) 4294967296))))
 (let (($x2402 (or (not (and $x2388 (= 5 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_05)) $x2400))))
 (let (($x2387 (or $x2383 (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))))
 (and $x2387 (or $x2388 (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05))) $x2402 $x2409)))))))))))
(assert
 (let ((?x2415 (ite (>= 6 v_0_cb_head) (+ 6 (* (- 1) v_0_cb_head)) (+ 22 (* (- 1) v_0_cb_head)))))
 (let (($x2416 (>= ?x2415 v_0_cb_count)))
 (let (($x2421 (not $x2416)))
 (let (($x2442 (or (not (and $x2421 (<= 1 ?x2415))) (= v_0_cb_end_06 (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2433 (= v_0_cb_end_06 (mod (+ v_0_snd_una v_0_cb_length_06 ?x2233) 4294967296))))
 (let (($x2435 (or (not (and $x2421 (= 6 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_06)) $x2433))))
 (let (($x2420 (or $x2416 (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06)))))
 (and $x2420 (or $x2421 (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06))) $x2435 $x2442)))))))))))
(assert
 (let ((?x2448 (ite (>= 7 v_0_cb_head) (+ 7 (* (- 1) v_0_cb_head)) (+ 23 (* (- 1) v_0_cb_head)))))
 (let (($x2449 (>= ?x2448 v_0_cb_count)))
 (let (($x2454 (not $x2449)))
 (let (($x2475 (or (not (and $x2454 (<= 1 ?x2448))) (= v_0_cb_end_07 (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2466 (= v_0_cb_end_07 (mod (+ v_0_snd_una v_0_cb_length_07 ?x2233) 4294967296))))
 (let (($x2468 (or (not (and $x2454 (= 7 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_07)) $x2466))))
 (let (($x2453 (or $x2449 (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))))
 (and $x2453 (or $x2454 (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07))) $x2468 $x2475)))))))))))
(assert
 (let ((?x2484 (ite (>= 8 v_0_cb_head) (+ 8 (* (- 1) v_0_cb_head)) (+ 24 (* (- 1) v_0_cb_head)))))
 (let (($x2485 (>= ?x2484 v_0_cb_count)))
 (let (($x2487 (not $x2485)))
 (let (($x2508 (or (not (and $x2487 (<= 1 ?x2484))) (= v_0_cb_end_08 (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2499 (= v_0_cb_end_08 (mod (+ v_0_snd_una v_0_cb_length_08 ?x2233) 4294967296))))
 (let (($x2501 (or (not (and $x2487 (= 8 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_08)) $x2499))))
 (let (($x2486 (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08)) $x2485)))
 (and $x2486 (or $x2487 (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08))) $x2501 $x2508)))))))))))
(assert
 (let ((?x2514 (ite (>= 9 v_0_cb_head) (+ 9 (* (- 1) v_0_cb_head)) (+ 25 (* (- 1) v_0_cb_head)))))
 (let (($x2515 (>= ?x2514 v_0_cb_count)))
 (let (($x2520 (not $x2515)))
 (let (($x2541 (or (not (and $x2520 (<= 1 ?x2514))) (= v_0_cb_end_09 (mod (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2532 (= v_0_cb_end_09 (mod (+ v_0_snd_una v_0_cb_length_09 ?x2233) 4294967296))))
 (let (($x2534 (or (not (and $x2520 (= 9 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09)) $x2532))))
 (let (($x2519 (or $x2515 (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09)))))
 (and $x2519 (or $x2520 (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09))) $x2534 $x2541)))))))))))
(assert
 (let ((?x2547 (ite (>= 10 v_0_cb_head) (+ 10 (* (- 1) v_0_cb_head)) (+ 26 (* (- 1) v_0_cb_head)))))
 (let (($x2548 (>= ?x2547 v_0_cb_count)))
 (let (($x2553 (not $x2548)))
 (let (($x2574 (or (not (and $x2553 (<= 1 ?x2547))) (= v_0_cb_end_10 (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2565 (= v_0_cb_end_10 (mod (+ v_0_snd_una v_0_cb_length_10 ?x2233) 4294967296))))
 (let (($x2567 (or (not (and $x2553 (= 10 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_10)) $x2565))))
 (let (($x2552 (or $x2548 (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10)))))
 (and $x2552 (or $x2553 (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10))) $x2567 $x2574)))))))))))
(assert
 (let ((?x2583 (ite (>= 11 v_0_cb_head) (+ 11 (* (- 1) v_0_cb_head)) (+ 27 (* (- 1) v_0_cb_head)))))
 (let (($x2584 (>= ?x2583 v_0_cb_count)))
 (let (($x2586 (not $x2584)))
 (let (($x2607 (or (not (and $x2586 (<= 1 ?x2583))) (= v_0_cb_end_11 (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2598 (= v_0_cb_end_11 (mod (+ v_0_snd_una v_0_cb_length_11 ?x2233) 4294967296))))
 (let (($x2600 (or (not (and $x2586 (= 11 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_11)) $x2598))))
 (let (($x2585 (or (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)) $x2584)))
 (and $x2585 (or $x2586 (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11))) $x2600 $x2607)))))))))))
(assert
 (let ((?x2616 (ite (>= 12 v_0_cb_head) (+ 12 (* (- 1) v_0_cb_head)) (+ 28 (* (- 1) v_0_cb_head)))))
 (let (($x2617 (>= ?x2616 v_0_cb_count)))
 (let (($x2619 (not $x2617)))
 (let (($x2640 (or (not (and $x2619 (<= 1 ?x2616))) (= v_0_cb_end_12 (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2631 (= v_0_cb_end_12 (mod (+ v_0_snd_una v_0_cb_length_12 ?x2233) 4294967296))))
 (let (($x2633 (or (not (and $x2619 (= 12 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_12)) $x2631))))
 (let (($x2618 (or (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12)) $x2617)))
 (and $x2618 (or $x2619 (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12))) $x2633 $x2640)))))))))))
(assert
 (let ((?x2649 (ite (>= 13 v_0_cb_head) (+ 13 (* (- 1) v_0_cb_head)) (+ 29 (* (- 1) v_0_cb_head)))))
 (let (($x2650 (>= ?x2649 v_0_cb_count)))
 (let (($x2652 (not $x2650)))
 (let (($x2673 (or (not (and $x2652 (<= 1 ?x2649))) (= v_0_cb_end_13 (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2664 (= v_0_cb_end_13 (mod (+ v_0_snd_una v_0_cb_length_13 ?x2233) 4294967296))))
 (let (($x2666 (or (not (and $x2652 (= 13 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_13)) $x2664))))
 (let (($x2651 (or (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)) $x2650)))
 (and $x2651 (or $x2652 (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13))) $x2666 $x2673)))))))))))
(assert
 (let ((?x2679 (ite (>= 14 v_0_cb_head) (+ 14 (* (- 1) v_0_cb_head)) (+ 30 (* (- 1) v_0_cb_head)))))
 (let (($x2680 (>= ?x2679 v_0_cb_count)))
 (let (($x2685 (not $x2680)))
 (let (($x2706 (or (not (and $x2685 (<= 1 ?x2679))) (= v_0_cb_end_14 (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2697 (= v_0_cb_end_14 (mod (+ v_0_snd_una v_0_cb_length_14 ?x2233) 4294967296))))
 (let (($x2699 (or (not (and $x2685 (= 14 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_14)) $x2697))))
 (let (($x2684 (or $x2680 (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14)))))
 (and $x2684 (or $x2685 (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14))) $x2699 $x2706)))))))))))
(assert
 (let ((?x2712 (ite (>= 15 v_0_cb_head) (+ 15 (* (- 1) v_0_cb_head)) (+ 31 (* (- 1) v_0_cb_head)))))
 (let (($x2713 (>= ?x2712 v_0_cb_count)))
 (let (($x2718 (not $x2713)))
 (let (($x2739 (or (not (and $x2718 (<= 1 ?x2712))) (= v_0_cb_end_15 (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))))
 (let ((?x648 (- 1)))
 (let ((?x2233 (* ?x648 v_0_cb_partial_prefix)))
 (let (($x2730 (= v_0_cb_end_15 (mod (+ v_0_snd_una v_0_cb_length_15 ?x2233) 4294967296))))
 (let (($x2732 (or (not (and $x2718 (= 15 v_0_cb_head))) (and (not (>= v_0_cb_partial_prefix v_0_cb_length_15)) $x2730))))
 (let (($x2717 (or $x2713 (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)))))
 (and $x2717 (or $x2718 (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15))) $x2732 $x2739)))))))))))
(assert
 (= 89 choice_0))
(assert
 (= 4 state_0))
(assert
 (= 4 state_1))
(assert
 (let ((?x2795 (ite (>= 1 v_1_cb_head) (+ 1 (* (- 1) v_1_cb_head)) (+ 17 (* (- 1) v_1_cb_head)))))
(let (($x2796 (>= ?x2795 v_1_cb_count)))
(let (($x2803 (or (not $x2796) (and (= 0 v_1_cb_length_01) (= 0 v_1_cb_end_01)))))
(let (($x2797 (or (and (<= 1 v_1_cb_length_01) (>= 4 v_1_cb_length_01)) $x2796)))
(let ((?x648 (- 1)))
(let ((?x2757 (* ?x648 v_1_cb_head)))
(let ((?x2759 (ite (>= 0 v_1_cb_head) ?x2757 (+ 16 ?x2757))))
(let (($x2760 (>= ?x2759 v_1_cb_count)))
(let (($x2763 (not $x2760)))
(let (($x2787 (or (not (and $x2763 (<= 1 ?x2759))) (= v_1_cb_end_00 (mod (+ v_1_cb_end_15 v_1_cb_length_00) 4294967296)))))
(let ((?x2776 (mod (+ v_1_snd_una v_1_cb_length_00 (* ?x648 v_1_cb_partial_prefix)) 4294967296)))
(let (($x2778 (and (not (>= v_1_cb_partial_prefix v_1_cb_length_00)) (= v_1_cb_end_00 ?x2776))))
(let (($x2768 (not (or $x2763 (and (= 0 v_1_cb_length_00) (= 0 v_1_cb_end_00))))))
(let (($x2761 (or (and (<= 1 v_1_cb_length_00) (>= 4 v_1_cb_length_00)) $x2760)))
(let (($x2752 (not (<= (+ v_1_cb_emitted_total v_1_snd_buf) v_1_svc_written_bytes))))
(or (not (>= 3 v_1_cb_partial_prefix)) $x2752 (not $x2761) $x2768 (not (or (not (and $x2763 (= 0 v_1_cb_head))) $x2778)) (not $x2787) (not $x2797) (not $x2803))))))))))))))))))
(check-sat)

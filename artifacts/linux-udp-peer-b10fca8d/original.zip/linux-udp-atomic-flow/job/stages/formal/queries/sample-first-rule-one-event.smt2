; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= choice_0 0))
(assert
 (let (($x304 (= v_1_disposition v_0_disposition)))
 (let (($x303 (= v_1_payload v_0_payload)))
 (let (($x69 (= v_1_require_checksum v_0_require_checksum)))
 (let (($x309 (= choice_0 (- 1))))
 (let (($x310 (and $x309 (= state_1 state_0) (= now_1 now_0) $x69 $x303 $x304)))
 (let (($x70 (= v_1_payload (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x68 (= 0 state_1)))
 (let (($x67 (= choice_0 0)))
 (let ((?x62 (seq.len input_0_net.packet_packet)))
 (let (($x64 (>= 27 ?x62)))
 (let (($x61 (>= now_1 now_0)))
 (let (($x21 (= state_0 0)))
 (let (($x72 (and and $x21 $x61 $x64 $x67 $x68 $x69 $x70 (= v_1_disposition "drop_short"))))
 (or $x72 $x310)))))))))))))))
(assert
 (>= choice_0 0))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x61 (= v_1_disposition "deliver")))
 (let ((?x825 (seq.unit (_ bv0 8))))
 (let ((?x686 (seq.unit (_ bv255 8))))
 (let ((?x1036 (seq.++ ?x686 ?x825)))
 (let (($x778 (= v_1_payload ?x1036)))
 (let (($x1151 (not v_1_require_checksum)))
 (let (($x391 (= 0 state_1)))
 (let (($x298 (= state_0 0)))
 (and $x298 (>= 0 now_0) $x391 $x1151 $x778 $x61))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x830 (seq.unit (_ bv193 8))))
(let ((?x711 (seq.++ ?x830 (seq.++ (seq.unit (_ bv4 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.unit (_ bv0 8)))))))
(let ((?x1318 (seq.unit (_ bv10 8))))
(let ((?x825 (seq.unit (_ bv0 8))))
(let ((?x501 (seq.unit (_ bv64 8))))
(let ((?x235 (seq.unit (_ bv156 8))))
(let ((?x221 (seq.unit (_ bv144 8))))
(let ((?x1161 (seq.++ ?x221 (seq.++ ?x235 (seq.++ ?x501 (seq.++ ?x825 (seq.++ ?x1318 ?x711)))))))
(let ((?x237 (seq.unit (_ bv31 8))))
(let ((?x207 (seq.unit (_ bv1 8))))
(let ((?x245 (seq.unit (_ bv2 8))))
(let ((?x214 (seq.unit (_ bv192 8))))
(let ((?x48 (seq.++ ?x214 (seq.++ ?x825 (seq.++ ?x245 (seq.++ ?x207 (seq.++ ?x237 ?x1161)))))))
(let ((?x933 (seq.unit (_ bv203 8))))
(let ((?x850 (seq.++ ?x933 (seq.++ ?x214 (seq.++ ?x825 (seq.++ ?x245 (seq.++ ?x245 ?x48)))))))
(let ((?x688 (seq.unit (_ bv182 8))))
(let ((?x411 (seq.unit (_ bv17 8))))
(let ((?x542 (seq.++ ?x501 (seq.++ ?x825 (seq.++ ?x501 (seq.++ ?x411 (seq.++ ?x688 ?x850)))))))
(let ((?x686 (seq.unit (_ bv255 8))))
(let ((?x690 (seq.unit (_ bv30 8))))
(let ((?x1230 (seq.++ ?x825 (seq.++ ?x825 (seq.++ ?x690 (seq.++ ?x686 (seq.++ ?x686 ?x542)))))))
(let ((?x511 (seq.unit (_ bv69 8))))
(let ((?x1137 (seq.++ ?x511 ?x1230)))
(= input_0_net.packet_packet ?x1137)))))))))))))))))))))))))
(check-sat)

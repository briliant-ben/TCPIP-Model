; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x58 (= v_1_disposition "drop_ip_checksum")))
 (let (($x720 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x755 (not v_1_require_checksum)))
 (let (($x411 (= 0 state_1)))
 (let (($x488 (= state_0 0)))
 (and $x488 (>= 0 now_0) $x411 $x755 $x720 $x58)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 2 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x52 (seq.unit (_ bv0 8))))
(let ((?x332 (seq.++ ?x52 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
(let ((?x7 (seq.unit (_ bv64 8))))
(let ((?x417 (seq.unit (_ bv156 8))))
(let ((?x382 (seq.unit (_ bv144 8))))
(let ((?x371 (seq.unit (_ bv31 8))))
(let ((?x339 (seq.unit (_ bv1 8))))
(let ((?x939 (seq.++ ?x339 (seq.++ ?x371 (seq.++ ?x382 (seq.++ ?x417 (seq.++ ?x7 ?x332)))))))
(let ((?x1352 (seq.unit (_ bv2 8))))
(let ((?x14 (seq.unit (_ bv192 8))))
(let ((?x944 (seq.++ ?x1352 (seq.++ ?x1352 (seq.++ ?x14 (seq.++ ?x52 (seq.++ ?x1352 ?x939)))))))
(let ((?x288 (seq.unit (_ bv204 8))))
(let ((?x333 (seq.unit (_ bv182 8))))
(let ((?x5 (seq.unit (_ bv17 8))))
(let ((?x1044 (seq.++ ?x5 (seq.++ ?x333 (seq.++ ?x288 (seq.++ ?x14 (seq.++ ?x52 ?x944)))))))
(let ((?x420 (seq.unit (_ bv52 8))))
(let ((?x359 (seq.unit (_ bv18 8))))
(let ((?x1049 (seq.++ ?x359 (seq.++ ?x420 (seq.++ ?x7 (seq.++ ?x52 (seq.++ ?x7 ?x1044)))))))
(let ((?x323 (seq.unit (_ bv28 8))))
(let ((?x37 (seq.unit (_ bv69 8))))
(let ((?x1053 (seq.++ ?x37 (seq.++ ?x52 (seq.++ ?x52 (seq.++ ?x323 ?x1049))))))
(= input_0_net.packet_packet ?x1053)))))))))))))))))))))))
(check-sat)

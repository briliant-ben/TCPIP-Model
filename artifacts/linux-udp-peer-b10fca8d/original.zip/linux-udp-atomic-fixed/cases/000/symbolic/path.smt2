; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x267 (= v_1_disposition "deliver")))
 (let ((?x77 (seq.unit (_ bv0 8))))
 (let ((?x499 (seq.++ ?x77 (seq.++ (seq.unit (_ bv128 8)) (seq.unit (_ bv255 8))))))
 (let (($x1351 (= v_1_payload ?x499)))
 (let (($x1344 (not v_1_require_checksum)))
 (let (($x264 (= 0 state_1)))
 (let (($x16 (= state_0 0)))
 (and $x16 (>= 0 now_0) $x264 $x1344 $x1351 $x267)))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x77 (seq.unit (_ bv0 8))))
(let ((?x499 (seq.++ ?x77 (seq.++ (seq.unit (_ bv128 8)) (seq.unit (_ bv255 8))))))
(let ((?x493 (seq.unit (_ bv130 8))))
(let ((?x101 (seq.unit (_ bv192 8))))
(let ((?x491 (seq.unit (_ bv11 8))))
(let ((?x88 (seq.unit (_ bv64 8))))
(let ((?x504 (seq.++ ?x88 (seq.++ ?x77 (seq.++ ?x491 (seq.++ ?x101 (seq.++ ?x493 ?x499)))))))
(let ((?x111 (seq.unit (_ bv156 8))))
(let ((?x109 (seq.unit (_ bv144 8))))
(let ((?x107 (seq.unit (_ bv31 8))))
(let ((?x105 (seq.unit (_ bv1 8))))
(let ((?x103 (seq.unit (_ bv2 8))))
(let ((?x509 (seq.++ ?x103 (seq.++ ?x105 (seq.++ ?x107 (seq.++ ?x109 (seq.++ ?x111 ?x504)))))))
(let ((?x514 (seq.++ ?x77 (seq.++ ?x103 (seq.++ ?x103 (seq.++ ?x101 (seq.++ ?x77 ?x509)))))))
(let ((?x489 (seq.unit (_ bv150 8))))
(let ((?x487 (seq.unit (_ bv164 8))))
(let ((?x90 (seq.unit (_ bv17 8))))
(let ((?x519 (seq.++ ?x88 (seq.++ ?x90 (seq.++ ?x487 (seq.++ ?x489 (seq.++ ?x101 ?x514)))))))
(let ((?x485 (seq.unit (_ bv52 8))))
(let ((?x483 (seq.unit (_ bv18 8))))
(let ((?x524 (seq.++ ?x107 (seq.++ ?x483 (seq.++ ?x485 (seq.++ ?x88 (seq.++ ?x77 ?x519)))))))
(let ((?x75 (seq.unit (_ bv69 8))))
(let ((?x527 (seq.++ ?x75 (seq.++ ?x77 (seq.++ ?x77 ?x524)))))
(= input_0_net.packet_packet ?x527)))))))))))))))))))))))))
(check-sat)

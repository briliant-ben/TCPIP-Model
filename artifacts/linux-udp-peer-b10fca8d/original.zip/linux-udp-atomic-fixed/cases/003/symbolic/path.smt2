; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x526 (= v_1_disposition "deliver")))
 (let (($x558 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x701 (not v_1_require_checksum)))
 (let (($x523 (= 0 state_1)))
 (let (($x244 (= state_0 0)))
 (and $x244 (>= 0 now_0) $x523 $x701 $x558 $x526)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x167 (seq.unit (_ bv0 8))))
(let ((?x1093 (seq.++ ?x167 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
(let ((?x298 (seq.unit (_ bv64 8))))
(let ((?x202 (seq.unit (_ bv156 8))))
(let ((?x63 (seq.unit (_ bv144 8))))
(let ((?x1210 (seq.unit (_ bv31 8))))
(let ((?x250 (seq.unit (_ bv1 8))))
(let ((?x1118 (seq.++ ?x250 (seq.++ ?x1210 (seq.++ ?x63 (seq.++ ?x202 (seq.++ ?x298 ?x1093)))))))
(let ((?x1207 (seq.unit (_ bv2 8))))
(let ((?x333 (seq.unit (_ bv192 8))))
(let ((?x1283 (seq.++ ?x1207 (seq.++ ?x1207 (seq.++ ?x333 (seq.++ ?x167 (seq.++ ?x1207 ?x1118)))))))
(let ((?x1302 (seq.unit (_ bv204 8))))
(let ((?x814 (seq.unit (_ bv182 8))))
(let ((?x29 (seq.unit (_ bv17 8))))
(let ((?x640 (seq.++ ?x29 (seq.++ ?x814 (seq.++ ?x1302 (seq.++ ?x333 (seq.++ ?x167 ?x1283)))))))
(let ((?x975 (seq.++ ?x167 (seq.++ ?x250 (seq.++ ?x298 (seq.++ ?x167 (seq.++ ?x298 ?x640)))))))
(let ((?x1267 (seq.unit (_ bv28 8))))
(let ((?x357 (seq.unit (_ bv69 8))))
(let ((?x1281 (seq.++ ?x357 (seq.++ ?x167 (seq.++ ?x167 (seq.++ ?x1267 ?x975))))))
(= input_0_net.packet_packet ?x1281)))))))))))))))))))))
(check-sat)

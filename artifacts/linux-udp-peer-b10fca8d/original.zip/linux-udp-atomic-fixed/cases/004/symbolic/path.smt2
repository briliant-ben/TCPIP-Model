; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_disposition () String)
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_require_checksum () Bool)
(declare-fun state_2 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x470 (= v_1_disposition "deliver")))
 (let ((?x511 (seq.unit (_ bv0 8))))
 (let ((?x877 (seq.++ ?x511 (seq.++ (seq.unit (_ bv128 8)) (seq.unit (_ bv255 8))))))
 (let (($x1538 (= v_1_payload ?x877)))
 (let (($x550 (not v_1_require_checksum)))
 (let (($x231 (= 0 state_1)))
 (let (($x1210 (= state_0 0)))
 (and $x1210 (>= 0 now_0) $x231 $x550 $x1538 $x470)))))))))
(assert
 true)
(assert
 (let (($x1028 (= v_2_disposition "deliver")))
 (let ((?x511 (seq.unit (_ bv0 8))))
 (let ((?x877 (seq.++ ?x511 (seq.++ (seq.unit (_ bv128 8)) (seq.unit (_ bv255 8))))))
 (let (($x973 (= v_2_payload ?x877)))
 (let (($x534 (= v_2_require_checksum v_1_require_checksum)))
 (let (($x776 (= 0 state_2)))
 (let (($x56 (= state_1 0)))
 (and $x56 $x776 $x534 $x973 $x1028)))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x511 (seq.unit (_ bv0 8))))
 (let ((?x877 (seq.++ ?x511 (seq.++ (seq.unit (_ bv128 8)) (seq.unit (_ bv255 8))))))
 (let ((?x382 (seq.unit (_ bv130 8))))
 (let ((?x155 (seq.unit (_ bv192 8))))
 (let ((?x981 (seq.unit (_ bv11 8))))
 (let ((?x559 (seq.unit (_ bv64 8))))
 (let ((?x291 (seq.++ ?x559 (seq.++ ?x511 (seq.++ ?x981 (seq.++ ?x155 (seq.++ ?x382 ?x877)))))))
 (let ((?x62 (seq.unit (_ bv156 8))))
 (let ((?x346 (seq.unit (_ bv144 8))))
 (let ((?x347 (seq.unit (_ bv31 8))))
 (let ((?x1193 (seq.unit (_ bv1 8))))
 (let ((?x93 (seq.unit (_ bv2 8))))
 (let ((?x425 (seq.++ ?x93 (seq.++ ?x1193 (seq.++ ?x347 (seq.++ ?x346 (seq.++ ?x62 ?x291)))))))
 (let ((?x841 (seq.++ ?x511 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x155 (seq.++ ?x511 ?x425)))))))
 (let ((?x1008 (seq.unit (_ bv150 8))))
 (let ((?x1012 (seq.unit (_ bv164 8))))
 (let ((?x349 (seq.unit (_ bv17 8))))
 (let ((?x125 (seq.++ ?x559 (seq.++ ?x349 (seq.++ ?x1012 (seq.++ ?x1008 (seq.++ ?x155 ?x841)))))))
 (let ((?x1227 (seq.unit (_ bv52 8))))
 (let ((?x1278 (seq.unit (_ bv18 8))))
 (let ((?x1077 (seq.++ ?x347 (seq.++ ?x1278 (seq.++ ?x1227 (seq.++ ?x559 (seq.++ ?x511 ?x125)))))))
 (let ((?x244 (seq.unit (_ bv69 8))))
 (let ((?x205 (seq.++ ?x244 (seq.++ ?x511 (seq.++ ?x511 ?x1077)))))
 (= input_0_net.packet_packet ?x205)))))))))))))))))))))))))
(assert
 (= 6 choice_1))
(assert
 (= 0 now_2))
(assert
 (let ((?x511 (seq.unit (_ bv0 8))))
(let ((?x877 (seq.++ ?x511 (seq.++ (seq.unit (_ bv128 8)) (seq.unit (_ bv255 8))))))
(let ((?x382 (seq.unit (_ bv130 8))))
(let ((?x155 (seq.unit (_ bv192 8))))
(let ((?x981 (seq.unit (_ bv11 8))))
(let ((?x559 (seq.unit (_ bv64 8))))
(let ((?x291 (seq.++ ?x559 (seq.++ ?x511 (seq.++ ?x981 (seq.++ ?x155 (seq.++ ?x382 ?x877)))))))
(let ((?x62 (seq.unit (_ bv156 8))))
(let ((?x346 (seq.unit (_ bv144 8))))
(let ((?x347 (seq.unit (_ bv31 8))))
(let ((?x1193 (seq.unit (_ bv1 8))))
(let ((?x93 (seq.unit (_ bv2 8))))
(let ((?x425 (seq.++ ?x93 (seq.++ ?x1193 (seq.++ ?x347 (seq.++ ?x346 (seq.++ ?x62 ?x291)))))))
(let ((?x841 (seq.++ ?x511 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x155 (seq.++ ?x511 ?x425)))))))
(let ((?x1008 (seq.unit (_ bv150 8))))
(let ((?x1012 (seq.unit (_ bv164 8))))
(let ((?x349 (seq.unit (_ bv17 8))))
(let ((?x125 (seq.++ ?x559 (seq.++ ?x349 (seq.++ ?x1012 (seq.++ ?x1008 (seq.++ ?x155 ?x841)))))))
(let ((?x1227 (seq.unit (_ bv52 8))))
(let ((?x1278 (seq.unit (_ bv18 8))))
(let ((?x1077 (seq.++ ?x347 (seq.++ ?x1278 (seq.++ ?x1227 (seq.++ ?x559 (seq.++ ?x511 ?x125)))))))
(let ((?x244 (seq.unit (_ bv69 8))))
(let ((?x205 (seq.++ ?x244 (seq.++ ?x511 (seq.++ ?x511 ?x1077)))))
(= input_1_net.packet_packet ?x205)))))))))))))))))))))))))
(check-sat)

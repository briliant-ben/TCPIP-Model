# 有限完整分段确认信用账本

本overlay继承tcp-output-schedule，不改变TCP字节ACK、发送／重传队列、序列空间或timer。增加16槽循环账本，每槽显式int长度1..4和seq32排他末端。仅实际非空tcp_data在该规则入口SND.NXT处的新发建立记录；SYN、FIN及旧范围重传不新计。每个原子规则至多一个新数据段，超出由不变量拒绝。循环head／tail和ACK释放均为JSON IR表达式，不依赖Python运行时回调、排序或隐藏队列。

在父模型已经接受新的data ACK信用后，覆盖完整原始段末端的记录才释放。cb_step_bytes是该原子输入的显式IR服务观察量；cb_acked_total累计完整记录信用。部分ACK仍立即推进父snd_una及svc_acked_bytes，却不提前释放完整段信用。重复／旧／未来ACK不伪造信用，重传不重复建账。cb_live_total减实际rtx字节数是已ACK但尚未释放的头段前缀，范围0..3；完整记录质量守恒包括原始段的被放弃信用，和父模型仅剩未确认字节的放弃量分别保留。

该服务策略来自固定lwIP2.2.1公开tcp_sent API和tcp_free_acked_segments实现：完整原始段释放后累加recv_acked，再调用sent回调。它是实现特定的可选观察模型，不是RFC要求所有TCP API使用同样回调粒度。RFC9293 August2022 §§3.4、3.10.7.4的字节／累计ACK语义继续由父链负责；源码版本、相关主文件SHA和解释绑定spec/sources/tcp-sent-ledger.json。C适配器只记录公共回调时间与字节数，不读取或改写内部PCB，不改变上游。

使用同一源输入／显式调度见证，独立比较完整严格线端和带时刻服务事件。服务匹配不抹去RTO或分段网络差异，也不把TCP字节ACK直接等同完整段回调。支持范围仍为SMSS4／队列16及父连接链，不覆盖所有Nagle/SWS、实现段拆分／合并／重分段策略、65535以上回调拆分、通用socket或实现精化。固定输入全字节查询、长度／标量归纳、真实内存netif观察和Linux证据分别标注，unknown保持unknown。

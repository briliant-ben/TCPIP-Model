# Independent public sent-callback observations

The pinned unmodified lwIP2.2.1 raw API driver records each public sent callback
as its virtual millisecond and acknowledged-byte count, including its boundaries.
It keeps the timer driver's1ms sys_check_timeouts dispatch, <=12000ms, <=64 events,
<=16 written bytes and <=64 peer bytes. No internal PCB state or upstream change.

TCP source inputs are consumed exactly once through the generic witness replayer.
Only declared IR choice events are inserted; they are not extra C API calls.
The tcp-sent-ledger model declares the circular segment accounting and cb_step_bytes.
The Python projection only reads that declared observation variable and compares
the ordered callback records exactly. It does not calculate TCP ACK eligibility.
The complete original reference contract is still required for these new fixtures.
Previous canonical failures and2750ms timer differences remain separate unchanged
evidence. Service agreement never erases a wire Difference.

Run `.venv/bin/python ports/lwip-service/run.py --scenario <bound-json> --out <dir>`;
then repeat with `--verify`. A valid executed mismatch returns1 on execution.
Use `.venv/bin/python ports/lwip-service/tests.py` for standalone validation.
All source/witness/projection/schema/C/compiler/binary/capture/query hashes are
bound. Binaries are rebuilt locally and ignored by Git. Real memory-netif frames
are implementation evidence, not Linux or general TCP/socket refinement proof.

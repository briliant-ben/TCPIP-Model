"""Same complete source inputs and full captured projection under explicit IR."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from protocol_lab.capture import normalize
from protocol_lab.flow import digest, read, write
from protocol_lab.ir import load
from protocol_lab.packets import compare
from protocol_lab.profiles import control_packets
from protocol_lab.symbolic import crosscheck_trace, model_hash


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


HERE = Path(__file__).resolve().parent
original = module('original_schedule_stream', ROOT / 'ports/lwip-stream/run.py')
replayer = module('generic_schedule_replayer', ROOT / 'tools/replay_schedule.py')
source_path = original.PORT / 'scenarios/four-byte-peer-window.json'
capture_dir = ROOT / 'artifacts/lwip-stream/four-byte-peer-window'
legacy_verification = original.verify(capture_dir, source_path)
assert legacy_verification['comparison'] == 'mismatch'
legacy_hashes = {n: digest(capture_dir / n) for n in ['report.json', 'capture.pcap', 'difference.json']}
source = read(source_path)
model = load(ROOT / 'model/tcp-output-schedule.json')
witness = read(HERE / 'witness.json')
machine, audit = replayer.replay_schedule(model, source, witness)
assert [x['source_step'] for x in audit if x['kind'] == 'source'] == list(range(len(source['steps'])))
summary = read(capture_dir / 'report.json')['summary']
assert summary['commands'] == len(source['steps']) == 7
assert summary['written_bytes'] == summary['acknowledged_bytes'] == 8
expected = control_packets(machine, source)
replay = crosscheck_trace(model, machine.trace, HERE / 'symbolic')
assert replay['status'] == 'match'
program = 'import sys,z3;s=z3.Solver();s.set(timeout=10000);s.add(z3.parse_smt2_file(sys.argv[1]));print(s.check())'
command = [sys.executable, '-c', program, str(HERE / 'symbolic/path.smt2')]
process = subprocess.run(command, capture_output=True, text=True, timeout=20)
assert process.returncode == 0 and process.stdout.strip() == 'sat', process.stderr
observed, metadata = normalize(capture_dir / 'capture.pcap', read(ROOT / 'packet-profile.json'),
                               expected, origin='external_capture', checksum_policy='strict', projection='tcp-connection-v1')
assert len(expected) == len(observed) == 9
difference = compare(expected, observed, tolerance_ms=0, projection='tcp-connection-v1')
assert difference['status'] == 'match'
negatives = []
for field, value in [('payload', [128, 0]), ('seq', 1002), ('time_ms', 22)]:
    altered = copy.deepcopy(observed)
    altered[3][field] = value
    answer = compare(expected, altered, tolerance_ms=0, projection='tcp-connection-v1')
    assert answer['status'] == 'mismatch'
    negatives.append(dict(field=field, comparison='mismatch'))
alternative = copy.deepcopy(witness)
choices = [x for x in alternative['steps'] if x.get('event') == 'choice.segment']
choices[0]['fields']['count'] = 1
choices[1]['fields']['count'] = 3
other_machine, _ = replayer.replay_schedule(model, source, alternative)
answer = compare(control_packets(other_machine, source), observed, tolerance_ms=0, projection='tcp-connection-v1')
assert answer['status'] == 'mismatch'
negatives.append(dict(candidate='valid_1_plus_3_final_state_matches', comparison='mismatch'))
assert {n: digest(capture_dir / n) for n in legacy_hashes} == legacy_hashes
write(HERE / 'audit.json', audit)
write(HERE / 'trace.json', machine.trace)
write(HERE / 'expected.json', expected)
write(HERE / 'observed.json', observed)
write(HERE / 'metadata.json', metadata)
write(HERE / 'difference.json', difference)
result = dict(status='matched_finite_same_input_full_capture_witness', source_steps=7, choice_steps=4,
              captured_packets=9, cutoff_applied=False, tolerance_ms=0,
              scope='existence of an explicit IR schedule for all fixed external inputs and the whole observed projection; not actual hidden C call causality or universal refinement',
              source_path=str(source_path.relative_to(ROOT)), source_sha256=digest(source_path),
              original_verification=legacy_verification, original_comparison='mismatch_preserved',
              original_hashes=legacy_hashes, model_semantic_sha256=model_hash(model),
              replayer_source_sha256=digest(ROOT / 'tools/replay_schedule.py'),
              independent_full_byte_query='sat', query_command=command,
              negative_variants=negatives, final_source_contract='unchanged_and_satisfied',
              new_independent_implementation_execution=False, linux_execution=False, full_stack_complete=False,
              file_hashes={n: digest(HERE / n) for n in ['check.py', 'witness.json', 'audit.json',
                  'trace.json', 'expected.json', 'observed.json', 'metadata.json', 'difference.json',
                  'symbolic/path.smt2', 'symbolic/result.json']})
write(HERE / 'result.json', result)
print(json.dumps({k: result[k] for k in ['status', 'source_steps', 'choice_steps', 'captured_packets',
                                        'original_comparison', 'negative_variants']}))

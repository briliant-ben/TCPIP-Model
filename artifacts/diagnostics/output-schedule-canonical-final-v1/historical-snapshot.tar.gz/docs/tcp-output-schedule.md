# 有界同输入完整抓包调度见证

本overlay将公开app.transmit解释为同毫秒发送机会：原数据发送规则保留元数据／idle前缀初始化但不立即移动队列、发数据或启动空RTO。真正的数据动作继续只由父choice.segment执行，必须有公开flush或原有效pure ACK规则授予的机会，且时刻严格等于机会时刻。其他外部／timer事件关闭机会；同一时刻可有多个受MSS／队列／窗口／cwnd预算约束的选择。不是修改原canonical模型，其原严格Difference保持。

参考RFC9293 August2022 §§3.7、3.9.1.2、3.10.7.4建立有限建模解释。TCP应用调用不决定segment边界，处理有效ACK后可能恢复输出；此policy不声称覆盖全部Nagle/SWS或拥塞算法。父自动LT／fast／控制输出保留。该层不改变RTO默认值／量化，不为2750ms差异增加时钟容差。所有机会、期限、guard、计数和动作在IR中，宿主验证器没有TCP协议逻辑。

通用tools/replay_schedule.py按source_step依次且各一次消费实际源场景，插入的事件只能是模型声明的application-origin choice.*，其实际权限由IR guard裁决。源字段／时刻／初值不由见证覆盖；禁止重复、遗漏、重排源步骤或伪造network/application输入。暂拒绝settle_ms和inline expect_trace源契约，不静默省略。最终源state、variables和timers契约仍须满足。trace范围审计记录每个源事件／选择引起的全部模型事件，包含自动timer处理。

完整PCAP比较使用原解析器、checksum、顺序及0ms投影，逐包数据不能重排／合并／改时刻。有限成功见证只表示：在此声明policy、同一完整外部输入与终态约束下存在匹配整个观察窗口的模型执行。相同毫秒中实际隐藏C调用归属不能由PCAP唯一推断；这是存在性事件对齐，不是实际内部causality证明或通用实现精化。单个失败候选也不证明不存在其他见证。

范围仍为SMSS4／队列16、已有connection/recovery继承链；首个独立目标是既有四字节窗口发送实验的全部输入／抓包。旧完整Difference和raw capture保持哈希绑定。未注册suite，主unknown保留；完整TCP、通用字节／时间／翻译对应、Nagle/SWS、Linux及后续协议仍待完成。

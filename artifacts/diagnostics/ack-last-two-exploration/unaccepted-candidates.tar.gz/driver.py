from pathlib import Path
import sys,json,tarfile,hashlib
sys.path.insert(0,str(Path('formal').resolve()))
import conditional_ssa as c
import modular_piecewise as p
root=Path('/tmp/ack-last-two-exploration');root.mkdir()
parsed={}
manifest=json.loads(Path('artifacts/sent-ledger-single-target-unknown/members.json').read_text())
with tarfile.open('artifacts/sent-ledger-single-target-unknown/exact-single-disjunct-attempt.tar.gz')as stream:
 for i in range(368):
  name=f'group-{i:03}.smt2';raw=stream.extractfile(name).read()
  if hashlib.sha256(raw).hexdigest()!=manifest[name]:raise ValueError('Wrong raw source')
  parsed[i]=list(c.z3.parse_smt2_string(raw.decode()))
rows=[]
for i in (295,296):
 directory=root/f'group-{i:03}';directory.mkdir();source=directory/'augmented.smt2'
 source.write_text(c.script(parsed[i]+[c.z3.Not(parsed[j][-1])for j in range(368)if j not in (295,296)]))
 p.produce(source,directory/'modulo');p.verify(directory/'modulo',source)
 answer=c.cli(directory/'modulo/normalized.smt2',directory/'query.log')
 rows.append(dict(target=i,query=answer,accepted_original_closure=False));print(json.dumps(rows[-1]),flush=True)
 c.write(root/'result.json',dict(status='unaccepted_exploration_only',rows=rows,scope='includes15 unaccepted head candidate facts; no original query closure'))

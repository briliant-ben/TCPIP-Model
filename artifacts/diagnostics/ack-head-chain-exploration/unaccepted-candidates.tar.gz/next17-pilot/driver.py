"""Exploration only; newly proved conclusions select next checked DAG nodes."""
from pathlib import Path
import hashlib,json,sys,tarfile
sys.path.insert(0,str(Path('formal').resolve()))
import conditional_ssa as c
import modular_piecewise as p
index=json.loads(Path('artifacts/ack-query-reuse/coverage-index.json').read_text())
remaining=index['remaining_unknown_disjuncts'];proved=sorted(set(range(368))-set(remaining))
root=Path('/tmp/ack-lemma-next17-pilot')
if root.exists():raise ValueError('Fresh output required')
root.mkdir();(root/'driver.py').write_bytes(Path(__file__).read_bytes())
manifest=json.loads(Path('artifacts/sent-ledger-single-target-unknown/members.json').read_text())
parsed={}
with tarfile.open('artifacts/sent-ledger-single-target-unknown/exact-single-disjunct-attempt.tar.gz')as stream:
 for number in range(368):
  name=f'group-{number:03}.smt2';data=stream.extractfile(name).read()
  if hashlib.sha256(data).hexdigest()!=manifest[name]:raise ValueError('Original query changed')
  parsed[number]=list(c.z3.parse_smt2_string(data.decode()))
common=parsed[remaining[0]][:-1]
for terms in parsed.values():
 if len(terms)!=len(common)+1 or any(not a.eq(b)for a,b in zip(common,terms[:-1])):raise ValueError('Different exact contexts')
rows=[]
for number in remaining:
 directory=root/f'group-{number:03}';directory.mkdir();source=directory/'augmented.smt2'
 source.write_text(c.script(parsed[number]+[c.z3.Not(parsed[i][-1])for i in proved]))
 p.produce(source,directory/'modulo');p.verify(directory/'modulo',source)
 answer=c.cli(directory/'modulo/normalized.smt2',directory/'query.log')
 row=dict(target=number,query=answer,added_previously_named_conclusions=len(proved),accepted_original_closure=False)
 rows.append(row);print(json.dumps(row),flush=True)
 c.write(root/'progress.json',dict(status='unaccepted_exploration',rows=rows))
c.write(root/'result.json',dict(status='terminal_unaccepted_exploration',rows=rows,
 scope='candidate selection only; dependencies must be actually replayed before any original query closure'))

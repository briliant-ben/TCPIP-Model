from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('formal').resolve()))
import conditional_ssa as c
index=json.loads(Path('artifacts/ack-query-reuse/coverage-index.json').read_text())
proved=sorted(set(range(368))-set(index['remaining_unknown_disjuncts']))
out=Path('/tmp/ack-next15-core-selection');out.mkdir()
rows=[]
for i in index['remaining_unknown_disjuncts'][2:]:
 path=Path(f'/tmp/ack-lemma-next17-pilot/group-{i:03}/modulo/normalized.smt2')
 terms=c.read_query(path);assert len(terms)==444+len(proved)
 solver=c.z3.Solver();solver.set(timeout=10000)
 for j,t in enumerate(terms):solver.assert_and_track(t,c.z3.Bool(f'clause_{j}'))
 answer=solver.check();deps=[]
 if answer==c.z3.unsat:
  selected=[int(str(x).split('_')[1])for x in solver.unsat_core()]
  deps=[proved[j-444]for j in selected if j>=444]
 row=dict(target=i,query=str(answer),selected_dependencies=sorted(deps),accepted_original_closure=False)
 rows.append(row);c.write(out/'progress.json',rows);print(json.dumps(row),flush=True)
c.write(out/'selection.json',dict(targets=[r['target']for r in rows],dependencies=sorted({d for r in rows for d in r['selected_dependencies']}),rows=rows,scope='candidate selection only; actual checked dependency replay required'))

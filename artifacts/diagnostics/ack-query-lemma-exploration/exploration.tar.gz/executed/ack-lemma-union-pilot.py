from pathlib import Path
import sys,json,tarfile
sys.path.insert(0,str(Path('formal').resolve()))
import modular_piecewise as p
import conditional_ssa as c
rows=[json.loads(line)for line in Path('/tmp/ack-lemma-core-pilot.log').read_text().splitlines()]
ids=sorted({int(item.removeprefix('proof_dependency_'))for row in rows for item in row.get('core',[])})
root=Path('/tmp/ack-lemma-union-pilot');root.mkdir()
c.write(root/'dependencies.json',ids)
with tarfile.open('artifacts/sent-ledger-single-target-unknown/exact-single-disjunct-attempt.tar.gz')as stream:
 parsed={i:list(c.z3.parse_smt2_string(stream.extractfile(f'group-{i:03}.smt2').read().decode()))for i in ids+[292,300]}
for target in (292,300):
 directory=root/str(target);directory.mkdir();source=directory/'augmented.smt2'
 source.write_text(c.script(parsed[target]+[c.z3.Not(parsed[i][-1])for i in ids]))
 p.produce(source,directory/'modulo');p.verify(directory/'modulo',source)
 print(target,len(ids),c.cli(directory/'modulo/normalized.smt2',directory/'query.log'),flush=True)

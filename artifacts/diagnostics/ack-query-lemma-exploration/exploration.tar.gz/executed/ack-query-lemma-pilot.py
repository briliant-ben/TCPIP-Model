"""Exploration only: reusable already-certified conclusions, never new assumptions."""
from pathlib import Path
import json,sys,tarfile
sys.path.insert(0,str(Path('formal').resolve()))
import modular_piecewise as p
import conditional_ssa as c
root=Path('/tmp/ack-query-lemma-pilot')
if root.exists():raise ValueError('Fresh output required')
root.mkdir()
index=json.loads(Path('artifacts/ack-piecewise-remaining68/coverage-index.json').read_text())
unknown=set(index['remaining_unknown_disjuncts']);proved=set(range(368))-unknown
with tarfile.open('artifacts/sent-ledger-single-target-unknown/exact-single-disjunct-attempt.tar.gz')as stream:
 parsed={i:list(c.z3.parse_smt2_string(stream.extractfile(f'group-{i:03}.smt2').read().decode()))for i in range(368)}
for target in (292,295,296,300):
 assert target not in proved
 common=parsed[target][:-1]
 for i in proved:
  if len(parsed[i])!=len(common)+1 or any(not a.eq(b)for a,b in zip(common,parsed[i][:-1])):raise ValueError('Different source context')
 for kind,ids in (('capacity-only',[280]),('all-proved',sorted(proved))):
  directory=root/f'{target}-{kind}';directory.mkdir()
  source=directory/'augmented.smt2'
  source.write_text(c.script(parsed[target]+[c.z3.Not(parsed[i][-1])for i in ids]))
  r=p.produce(source,directory/'modulo');v=p.verify(directory/'modulo',source)
  answer=c.cli(directory/'modulo/normalized.smt2',directory/'query.log')
  print(target,kind,len(ids),answer,flush=True)

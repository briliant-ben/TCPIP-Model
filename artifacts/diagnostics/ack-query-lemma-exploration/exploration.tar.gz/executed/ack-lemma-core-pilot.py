from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path('formal').resolve()))
import conditional_ssa as c
index=json.loads(Path('artifacts/ack-piecewise-remaining68/coverage-index.json').read_text())
ids=sorted(set(range(368))-set(index['remaining_unknown_disjuncts']))
for number in (292,300):
 path=Path(f'/tmp/ack-query-lemma-pilot/{number}-all-proved/modulo/normalized.smt2')
 a=c.read_query(path);assert len(a)==444+len(ids)
 solver=c.z3.Solver();solver.set(timeout=10000);solver.add(*a[:444])
 for i,expr in zip(ids,a[444:]):solver.assert_and_track(expr,c.z3.Bool('proof_dependency_'+str(i)))
 start=time.monotonic();answer=solver.check()
 result=dict(target=number,status=str(answer),seconds=time.monotonic()-start)
 if answer==c.z3.unsat:result['core']=[str(x)for x in solver.unsat_core()]
 print(json.dumps(result),flush=True)

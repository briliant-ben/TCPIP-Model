; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_peer_mac))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 v_0_checksums_enabled)
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_payload))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_udp_zero))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_pseudoheader))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_udp_wire))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_ip_zero))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_ip_wire))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_packet))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= (as seq.empty (Seq (_ BitVec 8))) v_0_pending_packet))
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 (let (($x217 (= due_1_cache due_0_cache)))
(let (($x224 (= due_1_query due_0_query)))
(let (($x215 (= active_1_cache active_0_cache)))
(let (($x223 (= active_1_query active_0_query)))
(let (($x213 (= v_1_pending_packet v_0_pending_packet)))
(let (($x212 (= v_1_ip_checksum v_0_ip_checksum)))
(let (($x211 (= v_1_udp_checksum v_0_udp_checksum)))
(let (($x210 (= v_1_udp_raw_checksum v_0_udp_raw_checksum)))
(let (($x209 (= v_1_ip_length v_0_ip_length)))
(let (($x208 (= v_1_udp_length v_0_udp_length)))
(let (($x207 (= v_1_packet v_0_packet)))
(let (($x206 (= v_1_ip_wire v_0_ip_wire)))
(let (($x205 (= v_1_ip_zero v_0_ip_zero)))
(let (($x204 (= v_1_udp_wire v_0_udp_wire)))
(let (($x203 (= v_1_pseudoheader v_0_pseudoheader)))
(let (($x202 (= v_1_udp_zero v_0_udp_zero)))
(let (($x201 (= v_1_payload v_0_payload)))
(let (($x200 (= v_1_checksums_enabled v_0_checksums_enabled)))
(let (($x199 (= v_1_cache_ttl_ms v_0_cache_ttl_ms)))
(let (($x222 (= v_1_retry_count v_0_retry_count)))
(let (($x197 (= v_1_peer_mac v_0_peer_mac)))
(let (($x636 (= now_1 now_0)))
(let (($x635 (= state_1 state_0)))
(and $x635 $x636 $x197 $x222 $x199 $x200 $x201 $x202 $x203 $x204 $x205 $x206 $x207 $x208 $x209 $x210 $x211 $x212 $x213 $x223 $x215 $x224 $x217)))))))))))))))))))))))))
(check-sat)

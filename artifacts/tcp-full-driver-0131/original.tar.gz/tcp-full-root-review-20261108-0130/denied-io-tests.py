import sys,unittest,fcntl
sys.path.insert(0,'.')
def audit(event,args):
 if event in {'subprocess.Popen','socket.__new__','os.system','os.exec','os.fork','os.posix_spawn'}:raise RuntimeError('HOST_IO_DENIED '+event)
sys.addaudithook(audit)
def denied(*a,**k):raise RuntimeError('HOST_IOCTL_DENIED')
fcntl.ioctl=denied
s=unittest.TestSuite()
for p in ['test_linux_tcp_ipv4_probe.py','test_tcp_ipv4_probe_lifecycle.py','test_tcp_ipv4_capture_contract.py','test_tcp_ipv4_application.py','test_tcp_ipv4_application_port.py','test_tcp_ipv4_full_lifecycle.py']:s.addTests(unittest.defaultTestLoader.discover('tests',pattern=p))
r=unittest.TextTestRunner(verbosity=2).run(s)
raise SystemExit(not r.wasSuccessful())

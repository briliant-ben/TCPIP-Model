import ast,builtins,copy,hashlib,json,resource,struct,sys,traceback
from pathlib import Path
P=Path('/home/blxu/protocol-flow');J=P/'candidates/tcp-ir-coupling-code-20261107-0064';W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';O=J/'validation-0001';O.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_CPU,(240,240));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
sys.path.insert(0,str(W))
from protocol_lab.ir import load,validate,Machine
from protocol_lab.compose.lower_component_state import lower_component_state
from protocol_lab.compose.namespace_component import namespace_component
from protocol_lab.compose.disjoint_union import merge_disjoint_components

def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def pure(path,fixture=False):
 tree=ast.parse(path.read_text());defs={n.name for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)}
 names={'isinstance','str','int','bool','bytes','bytearray','list','dict','set','tuple','len','enumerate','zip','sorted','any','all','range','min','max','sum','next','iter','ValueError','TypeError','KeyError','RuntimeError','AssertionError'}
 methods={'items','keys','values','get','append','extend','add','update','pop','copy','startswith','endswith','setdefault','insert','index','remove'}
 for n in ast.walk(tree):
  need(not isinstance(n,(ast.ClassDef,ast.AsyncFunctionDef,ast.With,ast.AsyncWith,ast.Global,ast.Nonlocal,ast.Try,ast.Lambda)),'unsupported source construct')
  if isinstance(n,ast.Import):need(all(a.name in ({'copy','struct'}if fixture else{'copy'})and a.asname is None for a in n.names),'import not allowed')
  if isinstance(n,ast.ImportFrom):need(not fixture and n.module=='protocol_lab.ir' and all(a.name=='validate' and a.asname is None for a in n.names),'import not allowed')
  if isinstance(n,ast.Name):need(not n.id.startswith('__'),'private runtime access')
  if isinstance(n,ast.Attribute):
   special=(isinstance(n.value,ast.Name)and(n.value.id,n.attr)in{('copy','deepcopy'),('struct','pack'),('struct','unpack'),('bytes','fromhex')})
   need(n.attr in methods or special,'attribute not allowed: '+n.attr)
  if isinstance(n,ast.Call):
   f=n.func
   need((isinstance(f,ast.Name)and f.id in defs|names|({'validate'}if not fixture else set()))or isinstance(f,ast.Attribute),'call not allowed')
  if isinstance(n,(ast.Assign,ast.AnnAssign,ast.AugAssign)):
   ts=n.targets if isinstance(n,ast.Assign)else[n.target]
   need(not any(isinstance(x,ast.Attribute)for t in ts for x in ast.walk(t)),'attribute mutation forbidden')
 for n in tree.body:need(isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Expr)),'module-level executable statement')
 tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
 ns={'__builtins__':{k:getattr(builtins,k)for k in names},'copy':copy,'struct':struct,'validate':validate}
 exec(compile(tree,str(path),'exec'),ns)
 return ns
stage='freeze_fixture'
try:
 fp=J/'independent_fixture/proposals/coupled_oracle.py';mp=J/'implementer/proposals/couple_tcp.py'
 save('status.json',dict(status='running',stage=stage,API_calls=0))
 f=pure(fp,True);tcp=json.loads((W/'spec/tcp-wire-endpoint-oracle.json').read_text());arp=json.loads((W/'spec/arp-endpoint-oracle.json').read_text());old=copy.deepcopy((tcp,arp));cases=f['build_cases'](tcp,arp);need((tcp,arp)==old,'fixture mutated independent inputs')
 save('frozen-independent-fixture.json',cases)
 save('freeze-receipt.json',dict(source_sha256=hashlib.sha256(fp.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256((O/'frozen-independent-fixture.json').read_bytes()).hexdigest(),source_oracle_sha256={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [W/'spec/tcp-wire-endpoint-oracle.json',W/'spec/arp-endpoint-oracle.json']},model_constructed_before_freeze=False,oracle_approved=False))
 stage='restricted_builder_validation';save('status.json',dict(status='running',stage=stage,API_calls=0))
 fn=pure(mp)['couple_tcp'];parts=[namespace_component(lower_component_state(load(W/n),'control','COMPOSED'),prefix)[0]for n,prefix in [('model/ipv4-udp-icmp-endpoint.json','L'),('model/tcp-wire-endpoint.json','T')]];base=merge_disjoint_components(parts,'finite-ipv4-tcp-udp-icmp-arp');frozen=copy.deepcopy(base);m=fn(base);need(base==frozen,'builder mutated input');validate(m)
 save('candidate-model.json',m);save('status.json',dict(status='schema_valid_pending_semantic_review',stage='finished',API_calls=0,rules=len(m['transitions']),variables=len(m['variables']),fixture_source_executed=True,proposal_source_executed=True,generated_model_executed=False,prototype_complete=False))
except Exception as e:
 save('status.json',dict(status='candidate_rejected',stage=stage,error_type=type(e).__name__,error=str(e)[:1800],API_calls=0,prototype_complete=False));(O/'traceback.txt').write_text(traceback.format_exc());raise

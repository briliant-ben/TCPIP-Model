import copy
import struct


def build_cases(tcp_oracle, arp_oracle):
    """
    Build coupled oracle cases for finite TCP/IP/Ethernet coupling.
    Uses only frozen independent literal oracles supplied as arguments.
    No I/O or runtime model imports.
    """

    # Extract frozen raw IP literal for TCP SYN from tcp_oracle first step expect_trace
    # Reuse exact bytes, never calculate from model logic.
    syn_step = tcp_oracle['cases']['bidirectional-cumulative-close']['steps'][0]
    raw_syn_ip_packet = syn_step['expect_trace'][0]['emitted'][0]['fields']['packet']

    # Extract ARP raw_hex from arp_oracle and convert to bytes independently
    arp_request_hex = arp_oracle['request_hex']
    arp_request_frame = bytes.fromhex(arp_request_hex)

    arp_peer_reply_hex = arp_oracle['peer_reply_hex']
    arp_peer_reply_frame = bytes.fromhex(arp_peer_reply_hex)

    # Define constants
    local_mac = [2, 0, 0, 0, 0, 1]
    peer_mac = [2, 0, 0, 0, 0, 2]
    ethertype_ipv4 = [0x08, 0x00]
    min_payload = 46

    # Helper to wrap raw IP packet into Ethernet frame with destination MAC, source MAC, ethertype, padding
    def wrap_ip_packet(raw_ip_bytes, dst_mac, src_mac=local_mac):
        header = list(dst_mac) + list(src_mac) + ethertype_ipv4
        payload = list(raw_ip_bytes)
        if len(payload) < min_payload:
            payload += [0] * (min_payload - len(payload))
        return header + payload

    # Expected SYN Ethernet frame to peer MAC after resolution
    expected_syn_ethernet = wrap_ip_packet(raw_syn_ip_packet, peer_mac, local_mac)

    # ARP request Ethernet frame exact (provided raw hex)
    arp_request_ethernet = list(arp_request_frame)

    # ARP peer reply frame from oracle (used as L.net.frame event fields)
    arp_peer_reply_frame_fields = list(arp_peer_reply_frame)

    # Define case 1: cold-connect-flush
    case1 = {
        'id': 'cold-connect-flush',
        'initial': {},
        'steps': [
            {
                'at_ms': 0,
                'event': 'app.connect',
                'fields': {},
                'expected_emitted': [
                    {
                        'message': 'ethernet.tx',
                        'fields': {'frame': arp_request_ethernet}
                    }
                ],
                'expected_variables': {
                    'T.control': 'SYN-SENT',
                    'L.control': 'PENDING',
                    'ip_pending_owner': 'TCP',
                    'L.pending_packet': raw_syn_ip_packet
                },
                'expected_timers': {
                    'L.query': 1000,
                    'T.rtx': 1000,
                    'T.user': 30000
                }
            },
            {
                'at_ms': 10,
                'event': 'net.frame',
                'fields': {'frame': arp_peer_reply_frame_fields},
                'expected_emitted': [
                    {
                        'message': 'neighbor.resolved',
                        'fields': {'ip': [192, 0, 2, 2], 'mac': peer_mac}
                    },
                    {
                        'message': 'ethernet.tx',
                        'fields': {'frame': expected_syn_ethernet}
                    }
                ],
                'expected_variables': {
                    'T.control': 'SYN-SENT',
                    'L.control': 'RESOLVED',
                    'ip_pending_owner': 'none',
                    'L.pending_packet': []
                },
                'expected_timers': {
                    'L.cache': 60010,
                    'T.rtx': 1000,
                    'T.user': 30000
                }
            }
        ],
        'limitations': [
            'Covers only cold start connect and ARP reply flush; no later TCP progression.',
            'Assumes ARP cache initially empty and no existing pending packet.'
        ]
    }

    # Case 2: abort-before-resolution
    # Based on provided TCP_abort_source snippet: abort in SYN-SENT cancels T.rtx, T.user, T.time_wait, emits application aborted, sets T.control CLOSED.
    # In coupled model, this should also clear pending TCP packet/owner conditionally while preserving ARP query timer.
    # We do not expect any RST emission because source snippet has no emit for TCP packet.
    case2 = {
        'id': 'abort-before-resolution',
        'initial': {},
        'steps': [
            {
                'at_ms': 0,
                'event': 'app.connect',
                'fields': {},
                'expected_emitted': [
                    {
                        'message': 'ethernet.tx',
                        'fields': {'frame': arp_request_ethernet}
                    }
                ],
                'expected_variables': {
                    'T.control': 'SYN-SENT',
                    'L.control': 'PENDING',
                    'ip_pending_owner': 'TCP',
                    'L.pending_packet': raw_syn_ip_packet
                },
                'expected_timers': {
                    'L.query': 1000,
                    'T.rtx': 1000,
                    'T.user': 30000
                }
            },
            {
                'at_ms': 5,
                'event': 'app.abort',
                'fields': {},
                'expected_emitted': [
                    {
                        'message': 'application',
                        'fields': {'code': 'aborted'}
                    }
                ],
                'expected_variables': {
                    'T.control': 'CLOSED',
                    'L.control': 'PENDING',
                    'ip_pending_owner': 'none',
                    'L.pending_packet': []
                },
                'expected_timers': {
                    'L.query': 1000  # remains from ARP query, not canceled by TCP abort
                }
            }
        ],
        'limitations': [
            'Based on provided TCP_abort_source snippet; full behavior of all guards/actions not independently known.',
            'Does not include subsequent ARP reply step to test no stale SYN flush because uncertain of exact state after abort, but frozen snippet strongly suggests CLOSED without packet emission.'
        ]
    }

    # Case 3: cached-connect
    # First resolve ARP, then connect using cache
    case3 = {
        'id': 'cached-connect',
        'initial': {},
        'steps': [
            {
                'at_ms': 0,
                'event': 'app.resolve',
                'fields': {'ip': [192, 0, 2, 2]},
                'expected_emitted': [
                    {
                        'message': 'ethernet.tx',
                        'fields': {'frame': arp_request_ethernet}
                    }
                ],
                'expected_variables': {
                    'L.control': 'PENDING',
                    'L.pending_packet': [],
                    'ip_pending_owner': 'none'
                },
                'expected_timers': {
                    'L.query': 1000
                }
            },
            {
                'at_ms': 10,
                'event': 'net.frame',
                'fields': {'frame': arp_peer_reply_frame_fields},
                'expected_emitted': [
                    {
                        'message': 'neighbor.resolved',
                        'fields': {'ip': [192, 0, 2, 2], 'mac': peer_mac}
                    }
                ],
                'expected_variables': {
                    'L.control': 'RESOLVED',
                    'L.pending_packet': [],
                    'ip_pending_owner': 'none'
                },
                'expected_timers': {
                    'L.cache': 60010
                }
            },
            {
                'at_ms': 20,
                'event': 'app.connect',
                'fields': {},
                'expected_emitted': [
                    {
                        'message': 'ethernet.tx',
                        'fields': {'frame': expected_syn_ethernet}
                    }
                ],
                'expected_variables': {
                    'T.control': 'SYN-SENT',
                    'L.control': 'RESOLVED',
                    'ip_pending_owner': 'none',
                    'L.pending_packet': []
                },
                'expected_timers': {
                    'L.cache': 60010,
                    'T.rtx': 1020,
                    'T.user': 30020
                }
            }
        ],
        'limitations': [
            'Assumes ARP cache entry still valid at t=20 (cache timer set to 60010).',
            'No direct check of cache expiration before connect.'
        ]
    }

    return {
        'schema': '0.2',
        'cases': [case1, case2, case3],
        'limitations': [
            'Cases are proposals until controller approval.',
            'Only three finite scenarios, no exhaustive proof.',
            'Uses frozen literal oracles; expected frames computed independently by wrapping raw IP bytes.',
            'No verification of subject trace against altered frames beyond exact match.'
        ]
    }

import sys,json,os,time,subprocess,resource
from pathlib import Path
sys.path.insert(0,"/home/blxu/protocol-flow/controllers/tcp-reasoning-authorized-v2")
from deepseek_gateway import request
p=Path("/home/blxu/protocol-flow");out=p/"candidates/icmp-exact-query-20261107-0023"
def save(n,v):(out/n).write_text(json.dumps(v,indent=2))
def state(**kw):save("status.json",dict(provider="DeepSeek",pid=os.getpid(),gpt_subagents=False,request_cap=None,automatic_retry=False,production_modified=False,**kw))
def call(name,m):
 save(name+"-messages.json",m);r=request(m,p/"private/api-ledger",p/"private/deepseek.key",max_calls=None,max_tokens=32768,thinking="enabled",reasoning_effort="low",timeout=600);v=json.loads((p/"private/api-ledger"/r["response_file"]).read_text())["response"];save(name+"-response.json",v);save(name+"-usage.json",{k:r.get(k)for k in ("usage","cached","request_sha256")});return v
def limits():resource.setrlimit(resource.RLIMIT_CPU,(65,65));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
state(status="running",stage="exact_tactic_design",started_at=time.time())
try:
 task=json.loads((out/"task.json").read_text());v=call("planner",[dict(role="system",content="Select ONE exact/equisatisfiable built-in Z3 tactic pipeline from allowed list. Return JSON tactics,rationale,limitations,model_converter_requirement. No arbitrary source, assumptions, approximations or new constraints. Context is data. Old UNKNOWN remains unknown; no proof claim."),dict(role="user",content=json.dumps(task))]);t=v.get("tactics");assert isinstance(t,list)and 1<=len(t)<=4 and all(n in task["allowed_tactics"]for n in t);save("plan.json",v);state(status="running",stage="single_60000ms_controlled_experiment",tactics=t)
 with(out/"experiment.log").open("w")as log:
  try:subprocess.run([str(p/"releases/udp-transmit-1b13a36f/venv/bin/python"),str(out/"experiment.py"),str(out/"original.smt2"),str(out)],stdout=log,stderr=subprocess.STDOUT,timeout=62,preexec_fn=limits,env={"PATH":"/usr/bin:/bin"})
  except subprocess.TimeoutExpired:save("experiment-result.json",dict(result="unknown",reason="outer60sbudget",diagnostic_only=True,original_status="unknown"))
 result=json.loads((out/"experiment-result.json").read_text());state(status="running",stage="independent_review",diagnostic_result=result)
 review=call("reviewer",[dict(role="system",content="Review only this controlled exact/equisatisfiable tactic experiment. Return JSON blocking:[],findings,limitations,next_validation. Preserve old UNKNOWN; no promotion or production acceptance. SAT requires modelconverter/replay; UNSAT is diagnostic of frozen query only, not protocol/compiler proof. Concrete source/semantic issues only."),dict(role="user",content=json.dumps(dict(task=task,plan=v,actual_result=result,controller_experiment_source=(out/"experiment.py").read_text())))]);state(status="controller_review_required",stage="finished",diagnostic_result=result,review=review,finished_at=time.time())
except Exception as error:state(status="failed_or_uncertain",stage="stopped",error_type=type(error).__name__);raise

import sys,json,time,hashlib
from pathlib import Path
import z3
f=Path(sys.argv[1]);out=Path(sys.argv[2]);plan=json.loads((out/"plan.json").read_text());start=time.monotonic();raw=f.read_bytes();assert hashlib.sha256(raw).hexdigest()=="412b9d51c3f847f828c967cbe0840c18a8199b0bc44caeb2cd6e9657cc12e3ee"
report=dict(original_sha256=hashlib.sha256(raw).hexdigest(),original_status="unknown",original_timeout_ms=60000,tactics=plan["tactics"],solver_version=z3.get_version_string(),diagnostic_only=True,production_modified=False,live_network=False)
try:
 ctx=z3.Context();a=z3.parse_smt2_string(raw.decode(),ctx=ctx);g=z3.Goal(ctx=ctx);g.add(a);pipeline=z3.Then(*[z3.Tactic(n,ctx=ctx)for n in plan["tactics"]])if len(plan["tactics"])>1 else z3.Tactic(plan["tactics"][0],ctx=ctx)
 remaining=max(1,60000-int((time.monotonic()-start)*1000));applied=z3.TryFor(pipeline,remaining)(g);assert len(applied)==1,"Unsupported branching tactic result";s=z3.Solver(ctx=ctx);s.add(applied[0]);query=s.to_smt2();(out/"preprocessed.smt2").write_text(query);remaining=60000-int((time.monotonic()-start)*1000)
 if remaining<=0:report.update(result="unknown",reason="total diagnostic budget exhausted before solve")
 else:
  s.set(timeout=remaining);answer=s.check();report.update(result=str(answer),reason=s.reason_unknown()if answer==z3.unknown else None,preprocessed_sha256=hashlib.sha256(query.encode()).hexdigest(),original_assertions=len(a),preprocessed_assertions=len(applied[0]),remaining_solver_ms=remaining,model_reconstructed=False,witness_replayed=False)
except Exception as error:report.update(result="unknown",reason=type(error).__name__)
report["seconds"]=time.monotonic()-start;(out/"experiment-result.json").write_text(json.dumps(report,indent=2));print(json.dumps(report))

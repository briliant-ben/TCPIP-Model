from pathlib import Path
import z3,json,re,hashlib,time
p=Path("/home/blxu/protocol-flow/candidates/icmp-exact-query-20261107-0023")
def definition(s):
 start=s.index("(define-funs-rec");level=0
 for end in range(start,len(s)):
  if s[end]=="(":level+=1
  elif s[end]==")":level-=1
  if level==0:return re.findall(r"\(|\)|[^\s()]+",s[start:end+1])
a=(p/"original.smt2").read_text();b=(p/"preprocessed.smt2").read_text();same=definition(a)==definition(b);assert same,"Recursive definition changed"
ctx=z3.Context();s=z3.Solver(ctx=ctx);s.set(timeout=60000);s.add(z3.parse_smt2_string(b,ctx=ctx));start=time.monotonic();r=s.check()
plan=json.loads((p/"plan.json").read_text())["tactics"];ctx2=z3.Context();solver=z3.Then(*[z3.Tactic(n,ctx=ctx2)for n in plan],z3.Tactic("smt",ctx=ctx2)).solver();solver.set(timeout=10000);x=z3.Int("original_x",ctx=ctx2);q=z3.Const("original_bytes",z3.SeqSort(z3.BitVecSort(8,ctx=ctx2)));lit=z3.Concat(z3.Unit(z3.BitVecVal(0,8,ctx=ctx2)),z3.Unit(z3.BitVecVal(255,8,ctx=ctx2)));solver.add(x==7,q==lit);sat=solver.check();assert sat==z3.sat;model=solver.model();converted=model.eval(x).as_long()==7 and z3.is_true(model.eval(q==lit));assert converted
report=dict(recursive_definition_token_equal=same,fresh_context_preprocessed_result=str(r),reparse_seconds=time.monotonic()-start,preprocessed_sha256=hashlib.sha256(b.encode()).hexdigest(),synthetic_sat_model_converter_preserves_int_and_bytes=converted,model_converter_scope="small synthetic satisfiable equations only; actual protocol witness replay still required",original_status="unknown",production_modified=False);(p/"closure-validation.json").write_text(json.dumps(report,indent=2));print(json.dumps(report))

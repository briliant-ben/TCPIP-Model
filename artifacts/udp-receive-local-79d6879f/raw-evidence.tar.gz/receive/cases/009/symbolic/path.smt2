; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x649 (= v_1_disposition "drop_udp_length")))
 (let (($x1666 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x293 (not v_1_require_checksum)))
 (let (($x578 (= 0 state_1)))
 (let (($x1221 (= state_0 0)))
 (and $x1221 (>= 0 now_0) $x578 $x293 $x1666 $x649)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 3 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x28 (seq.unit (_ bv101 8))))
(let ((?x1174 (seq.++ ?x28 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
(let ((?x941 (seq.unit (_ bv104 8))))
(let ((?x460 (seq.unit (_ bv0 8))))
(let ((?x591 (seq.unit (_ bv14 8))))
(let ((?x409 (seq.++ ?x460 (seq.++ ?x591 (seq.++ ?x460 (seq.++ ?x460 (seq.++ ?x941 ?x1174)))))))
(let ((?x1177 (seq.unit (_ bv64 8))))
(let ((?x152 (seq.unit (_ bv156 8))))
(let ((?x22 (seq.unit (_ bv144 8))))
(let ((?x48 (seq.unit (_ bv31 8))))
(let ((?x1042 (seq.unit (_ bv1 8))))
(let ((?x744 (seq.++ ?x1042 (seq.++ ?x48 (seq.++ ?x22 (seq.++ ?x152 (seq.++ ?x1177 ?x409)))))))
(let ((?x87 (seq.unit (_ bv2 8))))
(let ((?x548 (seq.unit (_ bv192 8))))
(let ((?x658 (seq.++ ?x87 (seq.++ ?x87 (seq.++ ?x548 (seq.++ ?x460 (seq.++ ?x87 ?x744)))))))
(let ((?x853 (seq.unit (_ bv200 8))))
(let ((?x806 (seq.unit (_ bv182 8))))
(let ((?x257 (seq.unit (_ bv17 8))))
(let ((?x1754 (seq.++ ?x257 (seq.++ ?x806 (seq.++ ?x853 (seq.++ ?x548 (seq.++ ?x460 ?x658)))))))
(let ((?x996 (seq.++ ?x460 (seq.++ ?x460 (seq.++ ?x1177 (seq.++ ?x460 (seq.++ ?x1177 ?x1754)))))))
(let ((?x1125 (seq.unit (_ bv33 8))))
(let ((?x708 (seq.unit (_ bv69 8))))
(let ((?x778 (seq.++ ?x708 (seq.++ ?x460 (seq.++ ?x460 (seq.++ ?x1125 ?x996))))))
(= input_0_net.packet_packet ?x778)))))))))))))))))))))))))
(check-sat)

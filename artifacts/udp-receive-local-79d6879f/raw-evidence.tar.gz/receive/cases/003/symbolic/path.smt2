; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x1179 (= v_1_disposition "drop_ip_length")))
 (let (($x1069 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x207 (not v_1_require_checksum)))
 (let (($x130 (= 0 state_1)))
 (let (($x302 (= state_0 0)))
 (and $x302 (>= 0 now_0) $x130 $x207 $x1069 $x1179)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 1 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1039 (seq.unit (_ bv101 8))))
(let ((?x774 (seq.++ ?x1039 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
(let ((?x1037 (seq.unit (_ bv104 8))))
(let ((?x1035 (seq.unit (_ bv45 8))))
(let ((?x1033 (seq.unit (_ bv124 8))))
(let ((?x413 (seq.unit (_ bv13 8))))
(let ((?x329 (seq.unit (_ bv0 8))))
(let ((?x1164 (seq.++ ?x329 (seq.++ ?x413 (seq.++ ?x1033 (seq.++ ?x1035 (seq.++ ?x1037 ?x774)))))))
(let ((?x584 (seq.unit (_ bv64 8))))
(let ((?x129 (seq.unit (_ bv156 8))))
(let ((?x124 (seq.unit (_ bv144 8))))
(let ((?x1230 (seq.unit (_ bv31 8))))
(let ((?x551 (seq.unit (_ bv1 8))))
(let ((?x451 (seq.++ ?x551 (seq.++ ?x1230 (seq.++ ?x124 (seq.++ ?x129 (seq.++ ?x584 ?x1164)))))))
(let ((?x548 (seq.unit (_ bv2 8))))
(let ((?x420 (seq.unit (_ bv192 8))))
(let ((?x216 (seq.++ ?x548 (seq.++ ?x548 (seq.++ ?x420 (seq.++ ?x329 (seq.++ ?x548 ?x451)))))))
(let ((?x417 (seq.unit (_ bv199 8))))
(let ((?x378 (seq.unit (_ bv182 8))))
(let ((?x835 (seq.unit (_ bv17 8))))
(let ((?x221 (seq.++ ?x835 (seq.++ ?x378 (seq.++ ?x417 (seq.++ ?x420 (seq.++ ?x329 ?x216)))))))
(let ((?x226 (seq.++ ?x329 (seq.++ ?x329 (seq.++ ?x584 (seq.++ ?x329 (seq.++ ?x584 ?x221)))))))
(let ((?x383 (seq.unit (_ bv34 8))))
(let ((?x327 (seq.unit (_ bv69 8))))
(let ((?x369 (seq.++ ?x327 (seq.++ ?x329 (seq.++ ?x329 (seq.++ ?x383 ?x226))))))
(= input_0_net.packet_packet ?x369)))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x466 (= v_1_disposition "deliver")))
 (let ((?x708 (seq.unit (_ bv128 8))))
 (let ((?x548 (seq.++ ?x708 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x1030 (seq.unit (_ bv0 8))))
 (let ((?x201 (seq.++ ?x1030 ?x548)))
 (let (($x1855 (= v_1_payload ?x201)))
 (let (($x1848 (not v_1_require_checksum)))
 (let (($x1115 (= 0 state_1)))
 (let (($x1179 (= state_0 0)))
 (and $x1179 (>= 0 now_0) $x1115 $x1848 $x1855 $x466)))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x708 (seq.unit (_ bv128 8))))
(let ((?x548 (seq.++ ?x708 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x1030 (seq.unit (_ bv0 8))))
(let ((?x201 (seq.++ ?x1030 ?x548)))
(let ((?x1052 (seq.unit (_ bv119 8))))
(let ((?x871 (seq.unit (_ bv192 8))))
(let ((?x1077 (seq.unit (_ bv13 8))))
(let ((?x858 (seq.unit (_ bv64 8))))
(let ((?x22 (seq.++ ?x858 (seq.++ ?x1030 (seq.++ ?x1077 (seq.++ ?x871 (seq.++ ?x1052 ?x201)))))))
(let ((?x960 (seq.unit (_ bv156 8))))
(let ((?x1003 (seq.unit (_ bv144 8))))
(let ((?x1205 (seq.unit (_ bv31 8))))
(let ((?x1208 (seq.unit (_ bv1 8))))
(let ((?x350 (seq.unit (_ bv2 8))))
(let ((?x925 (seq.++ ?x350 (seq.++ ?x1208 (seq.++ ?x1205 (seq.++ ?x1003 (seq.++ ?x960 ?x22)))))))
(let ((?x1239 (seq.++ ?x1030 (seq.++ ?x350 (seq.++ ?x350 (seq.++ ?x871 (seq.++ ?x1030 ?x925)))))))
(let ((?x1177 (seq.unit (_ bv200 8))))
(let ((?x571 (seq.unit (_ bv182 8))))
(let ((?x721 (seq.unit (_ bv17 8))))
(let ((?x154 (seq.++ ?x858 (seq.++ ?x721 (seq.++ ?x571 (seq.++ ?x1177 (seq.++ ?x871 ?x1239)))))))
(let ((?x157 (seq.unit (_ bv33 8))))
(let ((?x1325 (seq.++ ?x157 (seq.++ ?x1030 (seq.++ ?x1030 (seq.++ ?x858 (seq.++ ?x1030 ?x154)))))))
(let ((?x237 (seq.unit (_ bv69 8))))
(let ((?x325 (seq.++ ?x237 (seq.++ ?x1030 (seq.++ ?x1030 ?x1325)))))
(= input_0_net.packet_packet ?x325))))))))))))))))))))))))))
(check-sat)

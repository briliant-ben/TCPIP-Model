; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x96 (= v_1_disposition "drop_udp_checksum")))
 (let (($x1399 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1398 (not v_1_require_checksum)))
 (let (($x560 (= 0 state_1)))
 (let (($x458 (= state_0 0)))
 (and $x458 (>= 0 now_0) $x560 $x1398 $x1399 $x96)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 5 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x984 (seq.unit (_ bv101 8))))
(let ((?x721 (seq.++ ?x984 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv110 8)))))))
(let ((?x976 (seq.unit (_ bv104 8))))
(let ((?x1132 (seq.unit (_ bv45 8))))
(let ((?x1071 (seq.unit (_ bv124 8))))
(let ((?x934 (seq.unit (_ bv13 8))))
(let ((?x228 (seq.unit (_ bv0 8))))
(let ((?x794 (seq.++ ?x228 (seq.++ ?x934 (seq.++ ?x1071 (seq.++ ?x1132 (seq.++ ?x976 ?x721)))))))
(let ((?x316 (seq.unit (_ bv64 8))))
(let ((?x526 (seq.unit (_ bv156 8))))
(let ((?x38 (seq.unit (_ bv144 8))))
(let ((?x12 (seq.unit (_ bv31 8))))
(let ((?x481 (seq.unit (_ bv1 8))))
(let ((?x814 (seq.++ ?x481 (seq.++ ?x12 (seq.++ ?x38 (seq.++ ?x526 (seq.++ ?x316 ?x794)))))))
(let ((?x480 (seq.unit (_ bv2 8))))
(let ((?x479 (seq.unit (_ bv192 8))))
(let ((?x740 (seq.++ ?x480 (seq.++ ?x480 (seq.++ ?x479 (seq.++ ?x228 (seq.++ ?x480 ?x814)))))))
(let ((?x745 (seq.unit (_ bv200 8))))
(let ((?x771 (seq.unit (_ bv182 8))))
(let ((?x978 (seq.unit (_ bv17 8))))
(let ((?x1265 (seq.++ ?x978 (seq.++ ?x771 (seq.++ ?x745 (seq.++ ?x479 (seq.++ ?x228 ?x740)))))))
(let ((?x676 (seq.++ ?x228 (seq.++ ?x228 (seq.++ ?x316 (seq.++ ?x228 (seq.++ ?x316 ?x1265)))))))
(let ((?x768 (seq.unit (_ bv33 8))))
(let ((?x227 (seq.unit (_ bv69 8))))
(let ((?x714 (seq.++ ?x227 (seq.++ ?x228 (seq.++ ?x228 (seq.++ ?x768 ?x676))))))
(= input_0_net.packet_packet ?x714)))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x571 (= v_1_disposition "drop_udp_length")))
 (let (($x1257 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x435 (not v_1_require_checksum)))
 (let (($x348 (= 0 state_1)))
 (let (($x1033 (= state_0 0)))
 (and $x1033 (>= 0 now_0) $x348 $x435 $x1257 $x571)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 3 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x421 (seq.unit (_ bv101 8))))
(let ((?x480 (seq.++ ?x421 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
(let ((?x396 (seq.unit (_ bv104 8))))
(let ((?x562 (seq.unit (_ bv0 8))))
(let ((?x1502 (seq.unit (_ bv7 8))))
(let ((?x273 (seq.++ ?x562 (seq.++ ?x1502 (seq.++ ?x562 (seq.++ ?x562 (seq.++ ?x396 ?x480)))))))
(let ((?x491 (seq.unit (_ bv64 8))))
(let ((?x49 (seq.unit (_ bv156 8))))
(let ((?x1188 (seq.unit (_ bv144 8))))
(let ((?x89 (seq.unit (_ bv31 8))))
(let ((?x317 (seq.unit (_ bv1 8))))
(let ((?x1029 (seq.++ ?x317 (seq.++ ?x89 (seq.++ ?x1188 (seq.++ ?x49 (seq.++ ?x491 ?x273)))))))
(let ((?x1667 (seq.unit (_ bv2 8))))
(let ((?x1287 (seq.unit (_ bv192 8))))
(let ((?x1200 (seq.++ ?x1667 (seq.++ ?x1667 (seq.++ ?x1287 (seq.++ ?x562 (seq.++ ?x1667 ?x1029)))))))
(let ((?x1501 (seq.unit (_ bv200 8))))
(let ((?x1312 (seq.unit (_ bv182 8))))
(let ((?x492 (seq.unit (_ bv17 8))))
(let ((?x1440 (seq.++ ?x492 (seq.++ ?x1312 (seq.++ ?x1501 (seq.++ ?x1287 (seq.++ ?x562 ?x1200)))))))
(let ((?x205 (seq.++ ?x562 (seq.++ ?x562 (seq.++ ?x491 (seq.++ ?x562 (seq.++ ?x491 ?x1440)))))))
(let ((?x746 (seq.unit (_ bv33 8))))
(let ((?x1335 (seq.unit (_ bv69 8))))
(let ((?x648 (seq.++ ?x1335 (seq.++ ?x562 (seq.++ ?x562 (seq.++ ?x746 ?x205))))))
(= input_0_net.packet_packet ?x648)))))))))))))))))))))))))
(check-sat)

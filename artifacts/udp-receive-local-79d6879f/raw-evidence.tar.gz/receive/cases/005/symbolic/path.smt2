; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x331 (= v_1_disposition "deliver")))
 (let (($x625 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x619 (not v_1_require_checksum)))
 (let (($x299 (= 0 state_1)))
 (let (($x130 (= state_0 0)))
 (and $x130 (>= 0 now_0) $x299 $x619 $x625 $x331)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x807 (seq.unit (_ bv0 8))))
(let ((?x1304 (seq.++ ?x807 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
(let ((?x243 (seq.unit (_ bv64 8))))
(let ((?x942 (seq.unit (_ bv156 8))))
(let ((?x236 (seq.unit (_ bv144 8))))
(let ((?x1400 (seq.unit (_ bv31 8))))
(let ((?x417 (seq.unit (_ bv1 8))))
(let ((?x288 (seq.++ ?x417 (seq.++ ?x1400 (seq.++ ?x236 (seq.++ ?x942 (seq.++ ?x243 ?x1304)))))))
(let ((?x374 (seq.unit (_ bv2 8))))
(let ((?x378 (seq.unit (_ bv192 8))))
(let ((?x511 (seq.++ ?x374 (seq.++ ?x374 (seq.++ ?x378 (seq.++ ?x807 (seq.++ ?x374 ?x288)))))))
(let ((?x1019 (seq.unit (_ bv205 8))))
(let ((?x866 (seq.unit (_ bv182 8))))
(let ((?x67 (seq.unit (_ bv17 8))))
(let ((?x1010 (seq.++ ?x67 (seq.++ ?x866 (seq.++ ?x1019 (seq.++ ?x378 (seq.++ ?x807 ?x511)))))))
(let ((?x642 (seq.++ ?x807 (seq.++ ?x807 (seq.++ ?x243 (seq.++ ?x807 (seq.++ ?x243 ?x1010)))))))
(let ((?x864 (seq.unit (_ bv28 8))))
(let ((?x440 (seq.unit (_ bv69 8))))
(let ((?x1243 (seq.++ ?x440 (seq.++ ?x807 (seq.++ ?x807 (seq.++ ?x864 ?x642))))))
(= input_0_net.packet_packet ?x1243)))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x1032 (= v_1_disposition "drop_ip_checksum")))
 (let (($x1042 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1044 (not v_1_require_checksum)))
 (let (($x458 (= 0 state_1)))
 (let (($x552 (= state_0 0)))
 (and $x552 (>= 0 now_0) $x458 $x1044 $x1042 $x1032)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 2 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x312 (seq.unit (_ bv101 8))))
(let ((?x276 (seq.++ ?x312 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
(let ((?x53 (seq.unit (_ bv104 8))))
(let ((?x263 (seq.unit (_ bv45 8))))
(let ((?x259 (seq.unit (_ bv124 8))))
(let ((?x260 (seq.unit (_ bv13 8))))
(let ((?x545 (seq.unit (_ bv0 8))))
(let ((?x272 (seq.++ ?x545 (seq.++ ?x260 (seq.++ ?x259 (seq.++ ?x263 (seq.++ ?x53 ?x276)))))))
(let ((?x486 (seq.unit (_ bv64 8))))
(let ((?x75 (seq.unit (_ bv156 8))))
(let ((?x74 (seq.unit (_ bv144 8))))
(let ((?x349 (seq.unit (_ bv31 8))))
(let ((?x336 (seq.unit (_ bv1 8))))
(let ((?x323 (seq.++ ?x336 (seq.++ ?x349 (seq.++ ?x74 (seq.++ ?x75 (seq.++ ?x486 ?x272)))))))
(let ((?x306 (seq.unit (_ bv2 8))))
(let ((?x104 (seq.unit (_ bv192 8))))
(let ((?x319 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x104 (seq.++ ?x545 (seq.++ ?x306 ?x323)))))))
(let ((?x481 (seq.unit (_ bv200 8))))
(let ((?x479 (seq.unit (_ bv183 8))))
(let ((?x518 (seq.unit (_ bv17 8))))
(let ((?x390 (seq.++ ?x518 (seq.++ ?x479 (seq.++ ?x481 (seq.++ ?x104 (seq.++ ?x545 ?x319)))))))
(let ((?x430 (seq.++ ?x545 (seq.++ ?x545 (seq.++ ?x486 (seq.++ ?x545 (seq.++ ?x486 ?x390)))))))
(let ((?x477 (seq.unit (_ bv33 8))))
(let ((?x755 (seq.unit (_ bv69 8))))
(let ((?x352 (seq.++ ?x755 (seq.++ ?x545 (seq.++ ?x545 (seq.++ ?x477 ?x430))))))
(= input_0_net.packet_packet ?x352)))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x506 (= v_1_disposition "drop_short")))
 (let (($x728 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x656 (not v_1_require_checksum)))
 (let (($x172 (= 0 state_1)))
 (let (($x496 (= state_0 0)))
 (and $x496 (>= 0 now_0) $x172 $x656 $x728 $x506)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1138 (seq.unit (_ bv64 8))))
(let ((?x1293 (seq.++ ?x1138 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv8 8)) (seq.unit (_ bv192 8)))))))
(let ((?x399 (seq.unit (_ bv156 8))))
(let ((?x882 (seq.unit (_ bv144 8))))
(let ((?x553 (seq.unit (_ bv31 8))))
(let ((?x1059 (seq.unit (_ bv1 8))))
(let ((?x704 (seq.unit (_ bv2 8))))
(let ((?x948 (seq.++ ?x704 (seq.++ ?x1059 (seq.++ ?x553 (seq.++ ?x882 (seq.++ ?x399 ?x1293)))))))
(let ((?x426 (seq.unit (_ bv0 8))))
(let ((?x1207 (seq.unit (_ bv192 8))))
(let ((?x821 (seq.++ ?x426 (seq.++ ?x704 (seq.++ ?x704 (seq.++ ?x1207 (seq.++ ?x426 ?x948)))))))
(let ((?x1287 (seq.unit (_ bv205 8))))
(let ((?x1020 (seq.unit (_ bv182 8))))
(let ((?x316 (seq.unit (_ bv17 8))))
(let ((?x422 (seq.++ ?x1138 (seq.++ ?x316 (seq.++ ?x1020 (seq.++ ?x1287 (seq.++ ?x1207 ?x821)))))))
(let ((?x491 (seq.unit (_ bv28 8))))
(let ((?x932 (seq.++ ?x491 (seq.++ ?x426 (seq.++ ?x426 (seq.++ ?x1138 (seq.++ ?x426 ?x422)))))))
(let ((?x904 (seq.unit (_ bv69 8))))
(let ((?x841 (seq.++ ?x904 (seq.++ ?x426 (seq.++ ?x426 ?x932)))))
(= input_0_net.packet_packet ?x841)))))))))))))))))))))
(check-sat)

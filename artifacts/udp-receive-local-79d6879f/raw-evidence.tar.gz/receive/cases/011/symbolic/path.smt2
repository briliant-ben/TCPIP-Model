; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x637 (= v_1_disposition "deliver")))
 (let ((?x1771 (seq.unit (_ bv5 8))))
 (let ((?x853 (seq.unit (_ bv192 8))))
 (let ((?x1007 (seq.++ ?x853 ?x1771)))
 (let (($x875 (= v_1_payload ?x1007)))
 (let (($x1453 (not v_1_require_checksum)))
 (let (($x612 (= 0 state_1)))
 (let (($x1666 (= state_0 0)))
 (and $x1666 (>= 0 now_0) $x612 $x1453 $x875 $x637))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1448 (seq.unit (_ bv255 8))))
(let ((?x673 (seq.unit (_ bv10 8))))
(let ((?x1100 (seq.++ ?x673 (seq.++ ?x1448 (seq.++ ?x1448 (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv5 8))))))))
(let ((?x610 (seq.unit (_ bv0 8))))
(let ((?x1125 (seq.unit (_ bv64 8))))
(let ((?x1015 (seq.unit (_ bv156 8))))
(let ((?x425 (seq.unit (_ bv144 8))))
(let ((?x1303 (seq.unit (_ bv31 8))))
(let ((?x1227 (seq.++ ?x1303 (seq.++ ?x425 (seq.++ ?x1015 (seq.++ ?x1125 (seq.++ ?x610 ?x1100)))))))
(let ((?x307 (seq.unit (_ bv1 8))))
(let ((?x1749 (seq.unit (_ bv2 8))))
(let ((?x853 (seq.unit (_ bv192 8))))
(let ((?x1483 (seq.++ ?x1749 (seq.++ ?x853 (seq.++ ?x610 (seq.++ ?x1749 (seq.++ ?x307 ?x1227)))))))
(let ((?x1462 (seq.unit (_ bv203 8))))
(let ((?x1427 (seq.unit (_ bv182 8))))
(let ((?x1698 (seq.++ ?x1427 (seq.++ ?x1462 (seq.++ ?x853 (seq.++ ?x610 (seq.++ ?x1749 ?x1483)))))))
(let ((?x852 (seq.unit (_ bv17 8))))
(let ((?x604 (seq.++ ?x610 (seq.++ ?x1125 (seq.++ ?x610 (seq.++ ?x1125 (seq.++ ?x852 ?x1698)))))))
(let ((?x1391 (seq.unit (_ bv30 8))))
(let ((?x237 (seq.unit (_ bv69 8))))
(let ((?x1045 (seq.++ ?x237 (seq.++ ?x610 (seq.++ ?x610 (seq.++ ?x1391 (seq.++ ?x610 ?x604)))))))
(= input_0_net.packet_packet ?x1045)))))))))))))))))))))))
(check-sat)

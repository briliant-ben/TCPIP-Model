; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x269 (= v_1_disposition "deliver")))
 (let ((?x495 (seq.unit (_ bv101 8))))
 (let ((?x502 (seq.++ ?x495 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
 (let ((?x493 (seq.unit (_ bv104 8))))
 (let ((?x503 (seq.++ ?x493 ?x502)))
 (let (($x1374 (= v_1_payload ?x503)))
 (let (($x1368 (not v_1_require_checksum)))
 (let (($x266 (= 0 state_1)))
 (let (($x16 (= state_0 0)))
 (and $x16 (>= 0 now_0) $x266 $x1368 $x1374 $x269)))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x495 (seq.unit (_ bv101 8))))
(let ((?x502 (seq.++ ?x495 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
(let ((?x493 (seq.unit (_ bv104 8))))
(let ((?x503 (seq.++ ?x493 ?x502)))
(let ((?x77 (seq.unit (_ bv0 8))))
(let ((?x491 (seq.unit (_ bv13 8))))
(let ((?x88 (seq.unit (_ bv64 8))))
(let ((?x508 (seq.++ ?x88 (seq.++ ?x77 (seq.++ ?x491 (seq.++ ?x77 (seq.++ ?x77 ?x503)))))))
(let ((?x113 (seq.unit (_ bv156 8))))
(let ((?x111 (seq.unit (_ bv144 8))))
(let ((?x109 (seq.unit (_ bv31 8))))
(let ((?x107 (seq.unit (_ bv1 8))))
(let ((?x105 (seq.unit (_ bv2 8))))
(let ((?x513 (seq.++ ?x105 (seq.++ ?x107 (seq.++ ?x109 (seq.++ ?x111 (seq.++ ?x113 ?x508)))))))
(let ((?x103 (seq.unit (_ bv192 8))))
(let ((?x518 (seq.++ ?x77 (seq.++ ?x105 (seq.++ ?x105 (seq.++ ?x103 (seq.++ ?x77 ?x513)))))))
(let ((?x489 (seq.unit (_ bv200 8))))
(let ((?x487 (seq.unit (_ bv182 8))))
(let ((?x90 (seq.unit (_ bv17 8))))
(let ((?x523 (seq.++ ?x88 (seq.++ ?x90 (seq.++ ?x487 (seq.++ ?x489 (seq.++ ?x103 ?x518)))))))
(let ((?x485 (seq.unit (_ bv33 8))))
(let ((?x528 (seq.++ ?x485 (seq.++ ?x77 (seq.++ ?x77 (seq.++ ?x88 (seq.++ ?x77 ?x523)))))))
(let ((?x75 (seq.unit (_ bv69 8))))
(let ((?x531 (seq.++ ?x75 (seq.++ ?x77 (seq.++ ?x77 ?x528)))))
(= input_0_net.packet_packet ?x531))))))))))))))))))))))))))
(check-sat)

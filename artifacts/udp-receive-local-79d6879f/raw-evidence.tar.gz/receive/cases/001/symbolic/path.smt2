; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_require_checksum () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_disposition () String)
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_require_checksum () Bool)
(declare-fun state_2 () Int)
(declare-fun v_0_require_checksum () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.require_checksum_required () Bool)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x776 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x168 (= 0 state_1)))
 (let (($x107 (= state_0 0)))
 (and $x107 (>= 0 now_0) $x168 v_1_require_checksum $x776 (= v_1_disposition "none"))))))
(assert
 true)
(assert
 (let (($x349 (= v_2_disposition "drop_absent")))
 (let (($x336 (= (as seq.empty (Seq (_ BitVec 8))) v_2_payload)))
 (let (($x306 (= v_2_require_checksum v_1_require_checksum)))
 (let (($x302 (= 0 state_2)))
 (let (($x212 (= state_1 0)))
 (and $x212 v_1_require_checksum $x302 $x306 $x336 $x349)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_require_checksum false))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (= input_0_app.require_checksum_required true))
(assert
 (= 4 choice_1))
(assert
 (= 0 now_2))
(assert
 (let ((?x559 (seq.unit (_ bv101 8))))
(let ((?x566 (seq.++ ?x559 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv108 8)) (seq.unit (_ bv111 8)))))))
(let ((?x557 (seq.unit (_ bv104 8))))
(let ((?x301 (seq.unit (_ bv0 8))))
(let ((?x555 (seq.unit (_ bv13 8))))
(let ((?x580 (seq.++ ?x301 (seq.++ ?x555 (seq.++ ?x301 (seq.++ ?x301 (seq.++ ?x557 ?x566)))))))
(let ((?x16 (seq.unit (_ bv64 8))))
(let ((?x362 (seq.unit (_ bv156 8))))
(let ((?x364 (seq.unit (_ bv144 8))))
(let ((?x356 (seq.unit (_ bv31 8))))
(let ((?x382 (seq.unit (_ bv1 8))))
(let ((?x585 (seq.++ ?x382 (seq.++ ?x356 (seq.++ ?x364 (seq.++ ?x362 (seq.++ ?x16 ?x580)))))))
(let ((?x371 (seq.unit (_ bv2 8))))
(let ((?x377 (seq.unit (_ bv192 8))))
(let ((?x590 (seq.++ ?x371 (seq.++ ?x371 (seq.++ ?x377 (seq.++ ?x301 (seq.++ ?x371 ?x585)))))))
(let ((?x553 (seq.unit (_ bv200 8))))
(let ((?x551 (seq.unit (_ bv182 8))))
(let ((?x420 (seq.unit (_ bv17 8))))
(let ((?x595 (seq.++ ?x420 (seq.++ ?x551 (seq.++ ?x553 (seq.++ ?x377 (seq.++ ?x301 ?x590)))))))
(let ((?x973 (seq.++ ?x301 (seq.++ ?x301 (seq.++ ?x16 (seq.++ ?x301 (seq.++ ?x16 ?x595)))))))
(let ((?x550 (seq.unit (_ bv33 8))))
(let ((?x11 (seq.unit (_ bv69 8))))
(let ((?x545 (seq.++ ?x11 (seq.++ ?x301 (seq.++ ?x301 (seq.++ ?x550 ?x973))))))
(= input_1_net.packet_packet ?x545)))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!2
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!2
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!2
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x32963 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x63494 (= due_1_T.user due_0_T.user)))
 (let (($x63557 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x33115 (= due_1_L.cache due_0_L.cache)))
 (let (($x35625 (= due_1_L.query 1000)))
 (let (($x61 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x32639 (= active_1_T.user active_0_T.user)))
 (let (($x32638 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x33217 (= active_1_L.cache active_0_L.cache)))
 (let (($x30561 (= v_1_T.control "CLOSED")))
 (let (($x64424 (= v_1_T.wire_flags 0)))
 (let (($x35621 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x35620 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x35623 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x35622 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x35624 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x64630 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x64629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x64517 (= v_1_T.take 0)))
 (let (($x64518 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x64478 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x64479 (= v_1_T.snd_wnd 8)))
 (let (($x64595 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x64594 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x34801 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x64502 (= v_1_T.local_window 16)))
 (let (($x64503 (= v_1_T.msl_ms 60000)))
 (let (($x64421 (= v_1_T.user_timeout_ms 30000)))
 (let (($x64422 (= v_1_T.retries 0)))
 (let (($x64450 (= v_1_T.rto_ms 1000)))
 (let (($x64452 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x64427 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x64448 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x64449 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x34784 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x63440 (= v_1_T.irs (_ bv0 32))))
 (let (($x253 (= v_1_T.iss (_ bv1000 32))))
 (let (($x32839 (= v_1_L.control "PENDING")))
 (let (($x65137 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x65136 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x65135 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x65134 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x65133 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x30391 (not v_1_L.rxudp_require_checksum)))
 (let (($x65132 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x2392 (= v_1_L.ip_checksum 0)))
 (let (($x2393 (= v_1_L.udp_checksum 0)))
 (let (($x2394 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2395 (= v_1_L.ip_length 0)))
 (let (($x2396 (= v_1_L.udp_length 0)))
 (let (($x65131 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x65130 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x65129 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x65128 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x65127 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x65126 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x65125 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x35561 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x63632 (= 0 v_1_L.retry_count)))
 (let (($x65124 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x3213 (= 0 state_1)))
 (let (($x63404 (not active_0_T.time_wait)))
 (let (($x65123 (or $x63404 (not (<= due_0_T.time_wait 0)))))
 (let (($x34818 (not active_0_T.user)))
 (let (($x65121 (or $x34818 (not (<= due_0_T.user 0)))))
 (let (($x1243 (not active_0_T.rtx)))
 (let (($x64830 (or $x1243 (not (<= due_0_T.rtx 0)))))
 (let (($x594 (not active_0_L.cache)))
 (let (($x64820 (or $x594 (not (<= due_0_L.cache 0)))))
 (let (($x34816 (not active_0_L.query)))
 (let (($x64593 (or $x34816 (not (<= due_0_L.query 0)))))
 (let (($x63414 (= state_0 0)))
 (and $x63414 (>= 0 now_0) $x64593 $x64820 $x64830 $x65121 $x65123 $x3213 $x65124 $x63632 $x35561 v_1_L.checksums_enabled $x65125 $x65126 $x65127 $x65128 $x65129 $x65130 $x65131 $x2396 $x2395 $x2394 $x2393 $x2392 $x65132 $x30391 $x65133 (= v_1_L.rxudp_disposition "none") $x65134 $x65135 $x65136 $x65137 (= v_1_L.echo_disposition "none") $x32839 $x253 $x63440 $x34784 $x64449 $x64448 $x64427 $x64452 (= v_1_T.tx_flags "S") $x64450 $x64422 v_1_T.active_open $x64421 $x64503 $x64502 $x34801 $x64594 $x64595 $x64479 $x64478 $x64518 $x64517 $x64629 $x64630 $x35624 $x35622 $x35623 $x35620 $x35621 $x64424 (= v_1_T.wire_disposition "none") $x30561 (= v_1_ip_pending_owner "none") active_1_L.query $x33217 $x32638 $x32639 $x61 $x35625 $x33115 $x63557 $x63494 $x32963))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x30259 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x30258 (= due_2_T.user due_1_T.user)))
 (let (($x30257 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x30255 (= due_2_L.query due_1_L.query)))
 (let (($x30254 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x30253 (= active_2_T.user active_1_T.user)))
 (let (($x30252 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x65255 (not active_2_L.query)))
 (let (($x30249 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x30248 (= v_2_T.control v_1_T.control)))
 (let (($x30247 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x30246 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x30245 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x30244 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x30243 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x30242 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x30241 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x30240 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x30239 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x30238 (= v_2_T.take v_1_T.take)))
 (let (($x30237 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x30236 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x30235 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x30234 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x30233 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x30232 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x30231 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x30230 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x30229 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x30228 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x30227 (= v_2_T.retries v_1_T.retries)))
 (let (($x30226 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x30225 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x30224 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x30223 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x30222 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x30221 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x30220 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x30219 (= v_2_T.irs v_1_T.irs)))
 (let (($x30218 (= v_2_T.iss v_1_T.iss)))
 (let (($x30217 (= v_2_L.control "RESOLVED")))
 (let (($x30216 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x30215 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x30214 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x30213 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x30212 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x30211 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x30210 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x30209 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x30208 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x30207 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x30206 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x30205 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x30204 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x30203 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x30202 (= v_2_L.packet v_1_L.packet)))
 (let (($x30201 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x30200 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x30199 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x30198 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x30197 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x30196 (= v_2_L.payload v_1_L.payload)))
 (let (($x30195 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x30194 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x30193 (= 0 v_2_L.retry_count)))
 (let ((?x726 (seq.unit (_ bv0 8))))
 (let ((?x958 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.unit (_ bv2 8))))))))
 (let ((?x63712 (seq.unit (_ bv2 8))))
 (let ((?x959 (seq.++ ?x63712 ?x958)))
 (let (($x65254 (= v_2_L.peer_mac ?x959)))
 (let (($x30191 (= 0 state_2)))
 (let (($x65253 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x64653 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x64672 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x64668 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x64582 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x30160 (seq.len v_1_L.pending_packet)))
 (let (($x30170 (= 0 ?x30160)))
 (let (($x32839 (= v_1_L.control "PENDING")))
 (let (($x2385 (= state_1 0)))
 (and $x2385 $x32839 $x30170 $x64582 $x64668 $x64672 $x64653 $x65253 $x30191 $x65254 $x30193 $x30194 $x30195 $x30196 $x30197 $x30198 $x30199 $x30200 $x30201 $x30202 $x30203 $x30204 $x30205 $x30206 $x30207 $x30208 $x30209 $x30210 $x30211 $x30212 $x30213 $x30214 $x30215 $x30216 $x30217 $x30218 $x30219 $x30220 $x30221 $x30222 $x30223 $x30224 $x30225 $x30226 $x30227 $x30228 $x30229 $x30230 $x30231 $x30232 $x30233 $x30234 $x30235 $x30236 $x30237 $x30238 $x30239 $x30240 $x30241 $x30242 $x30243 $x30244 $x30245 $x30246 $x30247 $x30248 $x30249 $x65255 active_2_L.cache $x30252 $x30253 $x30254 $x30255 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x30257 $x30258 $x30259))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3448 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x2365 (= due_3_T.rtx 1020)))
 (let (($x13 (= due_3_L.cache due_2_L.cache)))
 (let (($x32684 (= due_3_L.query due_2_L.query)))
 (let (($x65115 (not active_3_T.time_wait)))
 (let (($x2555 (= active_3_L.cache active_2_L.cache)))
 (let (($x33122 (= active_3_L.query active_2_L.query)))
 (let (($x32642 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x33165 (= v_3_T.control "SYN-SENT")))
 (let (($x33064 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x65178 (= v_3_T.wire_flags 2)))
 (let ((?x726 (seq.unit (_ bv0 8))))
 (let ((?x2672 (seq.++ ?x726 ?x726)))
 (let ((?x33216 (seq.++ ?x726 (seq.++ ?x726 ?x2672))))
 (let ((?x33154 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x1184 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x63712 (seq.unit (_ bv2 8))))
 (let ((?x33399 (seq.unit (_ bv80 8))))
 (let ((?x64558 (seq.++ ?x726 (seq.++ ?x33399 (seq.++ ?x63712 (seq.++ ?x1184 (seq.++ ?x33154 ?x33216)))))))
 (let ((?x35601 (seq.unit ((_ extract 7 0) v_2_T.iss))))
 (let ((?x65197 (seq.unit ((_ extract 15 8) v_2_T.iss))))
 (let ((?x64713 (seq.++ ?x65197 (seq.++ ?x35601 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 ?x64558)))))))
 (let ((?x35596 (seq.unit ((_ extract 23 16) v_2_T.iss))))
 (let ((?x35587 (seq.unit ((_ extract 31 24) v_2_T.iss))))
 (let ((?x206 (seq.unit (_ bv144 8))))
 (let ((?x205 (seq.unit (_ bv31 8))))
 (let ((?x131 (seq.unit (_ bv64 8))))
 (let ((?x64429 (seq.++ ?x131 (seq.++ ?x205 (seq.++ ?x206 (seq.++ ?x35587 (seq.++ ?x35596 ?x64713)))))))
 (let ((?x32820 (seq.unit (_ bv156 8))))
 (let ((?x64434 (seq.++ ?x32820 ?x64429)))
 (let ((?x64721 (seq.unit (_ bv20 8))))
 (let ((?x32928 (seq.unit (_ bv6 8))))
 (let ((?x64913 (seq.++ ?x63712 (seq.++ ?x726 (seq.++ ?x32928 (seq.++ ?x726 (seq.++ ?x64721 ?x64434)))))))
 (let ((?x1140 (seq.unit (_ bv192 8))))
 (let ((?x370 (seq.unit (_ bv1 8))))
 (let ((?x64918 (seq.++ ?x63712 (seq.++ ?x370 (seq.++ ?x1140 (seq.++ ?x726 (seq.++ ?x63712 ?x64913)))))))
 (let ((?x64921 ((_ ir4_ones_sum16_checksum_instance!2 0) (seq.++ ?x1140 (seq.++ ?x726 ?x64918)))))
 (let ((?x3038 (seq.++ (seq.unit (bvnot ((_ extract 15 8) ?x64921))) (seq.++ (seq.unit (bvnot ((_ extract 7 0) ?x64921))) ?x2672))))
 (let ((?x538 (seq.++ ?x726 (seq.++ ?x33399 (seq.++ ?x63712 (seq.++ ?x1184 (seq.++ ?x33154 ?x3038)))))))
 (let ((?x35650 (seq.++ ?x65197 (seq.++ ?x35601 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 ?x538)))))))
 (let ((?x35655 (seq.++ ?x131 (seq.++ ?x205 (seq.++ ?x206 (seq.++ ?x35587 (seq.++ ?x35596 ?x35650)))))))
 (let ((?x35661 (seq.++ ?x32820 ?x35655)))
 (let ((?x65289 (seq.++ ?x370 (seq.++ ?x1140 (seq.++ ?x726 (seq.++ ?x63712 (seq.++ ?x63712 ?x35661)))))))
 (let ((?x64571 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x1140 (seq.++ ?x726 (seq.++ ?x63712 ?x65289))))))
 (let ((?x64510 (seq.++ ?x726 (seq.++ ?x131 (seq.++ ?x32928 (seq.++ (seq.unit (_ bv182 8)) ?x64571))))))
 (let ((?x64640 (seq.unit (_ bv40 8))))
 (let ((?x64638 (seq.++ ?x726 (seq.++ ?x64640 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x131 ?x64510)))))))
 (let ((?x129 (seq.unit (_ bv69 8))))
 (let (($x65177 (= v_3_T.wire_packet (seq.++ ?x129 (seq.++ ?x726 ?x64638)))))
 (let ((?x33488 (seq.++ ?x63712 (seq.++ ?x370 (seq.++ ?x1140 (seq.++ ?x726 (seq.++ ?x63712 ?x63712)))))))
 (let ((?x369 (seq.++ ?x32928 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x1140 (seq.++ ?x726 ?x33488)))))))
 (let ((?x33157 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x131 (seq.++ ?x726 (seq.++ ?x131 ?x369)))))))
 (let (($x64870 (= v_3_T.wire_ip_zero (seq.++ ?x129 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x64640 ?x33157)))))))
 (let (($x35657 (= v_3_T.wire_tcp ?x35661)))
 (let ((?x65039 (seq.++ ?x63712 (seq.++ ?x63712 (seq.++ ?x726 (seq.++ ?x32928 (seq.++ ?x726 ?x64721)))))))
 (let ((?x65044 (seq.++ ?x726 (seq.++ ?x63712 (seq.++ ?x370 (seq.++ ?x1140 (seq.++ ?x726 ?x65039)))))))
 (let (($x65046 (= v_3_T.wire_pseudo (seq.++ ?x1140 ?x65044))))
 (let (($x64764 (= v_3_T.wire_tcp_zero ?x64434)))
 (let (($x35582 (= (as seq.empty (Seq (_ BitVec 8))) v_3_T.wire_data)))
 (let (($x35451 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x307 (= v_3_T.take v_2_T.take)))
 (let (($x305 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x306 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x2549 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x33244 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x2543 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x2668 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x3208 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x3026 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x2662 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x2563 (= 0 v_3_T.retries)))
 (let (($x33313 (= 1000 v_3_T.rto_ms)))
 (let (($x33391 (= v_3_T.tx_flags "S")))
 (let (($x35579 (= v_3_T.tx_ack (_ bv0 32))))
 (let (($x2592 (= v_3_T.tx_seq v_2_T.iss)))
 (let (($x2591 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x35580 (= v_3_T.snd_nxt (bvadd (_ bv1 32) v_2_T.iss))))
 (let (($x2710 (= v_3_T.snd_una v_2_T.iss)))
 (let (($x33146 (= v_3_T.irs v_2_T.irs)))
 (let (($x32708 (= v_3_T.iss v_2_T.iss)))
 (let (($x35488 (= v_3_L.control v_2_L.control)))
 (let (($x32888 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x63758 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x3212 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x2948 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x3405 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x3404 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x3069 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x2834 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x2833 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x63619 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x63618 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x3586 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x3585 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x3207 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x3206 (= v_3_L.packet v_2_L.packet)))
 (let (($x2858 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x63581 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x63580 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x3278 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x2652 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x63679 (= v_3_L.payload v_2_L.payload)))
 (let (($x2588 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x32620 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x32619 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x33535 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x33199 (= 0 state_3)))
 (let (($x35555 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x65195 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x64553 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x2387 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x65255 (not active_2_L.query)))
 (let (($x64481 (or $x65255 (not (<= due_2_L.query 20)))))
 (let (($x30217 (= v_2_L.control "RESOLVED")))
 (let (($x3152 (= v_2_T.control "CLOSED")))
 (let (($x35643 (= state_2 0)))
 (and $x35643 $x3152 $x30217 $x64481 $x2387 $x64553 $x65195 $x35555 $x33199 $x33535 $x32619 $x32620 $x2588 $x63679 $x2652 $x3278 $x63580 $x63581 $x2858 $x3206 $x3207 $x3585 $x3586 $x63618 $x63619 $x2833 $x2834 $x3069 $x3404 $x3405 $x2948 $x3212 $x63758 $x32888 $x35488 $x32708 $x33146 $x2710 $x35580 $x2591 $x2592 $x35579 $x33391 $x33313 $x2563 v_3_T.active_open $x2662 $x3026 $x3208 $x2668 $x2543 $x33244 $x2549 $x306 $x305 $x307 $x35451 $x35582 $x64764 $x65046 $x35657 $x64870 $x65177 $x65178 $x33064 $x33165 $x32642 $x33122 $x2555 active_3_T.rtx active_3_T.user $x65115 $x32684 $x13 $x2365 (= due_3_T.user (+ 20 v_2_T.user_timeout_ms)) $x3448))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1140 (seq.unit (_ bv192 8))))
 (let ((?x33026 (seq.++ ?x1140 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x33026))))
(assert
 (= 30 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x1140 (seq.unit (_ bv192 8))))
 (let ((?x63680 (seq.++ ?x1140 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x370 (seq.unit (_ bv1 8))))
 (let ((?x726 (seq.unit (_ bv0 8))))
 (let ((?x94271 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x370 ?x63680)))))))
 (let ((?x63712 (seq.unit (_ bv2 8))))
 (let ((?x94276 (seq.++ ?x1140 (seq.++ ?x726 (seq.++ ?x63712 (seq.++ ?x63712 (seq.++ ?x63712 ?x94271)))))))
 (let ((?x94281 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x63712 ?x94276)))))))
 (let ((?x32930 (seq.unit (_ bv4 8))))
 (let ((?x32928 (seq.unit (_ bv6 8))))
 (let ((?x94286 (seq.++ ?x32928 (seq.++ ?x32930 (seq.++ ?x726 (seq.++ ?x63712 (seq.++ ?x63712 ?x94281)))))))
 (let ((?x33329 (seq.unit (_ bv8 8))))
 (let ((?x94291 (seq.++ ?x32928 (seq.++ ?x726 (seq.++ ?x370 (seq.++ ?x33329 (seq.++ ?x726 ?x94286)))))))
 (let ((?x94296 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x63712 (seq.++ ?x33329 ?x94291)))))))
 (let ((?x94301 (seq.++ ?x726 (seq.++ ?x726 (seq.++ ?x370 (seq.++ ?x63712 (seq.++ ?x726 ?x94296)))))))
 (let ((?x94304 (seq.++ ?x63712 (seq.++ ?x726 (seq.++ ?x726 ?x94301)))))
 (= input_1_L.net.frame_frame ?x94304))))))))))))))))))
(assert
 (= 66 choice_2))
(assert
 (= 20 now_3))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x1340 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x63751 (= due_1_T.user 30000)))
 (let (($x63750 (= due_1_T.rtx 1000)))
 (let (($x1337 (= due_1_L.cache due_0_L.cache)))
 (let (($x63749 (= due_1_L.query 1000)))
 (let (($x63748 (not active_1_T.time_wait)))
 (let (($x1332 (= active_1_L.cache active_0_L.cache)))
 (let (($x1330 (= v_1_ip_pending_owner "TCP")))
 (let (($x1329 (= v_1_T.control "SYN-SENT")))
 (let (($x63747 (= v_1_T.wire_flags 2)))
 (let ((?x63655 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2729 (seq.unit (_ bv16 8))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x1139 (seq.unit (_ bv80 8))))
 (let ((?x63660 (seq.++ ?x442 (seq.++ ?x1139 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x2729 ?x63655)))))))
 (let ((?x34454 (seq.unit (_ bv232 8))))
 (let ((?x34452 (seq.unit (_ bv3 8))))
 (let ((?x63665 (seq.++ ?x34452 (seq.++ ?x34454 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x63660)))))))
 (let ((?x744 (seq.unit (_ bv144 8))))
 (let ((?x742 (seq.unit (_ bv31 8))))
 (let ((?x732 (seq.unit (_ bv64 8))))
 (let ((?x63670 (seq.++ ?x732 (seq.++ ?x742 (seq.++ ?x744 (seq.++ ?x442 (seq.++ ?x442 ?x63665)))))))
 (let ((?x746 (seq.unit (_ bv156 8))))
 (let ((?x63671 (seq.++ ?x746 ?x63670)))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x63712 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x63671)))))))
 (let ((?x63716 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63712))))))
 (let ((?x540 (seq.unit (_ bv6 8))))
 (let ((?x63720 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x540 (seq.++ (seq.unit (_ bv182 8)) ?x63716))))))
 (let ((?x2725 (seq.unit (_ bv40 8))))
 (let ((?x63725 (seq.++ ?x442 (seq.++ ?x2725 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x732 ?x63720)))))))
 (let ((?x726 (seq.unit (_ bv69 8))))
 (let ((?x63727 (seq.++ ?x726 (seq.++ ?x442 ?x63725))))
 (let (($x63746 (= v_1_T.wire_packet ?x63727)))
 (let ((?x1202 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x444)))))))
 (let ((?x1207 (seq.++ ?x540 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x440 (seq.++ ?x442 ?x1202)))))))
 (let ((?x1212 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 ?x1207)))))))
 (let (($x63745 (= v_1_T.wire_ip_zero (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x2725 ?x1212)))))))
 (let (($x63744 (= v_1_T.wire_tcp ?x63671)))
 (let ((?x2826 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x540 (seq.++ ?x442 (seq.unit (_ bv20 8))))))))
 (let ((?x3371 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x2826)))))))
 (let (($x63743 (= v_1_T.wire_pseudo (seq.++ ?x440 (seq.++ ?x442 ?x3371)))))
 (let ((?x2945 (seq.++ ?x442 (seq.++ ?x2729 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x442)))))))
 (let ((?x253 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x1139 (seq.++ ?x444 ?x2945)))))))
 (let ((?x3154 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x34452 (seq.++ ?x34454 (seq.++ ?x442 ?x253)))))))
 (let (($x63742 (= v_1_T.wire_tcp_zero (seq.++ ?x746 (seq.++ ?x732 (seq.++ ?x742 (seq.++ ?x744 ?x3154)))))))
 (let (($x63741 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x63740 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3132 (= v_1_T.take 0)))
 (let (($x3133 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3134 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x3135 (= v_1_T.snd_wnd 8)))
 (let (($x63739 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x63738 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x63737 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3303 (= v_1_T.local_window 16)))
 (let (($x3304 (= v_1_T.msl_ms 60000)))
 (let (($x3305 (= v_1_T.user_timeout_ms 30000)))
 (let (($x1308 (= 0 v_1_T.retries)))
 (let (($x1307 (= 1000 v_1_T.rto_ms)))
 (let (($x1306 (= v_1_T.tx_flags "S")))
 (let (($x3308 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x3309 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3310 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x63736 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x3312 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x3313 (= v_1_T.irs (_ bv0 32))))
 (let (($x3259 (= v_1_T.iss (_ bv1000 32))))
 (let (($x1298 (= v_1_L.control "PENDING")))
 (let (($x63733 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x63732 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63731 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63730 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x63729 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x32962 (not v_1_L.rxudp_require_checksum)))
 (let (($x63728 (= v_1_L.pending_packet ?x63727)))
 (let (($x3279 (= v_1_L.ip_checksum 0)))
 (let (($x3280 (= v_1_L.udp_checksum 0)))
 (let (($x2686 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2687 (= v_1_L.ip_length 0)))
 (let (($x2695 (= v_1_L.udp_length 0)))
 (let (($x2722 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x2721 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x2720 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x2719 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x2718 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x2717 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x2716 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x3408 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x1274 (= 0 v_1_L.retry_count)))
 (let (($x2713 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x1272 (= 0 state_1)))
 (let (($x407 (not active_0_T.time_wait)))
 (let (($x2715 (or $x407 (not (<= due_0_T.time_wait 0)))))
 (let (($x405 (not active_0_T.user)))
 (let (($x3059 (or $x405 (not (<= due_0_T.user 0)))))
 (let (($x403 (not active_0_T.rtx)))
 (let (($x3085 (or $x403 (not (<= due_0_T.rtx 0)))))
 (let (($x401 (not active_0_L.cache)))
 (let (($x3066 (or $x401 (not (<= due_0_L.cache 0)))))
 (let (($x399 (not active_0_L.query)))
 (let (($x3120 (or $x399 (not (<= due_0_L.query 0)))))
 (let (($x216 (= state_0 0)))
 (and $x216 (>= 0 now_0) $x3120 $x3066 $x3085 $x3059 $x2715 $x1272 $x2713 $x1274 $x3408 v_1_L.checksums_enabled $x2716 $x2717 $x2718 $x2719 $x2720 $x2721 $x2722 $x2695 $x2687 $x2686 $x3280 $x3279 $x63728 $x32962 $x63729 (= v_1_L.rxudp_disposition "none") $x63730 $x63731 $x63732 $x63733 (= v_1_L.echo_disposition "none") $x1298 $x3259 $x3313 $x3312 $x63736 $x3310 $x3309 $x3308 $x1306 $x1307 $x1308 v_1_T.active_open $x3305 $x3304 $x3303 $x63737 $x63738 $x63739 $x3135 $x3134 $x3133 $x3132 $x63740 $x63741 $x63742 $x63743 $x63744 $x63745 $x63746 $x63747 (= v_1_T.wire_disposition "none") $x1329 $x1330 active_1_L.query $x1332 active_1_T.rtx active_1_T.user $x63748 $x63749 $x1337 $x63750 $x63751 $x1340)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x32827 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x32826 (= due_2_T.user due_1_T.user)))
 (let (($x32825 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x32823 (= due_2_L.query due_1_L.query)))
 (let (($x32822 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x32821 (= active_2_T.user active_1_T.user)))
 (let (($x32820 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x2790 (not active_2_L.query)))
 (let (($x32817 (= v_2_ip_pending_owner "none")))
 (let (($x32816 (= v_2_T.control v_1_T.control)))
 (let (($x32815 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x32814 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x32813 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x32812 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x32811 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x32810 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x32809 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x32808 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x32807 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x32806 (= v_2_T.take v_1_T.take)))
 (let (($x32805 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x32804 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x32803 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x32802 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x32801 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x32800 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x32799 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x32798 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x32797 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x32796 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x32795 (= v_2_T.retries v_1_T.retries)))
 (let (($x32794 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x32793 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x32792 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32791 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32790 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32789 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x32788 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x32787 (= v_2_T.irs v_1_T.irs)))
 (let (($x32786 (= v_2_T.iss v_1_T.iss)))
 (let (($x32785 (= v_2_L.control "RESOLVED")))
 (let (($x32784 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x32783 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x32782 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x32781 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x32780 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x32779 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32778 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32777 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x2789 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x32775 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x32774 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x32773 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x32772 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x32771 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x32770 (= v_2_L.packet v_1_L.packet)))
 (let (($x32769 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x32768 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x32767 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x32766 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32765 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x32764 (= v_2_L.payload v_1_L.payload)))
 (let (($x32763 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x32762 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x32761 (= 0 v_2_L.retry_count)))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x1495 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.unit (_ bv2 8))))))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x1496 (seq.++ ?x444 ?x1495)))
 (let (($x2788 (= v_2_L.peer_mac ?x1496)))
 (let (($x32759 (= 0 state_2)))
 (let (($x63748 (not active_1_T.time_wait)))
 (let (($x2787 (or $x63748 (not (<= due_1_T.time_wait 10)))))
 (let (($x2784 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x2780 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x249 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x3390 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x32716 (seq.len v_1_L.pending_packet)))
 (let (($x32717 (<= 28 ?x32716)))
 (let (($x1298 (= v_1_L.control "PENDING")))
 (let (($x2684 (= state_1 0)))
 (and $x2684 $x1298 $x32717 $x3390 $x249 $x2780 $x2784 $x2787 $x32759 $x2788 $x32761 $x32762 $x32763 $x32764 $x32765 $x32766 $x32767 $x32768 $x32769 $x32770 $x32771 $x32772 $x32773 $x32774 $x32775 $x2789 $x32777 $x32778 $x32779 $x32780 $x32781 $x32782 $x32783 $x32784 $x32785 $x32786 $x32787 $x32788 $x32789 $x32790 $x32791 $x32792 $x32793 $x32794 $x32795 $x32796 $x32797 $x32798 $x32799 $x32800 $x32801 $x32802 $x32803 $x32804 $x32805 $x32806 $x32807 $x32808 $x32809 $x32810 $x32811 $x32812 $x32813 $x32814 $x32815 $x32816 $x32817 $x2790 active_2_L.cache $x32820 $x32821 $x32822 $x32823 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x32825 $x32826 $x32827)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x440 (seq.unit (_ bv192 8))))
(let ((?x594 (seq.++ ?x440 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x514 (seq.unit (_ bv1 8))))
(let ((?x442 (seq.unit (_ bv0 8))))
(let ((?x63407 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x514 ?x594)))))))
(let ((?x444 (seq.unit (_ bv2 8))))
(let ((?x63412 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x444 ?x63407)))))))
(let ((?x63417 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 ?x63412)))))))
(let ((?x542 (seq.unit (_ bv4 8))))
(let ((?x540 (seq.unit (_ bv6 8))))
(let ((?x63422 (seq.++ ?x540 (seq.++ ?x542 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x63417)))))))
(let ((?x538 (seq.unit (_ bv8 8))))
(let ((?x63427 (seq.++ ?x540 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x538 (seq.++ ?x442 ?x63422)))))))
(let ((?x63432 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x538 ?x63427)))))))
(let ((?x63437 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x444 (seq.++ ?x442 ?x63432)))))))
(let ((?x63440 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x442 ?x63437)))))
(= input_1_L.net.frame_frame ?x63440))))))))))))))))))
(check-sat)

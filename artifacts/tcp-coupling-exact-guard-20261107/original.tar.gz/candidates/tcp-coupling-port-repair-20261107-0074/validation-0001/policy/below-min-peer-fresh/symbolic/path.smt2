; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x223550 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x223549 (= due_1_T.user due_0_T.user)))
 (let (($x223548 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x223507 (= due_1_L.cache due_0_L.cache)))
 (let (($x64926 (= due_1_L.query due_0_L.query)))
 (let (($x223506 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x64925 (= active_1_T.user active_0_T.user)))
 (let (($x223508 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x222983 (= active_1_L.cache active_0_L.cache)))
 (let (($x3328 (= active_1_L.query active_0_L.query)))
 (let (($x222981 (= v_1_T.wire_disposition "drop_ip_length")))
 (let (($x67671 (= v_1_T.wire_flags 0)))
 (let (($x5279 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x5278 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x5277 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x5276 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x5275 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x5274 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x5273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x30595 (= v_1_T.take 0)))
 (let (($x129318 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x68074 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x317123 (= v_1_T.snd_wnd 8)))
 (let (($x5272 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x5271 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x5270 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x222998 (= v_1_T.local_window 16)))
 (let (($x348489 (= v_1_T.msl_ms 60000)))
 (let (($x1834 (= v_1_T.user_timeout_ms 30000)))
 (let (($x64792 (= v_1_T.retries 0)))
 (let (($x30664 (= v_1_T.rto_ms 1000)))
 (let (($x223500 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x160679 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x317402 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x160734 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x160719 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x192115 (= v_1_T.irs (_ bv0 32))))
 (let (($x224155 (= v_1_T.iss (_ bv1000 32))))
 (let (($x5269 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x5268 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x5267 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x5266 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x5265 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x5264 (not v_1_L.rxudp_require_checksum)))
 (let (($x5263 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x129025 (= v_1_L.ip_checksum 0)))
 (let (($x223618 (= v_1_L.udp_checksum 0)))
 (let (($x64927 (= v_1_L.udp_raw_checksum 0)))
 (let (($x68035 (= v_1_L.ip_length 0)))
 (let (($x286246 (= v_1_L.udp_length 0)))
 (let (($x5262 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x5261 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x5260 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x5259 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x5258 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x5257 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x5256 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x67684 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x67686 (= v_1_L.retry_count 0)))
 (let (($x5255 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x3208 (= 0 state_1)))
 (let (($x348621 (not active_0_T.time_wait)))
 (let (($x5254 (or $x348621 (not (<= due_0_T.time_wait 0)))))
 (let (($x160618 (not active_0_T.user)))
 (let (($x5251 (or $x160618 (not (<= due_0_T.user 0)))))
 (let (($x223988 (not active_0_T.rtx)))
 (let (($x5248 (or $x223988 (not (<= due_0_T.rtx 0)))))
 (let (($x224309 (not active_0_L.cache)))
 (let (($x5245 (or $x224309 (not (<= due_0_L.cache 0)))))
 (let (($x286326 (not active_0_L.query)))
 (let (($x5242 (or $x286326 (not (<= due_0_L.query 0)))))
 (let (($x951 (= state_0 0)))
 (and $x951 (>= 0 now_0) $x5242 $x5245 $x5248 $x5251 $x5254 $x3208 $x5255 $x67686 $x67684 v_1_L.checksums_enabled $x5256 $x5257 $x5258 $x5259 $x5260 $x5261 $x5262 $x286246 $x68035 $x64927 $x223618 $x129025 $x5263 $x5264 $x5265 (= v_1_L.rxudp_disposition "none") $x5266 $x5267 $x5268 $x5269 (= v_1_L.echo_disposition "none") (= v_1_L.control "EMPTY") $x224155 $x192115 $x160719 $x160734 $x317402 $x160679 $x223500 (= v_1_T.tx_flags "S") $x30664 $x64792 v_1_T.active_open $x1834 $x348489 $x222998 $x5270 $x5271 $x5272 $x317123 $x68074 $x129318 $x30595 $x5273 $x5274 $x5275 $x5276 $x5277 $x5278 $x5279 $x67671 $x222981 (= v_1_T.control "CLOSED") (= v_1_ip_pending_owner "none") $x3328 $x222983 $x223508 $x64925 $x223506 $x64926 $x223507 $x223548 $x223549 $x223550))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 334 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x68129 (seq.unit (_ bv0 8))))
(let ((?x5148 (seq.++ ?x68129 (seq.++ ?x68129 (seq.++ ?x68129 (seq.++ ?x68129 (seq.++ ?x68129 ?x68129)))))))
(let ((?x5144 (seq.unit (_ bv221 8))))
(let ((?x5142 (seq.unit (_ bv72 8))))
(let ((?x5140 (seq.unit (_ bv16 8))))
(let ((?x5153 (seq.++ ?x5140 (seq.++ ?x5142 (seq.++ ?x5144 (seq.++ ?x68129 (seq.++ ?x68129 ?x5148)))))))
(let ((?x5138 (seq.unit (_ bv18 8))))
(let ((?x5136 (seq.unit (_ bv80 8))))
(let ((?x5134 (seq.unit (_ bv233 8))))
(let ((?x5132 (seq.unit (_ bv3 8))))
(let ((?x5158 (seq.++ ?x5132 (seq.++ ?x5134 (seq.++ ?x5136 (seq.++ ?x5138 (seq.++ ?x68129 ?x5153)))))))
(let ((?x5130 (seq.unit (_ bv40 8))))
(let ((?x5128 (seq.unit (_ bv35 8))))
(let ((?x5163 (seq.++ ?x68129 (seq.++ ?x5128 (seq.++ ?x5130 (seq.++ ?x68129 (seq.++ ?x68129 ?x5158)))))))
(let ((?x31055 (seq.unit (_ bv64 8))))
(let ((?x377875 (seq.unit (_ bv156 8))))
(let ((?x255161 (seq.unit (_ bv144 8))))
(let ((?x129263 (seq.unit (_ bv31 8))))
(let ((?x5168 (seq.++ ?x129263 (seq.++ ?x255161 (seq.++ ?x377875 (seq.++ ?x31055 (seq.++ ?x68129 ?x5163)))))))
(let ((?x377653 (seq.unit (_ bv1 8))))
(let ((?x159913 (seq.unit (_ bv2 8))))
(let ((?x317341 (seq.unit (_ bv192 8))))
(let ((?x5176 (seq.++ ?x159913 (seq.++ ?x317341 (seq.++ ?x68129 (seq.++ ?x159913 (seq.++ ?x377653 ?x5168)))))))
(let ((?x5126 (seq.unit (_ bv205 8))))
(let ((?x5124 (seq.unit (_ bv182 8))))
(let ((?x5181 (seq.++ ?x5124 (seq.++ ?x5126 (seq.++ ?x317341 (seq.++ ?x68129 (seq.++ ?x159913 ?x5176)))))))
(let ((?x377758 (seq.unit (_ bv6 8))))
(let ((?x5186 (seq.++ ?x68129 (seq.++ ?x31055 (seq.++ ?x68129 (seq.++ ?x31055 (seq.++ ?x377758 ?x5181)))))))
(let ((?x5122 (seq.unit (_ bv39 8))))
(let ((?x30471 (seq.unit (_ bv69 8))))
(let ((?x5191 (seq.++ ?x30471 (seq.++ ?x68129 (seq.++ ?x68129 (seq.++ ?x5122 (seq.++ ?x68129 ?x5186)))))))
(let ((?x377756 (seq.unit (_ bv8 8))))
(let ((?x5196 (seq.++ ?x68129 (seq.++ ?x68129 (seq.++ ?x159913 (seq.++ ?x377756 (seq.++ ?x68129 ?x5191)))))))
(let ((?x5201 (seq.++ ?x68129 (seq.++ ?x377653 (seq.++ ?x159913 (seq.++ ?x68129 (seq.++ ?x68129 ?x5196)))))))
(let ((?x5205 (seq.++ ?x159913 (seq.++ ?x68129 (seq.++ ?x68129 (seq.++ ?x68129 ?x5201))))))
(= input_0_L.net.frame_frame ?x5205)))))))))))))))))))))))))))))))))))))
(check-sat)

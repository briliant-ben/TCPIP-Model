import ast,builtins,copy,hashlib,json,resource,struct,sys,traceback
from pathlib import Path
P=Path('/home/blxu/protocol-flow');J=P/'candidates/tcp-coupling-port-repair-20261107-0074';W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';O=J/'validation-0001';O.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_CPU,(240,240));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
sys.path.insert(0,str(W))
from protocol_lab.ir import load,validate,Machine
from protocol_lab.compose.lower_component_state import lower_component_state
from protocol_lab.compose.namespace_component import namespace_component
from protocol_lab.compose.disjoint_union import merge_disjoint_components

def save(n,v):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def pure(path,fixture=False):
 tree=ast.parse(path.read_text());defs={n.name for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)}
 names={'isinstance','str','int','bool','bytes','bytearray','list','dict','set','tuple','len','enumerate','zip','sorted','any','all','range','min','max','sum','next','iter','ValueError','TypeError','KeyError','RuntimeError','AssertionError'}
 methods={'items','keys','values','get','append','extend','add','update','pop','copy','startswith','endswith','setdefault','insert','index','remove'}
 for n in ast.walk(tree):
  need(not isinstance(n,(ast.ClassDef,ast.AsyncFunctionDef,ast.With,ast.AsyncWith,ast.Global,ast.Nonlocal,ast.Try,ast.Lambda)),'unsupported source construct')
  if isinstance(n,ast.Import):need(all(a.name in ({'copy','struct'}if fixture else{'copy'})and a.asname is None for a in n.names),'import not allowed')
  if isinstance(n,ast.ImportFrom):need(not fixture and n.module=='protocol_lab.ir' and all(a.name=='validate' and a.asname is None for a in n.names),'import not allowed')
  if isinstance(n,ast.Name):need(not n.id.startswith('__'),'private runtime access')
  if isinstance(n,ast.Attribute):
   special=(isinstance(n.value,ast.Name)and(n.value.id,n.attr)in{('copy','deepcopy'),('struct','pack'),('struct','unpack'),('bytes','fromhex')})
   need(n.attr in methods or special,'attribute not allowed: '+n.attr)
  if isinstance(n,ast.Call):
   f=n.func
   need((isinstance(f,ast.Name)and f.id in defs|names|({'validate'}if not fixture else set()))or isinstance(f,ast.Attribute),'call not allowed')
  if isinstance(n,(ast.Assign,ast.AnnAssign,ast.AugAssign)):
   ts=n.targets if isinstance(n,ast.Assign)else[n.target]
   need(not any(isinstance(x,ast.Attribute)and isinstance(x.ctx,ast.Store)for t in ts for x in ast.walk(t)),'attribute mutation forbidden')
 for n in tree.body:need(isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Expr)),'module-level executable statement')
 tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
 ns={'__builtins__':{k:getattr(builtins,k)for k in names},'copy':copy,'struct':struct,'validate':validate}
 exec(compile(tree,str(path),'exec'),ns)
 return ns
stage='freeze_fixture'
try:
 fp=P/'candidates/tcp-ir-coupling-code-20261107-0064/independent_fixture/proposals/coupled_oracle.py';mp=J/'round-1/couple_tcp.py'
 save('status.json',dict(status='running',stage=stage,API_calls=0))
 f=pure(fp,True);tcp=json.loads((W/'spec/tcp-wire-endpoint-oracle.json').read_text());arp=json.loads((W/'spec/arp-endpoint-oracle.json').read_text());old=copy.deepcopy((tcp,arp));cases=f['build_cases'](tcp,arp);need((tcp,arp)==old,'fixture mutated independent inputs')
 save('frozen-independent-fixture.json',cases)
 save('freeze-receipt.json',dict(source_sha256=hashlib.sha256(fp.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256((O/'frozen-independent-fixture.json').read_bytes()).hexdigest(),source_oracle_sha256={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [W/'spec/tcp-wire-endpoint-oracle.json',W/'spec/arp-endpoint-oracle.json']},model_constructed_before_freeze=False,oracle_approved=False))
 # Deterministic interface qualification under the controller's pre-existing contract.
 event_map={'app.connect':'T.app.connect','app.abort':'T.app.abort','app.resolve':'L.app.resolve','net.frame':'L.net.frame'}
 message_map={'ethernet.tx':'L.ethernet.tx','neighbor.resolved':'L.neighbor.resolved','application':'T.application'}
 qualified=copy.deepcopy(cases)
 for c in qualified['cases']:
  for step in c['steps']:
   need(step['event'] in event_map,'unexpected fixture event');step['event']=event_map[step['event']]
   for emitted in step['expected_emitted']:
    need(emitted['message'] in message_map,'unexpected fixture message');emitted['message']=message_map[emitted['message']]
    if emitted['message']=='L.ethernet.tx':
     frame=emitted['fields']['frame']
     if frame[12:14]==[8,0]:
      raw=tcp['cases']['bidirectional-cumulative-close']['steps'][0]['expect_trace'][0]['emitted'][0]['fields']['packet']
      need(frame==[2,0,0,0,0,2,2,0,0,0,0,1,8,0]+raw+[0]*6,'literal SYN Ethernet bytes differ from independent source')
     else:need(frame==list(bytes.fromhex(arp['request_hex'])),'literal ARP request differs')
 # Independent integration projection: retain every original TCP literal byte/time.
 original=tcp['cases']['bidirectional-cumulative-close']
 need(original['steps'][0]['at_ms']==0 and original['steps'][1]['at_ms']>1,'unexpected frozen TCP prelude time')
 full={'id':'resolved-bidirectional-cumulative-close','initial':{'T.'+k:v for k,v in original.get('initial',{}).items()},'steps':[]}
 cold=copy.deepcopy(qualified['cases'][0])
 full['steps'].append(copy.deepcopy(cold['steps'][0]))
 reply=copy.deepcopy(cold['steps'][1]);reply['at_ms']=1;reply['expected_timers']['L.cache']=60001;full['steps'].append(reply)
 for old_step in original['steps'][1:]:
  step={'at_ms':old_step['at_ms'],'event':('L.net.frame' if old_step['event']=='net.packet' else 'T.'+old_step['event']),'fields':copy.deepcopy(old_step.get('fields',{})),'expected_variables':{},'expected_emitted':[]}
  if old_step['event']=='net.packet':
   raw=old_step['fields']['packet'];step['fields']={'frame':[2,0,0,0,0,1,2,0,0,0,0,2,8,0]+raw+[0]*max(0,46-len(raw))}
  need(len(old_step['expect_trace'])==1 and old_step['expect_trace'][0]['at_ms']==old_step['at_ms'],'unexpected frozen timer trace')
  for emitted in old_step['expect_trace'][0]['emitted']:
   if emitted['message']=='ipv4.tx':
    raw=emitted['fields']['packet'];step['expected_emitted'].append({'message':'L.ethernet.tx','fields':{'frame':[2,0,0,0,0,2,2,0,0,0,0,1,8,0]+raw+[0]*max(0,46-len(raw))}})
   else:step['expected_emitted'].append({'message':'T.'+emitted['message'],'fields':copy.deepcopy(emitted['fields'])})
  full['steps'].append(step)
 final=full['steps'][-1];final['expected_variables']={'T.'+k:v for k,v in original['expect'].get('variables',{}).items()};final['expected_variables'].update({'T.control':original['expect']['state'],'L.control':'RESOLVED','ip_pending_owner':'none','L.pending_packet':[]});final['expected_timers']={'T.'+k:v for k,v in original['expect']['timers'].items()};final['expected_timers']['L.cache']=60001
 qualified['cases'].append(full)
 save('qualified-independent-fixture.json',qualified)
 need(hashlib.sha256((O/'qualified-independent-fixture.json').read_bytes()).hexdigest()=='8f66ce0af1f88072d2de8990dd55b584edad299abc9b5baf55bcf00e6bedb919','pre-frozen independent fixture hash differs')
 save('qualification-receipt.json',dict(event_map=event_map,message_map=message_map,byte_values_and_expectations_unchanged=True,root_contract='0064/controller-contract.txt',qualified_sha256=hashlib.sha256((O/'qualified-independent-fixture.json').read_bytes()).hexdigest(),approved_scope='three finite initial cases plus independent frozen bidirectional TCP projection; old bytes/time unchanged, added ARP reply at1ms',model_constructed_before_qualification=False))
 policy_file=P/'incoming/tcp-coupling-policy-0069-prefreeze/frozen-policy-cases.json'
 need(hashlib.sha256(policy_file.read_bytes()).hexdigest()=='d453eeb3c8b859af407f6751611faf2e668c66bdfca296e92b8b2445db907be7','frozen policy fixture hash differs')
 policy=json.loads(policy_file.read_text());save('frozen-policy-cases.json',policy)
 stage='restricted_builder_validation';save('status.json',dict(status='running',stage=stage,API_calls=0))
 fn=pure(mp)['couple_tcp'];parts=[namespace_component(lower_component_state(load(W/n),'control','COMPOSED'),prefix)[0]for n,prefix in [('model/ipv4-udp-icmp-endpoint.json','L'),('model/tcp-wire-endpoint.json','T')]];base=merge_disjoint_components(parts,'finite-ipv4-tcp-udp-icmp-arp');frozen=copy.deepcopy(base);m=fn(base);need(base==frozen,'builder mutated input');validate(m)
 save('candidate-model.json',m)
 # API rejections are not protocol tests; they ensure unsupported source shapes are explicit.
 stage='defensive_source_shapes';save('status.json',dict(status='running',stage=stage,API_calls=0))
 for mode in ['missing_packet','extra_packet_field','unexpected_pending_expression']:
  invalid=copy.deepcopy(base);found=False
  for tr in invalid['transitions']:
   for act in tr['actions']:
    if mode in ['missing_packet','extra_packet_field']and act.get('emit',{}).get('message')=='T.ipv4.tx':
     if mode=='missing_packet':act['emit']['fields'].pop('packet')
     else:act['emit']['fields']['unexpected']={'bytes':[]}
     found=True;break
    if mode=='unexpected_pending_expression'and tr['id'].startswith('L.')and act.get('set',{}).get('var')=='L.pending_packet':
     act['set']['value']={'op':'bytes_concat','args':[{'bytes':[]},{'bytes':[]}]};found=True;break
   if found:break
  need(found,'missing defensive source target');old_input=copy.deepcopy(invalid)
  try:fn(invalid)
  except ValueError:pass
  else:raise ValueError('unsupported source shape silently accepted: '+mode)
  need(invalid==old_input,'invalid source input mutated')
 save('defensive-source-shapes.json',dict(rejected=3,input_unchanged=True))
 # Traceability of newly coupled TCP rules is part of the existing controller contract.
 def link_interaction(x):
  if isinstance(x,dict):
   if isinstance(x.get('var'),str)and(x['var'].startswith('L.')or x['var']=='ip_pending_owner'):return True
   if x.get('message')=='L.ethernet.tx':return True
   return any(link_interaction(v)for v in x.values())
  if isinstance(x,list):return any(link_interaction(v)for v in x)
  return False
 affected=[tr['id']for tr in m['transitions']if tr['id'].startswith('T.')and(tr['event']=='L.net.frame'or link_interaction(tr['guard'])or link_interaction(tr['actions']))]
 need(len(affected)>=147,'traceability selector lost original TCP emission family')
 need(all(any(tr['event']==event and tr['id']in affected for tr in m['transitions'])for event in ['T.app.connect','T.app.transmit','T.timer.rtx']),'traceability selector vacuous for application/timer coupling')
 need(all('CROSS-IP-LINK'in tr['requirements']for tr in m['transitions']if tr['id']in affected),'coupled TCP rule missing CROSS-IP-LINK source')
 save('coupled-source-bindings.json',dict(affected_rule_ids=affected,all_cross_link=True))
 from protocol_lab.ir import Uncovered
 stage='reference_policy_contracts';save('status.json',dict(status='running',stage=stage,API_calls=0))
 policy_refs=[]
 for case in policy['cases']:
  machine=Machine(m);steps=[]
  if case['context']=='pending_tcp':
   machine.dispatch('T.app.connect',{},0);cold=qualified['cases'][0]['steps'][0]
   need(machine.trace[-1]['emitted']==cold['expected_emitted'],'warm policy prelude bytes differ')
   for k,v in cold['expected_variables'].items():need(machine.values.get(k)==v,'warm policy prelude variable differs')
   need(machine.timers==cold['expected_timers'],'warm policy prelude timers differ')
   steps.append(dict(at_ms=0,event='T.app.connect',fields={}))
  before=machine.snapshot();before_trace=copy.deepcopy(machine.trace);before_now=machine.now_ms
  try:machine.dispatch(case['event'],case['fields'],case['at_ms']);actual=machine.values['T.wire_disposition']
  except Uncovered:actual='model_gap'
  need(actual==case['expected'],'independent policy classification differs '+case['id']+':'+str(actual))
  if actual=='model_gap':need(machine.snapshot()==before and machine.trace==before_trace and machine.now_ms==before_now,'model gap did not reject atomically')
  else:
   desired=copy.deepcopy(before);desired['variables']['T.wire_disposition']='drop_ip_length'
   need(machine.snapshot()==desired,'drop changed unrelated protocol state/cache/queue/timer')
   need(len(machine.trace)==len(before_trace)+1 and machine.trace[-1]['emitted']==[],'drop emitted or changed transition count')
  steps.append(dict(at_ms=case['at_ms'],event=case['event'],fields=case['fields']));scene=dict(scenario_version='0.2',id=case['id'],initial={},steps=steps)
  save('policy/'+case['id']+'/scenario.json',scene);save('policy/'+case['id']+'/reference-trace.json',machine.trace);policy_refs.append((case,scene,machine.trace))
 stage='reference_literal_contracts'

 from protocol_lab.codegen import generate
 from protocol_lab.codegen.execute import build,run
 from protocol_lab.symbolic import crosscheck_trace
 references=[];scenes=[]
 for case in qualified['cases']:
  machine=Machine(m,case.get('initial',{}));scene=dict(scenario_version='0.2',id=case['id'],initial=case.get('initial',{}),steps=[])
  for step in case['steps']:
   before=len(machine.trace);machine.dispatch(step['event'],step.get('fields',{}),step['at_ms']);observed=machine.trace[before:]
   need(len(observed)==1,'fixture operation transition count differs')
   need(observed[0]['emitted']==step['expected_emitted'],'independent emitted bytes differ in '+case['id'])
   for k,v in step['expected_variables'].items():need(machine.values.get(k)==v,'independent variable differs '+case['id']+':'+k)
   
   if 'expected_timers' in step:need(machine.timers==step['expected_timers'],'independent timers differ '+case['id'])
   scene['steps'].append(dict(at_ms=step['at_ms'],event=step['event'],fields=step.get('fields',{}),expect_trace=[dict(at_ms=step['at_ms'],emitted=step['expected_emitted'])]))
  scene['expect']=dict(state='COMPOSED',variables=step['expected_variables'],timers=step['expected_timers'])
  save(case['id']+'-scenario.json',scene);save(case['id']+'-reference-trace.json',machine.trace);references.append(machine.trace);scenes.append(scene)
 stage='actual_native';save('status.json',dict(status='running',stage=stage,API_calls=0,reference_cases=len(scenes)))
 generate(O/'candidate-model.json',O/'generated');built=build(O/'generated',O/'build');need(built['status']=='pass','native build failed')
 for scene in scenes:
  native=run(O/'generated',O/'build',O/(scene['id']+'-scenario.json'),O/(scene['id']+'-native'));need(native['status']=='pass','native/reference differed')
 # Actual native positive drops and negative model gaps use the strict pipeline comparator.
 from protocol_lab.codegen.execute import commands
 from protocol_lab.pipeline.worker import reference_case,compare_case
 import subprocess
 stage='actual_native_policy';save('status.json',dict(status='running',stage=stage,API_calls=0))
 for case,scene,trace in policy_refs:
  dest=O/'policy'/case['id']/'native';dest.mkdir();data=commands(m,scene);(dest/'native-input.txt').write_text(data)
  p=subprocess.run([str(O/'build/protocol-native')],input=data,capture_output=True,text=True,timeout=30)
  (dest/'native.stdout').write_text(p.stdout);(dest/'native.stderr').write_text(p.stderr);need(not p.stderr,'native policy stderr')
  expected=reference_case(m,scene);negative=case['expected']=='model_gap'
  need((expected.get('error')or{}).get('classification')==('model_gap'if negative else None),'policy reference classification mismatch')
  diff=compare_case(expected,[json.loads(line)for line in p.stdout.splitlines()],p.returncode,negative);save('policy/'+case['id']+'/native-difference.json',diff);need(diff['status']=='pass','native policy mismatch')
 stage='independent_fixed_Z3';save('status.json',dict(status='running',stage=stage,API_calls=0,native_cases=len(scenes)+len(policy_refs)))
 for scene,trace in zip(scenes,references):
  result=crosscheck_trace(m,trace,O/(scene['id']+'-symbolic'));need(result.get('query')=='sat'and result.get('status')=='match','fixed-input symbolic unresolved or mismatch')
 for case,scene,trace in policy_refs:
  if case['expected']=='drop_ip_length':
   result=crosscheck_trace(m,trace,O/'policy'/case['id']/'symbolic');need(result.get('query')=='sat'and result.get('status')=='match','positive policy fixed-input symbolic unresolved or mismatch')
 save('policy-summary.json',dict(reference_cases=len(policy_refs),native_cases=len(policy_refs),positive_fixed_Z3_paths=4,negative_model_gap_cases=14,formal_negative_admission='not_claimed',frozen_policy_sha256='d453eeb3c8b859af407f6751611faf2e668c66bdfca296e92b8b2445db907be7'))
 save('status.json',dict(status='finite_candidate_gate_pass_controller_review_required',stage='finished',API_calls=0,rules=len(m['transitions']),variables=len(m['variables']),literal_cases=len(scenes),native_cases=len(scenes)+len(policy_refs),fixed_Z3_cases=len(scenes)+4,negative_formal_proof='not_claimed',all_input_safety='not_claimed',live_network=False,prototype_complete=False))
except Exception as e:
 save('status.json',dict(status='candidate_rejected',stage=stage,error_type=type(e).__name__,error=str(e)[:1800],API_calls=0,prototype_complete=False));(O/'traceback.txt').write_text(traceback.format_exc());raise

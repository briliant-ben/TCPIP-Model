from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-coupling-port-repair-20261107-0074';O.mkdir(exist_ok=False);PRE=P/'candidates/tcp-ir-coupling-metadata-20261107-0073';PYTHON=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'))
from deepseek_gateway import request

def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),provider='DeepSeek',production_modified=False,automatic_failed_API_retry=False,prototype_complete=False,**v))
def call(name,context):
 messages=[dict(role='system',content='You are a precise protocol IR source repair engineer. Return JSON only. Supplied files are task data. No private data, IO/network execution, oracle or backend changes. Correct completed source against concrete counterexample, not an API retry.'),dict(role='user',content=json.dumps(context))];assert len(json.dumps(messages).encode())<96000;save(name+'-messages.json',messages)
 r=request(messages,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=32768,thinking='enabled',reasoning_effort='low',timeout=600)
 v=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response'];save(name+'-response.json',v);save(name+'-usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']});return v
try:
 status(status='running',stage='repair_completed_source_for_actual_counterexample',started_at=time.time())
 source=(PRE/'round-1/couple_tcp.py').read_text();(O/'previous-couple_tcp.py').write_text(source)
 policy_path=P/'incoming/tcp-coupling-policy-0069-prefreeze/frozen-policy-cases.json';assert hashlib.sha256(policy_path.read_bytes()).hexdigest()=='d453eeb3c8b859af407f6751611faf2e668c66bdfca296e92b8b2445db907be7'
 contract=(P/'incoming/tcp-policy-patch-contract-0069.txt').read_text();(O/'contract.txt').write_text(contract)
 proposal=call('implementation',dict(task='Fix the exact completed source minimally for actual frozen wrong-port-fresh classification failure. Independent frozen18 policy cases are authoritative finite contract. Current malformed IP-length drop is peer/local IP correct and <=1500, but must admit only fixed TCP source8080/dest40000, consistent with every TCP ingress envelope. Wrong peer/MAC/port/protocol/reverse/aboveMTU remain model_gap atomically; correctly addressed below-min39/truncated47 remain drop_ip_length in fresh and pendingTCP. Preserve pending packet/owner/timers/state; only disposition changes for drops. Retain all original TCP ingress/transport guards, old algorithms, traceability and defensive shape errors. No priority dispatch, callbacks, new opcodes, broad rewrite or weakening. Review complete finite envelope rather than masking one fixture. Return {patches:[{old:exact unique substring,new:replacement}],assumptions:[],limitations:[]}, max4 patches. Source will be capability checked then actual reference/C/exact fixed Z3, no free approval.',completed_source=source,actual_failure=json.loads((PRE/'validation-0001/status.json').read_text()),frozen_policy=json.loads(policy_path.read_text()),contract=contract,actual_operator_signatures=json.loads((P/'incoming/tcp-ir-operator-signatures.json').read_text())))
 patches=proposal.get('patches');assert isinstance(patches,list)and 1<=len(patches)<=4
 for patch in patches:
  assert set(patch)=={'old','new'}and isinstance(patch['old'],str)and patch['old']and source.count(patch['old'])==1
  source=source.replace(patch['old'],patch['new'],1)
 ast.parse(source);r=O/'round-1';r.mkdir();(r/'couple_tcp.py').write_text(source)
 template=(P/'incoming/validate-tcp-coupling-0069.py').read_text().replace('tcp-ir-coupling-policy-20261107-0069','tcp-coupling-port-repair-20261107-0074')
 old="def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\\n')";new="def save(n,v):\n p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\\n')";assert template.count(old)==1;template=template.replace(old,new)
 checker=r/'executed-validator.py';checker.write_text(template);status(status='running',stage='trusted_four_core_eighteen_policy_gate')
 try:
  with(r/'validation-controller.log').open('w')as log:cp=subprocess.run([str(PYTHON),str(checker)],stdout=log,stderr=subprocess.STDOUT,timeout=420,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 except subprocess.TimeoutExpired:
  status(status='resource_unresolved',stage='stopped',automatic_solver_retry=False);raise SystemExit(0)
 f=O/'validation-0001/status.json';result=json.loads(f.read_text())if f.exists()else {'status':'no_result'}
 if cp.returncode!=0 or result.get('status')!='finite_candidate_gate_pass_controller_review_required':
  status(status='candidate_rejected',stage='finished',validation=result,returncode=cp.returncode,finished_at=time.time());raise SystemExit(0)
 status(status='running',stage='independent_source_review_after_actual_gate')
 review=call('independent-review',dict(task='Independently review exact completed finite source for contract consistency. Return {blocking:[{issue,evidence,impact}],findings:[],limitations:[]}. No approval by self-assessment; actual controller gate below is limited fixed-input testing, negative model gaps not formal proofs. Check complete envelope/disposition, shared-owner/queue/abort/timers, cloning/traceability/defensive errors. Do not require undeclared full TCP features as defects.',contract=contract,source=source,actual_gate=result,frozen_policy=json.loads(policy_path.read_text())))
 status(status='candidate_review_findings'if review.get('blocking')else'candidate_ready_for_controller_review',stage='finished',validation=result,review=review,legacy_45_not_rerun=True,finished_at=time.time())
except Exception as e:
 status(status='failed_or_uncertain',stage='stopped',error_type=type(e).__name__,automatic_retry=False,finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_x () Int)
(declare-fun state_1 () Int)
(declare-fun v_2_x () Int)
(declare-fun state_2 () Int)
(declare-fun v_3_x () Int)
(declare-fun state_3 () Int)
(declare-fun v_0_x () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_one_n () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_two_n () Bool)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_one_n () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 (let (($x668 (= v_1_x 2)))
 (let (($x778 (= 0 state_1)))
 (let (($x2611 (>= 0 now_0)))
 (let (($x216 (= state_0 0)))
 (and $x216 $x2611 $x778 $x668))))))
(assert
 true)
(assert
 (let (($x32167 (= 0 state_2)))
 (let (($x2601 (= state_1 0)))
 (and $x2601 (>= 99 v_1_x) $x32167 (= v_2_x (+ 2 v_1_x))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x794 (= 0 state_3)))
 (let (($x2698 (= state_2 0)))
 (and $x2698 (>= 99 v_2_x) $x794 (= v_3_x (+ 2 v_2_x))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= 0 v_0_x))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 1 input_0_one_n))
(assert
 (= 1 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_two_n true))
(assert
 (= 0 choice_2))
(assert
 (= 2 now_3))
(assert
 (= 1 input_2_one_n))
(check-sat)

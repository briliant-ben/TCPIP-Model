
from pathlib import Path
import hashlib,importlib.util,json,resource,sys,time
mode,root=sys.argv[1:];P=Path('/home/blxu/protocol-flow');O=Path(root)/mode;O.mkdir();W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';sys.path.insert(0,str(W));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
if mode=='proposal':
 p=P/'candidates/tcp-guard-memo-proposal-20261107-0072/proposed-symbolic.py';s=importlib.util.spec_from_file_location('protocol_lab.symbolic',p);mod=importlib.util.module_from_spec(s);sys.modules['protocol_lab.symbolic']=mod;s.loader.exec_module(mod)
from protocol_lab.ir import load,Machine,ModelError,validate
from protocol_lab.symbolic import Encoding,encode_trace,crosscheck_trace
m=load(P/'candidates/tcp-ir-coupling-envelope-20261107-0067/validation-0002/candidate-model.json');trace=json.loads((P/'candidates/tcp-coupling-regression-20261107-0068/L-arp-udp-transmit-udp-zero-is-ffff/reference-trace.json').read_text());cpu=time.process_time();start=time.monotonic();enc=encode_trace(m,trace);q=enc.solver.to_smt2();(O/'diagnostic.smt2').write_text(q);timing=dict(cpu_seconds=time.process_time()-cpu,wall_seconds=time.monotonic()-start,query_sha256=hashlib.sha256(q.encode()).hexdigest(),solver_called=False);(O/'timing.json').write_text(json.dumps(timing,indent=2))
add={'op':'add','args':[{'var':'x'},1]}
generic={'ir_version':'0.2','semantics':'atomic-v1','protocol':'generic-cache-hazard','scope':{'terminal_states':[]},'states':['A'],'initial_state':'A','requirements':{'S':{'source':'docs/semantics.md','interpretation':'cache isolation counterexample'}},'variables':{'x':{'type':'int','initial':0}},'events':{'one':{'origin':'application','fields':{'n':'int'}},'two':{'origin':'application','fields':{'n':'bool'}}},'messages':{'out':{'fields':{'value':'int'}}},'timers':{},'invariants':[],'transitions':[]}
for name,literal in [('one',1),('two',True)]:
 generic['transitions'].append({'id':name,'from':'A','to':'A','event':name,'guard':{'op':'and','args':[{'op':'le','args':[add,100]},{'op':'eq','args':[{'event':'n'},literal]}]},'actions':[{'set':{'var':'x','value':add}},{'set':{'var':'x','value':add}},{'emit':{'message':'out','fields':{'value':{'var':'x'}}}}],'requirements':['S']})
validate(generic);machine=Machine(generic);machine.dispatch('one',{'n':1},0);machine.dispatch('two',{'n':True},1);machine.dispatch('one',{'n':1},2);assert machine.values['x']==6
r=crosscheck_trace(generic,machine.trace,O/'action-event-hazard');assert r['status']=='match'and r['query']=='sat'
e=Encoding(generic,2);(O/'all-input-generic.smt2').write_text(e.solver.to_smt2())
try:e.expr({'op':'definitely_unsupported','args':[]},e.frames[0],{})
except ModelError:pass
else:raise AssertionError('unsupported opcode accepted')
if mode=='proposal':
 e._cache_enabled=True;e._cache_event_name='manual';assert e.expr(True,e.frames[0],{}).sort()!=e.expr(1,e.frames[0],{}).sort();e._cache_enabled=False
 original=Encoding.solve
 def interrupted(self):
  assert (O/'interrupted/path.smt2').is_file()and not(O/'interrupted/result.json').exists();raise RuntimeError('deliberate interruption after query save')
 Encoding.solve=interrupted
 try:
  try:crosscheck_trace(generic,machine.trace,O/'interrupted')
  except RuntimeError as x:assert str(x)=='deliberate interruption after query save'
  else:raise AssertionError('interruption not delivered')
 finally:Encoding.solve=original
(O/'result.json').write_text(json.dumps(dict(status='pass',mutable_actions_and_event_types='SAT_replay_match',unknown_operator_rejected=True,diagnostic_solver_called=False),indent=2))

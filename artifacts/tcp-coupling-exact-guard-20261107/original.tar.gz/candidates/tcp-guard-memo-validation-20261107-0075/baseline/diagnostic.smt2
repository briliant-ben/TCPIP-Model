; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x846 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x845 (= due_1_T.user due_0_T.user)))
 (let (($x844 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x843 (= due_1_L.cache due_0_L.cache)))
 (let (($x63377 (= due_1_L.query 1000)))
 (let (($x841 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x840 (= active_1_T.user active_0_T.user)))
 (let (($x839 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x838 (= active_1_L.cache active_0_L.cache)))
 (let (($x836 (= v_1_ip_pending_owner "UDP")))
 (let (($x32540 (= v_1_T.control "CLOSED")))
 (let (($x2827 (= v_1_T.wire_flags 0)))
 (let (($x63376 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x63375 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x63374 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x63373 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x63372 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x63371 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x63370 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x2790 (= v_1_T.take 0)))
 (let (($x2791 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x2792 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x2793 (= v_1_T.snd_wnd 8)))
 (let (($x63369 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x63368 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x63367 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x2656 (= v_1_T.local_window 16)))
 (let (($x2657 (= v_1_T.msl_ms 60000)))
 (let (($x2861 (= v_1_T.user_timeout_ms 30000)))
 (let (($x2862 (= v_1_T.retries 0)))
 (let (($x2863 (= v_1_T.rto_ms 1000)))
 (let (($x2865 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x2866 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x2867 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x2868 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x2869 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x2870 (= v_1_T.irs (_ bv0 32))))
 (let (($x2871 (= v_1_T.iss (_ bv1000 32))))
 (let (($x804 (= v_1_L.control "PENDING")))
 (let (($x63366 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x63365 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63364 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63363 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x63362 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x32370 (not v_1_L.rxudp_require_checksum)))
 (let ((?x522 (seq.unit (_ bv255 8))))
 (let ((?x2773 (seq.unit (_ bv10 8))))
 (let ((?x62870 (seq.++ ?x2773 (seq.++ ?x522 (seq.++ ?x522 (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv5 8))))))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x954 (seq.unit (_ bv144 8))))
 (let ((?x952 (seq.unit (_ bv31 8))))
 (let ((?x714 (seq.unit (_ bv64 8))))
 (let ((?x956 (seq.unit (_ bv156 8))))
 (let ((?x62875 (seq.++ ?x956 (seq.++ ?x714 (seq.++ ?x952 (seq.++ ?x954 (seq.++ ?x442 ?x62870)))))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x63340 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x62875)))))))
 (let ((?x63235 (seq.unit (_ bv203 8))))
 (let ((?x63233 (seq.unit (_ bv182 8))))
 (let ((?x63345 (seq.++ ?x63233 (seq.++ ?x63235 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63340)))))))
 (let ((?x658 (seq.unit (_ bv17 8))))
 (let ((?x63350 (seq.++ ?x442 (seq.++ ?x714 (seq.++ ?x442 (seq.++ ?x714 (seq.++ ?x658 ?x63345)))))))
 (let ((?x62879 (seq.unit (_ bv30 8))))
 (let ((?x678 (seq.unit (_ bv69 8))))
 (let ((?x63355 (seq.++ ?x678 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x62879 (seq.++ ?x442 ?x63350)))))))
 (let (($x63361 (= v_1_L.pending_packet ?x63355)))
 (let (($x63360 (= v_1_L.ip_checksum 46795)))
 (let (($x63359 (= v_1_L.udp_checksum 65535)))
 (let (($x2944 (= v_1_L.udp_raw_checksum 0)))
 (let (($x63358 (= v_1_L.ip_length 30)))
 (let (($x63357 (= v_1_L.udp_length 10)))
 (let (($x63356 (= v_1_L.packet ?x63355)))
 (let ((?x306 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x444)))))))
 (let ((?x308 (seq.++ ?x440 (seq.++ ?x442 ?x306))))
 (let ((?x63291 (seq.++ ?x442 (seq.++ ?x714 (seq.++ ?x658 (seq.++ ?x63233 (seq.++ ?x63235 ?x308)))))))
 (let ((?x63296 (seq.++ ?x442 (seq.++ ?x62879 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x714 ?x63291)))))))
 (let (($x63299 (= v_1_L.ip_wire (seq.++ ?x678 (seq.++ ?x442 ?x63296)))))
 (let ((?x62950 (seq.++ ?x442 (seq.++ ?x714 (seq.++ ?x658 (seq.++ ?x442 (seq.++ ?x442 ?x308)))))))
 (let ((?x62955 (seq.++ ?x442 (seq.++ ?x62879 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x714 ?x62950)))))))
 (let (($x62958 (= v_1_L.ip_zero (seq.++ ?x678 (seq.++ ?x442 ?x62955)))))
 (let (($x62876 (= v_1_L.udp_wire ?x62875)))
 (let ((?x33794 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x658 (seq.++ ?x442 ?x2773)))))))
 (let ((?x33804 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 ?x33794)))))))
 (let (($x33806 (= v_1_L.pseudoheader (seq.++ ?x440 ?x33804))))
 (let ((?x2833 (seq.++ ?x2773 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x440 (seq.unit (_ bv5 8))))))))
 (let ((?x299 (seq.++ ?x956 (seq.++ ?x714 (seq.++ ?x952 (seq.++ ?x954 (seq.++ ?x442 ?x2833)))))))
 (let (($x300 (= v_1_L.udp_zero ?x299)))
 (let ((?x62814 (seq.++ ?x440 (seq.unit (_ bv5 8)))))
 (let (($x3004 (= v_1_L.payload ?x62814)))
 (let (($x2670 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x780 (= 0 v_1_L.retry_count)))
 (let (($x2824 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x778 (= 0 state_1)))
 (let (($x407 (not active_0_T.time_wait)))
 (let (($x2931 (or $x407 (not (<= due_0_T.time_wait 0)))))
 (let (($x405 (not active_0_T.user)))
 (let (($x2913 (or $x405 (not (<= due_0_T.user 0)))))
 (let (($x403 (not active_0_T.rtx)))
 (let (($x2978 (or $x403 (not (<= due_0_T.rtx 0)))))
 (let (($x401 (not active_0_L.cache)))
 (let (($x2973 (or $x401 (not (<= due_0_L.cache 0)))))
 (let (($x399 (not active_0_L.query)))
 (let (($x2605 (or $x399 (not (<= due_0_L.query 0)))))
 (let (($x216 (= state_0 0)))
 (and $x216 (>= 0 now_0) $x2605 $x2973 $x2978 $x2913 $x2931 $x778 $x2824 $x780 $x2670 v_1_L.checksums_enabled $x3004 $x300 $x33806 $x62876 $x62958 $x63299 $x63356 $x63357 $x63358 $x2944 $x63359 $x63360 $x63361 $x32370 $x63362 (= v_1_L.rxudp_disposition "none") $x63363 $x63364 $x63365 $x63366 (= v_1_L.echo_disposition "none") $x804 $x2871 $x2870 $x2869 $x2868 $x2867 $x2866 $x2865 (= v_1_T.tx_flags "S") $x2863 $x2862 v_1_T.active_open $x2861 $x2657 $x2656 $x63367 $x63368 $x63369 $x2793 $x2792 $x2791 $x2790 $x63370 $x63371 $x63372 $x63373 $x63374 $x63375 $x63376 $x2827 (= v_1_T.wire_disposition "none") $x32540 $x836 active_1_L.query $x838 $x839 $x840 $x841 $x63377 $x843 $x844 $x845 $x846)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x32235 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x32234 (= due_2_T.user due_1_T.user)))
 (let (($x32233 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x32231 (= due_2_L.query due_1_L.query)))
 (let (($x32230 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x32229 (= active_2_T.user active_1_T.user)))
 (let (($x32228 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x2577 (not active_2_L.query)))
 (let (($x32225 (= v_2_ip_pending_owner "none")))
 (let (($x32224 (= v_2_T.control v_1_T.control)))
 (let (($x32223 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x32222 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x32221 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x32220 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x32219 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x32218 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x32217 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x32216 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x32215 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x32214 (= v_2_T.take v_1_T.take)))
 (let (($x32213 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x32212 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x32211 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x32210 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x32209 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x32208 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x32207 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x32206 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x32205 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x32204 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x32203 (= v_2_T.retries v_1_T.retries)))
 (let (($x32202 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x32201 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x32200 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x32199 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x32198 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x32197 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x32196 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x32195 (= v_2_T.irs v_1_T.irs)))
 (let (($x32194 (= v_2_T.iss v_1_T.iss)))
 (let (($x32193 (= v_2_L.control "RESOLVED")))
 (let (($x32192 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x32191 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x32190 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x32189 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x32188 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x32187 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x32186 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x32185 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x2576 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x32183 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x32182 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x32181 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x32180 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x32179 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x32178 (= v_2_L.packet v_1_L.packet)))
 (let (($x32177 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x32176 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x32175 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x32174 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x32173 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x32172 (= v_2_L.payload v_1_L.payload)))
 (let (($x32171 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x32170 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x32169 (= 0 v_2_L.retry_count)))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x1424 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.unit (_ bv2 8))))))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x1425 (seq.++ ?x444 ?x1424)))
 (let (($x2580 (= v_2_L.peer_mac ?x1425)))
 (let (($x32167 (= 0 state_2)))
 (let (($x2579 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x33848 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x63202 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x63198 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x63194 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x32124 (seq.len v_1_L.pending_packet)))
 (let (($x32125 (<= 28 ?x32124)))
 (let (($x804 (= v_1_L.control "PENDING")))
 (let (($x2601 (= state_1 0)))
 (and $x2601 $x804 $x32125 $x63194 $x63198 $x63202 $x33848 $x2579 $x32167 $x2580 $x32169 $x32170 $x32171 $x32172 $x32173 $x32174 $x32175 $x32176 $x32177 $x32178 $x32179 $x32180 $x32181 $x32182 $x32183 $x2576 $x32185 $x32186 $x32187 $x32188 $x32189 $x32190 $x32191 $x32192 $x32193 $x32194 $x32195 $x32196 $x32197 $x32198 $x32199 $x32200 $x32201 $x32202 $x32203 $x32204 $x32205 $x32206 $x32207 $x32208 $x32209 $x32210 $x32211 $x32212 $x32213 $x32214 $x32215 $x32216 $x32217 $x32218 $x32219 $x32220 $x32221 $x32222 $x32223 $x32224 $x32225 $x2577 active_2_L.cache $x32228 $x32229 $x32230 $x32231 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x32233 $x32234 $x32235))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x62814 (seq.++ ?x440 (seq.unit (_ bv5 8)))))
 (= input_0_L.app.send_data ?x62814))))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x440 (seq.unit (_ bv192 8))))
(let ((?x594 (seq.++ ?x440 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x514 (seq.unit (_ bv1 8))))
(let ((?x442 (seq.unit (_ bv0 8))))
(let ((?x62821 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x514 ?x594)))))))
(let ((?x444 (seq.unit (_ bv2 8))))
(let ((?x62826 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 (seq.++ ?x444 ?x62821)))))))
(let ((?x62831 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 ?x62826)))))))
(let ((?x542 (seq.unit (_ bv4 8))))
(let ((?x540 (seq.unit (_ bv6 8))))
(let ((?x62836 (seq.++ ?x540 (seq.++ ?x542 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x62831)))))))
(let ((?x538 (seq.unit (_ bv8 8))))
(let ((?x62841 (seq.++ ?x540 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x538 (seq.++ ?x442 ?x62836)))))))
(let ((?x62846 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x538 ?x62841)))))))
(let ((?x62851 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x514 (seq.++ ?x444 (seq.++ ?x442 ?x62846)))))))
(let ((?x62854 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x442 ?x62851)))))
(= input_1_L.net.frame_frame ?x62854))))))))))))))))))
(check-sat)

from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');J=P/'candidates/tcp-guard-memo-proposal-20261107-0072';O=P/'candidates/tcp-guard-memo-validation-20261107-0077';W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';PYTHON=P/'releases/udp-transmit-1b13a36f/venv/bin/python';O.mkdir(exist_ok=False)
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,prototype_complete=False,**v))
try:
 status(status='running',stage='controller_static_approval',started_at=time.time())
 review=json.loads((J/'status.json').read_text());assert review['status']=='proposal_ready_for_controller_static_review'and not review['review']['blocking']
 old=(J/'original-symbolic.py').read_text();new=(J/'proposed-symbolic.py').read_text();assert old==(W/'protocol_lab/symbolic.py').read_text()
 ot=ast.parse(old);nt=ast.parse(new)
 def bodies(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 om=bodies(ot);nm=bodies(nt);assert set(om)==set(nm)
 for name in om:
  if name not in ['crosscheck_trace','Encoding']:assert ast.dump(om[name])==ast.dump(nm[name]),name
 oc={n.name:n for n in om['Encoding'].body if isinstance(n,ast.FunctionDef)};nc={n.name:n for n in nm['Encoding'].body if isinstance(n,ast.FunctionDef)}
 assert set(nc)-set(oc)=={'_expr_uncached','_contains_checksum'}
 for name in oc:
  if name not in ['__init__','expr','encode_step']:assert ast.dump(oc[name])==ast.dump(nc[name]),name
 original_expr=ast.parse(ast.unparse(oc['expr'])).body[0];original_expr.name='_expr_uncached';assert ast.dump(original_expr)==ast.dump(nc['_expr_uncached'])
 assert [ast.dump(n)for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))]==[ast.dump(n)for n in nt.body if isinstance(n,(ast.Import,ast.ImportFrom))]
 save('static-approval.json',dict(scope='Only isolated test execution approved, not production integration',old_sha256=hashlib.sha256(old.encode()).hexdigest(),new_sha256=hashlib.sha256(new.encode()).hexdigest(),unchanged_operator_body=True,unchanged_solve_witness_replay=True,all_guards_retained=True,guard_cache_disabled_before_actions=True,checksum_nodes_uncached=True))
 child=r'''
from pathlib import Path
import hashlib,importlib.util,json,resource,sys,time
mode,root=sys.argv[1:];P=Path('/home/blxu/protocol-flow');O=Path(root)/mode;O.mkdir();W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';sys.path.insert(0,str(W));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
if mode=='proposal':
 p=P/'candidates/tcp-guard-memo-proposal-20261107-0072/proposed-symbolic.py';s=importlib.util.spec_from_file_location('protocol_lab.symbolic',p);mod=importlib.util.module_from_spec(s);sys.modules['protocol_lab.symbolic']=mod;s.loader.exec_module(mod)
from protocol_lab.ir import load,Machine,ModelError,validate
from protocol_lab.symbolic import Encoding,encode_trace,crosscheck_trace
m=load(P/'candidates/tcp-ir-coupling-envelope-20261107-0067/validation-0002/candidate-model.json');trace=json.loads((P/'candidates/tcp-coupling-regression-20261107-0068/L-arp-udp-transmit-udp-zero-is-ffff/reference-trace.json').read_text());cpu=time.process_time();start=time.monotonic();enc=encode_trace(m,trace);q=enc.solver.to_smt2();(O/'diagnostic.smt2').write_text(q);timing=dict(cpu_seconds=time.process_time()-cpu,wall_seconds=time.monotonic()-start,query_sha256=hashlib.sha256(q.encode()).hexdigest(),solver_called=False);(O/'timing.json').write_text(json.dumps(timing,indent=2))
add={'op':'add','args':[{'var':'x'},1]}
generic={'ir_version':'0.2','semantics':'flat-efsm-atomic-ordered-v1','protocol':'generic-cache-hazard','scope':{'terminal_states':[]},'states':['A'],'initial_state':'A','requirements':{'S':{'source':'docs/semantics.md','interpretation':'cache isolation counterexample'}},'variables':{'x':{'type':'int','initial':0}},'events':{'one':{'origin':'application','fields':{'n':'int'}},'two':{'origin':'application','fields':{'n':'bool'}}},'messages':{'out':{'fields':{'value':'int'}}},'timers':{},'invariants':[],'transitions':[]}
for name,literal in [('one',1),('two',True)]:
 generic['transitions'].append({'id':name,'from':'A','to':'A','event':name,'guard':{'op':'and','args':[{'op':'le','args':[add,100]},{'op':'eq','args':[{'event':'n'},literal]}]},'actions':[{'set':{'var':'x','value':add}},{'set':{'var':'x','value':add}},{'emit':{'message':'out','fields':{'value':{'var':'x'}}}}],'requirements':['S']})
validate(generic);machine=Machine(generic);machine.dispatch('one',{'n':1},0);machine.dispatch('two',{'n':True},1);machine.dispatch('one',{'n':1},2);assert machine.values['x']==6
r=crosscheck_trace(generic,machine.trace,O/'action-event-hazard');assert r['status']=='match'and r['query']=='sat'
e=Encoding(generic,2,());(O/'all-input-generic.smt2').write_text(e.solver.to_smt2())
try:e.expr({'op':'definitely_unsupported','args':[]},e.frames[0],{})
except ModelError:pass
else:raise AssertionError('unsupported opcode accepted')
if mode=='proposal':
 e._cache_enabled=True;e._cache_event_name='manual';assert e.expr(True,e.frames[0],{}).sort()!=e.expr(1,e.frames[0],{}).sort();e._cache_enabled=False
 original=Encoding.solve
 def interrupted(self):
  assert (O/'interrupted/path.smt2').is_file()and not(O/'interrupted/result.json').exists();raise RuntimeError('deliberate interruption after query save')
 Encoding.solve=interrupted
 try:
  try:crosscheck_trace(generic,machine.trace,O/'interrupted')
  except RuntimeError as x:assert str(x)=='deliberate interruption after query save'
  else:raise AssertionError('interruption not delivered')
 finally:Encoding.solve=original
(O/'result.json').write_text(json.dumps(dict(status='pass',mutable_actions_and_event_types='SAT_replay_match',unknown_operator_rejected=True,diagnostic_solver_called=False),indent=2))
'''
 script=O/'executed-child.py';script.write_text(child)
 for mode in ['baseline','proposal']:
  status(status='running',stage=mode+'_exact_encoding_and_hazards')
  with(O/(mode+'.log')).open('w')as log:cp=subprocess.run([str(PYTHON),str(script),mode,str(O)],stdout=log,stderr=subprocess.STDOUT,timeout=180,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
  assert cp.returncode==0,mode+' child failed; inspect log'
 for n in ['diagnostic.smt2','all-input-generic.smt2','action-event-hazard/path.smt2']:
  assert (O/'baseline'/n).read_bytes()==(O/'proposal'/n).read_bytes(),'exact query changed: '+n
 times={mode:json.loads((O/mode/'timing.json').read_text())for mode in ['baseline','proposal']}
 status(status='exact_queries_and_hazard_gate_pass_review_required',stage='finished',exact_query_pairs=3,timing=times,speedup=times['baseline']['cpu_seconds']/times['proposal']['cpu_seconds'],all_input_safety='not_claimed',formal_equivalence_proof='not_claimed',finished_at=time.time())
except Exception as e:
 status(status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__,error=str(e),finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

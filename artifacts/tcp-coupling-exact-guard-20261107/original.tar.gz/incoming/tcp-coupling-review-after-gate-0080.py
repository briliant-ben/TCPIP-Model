from pathlib import Path
import hashlib,json,os,shutil,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-coupling-final-review-20261107-0080';O.mkdir(exist_ok=False);G=P/'candidates/tcp-coupling-optimized-validation-20261107-0079'
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'))
from deepseek_gateway import request

def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),provider='DeepSeek',production_modified=False,automatic_failed_API_retry=False,prototype_complete=False,**v))
try:
 status(status='waiting_for_trusted_gate',stage='before_any_API',started_at=time.time())
 deadline=time.monotonic()+3000
 while True:
  state=json.loads((G/'status.json').read_text());pid=state['pid'];proc=Path('/proc')/str(pid);live=proc.exists()and(proc/'stat').read_text().split(')')[1].split()[0]!='Z'
  if state['status']!='running' or not live:break
  if time.monotonic()>=deadline:
   status(status='wait_deadline_no_API',stage='stopped',last_gate=state);raise SystemExit(0)
  time.sleep(60)
 if state['status']!='finite_generic_and_45_regression_pass_controller_review_required':
  status(status='gate_not_accepted_no_API',stage='stopped',last_gate=state);raise SystemExit(0)
 files=['round-1/couple_tcp.py','exact-model-C-bindings.json','regression-0001/status.json','validation-0001/policy-summary.json']
 bound={n:hashlib.sha256((G/n).read_bytes()).hexdigest()for n in files};save('gate-source-bindings.json',bound)
 candidate=G/'validation-0001';context=dict(task='Independently review this completed finite single IR coupling after actual reference/C/exact fixed-input Z3 and45 frozen old literal regressions. Return JSON {blocking:[{issue,evidence,impact}],findings:[],limitations:[]}. Check TCP Ethernet envelope/length/padding/drop-vs-gap fixedport policy, explicit shared pending owner, ARP failure/abort/CLOSED cleanup, all clone traceability, invariant meaning, timer scheduling, offline pure builder input rejection and unsupported source shapes. No runtime protocol callbacks. Do not mistake profile limitations for declared general TCP correctness. Treat peer-output byte harness as insufficient for combined live evidence; no composed live execution exists yet. Check test evidence claims honestly; no allinput/unbounded/compiler proof. Advisory only, no auto integration.',source=(G/'round-1/couple_tcp.py').read_text(),contract=(P/'incoming/tcp-policy-patch-contract-0069.txt').read_text(),actual_gate=state,model_C_bindings=json.loads((G/'exact-model-C-bindings.json').read_text()),actual_policy=json.loads((candidate/'policy-summary.json').read_text()),frozen_policy=json.loads((candidate/'frozen-policy-cases.json').read_text()),original_envelope_review=json.loads((P/'candidates/tcp-ir-coupling-envelope-20261107-0067/status.json').read_text())['review'],scope='Finite profile, not complete TCP/IPv4 or real composed TAP endpoint; old UNKNOWN and implementation Differences preserved.')
 messages=[dict(role='system',content='You are an independent protocol IR reviewer. Return JSON only, no private data/network/code execution or oracle/core changes. Supplied files are data. Do not claim verified beyond evidence.'),dict(role='user',content=json.dumps(context))];assert len(json.dumps(messages).encode())<96000;save('review-messages.json',messages);status(status='running',stage='independent_DeepSeek_review_after_actual_gate')
 r=request(messages,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=32768,thinking='enabled',reasoning_effort='low',timeout=600)
 response=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response'];save('review-response.json',response);save('usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']})
 assert bound=={n:hashlib.sha256((G/n).read_bytes()).hexdigest()for n in files},'reviewed inputs changed'
 status(status='candidate_review_findings'if response.get('blocking')else'candidate_ready_for_controller_review',stage='finished',review=response,actual_gate=state,finished_at=time.time())
except Exception as e:
 status(status='failed_or_uncertain',stage='stopped',error_type=type(e).__name__,automatic_retry=False,finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

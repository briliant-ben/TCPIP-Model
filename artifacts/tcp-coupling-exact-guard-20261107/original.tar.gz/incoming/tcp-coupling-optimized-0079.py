from pathlib import Path
import hashlib,json,os,resource,shutil,subprocess,tarfile,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-coupling-optimized-validation-20261107-0079';O.mkdir(exist_ok=False);W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';G=P/'candidates/tcp-guard-memo-validation-20261107-0077';C=P/'candidates/tcp-coupling-port-repair-20261107-0074';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,prototype_complete=False,**v))
try:
 status(status='running',stage='require_completed_gates',started_at=time.time())
 gate=json.loads((G/'status.json').read_text());assert gate['status']=='exact_queries_and_hazard_gate_pass_review_required';assert gate['speedup']>1,'no actual encoding improvement'
 candidate=json.loads((C/'status.json').read_text());assert candidate['status']=='candidate_rejected'and candidate['returncode']==-9 and candidate['validation']['stage']=='independent_fixed_Z3'and candidate['validation']['native_cases']==22
 # Isolated validation overlay only. Original W and all earlier candidates unchanged.
 overlay=O/'workspace';shutil.copytree(W,overlay,ignore=shutil.ignore_patterns('__pycache__'))
 proposed=P/'candidates/tcp-guard-memo-proposal-20261107-0072/proposed-symbolic.py';shutil.copyfile(proposed,overlay/'protocol_lab/symbolic.py')
 fixture=P/'incoming/tcp-guard-regression-inputs-137ad5c3.tar';assert hashlib.sha256(fixture.read_bytes()).hexdigest()=='389fe3c234d71aae5dcf2e178349e0c9cc82769baaeeebe7d716863f5dc557a2'
 with tarfile.open(fixture)as tar:
  for item in tar.getmembers():
   path=Path(item.name);assert not path.is_absolute()and'..'not in path.parts and(item.isfile()or item.isdir())and path.parts[0]in ['tests','scenarios']
   dest=overlay/path
   if item.isdir():dest.mkdir(parents=True,exist_ok=True)
   else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(tar.extractfile(item).read())
 save('bindings.json',dict(baseline_git='137ad5c3',test_fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),new_symbolic_sha256=hashlib.sha256(proposed.read_bytes()).hexdigest(),guard_gate=gate,candidate_gate=candidate,overlay_only=True))
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(900,900));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))

 r=O/'round-1';r.mkdir();shutil.copyfile(C/'round-1/couple_tcp.py',r/'couple_tcp.py')
 validator=(P/'incoming/validate-tcp-coupling-0069.py').read_text().replace('tcp-ir-coupling-policy-20261107-0069','tcp-coupling-optimized-validation-20261107-0079').replace("W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace'","W=P/'candidates/tcp-coupling-optimized-validation-20261107-0079/workspace'")
 old_save="def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\\n')";new_save="def save(n,v):\n p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\\n')";assert validator.count(old_save)==1;validator=validator.replace(old_save,new_save)
 vf=r/'executed-validator.py';vf.write_text(validator);status(status='running',stage='four_core_eighteen_policy_new_exact_checker')
 with(O/'optimized-gate.log').open('w')as log:cp=subprocess.run([str(PY),str(vf)],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=420,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 f=O/'validation-0001/status.json';gate_result=json.loads(f.read_text())if f.exists()else {'status':'no_result'}
 assert cp.returncode==0 and gate_result.get('status')=='finite_candidate_gate_pass_controller_review_required','optimized exact gate incomplete: '+str(gate_result)
 new_validation=O/'validation-0001'
 assert (new_validation/'candidate-model.json').read_bytes()==(C/'validation-0001/candidate-model.json').read_bytes(),'candidate model changed'
 assert (new_validation/'generated/protocol.c').read_bytes()==(C/'validation-0001/generated/protocol.c').read_bytes(),'generated C source changed'
 save('exact-model-C-bindings.json',dict(candidate_model_byte_identical=True,generated_C_byte_identical=True,new_checker_source_bound_by_new_generation=True,original_0074_incomplete_result_preserved=True,optimized_gate=gate_result))
 status(status='running',stage='five_frozen_generic_regression_modules')
 with(O/'generic-tests.log').open('w')as log:
  cp=subprocess.run([str(PY),'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=1200,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 assert cp.returncode==0,'generic regression failed; inspect log'
 status(status='running',stage='45_original_literal_reference_native_fixedZ3_regressions')
 template=(P/'incoming/tcp-coupling-policy-regression-0069.py').read_text();template=template.replace("O=P/'candidates/tcp-ir-coupling-policy-20261107-0069/regression-0001'","O=P/'candidates/tcp-coupling-optimized-validation-20261107-0079/regression-0001'").replace("W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace'","W=P/'candidates/tcp-coupling-optimized-validation-20261107-0079/workspace'").replace("C=P/'candidates/tcp-ir-coupling-policy-20261107-0069/validation-0001'","C=P/'candidates/tcp-coupling-optimized-validation-20261107-0079/validation-0001'")
 # Original candidate native code uses unchanged model semantics and source bindings.
 # New checker is isolated, old generation/checker artifacts are never reclassified.
 rp=O/'executed-legacy-regression.py';rp.write_text(template)
 with(O/'legacy-controller.log').open('w')as log:cp=subprocess.run([str(PY),str(rp)],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=1200,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 f=O/'regression-0001/status.json';result=json.loads(f.read_text())if f.exists()else {'status':'no_result'}
 status(status='finite_generic_and_45_regression_pass_controller_review_required'if cp.returncode==0 and result.get('status')=='finite_regression_pass_controller_review_required'else'failed_or_unresolved',stage='finished',regression=result,returncode=cp.returncode,all_input_safety='not_claimed',live_network=False,finished_at=time.time())
except Exception as e:
 status(status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__,error=str(e),automatic_solver_retry=False,finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

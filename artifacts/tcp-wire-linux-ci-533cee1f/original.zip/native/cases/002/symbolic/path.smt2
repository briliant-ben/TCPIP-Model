; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_wire_disposition () String)
(declare-fun v_1_wire_flags () Int)
(declare-fun v_1_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_flags () Int)
(declare-fun v_0_wire_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x714 (= due_1_time_wait due_0_time_wait)))
 (let (($x713 (= due_1_user due_0_user)))
 (let (($x712 (= due_1_rtx due_0_rtx)))
 (let (($x711 (= active_1_time_wait active_0_time_wait)))
 (let (($x710 (= active_1_user active_0_user)))
 (let (($x709 (= active_1_rtx active_0_rtx)))
 (let (($x708 (= v_1_wire_disposition "drop_tcp_checksum")))
 (let (($x774 (= v_1_wire_flags 0)))
 (let (($x10704 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_packet)))
 (let (($x10703 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_ip_zero)))
 (let (($x10702 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp)))
 (let (($x10701 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_pseudo)))
 (let (($x10700 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp_zero)))
 (let (($x10699 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_data)))
 (let (($x10698 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x1310 (= v_1_take 0)))
 (let (($x834 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x836 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x1237 (= v_1_snd_wnd 8)))
 (let (($x10697 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x10696 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x10695 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x1238 (= v_1_local_window 16)))
 (let (($x1239 (= v_1_msl_ms 60000)))
 (let (($x1242 (= v_1_user_timeout_ms 30000)))
 (let (($x1258 (= v_1_retries 0)))
 (let (($x1259 (= v_1_rto_ms 1000)))
 (let (($x1261 (= v_1_tx_ack (_ bv0 32))))
 (let (($x1271 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x1262 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x1263 (= v_1_snd_nxt (_ bv1000 32))))
 (let (($x1274 (= v_1_snd_una (_ bv1000 32))))
 (let (($x1285 (= v_1_irs (_ bv0 32))))
 (let (($x1288 (= v_1_iss (_ bv1000 32))))
 (let (($x678 (= 0 state_1)))
 (let (($x10037 (not active_0_time_wait)))
 (let (($x10694 (or $x10037 (not (<= due_0_time_wait 0)))))
 (let (($x10041 (not active_0_user)))
 (let (($x10691 (or $x10041 (not (<= due_0_user 0)))))
 (let (($x10036 (not active_0_rtx)))
 (let (($x10688 (or $x10036 (not (<= due_0_rtx 0)))))
 (let (($x154 (= state_0 0)))
 (and $x154 (>= 0 now_0) $x10688 $x10691 $x10694 $x678 $x1288 $x1285 $x1274 $x1263 $x1262 $x1271 $x1261 (= v_1_tx_flags "S") $x1259 $x1258 v_1_active_open $x1242 $x1239 $x1238 $x10695 $x10696 $x10697 $x1237 $x836 $x834 $x1310 $x10698 $x10699 $x10700 $x10701 $x10702 $x10703 $x10704 $x774 $x708 $x709 $x710 $x711 $x712 $x713 $x714))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_wire_flags))
(assert
 (= v_0_wire_disposition "none"))
(assert
 (= 121 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x9827 (seq.unit (_ bv73 8))))
(let ((?x1136 (seq.++ ?x9827 (seq.++ (seq.unit (_ bv221 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
(let ((?x9828 (seq.unit (_ bv16 8))))
(let ((?x123 (seq.unit (_ bv0 8))))
(let ((?x1058 (seq.unit (_ bv18 8))))
(let ((?x10004 (seq.unit (_ bv80 8))))
(let ((?x1109 (seq.unit (_ bv233 8))))
(let ((?x93 (seq.++ ?x1109 (seq.++ ?x10004 (seq.++ ?x1058 (seq.++ ?x123 (seq.++ ?x9828 ?x1136)))))))
(let ((?x1036 (seq.unit (_ bv3 8))))
(let ((?x164 (seq.unit (_ bv40 8))))
(let ((?x1069 (seq.unit (_ bv35 8))))
(let ((?x9895 (seq.++ ?x1069 (seq.++ ?x164 (seq.++ ?x123 (seq.++ ?x123 (seq.++ ?x1036 ?x93)))))))
(let ((?x21 (seq.unit (_ bv64 8))))
(let ((?x1156 (seq.unit (_ bv156 8))))
(let ((?x1000 (seq.unit (_ bv144 8))))
(let ((?x9900 (seq.++ ?x1000 (seq.++ ?x1156 (seq.++ ?x21 (seq.++ ?x123 (seq.++ ?x123 ?x9895)))))))
(let ((?x1185 (seq.unit (_ bv31 8))))
(let ((?x973 (seq.unit (_ bv1 8))))
(let ((?x976 (seq.unit (_ bv2 8))))
(let ((?x42 (seq.unit (_ bv192 8))))
(let ((?x9905 (seq.++ ?x42 (seq.++ ?x123 (seq.++ ?x976 (seq.++ ?x973 (seq.++ ?x1185 ?x9900)))))))
(let ((?x1065 (seq.unit (_ bv204 8))))
(let ((?x9910 (seq.++ ?x1065 (seq.++ ?x42 (seq.++ ?x123 (seq.++ ?x976 (seq.++ ?x976 ?x9905)))))))
(let ((?x1040 (seq.unit (_ bv182 8))))
(let ((?x184 (seq.unit (_ bv6 8))))
(let ((?x9763 (seq.++ ?x21 (seq.++ ?x123 (seq.++ ?x21 (seq.++ ?x184 (seq.++ ?x1040 ?x9910)))))))
(let ((?x9945 (seq.++ ?x123 (seq.++ ?x123 (seq.++ ?x164 (seq.++ ?x123 (seq.++ ?x123 ?x9763)))))))
(let ((?x9677 (seq.unit (_ bv69 8))))
(let ((?x9741 (seq.++ ?x9677 ?x9945)))
(= input_0_net.packet_packet ?x9741)))))))))))))))))))))))))))))))
(check-sat)

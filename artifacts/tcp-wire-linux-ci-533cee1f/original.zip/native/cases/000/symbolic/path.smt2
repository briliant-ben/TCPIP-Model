; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_wire_disposition () String)
(declare-fun v_1_wire_flags () Int)
(declare-fun v_1_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_flags () Int)
(declare-fun v_0_wire_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x954 (= due_1_time_wait due_0_time_wait)))
 (let (($x953 (= due_1_user due_0_user)))
 (let (($x952 (= due_1_rtx due_0_rtx)))
 (let (($x951 (= active_1_time_wait active_0_time_wait)))
 (let (($x950 (= active_1_user active_0_user)))
 (let (($x949 (= active_1_rtx active_0_rtx)))
 (let (($x948 (= v_1_wire_disposition "drop_ip_checksum")))
 (let (($x1026 (= v_1_wire_flags 0)))
 (let (($x10051 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_packet)))
 (let (($x10050 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_ip_zero)))
 (let (($x10049 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp)))
 (let (($x10048 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_pseudo)))
 (let (($x10047 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp_zero)))
 (let (($x10046 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_data)))
 (let (($x10045 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x1034 (= v_1_take 0)))
 (let (($x1037 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x1038 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x1039 (= v_1_snd_wnd 8)))
 (let (($x10044 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x10043 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x10042 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x1046 (= v_1_local_window 16)))
 (let (($x1047 (= v_1_msl_ms 60000)))
 (let (($x1049 (= v_1_user_timeout_ms 30000)))
 (let (($x1053 (= v_1_retries 0)))
 (let (($x1052 (= v_1_rto_ms 1000)))
 (let (($x1056 (= v_1_tx_ack (_ bv0 32))))
 (let (($x1057 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x1060 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x1061 (= v_1_snd_nxt (_ bv1000 32))))
 (let (($x1062 (= v_1_snd_una (_ bv1000 32))))
 (let (($x1086 (= v_1_irs (_ bv0 32))))
 (let (($x1064 (= v_1_iss (_ bv1000 32))))
 (let (($x918 (= 0 state_1)))
 (let (($x185 (not active_0_time_wait)))
 (let (($x10041 (or $x185 (not (<= due_0_time_wait 0)))))
 (let (($x183 (not active_0_user)))
 (let (($x10038 (or $x183 (not (<= due_0_user 0)))))
 (let (($x181 (not active_0_rtx)))
 (let (($x10035 (or $x181 (not (<= due_0_rtx 0)))))
 (let (($x82 (= state_0 0)))
 (and $x82 (>= 0 now_0) $x10035 $x10038 $x10041 $x918 $x1064 $x1086 $x1062 $x1061 $x1060 $x1057 $x1056 (= v_1_tx_flags "S") $x1052 $x1053 v_1_active_open $x1049 $x1047 $x1046 $x10042 $x10043 $x10044 $x1039 $x1038 $x1037 $x1034 $x10045 $x10046 $x10047 $x10048 $x10049 $x10050 $x10051 $x1026 $x948 $x949 $x950 $x951 $x952 $x953 $x954))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_wire_flags))
(assert
 (= v_0_wire_disposition "none"))
(assert
 (= 119 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x9665 (seq.unit (_ bv72 8))))
(let ((?x9669 (seq.++ ?x9665 (seq.++ (seq.unit (_ bv221 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
(let ((?x9663 (seq.unit (_ bv16 8))))
(let ((?x235 (seq.unit (_ bv0 8))))
(let ((?x9661 (seq.unit (_ bv18 8))))
(let ((?x9659 (seq.unit (_ bv80 8))))
(let ((?x9657 (seq.unit (_ bv233 8))))
(let ((?x9674 (seq.++ ?x9657 (seq.++ ?x9659 (seq.++ ?x9661 (seq.++ ?x235 (seq.++ ?x9663 ?x9669)))))))
(let ((?x9655 (seq.unit (_ bv3 8))))
(let ((?x9647 (seq.unit (_ bv40 8))))
(let ((?x9653 (seq.unit (_ bv35 8))))
(let ((?x9679 (seq.++ ?x9653 (seq.++ ?x9647 (seq.++ ?x235 (seq.++ ?x235 (seq.++ ?x9655 ?x9674)))))))
(let ((?x244 (seq.unit (_ bv64 8))))
(let ((?x280 (seq.unit (_ bv156 8))))
(let ((?x278 (seq.unit (_ bv144 8))))
(let ((?x9684 (seq.++ ?x278 (seq.++ ?x280 (seq.++ ?x244 (seq.++ ?x235 (seq.++ ?x235 ?x9679)))))))
(let ((?x276 (seq.unit (_ bv31 8))))
(let ((?x274 (seq.unit (_ bv1 8))))
(let ((?x272 (seq.unit (_ bv2 8))))
(let ((?x270 (seq.unit (_ bv192 8))))
(let ((?x9689 (seq.++ ?x270 (seq.++ ?x235 (seq.++ ?x272 (seq.++ ?x274 (seq.++ ?x276 ?x9684)))))))
(let ((?x9651 (seq.unit (_ bv204 8))))
(let ((?x9694 (seq.++ ?x9651 (seq.++ ?x270 (seq.++ ?x235 (seq.++ ?x272 (seq.++ ?x272 ?x9689)))))))
(let ((?x9649 (seq.unit (_ bv183 8))))
(let ((?x430 (seq.unit (_ bv6 8))))
(let ((?x9699 (seq.++ ?x244 (seq.++ ?x235 (seq.++ ?x244 (seq.++ ?x430 (seq.++ ?x9649 ?x9694)))))))
(let ((?x9704 (seq.++ ?x235 (seq.++ ?x235 (seq.++ ?x9647 (seq.++ ?x235 (seq.++ ?x235 ?x9699)))))))
(let ((?x233 (seq.unit (_ bv69 8))))
(let ((?x9705 (seq.++ ?x233 ?x9704)))
(= input_0_net.packet_packet ?x9705)))))))))))))))))))))))))))))))
(check-sat)

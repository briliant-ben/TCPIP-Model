; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_wire_disposition () String)
(declare-fun v_1_wire_flags () Int)
(declare-fun v_1_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun due_2_time_wait () Int)
(declare-fun due_2_user () Int)
(declare-fun due_2_rtx () Int)
(declare-fun active_2_time_wait () Bool)
(declare-fun active_2_user () Bool)
(declare-fun active_2_rtx () Bool)
(declare-fun v_2_wire_disposition () String)
(declare-fun v_2_wire_flags () Int)
(declare-fun v_2_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_take () Int)
(declare-fun v_2_snd_wl2 () (_ BitVec 32))
(declare-fun v_2_snd_wl1 () (_ BitVec 32))
(declare-fun v_2_snd_wnd () Int)
(declare-fun v_2_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_local_window () Int)
(declare-fun v_2_msl_ms () Int)
(declare-fun v_2_user_timeout_ms () Int)
(declare-fun v_2_active_open () Bool)
(declare-fun v_2_retries () Int)
(declare-fun v_2_rto_ms () Int)
(declare-fun v_2_tx_flags () String)
(declare-fun v_2_tx_ack () (_ BitVec 32))
(declare-fun v_2_tx_seq () (_ BitVec 32))
(declare-fun v_2_rcv_nxt () (_ BitVec 32))
(declare-fun v_2_snd_nxt () (_ BitVec 32))
(declare-fun v_2_snd_una () (_ BitVec 32))
(declare-fun v_2_irs () (_ BitVec 32))
(declare-fun v_2_iss () (_ BitVec 32))
(declare-fun state_2 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_flags () Int)
(declare-fun v_0_wire_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.packet_packet () (Seq (_ BitVec 8)))
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!10
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!10
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!10
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x16435 (= due_1_time_wait due_0_time_wait)))
 (let (($x49351 (= due_1_user 30000)))
 (let (($x78879 (= due_1_rtx 1000)))
 (let (($x69829 (not active_1_time_wait)))
 (let (($x68437 (= v_1_wire_flags 2)))
 (let ((?x49188 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x68131 (seq.unit (_ bv16 8))))
 (let ((?x58129 (seq.unit (_ bv0 8))))
 (let ((?x23978 (seq.unit (_ bv2 8))))
 (let ((?x19290 (seq.unit (_ bv80 8))))
 (let ((?x49576 (seq.++ ?x58129 (seq.++ ?x19290 (seq.++ ?x23978 (seq.++ ?x58129 (seq.++ ?x68131 ?x49188)))))))
 (let ((?x68197 (seq.unit (_ bv232 8))))
 (let ((?x5191 (seq.unit (_ bv3 8))))
 (let ((?x38015 (seq.++ ?x5191 (seq.++ ?x68197 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x58129 ?x49576)))))))
 (let ((?x48327 (seq.unit (_ bv144 8))))
 (let ((?x48299 (seq.unit (_ bv31 8))))
 (let ((?x48291 (seq.unit (_ bv64 8))))
 (let ((?x68540 (seq.++ ?x48291 (seq.++ ?x48299 (seq.++ ?x48327 (seq.++ ?x58129 (seq.++ ?x58129 ?x38015)))))))
 (let ((?x48302 (seq.unit (_ bv156 8))))
 (let ((?x68541 (seq.++ ?x48302 ?x68540)))
 (let ((?x89741 (seq.unit (_ bv192 8))))
 (let ((?x89719 (seq.unit (_ bv1 8))))
 (let ((?x31498 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 (seq.++ ?x23978 ?x68541)))))))
 (let ((?x57863 (seq.unit (_ bv204 8))))
 (let ((?x57859 (seq.unit (_ bv182 8))))
 (let ((?x49231 (seq.++ ?x57859 (seq.++ ?x57863 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x31498)))))))
 (let ((?x47322 (seq.unit (_ bv6 8))))
 (let ((?x68052 (seq.++ ?x58129 (seq.++ ?x48291 (seq.++ ?x58129 (seq.++ ?x48291 (seq.++ ?x47322 ?x49231)))))))
 (let ((?x140 (seq.unit (_ bv40 8))))
 (let ((?x69642 (seq.unit (_ bv69 8))))
 (let ((?x68263 (seq.++ ?x69642 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x140 (seq.++ ?x58129 ?x68052)))))))
 (let (($x68436 (= v_1_wire_packet ?x68263)))
 (let ((?x26059 (seq.++ ?x23978 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x23978)))))))
 (let ((?x48352 (seq.++ ?x47322 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x89741 (seq.++ ?x58129 ?x26059)))))))
 (let ((?x88249 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x48291 (seq.++ ?x58129 (seq.++ ?x48291 ?x48352)))))))
 (let ((?x57890 (seq.++ ?x69642 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x140 ?x88249))))))
 (let (($x57893 (= v_1_wire_ip_zero ?x57890)))
 (let (($x6707 (= v_1_wire_tcp ?x68541)))
 (let ((?x23932 (seq.++ ?x23978 (seq.++ ?x58129 (seq.++ ?x47322 (seq.++ ?x58129 (seq.unit (_ bv20 8))))))))
 (let ((?x23948 (seq.++ ?x23978 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x23932)))))))
 (let ((?x19469 (seq.++ ?x89741 (seq.++ ?x58129 ?x23948))))
 (let (($x46917 (= v_1_wire_pseudo ?x19469)))
 (let ((?x68091 (seq.++ ?x58129 (seq.++ ?x68131 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x58129 ?x58129)))))))
 (let ((?x58355 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x19290 (seq.++ ?x23978 ?x68091)))))))
 (let ((?x58337 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x5191 (seq.++ ?x68197 (seq.++ ?x58129 ?x58355)))))))
 (let (($x58162 (= v_1_wire_tcp_zero (seq.++ ?x48302 (seq.++ ?x48291 (seq.++ ?x48299 (seq.++ ?x48327 ?x58337)))))))
 (let (($x23920 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_data)))
 (let (($x47092 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x68046 (= v_1_take 0)))
 (let (($x68047 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x68048 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x89751 (= v_1_snd_wnd 8)))
 (let (($x67928 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x67925 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x67926 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x67995 (= v_1_local_window 16)))
 (let (($x67996 (= v_1_msl_ms 60000)))
 (let (($x67997 (= v_1_user_timeout_ms 30000)))
 (let (($x36958 (= 0 v_1_retries)))
 (let (($x48247 (= 1000 v_1_rto_ms)))
 (let (($x97838 (= v_1_tx_flags "S")))
 (let (($x68003 (= v_1_tx_ack (_ bv0 32))))
 (let (($x68002 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x68005 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x67922 (= v_1_snd_nxt (_ bv1001 32))))
 (let (($x68007 (= v_1_snd_una (_ bv1000 32))))
 (let (($x68008 (= v_1_irs (_ bv0 32))))
 (let (($x68009 (= v_1_iss (_ bv1000 32))))
 (let (($x57517 (= 2 state_1)))
 (let (($x16392 (not active_0_time_wait)))
 (let (($x68196 (or $x16392 (not (<= due_0_time_wait 0)))))
 (let (($x16390 (not active_0_user)))
 (let (($x68193 (or $x16390 (not (<= due_0_user 0)))))
 (let (($x16388 (not active_0_rtx)))
 (let (($x68511 (or $x16388 (not (<= due_0_rtx 0)))))
 (let (($x57467 (= state_0 0)))
 (and $x57467 (>= 0 now_0) $x68511 $x68193 $x68196 $x57517 $x68009 $x68008 $x68007 $x67922 $x68005 $x68002 $x68003 $x97838 $x48247 $x36958 v_1_active_open $x67997 $x67996 $x67995 $x67926 $x67925 $x67928 $x89751 $x68048 $x68047 $x68046 $x47092 $x23920 $x58162 $x46917 $x6707 $x57893 $x68436 $x68437 (= v_1_wire_disposition "none") active_1_rtx active_1_user $x69829 $x78879 $x49351 $x16435))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x37512 (= due_2_time_wait due_1_time_wait)))
 (let (($x37511 (= due_2_user due_1_user)))
 (let (($x37510 (= due_2_rtx due_1_rtx)))
 (let (($x37509 (= active_2_time_wait active_1_time_wait)))
 (let (($x5821 (not active_2_user)))
 (let (($x5820 (not active_2_rtx)))
 (let (($x37506 (= v_2_wire_disposition "protocol")))
 (let (($x5819 (= v_2_wire_flags 16)))
 (let ((?x58129 (seq.unit (_ bv0 8))))
 (let ((?x58671 (seq.++ ?x58129 ?x58129)))
 (let ((?x47405 (seq.++ ?x58129 (seq.++ ?x58129 ?x58671))))
 (let ((?x37456 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) v_1_local_window)))))
 (let ((?x37454 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) v_1_local_window)))))
 (let ((?x68131 (seq.unit (_ bv16 8))))
 (let ((?x19290 (seq.unit (_ bv80 8))))
 (let ((?x107286 (seq.unit (_ bv41 8))))
 (let ((?x88867 (seq.++ ?x107286 (seq.++ ?x19290 (seq.++ ?x68131 (seq.++ ?x37454 (seq.++ ?x37456 ?x47405)))))))
 (let ((?x5189 (seq.unit (_ bv35 8))))
 (let ((?x58346 (seq.unit ((_ extract 7 0) v_1_snd_nxt))))
 (let ((?x68250 (seq.unit ((_ extract 15 8) v_1_snd_nxt))))
 (let ((?x47364 (seq.++ ?x68250 (seq.++ ?x58346 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x5189 ?x88867)))))))
 (let ((?x47188 (seq.unit ((_ extract 23 16) v_1_snd_nxt))))
 (let ((?x49913 (seq.unit ((_ extract 31 24) v_1_snd_nxt))))
 (let ((?x48327 (seq.unit (_ bv144 8))))
 (let ((?x48299 (seq.unit (_ bv31 8))))
 (let ((?x48291 (seq.unit (_ bv64 8))))
 (let ((?x78461 (seq.++ ?x48291 (seq.++ ?x48299 (seq.++ ?x48327 (seq.++ ?x49913 (seq.++ ?x47188 ?x47364)))))))
 (let ((?x48302 (seq.unit (_ bv156 8))))
 (let ((?x49619 (seq.++ ?x48302 ?x78461)))
 (let ((?x24006 (seq.unit (_ bv20 8))))
 (let ((?x47322 (seq.unit (_ bv6 8))))
 (let ((?x23978 (seq.unit (_ bv2 8))))
 (let ((?x5318 (seq.++ ?x23978 (seq.++ ?x58129 (seq.++ ?x47322 (seq.++ ?x58129 (seq.++ ?x24006 ?x49619)))))))
 (let ((?x89741 (seq.unit (_ bv192 8))))
 (let ((?x89719 (seq.unit (_ bv1 8))))
 (let ((?x5323 (seq.++ ?x23978 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x5318)))))))
 (let ((?x5326 ((_ ir4_ones_sum16_checksum_instance!10 0) (seq.++ ?x89741 (seq.++ ?x58129 ?x5323)))))
 (let ((?x5414 (seq.++ (seq.unit (bvnot ((_ extract 15 8) ?x5326))) (seq.++ (seq.unit (bvnot ((_ extract 7 0) ?x5326))) ?x58671))))
 (let ((?x5419 (seq.++ ?x107286 (seq.++ ?x19290 (seq.++ ?x68131 (seq.++ ?x37454 (seq.++ ?x37456 ?x5414)))))))
 (let ((?x5424 (seq.++ ?x68250 (seq.++ ?x58346 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x5189 ?x5419)))))))
 (let ((?x5429 (seq.++ ?x48291 (seq.++ ?x48299 (seq.++ ?x48327 (seq.++ ?x49913 (seq.++ ?x47188 ?x5424)))))))
 (let ((?x5430 (seq.++ ?x48302 ?x5429)))
 (let ((?x5802 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 (seq.++ ?x23978 ?x5430)))))))
 (let ((?x57863 (seq.unit (_ bv204 8))))
 (let ((?x57859 (seq.unit (_ bv182 8))))
 (let ((?x5807 (seq.++ ?x57859 (seq.++ ?x57863 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x5802)))))))
 (let ((?x5812 (seq.++ ?x58129 (seq.++ ?x48291 (seq.++ ?x58129 (seq.++ ?x48291 (seq.++ ?x47322 ?x5807)))))))
 (let ((?x140 (seq.unit (_ bv40 8))))
 (let ((?x69642 (seq.unit (_ bv69 8))))
 (let ((?x5817 (seq.++ ?x69642 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x140 (seq.++ ?x58129 ?x5812)))))))
 (let (($x5818 (= v_2_wire_packet ?x5817)))
 (let ((?x26059 (seq.++ ?x23978 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x23978)))))))
 (let ((?x48352 (seq.++ ?x47322 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x89741 (seq.++ ?x58129 ?x26059)))))))
 (let ((?x88249 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x48291 (seq.++ ?x58129 (seq.++ ?x48291 ?x48352)))))))
 (let ((?x57890 (seq.++ ?x69642 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x140 ?x88249))))))
 (let (($x5440 (= v_2_wire_ip_zero ?x57890)))
 (let (($x5431 (= v_2_wire_tcp ?x5430)))
 (let ((?x108800 (seq.++ ?x23978 (seq.++ ?x23978 (seq.++ ?x58129 (seq.++ ?x47322 (seq.++ ?x58129 ?x24006)))))))
 (let ((?x19472 (seq.++ ?x58129 (seq.++ ?x23978 (seq.++ ?x89719 (seq.++ ?x89741 (seq.++ ?x58129 ?x108800)))))))
 (let ((?x19469 (seq.++ ?x89741 ?x19472)))
 (let (($x5290 (= v_2_wire_pseudo ?x19469)))
 (let (($x5272 (= v_2_wire_tcp_zero ?x49619)))
 (let (($x47067 (= (as seq.empty (Seq (_ BitVec 8))) v_2_wire_data)))
 (let (($x37498 (= v_2_rx_chunk v_1_rx_chunk)))
 (let (($x37497 (= v_2_take v_1_take)))
 (let (($x49340 (= v_2_snd_wl2 (_ bv1001 32))))
 (let (($x49360 (= v_2_snd_wl1 (_ bv9000 32))))
 (let (($x49359 (= v_2_snd_wnd 16)))
 (let (($x37493 (= v_2_rcv_buf v_1_rcv_buf)))
 (let (($x37492 (= v_2_rtx_buf v_1_rtx_buf)))
 (let (($x37491 (= v_2_snd_buf v_1_snd_buf)))
 (let (($x37490 (= v_2_local_window v_1_local_window)))
 (let (($x37489 (= v_2_msl_ms v_1_msl_ms)))
 (let (($x37488 (= v_2_user_timeout_ms v_1_user_timeout_ms)))
 (let (($x37487 (= v_2_active_open v_1_active_open)))
 (let (($x37486 (= v_2_retries v_1_retries)))
 (let (($x37485 (= v_2_rto_ms v_1_rto_ms)))
 (let (($x37484 (= v_2_tx_flags v_1_tx_flags)))
 (let (($x37483 (= v_2_tx_ack v_1_tx_ack)))
 (let (($x37482 (= v_2_tx_seq v_1_tx_seq)))
 (let (($x19279 (= v_2_rcv_nxt (_ bv9001 32))))
 (let (($x37480 (= v_2_snd_nxt v_1_snd_nxt)))
 (let (($x68167 (= v_2_snd_una (_ bv1001 32))))
 (let (($x34699 (= v_2_irs (_ bv9000 32))))
 (let (($x37477 (= v_2_iss v_1_iss)))
 (let (($x37476 (= 4 state_2)))
 (let (($x69829 (not active_1_time_wait)))
 (let (($x47030 (or $x69829 (not (<= due_1_time_wait 10)))))
 (let (($x68447 (or (not active_1_user) (not (<= due_1_user 10)))))
 (let (($x49529 (or (not active_1_rtx) (not (<= due_1_rtx 10)))))
 (let (($x36958 (= 0 v_1_retries)))
 (let (($x67922 (= v_1_snd_nxt (_ bv1001 32))))
 (let (($x24158 (= state_1 2)))
 (and $x24158 $x67922 $x36958 $x49529 $x68447 $x47030 $x37476 $x37477 $x34699 $x68167 $x37480 $x19279 $x37482 $x37483 $x37484 $x37485 $x37486 $x37487 $x37488 $x37489 $x37490 $x37491 $x37492 $x37493 $x49359 $x49360 $x49340 $x37497 $x37498 $x47067 $x5272 $x5290 $x5431 $x5440 $x5818 $x5819 $x37506 $x5820 $x5821 $x37509 $x37510 $x37511 $x37512)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_wire_flags))
(assert
 (= v_0_wire_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 4 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x23978 (seq.unit (_ bv2 8))))
(let ((?x5208 (seq.++ ?x23978 (seq.++ (seq.unit (_ bv4 8)) (seq.++ (seq.unit (_ bv5 8)) (seq.unit (_ bv180 8)))))))
(let ((?x58129 (seq.unit (_ bv0 8))))
(let ((?x5201 (seq.unit (_ bv33 8))))
(let ((?x5199 (seq.unit (_ bv49 8))))
(let ((?x68131 (seq.unit (_ bv16 8))))
(let ((?x5213 (seq.++ ?x68131 (seq.++ ?x5199 (seq.++ ?x5201 (seq.++ ?x58129 (seq.++ ?x58129 ?x5208)))))))
(let ((?x5197 (seq.unit (_ bv18 8))))
(let ((?x5195 (seq.unit (_ bv96 8))))
(let ((?x5193 (seq.unit (_ bv233 8))))
(let ((?x5191 (seq.unit (_ bv3 8))))
(let ((?x5218 (seq.++ ?x5191 (seq.++ ?x5193 (seq.++ ?x5195 (seq.++ ?x5197 (seq.++ ?x58129 ?x5213)))))))
(let ((?x140 (seq.unit (_ bv40 8))))
(let ((?x5189 (seq.unit (_ bv35 8))))
(let ((?x5223 (seq.++ ?x58129 (seq.++ ?x5189 (seq.++ ?x140 (seq.++ ?x58129 (seq.++ ?x58129 ?x5218)))))))
(let ((?x48291 (seq.unit (_ bv64 8))))
(let ((?x48302 (seq.unit (_ bv156 8))))
(let ((?x48327 (seq.unit (_ bv144 8))))
(let ((?x48299 (seq.unit (_ bv31 8))))
(let ((?x5228 (seq.++ ?x48299 (seq.++ ?x48327 (seq.++ ?x48302 (seq.++ ?x48291 (seq.++ ?x58129 ?x5223)))))))
(let ((?x89719 (seq.unit (_ bv1 8))))
(let ((?x89741 (seq.unit (_ bv192 8))))
(let ((?x5233 (seq.++ ?x23978 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 (seq.++ ?x89719 ?x5228)))))))
(let ((?x5187 (seq.unit (_ bv200 8))))
(let ((?x5185 (seq.unit (_ bv245 8))))
(let ((?x5238 (seq.++ ?x5185 (seq.++ ?x5187 (seq.++ ?x89741 (seq.++ ?x58129 (seq.++ ?x23978 ?x5233)))))))
(let ((?x47322 (seq.unit (_ bv6 8))))
(let ((?x5183 (seq.unit (_ bv255 8))))
(let ((?x5243 (seq.++ ?x5183 (seq.++ ?x48291 (seq.++ ?x58129 (seq.++ ?x89719 (seq.++ ?x47322 ?x5238)))))))
(let ((?x5181 (seq.unit (_ bv44 8))))
(let ((?x69642 (seq.unit (_ bv69 8))))
(let ((?x5248 (seq.++ ?x69642 (seq.++ ?x58129 (seq.++ ?x58129 (seq.++ ?x5181 (seq.++ ?x5183 ?x5243)))))))
(= input_1_net.packet_packet ?x5248))))))))))))))))))))))))))))))))))
(check-sat)

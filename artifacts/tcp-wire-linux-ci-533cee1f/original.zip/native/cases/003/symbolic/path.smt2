; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_wire_disposition () String)
(declare-fun v_1_wire_flags () Int)
(declare-fun v_1_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_flags () Int)
(declare-fun v_0_wire_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x580 (= due_1_time_wait due_0_time_wait)))
 (let (($x579 (= due_1_user due_0_user)))
 (let (($x578 (= due_1_rtx due_0_rtx)))
 (let (($x577 (= active_1_time_wait active_0_time_wait)))
 (let (($x576 (= active_1_user active_0_user)))
 (let (($x575 (= active_1_rtx active_0_rtx)))
 (let (($x574 (= v_1_wire_disposition "drop_tcp_length")))
 (let (($x1376 (= v_1_wire_flags 0)))
 (let (($x9949 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_packet)))
 (let (($x117 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_ip_zero)))
 (let (($x917 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp)))
 (let (($x10414 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_pseudo)))
 (let (($x10413 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp_zero)))
 (let (($x10412 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_data)))
 (let (($x10411 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x1386 (= v_1_take 0)))
 (let (($x752 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x756 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x755 (= v_1_snd_wnd 8)))
 (let (($x10410 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x10409 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x10408 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x1359 (= v_1_local_window 16)))
 (let (($x762 (= v_1_msl_ms 60000)))
 (let (($x1362 (= v_1_user_timeout_ms 30000)))
 (let (($x1364 (= v_1_retries 0)))
 (let (($x1365 (= v_1_rto_ms 1000)))
 (let (($x1369 (= v_1_tx_ack (_ bv0 32))))
 (let (($x1370 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x1368 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x1371 (= v_1_snd_nxt (_ bv1000 32))))
 (let (($x667 (= v_1_snd_una (_ bv1000 32))))
 (let (($x669 (= v_1_irs (_ bv0 32))))
 (let (($x199 (= v_1_iss (_ bv1000 32))))
 (let (($x544 (= 0 state_1)))
 (let (($x10694 (not active_0_time_wait)))
 (let (($x10407 (or $x10694 (not (<= due_0_time_wait 0)))))
 (let (($x10692 (not active_0_user)))
 (let (($x10403 (or $x10692 (not (<= due_0_user 0)))))
 (let (($x10037 (not active_0_rtx)))
 (let (($x10236 (or $x10037 (not (<= due_0_rtx 0)))))
 (let (($x9908 (= state_0 0)))
 (and $x9908 (>= 0 now_0) $x10236 $x10403 $x10407 $x544 $x199 $x669 $x667 $x1371 $x1368 $x1370 $x1369 (= v_1_tx_flags "S") $x1365 $x1364 v_1_active_open $x1362 $x762 $x1359 $x10408 $x10409 $x10410 $x755 $x756 $x752 $x1386 $x10411 $x10412 $x10413 $x10414 $x917 $x117 $x9949 $x1376 $x574 $x575 $x576 $x577 $x578 $x579 $x580))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_wire_flags))
(assert
 (= v_0_wire_disposition "none"))
(assert
 (= 120 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1304 (seq.unit (_ bv88 8))))
(let ((?x1322 (seq.++ ?x1304 (seq.++ (seq.unit (_ bv221 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
(let ((?x1308 (seq.unit (_ bv16 8))))
(let ((?x10699 (seq.unit (_ bv0 8))))
(let ((?x1241 (seq.unit (_ bv18 8))))
(let ((?x10703 (seq.unit (_ bv64 8))))
(let ((?x1243 (seq.unit (_ bv233 8))))
(let ((?x1323 (seq.++ ?x1243 (seq.++ ?x10703 (seq.++ ?x1241 (seq.++ ?x10699 (seq.++ ?x1308 ?x1322)))))))
(let ((?x1264 (seq.unit (_ bv3 8))))
(let ((?x122 (seq.unit (_ bv40 8))))
(let ((?x1254 (seq.unit (_ bv35 8))))
(let ((?x10217 (seq.++ ?x1254 (seq.++ ?x122 (seq.++ ?x10699 (seq.++ ?x10699 (seq.++ ?x1264 ?x1323)))))))
(let ((?x1223 (seq.unit (_ bv156 8))))
(let ((?x1226 (seq.unit (_ bv144 8))))
(let ((?x10222 (seq.++ ?x1226 (seq.++ ?x1223 (seq.++ ?x10703 (seq.++ ?x10699 (seq.++ ?x10699 ?x10217)))))))
(let ((?x1320 (seq.unit (_ bv31 8))))
(let ((?x1230 (seq.unit (_ bv1 8))))
(let ((?x1246 (seq.unit (_ bv2 8))))
(let ((?x852 (seq.unit (_ bv192 8))))
(let ((?x30 (seq.++ ?x852 (seq.++ ?x10699 (seq.++ ?x1246 (seq.++ ?x1230 (seq.++ ?x1320 ?x10222)))))))
(let ((?x1279 (seq.unit (_ bv204 8))))
(let ((?x879 (seq.++ ?x1279 (seq.++ ?x852 (seq.++ ?x10699 (seq.++ ?x1246 (seq.++ ?x1246 ?x30)))))))
(let ((?x1267 (seq.unit (_ bv182 8))))
(let ((?x821 (seq.unit (_ bv6 8))))
(let ((?x783 (seq.++ ?x10703 (seq.++ ?x10699 (seq.++ ?x10703 (seq.++ ?x821 (seq.++ ?x1267 ?x879)))))))
(let ((?x1312 (seq.++ ?x10699 (seq.++ ?x10699 (seq.++ ?x122 (seq.++ ?x10699 (seq.++ ?x10699 ?x783)))))))
(let ((?x1031 (seq.unit (_ bv69 8))))
(let ((?x1358 (seq.++ ?x1031 ?x1312)))
(= input_0_net.packet_packet ?x1358))))))))))))))))))))))))))))))
(check-sat)

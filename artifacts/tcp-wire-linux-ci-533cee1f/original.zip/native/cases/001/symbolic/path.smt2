; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_wire_disposition () String)
(declare-fun v_1_wire_flags () Int)
(declare-fun v_1_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_flags () Int)
(declare-fun v_0_wire_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x823 (= due_1_time_wait due_0_time_wait)))
 (let (($x822 (= due_1_user due_0_user)))
 (let (($x821 (= due_1_rtx due_0_rtx)))
 (let (($x820 (= active_1_time_wait active_0_time_wait)))
 (let (($x819 (= active_1_user active_0_user)))
 (let (($x818 (= active_1_rtx active_0_rtx)))
 (let (($x817 (= v_1_wire_disposition "drop_ip_length")))
 (let (($x996 (= v_1_wire_flags 0)))
 (let (($x24 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_packet)))
 (let (($x145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_ip_zero)))
 (let (($x21 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp)))
 (let (($x134 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_pseudo)))
 (let (($x18 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp_zero)))
 (let (($x118 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_data)))
 (let (($x123 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x984 (= v_1_take 0)))
 (let (($x988 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x987 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x990 (= v_1_snd_wnd 8)))
 (let (($x13 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x11 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x40 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x999 (= v_1_local_window 16)))
 (let (($x994 (= v_1_msl_ms 60000)))
 (let (($x897 (= v_1_user_timeout_ms 30000)))
 (let (($x898 (= v_1_retries 0)))
 (let (($x1001 (= v_1_rto_ms 1000)))
 (let (($x1003 (= v_1_tx_ack (_ bv0 32))))
 (let (($x1004 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x1007 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x1008 (= v_1_snd_nxt (_ bv1000 32))))
 (let (($x1009 (= v_1_snd_una (_ bv1000 32))))
 (let (($x1010 (= v_1_irs (_ bv0 32))))
 (let (($x17 (= v_1_iss (_ bv1000 32))))
 (let (($x787 (= 0 state_1)))
 (let (($x10041 (not active_0_time_wait)))
 (let (($x39 (or $x10041 (not (<= due_0_time_wait 0)))))
 (let (($x10039 (not active_0_user)))
 (let (($x10036 (or $x10039 (not (<= due_0_user 0)))))
 (let (($x185 (not active_0_rtx)))
 (let (($x1006 (or $x185 (not (<= due_0_rtx 0)))))
 (let (($x9692 (= state_0 0)))
 (and $x9692 (>= 0 now_0) $x1006 $x10036 $x39 $x787 $x17 $x1010 $x1009 $x1008 $x1007 $x1004 $x1003 (= v_1_tx_flags "S") $x1001 $x898 v_1_active_open $x897 $x994 $x999 $x40 $x11 $x13 $x990 $x987 $x988 $x984 $x123 $x118 $x18 $x134 $x21 $x145 $x24 $x996 $x817 $x818 $x819 $x820 $x821 $x822 $x823))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_wire_flags))
(assert
 (= v_0_wire_disposition "none"))
(assert
 (= 118 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x9938 (seq.unit (_ bv72 8))))
(let ((?x9942 (seq.++ ?x9938 (seq.++ (seq.unit (_ bv221 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
(let ((?x9936 (seq.unit (_ bv16 8))))
(let ((?x10046 (seq.unit (_ bv0 8))))
(let ((?x9934 (seq.unit (_ bv18 8))))
(let ((?x1022 (seq.unit (_ bv80 8))))
(let ((?x1018 (seq.unit (_ bv233 8))))
(let ((?x1103 (seq.++ ?x1018 (seq.++ ?x1022 (seq.++ ?x9934 (seq.++ ?x10046 (seq.++ ?x9936 ?x9942)))))))
(let ((?x1021 (seq.unit (_ bv3 8))))
(let ((?x955 (seq.unit (_ bv40 8))))
(let ((?x946 (seq.unit (_ bv35 8))))
(let ((?x172 (seq.++ ?x946 (seq.++ ?x955 (seq.++ ?x10046 (seq.++ ?x10046 (seq.++ ?x1021 ?x1103)))))))
(let ((?x10050 (seq.unit (_ bv64 8))))
(let ((?x1108 (seq.unit (_ bv156 8))))
(let ((?x1083 (seq.unit (_ bv144 8))))
(let ((?x1044 (seq.++ ?x1083 (seq.++ ?x1108 (seq.++ ?x10050 (seq.++ ?x10046 (seq.++ ?x10046 ?x172)))))))
(let ((?x1130 (seq.unit (_ bv31 8))))
(let ((?x1027 (seq.unit (_ bv1 8))))
(let ((?x1115 (seq.unit (_ bv2 8))))
(let ((?x1091 (seq.unit (_ bv192 8))))
(let ((?x170 (seq.++ ?x1091 (seq.++ ?x10046 (seq.++ ?x1115 (seq.++ ?x1027 (seq.++ ?x1130 ?x1044)))))))
(let ((?x944 (seq.unit (_ bv203 8))))
(let ((?x9834 (seq.++ ?x944 (seq.++ ?x1091 (seq.++ ?x10046 (seq.++ ?x1115 (seq.++ ?x1115 ?x170)))))))
(let ((?x942 (seq.unit (_ bv182 8))))
(let ((?x262 (seq.unit (_ bv6 8))))
(let ((?x9839 (seq.++ ?x10050 (seq.++ ?x10046 (seq.++ ?x10050 (seq.++ ?x262 (seq.++ ?x942 ?x9834)))))))
(let ((?x940 (seq.unit (_ bv41 8))))
(let ((?x9844 (seq.++ ?x10046 (seq.++ ?x10046 (seq.++ ?x940 (seq.++ ?x10046 (seq.++ ?x10046 ?x9839)))))))
(let ((?x67 (seq.unit (_ bv69 8))))
(let ((?x9845 (seq.++ ?x67 ?x9844)))
(= input_0_net.packet_packet ?x9845))))))))))))))))))))))))))))))))
(check-sat)

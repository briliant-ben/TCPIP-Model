; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_wire_disposition () String)
(declare-fun v_1_wire_flags () Int)
(declare-fun v_1_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_wire_flags () Int)
(declare-fun v_0_wire_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x48040 (= due_1_time_wait due_0_time_wait)))
 (let (($x23980 (= due_1_user due_0_user)))
 (let (($x19511 (= due_1_rtx due_0_rtx)))
 (let (($x19521 (= active_1_time_wait active_0_time_wait)))
 (let (($x58132 (= active_1_user active_0_user)))
 (let (($x19632 (= active_1_rtx active_0_rtx)))
 (let (($x12668 (= v_1_wire_disposition "drop_short")))
 (let (($x19097 (= v_1_wire_flags 0)))
 (let (($x58537 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_packet)))
 (let (($x58586 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_ip_zero)))
 (let (($x107199 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp)))
 (let (($x48290 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_pseudo)))
 (let (($x19693 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_tcp_zero)))
 (let (($x47046 (= (as seq.empty (Seq (_ BitVec 8))) v_1_wire_data)))
 (let (($x34499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x34517 (= v_1_take 0)))
 (let (($x58585 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x19299 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x19300 (= v_1_snd_wnd 8)))
 (let (($x2695 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x18995 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x58656 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x3999 (= v_1_local_window 16)))
 (let (($x25668 (= v_1_msl_ms 60000)))
 (let (($x25227 (= v_1_user_timeout_ms 30000)))
 (let (($x12820 (= v_1_retries 0)))
 (let (($x79549 (= v_1_rto_ms 1000)))
 (let (($x47376 (= v_1_tx_ack (_ bv0 32))))
 (let (($x36710 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x48340 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x19719 (= v_1_snd_nxt (_ bv1000 32))))
 (let (($x19720 (= v_1_snd_una (_ bv1000 32))))
 (let (($x19135 (= v_1_irs (_ bv0 32))))
 (let (($x19136 (= v_1_iss (_ bv1000 32))))
 (let (($x68760 (= 0 state_1)))
 (let (($x30892 (not active_0_time_wait)))
 (let (($x19290 (or $x30892 (not (<= due_0_time_wait 0)))))
 (let (($x89690 (not active_0_user)))
 (let (($x41284 (or $x89690 (not (<= due_0_user 0)))))
 (let (($x69981 (not active_0_rtx)))
 (let (($x19692 (or $x69981 (not (<= due_0_rtx 0)))))
 (let (($x70424 (= state_0 0)))
 (and $x70424 (>= 0 now_0) $x19692 $x41284 $x19290 $x68760 $x19136 $x19135 $x19720 $x19719 $x48340 $x36710 $x47376 (= v_1_tx_flags "S") $x79549 $x12820 v_1_active_open $x25227 $x25668 $x3999 $x58656 $x18995 $x2695 $x19300 $x19299 $x58585 $x34517 $x34499 $x47046 $x19693 $x48290 $x107199 $x58586 $x58537 $x19097 $x12668 $x19632 $x58132 $x19521 $x19511 $x23980 $x48040))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_wire_flags))
(assert
 (= v_0_wire_disposition "none"))
(assert
 (= 117 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x23151 (seq.unit (_ bv16 8))))
(let ((?x23158 (seq.++ ?x23151 (seq.++ (seq.unit (_ bv72 8)) (seq.++ (seq.unit (_ bv221 8)) (seq.unit (_ bv0 8)))))))
(let ((?x70558 (seq.unit (_ bv0 8))))
(let ((?x23149 (seq.unit (_ bv18 8))))
(let ((?x23147 (seq.unit (_ bv80 8))))
(let ((?x23145 (seq.unit (_ bv233 8))))
(let ((?x23143 (seq.unit (_ bv3 8))))
(let ((?x23163 (seq.++ ?x23143 (seq.++ ?x23145 (seq.++ ?x23147 (seq.++ ?x23149 (seq.++ ?x70558 ?x23158)))))))
(let ((?x23135 (seq.unit (_ bv40 8))))
(let ((?x23141 (seq.unit (_ bv35 8))))
(let ((?x23168 (seq.++ ?x70558 (seq.++ ?x23141 (seq.++ ?x23135 (seq.++ ?x70558 (seq.++ ?x70558 ?x23163)))))))
(let ((?x70566 (seq.unit (_ bv64 8))))
(let ((?x38318 (seq.unit (_ bv156 8))))
(let ((?x48313 (seq.unit (_ bv144 8))))
(let ((?x48308 (seq.unit (_ bv31 8))))
(let ((?x23173 (seq.++ ?x48308 (seq.++ ?x48313 (seq.++ ?x38318 (seq.++ ?x70566 (seq.++ ?x70558 ?x23168)))))))
(let ((?x48291 (seq.unit (_ bv1 8))))
(let ((?x48327 (seq.unit (_ bv2 8))))
(let ((?x48325 (seq.unit (_ bv192 8))))
(let ((?x23178 (seq.++ ?x48327 (seq.++ ?x48325 (seq.++ ?x70558 (seq.++ ?x48327 (seq.++ ?x48291 ?x23173)))))))
(let ((?x23139 (seq.unit (_ bv204 8))))
(let ((?x23137 (seq.unit (_ bv182 8))))
(let ((?x23183 (seq.++ ?x23137 (seq.++ ?x23139 (seq.++ ?x48325 (seq.++ ?x70558 (seq.++ ?x48327 ?x23178)))))))
(let ((?x70863 (seq.unit (_ bv6 8))))
(let ((?x23188 (seq.++ ?x70558 (seq.++ ?x70566 (seq.++ ?x70558 (seq.++ ?x70566 (seq.++ ?x70863 ?x23183)))))))
(let ((?x70557 (seq.unit (_ bv69 8))))
(let ((?x23193 (seq.++ ?x70557 (seq.++ ?x70558 (seq.++ ?x70558 (seq.++ ?x23135 (seq.++ ?x70558 ?x23188)))))))
(= input_0_net.packet_packet ?x23193)))))))))))))))))))))))))))))
(check-sat)

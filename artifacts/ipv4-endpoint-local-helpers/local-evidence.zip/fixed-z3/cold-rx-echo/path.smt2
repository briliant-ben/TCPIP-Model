; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x622 (= due_1_cache due_0_cache)))
 (let (($x621 (= due_1_query due_0_query)))
 (let (($x620 (= active_1_cache active_0_cache)))
 (let (($x619 (= active_1_query active_0_query)))
 (let (($x4513 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x4512 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x4511 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x4510 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x613 (= v_1_rxudp_disposition "deliver")))
 (let ((?x4110 (seq.unit (_ bv128 8))))
 (let ((?x2772 (seq.++ ?x4110 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x197 (seq.unit (_ bv0 8))))
 (let ((?x2780 (seq.++ ?x197 ?x2772)))
 (let (($x4509 (= v_1_rxudp_payload ?x2780)))
 (let (($x2310 (not v_1_rxudp_require_checksum)))
 (let (($x4502 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2632 (= v_1_ip_checksum 0)))
 (let (($x2635 (= v_1_udp_checksum 0)))
 (let (($x2636 (= v_1_udp_raw_checksum 0)))
 (let (($x2637 (= v_1_ip_length 0)))
 (let (($x2638 (= v_1_udp_length 0)))
 (let (($x4501 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4500 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4498 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4497 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x4496 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4495 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x2890 (= v_1_cache_ttl_ms 60000)))
 (let (($x2891 (= v_1_retry_count 0)))
 (let (($x4494 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x593 (= 0 state_1)))
 (let (($x181 (not active_0_cache)))
 (let (($x4493 (or $x181 (not (<= due_0_cache 0)))))
 (let (($x179 (not active_0_query)))
 (let (($x4490 (or $x179 (not (<= due_0_query 0)))))
 (let (($x99 (= state_0 0)))
 (and $x99 (>= 0 now_0) $x4490 $x4493 $x593 $x4494 $x2891 $x2890 v_1_checksums_enabled $x4495 $x4496 $x4497 $x4498 $x4499 $x4500 $x4501 $x2638 $x2637 $x2636 $x2635 $x2632 $x4502 $x2310 $x4509 $x613 $x4510 $x4511 $x4512 $x4513 (= v_1_echo_disposition "none") $x619 $x620 $x621 $x622)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2576 (= due_2_cache due_1_cache)))
 (let (($x2575 (= due_2_query due_1_query)))
 (let (($x2574 (= active_2_cache active_1_cache)))
 (let (($x2573 (= active_2_query active_1_query)))
 (let (($x2572 (= v_2_echo_disposition "reply")))
 (let ((?x195 (seq.unit (_ bv192 8))))
 (let ((?x202 (seq.++ ?x195 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x244 (seq.unit (_ bv1 8))))
 (let ((?x199 (seq.unit (_ bv2 8))))
 (let ((?x197 (seq.unit (_ bv0 8))))
 (let ((?x2462 (seq.++ ?x197 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x244 ?x202)))))))
 (let ((?x433 (seq.unit (_ bv64 8))))
 (let ((?x2467 (seq.++ ?x433 (seq.++ ?x197 (seq.++ ?x433 (seq.++ ?x244 (seq.++ ?x197 ?x2462)))))))
 (let ((?x2469 (seq.++ ?x197 (seq.++ ?x197 ?x2467))))
 (let ((?x4098 (seq.unit (_ bv33 8))))
 (let ((?x427 (seq.unit (_ bv69 8))))
 (let (($x4735 (= v_2_echo_ip_zero (seq.++ ?x427 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x4098 ?x2469)))))))
 (let ((?x4110 (seq.unit (_ bv128 8))))
 (let ((?x2780 (seq.++ ?x197 (seq.++ ?x4110 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x197))))))
 (let ((?x4176 (seq.unit (_ bv205 8))))
 (let ((?x4174 (seq.unit (_ bv171 8))))
 (let ((?x4172 (seq.unit (_ bv52 8))))
 (let ((?x4170 (seq.unit (_ bv18 8))))
 (let ((?x960 (seq.++ ?x4170 (seq.++ ?x4172 (seq.++ ?x4174 (seq.++ ?x4176 ?x2780))))))
 (let ((?x4168 (seq.unit (_ bv118 8))))
 (let ((?x4675 (seq.++ ?x197 (seq.++ ?x197 (seq.++ (seq.unit (_ bv66 8)) (seq.++ ?x4168 ?x960))))))
 (let (($x4734 (= v_2_echo_icmp_wire ?x4675)))
 (let (($x4733 (= v_2_echo_icmp_zero (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x960)))))))
 (let ((?x4716 (seq.++ ?x244 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x199 ?x4675)))))))
 (let ((?x4164 (seq.unit (_ bv216 8))))
 (let ((?x4721 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x4164 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 ?x4716)))))))
 (let ((?x4726 (seq.++ ?x197 (seq.++ ?x433 (seq.++ ?x197 (seq.++ ?x433 (seq.++ ?x244 ?x4721)))))))
 (let ((?x4731 (seq.++ ?x427 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x4098 (seq.++ ?x197 ?x4726)))))))
 (let (($x4732 (= v_2_echo_reply ?x4731)))
 (let (($x2567 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2566 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x2565 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x2564 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x2563 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2562 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2561 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2560 (= v_2_ip_length v_1_ip_length)))
 (let (($x2559 (= v_2_udp_length v_1_udp_length)))
 (let (($x2558 (= v_2_packet v_1_packet)))
 (let (($x2557 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2556 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2555 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2554 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2553 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2552 (= v_2_payload v_1_payload)))
 (let (($x2551 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2550 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2549 (= v_2_retry_count v_1_retry_count)))
 (let (($x2548 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x2547 (= 0 state_2)))
 (let (($x2930 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x1010 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x1074 (= state_1 0)))
 (and $x1074 $x1010 $x2930 $x2547 $x2548 $x2549 $x2550 $x2551 $x2552 $x2553 $x2554 $x2555 $x2556 $x2557 $x2558 $x2559 $x2560 $x2561 $x2562 $x2563 $x2564 $x2565 $x2566 $x2567 $x4732 $x4733 $x4734 $x4735 $x2572 $x2573 $x2574 $x2575 $x2576))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x197 (seq.unit (_ bv0 8))))
 (let ((?x2433 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x197)))))
 (let ((?x2501 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2433)))))))
 (let ((?x2506 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2501)))))))
 (let ((?x4112 (seq.unit (_ bv7 8))))
 (let ((?x252 (seq.unit (_ bv255 8))))
 (let ((?x4110 (seq.unit (_ bv128 8))))
 (let ((?x4116 (seq.++ ?x197 (seq.++ ?x4110 (seq.++ ?x252 (seq.++ ?x4112 ?x2506))))))
 (let ((?x195 (seq.unit (_ bv192 8))))
 (let ((?x4120 (seq.++ ?x197 (seq.++ (seq.unit (_ bv13 8)) (seq.++ ?x195 (seq.++ (seq.unit (_ bv119 8)) ?x4116))))))
 (let ((?x433 (seq.unit (_ bv64 8))))
 (let ((?x447 (seq.unit (_ bv156 8))))
 (let ((?x445 (seq.unit (_ bv144 8))))
 (let ((?x443 (seq.unit (_ bv31 8))))
 (let ((?x244 (seq.unit (_ bv1 8))))
 (let ((?x4125 (seq.++ ?x244 (seq.++ ?x443 (seq.++ ?x445 (seq.++ ?x447 (seq.++ ?x433 ?x4120)))))))
 (let ((?x199 (seq.unit (_ bv2 8))))
 (let ((?x4130 (seq.++ ?x199 (seq.++ ?x199 (seq.++ ?x195 (seq.++ ?x197 (seq.++ ?x199 ?x4125)))))))
 (let ((?x4134 (seq.++ (seq.unit (_ bv177 8)) (seq.++ (seq.unit (_ bv246 8)) (seq.++ ?x195 (seq.++ ?x197 ?x4130))))))
 (let ((?x435 (seq.unit (_ bv17 8))))
 (let ((?x4139 (seq.++ (seq.unit (_ bv210 8)) (seq.++ ?x433 (seq.++ ?x197 (seq.++ ?x433 (seq.++ ?x435 ?x4134)))))))
 (let ((?x273 (seq.unit (_ bv4 8))))
 (let ((?x4098 (seq.unit (_ bv33 8))))
 (let ((?x427 (seq.unit (_ bv69 8))))
 (let ((?x4144 (seq.++ ?x427 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x4098 (seq.++ ?x273 ?x4139)))))))
 (let ((?x269 (seq.unit (_ bv8 8))))
 (let ((?x4149 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x269 (seq.++ ?x197 ?x4144)))))))
 (let ((?x4154 (seq.++ ?x197 (seq.++ ?x244 (seq.++ ?x199 (seq.++ ?x197 (seq.++ ?x197 ?x4149)))))))
 (let ((?x4158 (seq.++ ?x199 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x4154))))))
 (= input_0_net.frame_frame ?x4158)))))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x197 (seq.unit (_ bv0 8))))
(let ((?x2433 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x197)))))
(let ((?x2501 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2433)))))))
(let ((?x2506 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 ?x2501)))))))
(let ((?x4112 (seq.unit (_ bv7 8))))
(let ((?x252 (seq.unit (_ bv255 8))))
(let ((?x4110 (seq.unit (_ bv128 8))))
(let ((?x4116 (seq.++ ?x197 (seq.++ ?x4110 (seq.++ ?x252 (seq.++ ?x4112 ?x2506))))))
(let ((?x4176 (seq.unit (_ bv205 8))))
(let ((?x4174 (seq.unit (_ bv171 8))))
(let ((?x4172 (seq.unit (_ bv52 8))))
(let ((?x4170 (seq.unit (_ bv18 8))))
(let ((?x4168 (seq.unit (_ bv118 8))))
(let ((?x4181 (seq.++ ?x4168 (seq.++ ?x4170 (seq.++ ?x4172 (seq.++ ?x4174 (seq.++ ?x4176 ?x4116)))))))
(let ((?x4166 (seq.unit (_ bv58 8))))
(let ((?x269 (seq.unit (_ bv8 8))))
(let ((?x244 (seq.unit (_ bv1 8))))
(let ((?x199 (seq.unit (_ bv2 8))))
(let ((?x4186 (seq.++ ?x199 (seq.++ ?x244 (seq.++ ?x269 (seq.++ ?x197 (seq.++ ?x4166 ?x4181)))))))
(let ((?x195 (seq.unit (_ bv192 8))))
(let ((?x4191 (seq.++ ?x197 (seq.++ ?x199 (seq.++ ?x199 (seq.++ ?x195 (seq.++ ?x197 ?x4186)))))))
(let ((?x4164 (seq.unit (_ bv216 8))))
(let ((?x4162 (seq.unit (_ bv245 8))))
(let ((?x4196 (seq.++ ?x244 (seq.++ ?x244 (seq.++ ?x4162 (seq.++ ?x4164 (seq.++ ?x195 ?x4191)))))))
(let ((?x433 (seq.unit (_ bv64 8))))
(let ((?x4098 (seq.unit (_ bv33 8))))
(let ((?x4201 (seq.++ ?x4098 (seq.++ ?x252 (seq.++ ?x252 (seq.++ ?x433 (seq.++ ?x197 ?x4196)))))))
(let ((?x427 (seq.unit (_ bv69 8))))
(let ((?x4206 (seq.++ ?x269 (seq.++ ?x197 (seq.++ ?x427 (seq.++ ?x197 (seq.++ ?x197 ?x4201)))))))
(let ((?x4211 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x199 ?x4206)))))))
(let ((?x4216 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x197 (seq.++ ?x244 (seq.++ ?x199 ?x4211)))))))
(let ((?x4218 (seq.++ ?x199 (seq.++ ?x197 ?x4216))))
(= input_1_net.frame_frame ?x4218))))))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x5870 (= due_1_cache due_0_cache)))
 (let (($x1785 (= due_1_query due_0_query)))
 (let (($x2186 (= active_1_cache active_0_cache)))
 (let (($x1784 (= active_1_query active_0_query)))
 (let (($x3362 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3361 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3360 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3359 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x2224 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x3358 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3357 (not v_1_rxudp_require_checksum)))
 (let (($x3356 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2153 (= v_1_ip_checksum 0)))
 (let (($x2884 (= v_1_udp_checksum 0)))
 (let (($x3897 (= v_1_udp_raw_checksum 0)))
 (let (($x6479 (= v_1_ip_length 0)))
 (let (($x1276 (= v_1_udp_length 0)))
 (let (($x3355 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2409 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x6396 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3297 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3296 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2177 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x7636 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x255 (= v_1_cache_ttl_ms 60000)))
 (let (($x701 (= v_1_retry_count 0)))
 (let (($x4414 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x90 (= 0 state_1)))
 (let (($x5986 (not active_0_cache)))
 (let (($x6476 (or $x5986 (not (<= due_0_cache 0)))))
 (let (($x5988 (not active_0_query)))
 (let (($x5308 (or $x5988 (not (<= due_0_query 0)))))
 (let (($x3206 (= state_0 0)))
 (and $x3206 (>= 0 now_0) $x5308 $x6476 $x90 $x4414 $x701 $x255 v_1_checksums_enabled $x7636 $x2177 $x3296 $x3297 $x6396 $x2409 $x3355 $x1276 $x6479 $x3897 $x2884 $x2153 $x3356 $x3357 $x3358 $x2224 $x3359 $x3360 $x3361 $x3362 (= v_1_echo_disposition "none") $x1784 $x2186 $x1785 $x5870)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2295 (seq.unit (_ bv0 8))))
(let ((?x3285 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 ?x2295)))))))
(let ((?x3290 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 ?x3285)))))))
(let ((?x2539 (seq.unit (_ bv111 8))))
(let ((?x7638 (seq.unit (_ bv108 8))))
(let ((?x3300 (seq.++ ?x7638 (seq.++ ?x7638 (seq.++ ?x2539 (seq.++ ?x2295 (seq.++ ?x2295 ?x3290)))))))
(let ((?x1264 (seq.unit (_ bv101 8))))
(let ((?x5555 (seq.unit (_ bv104 8))))
(let ((?x5482 (seq.unit (_ bv45 8))))
(let ((?x3310 (seq.unit (_ bv124 8))))
(let ((?x4467 (seq.unit (_ bv13 8))))
(let ((?x2995 (seq.++ ?x4467 (seq.++ ?x3310 (seq.++ ?x5482 (seq.++ ?x5555 (seq.++ ?x1264 ?x3300)))))))
(let ((?x5942 (seq.unit (_ bv64 8))))
(let ((?x1725 (seq.unit (_ bv156 8))))
(let ((?x1723 (seq.unit (_ bv144 8))))
(let ((?x1721 (seq.unit (_ bv31 8))))
(let ((?x2846 (seq.++ ?x1721 (seq.++ ?x1723 (seq.++ ?x1725 (seq.++ ?x5942 (seq.++ ?x2295 ?x2995)))))))
(let ((?x2814 (seq.unit (_ bv1 8))))
(let ((?x663 (seq.unit (_ bv2 8))))
(let ((?x5972 (seq.unit (_ bv192 8))))
(let ((?x3393 (seq.++ ?x663 (seq.++ ?x5972 (seq.++ ?x2295 (seq.++ ?x663 (seq.++ ?x2814 ?x2846)))))))
(let ((?x4630 (seq.unit (_ bv186 8))))
(let ((?x6982 (seq.unit (_ bv182 8))))
(let ((?x245 (seq.++ ?x6982 (seq.++ ?x4630 (seq.++ ?x5972 (seq.++ ?x2295 (seq.++ ?x663 ?x3393)))))))
(let ((?x6955 (seq.unit (_ bv17 8))))
(let ((?x5995 (seq.++ ?x2295 (seq.++ ?x5942 (seq.++ ?x2295 (seq.++ ?x5942 (seq.++ ?x6955 ?x245)))))))
(let ((?x3949 (seq.unit (_ bv47 8))))
(let ((?x5936 (seq.unit (_ bv69 8))))
(let ((?x5959 (seq.++ ?x5936 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x3949 (seq.++ ?x2295 ?x5995)))))))
(let ((?x2800 (seq.unit (_ bv8 8))))
(let ((?x644 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x663 (seq.++ ?x2800 (seq.++ ?x2295 ?x5959)))))))
(let ((?x6011 (seq.++ ?x2295 (seq.++ ?x2814 (seq.++ ?x663 (seq.++ ?x2295 (seq.++ ?x2295 ?x644)))))))
(let ((?x2980 (seq.++ ?x663 (seq.++ ?x2295 (seq.++ ?x2295 (seq.++ ?x2295 ?x6011))))))
(= input_0_net.frame_frame ?x2980)))))))))))))))))))))))))))))))))))
(check-sat)

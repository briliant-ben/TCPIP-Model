; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_echo_disposition () String)
(declare-fun v_3_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_disposition () String)
(declare-fun v_3_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_rxudp_require_checksum () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.require_checksum_required () Bool)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2509 (= due_1_cache due_0_cache)))
 (let (($x101 (= due_1_query due_0_query)))
 (let (($x7154 (= active_1_cache active_0_cache)))
 (let (($x7009 (= active_1_query active_0_query)))
 (let (($x6476 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x7247 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x7222 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x728 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x7583 (= v_1_rxudp_disposition "deliver")))
 (let ((?x4739 (seq.unit (_ bv128 8))))
 (let ((?x4359 (seq.++ ?x4739 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x7450 (seq.unit (_ bv0 8))))
 (let (($x5077 (= v_1_rxudp_payload (seq.++ ?x7450 ?x4359))))
 (let (($x2373 (not v_1_rxudp_require_checksum)))
 (let (($x7535 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x3121 (= v_1_ip_checksum 0)))
 (let (($x3122 (= v_1_udp_checksum 0)))
 (let (($x4460 (= v_1_udp_raw_checksum 0)))
 (let (($x4536 (= v_1_ip_length 0)))
 (let (($x4597 (= v_1_udp_length 0)))
 (let (($x6393 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x7511 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x4668 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4282 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1163 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x7293 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2641 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x3393 (= v_1_cache_ttl_ms 60000)))
 (let (($x960 (= v_1_retry_count 0)))
 (let (($x7456 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x5007 (= 0 state_1)))
 (let (($x4592 (not active_0_cache)))
 (let (($x609 (or $x4592 (not (<= due_0_cache 0)))))
 (let (($x4700 (not active_0_query)))
 (let (($x7421 (or $x4700 (not (<= due_0_query 0)))))
 (let (($x2539 (= state_0 0)))
 (and $x2539 (>= 0 now_0) $x7421 $x609 $x5007 $x7456 $x960 $x3393 v_1_checksums_enabled $x2641 $x7293 $x1163 $x4282 $x4668 $x7511 $x6393 $x4597 $x4536 $x4460 $x3122 $x3121 $x7535 $x2373 $x5077 $x7583 $x728 $x7222 $x7247 $x6476 (= v_1_echo_disposition "none") $x7009 $x7154 $x101 $x2509))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x4741 (= due_2_cache due_1_cache)))
 (let (($x2263 (= due_2_query due_1_query)))
 (let (($x6595 (= active_2_cache active_1_cache)))
 (let (($x2172 (= active_2_query active_1_query)))
 (let (($x2231 (= v_2_echo_disposition v_1_echo_disposition)))
 (let (($x2268 (= v_2_echo_ip_zero v_1_echo_ip_zero)))
 (let (($x3665 (= v_2_echo_icmp_wire v_1_echo_icmp_wire)))
 (let (($x2952 (= v_2_echo_icmp_zero v_1_echo_icmp_zero)))
 (let (($x4802 (= v_2_echo_reply v_1_echo_reply)))
 (let (($x5043 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x2718 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x6526 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x6525 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x4748 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x701 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x4921 (= v_2_ip_length v_1_ip_length)))
 (let (($x5079 (= v_2_udp_length v_1_udp_length)))
 (let (($x4507 (= v_2_packet v_1_packet)))
 (let (($x3621 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x5107 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x723 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x6524 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x6523 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x3578 (= v_2_payload v_1_payload)))
 (let (($x4784 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2201 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2153 (= v_2_retry_count v_1_retry_count)))
 (let (($x4954 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x3594 (= 0 state_2)))
 (let (($x1271 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x2736 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x7227 (= state_1 0)))
 (and $x7227 $x2736 $x1271 $x3594 $x4954 $x2153 $x2201 $x4784 $x3578 $x6523 $x6524 $x723 $x5107 $x3621 $x4507 $x5079 $x4921 $x701 $x4748 $x6525 $x6526 v_2_rxudp_require_checksum $x2718 $x5043 $x4802 $x2952 $x3665 $x2268 $x2231 $x2172 $x6595 $x2263 $x4741))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3334 (= due_3_cache due_2_cache)))
 (let (($x3333 (= due_3_query due_2_query)))
 (let (($x3332 (= active_3_cache active_2_cache)))
 (let (($x3331 (= active_3_query active_2_query)))
 (let (($x3330 (= v_3_echo_disposition v_2_echo_disposition)))
 (let (($x3329 (= v_3_echo_ip_zero v_2_echo_ip_zero)))
 (let (($x3328 (= v_3_echo_icmp_wire v_2_echo_icmp_wire)))
 (let (($x3327 (= v_3_echo_icmp_zero v_2_echo_icmp_zero)))
 (let (($x3326 (= v_3_echo_reply v_2_echo_reply)))
 (let (($x3325 (= v_3_rxudp_disposition "drop_absent")))
 (let (($x4695 (= (as seq.empty (Seq (_ BitVec 8))) v_3_rxudp_payload)))
 (let (($x3323 (= v_3_rxudp_require_checksum v_2_rxudp_require_checksum)))
 (let (($x569 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x568 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x3322 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x3321 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x3320 (= v_3_ip_length v_2_ip_length)))
 (let (($x3319 (= v_3_udp_length v_2_udp_length)))
 (let (($x3318 (= v_3_packet v_2_packet)))
 (let (($x3317 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x3316 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x3315 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x3314 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x3313 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x3312 (= v_3_payload v_2_payload)))
 (let (($x3311 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x3310 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x3309 (= v_3_retry_count v_2_retry_count)))
 (let (($x3308 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x3307 (= 0 state_3)))
 (let (($x2818 (or (not active_2_cache) (not (<= due_2_cache 2)))))
 (let (($x7323 (or (not active_2_query) (not (<= due_2_query 2)))))
 (let (($x3395 (= state_2 0)))
 (and $x3395 v_2_rxudp_require_checksum $x7323 $x2818 $x3307 $x3308 $x3309 $x3310 $x3311 $x3312 $x3313 $x3314 $x3315 $x3316 $x3317 $x3318 $x3319 $x3320 $x3321 $x3322 $x568 $x569 $x3323 $x4695 $x3325 $x3326 $x3327 $x3328 $x3329 $x3330 $x3331 $x3332 $x3333 $x3334)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x7450 (seq.unit (_ bv0 8))))
 (let ((?x3397 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x7450)))))))
 (let ((?x3560 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x3397)))))))
 (let ((?x662 (seq.unit (_ bv7 8))))
 (let ((?x3702 (seq.unit (_ bv255 8))))
 (let ((?x181 (seq.++ ?x3702 (seq.++ ?x662 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x3560)))))))
 (let ((?x4739 (seq.unit (_ bv128 8))))
 (let ((?x2212 (seq.unit (_ bv13 8))))
 (let ((?x2118 (seq.++ ?x2212 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x4739 ?x181)))))))
 (let ((?x3732 (seq.unit (_ bv64 8))))
 (let ((?x5688 (seq.unit (_ bv156 8))))
 (let ((?x7192 (seq.unit (_ bv144 8))))
 (let ((?x7190 (seq.unit (_ bv31 8))))
 (let ((?x3778 (seq.++ ?x7190 (seq.++ ?x7192 (seq.++ ?x5688 (seq.++ ?x3732 (seq.++ ?x7450 ?x2118)))))))
 (let ((?x7479 (seq.unit (_ bv1 8))))
 (let ((?x2414 (seq.unit (_ bv2 8))))
 (let ((?x4966 (seq.unit (_ bv192 8))))
 (let ((?x2777 (seq.++ ?x2414 (seq.++ ?x4966 (seq.++ ?x7450 (seq.++ ?x2414 (seq.++ ?x7479 ?x3778)))))))
 (let ((?x692 (seq.unit (_ bv200 8))))
 (let ((?x3699 (seq.unit (_ bv182 8))))
 (let ((?x2871 (seq.++ ?x3699 (seq.++ ?x692 (seq.++ ?x4966 (seq.++ ?x7450 (seq.++ ?x2414 ?x2777)))))))
 (let ((?x4860 (seq.unit (_ bv17 8))))
 (let ((?x4733 (seq.++ ?x7450 (seq.++ ?x3732 (seq.++ ?x7450 (seq.++ ?x3732 (seq.++ ?x4860 ?x2871)))))))
 (let ((?x2296 (seq.unit (_ bv33 8))))
 (let ((?x985 (seq.unit (_ bv69 8))))
 (let ((?x2117 (seq.++ ?x985 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x2296 (seq.++ ?x7450 ?x4733)))))))
 (let ((?x6449 (seq.unit (_ bv8 8))))
 (let ((?x4865 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x2414 (seq.++ ?x6449 (seq.++ ?x7450 ?x2117)))))))
 (let ((?x4873 (seq.++ ?x7450 (seq.++ ?x7479 (seq.++ ?x2414 (seq.++ ?x7450 (seq.++ ?x7450 ?x4865)))))))
 (let ((?x4158 (seq.++ ?x2414 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x4873))))))
 (= input_0_net.frame_frame ?x4158))))))))))))))))))))))))))))))))
(assert
 (= 35 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_app.require_checksum_required true))
(assert
 (= 32 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x7450 (seq.unit (_ bv0 8))))
(let ((?x3397 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x7450)))))))
(let ((?x3560 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x3397)))))))
(let ((?x662 (seq.unit (_ bv7 8))))
(let ((?x3702 (seq.unit (_ bv255 8))))
(let ((?x181 (seq.++ ?x3702 (seq.++ ?x662 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x3560)))))))
(let ((?x4739 (seq.unit (_ bv128 8))))
(let ((?x2212 (seq.unit (_ bv13 8))))
(let ((?x2118 (seq.++ ?x2212 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x4739 ?x181)))))))
(let ((?x3732 (seq.unit (_ bv64 8))))
(let ((?x5688 (seq.unit (_ bv156 8))))
(let ((?x7192 (seq.unit (_ bv144 8))))
(let ((?x7190 (seq.unit (_ bv31 8))))
(let ((?x3778 (seq.++ ?x7190 (seq.++ ?x7192 (seq.++ ?x5688 (seq.++ ?x3732 (seq.++ ?x7450 ?x2118)))))))
(let ((?x7479 (seq.unit (_ bv1 8))))
(let ((?x2414 (seq.unit (_ bv2 8))))
(let ((?x4966 (seq.unit (_ bv192 8))))
(let ((?x2777 (seq.++ ?x2414 (seq.++ ?x4966 (seq.++ ?x7450 (seq.++ ?x2414 (seq.++ ?x7479 ?x3778)))))))
(let ((?x692 (seq.unit (_ bv200 8))))
(let ((?x3699 (seq.unit (_ bv182 8))))
(let ((?x2871 (seq.++ ?x3699 (seq.++ ?x692 (seq.++ ?x4966 (seq.++ ?x7450 (seq.++ ?x2414 ?x2777)))))))
(let ((?x4860 (seq.unit (_ bv17 8))))
(let ((?x4733 (seq.++ ?x7450 (seq.++ ?x3732 (seq.++ ?x7450 (seq.++ ?x3732 (seq.++ ?x4860 ?x2871)))))))
(let ((?x2296 (seq.unit (_ bv33 8))))
(let ((?x985 (seq.unit (_ bv69 8))))
(let ((?x2117 (seq.++ ?x985 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x2296 (seq.++ ?x7450 ?x4733)))))))
(let ((?x6449 (seq.unit (_ bv8 8))))
(let ((?x4865 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x2414 (seq.++ ?x6449 (seq.++ ?x7450 ?x2117)))))))
(let ((?x4873 (seq.++ ?x7450 (seq.++ ?x7479 (seq.++ ?x2414 (seq.++ ?x7450 (seq.++ ?x7450 ?x4865)))))))
(let ((?x4158 (seq.++ ?x2414 (seq.++ ?x7450 (seq.++ ?x7450 (seq.++ ?x7450 ?x4873))))))
(= input_2_net.frame_frame ?x4158))))))))))))))))))))))))))))))))
(check-sat)

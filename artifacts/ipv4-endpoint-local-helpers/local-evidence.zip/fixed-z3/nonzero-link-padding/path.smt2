; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2557 (= due_1_cache due_0_cache)))
 (let (($x6749 (= due_1_query due_0_query)))
 (let (($x7627 (= active_1_cache active_0_cache)))
 (let (($x7375 (= active_1_query active_0_query)))
 (let (($x6648 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x6647 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x6646 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x6645 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4769 (= v_1_rxudp_disposition "deliver")))
 (let (($x6644 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x63 (not v_1_rxudp_require_checksum)))
 (let (($x6641 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1842 (= v_1_ip_checksum 0)))
 (let (($x1845 (= v_1_udp_checksum 0)))
 (let (($x1846 (= v_1_udp_raw_checksum 0)))
 (let (($x1847 (= v_1_ip_length 0)))
 (let (($x1848 (= v_1_udp_length 0)))
 (let (($x6640 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x5871 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x5870 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x6639 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x6638 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x6637 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x6636 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x2033 (= v_1_cache_ttl_ms 60000)))
 (let (($x2034 (= v_1_retry_count 0)))
 (let (($x6635 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4421 (= 0 state_1)))
 (let (($x3395 (not active_0_cache)))
 (let (($x6634 (or $x3395 (not (<= due_0_cache 0)))))
 (let (($x2129 (not active_0_query)))
 (let (($x6631 (or $x2129 (not (<= due_0_query 0)))))
 (let (($x4873 (= state_0 0)))
 (and $x4873 (>= 0 now_0) $x6631 $x6634 $x4421 $x6635 $x2034 $x2033 v_1_checksums_enabled $x6636 $x6637 $x6638 $x6639 $x5870 $x5871 $x6640 $x1848 $x1847 $x1846 $x1845 $x1842 $x6641 $x63 $x6644 $x4769 $x6645 $x6646 $x6647 $x6648 (= v_1_echo_disposition "none") $x7375 $x7627 $x6749 $x2557)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1787 (= due_2_cache due_1_cache)))
 (let (($x1786 (= due_2_query due_1_query)))
 (let (($x1785 (= active_2_cache active_1_cache)))
 (let (($x1784 (= active_2_query active_1_query)))
 (let (($x1783 (= v_2_echo_disposition "reply")))
 (let ((?x3307 (seq.unit (_ bv192 8))))
 (let ((?x3309 (seq.++ ?x3307 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x3322 (seq.unit (_ bv1 8))))
 (let ((?x3308 (seq.unit (_ bv2 8))))
 (let ((?x2645 (seq.unit (_ bv0 8))))
 (let ((?x1679 (seq.++ ?x2645 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x3322 ?x3309)))))))
 (let ((?x7741 (seq.unit (_ bv64 8))))
 (let ((?x1684 (seq.++ ?x7741 (seq.++ ?x2645 (seq.++ ?x7741 (seq.++ ?x3322 (seq.++ ?x2645 ?x1679)))))))
 (let ((?x1686 (seq.++ ?x2645 (seq.++ ?x2645 ?x1684))))
 (let ((?x5878 (seq.unit (_ bv28 8))))
 (let ((?x2924 (seq.unit (_ bv69 8))))
 (let (($x902 (= v_2_echo_ip_zero (seq.++ ?x2924 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x5878 ?x1686)))))))
 (let ((?x5952 (seq.unit (_ bv18 8))))
 (let ((?x3837 (seq.++ ?x5952 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x5950 (seq.unit (_ bv254 8))))
 (let ((?x3602 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ (seq.unit (_ bv65 8)) (seq.++ ?x5950 ?x3837))))))
 (let (($x2224 (= v_2_echo_icmp_wire ?x3602)))
 (let (($x4795 (= v_2_echo_icmp_zero (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x2645 ?x3837)))))))
 (let ((?x32 (seq.++ ?x3322 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x3308 ?x3602)))))))
 (let ((?x5946 (seq.unit (_ bv221 8))))
 (let ((?x5880 (seq.unit (_ bv182 8))))
 (let ((?x6519 (seq.++ ?x5880 (seq.++ ?x5946 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 ?x32)))))))
 (let ((?x3793 (seq.++ ?x2645 (seq.++ ?x7741 (seq.++ ?x2645 (seq.++ ?x7741 (seq.++ ?x3322 ?x6519)))))))
 (let ((?x6205 (seq.++ ?x2924 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x5878 (seq.++ ?x2645 ?x3793)))))))
 (let (($x4804 (= v_2_echo_reply ?x6205)))
 (let (($x1778 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x1777 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x1776 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x6958 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x1775 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1774 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1509 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1508 (= v_2_ip_length v_1_ip_length)))
 (let (($x1773 (= v_2_udp_length v_1_udp_length)))
 (let (($x1772 (= v_2_packet v_1_packet)))
 (let (($x1771 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1770 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1769 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1768 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1767 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1766 (= v_2_payload v_1_payload)))
 (let (($x1765 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1764 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1763 (= v_2_retry_count v_1_retry_count)))
 (let (($x1762 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1761 (= 0 state_2)))
 (let (($x3960 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x3889 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x2857 (= state_1 0)))
 (and $x2857 $x3889 $x3960 $x1761 $x1762 $x1763 $x1764 $x1765 $x1766 $x1767 $x1768 $x1769 $x1770 $x1771 $x1772 $x1773 $x1508 $x1509 $x1774 $x1775 $x6958 $x1776 $x1777 $x1778 $x4804 $x4795 $x2224 $x902 $x1783 $x1784 $x1785 $x1786 $x1787))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5886 (seq.unit (_ bv165 8))))
 (let ((?x5891 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 ?x5886)))))))
 (let ((?x5896 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 ?x5891)))))))
 (let ((?x5901 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 (seq.++ ?x5886 ?x5896)))))))
 (let ((?x3307 (seq.unit (_ bv192 8))))
 (let ((?x5905 (seq.++ ?x3307 (seq.++ (seq.unit (_ bv9 8)) (seq.++ ?x5886 (seq.++ ?x5886 ?x5901))))))
 (let ((?x2734 (seq.unit (_ bv8 8))))
 (let ((?x2645 (seq.unit (_ bv0 8))))
 (let ((?x7741 (seq.unit (_ bv64 8))))
 (let ((?x8 (seq.unit (_ bv156 8))))
 (let ((?x4227 (seq.unit (_ bv144 8))))
 (let ((?x5910 (seq.++ ?x4227 (seq.++ ?x8 (seq.++ ?x7741 (seq.++ ?x2645 (seq.++ ?x2734 ?x5905)))))))
 (let ((?x7633 (seq.unit (_ bv31 8))))
 (let ((?x3322 (seq.unit (_ bv1 8))))
 (let ((?x3308 (seq.unit (_ bv2 8))))
 (let ((?x5915 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x3322 (seq.++ ?x7633 ?x5910)))))))
 (let ((?x5882 (seq.unit (_ bv205 8))))
 (let ((?x5920 (seq.++ ?x5882 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x3308 ?x5915)))))))
 (let ((?x5880 (seq.unit (_ bv182 8))))
 (let ((?x4679 (seq.unit (_ bv17 8))))
 (let ((?x5924 (seq.++ ?x7741 (seq.++ ?x2645 (seq.++ ?x7741 (seq.++ ?x4679 (seq.++ ?x5880 ?x5920)))))))
 (let ((?x5878 (seq.unit (_ bv28 8))))
 (let ((?x5666 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x5878 (seq.++ ?x2645 (seq.++ ?x2645 ?x5924)))))))
 (let ((?x2924 (seq.unit (_ bv69 8))))
 (let ((?x5932 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x2734 (seq.++ ?x2645 (seq.++ ?x2924 ?x5666)))))))
 (let ((?x5937 (seq.++ ?x3322 (seq.++ ?x3308 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x2645 ?x5932)))))))
 (let ((?x5942 (seq.++ ?x3308 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x2645 ?x5937)))))))
 (= input_0_net.frame_frame ?x5942)))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x5958 (seq.unit (_ bv126 8))))
(let ((?x5963 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 ?x5958)))))))
(let ((?x5968 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 ?x5963)))))))
(let ((?x5973 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 (seq.++ ?x5958 ?x5968)))))))
(let ((?x5882 (seq.unit (_ bv205 8))))
(let ((?x5956 (seq.unit (_ bv171 8))))
(let ((?x5954 (seq.unit (_ bv52 8))))
(let ((?x5978 (seq.++ ?x5954 (seq.++ ?x5956 (seq.++ ?x5882 (seq.++ ?x5958 (seq.++ ?x5958 ?x5973)))))))
(let ((?x5952 (seq.unit (_ bv18 8))))
(let ((?x5950 (seq.unit (_ bv254 8))))
(let ((?x5948 (seq.unit (_ bv57 8))))
(let ((?x2645 (seq.unit (_ bv0 8))))
(let ((?x2734 (seq.unit (_ bv8 8))))
(let ((?x5983 (seq.++ ?x2734 (seq.++ ?x2645 (seq.++ ?x5948 (seq.++ ?x5950 (seq.++ ?x5952 ?x5978)))))))
(let ((?x3322 (seq.unit (_ bv1 8))))
(let ((?x3308 (seq.unit (_ bv2 8))))
(let ((?x3307 (seq.unit (_ bv192 8))))
(let ((?x5988 (seq.++ ?x3308 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x3322 ?x5983)))))))
(let ((?x5946 (seq.unit (_ bv221 8))))
(let ((?x5880 (seq.unit (_ bv182 8))))
(let ((?x5993 (seq.++ ?x5880 (seq.++ ?x5946 (seq.++ ?x3307 (seq.++ ?x2645 (seq.++ ?x3308 ?x5988)))))))
(let ((?x7741 (seq.unit (_ bv64 8))))
(let ((?x5998 (seq.++ ?x2645 (seq.++ ?x7741 (seq.++ ?x2645 (seq.++ ?x7741 (seq.++ ?x3322 ?x5993)))))))
(let ((?x5878 (seq.unit (_ bv28 8))))
(let ((?x2924 (seq.unit (_ bv69 8))))
(let ((?x6003 (seq.++ ?x2924 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x5878 (seq.++ ?x2645 ?x5998)))))))
(let ((?x6008 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x3308 (seq.++ ?x2734 (seq.++ ?x2645 ?x6003)))))))
(let ((?x6013 (seq.++ ?x2645 (seq.++ ?x3322 (seq.++ ?x3308 (seq.++ ?x2645 (seq.++ ?x2645 ?x6008)))))))
(let ((?x6017 (seq.++ ?x3308 (seq.++ ?x2645 (seq.++ ?x2645 (seq.++ ?x2645 ?x6013))))))
(= input_1_net.frame_frame ?x6017)))))))))))))))))))))))))))))))
(check-sat)

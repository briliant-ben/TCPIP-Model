; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x5265 (= due_1_cache due_0_cache)))
 (let (($x3312 (= due_1_query due_0_query)))
 (let (($x5554 (= active_1_cache active_0_cache)))
 (let (($x7486 (= active_1_query active_0_query)))
 (let (($x3353 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3352 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3351 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3350 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1155 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x3349 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x3348 (not v_1_rxudp_require_checksum)))
 (let (($x3347 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x920 (= v_1_ip_checksum 0)))
 (let (($x4632 (= v_1_udp_checksum 0)))
 (let (($x4272 (= v_1_udp_raw_checksum 0)))
 (let (($x2814 (= v_1_ip_length 0)))
 (let (($x2892 (= v_1_udp_length 0)))
 (let (($x3346 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x3345 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3344 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3343 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3342 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3341 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3339 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x5007 (= v_1_cache_ttl_ms 60000)))
 (let (($x2641 (= v_1_retry_count 0)))
 (let (($x3338 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4123 (= 0 state_1)))
 (let (($x1686 (not active_0_cache)))
 (let (($x3337 (or $x1686 (not (<= due_0_cache 0)))))
 (let (($x1684 (not active_0_query)))
 (let (($x3304 (or $x1684 (not (<= due_0_query 0)))))
 (let (($x3794 (= state_0 0)))
 (and $x3794 (>= 0 now_0) $x3304 $x3337 $x4123 $x3338 $x2641 $x5007 v_1_checksums_enabled $x3339 $x3341 $x3342 $x3343 $x3344 $x3345 $x3346 $x2892 $x2814 $x4272 $x4632 $x920 $x3347 $x3348 $x3349 $x1155 $x3350 $x3351 $x3352 $x3353 (= v_1_echo_disposition "none") $x7486 $x5554 $x3312 $x5265)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5883 (seq.unit (_ bv0 8))))
(let ((?x3191 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 ?x5883)))))))
(let ((?x3196 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 ?x3191)))))))
(let ((?x3187 (seq.unit (_ bv111 8))))
(let ((?x3185 (seq.unit (_ bv108 8))))
(let ((?x3201 (seq.++ ?x3185 (seq.++ ?x3185 (seq.++ ?x3187 (seq.++ ?x5883 (seq.++ ?x5883 ?x3196)))))))
(let ((?x3183 (seq.unit (_ bv101 8))))
(let ((?x3181 (seq.unit (_ bv104 8))))
(let ((?x3179 (seq.unit (_ bv45 8))))
(let ((?x3177 (seq.unit (_ bv124 8))))
(let ((?x3175 (seq.unit (_ bv13 8))))
(let ((?x3209 (seq.++ ?x3175 (seq.++ ?x3177 (seq.++ ?x3179 (seq.++ ?x3181 (seq.++ ?x3183 ?x3201)))))))
(let ((?x1771 (seq.unit (_ bv64 8))))
(let ((?x3743 (seq.unit (_ bv156 8))))
(let ((?x1509 (seq.unit (_ bv144 8))))
(let ((?x3522 (seq.unit (_ bv31 8))))
(let ((?x3214 (seq.++ ?x3522 (seq.++ ?x1509 (seq.++ ?x3743 (seq.++ ?x1771 (seq.++ ?x5883 ?x3209)))))))
(let ((?x5926 (seq.unit (_ bv1 8))))
(let ((?x5885 (seq.unit (_ bv2 8))))
(let ((?x8 (seq.unit (_ bv192 8))))
(let ((?x3219 (seq.++ ?x5885 (seq.++ ?x8 (seq.++ ?x5883 (seq.++ ?x5885 (seq.++ ?x5926 ?x3214)))))))
(let ((?x3174 (seq.unit (_ bv206 8))))
(let ((?x3172 (seq.unit (_ bv182 8))))
(let ((?x3224 (seq.++ ?x3172 (seq.++ ?x3174 (seq.++ ?x8 (seq.++ ?x5883 (seq.++ ?x5885 ?x3219)))))))
(let ((?x3397 (seq.unit (_ bv17 8))))
(let ((?x3229 (seq.++ ?x5883 (seq.++ ?x1771 (seq.++ ?x5883 (seq.++ ?x1771 (seq.++ ?x3397 ?x3224)))))))
(let ((?x3170 (seq.unit (_ bv27 8))))
(let ((?x1769 (seq.unit (_ bv69 8))))
(let ((?x3234 (seq.++ ?x1769 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x3170 (seq.++ ?x5883 ?x3229)))))))
(let ((?x1714 (seq.unit (_ bv8 8))))
(let ((?x3239 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5885 (seq.++ ?x1714 (seq.++ ?x5883 ?x3234)))))))
(let ((?x3244 (seq.++ ?x5883 (seq.++ ?x5926 (seq.++ ?x5885 (seq.++ ?x5883 (seq.++ ?x5883 ?x3239)))))))
(let ((?x3248 (seq.++ ?x5885 (seq.++ ?x5883 (seq.++ ?x5883 (seq.++ ?x5883 ?x3244))))))
(= input_0_net.frame_frame ?x3248)))))))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_echo_disposition () String)
(declare-fun v_2_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_disposition () String)
(declare-fun v_2_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_rxudp_require_checksum () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4546 (= due_1_cache due_0_cache)))
 (let (($x133 (= due_1_query due_0_query)))
 (let (($x4545 (= active_1_cache active_0_cache)))
 (let (($x2066 (= active_1_query active_0_query)))
 (let (($x3460 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x3459 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x3458 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x3457 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x2064 (= v_1_rxudp_disposition "deliver")))
 (let ((?x259 (seq.unit (_ bv128 8))))
 (let ((?x4296 (seq.++ ?x259 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x4786 (seq.unit (_ bv0 8))))
 (let (($x3456 (= v_1_rxudp_payload (seq.++ ?x4786 ?x4296))))
 (let (($x4907 (not v_1_rxudp_require_checksum)))
 (let (($x3449 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x608 (= v_1_ip_checksum 0)))
 (let (($x4957 (= v_1_udp_checksum 0)))
 (let (($x4958 (= v_1_udp_raw_checksum 0)))
 (let (($x5103 (= v_1_ip_length 0)))
 (let (($x5066 (= v_1_udp_length 0)))
 (let (($x3448 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x3447 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x3446 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3445 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x3444 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x3443 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3442 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1399 (= v_1_cache_ttl_ms 60000)))
 (let (($x910 (= v_1_retry_count 0)))
 (let (($x3441 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4171 (= 0 state_1)))
 (let (($x4399 (not active_0_cache)))
 (let (($x3440 (or $x4399 (not (<= due_0_cache 0)))))
 (let (($x4398 (not active_0_query)))
 (let (($x3437 (or $x4398 (not (<= due_0_query 0)))))
 (let (($x4887 (= state_0 0)))
 (and $x4887 (>= 0 now_0) $x3437 $x3440 $x4171 $x3441 $x910 $x1399 v_1_checksums_enabled $x3442 $x3443 $x3444 $x3445 $x3446 $x3447 $x3448 $x5066 $x5103 $x4958 $x4957 $x608 $x3449 $x4907 $x3456 $x2064 $x3457 $x3458 $x3459 $x3460 (= v_1_echo_disposition "none") $x2066 $x4545 $x133 $x4546))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x27456 (= due_2_cache due_1_cache)))
 (let (($x3131 (= due_2_query due_1_query)))
 (let (($x5203 (= active_2_cache active_1_cache)))
 (let (($x5201 (= active_2_query active_1_query)))
 (let (($x2612 (= v_2_echo_disposition "reply")))
 (let ((?x2420 (seq.unit (_ bv192 8))))
 (let ((?x2250 (seq.++ ?x2420 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x4358 (seq.unit (_ bv1 8))))
 (let ((?x4785 (seq.unit (_ bv2 8))))
 (let ((?x4786 (seq.unit (_ bv0 8))))
 (let ((?x5127 (seq.++ ?x4786 (seq.++ ?x2420 (seq.++ ?x4786 (seq.++ ?x4785 (seq.++ ?x4358 ?x2250)))))))
 (let ((?x4462 (seq.unit (_ bv64 8))))
 (let ((?x4599 (seq.++ ?x4462 (seq.++ ?x4786 (seq.++ ?x4462 (seq.++ ?x4358 (seq.++ ?x4786 ?x5127)))))))
 (let ((?x6185 (seq.++ ?x4786 (seq.++ ?x4786 ?x4599))))
 (let ((?x1142 (seq.unit (_ bv28 8))))
 (let ((?x24807 (seq.unit (_ bv69 8))))
 (let (($x3559 (= v_2_echo_ip_zero (seq.++ ?x24807 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x1142 ?x6185)))))))
 (let ((?x2809 (seq.unit (_ bv18 8))))
 (let ((?x5554 (seq.++ ?x2809 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x1933 (seq.unit (_ bv254 8))))
 (let ((?x3499 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ (seq.unit (_ bv65 8)) (seq.++ ?x1933 ?x5554))))))
 (let (($x3558 (= v_2_echo_icmp_wire ?x3499)))
 (let (($x3557 (= v_2_echo_icmp_zero (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4786 ?x5554)))))))
 (let ((?x3540 (seq.++ ?x4358 (seq.++ ?x2420 (seq.++ ?x4786 (seq.++ ?x4785 (seq.++ ?x4785 ?x3499)))))))
 (let ((?x1483 (seq.unit (_ bv221 8))))
 (let ((?x308 (seq.unit (_ bv182 8))))
 (let ((?x3545 (seq.++ ?x308 (seq.++ ?x1483 (seq.++ ?x2420 (seq.++ ?x4786 (seq.++ ?x4785 ?x3540)))))))
 (let ((?x3550 (seq.++ ?x4786 (seq.++ ?x4462 (seq.++ ?x4786 (seq.++ ?x4462 (seq.++ ?x4358 ?x3545)))))))
 (let ((?x3555 (seq.++ ?x24807 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x1142 (seq.++ ?x4786 ?x3550)))))))
 (let (($x3556 (= v_2_echo_reply ?x3555)))
 (let (($x5113 (= v_2_rxudp_disposition v_1_rxudp_disposition)))
 (let (($x3042 (= v_2_rxudp_payload v_1_rxudp_payload)))
 (let (($x5057 (= v_2_rxudp_require_checksum v_1_rxudp_require_checksum)))
 (let (($x4981 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x1998 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1986 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x5325 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x5324 (= v_2_ip_length v_1_ip_length)))
 (let (($x5323 (= v_2_udp_length v_1_udp_length)))
 (let (($x4748 (= v_2_packet v_1_packet)))
 (let (($x4751 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x4800 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x4799 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x5287 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x5286 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x4759 (= v_2_payload v_1_payload)))
 (let (($x5231 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x5229 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x5234 (= v_2_retry_count v_1_retry_count)))
 (let (($x1028 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1723 (= 0 state_2)))
 (let (($x4479 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x1057 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x5739 (= state_1 0)))
 (and $x5739 $x1057 $x4479 $x1723 $x1028 $x5234 $x5229 $x5231 $x4759 $x5286 $x5287 $x4799 $x4800 $x4751 $x4748 $x5323 $x5324 $x5325 $x1986 $x1998 $x4981 $x5057 $x3042 $x5113 $x3556 $x3557 $x3558 $x3559 $x2612 $x5201 $x5203 $x3131 $x27456))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x263 (seq.unit (_ bv165 8))))
 (let ((?x268 (seq.++ ?x263 (seq.++ ?x263 (seq.++ ?x263 (seq.++ ?x263 (seq.++ ?x263 ?x263)))))))
 (let ((?x327 (seq.++ ?x263 (seq.++ ?x263 (seq.++ ?x263 (seq.++ ?x263 (seq.++ ?x263 ?x268)))))))
 (let ((?x4786 (seq.unit (_ bv0 8))))
 (let ((?x261 (seq.unit (_ bv7 8))))
 (let ((?x4433 (seq.unit (_ bv255 8))))
 (let ((?x331 (seq.++ ?x4433 (seq.++ ?x261 (seq.++ ?x4786 (seq.++ ?x263 (seq.++ ?x263 ?x327)))))))
 (let ((?x259 (seq.unit (_ bv128 8))))
 (let ((?x2420 (seq.unit (_ bv192 8))))
 (let ((?x335 (seq.++ ?x2420 (seq.++ (seq.unit (_ bv119 8)) (seq.++ ?x4786 (seq.++ ?x259 ?x331))))))
 (let ((?x4462 (seq.unit (_ bv64 8))))
 (let ((?x4173 (seq.unit (_ bv156 8))))
 (let ((?x341 (seq.++ ?x4173 (seq.++ ?x4462 (seq.++ ?x4786 (seq.++ (seq.unit (_ bv13 8)) ?x335))))))
 (let ((?x1657 (seq.unit (_ bv144 8))))
 (let ((?x4719 (seq.unit (_ bv31 8))))
 (let ((?x4358 (seq.unit (_ bv1 8))))
 (let ((?x4785 (seq.unit (_ bv2 8))))
 (let ((?x357 (seq.++ ?x4786 (seq.++ ?x4785 (seq.++ ?x4358 (seq.++ ?x4719 (seq.++ ?x1657 ?x341)))))))
 (let ((?x362 (seq.++ ?x2420 (seq.++ ?x4786 (seq.++ ?x4785 (seq.++ ?x4785 (seq.++ ?x2420 ?x357)))))))
 (let ((?x308 (seq.unit (_ bv182 8))))
 (let ((?x4470 (seq.unit (_ bv17 8))))
 (let ((?x366 (seq.++ ?x4462 (seq.++ ?x4470 (seq.++ ?x308 (seq.++ (seq.unit (_ bv200 8)) ?x362))))))
 (let ((?x371 (seq.++ (seq.unit (_ bv33 8)) (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4462 (seq.++ ?x4786 ?x366)))))))
 (let ((?x24807 (seq.unit (_ bv69 8))))
 (let ((?x4417 (seq.unit (_ bv8 8))))
 (let ((?x376 (seq.++ ?x4417 (seq.++ ?x4786 (seq.++ ?x24807 (seq.++ ?x4786 (seq.++ ?x4786 ?x371)))))))
 (let ((?x3082 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4785 ?x376)))))))
 (let ((?x1531 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4358 (seq.++ ?x4785 ?x3082)))))))
 (let ((?x2165 (seq.++ ?x4785 (seq.++ ?x4786 ?x1531))))
 (= input_0_net.frame_frame ?x2165)))))))))))))))))))))))))))))))
(assert
 (= 53 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x2029 (seq.unit (_ bv126 8))))
(let ((?x2205 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 ?x2029)))))))
(let ((?x702 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 ?x2205)))))))
(let ((?x1451 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 (seq.++ ?x2029 ?x702)))))))
(let ((?x2395 (seq.unit (_ bv205 8))))
(let ((?x121 (seq.unit (_ bv171 8))))
(let ((?x2753 (seq.unit (_ bv52 8))))
(let ((?x1446 (seq.++ ?x2753 (seq.++ ?x121 (seq.++ ?x2395 (seq.++ ?x2029 (seq.++ ?x2029 ?x1451)))))))
(let ((?x2809 (seq.unit (_ bv18 8))))
(let ((?x1933 (seq.unit (_ bv254 8))))
(let ((?x1003 (seq.unit (_ bv57 8))))
(let ((?x4786 (seq.unit (_ bv0 8))))
(let ((?x4417 (seq.unit (_ bv8 8))))
(let ((?x3106 (seq.++ ?x4417 (seq.++ ?x4786 (seq.++ ?x1003 (seq.++ ?x1933 (seq.++ ?x2809 ?x1446)))))))
(let ((?x4358 (seq.unit (_ bv1 8))))
(let ((?x4785 (seq.unit (_ bv2 8))))
(let ((?x2420 (seq.unit (_ bv192 8))))
(let ((?x2088 (seq.++ ?x4785 (seq.++ ?x2420 (seq.++ ?x4786 (seq.++ ?x4785 (seq.++ ?x4358 ?x3106)))))))
(let ((?x1483 (seq.unit (_ bv221 8))))
(let ((?x308 (seq.unit (_ bv182 8))))
(let ((?x2041 (seq.++ ?x308 (seq.++ ?x1483 (seq.++ ?x2420 (seq.++ ?x4786 (seq.++ ?x4785 ?x2088)))))))
(let ((?x4462 (seq.unit (_ bv64 8))))
(let ((?x2545 (seq.++ ?x4786 (seq.++ ?x4462 (seq.++ ?x4786 (seq.++ ?x4462 (seq.++ ?x4358 ?x2041)))))))
(let ((?x1142 (seq.unit (_ bv28 8))))
(let ((?x24807 (seq.unit (_ bv69 8))))
(let ((?x1899 (seq.++ ?x24807 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x1142 (seq.++ ?x4786 ?x2545)))))))
(let ((?x2152 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4785 (seq.++ ?x4417 (seq.++ ?x4786 ?x1899)))))))
(let ((?x2144 (seq.++ ?x4786 (seq.++ ?x4358 (seq.++ ?x4785 (seq.++ ?x4786 (seq.++ ?x4786 ?x2152)))))))
(let ((?x559 (seq.++ ?x4785 (seq.++ ?x4786 (seq.++ ?x4786 (seq.++ ?x4786 ?x2144))))))
(= input_1_net.frame_frame ?x559)))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x39 (= due_1_cache due_0_cache)))
 (let (($x4152 (= due_1_query due_0_query)))
 (let (($x4151 (= active_1_cache active_0_cache)))
 (let (($x5028 (= active_1_query active_0_query)))
 (let (($x2250 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x704 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x5088 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x2420 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4951 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x188 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1280 (not v_1_rxudp_require_checksum)))
 (let (($x1101 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x449 (= v_1_ip_checksum 0)))
 (let (($x4395 (= v_1_udp_checksum 0)))
 (let (($x4399 (= v_1_udp_raw_checksum 0)))
 (let (($x4398 (= v_1_ip_length 0)))
 (let (($x4407 (= v_1_udp_length 0)))
 (let (($x2949 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x4527 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x18145 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x753 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x4502 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x4499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x4498 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x5454 (= v_1_cache_ttl_ms 60000)))
 (let (($x5451 (= v_1_retry_count 0)))
 (let (($x4484 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4945 (= 0 state_1)))
 (let (($x5320 (not active_0_cache)))
 (let (($x4483 (or $x5320 (not (<= due_0_cache 0)))))
 (let (($x4582 (not active_0_query)))
 (let (($x4164 (or $x4582 (not (<= due_0_query 0)))))
 (let (($x4787 (= state_0 0)))
 (and $x4787 (>= 0 now_0) $x4164 $x4483 $x4945 $x4484 $x5451 $x5454 v_1_checksums_enabled $x4498 $x4499 $x4502 $x753 $x18145 $x4527 $x2949 $x4407 $x4398 $x4399 $x4395 $x449 $x1101 $x1280 $x188 $x4951 $x2420 $x5088 $x704 $x2250 (= v_1_echo_disposition "none") $x5028 $x4151 $x4152 $x39)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1988 (seq.unit (_ bv0 8))))
(let ((?x1096 (seq.++ ?x1988 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
(let ((?x5208 (seq.unit (_ bv64 8))))
(let ((?x5250 (seq.unit (_ bv156 8))))
(let ((?x5197 (seq.unit (_ bv144 8))))
(let ((?x5191 (seq.unit (_ bv31 8))))
(let ((?x4304 (seq.unit (_ bv1 8))))
(let ((?x28298 (seq.++ ?x4304 (seq.++ ?x5191 (seq.++ ?x5197 (seq.++ ?x5250 (seq.++ ?x5208 ?x1096)))))))
(let ((?x506 (seq.unit (_ bv2 8))))
(let ((?x1119 (seq.unit (_ bv192 8))))
(let ((?x4154 (seq.++ ?x506 (seq.++ ?x506 (seq.++ ?x1119 (seq.++ ?x1988 (seq.++ ?x506 ?x28298)))))))
(let ((?x6154 (seq.unit (_ bv186 8))))
(let ((?x5375 (seq.unit (_ bv182 8))))
(let ((?x5207 (seq.unit (_ bv17 8))))
(let ((?x5173 (seq.++ ?x5207 (seq.++ ?x5375 (seq.++ ?x6154 (seq.++ ?x1119 (seq.++ ?x1988 ?x4154)))))))
(let ((?x2661 (seq.++ ?x1988 (seq.++ ?x1988 (seq.++ ?x5208 (seq.++ ?x1988 (seq.++ ?x5208 ?x5173)))))))
(let ((?x5441 (seq.unit (_ bv47 8))))
(let ((?x5246 (seq.unit (_ bv69 8))))
(let ((?x4732 (seq.++ ?x1988 (seq.++ ?x5246 (seq.++ ?x1988 (seq.++ ?x1988 (seq.++ ?x5441 ?x2661)))))))
(let ((?x4636 (seq.unit (_ bv8 8))))
(let ((?x5434 (seq.++ ?x1988 (seq.++ ?x1988 (seq.++ ?x1988 (seq.++ ?x506 (seq.++ ?x4636 ?x4732)))))))
(let ((?x5439 (seq.++ ?x1988 (seq.++ ?x1988 (seq.++ ?x4304 (seq.++ ?x506 (seq.++ ?x1988 ?x5434)))))))
(let ((?x5172 (seq.++ ?x506 (seq.++ ?x1988 (seq.++ ?x1988 ?x5439)))))
(= input_0_net.frame_frame ?x5172)))))))))))))))))))))))))
(check-sat)

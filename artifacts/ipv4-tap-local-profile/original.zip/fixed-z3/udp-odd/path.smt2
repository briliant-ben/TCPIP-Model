; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x220 (= due_1_cache due_0_cache)))
 (let (($x219 (= due_1_query due_0_query)))
 (let (($x218 (= active_1_cache active_0_cache)))
 (let (($x217 (= active_1_query active_0_query)))
 (let (($x2896 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2730 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x2729 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x2728 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x209 (= v_1_rxudp_disposition "deliver")))
 (let ((?x1107 (seq.unit (_ bv128 8))))
 (let ((?x746 (seq.++ ?x1107 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x1682 (seq.unit (_ bv0 8))))
 (let ((?x750 (seq.++ ?x1682 ?x746)))
 (let (($x2727 (= v_1_rxudp_payload ?x750)))
 (let (($x2113 (not v_1_rxudp_require_checksum)))
 (let (($x2329 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x448 (= v_1_ip_checksum 0)))
 (let (($x470 (= v_1_udp_checksum 0)))
 (let (($x449 (= v_1_udp_raw_checksum 0)))
 (let (($x451 (= v_1_ip_length 0)))
 (let (($x450 (= v_1_udp_length 0)))
 (let (($x1393 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1611 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1384 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1383 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1387 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1591 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x25 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x621 (= v_1_cache_ttl_ms 60000)))
 (let (($x1109 (= v_1_retry_count 0)))
 (let (($x2534 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x189 (= 0 state_1)))
 (let (($x706 (not active_0_cache)))
 (let (($x1240 (or $x706 (not (<= due_0_cache 0)))))
 (let (($x704 (not active_0_query)))
 (let (($x2915 (or $x704 (not (<= due_0_query 0)))))
 (let (($x3082 (= state_0 0)))
 (and $x3082 (>= 0 now_0) $x2915 $x1240 $x189 $x2534 $x1109 $x621 v_1_checksums_enabled $x25 $x1591 $x1387 $x1383 $x1384 $x1611 $x1393 $x450 $x451 $x449 $x470 $x448 $x2329 $x2113 $x2727 $x209 $x2728 $x2729 $x2730 $x2896 (= v_1_echo_disposition "none") $x217 $x218 $x219 $x220)))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1107 (seq.unit (_ bv128 8))))
(let ((?x746 (seq.++ ?x1107 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x1682 (seq.unit (_ bv0 8))))
(let ((?x750 (seq.++ ?x1682 ?x746)))
(let ((?x1100 (seq.unit (_ bv119 8))))
(let ((?x1681 (seq.unit (_ bv192 8))))
(let ((?x2998 (seq.unit (_ bv13 8))))
(let ((?x1401 (seq.unit (_ bv64 8))))
(let ((?x1097 (seq.++ ?x1401 (seq.++ ?x1682 (seq.++ ?x2998 (seq.++ ?x1681 (seq.++ ?x1100 ?x750)))))))
(let ((?x49 (seq.unit (_ bv156 8))))
(let ((?x48 (seq.unit (_ bv144 8))))
(let ((?x47 (seq.unit (_ bv31 8))))
(let ((?x90 (seq.unit (_ bv1 8))))
(let ((?x95 (seq.unit (_ bv2 8))))
(let ((?x2787 (seq.++ ?x95 (seq.++ ?x90 (seq.++ ?x47 (seq.++ ?x48 (seq.++ ?x49 ?x1097)))))))
(let ((?x2375 (seq.++ ?x1682 (seq.++ ?x95 (seq.++ ?x95 (seq.++ ?x1681 (seq.++ ?x1682 ?x2787)))))))
(let ((?x1255 (seq.unit (_ bv246 8))))
(let ((?x1239 (seq.unit (_ bv177 8))))
(let ((?x39 (seq.unit (_ bv17 8))))
(let ((?x849 (seq.++ ?x1401 (seq.++ ?x39 (seq.++ ?x1239 (seq.++ ?x1255 (seq.++ ?x1681 ?x2375)))))))
(let ((?x1236 (seq.unit (_ bv210 8))))
(let ((?x2052 (seq.unit (_ bv4 8))))
(let ((?x1237 (seq.unit (_ bv33 8))))
(let ((?x768 (seq.++ ?x1237 (seq.++ ?x2052 (seq.++ ?x1236 (seq.++ ?x1401 (seq.++ ?x1682 ?x849)))))))
(let ((?x1558 (seq.unit (_ bv69 8))))
(let ((?x242 (seq.unit (_ bv8 8))))
(let ((?x2960 (seq.++ ?x242 (seq.++ ?x1682 (seq.++ ?x1558 (seq.++ ?x1682 (seq.++ ?x1682 ?x768)))))))
(let ((?x2420 (seq.++ ?x1682 (seq.++ ?x1682 (seq.++ ?x1682 (seq.++ ?x1682 (seq.++ ?x95 ?x2960)))))))
(let ((?x3071 (seq.++ ?x1682 (seq.++ ?x1682 (seq.++ ?x1682 (seq.++ ?x90 (seq.++ ?x95 ?x2420)))))))
(let ((?x2714 (seq.++ ?x95 (seq.++ ?x1682 ?x3071))))
(= input_0_net.frame_frame ?x2714))))))))))))))))))))))))))))))))
(check-sat)

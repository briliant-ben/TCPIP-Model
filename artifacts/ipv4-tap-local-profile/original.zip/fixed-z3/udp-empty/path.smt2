; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x592 (= due_1_cache due_0_cache)))
 (let (($x591 (= due_1_query due_0_query)))
 (let (($x590 (= active_1_cache active_0_cache)))
 (let (($x589 (= active_1_query active_0_query)))
 (let (($x2710 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2709 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x2708 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x2707 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x583 (= v_1_rxudp_disposition "deliver")))
 (let (($x2706 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2703 (not v_1_rxudp_require_checksum)))
 (let (($x2702 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x789 (= v_1_ip_checksum 0)))
 (let (($x792 (= v_1_udp_checksum 0)))
 (let (($x793 (= v_1_udp_raw_checksum 0)))
 (let (($x794 (= v_1_ip_length 0)))
 (let (($x795 (= v_1_udp_length 0)))
 (let (($x2701 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2700 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2699 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x2698 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x2697 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2696 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2695 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x902 (= v_1_cache_ttl_ms 60000)))
 (let (($x910 (= v_1_retry_count 0)))
 (let (($x2694 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x563 (= 0 state_1)))
 (let (($x150 (not active_0_cache)))
 (let (($x2693 (or $x150 (not (<= due_0_cache 0)))))
 (let (($x148 (not active_0_query)))
 (let (($x2690 (or $x148 (not (<= due_0_query 0)))))
 (let (($x68 (= state_0 0)))
 (and $x68 (>= 0 now_0) $x2690 $x2693 $x563 $x2694 $x910 $x902 v_1_checksums_enabled $x2695 $x2696 $x2697 $x2698 $x2699 $x2700 $x2701 $x795 $x794 $x793 $x792 $x789 $x2702 $x2703 $x2706 $x583 $x2707 $x2708 $x2709 $x2710 (= v_1_echo_disposition "none") $x589 $x590 $x591 $x592)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 34 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x166 (seq.unit (_ bv0 8))))
(let ((?x2063 (seq.++ ?x166 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
(let ((?x403 (seq.unit (_ bv64 8))))
(let ((?x417 (seq.unit (_ bv156 8))))
(let ((?x415 (seq.unit (_ bv144 8))))
(let ((?x413 (seq.unit (_ bv31 8))))
(let ((?x213 (seq.unit (_ bv1 8))))
(let ((?x2068 (seq.++ ?x213 (seq.++ ?x413 (seq.++ ?x415 (seq.++ ?x417 (seq.++ ?x403 ?x2063)))))))
(let ((?x168 (seq.unit (_ bv2 8))))
(let ((?x164 (seq.unit (_ bv192 8))))
(let ((?x2073 (seq.++ ?x168 (seq.++ ?x168 (seq.++ ?x164 (seq.++ ?x166 (seq.++ ?x168 ?x2068)))))))
(let ((?x2058 (seq.unit (_ bv251 8))))
(let ((?x2056 (seq.unit (_ bv177 8))))
(let ((?x405 (seq.unit (_ bv17 8))))
(let ((?x2078 (seq.++ ?x405 (seq.++ ?x2056 (seq.++ ?x2058 (seq.++ ?x164 (seq.++ ?x166 ?x2073)))))))
(let ((?x2054 (seq.unit (_ bv210 8))))
(let ((?x242 (seq.unit (_ bv4 8))))
(let ((?x2083 (seq.++ ?x242 (seq.++ ?x2054 (seq.++ ?x403 (seq.++ ?x166 (seq.++ ?x403 ?x2078)))))))
(let ((?x2052 (seq.unit (_ bv28 8))))
(let ((?x397 (seq.unit (_ bv69 8))))
(let ((?x2088 (seq.++ ?x166 (seq.++ ?x397 (seq.++ ?x166 (seq.++ ?x166 (seq.++ ?x2052 ?x2083)))))))
(let ((?x238 (seq.unit (_ bv8 8))))
(let ((?x2093 (seq.++ ?x166 (seq.++ ?x166 (seq.++ ?x166 (seq.++ ?x168 (seq.++ ?x238 ?x2088)))))))
(let ((?x2098 (seq.++ ?x166 (seq.++ ?x166 (seq.++ ?x213 (seq.++ ?x168 (seq.++ ?x166 ?x2093)))))))
(let ((?x2101 (seq.++ ?x168 (seq.++ ?x166 (seq.++ ?x166 ?x2098)))))
(= input_0_net.frame_frame ?x2101)))))))))))))))))))))))))))
(check-sat)

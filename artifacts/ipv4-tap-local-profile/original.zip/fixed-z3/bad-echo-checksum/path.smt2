; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4707 (= due_1_cache due_0_cache)))
 (let (($x4706 (= due_1_query due_0_query)))
 (let (($x4705 (= active_1_cache active_0_cache)))
 (let (($x4704 (= active_1_query active_0_query)))
 (let (($x4703 (= v_1_echo_disposition "drop_icmp_checksum")))
 (let (($x6123 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x1398 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x1166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x49 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x1170 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x6128 (not v_1_rxudp_require_checksum)))
 (let (($x6127 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x4768 (= v_1_ip_checksum 0)))
 (let (($x4769 (= v_1_udp_checksum 0)))
 (let (($x4770 (= v_1_udp_raw_checksum 0)))
 (let (($x4774 (= v_1_ip_length 0)))
 (let (($x4773 (= v_1_udp_length 0)))
 (let (($x2769 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2252 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1592 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x27452 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x27454 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x958 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2059 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x4587 (= v_1_cache_ttl_ms 60000)))
 (let (($x5259 (= v_1_retry_count 0)))
 (let (($x1455 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4678 (= 0 state_1)))
 (let (($x1657 (not active_0_cache)))
 (let (($x5165 (or $x1657 (not (<= due_0_cache 0)))))
 (let (($x527 (not active_0_query)))
 (let (($x6186 (or $x527 (not (<= due_0_query 0)))))
 (let (($x6179 (= state_0 0)))
 (and $x6179 (>= 0 now_0) $x6186 $x5165 $x4678 $x1455 $x5259 $x4587 v_1_checksums_enabled $x2059 $x958 $x27454 $x27452 $x1592 $x2252 $x2769 $x4773 $x4774 $x4770 $x4769 $x4768 $x6127 $x6128 $x1170 (= v_1_rxudp_disposition "none") $x49 $x1166 $x1398 $x6123 $x4703 $x4704 $x4705 $x4706 $x4707)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 52 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1113 (seq.unit (_ bv128 8))))
(let ((?x1401 (seq.++ ?x1113 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv1 8)))))))
(let ((?x1058 (seq.unit (_ bv0 8))))
(let ((?x1114 (seq.unit (_ bv205 8))))
(let ((?x539 (seq.unit (_ bv171 8))))
(let ((?x564 (seq.unit (_ bv52 8))))
(let ((?x1412 (seq.unit (_ bv18 8))))
(let ((?x4998 (seq.++ ?x1412 (seq.++ ?x564 (seq.++ ?x539 (seq.++ ?x1114 (seq.++ ?x1058 ?x1401)))))))
(let ((?x2006 (seq.unit (_ bv118 8))))
(let ((?x144 (seq.unit (_ bv58 8))))
(let ((?x4993 (seq.unit (_ bv8 8))))
(let ((?x4557 (seq.unit (_ bv1 8))))
(let ((?x517 (seq.++ ?x4557 (seq.++ ?x4993 (seq.++ ?x1058 (seq.++ ?x144 (seq.++ ?x2006 ?x4998)))))))
(let ((?x4638 (seq.unit (_ bv2 8))))
(let ((?x2062 (seq.unit (_ bv192 8))))
(let ((?x2556 (seq.++ ?x4638 (seq.++ ?x4638 (seq.++ ?x2062 (seq.++ ?x1058 (seq.++ ?x4638 ?x517)))))))
(let ((?x1128 (seq.unit (_ bv216 8))))
(let ((?x609 (seq.unit (_ bv182 8))))
(let ((?x213 (seq.++ ?x4557 (seq.++ ?x609 (seq.++ ?x1128 (seq.++ ?x2062 (seq.++ ?x1058 ?x2556)))))))
(let ((?x4244 (seq.unit (_ bv64 8))))
(let ((?x47 (seq.++ ?x1058 (seq.++ ?x1058 (seq.++ ?x4244 (seq.++ ?x1058 (seq.++ ?x4244 ?x213)))))))
(let ((?x507 (seq.unit (_ bv33 8))))
(let ((?x4238 (seq.unit (_ bv69 8))))
(let ((?x1191 (seq.++ ?x1058 (seq.++ ?x4238 (seq.++ ?x1058 (seq.++ ?x1058 (seq.++ ?x507 ?x47)))))))
(let ((?x1749 (seq.++ ?x1058 (seq.++ ?x1058 (seq.++ ?x1058 (seq.++ ?x4638 (seq.++ ?x4993 ?x1191)))))))
(let ((?x2510 (seq.++ ?x1058 (seq.++ ?x1058 (seq.++ ?x4557 (seq.++ ?x4638 (seq.++ ?x1058 ?x1749)))))))
(let ((?x5134 (seq.++ ?x4638 (seq.++ ?x1058 (seq.++ ?x1058 ?x2510)))))
(= input_0_net.frame_frame ?x5134)))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4285 (= due_1_cache due_0_cache)))
 (let (($x4304 (= due_1_query due_0_query)))
 (let (($x4303 (= active_1_cache active_0_cache)))
 (let (($x4313 (= active_1_query active_0_query)))
 (let (($x3071 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2058 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x902 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x1140 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4279 (= v_1_rxudp_disposition "drop_ip_length")))
 (let (($x1557 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1141 (not v_1_rxudp_require_checksum)))
 (let (($x273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x4495 (= v_1_ip_checksum 0)))
 (let (($x4496 (= v_1_udp_checksum 0)))
 (let (($x4497 (= v_1_udp_raw_checksum 0)))
 (let (($x4501 (= v_1_ip_length 0)))
 (let (($x4500 (= v_1_udp_length 0)))
 (let (($x771 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x6183 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2229 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x4972 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x506 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1988 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x434 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x4712 (= v_1_cache_ttl_ms 60000)))
 (let (($x4713 (= v_1_retry_count 0)))
 (let (($x65 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x657 (= 0 state_1)))
 (let (($x4582 (not active_0_cache)))
 (let (($x1017 (or $x4582 (not (<= due_0_cache 0)))))
 (let (($x4586 (not active_0_query)))
 (let (($x4597 (or $x4586 (not (<= due_0_query 0)))))
 (let (($x1565 (= state_0 0)))
 (and $x1565 (>= 0 now_0) $x4597 $x1017 $x657 $x65 $x4713 $x4712 v_1_checksums_enabled $x434 $x1988 $x506 $x4972 $x2229 $x6183 $x771 $x4500 $x4501 $x4497 $x4496 $x4495 $x273 $x1141 $x1557 $x4279 $x1140 $x902 $x2058 $x3071 (= v_1_echo_disposition "none") $x4313 $x4303 $x4304 $x4285)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 36 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x5165 (seq.unit (_ bv0 8))))
(let ((?x4708 (seq.++ ?x5165 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv9 8)))))))
(let ((?x5072 (seq.unit (_ bv64 8))))
(let ((?x4886 (seq.unit (_ bv156 8))))
(let ((?x4961 (seq.unit (_ bv144 8))))
(let ((?x4887 (seq.unit (_ bv31 8))))
(let ((?x6171 (seq.unit (_ bv1 8))))
(let ((?x4738 (seq.++ ?x6171 (seq.++ ?x4887 (seq.++ ?x4961 (seq.++ ?x4886 (seq.++ ?x5072 ?x4708)))))))
(let ((?x4678 (seq.unit (_ bv2 8))))
(let ((?x2663 (seq.unit (_ bv192 8))))
(let ((?x4746 (seq.++ ?x4678 (seq.++ ?x4678 (seq.++ ?x2663 (seq.++ ?x5165 (seq.++ ?x4678 ?x4738)))))))
(let ((?x4698 (seq.unit (_ bv206 8))))
(let ((?x4696 (seq.unit (_ bv182 8))))
(let ((?x5039 (seq.unit (_ bv17 8))))
(let ((?x5220 (seq.++ ?x5039 (seq.++ ?x4696 (seq.++ ?x4698 (seq.++ ?x2663 (seq.++ ?x5165 ?x4746)))))))
(let ((?x4790 (seq.++ ?x5165 (seq.++ ?x5165 (seq.++ ?x5072 (seq.++ ?x5165 (seq.++ ?x5072 ?x5220)))))))
(let ((?x4694 (seq.unit (_ bv27 8))))
(let ((?x4979 (seq.unit (_ bv69 8))))
(let ((?x4784 (seq.++ ?x5165 (seq.++ ?x4979 (seq.++ ?x5165 (seq.++ ?x5165 (seq.++ ?x4694 ?x4790)))))))
(let ((?x5221 (seq.unit (_ bv8 8))))
(let ((?x5269 (seq.++ ?x5165 (seq.++ ?x5165 (seq.++ ?x5165 (seq.++ ?x4678 (seq.++ ?x5221 ?x4784)))))))
(let ((?x4758 (seq.++ ?x5165 (seq.++ ?x5165 (seq.++ ?x6171 (seq.++ ?x4678 (seq.++ ?x5165 ?x5269)))))))
(let ((?x5241 (seq.++ ?x4678 (seq.++ ?x5165 (seq.++ ?x5165 ?x4758)))))
(= input_0_net.frame_frame ?x5241)))))))))))))))))))))))))
(check-sat)

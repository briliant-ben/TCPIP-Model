; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1856 (= due_1_cache due_0_cache)))
 (let (($x1855 (= due_1_query due_0_query)))
 (let (($x1854 (= active_1_cache active_0_cache)))
 (let (($x1853 (= active_1_query active_0_query)))
 (let (($x1852 (= v_1_echo_disposition "reply")))
 (let ((?x280 (seq.unit (_ bv192 8))))
 (let ((?x40 (seq.++ ?x280 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x2249 (seq.unit (_ bv1 8))))
 (let ((?x1574 (seq.unit (_ bv2 8))))
 (let ((?x706 (seq.unit (_ bv0 8))))
 (let ((?x287 (seq.++ ?x706 (seq.++ ?x280 (seq.++ ?x706 (seq.++ ?x1574 (seq.++ ?x2249 ?x40)))))))
 (let ((?x403 (seq.unit (_ bv64 8))))
 (let ((?x298 (seq.++ ?x403 (seq.++ ?x706 (seq.++ ?x403 (seq.++ ?x2249 (seq.++ ?x706 ?x287)))))))
 (let ((?x293 (seq.++ ?x706 (seq.++ ?x706 ?x298))))
 (let ((?x1441 (seq.unit (_ bv33 8))))
 (let ((?x402 (seq.unit (_ bv69 8))))
 (let (($x3250 (= v_1_echo_ip_zero (seq.++ ?x402 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x1441 ?x293)))))))
 (let ((?x1793 (seq.unit (_ bv128 8))))
 (let ((?x2220 (seq.++ ?x706 (seq.++ ?x1793 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x706))))))
 (let ((?x2853 (seq.unit (_ bv205 8))))
 (let ((?x2895 (seq.unit (_ bv171 8))))
 (let ((?x1617 (seq.unit (_ bv52 8))))
 (let ((?x2847 (seq.unit (_ bv18 8))))
 (let ((?x2406 (seq.++ ?x2847 (seq.++ ?x1617 (seq.++ ?x2895 (seq.++ ?x2853 ?x2220))))))
 (let ((?x2845 (seq.unit (_ bv118 8))))
 (let ((?x2105 (seq.++ ?x2845 ?x2406)))
 (let ((?x3190 (seq.++ ?x706 (seq.++ ?x706 (seq.++ (seq.unit (_ bv66 8)) ?x2105)))))
 (let (($x3249 (= v_1_echo_icmp_wire ?x3190)))
 (let (($x3248 (= v_1_echo_icmp_zero (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x706 ?x2406)))))))
 (let ((?x3231 (seq.++ ?x2249 (seq.++ ?x280 (seq.++ ?x706 (seq.++ ?x1574 (seq.++ ?x1574 ?x3190)))))))
 (let ((?x2841 (seq.unit (_ bv216 8))))
 (let ((?x3236 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x2841 (seq.++ ?x280 (seq.++ ?x706 (seq.++ ?x1574 ?x3231)))))))
 (let ((?x3241 (seq.++ ?x706 (seq.++ ?x403 (seq.++ ?x706 (seq.++ ?x403 (seq.++ ?x2249 ?x3236)))))))
 (let ((?x3246 (seq.++ ?x402 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x1441 (seq.++ ?x706 ?x3241)))))))
 (let (($x3247 (= v_1_echo_reply ?x3246)))
 (let (($x2394 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x1631 (not v_1_rxudp_require_checksum)))
 (let (($x1798 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1918 (= v_1_ip_checksum 0)))
 (let (($x1921 (= v_1_udp_checksum 0)))
 (let (($x1922 (= v_1_udp_raw_checksum 0)))
 (let (($x1923 (= v_1_ip_length 0)))
 (let (($x1924 (= v_1_udp_length 0)))
 (let (($x1797 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2994 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1170 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1191 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2720 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2722 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1024 (= v_1_cache_ttl_ms 60000)))
 (let (($x1949 (= v_1_retry_count 0)))
 (let (($x1565 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x380 (= 0 state_1)))
 (let (($x41 (not active_0_cache)))
 (let (($x549 (or $x41 (not (<= due_0_cache 0)))))
 (let (($x3030 (not active_0_query)))
 (let (($x1267 (or $x3030 (not (<= due_0_query 0)))))
 (let (($x2166 (= state_0 0)))
 (and $x2166 (>= 0 now_0) $x1267 $x549 $x380 $x1565 $x1949 $x1024 v_1_checksums_enabled $x2722 $x2720 $x1191 $x1170 $x1166 $x2994 $x1797 $x1924 $x1923 $x1922 $x1921 $x1918 $x1798 $x1631 $x2394 (= v_1_rxudp_disposition "none") $x3247 $x3248 $x3249 $x3250 $x1852 $x1853 $x1854 $x1855 $x1856)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 53 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1793 (seq.unit (_ bv128 8))))
(let ((?x1135 (seq.++ ?x1793 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x706 (seq.unit (_ bv0 8))))
(let ((?x2853 (seq.unit (_ bv205 8))))
(let ((?x2895 (seq.unit (_ bv171 8))))
(let ((?x1617 (seq.unit (_ bv52 8))))
(let ((?x2847 (seq.unit (_ bv18 8))))
(let ((?x2406 (seq.++ ?x2847 (seq.++ ?x1617 (seq.++ ?x2895 (seq.++ ?x2853 (seq.++ ?x706 ?x1135)))))))
(let ((?x2845 (seq.unit (_ bv118 8))))
(let ((?x2105 (seq.++ ?x2845 ?x2406)))
(let ((?x2843 (seq.unit (_ bv58 8))))
(let ((?x3083 (seq.unit (_ bv8 8))))
(let ((?x2249 (seq.unit (_ bv1 8))))
(let ((?x1574 (seq.unit (_ bv2 8))))
(let ((?x1521 (seq.++ ?x1574 (seq.++ ?x2249 (seq.++ ?x3083 (seq.++ ?x706 (seq.++ ?x2843 ?x2105)))))))
(let ((?x280 (seq.unit (_ bv192 8))))
(let ((?x1652 (seq.++ ?x706 (seq.++ ?x1574 (seq.++ ?x1574 (seq.++ ?x280 (seq.++ ?x706 ?x1521)))))))
(let ((?x2841 (seq.unit (_ bv216 8))))
(let ((?x1381 (seq.unit (_ bv245 8))))
(let ((?x622 (seq.++ ?x2249 (seq.++ ?x2249 (seq.++ ?x1381 (seq.++ ?x2841 (seq.++ ?x280 ?x1652)))))))
(let ((?x403 (seq.unit (_ bv64 8))))
(let ((?x781 (seq.unit (_ bv255 8))))
(let ((?x1441 (seq.unit (_ bv33 8))))
(let ((?x538 (seq.++ ?x1441 (seq.++ ?x781 (seq.++ ?x781 (seq.++ ?x403 (seq.++ ?x706 ?x622)))))))
(let ((?x402 (seq.unit (_ bv69 8))))
(let ((?x2990 (seq.++ ?x3083 (seq.++ ?x706 (seq.++ ?x402 (seq.++ ?x706 (seq.++ ?x706 ?x538)))))))
(let ((?x2936 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x1574 ?x2990)))))))
(let ((?x135 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x706 (seq.++ ?x2249 (seq.++ ?x1574 ?x2936)))))))
(let ((?x3074 (seq.++ ?x1574 (seq.++ ?x706 ?x135))))
(= input_0_net.frame_frame ?x3074)))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1106 (= due_1_cache due_0_cache)))
 (let (($x1105 (= due_1_query due_0_query)))
 (let (($x1104 (= active_1_cache active_0_cache)))
 (let (($x1103 (= active_1_query active_0_query)))
 (let (($x1102 (= v_1_echo_disposition "reply")))
 (let ((?x902 (seq.unit (_ bv192 8))))
 (let ((?x44 (seq.++ ?x902 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x589 (seq.unit (_ bv1 8))))
 (let ((?x2695 (seq.unit (_ bv2 8))))
 (let ((?x41 (seq.unit (_ bv0 8))))
 (let ((?x658 (seq.++ ?x41 (seq.++ ?x902 (seq.++ ?x41 (seq.++ ?x2695 (seq.++ ?x589 ?x44)))))))
 (let ((?x280 (seq.unit (_ bv64 8))))
 (let ((?x664 (seq.++ ?x280 (seq.++ ?x41 (seq.++ ?x280 (seq.++ ?x589 (seq.++ ?x41 ?x658)))))))
 (let ((?x666 (seq.++ ?x41 (seq.++ ?x41 ?x664))))
 (let ((?x771 (seq.unit (_ bv28 8))))
 (let ((?x273 (seq.unit (_ bv69 8))))
 (let (($x3101 (= v_1_echo_ip_zero (seq.++ ?x273 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x771 ?x666)))))))
 (let ((?x2609 (seq.unit (_ bv18 8))))
 (let ((?x969 (seq.++ ?x2609 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x2510 (seq.unit (_ bv254 8))))
 (let ((?x970 (seq.++ ?x2510 ?x969)))
 (let ((?x3041 (seq.++ ?x41 (seq.++ ?x41 (seq.++ (seq.unit (_ bv65 8)) ?x970)))))
 (let (($x3100 (= v_1_echo_icmp_wire ?x3041)))
 (let (($x3099 (= v_1_echo_icmp_zero (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x41 ?x969)))))))
 (let ((?x3082 (seq.++ ?x589 (seq.++ ?x902 (seq.++ ?x41 (seq.++ ?x2695 (seq.++ ?x2695 ?x3041)))))))
 (let ((?x819 (seq.unit (_ bv221 8))))
 (let ((?x3087 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x819 (seq.++ ?x902 (seq.++ ?x41 (seq.++ ?x2695 ?x3082)))))))
 (let ((?x3092 (seq.++ ?x41 (seq.++ ?x280 (seq.++ ?x41 (seq.++ ?x280 (seq.++ ?x589 ?x3087)))))))
 (let ((?x3097 (seq.++ ?x273 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x771 (seq.++ ?x41 ?x3092)))))))
 (let (($x3098 (= v_1_echo_reply ?x3097)))
 (let (($x137 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x852 (not v_1_rxudp_require_checksum)))
 (let (($x1035 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1169 (= v_1_ip_checksum 0)))
 (let (($x1172 (= v_1_udp_checksum 0)))
 (let (($x1173 (= v_1_udp_raw_checksum 0)))
 (let (($x1174 (= v_1_ip_length 0)))
 (let (($x1175 (= v_1_udp_length 0)))
 (let (($x133 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x132 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2109 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1059 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1058 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2203 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x2328 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1455 (= v_1_cache_ttl_ms 60000)))
 (let (($x1456 (= v_1_retry_count 0)))
 (let (($x2230 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x745 (= 0 state_1)))
 (let (($x2690 (not active_0_cache)))
 (let (($x2229 (or $x2690 (not (<= due_0_cache 0)))))
 (let (($x2688 (not active_0_query)))
 (let (($x2173 (or $x2688 (not (<= due_0_query 0)))))
 (let (($x2085 (= state_0 0)))
 (and $x2085 (>= 0 now_0) $x2173 $x2229 $x745 $x2230 $x1456 $x1455 v_1_checksums_enabled $x2328 $x2203 $x1058 $x1059 $x2109 $x132 $x133 $x1175 $x1174 $x1173 $x1172 $x1169 $x1035 $x852 $x137 (= v_1_rxudp_disposition "none") $x3098 $x3099 $x3100 $x3101 $x1102 $x1103 $x1104 $x1105 $x1106))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 53 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2609 (seq.unit (_ bv18 8))))
(let ((?x969 (seq.++ ?x2609 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
(let ((?x2510 (seq.unit (_ bv254 8))))
(let ((?x970 (seq.++ ?x2510 ?x969)))
(let ((?x1004 (seq.unit (_ bv57 8))))
(let ((?x41 (seq.unit (_ bv0 8))))
(let ((?x959 (seq.unit (_ bv8 8))))
(let ((?x589 (seq.unit (_ bv1 8))))
(let ((?x2695 (seq.unit (_ bv2 8))))
(let ((?x2141 (seq.++ ?x2695 (seq.++ ?x589 (seq.++ ?x959 (seq.++ ?x41 (seq.++ ?x1004 ?x970)))))))
(let ((?x902 (seq.unit (_ bv192 8))))
(let ((?x2555 (seq.++ ?x41 (seq.++ ?x2695 (seq.++ ?x2695 (seq.++ ?x902 (seq.++ ?x41 ?x2141)))))))
(let ((?x819 (seq.unit (_ bv221 8))))
(let ((?x96 (seq.unit (_ bv245 8))))
(let ((?x2342 (seq.++ ?x589 (seq.++ ?x589 (seq.++ ?x96 (seq.++ ?x819 (seq.++ ?x902 ?x2555)))))))
(let ((?x280 (seq.unit (_ bv64 8))))
(let ((?x151 (seq.unit (_ bv255 8))))
(let ((?x771 (seq.unit (_ bv28 8))))
(let ((?x2347 (seq.++ ?x771 (seq.++ ?x151 (seq.++ ?x151 (seq.++ ?x280 (seq.++ ?x41 ?x2342)))))))
(let ((?x273 (seq.unit (_ bv69 8))))
(let ((?x2352 (seq.++ ?x959 (seq.++ ?x41 (seq.++ ?x273 (seq.++ ?x41 (seq.++ ?x41 ?x2347)))))))
(let ((?x2357 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x2695 ?x2352)))))))
(let ((?x2362 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x41 (seq.++ ?x589 (seq.++ ?x2695 ?x2357)))))))
(let ((?x837 (seq.++ ?x2695 (seq.++ ?x41 ?x2362))))
(= input_0_net.frame_frame ?x837))))))))))))))))))))))))))
(check-sat)

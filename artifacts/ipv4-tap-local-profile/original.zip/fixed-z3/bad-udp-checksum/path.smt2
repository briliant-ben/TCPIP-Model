; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_echo_disposition () String)
(declare-fun v_1_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_disposition () String)
(declare-fun v_1_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_rxudp_require_checksum () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_require_checksum () Bool)
(declare-fun v_0_rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_rxudp_disposition () String)
(declare-fun v_0_echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_echo_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x4667 (= due_1_cache due_0_cache)))
 (let (($x4666 (= due_1_query due_0_query)))
 (let (($x4665 (= active_1_cache active_0_cache)))
 (let (($x4664 (= active_1_query active_0_query)))
 (let (($x852 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_ip_zero)))
 (let (($x2070 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_wire)))
 (let (($x1173 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_icmp_zero)))
 (let (($x2069 (= (as seq.empty (Seq (_ BitVec 8))) v_1_echo_reply)))
 (let (($x4658 (= v_1_rxudp_disposition "drop_udp_checksum")))
 (let (($x1174 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rxudp_payload)))
 (let (($x2068 (not v_1_rxudp_require_checksum)))
 (let (($x1175 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x4871 (= v_1_ip_checksum 0)))
 (let (($x4870 (= v_1_udp_checksum 0)))
 (let (($x4873 (= v_1_udp_raw_checksum 0)))
 (let (($x4874 (= v_1_ip_length 0)))
 (let (($x4875 (= v_1_udp_length 0)))
 (let (($x2067 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x133 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2066 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x132 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x2109 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x2064 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1059 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x4906 (= v_1_cache_ttl_ms 60000)))
 (let (($x4908 (= v_1_retry_count 0)))
 (let (($x2063 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x4638 (= 0 state_1)))
 (let (($x4162 (not active_0_cache)))
 (let (($x1058 (or $x4162 (not (<= due_0_cache 0)))))
 (let (($x1239 (not active_0_query)))
 (let (($x2203 (or $x1239 (not (<= due_0_query 0)))))
 (let (($x4563 (= state_0 0)))
 (and $x4563 (>= 0 now_0) $x2203 $x1058 $x4638 $x2063 $x4908 $x4906 v_1_checksums_enabled $x1059 $x2064 $x2109 $x132 $x2066 $x133 $x2067 $x4875 $x4874 $x4873 $x4870 $x4871 $x1175 $x2068 $x1174 $x4658 $x2069 $x1173 $x2070 $x852 (= v_1_echo_disposition "none") $x4664 $x4665 $x4666 $x4667)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_require_checksum false))
(assert
 (= v_0_rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rxudp_disposition "none"))
(assert
 (= v_0_echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_echo_disposition "none"))
(assert
 (= 33 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x6156 (seq.unit (_ bv128 8))))
(let ((?x6161 (seq.++ ?x6156 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv1 8)))))))
(let ((?x4173 (seq.unit (_ bv0 8))))
(let ((?x6154 (seq.unit (_ bv119 8))))
(let ((?x4172 (seq.unit (_ bv192 8))))
(let ((?x6152 (seq.unit (_ bv13 8))))
(let ((?x6166 (seq.++ ?x4173 (seq.++ ?x6152 (seq.++ ?x4172 (seq.++ ?x6154 (seq.++ ?x4173 ?x6161)))))))
(let ((?x4391 (seq.unit (_ bv64 8))))
(let ((?x4405 (seq.unit (_ bv156 8))))
(let ((?x4403 (seq.unit (_ bv144 8))))
(let ((?x4401 (seq.unit (_ bv31 8))))
(let ((?x4213 (seq.unit (_ bv1 8))))
(let ((?x6171 (seq.++ ?x4213 (seq.++ ?x4401 (seq.++ ?x4403 (seq.++ ?x4405 (seq.++ ?x4391 ?x6166)))))))
(let ((?x4175 (seq.unit (_ bv2 8))))
(let ((?x6176 (seq.++ ?x4175 (seq.++ ?x4175 (seq.++ ?x4172 (seq.++ ?x4173 (seq.++ ?x4175 ?x6171)))))))
(let ((?x6150 (seq.unit (_ bv200 8))))
(let ((?x2839 (seq.unit (_ bv182 8))))
(let ((?x4393 (seq.unit (_ bv17 8))))
(let ((?x6181 (seq.++ ?x4393 (seq.++ ?x2839 (seq.++ ?x6150 (seq.++ ?x4172 (seq.++ ?x4173 ?x6176)))))))
(let ((?x1472 (seq.++ ?x4173 (seq.++ ?x4173 (seq.++ ?x4391 (seq.++ ?x4173 (seq.++ ?x4391 ?x6181)))))))
(let ((?x18145 (seq.unit (_ bv33 8))))
(let ((?x4385 (seq.unit (_ bv69 8))))
(let ((?x2612 (seq.++ ?x4173 (seq.++ ?x4385 (seq.++ ?x4173 (seq.++ ?x4173 (seq.++ ?x18145 ?x1472)))))))
(let ((?x4232 (seq.unit (_ bv8 8))))
(let ((?x3177 (seq.++ ?x4173 (seq.++ ?x4173 (seq.++ ?x4173 (seq.++ ?x4175 (seq.++ ?x4232 ?x2612)))))))
(let ((?x10409 (seq.++ ?x4173 (seq.++ ?x4173 (seq.++ ?x4213 (seq.++ ?x4175 (seq.++ ?x4173 ?x3177)))))))
(let ((?x21096 (seq.++ ?x4175 (seq.++ ?x4173 (seq.++ ?x4173 ?x10409)))))
(= input_0_net.frame_frame ?x21096)))))))))))))))))))))))))))))
(check-sat)

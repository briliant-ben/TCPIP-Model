(declare-fun v_0_cb_head () Int)
(declare-fun v_1_cb_partial_prefix () Int)
(declare-fun state_1 () Int)
(declare-fun state_0 () Int)
(declare-fun choice_0 () Int)
(declare-fun v_0_cb_length_15 () Int)
(declare-fun v_0_cb_end_14 () Int)
(declare-fun v_0_cb_end_15 () Int)
(declare-fun v_0_cb_count () Int)
(declare-fun v_0_cb_partial_prefix () Int)
(declare-fun v_0_snd_una () Int)
(declare-fun v_0_cb_length_14 () Int)
(declare-fun v_0_cb_end_13 () Int)
(declare-fun v_0_cb_length_13 () Int)
(declare-fun v_0_cb_end_12 () Int)
(declare-fun v_0_cb_length_12 () Int)
(declare-fun v_0_cb_end_11 () Int)
(declare-fun v_0_cb_length_11 () Int)
(declare-fun v_0_cb_end_10 () Int)
(declare-fun v_0_cb_length_10 () Int)
(declare-fun v_0_cb_end_09 () Int)
(declare-fun v_0_cb_length_09 () Int)
(declare-fun v_0_cb_end_08 () Int)
(declare-fun v_0_cb_length_08 () Int)
(declare-fun v_0_cb_end_07 () Int)
(declare-fun v_0_cb_length_07 () Int)
(declare-fun v_0_cb_end_06 () Int)
(declare-fun v_0_cb_length_06 () Int)
(declare-fun v_0_cb_end_05 () Int)
(declare-fun v_0_cb_length_05 () Int)
(declare-fun v_0_cb_end_04 () Int)
(declare-fun v_0_cb_length_04 () Int)
(declare-fun v_0_cb_end_03 () Int)
(declare-fun v_0_cb_length_03 () Int)
(declare-fun v_0_cb_end_02 () Int)
(declare-fun v_0_cb_length_02 () Int)
(declare-fun v_0_cb_end_01 () Int)
(declare-fun v_0_cb_length_01 () Int)
(declare-fun v_0_cb_end_00 () Int)
(declare-fun v_0_cb_length_00 () Int)
(declare-fun v_0_svc_written_bytes () Int)
(declare-fun v_0_snd_buf () Int)
(declare-fun v_0_cb_emitted_total () Int)
(declare-fun v_0_rtx_buf () Int)
(declare-fun v_0_cb_live_total () Int)
(declare-fun v_0_cb_abandoned_total () Int)
(declare-fun v_0_cb_acked_total () Int)
(declare-fun v_0_cb_drop_step () Int)
(declare-fun v_0_cb_step_bytes () Int)
(declare-fun v_0_svc_acked_bytes () Int)
(declare-fun v_0_cb_new_count () Int)
(declare-fun v_0_cb_tail () Int)
(declare-fun v_0_svc_drop_step () Int)
(declare-fun v_0_svc_ack_step () Int)
(declare-fun v_0_svc_accept_step () Int)
(declare-fun v_0_cc_acked () Int)
(declare-fun v_0_svc_abandoned_bytes () Int)
(declare-fun v_0_idle_event_ms () Int)
(declare-fun v_0_sched_at_ms () Int)
(declare-fun v_0_sched_open () Bool)
(declare-fun v_0_choice_used () Bool)
(declare-fun v_0_sched_cause () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_sched_bytes () Int)
(declare-fun v_0_sched_packets () Int)
(declare-fun v_0_choice_count () Int)
(declare-fun v_0_choice_before_flight () Int)
(declare-fun v_0_choice_before_nxt () Int)
(declare-fun v_0_snd_nxt () Int)
(declare-fun v_0_cc_send_budget () Int)
(declare-fun v_0_cc_new_sent () Int)
(declare-fun v_0_take () Int)
(declare-fun v_0_choice_limit () Int)
(declare-fun v_0_lt_before_bytes () Int)
(declare-fun v_0_fr_before_flight () Int)
(declare-fun v_0_lt_loss_flight () Int)
(declare-fun v_0_fr_entered () Bool)
(declare-fun v_0_lt_take () Int)
(declare-fun v_0_lt_before_nxt () Int)
(declare-fun v_0_cc_cwnd () Int)
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_lt_before_flight () Int)
(declare-fun v_0_lt_before_cwnd () Int)
(declare-fun v_0_fin_sent () Bool)
(declare-fun v_0_fr_active () Bool)
(declare-fun v_0_fr_dupacks () Int)
(declare-fun v_0_fr_duplicate () Bool)
(declare-fun v_0_lt_emitted () Bool)
(declare-fun v_0_lt_epoch_packets () Int)
(declare-fun v_0_lt_epoch_bytes () Int)
(declare-fun v_0_cc_ca_credit () Int)
(declare-fun v_0_idle_before_threshold () Int)
(declare-fun v_0_cc_ssthresh () Int)
(declare-fun v_0_idle_before_cwnd () Int)
(declare-fun v_0_cc_initial_window () Int)
(declare-fun v_0_idle_elapsed_ms () Int)
(declare-fun v_0_idle_before_rto () Int)
(declare-fun v_0_idle_restart () Bool)
(declare-fun v_0_idle_last_data_ms () Int)
(declare-fun v_0_idle_data_emitted () Bool)
(declare-fun v_0_idle_restart_count () Int)
(declare-fun v_0_fr_exited () Bool)
(declare-fun v_0_fr_retransmitted () Bool)
(declare-fun v_0_fr_before_window_valid () Bool)
(declare-fun v_0_fr_window_valid () Bool)
(declare-fun v_0_fr_before_wire_window () Int)
(declare-fun v_0_fr_last_window () Int)
(declare-fun v_0_fr_window_ignored () Bool)
(declare-fun v_0_tx_retransmitted () Bool)
(declare-fun v_0_fr_before_retries () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_fr_before_rto () Int)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_fr_before_nxt () Int)
(declare-fun v_0_fr_emit_count () Int)
(declare-fun v_0_persist_active () Bool)
(declare-fun v_0_fr_entries () Int)
(declare-fun v_0_cc_rto_15 () Bool)
(declare-fun v_0_cc_rto_14 () Bool)
(declare-fun v_0_cc_rto_13 () Bool)
(declare-fun v_0_cc_rto_12 () Bool)
(declare-fun v_0_cc_rto_11 () Bool)
(declare-fun v_0_cc_rto_10 () Bool)
(declare-fun v_0_cc_rto_09 () Bool)
(declare-fun v_0_cc_rto_08 () Bool)
(declare-fun v_0_cc_rto_07 () Bool)
(declare-fun v_0_cc_rto_06 () Bool)
(declare-fun v_0_cc_rto_05 () Bool)
(declare-fun v_0_cc_rto_04 () Bool)
(declare-fun v_0_cc_rto_03 () Bool)
(declare-fun v_0_cc_rto_02 () Bool)
(declare-fun v_0_cc_rto_01 () Bool)
(declare-fun v_0_cc_rto_00 () Bool)
(declare-fun v_0_cc_threshold_updates () Int)
(declare-fun v_0_cc_growth () Int)
(declare-fun v_0_cc_initial_threshold () Int)
(declare-fun v_0_persist_probes () Int)
(declare-fun v_0_persist_deadline_ms () Int)
(declare-fun v_0_persist_last_ms () Int)
(declare-fun v_0_persist_since_ms () Int)
(declare-fun v_0_tx_time_00 () Int)
(declare-fun v_0_persist_previous_interval_ms () Int)
(declare-fun v_0_persist_elapsed_ms () Int)
(declare-fun v_0_persist_probe_sent () Bool)
(declare-fun v_0_persist_interval_ms () Int)
(declare-fun v_0_rtt_remaining () Int)
(declare-fun v_0_rtt_active () Bool)
(declare-fun active_0_rtx () Bool)
(declare-fun active_0_persist () Bool)
(declare-fun v_0_ack_since_ms () Int)
(declare-fun v_0_ack_full_segments () Int)
(declare-fun v_0_ack_bytes () Int)
(declare-fun v_0_ack_pending () Bool)
(declare-fun v_0_rx_fin_done () Bool)
(declare-fun active_0_delack () Bool)
(declare-fun v_0_ack_rmss () Int)
(declare-fun v_0_ack_delay_ms () Int)
(declare-fun v_0_tx_syn_time () Int)
(declare-fun v_0_tx_syn_pending () Bool)
(declare-fun v_0_tx_waiting () Bool)
(declare-fun v_0_tx_emit_count () Int)
(declare-fun v_0_tx_is_fin () Bool)
(declare-fun v_0_tx_previous_rto () Int)
(declare-fun v_0_tx_elapsed () Int)
(declare-fun v_0_tx_max_previous () Int)
(declare-fun v_0_tx_eligible () Int)
(declare-fun v_0_tx_fin_time () Int)
(declare-fun v_0_tx_time_15 () Int)
(declare-fun v_0_tx_time_14 () Int)
(declare-fun v_0_tx_time_13 () Int)
(declare-fun v_0_tx_time_12 () Int)
(declare-fun v_0_tx_time_11 () Int)
(declare-fun v_0_tx_time_10 () Int)
(declare-fun v_0_tx_time_09 () Int)
(declare-fun v_0_tx_time_08 () Int)
(declare-fun v_0_tx_time_07 () Int)
(declare-fun v_0_tx_time_06 () Int)
(declare-fun v_0_tx_time_05 () Int)
(declare-fun v_0_tx_time_04 () Int)
(declare-fun v_0_tx_time_03 () Int)
(declare-fun v_0_tx_time_02 () Int)
(declare-fun v_0_tx_time_01 () Int)
(declare-fun v_0_rtt_last_ms () Int)
(declare-fun v_0_rtt_previous_srtt () Real)
(declare-fun v_0_rtt_previous_measured () Bool)
(declare-fun v_0_srtt_ms () Real)
(declare-fun v_0_rtt_previous_var () Real)
(declare-fun v_0_rttvar_ms () Real)
(declare-fun v_0_rtt_sample_used () Bool)
(declare-fun v_0_rtt_sample_at_ms () Int)
(declare-fun v_0_rtt_start_ms () Int)
(declare-fun v_0_rtt_measured () Bool)
(declare-fun v_0_rtt_sample_was_ambiguous () Bool)
(declare-fun v_0_rtt_end () Int)
(declare-fun v_0_rtt_samples () Int)
(declare-fun v_0_rto_base_ms () Int)
(declare-fun v_0_rtt_error_ms () Real)
(declare-fun v_0_rx_slot_15 () Int)
(declare-fun v_0_rx_fin_offset () Int)
(declare-fun v_0_rx_fin_pending () Bool)
(declare-fun v_0_rx_slot_14 () Int)
(declare-fun v_0_rx_slot_13 () Int)
(declare-fun v_0_rx_slot_12 () Int)
(declare-fun v_0_rx_slot_11 () Int)
(declare-fun v_0_rx_slot_10 () Int)
(declare-fun v_0_rx_slot_09 () Int)
(declare-fun v_0_rx_slot_08 () Int)
(declare-fun v_0_rx_slot_07 () Int)
(declare-fun v_0_rx_slot_06 () Int)
(declare-fun v_0_rx_slot_05 () Int)
(declare-fun v_0_rx_slot_04 () Int)
(declare-fun v_0_rx_slot_03 () Int)
(declare-fun v_0_rx_slot_02 () Int)
(declare-fun v_0_rx_slot_01 () Int)
(declare-fun v_0_rx_slot_00 () Int)
(declare-fun v_0_rx_fin_seq () Int)
(declare-fun v_0_rcv_nxt () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_fin_requested () Bool)
(declare-fun v_0_ack_delta () Int)
(declare-fun v_0_rx_advance () Int)
(declare-fun v_0_rx_chunk () Int)
(declare-fun v_0_rcv_buf () Int)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun active_0_user () Bool)
(declare-fun due_0_persist () Int)
(declare-fun now_1 () Int)
(declare-fun v_0_rtt_ambiguous () Bool)
(declare-fun input_0_net.ack_ack () Int)
(declare-fun input_0_net.ack_seq () Int)
(declare-fun input_0_net.ack_window () Int)
(declare-fun v_0_snd_wl1 () Int)
(declare-fun v_0_snd_wl2 () Int)
(declare-fun due_1_persist () Int)
(declare-fun due_0_delack () Int)
(declare-fun due_1_delack () Int)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_0_user () Int)
(declare-fun due_1_user () Int)
(declare-fun due_0_rtx () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_persist () Bool)
(declare-fun active_1_delack () Bool)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_cb_done_15 () Bool)
(declare-fun v_1_cb_end_15 () Int)
(declare-fun v_1_cb_length_15 () Int)
(declare-fun v_1_cb_done_14 () Bool)
(declare-fun v_1_cb_end_14 () Int)
(declare-fun v_1_cb_length_14 () Int)
(declare-fun v_1_cb_done_13 () Bool)
(declare-fun v_1_cb_end_13 () Int)
(declare-fun v_1_cb_length_13 () Int)
(declare-fun v_1_cb_done_12 () Bool)
(declare-fun v_1_cb_end_12 () Int)
(declare-fun v_1_cb_length_12 () Int)
(declare-fun v_1_cb_done_11 () Bool)
(declare-fun v_1_cb_end_11 () Int)
(declare-fun v_1_cb_length_11 () Int)
(declare-fun v_1_cb_done_10 () Bool)
(declare-fun v_1_cb_end_10 () Int)
(declare-fun v_1_cb_length_10 () Int)
(declare-fun v_1_cb_done_09 () Bool)
(declare-fun v_1_cb_end_09 () Int)
(declare-fun v_1_cb_length_09 () Int)
(declare-fun v_1_cb_done_08 () Bool)
(declare-fun v_1_cb_end_08 () Int)
(declare-fun v_1_cb_length_08 () Int)
(declare-fun v_1_cb_done_07 () Bool)
(declare-fun v_1_cb_end_07 () Int)
(declare-fun v_1_cb_length_07 () Int)
(declare-fun v_1_cb_done_06 () Bool)
(declare-fun v_1_cb_end_06 () Int)
(declare-fun v_1_cb_length_06 () Int)
(declare-fun v_1_cb_done_05 () Bool)
(declare-fun v_1_cb_end_05 () Int)
(declare-fun v_1_cb_length_05 () Int)
(declare-fun v_1_cb_done_04 () Bool)
(declare-fun v_1_cb_end_04 () Int)
(declare-fun v_1_cb_length_04 () Int)
(declare-fun v_1_cb_done_03 () Bool)
(declare-fun v_1_cb_end_03 () Int)
(declare-fun v_1_cb_length_03 () Int)
(declare-fun v_1_cb_done_02 () Bool)
(declare-fun v_1_cb_end_02 () Int)
(declare-fun v_1_cb_length_02 () Int)
(declare-fun v_1_cb_done_01 () Bool)
(declare-fun v_1_cb_end_01 () Int)
(declare-fun v_1_cb_length_01 () Int)
(declare-fun v_1_cb_done_00 () Bool)
(declare-fun v_1_cb_end_00 () Int)
(declare-fun v_1_cb_length_00 () Int)
(declare-fun v_1_cb_is_new () Bool)
(declare-fun v_1_cb_append_end () Int)
(declare-fun v_1_cb_before_nxt () Int)
(declare-fun v_1_cb_drop_step () Int)
(declare-fun v_1_cb_abandoned_total () Int)
(declare-fun v_1_cb_acked_total () Int)
(declare-fun v_1_cb_emitted_total () Int)
(declare-fun v_1_cb_live_total () Int)
(declare-fun v_1_cb_step_bytes () Int)
(declare-fun v_1_cb_retired_count () Int)
(declare-fun v_1_cb_append_length () Int)
(declare-fun v_1_cb_new_count () Int)
(declare-fun v_1_cb_count () Int)
(declare-fun v_1_cb_tail () Int)
(declare-fun v_1_cb_head () Int)
(declare-fun v_1_svc_abandoned_bytes () Int)
(declare-fun v_1_svc_acked_bytes () Int)
(declare-fun v_1_svc_written_bytes () Int)
(declare-fun v_1_svc_drop_step () Int)
(declare-fun v_1_svc_ack_step () Int)
(declare-fun v_1_svc_accept_step () Int)
(declare-fun v_1_svc_before_total () Int)
(declare-fun v_1_sched_packets () Int)
(declare-fun v_1_sched_bytes () Int)
(declare-fun v_1_sched_cause () Int)
(declare-fun v_1_sched_at_ms () Int)
(declare-fun v_1_sched_open () Bool)
(declare-fun v_1_choice_before_flight () Int)
(declare-fun v_1_choice_before_nxt () Int)
(declare-fun v_1_choice_limit () Int)
(declare-fun v_1_choice_count () Int)
(declare-fun v_1_choice_used () Bool)
(declare-fun v_1_lt_loss_flight () Int)
(declare-fun v_1_lt_before_window () Int)
(declare-fun v_1_lt_before_flight () Int)
(declare-fun v_1_lt_before_nxt () Int)
(declare-fun v_1_lt_before_cwnd () Int)
(declare-fun v_1_lt_before_bytes () Int)
(declare-fun v_1_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_bytes () Int)
(declare-fun v_1_lt_take () Int)
(declare-fun v_1_lt_emitted () Bool)
(declare-fun v_1_lt_eligible () Bool)
(declare-fun v_1_idle_restart_count () Int)
(declare-fun v_1_idle_before_threshold () Int)
(declare-fun v_1_idle_before_rto () Int)
(declare-fun v_1_idle_before_cwnd () Int)
(declare-fun v_0_idle_data_valid () Bool)
(declare-fun v_1_idle_elapsed_ms () Int)
(declare-fun v_1_idle_restart () Bool)
(declare-fun v_1_idle_data_emitted () Bool)
(declare-fun v_1_idle_event_ms () Int)
(declare-fun v_1_idle_last_data_ms () Int)
(declare-fun v_1_idle_data_valid () Bool)
(declare-fun v_1_fr_entries () Int)
(declare-fun v_1_fr_emit_count () Int)
(declare-fun v_1_fr_retransmitted () Bool)
(declare-fun v_1_fr_exited () Bool)
(declare-fun v_1_fr_extra () Bool)
(declare-fun v_1_fr_entered () Bool)
(declare-fun v_1_fr_duplicate () Bool)
(declare-fun v_1_fr_before_retries () Int)
(declare-fun v_1_fr_before_rto () Int)
(declare-fun v_1_fr_before_flight () Int)
(declare-fun v_1_fr_before_nxt () Int)
(declare-fun v_1_fr_before_una () Int)
(declare-fun v_1_fr_was_active () Bool)
(declare-fun v_1_fr_last_window () Int)
(declare-fun v_1_fr_window_valid () Bool)
(declare-fun v_1_fr_dupacks () Int)
(declare-fun v_1_fr_active () Bool)
(declare-fun v_1_fr_before_window_valid () Bool)
(declare-fun v_1_fr_before_wire_window () Int)
(declare-fun v_1_fr_window_ignored () Bool)
(declare-fun v_1_cc_rto_15 () Bool)
(declare-fun v_1_cc_rto_14 () Bool)
(declare-fun v_1_cc_rto_13 () Bool)
(declare-fun v_1_cc_rto_12 () Bool)
(declare-fun v_1_cc_rto_11 () Bool)
(declare-fun v_1_cc_rto_10 () Bool)
(declare-fun v_1_cc_rto_09 () Bool)
(declare-fun v_1_cc_rto_08 () Bool)
(declare-fun v_1_cc_rto_07 () Bool)
(declare-fun v_1_cc_rto_06 () Bool)
(declare-fun v_1_cc_rto_05 () Bool)
(declare-fun v_1_cc_rto_04 () Bool)
(declare-fun v_1_cc_rto_03 () Bool)
(declare-fun v_1_cc_rto_02 () Bool)
(declare-fun v_1_cc_rto_01 () Bool)
(declare-fun v_1_cc_rto_00 () Bool)
(declare-fun v_1_cc_new_sent () Int)
(declare-fun v_1_cc_send_budget () Int)
(declare-fun v_1_cc_before_cwnd () Int)
(declare-fun v_1_cc_growth () Int)
(declare-fun v_1_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_changed () Bool)
(declare-fun v_1_cc_loss () Bool)
(declare-fun v_1_cc_before_window () Int)
(declare-fun v_1_cc_before_persist () Bool)
(declare-fun v_1_cc_before_una () Int)
(declare-fun v_1_cc_before_flight () Int)
(declare-fun v_1_cc_acked () Int)
(declare-fun v_1_cc_ca_credit () Int)
(declare-fun v_1_cc_ssthresh () Int)
(declare-fun v_1_cc_cwnd () Int)
(declare-fun v_1_cc_initial_threshold () Int)
(declare-fun v_1_cc_initial_window () Int)
(declare-fun v_1_persist_elapsed_ms () Int)
(declare-fun v_1_persist_probes () Int)
(declare-fun v_1_persist_deadline_ms () Int)
(declare-fun v_1_persist_last_ms () Int)
(declare-fun v_1_persist_since_ms () Int)
(declare-fun v_1_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_interval_ms () Int)
(declare-fun v_1_persist_probe_new () Bool)
(declare-fun v_1_persist_probe_sent () Bool)
(declare-fun v_1_persist_first () Bool)
(declare-fun v_1_persist_was_active () Bool)
(declare-fun v_1_persist_start () Bool)
(declare-fun v_1_persist_eligible () Bool)
(declare-fun v_1_persist_active () Bool)
(declare-fun v_1_ack_defer_now () Bool)
(declare-fun v_1_ack_defer_candidate () Bool)
(declare-fun v_1_ack_rmss () Int)
(declare-fun v_1_ack_delay_ms () Int)
(declare-fun v_1_ack_full_segments () Int)
(declare-fun v_1_ack_bytes () Int)
(declare-fun v_1_ack_since_ms () Int)
(declare-fun v_1_ack_pending () Bool)
(declare-fun v_1_syn_timeout_eligible () Bool)
(declare-fun v_1_tx_syn_pending () Bool)
(declare-fun v_1_tx_syn_time () Int)
(declare-fun v_1_tx_waiting () Bool)
(declare-fun v_1_tx_is_fin () Bool)
(declare-fun v_1_tx_previous_rto () Int)
(declare-fun v_1_tx_elapsed () Int)
(declare-fun v_1_tx_retransmitted () Bool)
(declare-fun v_1_tx_max_previous () Int)
(declare-fun v_1_tx_eligible () Int)
(declare-fun v_1_tx_emit_count () Int)
(declare-fun v_0_fin_acknowledged () Bool)
(declare-fun v_1_tx_fin_time () Int)
(declare-fun v_1_tx_time_15 () Int)
(declare-fun v_1_tx_time_14 () Int)
(declare-fun v_1_tx_time_13 () Int)
(declare-fun v_1_tx_time_12 () Int)
(declare-fun v_1_tx_time_11 () Int)
(declare-fun v_1_tx_time_10 () Int)
(declare-fun v_1_tx_time_09 () Int)
(declare-fun v_1_tx_time_08 () Int)
(declare-fun v_1_tx_time_07 () Int)
(declare-fun v_1_tx_time_06 () Int)
(declare-fun v_1_tx_time_05 () Int)
(declare-fun v_1_tx_time_04 () Int)
(declare-fun v_1_tx_time_03 () Int)
(declare-fun v_1_tx_time_02 () Int)
(declare-fun v_1_tx_time_01 () Int)
(declare-fun v_1_tx_time_00 () Int)
(declare-fun v_1_rto_base_ms () Int)
(declare-fun v_1_rtt_samples () Int)
(declare-fun v_1_rtt_last_ms () Int)
(declare-fun v_1_rtt_sample_was_ambiguous () Bool)
(declare-fun v_1_rtt_sample_used () Bool)
(declare-fun v_1_rtt_start_new () Bool)
(declare-fun v_1_rtt_remaining () Int)
(declare-fun v_1_rtt_end () Int)
(declare-fun v_1_rtt_start_ms () Int)
(declare-fun v_1_rtt_sample_at_ms () Int)
(declare-fun v_1_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_active () Bool)
(declare-fun v_1_rtt_previous_measured () Bool)
(declare-fun v_1_rtt_measured () Bool)
(declare-fun v_1_rtt_previous_var () Real)
(declare-fun v_1_rtt_previous_srtt () Real)
(declare-fun v_1_rtt_error_ms () Real)
(declare-fun v_1_rttvar_ms () Real)
(declare-fun v_1_srtt_ms () Real)
(declare-fun v_0_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_done () Bool)
(declare-fun v_1_rx_fin_offset () Int)
(declare-fun v_1_rx_fin_seq () Int)
(declare-fun v_1_rx_fin_pending () Bool)
(declare-fun v_1_fin_acknowledged () Bool)
(declare-fun v_0_fin_seq () Int)
(declare-fun v_1_fin_seq () Int)
(declare-fun v_1_fin_sent () Bool)
(declare-fun v_1_fin_requested () Bool)
(declare-fun v_1_ack_window_update () Bool)
(declare-fun v_1_ack_advance () Bool)
(declare-fun v_1_ack_is_future () Bool)
(declare-fun v_1_ack_is_new () Bool)
(declare-fun v_1_ack_delta () Int)
(declare-fun v_1_seg_acceptable () Bool)
(declare-fun v_0_rx_acceptable () Bool)
(declare-fun v_1_rx_acceptable () Bool)
(declare-fun v_1_rx_advance () Int)
(declare-fun v_1_rx_slot_15 () Int)
(declare-fun v_1_rx_slot_14 () Int)
(declare-fun v_1_rx_slot_13 () Int)
(declare-fun v_1_rx_slot_12 () Int)
(declare-fun v_1_rx_slot_11 () Int)
(declare-fun v_1_rx_slot_10 () Int)
(declare-fun v_1_rx_slot_09 () Int)
(declare-fun v_1_rx_slot_08 () Int)
(declare-fun v_1_rx_slot_07 () Int)
(declare-fun v_1_rx_slot_06 () Int)
(declare-fun v_1_rx_slot_05 () Int)
(declare-fun v_1_rx_slot_04 () Int)
(declare-fun v_1_rx_slot_03 () Int)
(declare-fun v_1_rx_slot_02 () Int)
(declare-fun v_1_rx_slot_01 () Int)
(declare-fun v_1_rx_slot_00 () Int)
(declare-fun v_1_rx_chunk () Int)
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () Int)
(declare-fun v_1_snd_wl1 () Int)
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () Int)
(declare-fun v_1_rtx_buf () Int)
(declare-fun v_1_snd_buf () Int)
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_0_tx_flags () String)
(declare-fun v_1_tx_flags () String)
(declare-fun v_0_tx_ack () Int)
(declare-fun v_1_tx_ack () Int)
(declare-fun v_0_tx_seq () Int)
(declare-fun v_1_tx_seq () Int)
(declare-fun v_1_rcv_nxt () Int)
(declare-fun v_1_snd_nxt () Int)
(declare-fun v_1_snd_una () Int)
(declare-fun v_0_irs () Int)
(declare-fun v_1_irs () Int)
(declare-fun v_0_iss () Int)
(declare-fun v_1_iss () Int)
(declare-fun input_0_net.fin_segment_ack () Int)
(declare-fun input_0_net.fin_segment_seq () Int)
(declare-fun input_0_net.data_ack () Int)
(declare-fun input_0_net.data_seq () Int)
(declare-fun input_0_net.rstack_ack () Int)
(declare-fun input_0_net.rstack_seq () Int)
(declare-fun input_0_net.rst_seq () Int)
(declare-fun input_0_net.fin_ack () Int)
(declare-fun input_0_net.fin_seq () Int)
(declare-fun input_0_net.synack_ack () Int)
(declare-fun input_0_net.synack_seq () Int)
(declare-fun input_0_net.syn_seq () Int)
(declare-fun input_0_net.fin_segment_data () Int)
(declare-fun input_0_net.data_data () Int)
(declare-fun input_0_app.send_data () Int)
(declare-fun v_0_cb_append_end () Int)
(declare-fun v_0_cb_before_nxt () Int)
(declare-fun v_0_fr_before_una () Int)
(declare-fun v_0_cc_before_una () Int)
(assert (= v_0_cb_head 15))
(assert (let ((a!1 (>= (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) (- 4294967296)))
      (a!2 (< (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 8589934592))
      (a!3 (< (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 0))
      (a!4 (+ (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!5 (>= (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!6 (- (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!8 (mod (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!10 (>= (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) (- 4294967296)))
      (a!11 (< (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 8589934592))
      (a!12 (< (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 0))
      (a!13 (+ (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!14 (>= (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!15 (- (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!17 (mod (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!19 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) (- 4294967296)))
      (a!20 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 8589934592))
      (a!21 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 0))
      (a!22 (+ (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!23 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!24 (- (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!26 (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!28 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) (- 4294967296)))
      (a!29 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 8589934592))
      (a!30 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 0))
      (a!31 (+ (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!32 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!33 (- (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!35 (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!41 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) (- 4294967296)))
      (a!42 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 8589934592))
      (a!43 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 0))
      (a!44 (+ (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!45 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!46 (- (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!48 (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!50 (>= (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) (- 4294967296)))
      (a!51 (< (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 8589934592))
      (a!52 (< (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 0))
      (a!53 (+ (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!54 (>= (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!55 (- (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!57 (mod (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!66 (and (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)))
      (a!74 (+ (* (- (/ 1.0 2.0)) (to_real v_0_rtx_buf))
               (* (/ 1.0 2.0) (to_real v_0_lt_epoch_bytes))))
      (a!77 (and (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)
                 v_0_fr_active))
      (a!91 (>= (+ v_0_rtt_end (* (- 1) v_0_snd_una)) (- 4294967296)))
      (a!92 (< (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 8589934592))
      (a!93 (< (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 0))
      (a!94 (+ (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!95 (>= (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!96 (- (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!98 (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!259 (= v_1_tx_fin_time
                (ite (and v_0_fin_sent (not v_0_fin_acknowledged))
                     v_0_tx_fin_time
                     0)))
      (a!266 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd)
                (* (- 1) v_0_rtx_buf)))
      (a!370 (ite v_0_idle_data_valid
                  (+ now_1 (* (- 1) v_0_idle_last_data_ms))
                  0))
      (a!375 (= v_1_lt_loss_flight (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes))))
      (a!378 (ite (>= 0 v_0_cb_head)
                  (* (- 1) v_0_cb_head)
                  (+ 16 (* (- 1) v_0_cb_head))))
      (a!389 (ite (>= 1 v_0_cb_head)
                  (+ 1 (* (- 1) v_0_cb_head))
                  (+ 17 (* (- 1) v_0_cb_head))))
      (a!400 (ite (>= 2 v_0_cb_head)
                  (+ 2 (* (- 1) v_0_cb_head))
                  (+ 18 (* (- 1) v_0_cb_head))))
      (a!411 (ite (>= 3 v_0_cb_head)
                  (+ 3 (* (- 1) v_0_cb_head))
                  (+ 19 (* (- 1) v_0_cb_head))))
      (a!422 (ite (>= 4 v_0_cb_head)
                  (+ 4 (* (- 1) v_0_cb_head))
                  (+ 20 (* (- 1) v_0_cb_head))))
      (a!433 (ite (>= 5 v_0_cb_head)
                  (+ 5 (* (- 1) v_0_cb_head))
                  (+ 21 (* (- 1) v_0_cb_head))))
      (a!444 (ite (>= 6 v_0_cb_head)
                  (+ 6 (* (- 1) v_0_cb_head))
                  (+ 22 (* (- 1) v_0_cb_head))))
      (a!455 (ite (>= 7 v_0_cb_head)
                  (+ 7 (* (- 1) v_0_cb_head))
                  (+ 23 (* (- 1) v_0_cb_head))))
      (a!466 (ite (>= 8 v_0_cb_head)
                  (+ 8 (* (- 1) v_0_cb_head))
                  (+ 24 (* (- 1) v_0_cb_head))))
      (a!477 (ite (>= 9 v_0_cb_head)
                  (+ 9 (* (- 1) v_0_cb_head))
                  (+ 25 (* (- 1) v_0_cb_head))))
      (a!488 (ite (>= 10 v_0_cb_head)
                  (+ 10 (* (- 1) v_0_cb_head))
                  (+ 26 (* (- 1) v_0_cb_head))))
      (a!499 (ite (>= 11 v_0_cb_head)
                  (+ 11 (* (- 1) v_0_cb_head))
                  (+ 27 (* (- 1) v_0_cb_head))))
      (a!510 (ite (>= 12 v_0_cb_head)
                  (+ 12 (* (- 1) v_0_cb_head))
                  (+ 28 (* (- 1) v_0_cb_head))))
      (a!521 (ite (>= 13 v_0_cb_head)
                  (+ 13 (* (- 1) v_0_cb_head))
                  (+ 29 (* (- 1) v_0_cb_head))))
      (a!532 (ite (>= 14 v_0_cb_head)
                  (+ 14 (* (- 1) v_0_cb_head))
                  (+ 30 (* (- 1) v_0_cb_head))))
      (a!543 (ite (>= 15 v_0_cb_head)
                  (+ 15 (* (- 1) v_0_cb_head))
                  (+ 31 (* (- 1) v_0_cb_head))))
      (a!675 (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf))))
      (a!676 (>= 16
                 (+ v_0_rcv_buf
                    v_0_rx_slot_00
                    v_0_rx_slot_01
                    v_0_rx_slot_02
                    v_0_rx_slot_03
                    v_0_rx_slot_04
                    v_0_rx_slot_05
                    v_0_rx_slot_06
                    v_0_rx_slot_07
                    v_0_rx_slot_08
                    v_0_rx_slot_09
                    v_0_rx_slot_10
                    v_0_rx_slot_11
                    v_0_rx_slot_12
                    v_0_rx_slot_13
                    v_0_rx_slot_14
                    v_0_rx_slot_15)))
      (a!677 (and (>= (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                      (- 4294967296))
                  (< (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                     8589934592)))
      (a!678 (ite (>= (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                      4294967296)
                  (- (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                     4294967296)
                  (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))))
      (a!681 (and (not v_0_rx_fin_done)
                  (<= 1 v_0_rx_fin_offset)
                  (<= v_0_rx_fin_offset (+ (- 1) v_0_local_window))))
      (a!682 (ite (< (+ v_0_rcv_nxt v_0_rx_fin_offset) 0)
                  (+ (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                  (ite (>= (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                       (- (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                       (+ v_0_rcv_nxt v_0_rx_fin_offset))))
      (a!684 (ite (< (+ 1 v_0_rx_fin_seq) 0)
                  (+ (+ 1 v_0_rx_fin_seq) 4294967296)
                  (ite (>= (+ 1 v_0_rx_fin_seq) 4294967296)
                       (- (+ 1 v_0_rx_fin_seq) 4294967296)
                       (+ 1 v_0_rx_fin_seq))))
      (a!686 (or (not (and v_0_rx_fin_pending (>= 0 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_00)))
      (a!687 (or (not (and v_0_rx_fin_pending (>= 1 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_01)))
      (a!688 (or (not (and v_0_rx_fin_pending (>= 2 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_02)))
      (a!689 (or (not (and v_0_rx_fin_pending (>= 3 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_03)))
      (a!690 (or (not (and v_0_rx_fin_pending (>= 4 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_04)))
      (a!691 (or (not (and v_0_rx_fin_pending (>= 5 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_05)))
      (a!692 (or (not (and v_0_rx_fin_pending (>= 6 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_06)))
      (a!693 (or (not (and v_0_rx_fin_pending (>= 7 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_07)))
      (a!694 (or (not (and v_0_rx_fin_pending (>= 8 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_08)))
      (a!695 (or (not (and v_0_rx_fin_pending (>= 9 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_09)))
      (a!696 (or (not (and v_0_rx_fin_pending (>= 10 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_10)))
      (a!697 (or (not (and v_0_rx_fin_pending (>= 11 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_11)))
      (a!698 (or (not (and v_0_rx_fin_pending (>= 12 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_12)))
      (a!699 (or (not (and v_0_rx_fin_pending (>= 13 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_13)))
      (a!700 (or (not (and v_0_rx_fin_pending (>= 14 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_14)))
      (a!701 (or (not (and v_0_rx_fin_pending (>= 15 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_15)))
      (a!702 (* (- 1.0)
                (ite (<= v_0_rttvar_ms (/ 1.0 4.0)) 1.0 (* 4.0 v_0_rttvar_ms))))
      (a!706 (>= (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) (- 4294967296)))
      (a!707 (< (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 8589934592))
      (a!708 (< (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 0))
      (a!709 (+ (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!710 (>= (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!711 (- (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!713 (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!715 (= v_0_rtt_last_ms
                (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms))))
      (a!716 (>= (+ v_0_rtt_previous_srtt (* (- 1.0) (to_real v_0_rtt_last_ms)))
                 0.0))
      (a!719 (ite v_0_rtt_previous_measured
                  (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt)
                     (* (/ 1.0 8.0) (to_real v_0_rtt_last_ms)))
                  (to_real v_0_rtt_last_ms)))
      (a!721 (or (not v_0_tx_retransmitted)
                 (and (>= v_0_tx_elapsed v_0_tx_previous_rto)
                      (<= 1 v_0_tx_emit_count)
                      (or (not v_0_tx_is_fin) (= 1 v_0_tx_emit_count)))))
      (a!722 (or v_0_ack_pending
                 (and (= 0 v_0_ack_bytes)
                      (= 0 v_0_ack_full_segments)
                      (= 0 v_0_ack_since_ms))))
      (a!723 (and (<= 1 (+ v_0_rtx_buf (ite v_0_fin_sent 1 0)))
                  (not v_0_persist_active)))
      (a!724 (or (not v_0_persist_active)
                 (and (= 0 v_0_snd_wnd)
                      (not v_0_fin_sent)
                      (<= 1 (+ v_0_rtx_buf v_0_snd_buf))
                      (>= 1 v_0_rtx_buf)
                      (not active_0_rtx))))
      (a!725 (= v_0_persist_deadline_ms
                (+ (ite (= 0 v_0_persist_probes)
                        v_0_persist_since_ms
                        v_0_persist_last_ms)
                   v_0_persist_interval_ms)))
      (a!726 (or (not v_0_persist_probe_sent)
                 (and (>= v_0_persist_elapsed_ms
                          v_0_persist_previous_interval_ms)
                      (= 1 v_0_rtx_buf))))
      (a!727 (or (not (and v_0_persist_active
                           (<= 1 v_0_persist_probes)
                           (= 1 v_0_rtx_buf)))
                 (= v_0_tx_time_00 v_0_persist_last_ms)))
      (a!728 (or v_0_persist_active
                 (and (= 0 v_0_persist_since_ms)
                      (= 0 v_0_persist_last_ms)
                      (= 0 v_0_persist_deadline_ms)
                      (= 0 v_0_persist_probes))))
      (a!729 (or (not v_0_fr_active)
                 (and (<= 3 v_0_fr_dupacks)
                      (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active))))
      (a!730 (or (not v_0_fr_retransmitted)
                 (and v_0_fr_entered
                      (= 3 v_0_fr_dupacks)
                      (<= 1 v_0_fr_emit_count)
                      (= v_0_snd_nxt v_0_fr_before_nxt)
                      (= v_0_rto_ms v_0_fr_before_rto)
                      (= v_0_retries v_0_fr_before_retries)
                      (not v_0_tx_retransmitted))))
      (a!731 (or (not v_0_fr_window_ignored)
                 (and (= v_0_fr_last_window v_0_fr_before_wire_window)
                      (= v_0_fr_window_valid v_0_fr_before_window_valid))))
      (a!732 (or (not v_0_fr_exited)
                 (and (= v_0_cc_cwnd v_0_cc_ssthresh) (= 0 v_0_cc_ca_credit))))
      (a!733 (and (not (>= v_0_idle_before_rto v_0_idle_elapsed_ms))
                  (= v_0_cc_cwnd
                     (ite (<= v_0_cc_initial_window v_0_idle_before_cwnd)
                          v_0_cc_initial_window
                          v_0_idle_before_cwnd))
                  (= v_0_cc_ssthresh v_0_idle_before_threshold)
                  (= 0 v_0_cc_ca_credit)))
      (a!734 (ite (< (+ v_0_lt_before_nxt v_0_lt_take) 0)
                  (+ (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                  (ite (>= (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                       (- (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                       (+ v_0_lt_before_nxt v_0_lt_take))))
      (a!737 (= v_0_lt_loss_flight
                (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes))))
      (a!738 (ite (< (+ v_0_choice_before_nxt v_0_choice_count) 0)
                  (+ (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)
                  (ite (>= (+ v_0_choice_before_nxt v_0_choice_count)
                           4294967296)
                       (- (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)
                       (+ v_0_choice_before_nxt v_0_choice_count))))
      (a!741 (= v_0_cb_tail
                (ite (<= 16 (+ v_0_cb_head v_0_cb_count))
                     (+ (- 16) v_0_cb_head v_0_cb_count)
                     (+ v_0_cb_head v_0_cb_count))))
      (a!742 (= v_0_cb_live_total
                (+ v_0_cb_length_00
                   v_0_cb_length_01
                   v_0_cb_length_02
                   v_0_cb_length_03
                   v_0_cb_length_04
                   v_0_cb_length_05
                   v_0_cb_length_06
                   v_0_cb_length_07
                   v_0_cb_length_08
                   v_0_cb_length_09
                   v_0_cb_length_10
                   v_0_cb_length_11
                   v_0_cb_length_12
                   v_0_cb_length_13
                   v_0_cb_length_14
                   v_0_cb_length_15)))
      (a!743 (= v_0_cb_partial_prefix
                (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf))))
      (a!745 (>= (+ v_0_snd_una
                    v_0_cb_length_00
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!746 (< (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!747 (< (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!748 (+ (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!749 (>= (+ v_0_snd_una
                    v_0_cb_length_00
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!750 (- (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!752 (mod (+ v_0_snd_una
                     v_0_cb_length_00
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!755 (ite (< (+ v_0_cb_end_15 v_0_cb_length_00) 0)
                  (+ (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                  (ite (>= (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                       (- (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                       (+ v_0_cb_end_15 v_0_cb_length_00))))
      (a!758 (>= (+ v_0_snd_una
                    v_0_cb_length_01
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!759 (< (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!760 (< (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!761 (+ (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!762 (>= (+ v_0_snd_una
                    v_0_cb_length_01
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!763 (- (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!765 (mod (+ v_0_snd_una
                     v_0_cb_length_01
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!768 (ite (< (+ v_0_cb_end_00 v_0_cb_length_01) 0)
                  (+ (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                  (ite (>= (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                       (- (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                       (+ v_0_cb_end_00 v_0_cb_length_01))))
      (a!771 (>= (+ v_0_snd_una
                    v_0_cb_length_02
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!772 (< (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!773 (< (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!774 (+ (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!775 (>= (+ v_0_snd_una
                    v_0_cb_length_02
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!776 (- (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!778 (mod (+ v_0_snd_una
                     v_0_cb_length_02
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!781 (ite (< (+ v_0_cb_end_01 v_0_cb_length_02) 0)
                  (+ (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                  (ite (>= (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                       (- (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                       (+ v_0_cb_end_01 v_0_cb_length_02))))
      (a!784 (>= (+ v_0_snd_una
                    v_0_cb_length_03
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!785 (< (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!786 (< (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!787 (+ (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!788 (>= (+ v_0_snd_una
                    v_0_cb_length_03
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!789 (- (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!791 (mod (+ v_0_snd_una
                     v_0_cb_length_03
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!794 (ite (< (+ v_0_cb_end_02 v_0_cb_length_03) 0)
                  (+ (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                  (ite (>= (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                       (- (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                       (+ v_0_cb_end_02 v_0_cb_length_03))))
      (a!797 (>= (+ v_0_snd_una
                    v_0_cb_length_04
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!798 (< (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!799 (< (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!800 (+ (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!801 (>= (+ v_0_snd_una
                    v_0_cb_length_04
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!802 (- (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!804 (mod (+ v_0_snd_una
                     v_0_cb_length_04
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!807 (ite (< (+ v_0_cb_end_03 v_0_cb_length_04) 0)
                  (+ (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                  (ite (>= (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                       (- (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                       (+ v_0_cb_end_03 v_0_cb_length_04))))
      (a!810 (>= (+ v_0_snd_una
                    v_0_cb_length_05
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!811 (< (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!812 (< (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!813 (+ (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!814 (>= (+ v_0_snd_una
                    v_0_cb_length_05
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!815 (- (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!817 (mod (+ v_0_snd_una
                     v_0_cb_length_05
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!820 (ite (< (+ v_0_cb_end_04 v_0_cb_length_05) 0)
                  (+ (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                  (ite (>= (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                       (- (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                       (+ v_0_cb_end_04 v_0_cb_length_05))))
      (a!823 (>= (+ v_0_snd_una
                    v_0_cb_length_06
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!824 (< (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!825 (< (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!826 (+ (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!827 (>= (+ v_0_snd_una
                    v_0_cb_length_06
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!828 (- (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!830 (mod (+ v_0_snd_una
                     v_0_cb_length_06
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!833 (ite (< (+ v_0_cb_end_05 v_0_cb_length_06) 0)
                  (+ (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                  (ite (>= (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                       (- (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                       (+ v_0_cb_end_05 v_0_cb_length_06))))
      (a!836 (>= (+ v_0_snd_una
                    v_0_cb_length_07
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!837 (< (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!838 (< (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!839 (+ (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!840 (>= (+ v_0_snd_una
                    v_0_cb_length_07
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!841 (- (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!843 (mod (+ v_0_snd_una
                     v_0_cb_length_07
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!846 (ite (< (+ v_0_cb_end_06 v_0_cb_length_07) 0)
                  (+ (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                  (ite (>= (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                       (- (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                       (+ v_0_cb_end_06 v_0_cb_length_07))))
      (a!849 (>= (+ v_0_snd_una
                    v_0_cb_length_08
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!850 (< (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!851 (< (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!852 (+ (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!853 (>= (+ v_0_snd_una
                    v_0_cb_length_08
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!854 (- (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!856 (mod (+ v_0_snd_una
                     v_0_cb_length_08
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!859 (ite (< (+ v_0_cb_end_07 v_0_cb_length_08) 0)
                  (+ (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                  (ite (>= (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                       (- (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                       (+ v_0_cb_end_07 v_0_cb_length_08))))
      (a!862 (>= (+ v_0_snd_una
                    v_0_cb_length_09
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!863 (< (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!864 (< (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!865 (+ (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!866 (>= (+ v_0_snd_una
                    v_0_cb_length_09
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!867 (- (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!869 (mod (+ v_0_snd_una
                     v_0_cb_length_09
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!872 (ite (< (+ v_0_cb_end_08 v_0_cb_length_09) 0)
                  (+ (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)
                  (ite (>= (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)
                       (- (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)
                       (+ v_0_cb_end_08 v_0_cb_length_09))))
      (a!875 (>= (+ v_0_snd_una
                    v_0_cb_length_10
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!876 (< (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!877 (< (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!878 (+ (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!879 (>= (+ v_0_snd_una
                    v_0_cb_length_10
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!880 (- (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!882 (mod (+ v_0_snd_una
                     v_0_cb_length_10
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!885 (ite (< (+ v_0_cb_end_09 v_0_cb_length_10) 0)
                  (+ (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                  (ite (>= (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                       (- (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                       (+ v_0_cb_end_09 v_0_cb_length_10))))
      (a!888 (>= (+ v_0_snd_una
                    v_0_cb_length_11
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!889 (< (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!890 (< (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!891 (+ (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!892 (>= (+ v_0_snd_una
                    v_0_cb_length_11
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!893 (- (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!895 (mod (+ v_0_snd_una
                     v_0_cb_length_11
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!898 (ite (< (+ v_0_cb_end_10 v_0_cb_length_11) 0)
                  (+ (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                  (ite (>= (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                       (- (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                       (+ v_0_cb_end_10 v_0_cb_length_11))))
      (a!901 (>= (+ v_0_snd_una
                    v_0_cb_length_12
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!902 (< (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!903 (< (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!904 (+ (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!905 (>= (+ v_0_snd_una
                    v_0_cb_length_12
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!906 (- (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!908 (mod (+ v_0_snd_una
                     v_0_cb_length_12
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!911 (ite (< (+ v_0_cb_end_11 v_0_cb_length_12) 0)
                  (+ (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                  (ite (>= (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                       (- (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                       (+ v_0_cb_end_11 v_0_cb_length_12))))
      (a!914 (>= (+ v_0_snd_una
                    v_0_cb_length_13
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!915 (< (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!916 (< (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!917 (+ (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!918 (>= (+ v_0_snd_una
                    v_0_cb_length_13
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!919 (- (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!921 (mod (+ v_0_snd_una
                     v_0_cb_length_13
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!924 (ite (< (+ v_0_cb_end_12 v_0_cb_length_13) 0)
                  (+ (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                  (ite (>= (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                       (- (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                       (+ v_0_cb_end_12 v_0_cb_length_13))))
      (a!927 (>= (+ v_0_snd_una
                    v_0_cb_length_14
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!928 (< (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!929 (< (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!930 (+ (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!931 (>= (+ v_0_snd_una
                    v_0_cb_length_14
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!932 (- (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!934 (mod (+ v_0_snd_una
                     v_0_cb_length_14
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!937 (ite (< (+ v_0_cb_end_13 v_0_cb_length_14) 0)
                  (+ (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                  (ite (>= (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                       (- (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                       (+ v_0_cb_end_13 v_0_cb_length_14))))
      (a!940 (>= (+ v_0_snd_una
                    v_0_cb_length_15
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!941 (< (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!942 (< (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!943 (+ (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!944 (>= (+ v_0_snd_una
                    v_0_cb_length_15
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!945 (- (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!947 (mod (+ v_0_snd_una
                     v_0_cb_length_15
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!950 (ite (< (+ v_0_cb_end_14 v_0_cb_length_15) 0)
                  (+ (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                  (ite (>= (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                       (- (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                       (+ v_0_cb_end_14 v_0_cb_length_15))))
      (a!953 (ite (>= 0 15) (* (- 1) 15) (+ 16 (* (- 1) 15))))
      (a!955 (ite (>= 1 15) (+ 1 (* (- 1) 15)) (+ 17 (* (- 1) 15))))
      (a!957 (ite (>= 2 15) (+ 2 (* (- 1) 15)) (+ 18 (* (- 1) 15))))
      (a!959 (ite (>= 3 15) (+ 3 (* (- 1) 15)) (+ 19 (* (- 1) 15))))
      (a!961 (ite (>= 4 15) (+ 4 (* (- 1) 15)) (+ 20 (* (- 1) 15))))
      (a!963 (ite (>= 5 15) (+ 5 (* (- 1) 15)) (+ 21 (* (- 1) 15))))
      (a!965 (ite (>= 6 15) (+ 6 (* (- 1) 15)) (+ 22 (* (- 1) 15))))
      (a!967 (ite (>= 7 15) (+ 7 (* (- 1) 15)) (+ 23 (* (- 1) 15))))
      (a!969 (ite (>= 8 15) (+ 8 (* (- 1) 15)) (+ 24 (* (- 1) 15))))
      (a!971 (ite (>= 9 15) (+ 9 (* (- 1) 15)) (+ 25 (* (- 1) 15))))
      (a!973 (ite (>= 10 15) (+ 10 (* (- 1) 15)) (+ 26 (* (- 1) 15))))
      (a!975 (ite (>= 11 15) (+ 11 (* (- 1) 15)) (+ 27 (* (- 1) 15))))
      (a!977 (ite (>= 12 15) (+ 12 (* (- 1) 15)) (+ 28 (* (- 1) 15))))
      (a!979 (ite (>= 13 15) (+ 13 (* (- 1) 15)) (+ 29 (* (- 1) 15))))
      (a!981 (ite (>= 14 15) (+ 14 (* (- 1) 15)) (+ 30 (* (- 1) 15))))
      (a!983 (ite (>= 15 15) (+ 15 (* (- 1) 15)) (+ 31 (* (- 1) 15))))
      (a!1086 (= v_0_cb_tail
                 (ite (<= 16 (+ 15 v_0_cb_count))
                      (+ (- 16) 15 v_0_cb_count)
                      (+ 15 v_0_cb_count)))))
(let ((a!7 (ite a!5 a!6 (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq))))
      (a!16 (ite a!14 a!15 (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt))))
      (a!25 (ite a!23 a!24 (+ input_0_net.ack_ack (* (- 1) v_0_snd_una))))
      (a!34 (ite a!32 a!33 (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt))))
      (a!47 (ite a!45 a!46 (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2))))
      (a!56 (ite a!54 a!55 (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1))))
      (a!75 (<= 8 (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes) (to_int a!74))))
      (a!97 (ite a!95 a!96 (+ v_0_rtt_end (* (- 1) v_0_snd_una))))
      (a!679 (ite (< (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)) 0)
                  (+ (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                     4294967296)
                  a!678))
      (a!683 (ite (and (>= (+ v_0_rcv_nxt v_0_rx_fin_offset) (- 4294967296))
                       (< (+ v_0_rcv_nxt v_0_rx_fin_offset) 8589934592))
                  a!682
                  (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)))
      (a!685 (ite (and (>= (+ 1 v_0_rx_fin_seq) (- 4294967296))
                       (< (+ 1 v_0_rx_fin_seq) 8589934592))
                  a!684
                  (mod (+ 1 v_0_rx_fin_seq) 4294967296)))
      (a!703 (to_int (+ (* (- 1.0) v_0_srtt_ms) a!702)))
      (a!712 (ite a!710 a!711 (+ v_0_snd_nxt (* (- 1) v_0_snd_una))))
      (a!717 (ite a!716
                  (+ v_0_rtt_previous_srtt
                     (* (- 1.0) (to_real v_0_rtt_last_ms)))
                  (+ (* (- 1.0) v_0_rtt_previous_srtt)
                     (to_real v_0_rtt_last_ms))))
      (a!735 (ite (and (>= (+ v_0_lt_before_nxt v_0_lt_take) (- 4294967296))
                       (< (+ v_0_lt_before_nxt v_0_lt_take) 8589934592))
                  a!734
                  (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)))
      (a!739 (ite (and (>= (+ v_0_choice_before_nxt v_0_choice_count)
                           (- 4294967296))
                       (< (+ v_0_choice_before_nxt v_0_choice_count) 8589934592))
                  a!738
                  (mod (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)))
      (a!744 (not (and (not (>= a!378 v_0_cb_count)) (= 0 v_0_cb_head))))
      (a!751 (ite a!749
                  a!750
                  (+ v_0_snd_una
                     v_0_cb_length_00
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!754 (not (and (not (>= a!378 v_0_cb_count)) (<= 1 a!378))))
      (a!756 (ite (and (>= (+ v_0_cb_end_15 v_0_cb_length_00) (- 4294967296))
                       (< (+ v_0_cb_end_15 v_0_cb_length_00) 8589934592))
                  a!755
                  (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)))
      (a!757 (not (and (not (>= a!389 v_0_cb_count)) (= 1 v_0_cb_head))))
      (a!764 (ite a!762
                  a!763
                  (+ v_0_snd_una
                     v_0_cb_length_01
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!767 (not (and (not (>= a!389 v_0_cb_count)) (<= 1 a!389))))
      (a!769 (ite (and (>= (+ v_0_cb_end_00 v_0_cb_length_01) (- 4294967296))
                       (< (+ v_0_cb_end_00 v_0_cb_length_01) 8589934592))
                  a!768
                  (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)))
      (a!770 (not (and (not (>= a!400 v_0_cb_count)) (= 2 v_0_cb_head))))
      (a!777 (ite a!775
                  a!776
                  (+ v_0_snd_una
                     v_0_cb_length_02
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!780 (not (and (not (>= a!400 v_0_cb_count)) (<= 1 a!400))))
      (a!782 (ite (and (>= (+ v_0_cb_end_01 v_0_cb_length_02) (- 4294967296))
                       (< (+ v_0_cb_end_01 v_0_cb_length_02) 8589934592))
                  a!781
                  (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)))
      (a!783 (not (and (not (>= a!411 v_0_cb_count)) (= 3 v_0_cb_head))))
      (a!790 (ite a!788
                  a!789
                  (+ v_0_snd_una
                     v_0_cb_length_03
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!793 (not (and (not (>= a!411 v_0_cb_count)) (<= 1 a!411))))
      (a!795 (ite (and (>= (+ v_0_cb_end_02 v_0_cb_length_03) (- 4294967296))
                       (< (+ v_0_cb_end_02 v_0_cb_length_03) 8589934592))
                  a!794
                  (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)))
      (a!796 (not (and (not (>= a!422 v_0_cb_count)) (= 4 v_0_cb_head))))
      (a!803 (ite a!801
                  a!802
                  (+ v_0_snd_una
                     v_0_cb_length_04
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!806 (not (and (not (>= a!422 v_0_cb_count)) (<= 1 a!422))))
      (a!808 (ite (and (>= (+ v_0_cb_end_03 v_0_cb_length_04) (- 4294967296))
                       (< (+ v_0_cb_end_03 v_0_cb_length_04) 8589934592))
                  a!807
                  (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)))
      (a!809 (not (and (not (>= a!433 v_0_cb_count)) (= 5 v_0_cb_head))))
      (a!816 (ite a!814
                  a!815
                  (+ v_0_snd_una
                     v_0_cb_length_05
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!819 (not (and (not (>= a!433 v_0_cb_count)) (<= 1 a!433))))
      (a!821 (ite (and (>= (+ v_0_cb_end_04 v_0_cb_length_05) (- 4294967296))
                       (< (+ v_0_cb_end_04 v_0_cb_length_05) 8589934592))
                  a!820
                  (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)))
      (a!822 (not (and (not (>= a!444 v_0_cb_count)) (= 6 v_0_cb_head))))
      (a!829 (ite a!827
                  a!828
                  (+ v_0_snd_una
                     v_0_cb_length_06
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!832 (not (and (not (>= a!444 v_0_cb_count)) (<= 1 a!444))))
      (a!834 (ite (and (>= (+ v_0_cb_end_05 v_0_cb_length_06) (- 4294967296))
                       (< (+ v_0_cb_end_05 v_0_cb_length_06) 8589934592))
                  a!833
                  (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)))
      (a!835 (not (and (not (>= a!455 v_0_cb_count)) (= 7 v_0_cb_head))))
      (a!842 (ite a!840
                  a!841
                  (+ v_0_snd_una
                     v_0_cb_length_07
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!845 (not (and (not (>= a!455 v_0_cb_count)) (<= 1 a!455))))
      (a!847 (ite (and (>= (+ v_0_cb_end_06 v_0_cb_length_07) (- 4294967296))
                       (< (+ v_0_cb_end_06 v_0_cb_length_07) 8589934592))
                  a!846
                  (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)))
      (a!848 (not (and (not (>= a!466 v_0_cb_count)) (= 8 v_0_cb_head))))
      (a!855 (ite a!853
                  a!854
                  (+ v_0_snd_una
                     v_0_cb_length_08
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!858 (not (and (not (>= a!466 v_0_cb_count)) (<= 1 a!466))))
      (a!860 (ite (and (>= (+ v_0_cb_end_07 v_0_cb_length_08) (- 4294967296))
                       (< (+ v_0_cb_end_07 v_0_cb_length_08) 8589934592))
                  a!859
                  (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)))
      (a!861 (not (and (not (>= a!477 v_0_cb_count)) (= 9 v_0_cb_head))))
      (a!868 (ite a!866
                  a!867
                  (+ v_0_snd_una
                     v_0_cb_length_09
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!871 (not (and (not (>= a!477 v_0_cb_count)) (<= 1 a!477))))
      (a!873 (ite (and (>= (+ v_0_cb_end_08 v_0_cb_length_09) (- 4294967296))
                       (< (+ v_0_cb_end_08 v_0_cb_length_09) 8589934592))
                  a!872
                  (mod (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)))
      (a!874 (not (and (not (>= a!488 v_0_cb_count)) (= 10 v_0_cb_head))))
      (a!881 (ite a!879
                  a!880
                  (+ v_0_snd_una
                     v_0_cb_length_10
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!884 (not (and (not (>= a!488 v_0_cb_count)) (<= 1 a!488))))
      (a!886 (ite (and (>= (+ v_0_cb_end_09 v_0_cb_length_10) (- 4294967296))
                       (< (+ v_0_cb_end_09 v_0_cb_length_10) 8589934592))
                  a!885
                  (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)))
      (a!887 (not (and (not (>= a!499 v_0_cb_count)) (= 11 v_0_cb_head))))
      (a!894 (ite a!892
                  a!893
                  (+ v_0_snd_una
                     v_0_cb_length_11
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!897 (not (and (not (>= a!499 v_0_cb_count)) (<= 1 a!499))))
      (a!899 (ite (and (>= (+ v_0_cb_end_10 v_0_cb_length_11) (- 4294967296))
                       (< (+ v_0_cb_end_10 v_0_cb_length_11) 8589934592))
                  a!898
                  (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)))
      (a!900 (not (and (not (>= a!510 v_0_cb_count)) (= 12 v_0_cb_head))))
      (a!907 (ite a!905
                  a!906
                  (+ v_0_snd_una
                     v_0_cb_length_12
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!910 (not (and (not (>= a!510 v_0_cb_count)) (<= 1 a!510))))
      (a!912 (ite (and (>= (+ v_0_cb_end_11 v_0_cb_length_12) (- 4294967296))
                       (< (+ v_0_cb_end_11 v_0_cb_length_12) 8589934592))
                  a!911
                  (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)))
      (a!913 (not (and (not (>= a!521 v_0_cb_count)) (= 13 v_0_cb_head))))
      (a!920 (ite a!918
                  a!919
                  (+ v_0_snd_una
                     v_0_cb_length_13
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!923 (not (and (not (>= a!521 v_0_cb_count)) (<= 1 a!521))))
      (a!925 (ite (and (>= (+ v_0_cb_end_12 v_0_cb_length_13) (- 4294967296))
                       (< (+ v_0_cb_end_12 v_0_cb_length_13) 8589934592))
                  a!924
                  (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)))
      (a!926 (not (and (not (>= a!532 v_0_cb_count)) (= 14 v_0_cb_head))))
      (a!933 (ite a!931
                  a!932
                  (+ v_0_snd_una
                     v_0_cb_length_14
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!936 (not (and (not (>= a!532 v_0_cb_count)) (<= 1 a!532))))
      (a!938 (ite (and (>= (+ v_0_cb_end_13 v_0_cb_length_14) (- 4294967296))
                       (< (+ v_0_cb_end_13 v_0_cb_length_14) 8589934592))
                  a!937
                  (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)))
      (a!939 (not (and (not (>= a!543 v_0_cb_count)) (= 15 v_0_cb_head))))
      (a!946 (ite a!944
                  a!945
                  (+ v_0_snd_una
                     v_0_cb_length_15
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!949 (not (and (not (>= a!543 v_0_cb_count)) (<= 1 a!543))))
      (a!951 (ite (and (>= (+ v_0_cb_end_14 v_0_cb_length_15) (- 4294967296))
                       (< (+ v_0_cb_end_14 v_0_cb_length_15) 8589934592))
                  a!950
                  (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))
      (a!1087 (not (and (not (>= a!953 v_0_cb_count)) (= 0 15))))
      (a!1088 (not (and (not (>= a!953 v_0_cb_count)) (<= 1 a!953))))
      (a!1089 (not (and (not (>= a!955 v_0_cb_count)) (= 1 15))))
      (a!1090 (not (and (not (>= a!955 v_0_cb_count)) (<= 1 a!955))))
      (a!1091 (not (and (not (>= a!957 v_0_cb_count)) (= 2 15))))
      (a!1092 (not (and (not (>= a!957 v_0_cb_count)) (<= 1 a!957))))
      (a!1093 (not (and (not (>= a!959 v_0_cb_count)) (= 3 15))))
      (a!1094 (not (and (not (>= a!959 v_0_cb_count)) (<= 1 a!959))))
      (a!1095 (not (and (not (>= a!961 v_0_cb_count)) (= 4 15))))
      (a!1096 (not (and (not (>= a!961 v_0_cb_count)) (<= 1 a!961))))
      (a!1097 (not (and (not (>= a!963 v_0_cb_count)) (= 5 15))))
      (a!1098 (not (and (not (>= a!963 v_0_cb_count)) (<= 1 a!963))))
      (a!1099 (not (and (not (>= a!965 v_0_cb_count)) (= 6 15))))
      (a!1100 (not (and (not (>= a!965 v_0_cb_count)) (<= 1 a!965))))
      (a!1101 (not (and (not (>= a!967 v_0_cb_count)) (= 7 15))))
      (a!1102 (not (and (not (>= a!967 v_0_cb_count)) (<= 1 a!967))))
      (a!1103 (not (and (not (>= a!969 v_0_cb_count)) (= 8 15))))
      (a!1104 (not (and (not (>= a!969 v_0_cb_count)) (<= 1 a!969))))
      (a!1105 (not (and (not (>= a!971 v_0_cb_count)) (= 9 15))))
      (a!1106 (not (and (not (>= a!971 v_0_cb_count)) (<= 1 a!971))))
      (a!1107 (not (and (not (>= a!973 v_0_cb_count)) (= 10 15))))
      (a!1108 (not (and (not (>= a!973 v_0_cb_count)) (<= 1 a!973))))
      (a!1109 (not (and (not (>= a!975 v_0_cb_count)) (= 11 15))))
      (a!1110 (not (and (not (>= a!975 v_0_cb_count)) (<= 1 a!975))))
      (a!1111 (not (and (not (>= a!977 v_0_cb_count)) (= 12 15))))
      (a!1112 (not (and (not (>= a!977 v_0_cb_count)) (<= 1 a!977))))
      (a!1113 (not (and (not (>= a!979 v_0_cb_count)) (= 13 15))))
      (a!1114 (not (and (not (>= a!979 v_0_cb_count)) (<= 1 a!979))))
      (a!1115 (not (and (not (>= a!981 v_0_cb_count)) (= 14 15))))
      (a!1116 (not (and (not (>= a!981 v_0_cb_count)) (<= 1 a!981))))
      (a!1117 (not (and (not (>= a!983 v_0_cb_count)) (= 15 15))))
      (a!1118 (not (and (not (>= a!983 v_0_cb_count)) (<= 1 a!983)))))
(let ((a!9 (not (= (ite (and a!1 a!2) (ite a!3 a!4 a!7) a!8) 2147483648)))
      (a!18 (and (<= 1 v_0_local_window)
                 (<= (ite (and a!10 a!11) (ite a!12 a!13 a!16) a!17)
                     (+ (- 1) v_0_local_window))))
      (a!27 (not (= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26) 2147483648)))
      (a!36 (not (= (ite (and a!28 a!29) (ite a!30 a!31 a!34) a!35) 2147483648)))
      (a!37 (and (>= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)
                     (+ 1 v_0_rtx_buf))
                 (>= 2147483647 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))))
      (a!38 (<= 1 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!39 (<= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26) v_0_rtx_buf))
      (a!49 (not (<= 2147483648 (ite (and a!41 a!42) (ite a!43 a!44 a!47) a!48))))
      (a!58 (not (<= (ite (and a!50 a!51) (ite a!52 a!53 a!56) a!57) 0)))
      (a!59 (not (<= 2147483648 (ite (and a!50 a!51) (ite a!52 a!53 a!56) a!57))))
      (a!61 (* (- 1) (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!76 (ite a!75
                 (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes) (to_int a!74))
                 8))
      (a!99 (>= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)
                (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98)))
      (a!126 (= v_1_ack_delta (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!154 (not (= 0 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))))
      (a!156 (= 1 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!157 (= 2 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!158 (= 3 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!159 (= 4 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!160 (= 5 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!161 (= 6 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!162 (= 7 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!163 (= 8 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!164 (= 9 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!165 (= 10 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!166 (= 11 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!167 (= 12 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!168 (= 13 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!169 (= 14 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!170 (ite (= 15 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))
                  v_0_tx_time_15
                  0))
      (a!680 (ite a!677
                  a!679
                  (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                       4294967296)))
      (a!704 (ite (<= a!703 (- 1000)) (* (- 1) a!703) 1000))
      (a!714 (and (<= v_0_rtt_start_ms now_0)
                  (<= 1 v_0_rtt_remaining)
                  (>= 4 v_0_rtt_remaining)
                  (>= (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98)
                      v_0_rtt_remaining)
                  (<= (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98)
                      (ite (and a!706 a!707) (ite a!708 a!709 a!712) a!713))))
      (a!718 (ite v_0_rtt_previous_measured
                  (+ (* (/ 3.0 4.0) v_0_rtt_previous_var) (* (/ 1.0 4.0) a!717))
                  (* (/ 1.0 2.0) (to_real v_0_rtt_last_ms))))
      (a!736 (or (not v_0_lt_emitted)
                 (and v_0_fr_duplicate
                      (<= 1 v_0_fr_dupacks)
                      (>= 2 v_0_fr_dupacks)
                      (not v_0_fr_active)
                      (not v_0_fin_sent)
                      (<= 1 v_0_lt_take)
                      (>= 4 v_0_lt_take)
                      (= v_0_cc_cwnd v_0_lt_before_cwnd)
                      (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take))
                      (<= v_0_rtx_buf v_0_snd_wnd)
                      (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd))
                      (= v_0_snd_nxt a!735))))
      (a!740 (or (not v_0_choice_used)
                 (and (<= 1 v_0_choice_count)
                      (<= v_0_choice_count v_0_choice_limit)
                      (= v_0_take v_0_choice_count)
                      (= v_0_cc_new_sent v_0_choice_count)
                      (<= v_0_choice_count v_0_cc_send_budget)
                      (= v_0_snd_nxt a!739)
                      (= v_0_rtx_buf
                         (+ v_0_choice_before_flight v_0_choice_count)))))
      (a!753 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_00))
                  (= v_0_cb_end_00
                     (ite (and a!745 a!746) (ite a!747 a!748 a!751) a!752))))
      (a!766 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_01))
                  (= v_0_cb_end_01
                     (ite (and a!758 a!759) (ite a!760 a!761 a!764) a!765))))
      (a!779 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_02))
                  (= v_0_cb_end_02
                     (ite (and a!771 a!772) (ite a!773 a!774 a!777) a!778))))
      (a!792 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_03))
                  (= v_0_cb_end_03
                     (ite (and a!784 a!785) (ite a!786 a!787 a!790) a!791))))
      (a!805 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_04))
                  (= v_0_cb_end_04
                     (ite (and a!797 a!798) (ite a!799 a!800 a!803) a!804))))
      (a!818 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_05))
                  (= v_0_cb_end_05
                     (ite (and a!810 a!811) (ite a!812 a!813 a!816) a!817))))
      (a!831 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_06))
                  (= v_0_cb_end_06
                     (ite (and a!823 a!824) (ite a!825 a!826 a!829) a!830))))
      (a!844 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_07))
                  (= v_0_cb_end_07
                     (ite (and a!836 a!837) (ite a!838 a!839 a!842) a!843))))
      (a!857 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_08))
                  (= v_0_cb_end_08
                     (ite (and a!849 a!850) (ite a!851 a!852 a!855) a!856))))
      (a!870 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09))
                  (= v_0_cb_end_09
                     (ite (and a!862 a!863) (ite a!864 a!865 a!868) a!869))))
      (a!883 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_10))
                  (= v_0_cb_end_10
                     (ite (and a!875 a!876) (ite a!877 a!878 a!881) a!882))))
      (a!896 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_11))
                  (= v_0_cb_end_11
                     (ite (and a!888 a!889) (ite a!890 a!891 a!894) a!895))))
      (a!909 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_12))
                  (= v_0_cb_end_12
                     (ite (and a!901 a!902) (ite a!903 a!904 a!907) a!908))))
      (a!922 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_13))
                  (= v_0_cb_end_13
                     (ite (and a!914 a!915) (ite a!916 a!917 a!920) a!921))))
      (a!935 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_14))
                  (= v_0_cb_end_14
                     (ite (and a!927 a!928) (ite a!929 a!930 a!933) a!934))))
      (a!948 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_15))
                  (= v_0_cb_end_15
                     (ite (and a!940 a!941) (ite a!942 a!943 a!946) a!947)))))
(let ((a!40 (and (or (and (= 0 v_0_local_window)
                          (= input_0_net.ack_seq v_0_rcv_nxt))
                     a!18)
                 a!38
                 a!39))
      (a!60 (and (or (and (= 0 v_0_local_window)
                          (= input_0_net.ack_seq v_0_rcv_nxt))
                     a!18)
                 a!39
                 (or (and (= v_0_snd_wl1 input_0_net.ack_seq) a!49)
                     (and a!58 a!59))))
      (a!62 (ite (<= v_0_rtx_buf
                     (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))
                 0
                 (+ v_0_rtx_buf a!61)))
      (a!100 (and v_0_rtt_active
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  a!99
                  (not v_0_rtt_ambiguous)))
      (a!125 (= v_1_seg_acceptable
                (or (and (= 0 v_0_local_window)
                         (= input_0_net.ack_seq v_0_rcv_nxt))
                    a!18)))
      (a!127 (and v_0_rtt_active
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  a!99))
      (a!137 (+ (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98) a!61))
      (a!155 (and (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  a!154))
      (a!171 (ite a!166
                  v_0_tx_time_11
                  (ite a!167
                       v_0_tx_time_12
                       (ite a!168
                            v_0_tx_time_13
                            (ite a!169 v_0_tx_time_14 a!170)))))
      (a!178 (ite a!166
                  v_0_tx_time_12
                  (ite a!167
                       v_0_tx_time_13
                       (ite a!168 v_0_tx_time_14 (ite a!169 v_0_tx_time_15 0)))))
      (a!185 (ite a!165
                  v_0_tx_time_12
                  (ite a!166
                       v_0_tx_time_13
                       (ite a!167 v_0_tx_time_14 (ite a!168 v_0_tx_time_15 0)))))
      (a!192 (ite a!164
                  v_0_tx_time_12
                  (ite a!165
                       v_0_tx_time_13
                       (ite a!166 v_0_tx_time_14 (ite a!167 v_0_tx_time_15 0)))))
      (a!199 (ite a!163
                  v_0_tx_time_12
                  (ite a!164
                       v_0_tx_time_13
                       (ite a!165 v_0_tx_time_14 (ite a!166 v_0_tx_time_15 0)))))
      (a!206 (ite a!162
                  v_0_tx_time_12
                  (ite a!163
                       v_0_tx_time_13
                       (ite a!164 v_0_tx_time_14 (ite a!165 v_0_tx_time_15 0)))))
      (a!212 (ite a!161
                  v_0_tx_time_12
                  (ite a!162
                       v_0_tx_time_13
                       (ite a!163 v_0_tx_time_14 (ite a!164 v_0_tx_time_15 0)))))
      (a!218 (ite a!160
                  v_0_tx_time_12
                  (ite a!161
                       v_0_tx_time_13
                       (ite a!162 v_0_tx_time_14 (ite a!163 v_0_tx_time_15 0)))))
      (a!224 (ite a!159
                  v_0_tx_time_12
                  (ite a!160
                       v_0_tx_time_13
                       (ite a!161 v_0_tx_time_14 (ite a!162 v_0_tx_time_15 0)))))
      (a!230 (ite a!158
                  v_0_tx_time_12
                  (ite a!159
                       v_0_tx_time_13
                       (ite a!160 v_0_tx_time_14 (ite a!161 v_0_tx_time_15 0)))))
      (a!235 (ite a!157
                  v_0_tx_time_12
                  (ite a!158
                       v_0_tx_time_13
                       (ite a!159 v_0_tx_time_14 (ite a!160 v_0_tx_time_15 0)))))
      (a!240 (ite a!156
                  v_0_tx_time_12
                  (ite a!157
                       v_0_tx_time_13
                       (ite a!158 v_0_tx_time_14 (ite a!159 v_0_tx_time_15 0)))))
      (a!705 (= v_0_rto_base_ms
                (ite v_0_rtt_measured (ite (<= 60000 a!704) 60000 a!704) 1000)))
      (a!720 (or (not v_0_rtt_sample_used)
                 (and (= v_0_rttvar_ms a!718) (= v_0_srtt_ms a!719)))))
(let ((a!63 (ite (<= a!62 (ite (<= 0 v_0_rtx_buf) v_0_rtx_buf 0))
                 a!62
                 (ite (<= 0 v_0_rtx_buf) v_0_rtx_buf 0)))
      (a!70 (and (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)
                 (not v_0_fr_active)
                 (= (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks) 3)
                 (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una)))
      (a!71 (and v_0_fr_active
                 (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))))
      (a!101 (ite a!100 (+ now_1 (* (- 1) v_0_rtt_start_ms)) v_0_rtt_last_ms))
      (a!129 (>= (+ v_0_rtt_end
                    (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                 (- 4294967296)))
      (a!130 (< (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                8589934592))
      (a!131 (< (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                0))
      (a!132 (+ (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                4294967296))
      (a!133 (>= (+ v_0_rtt_end
                    (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                 4294967296))
      (a!134 (- (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                4294967296))
      (a!136 (mod (+ v_0_rtt_end
                     (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                  4294967296))
      (a!138 (and v_0_rtt_active
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  (not (<= v_0_rtt_remaining a!137))))
      (a!172 (ite a!162
                  v_0_tx_time_07
                  (ite a!163
                       v_0_tx_time_08
                       (ite a!164
                            v_0_tx_time_09
                            (ite a!165 v_0_tx_time_10 a!171)))))
      (a!179 (ite a!162
                  v_0_tx_time_08
                  (ite a!163
                       v_0_tx_time_09
                       (ite a!164
                            v_0_tx_time_10
                            (ite a!165 v_0_tx_time_11 a!178)))))
      (a!186 (ite a!161
                  v_0_tx_time_08
                  (ite a!162
                       v_0_tx_time_09
                       (ite a!163
                            v_0_tx_time_10
                            (ite a!164 v_0_tx_time_11 a!185)))))
      (a!193 (ite a!160
                  v_0_tx_time_08
                  (ite a!161
                       v_0_tx_time_09
                       (ite a!162
                            v_0_tx_time_10
                            (ite a!163 v_0_tx_time_11 a!192)))))
      (a!200 (ite a!159
                  v_0_tx_time_08
                  (ite a!160
                       v_0_tx_time_09
                       (ite a!161
                            v_0_tx_time_10
                            (ite a!162 v_0_tx_time_11 a!199)))))
      (a!207 (ite a!158
                  v_0_tx_time_08
                  (ite a!159
                       v_0_tx_time_09
                       (ite a!160
                            v_0_tx_time_10
                            (ite a!161 v_0_tx_time_11 a!206)))))
      (a!213 (ite a!157
                  v_0_tx_time_08
                  (ite a!158
                       v_0_tx_time_09
                       (ite a!159
                            v_0_tx_time_10
                            (ite a!160 v_0_tx_time_11 a!212)))))
      (a!219 (ite a!156
                  v_0_tx_time_08
                  (ite a!157
                       v_0_tx_time_09
                       (ite a!158
                            v_0_tx_time_10
                            (ite a!159 v_0_tx_time_11 a!218)))))
      (a!225 (ite a!155
                  (ite a!156
                       v_0_tx_time_09
                       (ite a!157
                            v_0_tx_time_10
                            (ite a!158 v_0_tx_time_11 a!224)))
                  v_0_tx_time_08))
      (a!245 (ite a!155
                  (ite a!156
                       v_0_tx_time_13
                       (ite a!157 v_0_tx_time_14 (ite a!158 v_0_tx_time_15 0)))
                  v_0_tx_time_12))
      (a!379 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_00))
                 (- 4294967296)))
      (a!380 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                8589934592))
      (a!381 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                0))
      (a!382 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                4294967296))
      (a!383 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_00))
                 4294967296))
      (a!384 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                4294967296))
      (a!386 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_00))
                  4294967296))
      (a!390 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_01))
                 (- 4294967296)))
      (a!391 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                8589934592))
      (a!392 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                0))
      (a!393 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                4294967296))
      (a!394 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_01))
                 4294967296))
      (a!395 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                4294967296))
      (a!397 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_01))
                  4294967296))
      (a!401 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_02))
                 (- 4294967296)))
      (a!402 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                8589934592))
      (a!403 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                0))
      (a!404 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                4294967296))
      (a!405 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_02))
                 4294967296))
      (a!406 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                4294967296))
      (a!408 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_02))
                  4294967296))
      (a!412 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_03))
                 (- 4294967296)))
      (a!413 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                8589934592))
      (a!414 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                0))
      (a!415 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                4294967296))
      (a!416 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_03))
                 4294967296))
      (a!417 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                4294967296))
      (a!419 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_03))
                  4294967296))
      (a!423 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_04))
                 (- 4294967296)))
      (a!424 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                8589934592))
      (a!425 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                0))
      (a!426 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                4294967296))
      (a!427 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_04))
                 4294967296))
      (a!428 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                4294967296))
      (a!430 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_04))
                  4294967296))
      (a!434 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_05))
                 (- 4294967296)))
      (a!435 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                8589934592))
      (a!436 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                0))
      (a!437 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                4294967296))
      (a!438 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_05))
                 4294967296))
      (a!439 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                4294967296))
      (a!441 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_05))
                  4294967296))
      (a!445 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_06))
                 (- 4294967296)))
      (a!446 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                8589934592))
      (a!447 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                0))
      (a!448 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                4294967296))
      (a!449 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_06))
                 4294967296))
      (a!450 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                4294967296))
      (a!452 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_06))
                  4294967296))
      (a!456 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_07))
                 (- 4294967296)))
      (a!457 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                8589934592))
      (a!458 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                0))
      (a!459 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                4294967296))
      (a!460 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_07))
                 4294967296))
      (a!461 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                4294967296))
      (a!463 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_07))
                  4294967296))
      (a!467 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_08))
                 (- 4294967296)))
      (a!468 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                8589934592))
      (a!469 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                0))
      (a!470 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                4294967296))
      (a!471 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_08))
                 4294967296))
      (a!472 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                4294967296))
      (a!474 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_08))
                  4294967296))
      (a!478 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_09))
                 (- 4294967296)))
      (a!479 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                8589934592))
      (a!480 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                0))
      (a!481 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                4294967296))
      (a!482 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_09))
                 4294967296))
      (a!483 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                4294967296))
      (a!485 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_09))
                  4294967296))
      (a!489 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_10))
                 (- 4294967296)))
      (a!490 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                8589934592))
      (a!491 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                0))
      (a!492 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                4294967296))
      (a!493 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_10))
                 4294967296))
      (a!494 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                4294967296))
      (a!496 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_10))
                  4294967296))
      (a!500 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_11))
                 (- 4294967296)))
      (a!501 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                8589934592))
      (a!502 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                0))
      (a!503 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                4294967296))
      (a!504 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_11))
                 4294967296))
      (a!505 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                4294967296))
      (a!507 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_11))
                  4294967296))
      (a!511 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_12))
                 (- 4294967296)))
      (a!512 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                8589934592))
      (a!513 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                0))
      (a!514 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                4294967296))
      (a!515 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_12))
                 4294967296))
      (a!516 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                4294967296))
      (a!518 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_12))
                  4294967296))
      (a!522 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_13))
                 (- 4294967296)))
      (a!523 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                8589934592))
      (a!524 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                0))
      (a!525 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                4294967296))
      (a!526 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_13))
                 4294967296))
      (a!527 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                4294967296))
      (a!529 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_13))
                  4294967296))
      (a!533 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_14))
                 (- 4294967296)))
      (a!534 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                8589934592))
      (a!535 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                0))
      (a!536 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                4294967296))
      (a!537 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_14))
                 4294967296))
      (a!538 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                4294967296))
      (a!540 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_14))
                  4294967296))
      (a!544 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_15))
                 (- 4294967296)))
      (a!545 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                8589934592))
      (a!546 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                0))
      (a!547 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                4294967296))
      (a!548 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_15))
                 4294967296))
      (a!549 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                4294967296))
      (a!551 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_15))
                  4294967296)))
(let ((a!64 (and (= 0 (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                 (not v_0_fin_sent)
                 (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) v_0_snd_buf))
                 (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                 (or v_0_persist_active (= 0 (ite a!40 a!63 v_0_rtx_buf)))))
      (a!73 (+ (ite a!60 input_0_net.ack_window v_0_snd_wnd)
               (* (- 1) (ite a!40 a!63 v_0_rtx_buf))))
      (a!78 (ite (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una)
                 0
                 (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf)))))
      (a!83 (ite (<= (ite a!40 a!63 v_0_rtx_buf)
                     (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                 (ite a!40 a!63 v_0_rtx_buf)
                 (ite a!60 input_0_net.ack_window v_0_snd_wnd)))
      (a!85 (ite (<= (ite a!40 a!63 v_0_rtx_buf) 0)
                 0
                 (ite a!40 a!63 v_0_rtx_buf)))
      (a!102 (ite v_0_rtt_measured
                  (+ (* (/ 7.0 8.0) v_0_srtt_ms)
                     (* (/ 1.0 8.0) (to_real a!101)))
                  (to_real a!101)))
      (a!103 (>= (+ v_0_srtt_ms (* (- 1.0) (to_real a!101))) 0.0))
      (a!135 (ite a!133
                  a!134
                  (+ v_0_rtt_end
                     (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))))
      (a!173 (ite a!158
                  v_0_tx_time_03
                  (ite a!159
                       v_0_tx_time_04
                       (ite a!160
                            v_0_tx_time_05
                            (ite a!161 v_0_tx_time_06 a!172)))))
      (a!180 (ite a!158
                  v_0_tx_time_04
                  (ite a!159
                       v_0_tx_time_05
                       (ite a!160
                            v_0_tx_time_06
                            (ite a!161 v_0_tx_time_07 a!179)))))
      (a!187 (ite a!157
                  v_0_tx_time_04
                  (ite a!158
                       v_0_tx_time_05
                       (ite a!159
                            v_0_tx_time_06
                            (ite a!160 v_0_tx_time_07 a!186)))))
      (a!194 (ite a!156
                  v_0_tx_time_04
                  (ite a!157
                       v_0_tx_time_05
                       (ite a!158
                            v_0_tx_time_06
                            (ite a!159 v_0_tx_time_07 a!193)))))
      (a!201 (ite a!155
                  (ite a!156
                       v_0_tx_time_05
                       (ite a!157
                            v_0_tx_time_06
                            (ite a!158 v_0_tx_time_07 a!200)))
                  v_0_tx_time_04))
      (a!208 (ite (>= 5 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!155
                       (ite a!156
                            v_0_tx_time_06
                            (ite a!157 v_0_tx_time_07 a!207))
                       v_0_tx_time_05)))
      (a!231 (ite (>= 9 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!155
                       (ite a!156
                            v_0_tx_time_10
                            (ite a!157 v_0_tx_time_11 a!230))
                       v_0_tx_time_09)))
      (a!250 (ite (>= 13 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!155
                       (ite a!156 v_0_tx_time_14 (ite a!157 v_0_tx_time_15 0))
                       v_0_tx_time_13)))
      (a!258 (ite (or (>= 15 (ite a!40 a!63 v_0_rtx_buf)) a!155)
                  0
                  v_0_tx_time_15))
      (a!260 (and (= 0 (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                  (not v_0_fin_sent)
                  (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) v_0_snd_buf))
                  (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (or v_0_persist_active (= 0 (ite a!40 a!63 v_0_rtx_buf)))
                  (not v_0_persist_active)))
      (a!267 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 0))
      (a!268 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 1))
      (a!270 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 2))
      (a!272 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 3))
      (a!274 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 4))
      (a!276 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 5))
      (a!278 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 6))
      (a!280 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 7))
      (a!282 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 8))
      (a!284 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 9))
      (a!286 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 10))
      (a!288 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 11))
      (a!290 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 12))
      (a!292 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 13))
      (a!294 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 14))
      (a!296 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 15))
      (a!385 (ite a!383
                  a!384
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_00))))
      (a!396 (ite a!394
                  a!395
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_01))))
      (a!407 (ite a!405
                  a!406
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_02))))
      (a!418 (ite a!416
                  a!417
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_03))))
      (a!429 (ite a!427
                  a!428
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_04))))
      (a!440 (ite a!438
                  a!439
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_05))))
      (a!451 (ite a!449
                  a!450
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_06))))
      (a!462 (ite a!460
                  a!461
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_07))))
      (a!473 (ite a!471
                  a!472
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_08))))
      (a!484 (ite a!482
                  a!483
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_09))))
      (a!495 (ite a!493
                  a!494
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_10))))
      (a!506 (ite a!504
                  a!505
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_11))))
      (a!517 (ite a!515
                  a!516
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_12))))
      (a!528 (ite a!526
                  a!527
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_13))))
      (a!539 (ite a!537
                  a!538
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_14))))
      (a!550 (ite a!548
                  a!549
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_15))))
      (a!669 (and (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  (= 0 (ite a!40 a!63 v_0_rtx_buf))))
      (a!670 (and (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf)))))
(let ((a!65 (or a!64
                (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                (= 0 (ite a!40 a!63 v_0_rtx_buf))))
      (a!69 (not (or a!64 (= 0 (ite a!40 a!63 v_0_rtx_buf)))))
      (a!79 (or v_0_fr_active
                (not (and (<= 1 a!78)
                          (not v_0_persist_active)
                          (<= 1 v_0_snd_wnd)))))
      (a!80 (ite (>= v_0_cc_cwnd v_0_cc_ssthresh)
                 (ite (>= (+ v_0_cc_ca_credit a!78) v_0_cc_cwnd) 4 0)
                 (ite (>= 4 a!78) a!78 4)))
      (a!84 (<= 1 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!86 (<= 0 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!104 (ite a!103
                  (+ v_0_srtt_ms (* (- 1.0) (to_real a!101)))
                  (+ (* (- 1.0) v_0_srtt_ms) (to_real a!101))))
      (a!139 (+ (ite (and a!129 a!130) (ite a!131 a!132 a!135) a!136)
                (* (- 1)
                   (ite (or a!64 a!127) 0 (ite a!138 a!137 v_0_rtt_remaining)))))
      (a!174 (ite (>= 0 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!155
                       (ite a!156
                            v_0_tx_time_01
                            (ite a!157 v_0_tx_time_02 a!173))
                       v_0_tx_time_00)))
      (a!175 (<= 2 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!181 (ite (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!155
                       (ite a!156
                            v_0_tx_time_02
                            (ite a!157 v_0_tx_time_03 a!180))
                       v_0_tx_time_01)))
      (a!182 (<= 3 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!189 (<= 4 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!196 (<= 5 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!203 (<= 6 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!209 (<= 7 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!216 (<= 8 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!221 (<= 9 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!227 (<= 10 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!232 (<= 11 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!237 (<= 12 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!242 (<= 13 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!247 (<= 14 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!251 (<= 15 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!255 (<= 16 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!264 (and (>= v_0_cc_cwnd v_0_cc_ssthresh)
                  (not (>= (+ v_0_cc_ca_credit a!78) v_0_cc_cwnd))))
      (a!269 (and a!268
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!271 (and a!270
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!273 (and a!272
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!275 (and a!274
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!277 (and a!276
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!279 (and a!278
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!281 (and a!280
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!283 (and a!282
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!285 (and a!284
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!287 (and a!286
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!289 (and a!288
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!291 (and a!290
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!293 (and a!292
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!295 (and a!294
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!297 (and a!296
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!303 (and a!294
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!309 (and a!292
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!315 (and a!290
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!320 (and a!288
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!325 (and a!286
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!330 (and a!284
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!335 (and a!282
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!339 (and a!280
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!343 (and a!278
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!347 (and a!276
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!351 (and a!274
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!354 (and a!272
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!357 (and a!270
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!360 (and a!268
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!363 (and (not (>= 15 (ite a!40 a!63 v_0_rtx_buf)))
                  (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_15))
      (a!365 (= v_1_fr_emit_count (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!372 (or a!64
                 a!71
                 a!70
                 (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                 (= 0 (ite a!40 a!63 v_0_rtx_buf))))
      (a!387 (not (<= 2147483648
                      (ite (and a!379 a!380) (ite a!381 a!382 a!385) a!386))))
      (a!398 (not (<= 2147483648
                      (ite (and a!390 a!391) (ite a!392 a!393 a!396) a!397))))
      (a!409 (not (<= 2147483648
                      (ite (and a!401 a!402) (ite a!403 a!404 a!407) a!408))))
      (a!420 (not (<= 2147483648
                      (ite (and a!412 a!413) (ite a!414 a!415 a!418) a!419))))
      (a!431 (not (<= 2147483648
                      (ite (and a!423 a!424) (ite a!425 a!426 a!429) a!430))))
      (a!442 (not (<= 2147483648
                      (ite (and a!434 a!435) (ite a!436 a!437 a!440) a!441))))
      (a!453 (not (<= 2147483648
                      (ite (and a!445 a!446) (ite a!447 a!448 a!451) a!452))))
      (a!464 (not (<= 2147483648
                      (ite (and a!456 a!457) (ite a!458 a!459 a!462) a!463))))
      (a!475 (not (<= 2147483648
                      (ite (and a!467 a!468) (ite a!469 a!470 a!473) a!474))))
      (a!486 (not (<= 2147483648
                      (ite (and a!478 a!479) (ite a!480 a!481 a!484) a!485))))
      (a!497 (not (<= 2147483648
                      (ite (and a!489 a!490) (ite a!491 a!492 a!495) a!496))))
      (a!508 (not (<= 2147483648
                      (ite (and a!500 a!501) (ite a!502 a!503 a!506) a!507))))
      (a!519 (not (<= 2147483648
                      (ite (and a!511 a!512) (ite a!513 a!514 a!517) a!518))))
      (a!530 (not (<= 2147483648
                      (ite (and a!522 a!523) (ite a!524 a!525 a!528) a!529))))
      (a!541 (not (<= 2147483648
                      (ite (and a!533 a!534) (ite a!535 a!536 a!539) a!540))))
      (a!552 (not (<= 2147483648
                      (ite (and a!544 a!545) (ite a!546 a!547 a!550) a!551))))
      (a!671 (and (not a!64) (or (and (not a!669) active_0_rtx) a!670)))
      (a!673 (and (= 0 (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                  (not v_0_fin_sent)
                  (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) v_0_snd_buf))
                  (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (or v_0_persist_active (= 0 (ite a!40 a!63 v_0_rtx_buf)))
                  (or active_0_persist a!260))))
(let ((a!67 (<= 1 (ite a!65 0 (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks))))
      (a!68 (>= 2 (ite a!65 0 (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks))))
      (a!72 (and a!69 (or a!70 (and (not a!71) v_0_fr_active))))
      (a!81 (ite a!77
                 (+ 4 v_0_cc_cwnd (ite a!79 0 a!80))
                 (ite a!71
                      (ite a!70 a!76 v_0_cc_ssthresh)
                      (+ v_0_cc_cwnd (ite a!79 0 a!80)))))
      (a!87 (and a!86
                 (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)
                 (not v_0_fr_active)
                 (= (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks) 3)
                 (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una)))
      (a!105 (ite v_0_rtt_measured
                  (+ (* (/ 3.0 4.0) v_0_rttvar_ms)
                     (* (/ 1.0 4.0) (ite a!100 a!104 v_0_rtt_error_ms)))
                  (* (/ 1.0 2.0) (to_real a!101))))
      (a!265 (ite (or v_0_fr_active a!71 a!70)
                  0
                  (ite (and (<= 1 a!78)
                            (not v_0_persist_active)
                            (<= 1 v_0_snd_wnd))
                       (ite a!264 (+ v_0_cc_ca_credit a!78) 0)
                       v_0_cc_ca_credit)))
      (a!298 (ite a!289
                  v_0_cc_rto_11
                  (ite a!291
                       v_0_cc_rto_12
                       (ite a!293 v_0_cc_rto_13 (ite a!295 v_0_cc_rto_14 a!297)))))
      (a!304 (ite a!287
                  v_0_cc_rto_11
                  (ite a!289
                       v_0_cc_rto_12
                       (ite a!291 v_0_cc_rto_13 (ite a!293 v_0_cc_rto_14 a!303)))))
      (a!310 (ite a!285
                  v_0_cc_rto_11
                  (ite a!287
                       v_0_cc_rto_12
                       (ite a!289 v_0_cc_rto_13 (ite a!291 v_0_cc_rto_14 a!309)))))
      (a!316 (ite a!283
                  v_0_cc_rto_11
                  (ite a!285
                       v_0_cc_rto_12
                       (ite a!287 v_0_cc_rto_13 (ite a!289 v_0_cc_rto_14 a!315)))))
      (a!321 (ite a!281
                  v_0_cc_rto_11
                  (ite a!283
                       v_0_cc_rto_12
                       (ite a!285 v_0_cc_rto_13 (ite a!287 v_0_cc_rto_14 a!320)))))
      (a!326 (ite a!279
                  v_0_cc_rto_11
                  (ite a!281
                       v_0_cc_rto_12
                       (ite a!283 v_0_cc_rto_13 (ite a!285 v_0_cc_rto_14 a!325)))))
      (a!331 (ite a!277
                  v_0_cc_rto_11
                  (ite a!279
                       v_0_cc_rto_12
                       (ite a!281 v_0_cc_rto_13 (ite a!283 v_0_cc_rto_14 a!330)))))
      (a!336 (ite a!275
                  v_0_cc_rto_11
                  (ite a!277
                       v_0_cc_rto_12
                       (ite a!279 v_0_cc_rto_13 (ite a!281 v_0_cc_rto_14 a!335)))))
      (a!340 (ite a!273
                  v_0_cc_rto_11
                  (ite a!275
                       v_0_cc_rto_12
                       (ite a!277 v_0_cc_rto_13 (ite a!279 v_0_cc_rto_14 a!339)))))
      (a!344 (ite a!271
                  v_0_cc_rto_11
                  (ite a!273
                       v_0_cc_rto_12
                       (ite a!275 v_0_cc_rto_13 (ite a!277 v_0_cc_rto_14 a!343)))))
      (a!348 (ite a!269
                  v_0_cc_rto_11
                  (ite a!271
                       v_0_cc_rto_12
                       (ite a!273 v_0_cc_rto_13 (ite a!275 v_0_cc_rto_14 a!347)))))
      (a!352 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_11
                  (ite a!269
                       v_0_cc_rto_12
                       (ite a!271 v_0_cc_rto_13 (ite a!273 v_0_cc_rto_14 a!351)))))
      (a!355 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_12
                  (ite a!269 v_0_cc_rto_13 (ite a!271 v_0_cc_rto_14 a!354))))
      (a!358 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_13
                  (ite a!269 v_0_cc_rto_14 a!357)))
      (a!361 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_14
                  a!360))
      (a!364 (= v_1_fr_dupacks
                (ite a!65 0 (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks))))
      (a!388 (ite (and (not (>= a!378 v_0_cb_count)) (<= 1 a!78) a!387) 1 0))
      (a!399 (ite (and (not (>= a!389 v_0_cb_count)) (<= 1 a!78) a!398) 1 0))
      (a!410 (ite (and (not (>= a!400 v_0_cb_count)) (<= 1 a!78) a!409) 1 0))
      (a!421 (ite (and (not (>= a!411 v_0_cb_count)) (<= 1 a!78) a!420) 1 0))
      (a!432 (ite (and (not (>= a!422 v_0_cb_count)) (<= 1 a!78) a!431) 1 0))
      (a!443 (ite (and (not (>= a!433 v_0_cb_count)) (<= 1 a!78) a!442) 1 0))
      (a!454 (ite (and (not (>= a!444 v_0_cb_count)) (<= 1 a!78) a!453) 1 0))
      (a!465 (ite (and (not (>= a!455 v_0_cb_count)) (<= 1 a!78) a!464) 1 0))
      (a!476 (ite (and (not (>= a!466 v_0_cb_count)) (<= 1 a!78) a!475) 1 0))
      (a!487 (ite (and (not (>= a!477 v_0_cb_count)) (<= 1 a!78) a!486) 1 0))
      (a!498 (ite (and (not (>= a!488 v_0_cb_count)) (<= 1 a!78) a!497) 1 0))
      (a!509 (ite (and (not (>= a!499 v_0_cb_count)) (<= 1 a!78) a!508) 1 0))
      (a!520 (ite (and (not (>= a!510 v_0_cb_count)) (<= 1 a!78) a!519) 1 0))
      (a!531 (ite (and (not (>= a!521 v_0_cb_count)) (<= 1 a!78) a!530) 1 0))
      (a!542 (ite (and (not (>= a!532 v_0_cb_count)) (<= 1 a!78) a!541) 1 0))
      (a!553 (ite (and (not (>= a!543 v_0_cb_count)) (<= 1 a!78) a!552) 1 0))
      (a!563 (ite (and (not (>= a!378 v_0_cb_count)) (<= 1 a!78) a!387)
                  v_0_cb_length_00
                  0))
      (a!564 (ite (and (not (>= a!389 v_0_cb_count)) (<= 1 a!78) a!398)
                  v_0_cb_length_01
                  0))
      (a!565 (ite (and (not (>= a!400 v_0_cb_count)) (<= 1 a!78) a!409)
                  v_0_cb_length_02
                  0))
      (a!566 (ite (and (not (>= a!411 v_0_cb_count)) (<= 1 a!78) a!420)
                  v_0_cb_length_03
                  0))
      (a!567 (ite (and (not (>= a!422 v_0_cb_count)) (<= 1 a!78) a!431)
                  v_0_cb_length_04
                  0))
      (a!568 (ite (and (not (>= a!433 v_0_cb_count)) (<= 1 a!78) a!442)
                  v_0_cb_length_05
                  0))
      (a!569 (ite (and (not (>= a!444 v_0_cb_count)) (<= 1 a!78) a!453)
                  v_0_cb_length_06
                  0))
      (a!570 (ite (and (not (>= a!455 v_0_cb_count)) (<= 1 a!78) a!464)
                  v_0_cb_length_07
                  0))
      (a!571 (ite (and (not (>= a!466 v_0_cb_count)) (<= 1 a!78) a!475)
                  v_0_cb_length_08
                  0))
      (a!572 (ite (and (not (>= a!477 v_0_cb_count)) (<= 1 a!78) a!486)
                  v_0_cb_length_09
                  0))
      (a!573 (ite (and (not (>= a!488 v_0_cb_count)) (<= 1 a!78) a!497)
                  v_0_cb_length_10
                  0))
      (a!574 (ite (and (not (>= a!499 v_0_cb_count)) (<= 1 a!78) a!508)
                  v_0_cb_length_11
                  0))
      (a!575 (ite (and (not (>= a!510 v_0_cb_count)) (<= 1 a!78) a!519)
                  v_0_cb_length_12
                  0))
      (a!576 (ite (and (not (>= a!521 v_0_cb_count)) (<= 1 a!78) a!530)
                  v_0_cb_length_13
                  0))
      (a!577 (ite (and (not (>= a!532 v_0_cb_count)) (<= 1 a!78) a!541)
                  v_0_cb_length_14
                  0))
      (a!578 (ite (and (not (>= a!543 v_0_cb_count)) (<= 1 a!78) a!552)
                  v_0_cb_length_15
                  0))
      (a!616 (ite (and (not (>= a!378 v_0_cb_count)) (<= 1 a!78) a!387)
                  0
                  v_0_cb_length_00))
      (a!617 (ite (and (not (>= a!389 v_0_cb_count)) (<= 1 a!78) a!398)
                  0
                  v_0_cb_length_01))
      (a!618 (ite (and (not (>= a!400 v_0_cb_count)) (<= 1 a!78) a!409)
                  0
                  v_0_cb_length_02))
      (a!619 (ite (and (not (>= a!411 v_0_cb_count)) (<= 1 a!78) a!420)
                  0
                  v_0_cb_length_03))
      (a!620 (ite (and (not (>= a!422 v_0_cb_count)) (<= 1 a!78) a!431)
                  0
                  v_0_cb_length_04))
      (a!621 (ite (and (not (>= a!433 v_0_cb_count)) (<= 1 a!78) a!442)
                  0
                  v_0_cb_length_05))
      (a!622 (ite (and (not (>= a!444 v_0_cb_count)) (<= 1 a!78) a!453)
                  0
                  v_0_cb_length_06))
      (a!623 (ite (and (not (>= a!455 v_0_cb_count)) (<= 1 a!78) a!464)
                  0
                  v_0_cb_length_07))
      (a!624 (ite (and (not (>= a!466 v_0_cb_count)) (<= 1 a!78) a!475)
                  0
                  v_0_cb_length_08))
      (a!625 (ite (and (not (>= a!477 v_0_cb_count)) (<= 1 a!78) a!486)
                  0
                  v_0_cb_length_09))
      (a!626 (ite (and (not (>= a!488 v_0_cb_count)) (<= 1 a!78) a!497)
                  0
                  v_0_cb_length_10))
      (a!627 (ite (and (not (>= a!499 v_0_cb_count)) (<= 1 a!78) a!508)
                  0
                  v_0_cb_length_11))
      (a!628 (ite (and (not (>= a!510 v_0_cb_count)) (<= 1 a!78) a!519)
                  0
                  v_0_cb_length_12))
      (a!629 (ite (and (not (>= a!521 v_0_cb_count)) (<= 1 a!78) a!530)
                  0
                  v_0_cb_length_13))
      (a!630 (ite (and (not (>= a!532 v_0_cb_count)) (<= 1 a!78) a!541)
                  0
                  v_0_cb_length_14))
      (a!631 (ite (and (not (>= a!543 v_0_cb_count)) (<= 1 a!78) a!552)
                  0
                  v_0_cb_length_15))
      (a!638 (= v_1_cb_done_00
                (and (not (>= a!378 v_0_cb_count)) (<= 1 a!78) a!387)))
      (a!640 (= v_1_cb_done_01
                (and (not (>= a!389 v_0_cb_count)) (<= 1 a!78) a!398)))
      (a!642 (= v_1_cb_done_02
                (and (not (>= a!400 v_0_cb_count)) (<= 1 a!78) a!409)))
      (a!644 (= v_1_cb_done_03
                (and (not (>= a!411 v_0_cb_count)) (<= 1 a!78) a!420)))
      (a!646 (= v_1_cb_done_04
                (and (not (>= a!422 v_0_cb_count)) (<= 1 a!78) a!431)))
      (a!648 (= v_1_cb_done_05
                (and (not (>= a!433 v_0_cb_count)) (<= 1 a!78) a!442)))
      (a!650 (= v_1_cb_done_06
                (and (not (>= a!444 v_0_cb_count)) (<= 1 a!78) a!453)))
      (a!652 (= v_1_cb_done_07
                (and (not (>= a!455 v_0_cb_count)) (<= 1 a!78) a!464)))
      (a!654 (= v_1_cb_done_08
                (and (not (>= a!466 v_0_cb_count)) (<= 1 a!78) a!475)))
      (a!656 (= v_1_cb_done_09
                (and (not (>= a!477 v_0_cb_count)) (<= 1 a!78) a!486)))
      (a!658 (= v_1_cb_done_10
                (and (not (>= a!488 v_0_cb_count)) (<= 1 a!78) a!497)))
      (a!660 (= v_1_cb_done_11
                (and (not (>= a!499 v_0_cb_count)) (<= 1 a!78) a!508)))
      (a!662 (= v_1_cb_done_12
                (and (not (>= a!510 v_0_cb_count)) (<= 1 a!78) a!519)))
      (a!664 (= v_1_cb_done_13
                (and (not (>= a!521 v_0_cb_count)) (<= 1 a!78) a!530)))
      (a!666 (= v_1_cb_done_14
                (and (not (>= a!532 v_0_cb_count)) (<= 1 a!78) a!541)))
      (a!668 (= v_1_cb_done_15
                (and (not (>= a!543 v_0_cb_count)) (<= 1 a!78) a!552)))
      (a!672 (and v_0_persist_active
                  (not a!64)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (not a!671)))
      (a!954 (ite (and (not (>= a!953 v_0_cb_count)) (<= 1 a!78) a!387) 1 0))
      (a!956 (ite (and (not (>= a!955 v_0_cb_count)) (<= 1 a!78) a!398) 1 0))
      (a!958 (ite (and (not (>= a!957 v_0_cb_count)) (<= 1 a!78) a!409) 1 0))
      (a!960 (ite (and (not (>= a!959 v_0_cb_count)) (<= 1 a!78) a!420) 1 0))
      (a!962 (ite (and (not (>= a!961 v_0_cb_count)) (<= 1 a!78) a!431) 1 0))
      (a!964 (ite (and (not (>= a!963 v_0_cb_count)) (<= 1 a!78) a!442) 1 0))
      (a!966 (ite (and (not (>= a!965 v_0_cb_count)) (<= 1 a!78) a!453) 1 0))
      (a!968 (ite (and (not (>= a!967 v_0_cb_count)) (<= 1 a!78) a!464) 1 0))
      (a!970 (ite (and (not (>= a!969 v_0_cb_count)) (<= 1 a!78) a!475) 1 0))
      (a!972 (ite (and (not (>= a!971 v_0_cb_count)) (<= 1 a!78) a!486) 1 0))
      (a!974 (ite (and (not (>= a!973 v_0_cb_count)) (<= 1 a!78) a!497) 1 0))
      (a!976 (ite (and (not (>= a!975 v_0_cb_count)) (<= 1 a!78) a!508) 1 0))
      (a!978 (ite (and (not (>= a!977 v_0_cb_count)) (<= 1 a!78) a!519) 1 0))
      (a!980 (ite (and (not (>= a!979 v_0_cb_count)) (<= 1 a!78) a!530) 1 0))
      (a!982 (ite (and (not (>= a!981 v_0_cb_count)) (<= 1 a!78) a!541) 1 0))
      (a!984 (ite (and (not (>= a!983 v_0_cb_count)) (<= 1 a!78) a!552) 1 0))
      (a!988 (ite (and (not (>= a!953 v_0_cb_count)) (<= 1 a!78) a!387)
                  v_0_cb_length_00
                  0))
      (a!989 (ite (and (not (>= a!955 v_0_cb_count)) (<= 1 a!78) a!398)
                  v_0_cb_length_01
                  0))
      (a!990 (ite (and (not (>= a!957 v_0_cb_count)) (<= 1 a!78) a!409)
                  v_0_cb_length_02
                  0))
      (a!991 (ite (and (not (>= a!959 v_0_cb_count)) (<= 1 a!78) a!420)
                  v_0_cb_length_03
                  0))
      (a!992 (ite (and (not (>= a!961 v_0_cb_count)) (<= 1 a!78) a!431)
                  v_0_cb_length_04
                  0))
      (a!993 (ite (and (not (>= a!963 v_0_cb_count)) (<= 1 a!78) a!442)
                  v_0_cb_length_05
                  0))
      (a!994 (ite (and (not (>= a!965 v_0_cb_count)) (<= 1 a!78) a!453)
                  v_0_cb_length_06
                  0))
      (a!995 (ite (and (not (>= a!967 v_0_cb_count)) (<= 1 a!78) a!464)
                  v_0_cb_length_07
                  0))
      (a!996 (ite (and (not (>= a!969 v_0_cb_count)) (<= 1 a!78) a!475)
                  v_0_cb_length_08
                  0))
      (a!997 (ite (and (not (>= a!971 v_0_cb_count)) (<= 1 a!78) a!486)
                  v_0_cb_length_09
                  0))
      (a!998 (ite (and (not (>= a!973 v_0_cb_count)) (<= 1 a!78) a!497)
                  v_0_cb_length_10
                  0))
      (a!999 (ite (and (not (>= a!975 v_0_cb_count)) (<= 1 a!78) a!508)
                  v_0_cb_length_11
                  0))
      (a!1000 (ite (and (not (>= a!977 v_0_cb_count)) (<= 1 a!78) a!519)
                   v_0_cb_length_12
                   0))
      (a!1001 (ite (and (not (>= a!979 v_0_cb_count)) (<= 1 a!78) a!530)
                   v_0_cb_length_13
                   0))
      (a!1002 (ite (and (not (>= a!981 v_0_cb_count)) (<= 1 a!78) a!541)
                   v_0_cb_length_14
                   0))
      (a!1003 (ite (and (not (>= a!983 v_0_cb_count)) (<= 1 a!78) a!552)
                   v_0_cb_length_15
                   0))
      (a!1037 (ite (and (not (>= a!953 v_0_cb_count)) (<= 1 a!78) a!387)
                   0
                   v_0_cb_length_00))
      (a!1038 (ite (and (not (>= a!955 v_0_cb_count)) (<= 1 a!78) a!398)
                   0
                   v_0_cb_length_01))
      (a!1039 (ite (and (not (>= a!957 v_0_cb_count)) (<= 1 a!78) a!409)
                   0
                   v_0_cb_length_02))
      (a!1040 (ite (and (not (>= a!959 v_0_cb_count)) (<= 1 a!78) a!420)
                   0
                   v_0_cb_length_03))
      (a!1041 (ite (and (not (>= a!961 v_0_cb_count)) (<= 1 a!78) a!431)
                   0
                   v_0_cb_length_04))
      (a!1042 (ite (and (not (>= a!963 v_0_cb_count)) (<= 1 a!78) a!442)
                   0
                   v_0_cb_length_05))
      (a!1043 (ite (and (not (>= a!965 v_0_cb_count)) (<= 1 a!78) a!453)
                   0
                   v_0_cb_length_06))
      (a!1044 (ite (and (not (>= a!967 v_0_cb_count)) (<= 1 a!78) a!464)
                   0
                   v_0_cb_length_07))
      (a!1045 (ite (and (not (>= a!969 v_0_cb_count)) (<= 1 a!78) a!475)
                   0
                   v_0_cb_length_08))
      (a!1046 (ite (and (not (>= a!971 v_0_cb_count)) (<= 1 a!78) a!486)
                   0
                   v_0_cb_length_09))
      (a!1047 (ite (and (not (>= a!973 v_0_cb_count)) (<= 1 a!78) a!497)
                   0
                   v_0_cb_length_10))
      (a!1048 (ite (and (not (>= a!975 v_0_cb_count)) (<= 1 a!78) a!508)
                   0
                   v_0_cb_length_11))
      (a!1049 (ite (and (not (>= a!977 v_0_cb_count)) (<= 1 a!78) a!519)
                   0
                   v_0_cb_length_12))
      (a!1050 (ite (and (not (>= a!979 v_0_cb_count)) (<= 1 a!78) a!530)
                   0
                   v_0_cb_length_13))
      (a!1051 (ite (and (not (>= a!981 v_0_cb_count)) (<= 1 a!78) a!541)
                   0
                   v_0_cb_length_14))
      (a!1052 (ite (and (not (>= a!983 v_0_cb_count)) (<= 1 a!78) a!552)
                   0
                   v_0_cb_length_15))
      (a!1055 (= v_1_cb_done_00
                 (and (not (>= a!953 v_0_cb_count)) (<= 1 a!78) a!387)))
      (a!1057 (= v_1_cb_done_01
                 (and (not (>= a!955 v_0_cb_count)) (<= 1 a!78) a!398)))
      (a!1059 (= v_1_cb_done_02
                 (and (not (>= a!957 v_0_cb_count)) (<= 1 a!78) a!409)))
      (a!1061 (= v_1_cb_done_03
                 (and (not (>= a!959 v_0_cb_count)) (<= 1 a!78) a!420)))
      (a!1063 (= v_1_cb_done_04
                 (and (not (>= a!961 v_0_cb_count)) (<= 1 a!78) a!431)))
      (a!1065 (= v_1_cb_done_05
                 (and (not (>= a!963 v_0_cb_count)) (<= 1 a!78) a!442)))
      (a!1067 (= v_1_cb_done_06
                 (and (not (>= a!965 v_0_cb_count)) (<= 1 a!78) a!453)))
      (a!1069 (= v_1_cb_done_07
                 (and (not (>= a!967 v_0_cb_count)) (<= 1 a!78) a!464)))
      (a!1071 (= v_1_cb_done_08
                 (and (not (>= a!969 v_0_cb_count)) (<= 1 a!78) a!475)))
      (a!1073 (= v_1_cb_done_09
                 (and (not (>= a!971 v_0_cb_count)) (<= 1 a!78) a!486)))
      (a!1075 (= v_1_cb_done_10
                 (and (not (>= a!973 v_0_cb_count)) (<= 1 a!78) a!497)))
      (a!1077 (= v_1_cb_done_11
                 (and (not (>= a!975 v_0_cb_count)) (<= 1 a!78) a!508)))
      (a!1079 (= v_1_cb_done_12
                 (and (not (>= a!977 v_0_cb_count)) (<= 1 a!78) a!519)))
      (a!1081 (= v_1_cb_done_13
                 (and (not (>= a!979 v_0_cb_count)) (<= 1 a!78) a!530)))
      (a!1083 (= v_1_cb_done_14
                 (and (not (>= a!981 v_0_cb_count)) (<= 1 a!78) a!541)))
      (a!1085 (= v_1_cb_done_15
                 (and (not (>= a!983 v_0_cb_count)) (<= 1 a!78) a!552))))
(let ((a!82 (+ (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)
               (* (- 1) (ite a!40 a!63 v_0_rtx_buf))))
      (a!88 (<= a!85 (ite a!87 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!106 (* (- 1.0)
                (ite (<= (ite a!100 a!105 v_0_rttvar_ms) (/ 1.0 4.0))
                     1.0
                     (* 4.0 (ite a!100 a!105 v_0_rttvar_ms)))))
      (a!111 (+ 8 (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)))
      (a!112 (+ 8
                (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)
                (* (- 1) (ite a!40 a!63 v_0_rtx_buf))))
      (a!263 (= v_1_cc_cwnd
                (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)))
      (a!299 (ite a!281
                  v_0_cc_rto_07
                  (ite a!283
                       v_0_cc_rto_08
                       (ite a!285 v_0_cc_rto_09 (ite a!287 v_0_cc_rto_10 a!298)))))
      (a!305 (ite a!279
                  v_0_cc_rto_07
                  (ite a!281
                       v_0_cc_rto_08
                       (ite a!283 v_0_cc_rto_09 (ite a!285 v_0_cc_rto_10 a!304)))))
      (a!311 (ite a!277
                  v_0_cc_rto_07
                  (ite a!279
                       v_0_cc_rto_08
                       (ite a!281 v_0_cc_rto_09 (ite a!283 v_0_cc_rto_10 a!310)))))
      (a!317 (ite a!275
                  v_0_cc_rto_07
                  (ite a!277
                       v_0_cc_rto_08
                       (ite a!279 v_0_cc_rto_09 (ite a!281 v_0_cc_rto_10 a!316)))))
      (a!322 (ite a!273
                  v_0_cc_rto_07
                  (ite a!275
                       v_0_cc_rto_08
                       (ite a!277 v_0_cc_rto_09 (ite a!279 v_0_cc_rto_10 a!321)))))
      (a!327 (ite a!271
                  v_0_cc_rto_07
                  (ite a!273
                       v_0_cc_rto_08
                       (ite a!275 v_0_cc_rto_09 (ite a!277 v_0_cc_rto_10 a!326)))))
      (a!332 (ite a!269
                  v_0_cc_rto_07
                  (ite a!271
                       v_0_cc_rto_08
                       (ite a!273 v_0_cc_rto_09 (ite a!275 v_0_cc_rto_10 a!331)))))
      (a!337 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_07
                  (ite a!269
                       v_0_cc_rto_08
                       (ite a!271 v_0_cc_rto_09 (ite a!273 v_0_cc_rto_10 a!336)))))
      (a!341 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_08
                  (ite a!269 v_0_cc_rto_09 (ite a!271 v_0_cc_rto_10 a!340))))
      (a!345 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_09
                  (ite a!269 v_0_cc_rto_10 a!344)))
      (a!349 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_10
                  a!348))
      (a!353 (and (not (>= 11 (ite a!40 a!63 v_0_rtx_buf))) a!352))
      (a!356 (and (not (>= 12 (ite a!40 a!63 v_0_rtx_buf))) a!355))
      (a!359 (and (not (>= 13 (ite a!40 a!63 v_0_rtx_buf))) a!358))
      (a!362 (and (not (>= 14 (ite a!40 a!63 v_0_rtx_buf))) a!361))
      (a!554 (+ v_0_cb_head
                a!388
                a!399
                a!410
                a!421
                a!432
                a!443
                a!454
                a!465
                a!476
                a!487
                a!498
                a!509
                a!520
                a!531
                a!542
                a!553))
      (a!985 (+ 15
                a!954
                a!956
                a!958
                a!960
                a!962
                a!964
                a!966
                a!968
                a!970
                a!972
                a!974
                a!976
                a!978
                a!980
                a!982
                a!984)))
(let ((a!89 (ite a!88 a!85 (ite a!87 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!107 (to_int (+ (* (- 1.0) (ite a!100 a!102 v_0_srtt_ms)) a!106)))
      (a!113 (<= v_0_snd_buf
                 (ite (<= (ite a!60 input_0_net.ack_window v_0_snd_wnd) a!111)
                      a!73
                      a!112)))
      (a!149 (<= (- 999.0) (+ (* (- 1.0) (ite a!100 a!102 v_0_srtt_ms)) a!106)))
      (a!300 (ite a!273
                  v_0_cc_rto_03
                  (ite a!275
                       v_0_cc_rto_04
                       (ite a!277 v_0_cc_rto_05 (ite a!279 v_0_cc_rto_06 a!299)))))
      (a!306 (ite a!271
                  v_0_cc_rto_03
                  (ite a!273
                       v_0_cc_rto_04
                       (ite a!275 v_0_cc_rto_05 (ite a!277 v_0_cc_rto_06 a!305)))))
      (a!312 (ite a!269
                  v_0_cc_rto_03
                  (ite a!271
                       v_0_cc_rto_04
                       (ite a!273 v_0_cc_rto_05 (ite a!275 v_0_cc_rto_06 a!311)))))
      (a!318 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_03
                  (ite a!269
                       v_0_cc_rto_04
                       (ite a!271 v_0_cc_rto_05 (ite a!273 v_0_cc_rto_06 a!317)))))
      (a!323 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_04
                  (ite a!269 v_0_cc_rto_05 (ite a!271 v_0_cc_rto_06 a!322))))
      (a!328 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_05
                  (ite a!269 v_0_cc_rto_06 a!327)))
      (a!333 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_06
                  a!332))
      (a!338 (and (not (>= 7 (ite a!40 a!63 v_0_rtx_buf))) a!337))
      (a!342 (and (not (>= 8 (ite a!40 a!63 v_0_rtx_buf))) a!341))
      (a!346 (and (not (>= 9 (ite a!40 a!63 v_0_rtx_buf))) a!345))
      (a!350 (and (not (>= 10 (ite a!40 a!63 v_0_rtx_buf))) a!349)))
(let ((a!90 (* (- 1) (ite (and a!84 (<= 1 a!89)) now_1 v_0_idle_last_data_ms)))
      (a!108 (ite (<= a!107 (- 1000)) (* (- 1) a!107) 1000))
      (a!114 (ite a!113
                  v_0_snd_buf
                  (ite (<= (ite a!60 input_0_net.ack_window v_0_snd_wnd) a!111)
                       a!73
                       a!112)))
      (a!140 (and (not a!64)
                  v_0_rtt_active
                  (not a!127)
                  (<= a!139 (+ (- 1) a!89))))
      (a!150 (<= 60000 (ite a!149 1000 (* (- 1) a!107))))
      (a!301 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_00
                  (ite a!269 v_0_cc_rto_01 (ite a!271 v_0_cc_rto_02 a!300))))
      (a!307 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_01
                  (ite a!269 v_0_cc_rto_02 a!306)))
      (a!313 (ite (or a!267
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_02
                  a!312))
      (a!319 (and (not (>= 3 (ite a!40 a!63 v_0_rtx_buf))) a!318))
      (a!324 (and (not (>= 4 (ite a!40 a!63 v_0_rtx_buf))) a!323))
      (a!329 (and (not (>= 5 (ite a!40 a!63 v_0_rtx_buf))) a!328))
      (a!334 (and (not (>= 6 (ite a!40 a!63 v_0_rtx_buf))) a!333))
      (a!557 (and a!84
                  (<= 1 a!89)
                  (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_nxt)))
      (a!633 (and (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                      (- 4294967296))
                  (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                     8589934592)))
      (a!634 (ite (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                      4294967296)
                  (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                     4294967296)
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89))))
(let ((a!109 (<= (+ now_1 a!90)
                 (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_ms)))
      (a!117 (= v_1_rto_ms
                (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_ms)))
      (a!141 (ite a!84
                  (or (and (not a!64) (not a!127) v_0_rtt_ambiguous) a!140)
                  (and (not a!64) (not a!127) v_0_rtt_ambiguous)))
      (a!148 (= v_1_rto_base_ms
                (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_base_ms)))
      (a!151 (ite a!150 60000 (ite a!149 1000 (* (- 1) a!107))))
      (a!261 (ite a!260
                  (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_ms)
                  v_0_persist_interval_ms))
      (a!302 (and (not (>= 0 (ite a!40 a!63 v_0_rtx_buf))) a!301))
      (a!308 (and (not (>= 1 (ite a!40 a!63 v_0_rtx_buf))) a!307))
      (a!314 (and (not (>= 2 (ite a!40 a!63 v_0_rtx_buf))) a!313))
      (a!635 (ite (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89) 0)
                  (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                     4294967296)
                  a!634)))
(let ((a!110 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  a!109))
      (a!142 (or a!141 (not (and (not a!64) v_0_rtt_active (not a!127)))))
      (a!262 (= v_1_persist_deadline_ms
                (ite a!64 (ite a!260 (+ now_1 a!261) v_0_persist_deadline_ms) 0)))
      (a!636 (ite a!633
                  a!635
                  (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                       4294967296)))
      (a!674 (= due_1_rtx
                (ite (or a!672 a!670)
                     (+ now_1 (ite a!100 a!151 v_0_rto_ms))
                     due_0_rtx))))
(let ((a!115 (+ v_0_snd_nxt (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take)))
      (a!118 (<= 0 (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take)))
      (a!124 (= v_1_take (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take)))
      (a!128 (= v_1_rtt_active
                (or a!110 (and (not a!64) v_0_rtt_active (not a!127)))))
      (a!143 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  a!109
                  a!142))
      (a!371 (= v_1_lt_take (ite a!110 (ite (<= 4 a!114) 4 a!114) 0)))
      (a!373 (+ (ite a!372 0 v_0_lt_epoch_bytes)
                (ite a!110 (ite (<= 4 a!114) 4 a!114) 0)))
      (a!374 (= v_1_lt_epoch_packets
                (+ (ite a!372 0 v_0_lt_epoch_packets) (ite a!110 1 0)))))
(let ((a!116 (ite (and (>= a!115 (- 4294967296)) (< a!115 8589934592))
                  (ite (< a!115 0)
                       (+ a!115 4294967296)
                       (ite (>= a!115 4294967296) (- a!115 4294967296) a!115))
                  (mod a!115 4294967296)))
      (a!119 (ite a!118 (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take) 0))
      (a!144 (= v_1_rtt_ambiguous (ite a!110 (and (not a!143) a!141) a!141))))
(let ((a!120 (ite (<= v_0_snd_buf a!119) 0 (+ v_0_snd_buf (* (- 1) a!119))))
      (a!122 (ite (<= (ite (<= v_0_snd_buf 0) 0 v_0_snd_buf) a!119)
                  (ite (<= v_0_snd_buf 0) 0 v_0_snd_buf)
                  a!119)))
(let ((a!121 (ite (<= a!120 (ite (<= 0 v_0_snd_buf) v_0_snd_buf 0))
                  a!120
                  (ite (<= 0 v_0_snd_buf) v_0_snd_buf 0)))
      (a!123 (ite a!110
                  (+ (ite a!40 a!63 v_0_rtx_buf) a!122)
                  (ite a!40 a!63 v_0_rtx_buf)))
      (a!145 (ite (< (+ v_0_snd_nxt a!122) 0)
                  (+ (+ v_0_snd_nxt a!122) 4294967296)
                  (ite (>= (+ v_0_snd_nxt a!122) 4294967296)
                       (- (+ v_0_snd_nxt a!122) 4294967296)
                       (+ v_0_snd_nxt a!122))))
      (a!147 (= v_1_rtt_remaining
                (ite a!143
                     a!122
                     (ite (or a!64 a!127) 0 (ite a!138 a!137 v_0_rtt_remaining)))))
      (a!152 (and (>= 0 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!176 (and (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 2 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!183 (and (>= 2 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 3 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!190 (and (>= 3 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 4 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!197 (and (>= 4 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 5 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!204 (and (>= 5 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 6 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!210 (and (>= 6 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 7 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!215 (and (>= 7 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 8 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!222 (and (>= 8 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 9 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!228 (and (>= 9 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 10 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!233 (and (>= 10 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 11 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!238 (and (>= 11 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 12 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!243 (and (>= 12 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 13 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!248 (and (>= 13 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 14 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!252 (and (>= 14 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 15 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!256 (and (>= 15 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 16 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!366 (ite a!110
                  (or v_0_idle_data_valid (and a!84 (<= 1 a!89)) (<= 1 a!122))
                  (or v_0_idle_data_valid (and a!84 (<= 1 a!89)))))
      (a!367 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                  (or (and a!84 (<= 1 a!89)) (<= 1 a!122))))
      (a!369 (ite a!110
                  (or (and a!84 (<= 1 a!89)) (<= 1 a!122))
                  (and a!84 (<= 1 a!89))))
      (a!558 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  a!109
                  (<= 1 a!122))))
(let ((a!146 (ite (and (>= (+ v_0_snd_nxt a!122) (- 4294967296))
                       (< (+ v_0_snd_nxt a!122) 8589934592))
                  a!145
                  (mod (+ v_0_snd_nxt a!122) 4294967296)))
      (a!153 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!152 a!84))
                 (and (not a!110) a!84)))
      (a!177 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!175) a!176))
                 (and (not a!110) a!84 a!175)))
      (a!184 (or (and (not a!110) a!84 a!182)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!182) a!183))))
      (a!191 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!189) a!190))
                 (and (not a!110) a!84 a!189)))
      (a!198 (or (and (not a!110) a!84 a!196)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!196) a!197))))
      (a!205 (or (and (not a!110) a!84 a!203)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!204 (and a!84 a!203)))))
      (a!211 (or (and (not a!110) a!84 a!209)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!209) a!210))))
      (a!217 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!215 (and a!84 a!216)))
                 (and (not a!110) a!84 a!216)))
      (a!223 (or (and (not a!110) a!84 a!221)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!221) a!222))))
      (a!229 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!227) a!228))
                 (and (not a!110) a!84 a!227)))
      (a!234 (or (and (not a!110) a!84 a!232)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!233 (and a!84 a!232)))))
      (a!239 (or (and (not a!110) a!84 a!237)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!238 (and a!84 a!237)))))
      (a!244 (or (and (not a!110) a!84 a!242)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!243 (and a!84 a!242)))))
      (a!249 (or (and (not a!110) a!84 a!247)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!248 (and a!84 a!247)))))
      (a!253 (or (and (not a!110) a!84 a!251)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or a!252 (and a!84 a!251)))))
      (a!257 (or (and (not a!110) a!84 a!255)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!151 v_0_rto_ms))
                      (or (and a!84 a!255) a!256))))
      (a!368 (ite (or (and (not a!110) a!84 (<= 1 a!89)) a!367)
                  now_1
                  v_0_idle_last_data_ms))
      (a!376 (+ v_0_snd_buf
                v_0_rtx_buf
                (* (- 1) a!78)
                (* (- 1) (ite a!110 a!121 v_0_snd_buf))
                (* (- 1) a!123)))
      (a!562 (= v_1_cb_new_count (+ (ite a!557 1 0) (ite a!558 1 0))))
      (a!579 (= 1 (+ (ite a!557 1 0) (ite a!558 1 0))))
      (a!615 (= v_1_cb_emitted_total
                (+ v_0_cb_emitted_total (ite a!558 a!122 (ite a!557 a!89 0))))))
(let ((a!188 (ite a!184
                  now_1
                  (ite (>= 2 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155
                            (ite a!156 v_0_tx_time_03 a!187)
                            v_0_tx_time_02))))
      (a!195 (ite a!191
                  now_1
                  (ite (>= 3 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155 a!194 v_0_tx_time_03))))
      (a!202 (ite a!198 now_1 (ite (>= 4 (ite a!40 a!63 v_0_rtx_buf)) 0 a!201)))
      (a!214 (ite a!211
                  now_1
                  (ite (>= 6 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155
                            (ite a!156 v_0_tx_time_07 a!213)
                            v_0_tx_time_06))))
      (a!220 (ite a!217
                  now_1
                  (ite (>= 7 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155 a!219 v_0_tx_time_07))))
      (a!226 (ite a!223 now_1 (ite (>= 8 (ite a!40 a!63 v_0_rtx_buf)) 0 a!225)))
      (a!236 (ite a!234
                  now_1
                  (ite (>= 10 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155
                            (ite a!156 v_0_tx_time_11 a!235)
                            v_0_tx_time_10))))
      (a!241 (ite a!239
                  now_1
                  (ite (>= 11 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155 a!240 v_0_tx_time_11))))
      (a!246 (ite a!244 now_1 (ite (>= 12 (ite a!40 a!63 v_0_rtx_buf)) 0 a!245)))
      (a!254 (ite a!253
                  now_1
                  (ite (>= 14 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!155 (ite a!156 v_0_tx_time_15 0) v_0_tx_time_14))))
      (a!377 (= v_1_svc_abandoned_bytes
                (+ v_0_svc_abandoned_bytes (ite (<= 0 a!376) a!376 0))))
      (a!555 (ite (<= 1 (ite (<= 0 a!376) a!376 0))
                  0
                  (ite (<= 16 a!554)
                       (+ (- 16)
                          v_0_cb_head
                          a!388
                          a!399
                          a!410
                          a!421
                          a!432
                          a!443
                          a!454
                          a!465
                          a!476
                          a!487
                          a!498
                          a!509
                          a!520
                          a!531
                          a!542
                          a!553)
                       a!554)))
      (a!556 (ite (<= 1 (ite (<= 0 a!376) a!376 0)) 0 v_0_cb_tail))
      (a!561 (ite (<= 1 (ite (<= 0 a!376) a!376 0))
                  0
                  (+ v_0_cb_count
                     (* (- 1) a!388)
                     (* (- 1) a!399)
                     (* (- 1) a!410)
                     (* (- 1) a!421)
                     (* (- 1) a!432)
                     (* (- 1) a!443)
                     (* (- 1) a!454)
                     (* (- 1) a!465)
                     (* (- 1) a!476)
                     (* (- 1) a!487)
                     (* (- 1) a!498)
                     (* (- 1) a!509)
                     (* (- 1) a!520)
                     (* (- 1) a!531)
                     (* (- 1) a!542)
                     (* (- 1) a!553))))
      (a!580 (or (= v_0_cb_tail 0) (<= 1 (ite (<= 0 a!376) a!376 0))))
      (a!581 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!378 v_0_cb_count)) (<= 1 a!78) a!387)))
      (a!583 (not (<= 1 (ite (<= 0 a!376) a!376 0))))
      (a!584 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!389 v_0_cb_count)) (<= 1 a!78) a!398)))
      (a!586 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!400 v_0_cb_count)) (<= 1 a!78) a!409)))
      (a!588 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!411 v_0_cb_count)) (<= 1 a!78) a!420)))
      (a!590 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!422 v_0_cb_count)) (<= 1 a!78) a!431)))
      (a!592 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!433 v_0_cb_count)) (<= 1 a!78) a!442)))
      (a!594 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!444 v_0_cb_count)) (<= 1 a!78) a!453)))
      (a!596 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!455 v_0_cb_count)) (<= 1 a!78) a!464)))
      (a!598 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!466 v_0_cb_count)) (<= 1 a!78) a!475)))
      (a!600 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!477 v_0_cb_count)) (<= 1 a!78) a!486)))
      (a!602 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!488 v_0_cb_count)) (<= 1 a!78) a!497)))
      (a!604 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!499 v_0_cb_count)) (<= 1 a!78) a!508)))
      (a!606 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!510 v_0_cb_count)) (<= 1 a!78) a!519)))
      (a!608 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!521 v_0_cb_count)) (<= 1 a!78) a!530)))
      (a!610 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!532 v_0_cb_count)) (<= 1 a!78) a!541)))
      (a!612 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                 (and (not (>= a!543 v_0_cb_count)) (<= 1 a!78) a!552)))
      (a!632 (ite (<= 1 (ite (<= 0 a!376) a!376 0))
                  (+ a!616
                     a!617
                     a!618
                     a!619
                     a!620
                     a!621
                     a!622
                     a!623
                     a!624
                     a!625
                     a!626
                     a!627
                     a!628
                     a!629
                     a!630
                     a!631)
                  0))
      (a!986 (ite (<= 1 (ite (<= 0 a!376) a!376 0))
                  0
                  (ite (<= 16 a!985)
                       (+ (- 16)
                          15
                          a!954
                          a!956
                          a!958
                          a!960
                          a!962
                          a!964
                          a!966
                          a!968
                          a!970
                          a!972
                          a!974
                          a!976
                          a!978
                          a!980
                          a!982
                          a!984)
                       a!985)))
      (a!987 (ite (<= 1 (ite (<= 0 a!376) a!376 0))
                  0
                  (+ v_0_cb_count
                     (* (- 1) a!954)
                     (* (- 1) a!956)
                     (* (- 1) a!958)
                     (* (- 1) a!960)
                     (* (- 1) a!962)
                     (* (- 1) a!964)
                     (* (- 1) a!966)
                     (* (- 1) a!968)
                     (* (- 1) a!970)
                     (* (- 1) a!972)
                     (* (- 1) a!974)
                     (* (- 1) a!976)
                     (* (- 1) a!978)
                     (* (- 1) a!980)
                     (* (- 1) a!982)
                     (* (- 1) a!984))))
      (a!1004 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!953 v_0_cb_count)) (<= 1 a!78) a!387)))
      (a!1006 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!955 v_0_cb_count)) (<= 1 a!78) a!398)))
      (a!1008 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!957 v_0_cb_count)) (<= 1 a!78) a!409)))
      (a!1010 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!959 v_0_cb_count)) (<= 1 a!78) a!420)))
      (a!1012 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!961 v_0_cb_count)) (<= 1 a!78) a!431)))
      (a!1014 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!963 v_0_cb_count)) (<= 1 a!78) a!442)))
      (a!1016 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!965 v_0_cb_count)) (<= 1 a!78) a!453)))
      (a!1018 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!967 v_0_cb_count)) (<= 1 a!78) a!464)))
      (a!1020 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!969 v_0_cb_count)) (<= 1 a!78) a!475)))
      (a!1022 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!971 v_0_cb_count)) (<= 1 a!78) a!486)))
      (a!1024 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!973 v_0_cb_count)) (<= 1 a!78) a!497)))
      (a!1026 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!975 v_0_cb_count)) (<= 1 a!78) a!508)))
      (a!1028 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!977 v_0_cb_count)) (<= 1 a!78) a!519)))
      (a!1030 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!979 v_0_cb_count)) (<= 1 a!78) a!530)))
      (a!1032 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!981 v_0_cb_count)) (<= 1 a!78) a!541)))
      (a!1034 (or (<= 1 (ite (<= 0 a!376) a!376 0))
                  (and (not (>= a!983 v_0_cb_count)) (<= 1 a!78) a!552)))
      (a!1053 (ite (<= 1 (ite (<= 0 a!376) a!376 0))
                   (+ a!1037
                      a!1038
                      a!1039
                      a!1040
                      a!1041
                      a!1042
                      a!1043
                      a!1044
                      a!1045
                      a!1046
                      a!1047
                      a!1048
                      a!1049
                      a!1050
                      a!1051
                      a!1052)
                   0)))
(let ((a!559 (+ a!556 (ite a!557 1 0) (ite a!558 1 0)))
      (a!582 (ite (and a!579 a!580)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!581 0 v_0_cb_length_00)))
      (a!585 (ite (and a!579 (= v_0_cb_tail 1) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!584 0 v_0_cb_length_01)))
      (a!587 (ite (and a!579 (= v_0_cb_tail 2) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!586 0 v_0_cb_length_02)))
      (a!589 (ite (and a!579 (= v_0_cb_tail 3) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!588 0 v_0_cb_length_03)))
      (a!591 (ite (and a!579 (= v_0_cb_tail 4) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!590 0 v_0_cb_length_04)))
      (a!593 (ite (and a!579 (= v_0_cb_tail 5) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!592 0 v_0_cb_length_05)))
      (a!595 (ite (and a!579 (= v_0_cb_tail 6) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!594 0 v_0_cb_length_06)))
      (a!597 (ite (and a!579 (= v_0_cb_tail 7) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!596 0 v_0_cb_length_07)))
      (a!599 (ite (and a!579 (= v_0_cb_tail 8) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!598 0 v_0_cb_length_08)))
      (a!601 (ite (and a!579 (= v_0_cb_tail 9) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!600 0 v_0_cb_length_09)))
      (a!603 (ite (and a!579 (= v_0_cb_tail 10) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!602 0 v_0_cb_length_10)))
      (a!605 (ite (and a!579 (= v_0_cb_tail 11) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!604 0 v_0_cb_length_11)))
      (a!607 (ite (and a!579 (= v_0_cb_tail 12) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!606 0 v_0_cb_length_12)))
      (a!609 (ite (and a!579 (= v_0_cb_tail 13) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!608 0 v_0_cb_length_13)))
      (a!611 (ite (and a!579 (= v_0_cb_tail 14) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!610 0 v_0_cb_length_14)))
      (a!613 (ite (and a!579 (= v_0_cb_tail 15) a!583)
                  (ite a!558 a!122 (ite a!557 a!89 0))
                  (ite a!612 0 v_0_cb_length_15)))
      (a!637 (= v_1_cb_end_00
                (ite (and a!579 a!580)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!581 0 v_0_cb_end_00))))
      (a!639 (= v_1_cb_end_01
                (ite (and a!579 (= v_0_cb_tail 1) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!584 0 v_0_cb_end_01))))
      (a!641 (= v_1_cb_end_02
                (ite (and a!579 (= v_0_cb_tail 2) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!586 0 v_0_cb_end_02))))
      (a!643 (= v_1_cb_end_03
                (ite (and a!579 (= v_0_cb_tail 3) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!588 0 v_0_cb_end_03))))
      (a!645 (= v_1_cb_end_04
                (ite (and a!579 (= v_0_cb_tail 4) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!590 0 v_0_cb_end_04))))
      (a!647 (= v_1_cb_end_05
                (ite (and a!579 (= v_0_cb_tail 5) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!592 0 v_0_cb_end_05))))
      (a!649 (= v_1_cb_end_06
                (ite (and a!579 (= v_0_cb_tail 6) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!594 0 v_0_cb_end_06))))
      (a!651 (= v_1_cb_end_07
                (ite (and a!579 (= v_0_cb_tail 7) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!596 0 v_0_cb_end_07))))
      (a!653 (= v_1_cb_end_08
                (ite (and a!579 (= v_0_cb_tail 8) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!598 0 v_0_cb_end_08))))
      (a!655 (= v_1_cb_end_09
                (ite (and a!579 (= v_0_cb_tail 9) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!600 0 v_0_cb_end_09))))
      (a!657 (= v_1_cb_end_10
                (ite (and a!579 (= v_0_cb_tail 10) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!602 0 v_0_cb_end_10))))
      (a!659 (= v_1_cb_end_11
                (ite (and a!579 (= v_0_cb_tail 11) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!604 0 v_0_cb_end_11))))
      (a!661 (= v_1_cb_end_12
                (ite (and a!579 (= v_0_cb_tail 12) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!606 0 v_0_cb_end_12))))
      (a!663 (= v_1_cb_end_13
                (ite (and a!579 (= v_0_cb_tail 13) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!608 0 v_0_cb_end_13))))
      (a!665 (= v_1_cb_end_14
                (ite (and a!579 (= v_0_cb_tail 14) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!610 0 v_0_cb_end_14))))
      (a!667 (= v_1_cb_end_15
                (ite (and a!579 (= v_0_cb_tail 15) a!583)
                     (ite a!558 a!146 (ite a!557 a!636 0))
                     (ite a!612 0 v_0_cb_end_15))))
      (a!1005 (ite (and a!579 a!580)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1004 0 v_0_cb_length_00)))
      (a!1007 (ite (and a!579 (= v_0_cb_tail 1) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1006 0 v_0_cb_length_01)))
      (a!1009 (ite (and a!579 (= v_0_cb_tail 2) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1008 0 v_0_cb_length_02)))
      (a!1011 (ite (and a!579 (= v_0_cb_tail 3) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1010 0 v_0_cb_length_03)))
      (a!1013 (ite (and a!579 (= v_0_cb_tail 4) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1012 0 v_0_cb_length_04)))
      (a!1015 (ite (and a!579 (= v_0_cb_tail 5) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1014 0 v_0_cb_length_05)))
      (a!1017 (ite (and a!579 (= v_0_cb_tail 6) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1016 0 v_0_cb_length_06)))
      (a!1019 (ite (and a!579 (= v_0_cb_tail 7) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1018 0 v_0_cb_length_07)))
      (a!1021 (ite (and a!579 (= v_0_cb_tail 8) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1020 0 v_0_cb_length_08)))
      (a!1023 (ite (and a!579 (= v_0_cb_tail 9) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1022 0 v_0_cb_length_09)))
      (a!1025 (ite (and a!579 (= v_0_cb_tail 10) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1024 0 v_0_cb_length_10)))
      (a!1027 (ite (and a!579 (= v_0_cb_tail 11) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1026 0 v_0_cb_length_11)))
      (a!1029 (ite (and a!579 (= v_0_cb_tail 12) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1028 0 v_0_cb_length_12)))
      (a!1031 (ite (and a!579 (= v_0_cb_tail 13) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1030 0 v_0_cb_length_13)))
      (a!1033 (ite (and a!579 (= v_0_cb_tail 14) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1032 0 v_0_cb_length_14)))
      (a!1035 (ite (and a!579 (= v_0_cb_tail 15) a!583)
                   (ite a!558 a!122 (ite a!557 a!89 0))
                   (ite a!1034 0 v_0_cb_length_15)))
      (a!1054 (= v_1_cb_end_00
                 (ite (and a!579 a!580)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1004 0 v_0_cb_end_00))))
      (a!1056 (= v_1_cb_end_01
                 (ite (and a!579 (= v_0_cb_tail 1) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1006 0 v_0_cb_end_01))))
      (a!1058 (= v_1_cb_end_02
                 (ite (and a!579 (= v_0_cb_tail 2) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1008 0 v_0_cb_end_02))))
      (a!1060 (= v_1_cb_end_03
                 (ite (and a!579 (= v_0_cb_tail 3) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1010 0 v_0_cb_end_03))))
      (a!1062 (= v_1_cb_end_04
                 (ite (and a!579 (= v_0_cb_tail 4) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1012 0 v_0_cb_end_04))))
      (a!1064 (= v_1_cb_end_05
                 (ite (and a!579 (= v_0_cb_tail 5) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1014 0 v_0_cb_end_05))))
      (a!1066 (= v_1_cb_end_06
                 (ite (and a!579 (= v_0_cb_tail 6) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1016 0 v_0_cb_end_06))))
      (a!1068 (= v_1_cb_end_07
                 (ite (and a!579 (= v_0_cb_tail 7) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1018 0 v_0_cb_end_07))))
      (a!1070 (= v_1_cb_end_08
                 (ite (and a!579 (= v_0_cb_tail 8) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1020 0 v_0_cb_end_08))))
      (a!1072 (= v_1_cb_end_09
                 (ite (and a!579 (= v_0_cb_tail 9) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1022 0 v_0_cb_end_09))))
      (a!1074 (= v_1_cb_end_10
                 (ite (and a!579 (= v_0_cb_tail 10) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1024 0 v_0_cb_end_10))))
      (a!1076 (= v_1_cb_end_11
                 (ite (and a!579 (= v_0_cb_tail 11) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1026 0 v_0_cb_end_11))))
      (a!1078 (= v_1_cb_end_12
                 (ite (and a!579 (= v_0_cb_tail 12) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1028 0 v_0_cb_end_12))))
      (a!1080 (= v_1_cb_end_13
                 (ite (and a!579 (= v_0_cb_tail 13) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1030 0 v_0_cb_end_13))))
      (a!1082 (= v_1_cb_end_14
                 (ite (and a!579 (= v_0_cb_tail 14) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1032 0 v_0_cb_end_14))))
      (a!1084 (= v_1_cb_end_15
                 (ite (and a!579 (= v_0_cb_tail 15) a!583)
                      (ite a!558 a!146 (ite a!557 a!636 0))
                      (ite a!1034 0 v_0_cb_end_15)))))
(let ((a!560 (= v_1_cb_tail
                (ite (<= 16 a!559)
                     (+ (- 16) a!556 (ite a!557 1 0) (ite a!558 1 0))
                     a!559)))
      (a!614 (= v_1_cb_partial_prefix
                (+ a!582
                   a!585
                   a!587
                   a!589
                   a!591
                   a!593
                   a!595
                   a!597
                   a!599
                   a!601
                   a!603
                   a!605
                   a!607
                   a!609
                   a!611
                   a!613
                   (* (- 1) a!123))))
      (a!1036 (= v_1_cb_partial_prefix
                 (+ a!1005
                    a!1007
                    a!1009
                    a!1011
                    a!1013
                    a!1015
                    a!1017
                    a!1019
                    a!1021
                    a!1023
                    a!1025
                    a!1027
                    a!1029
                    a!1031
                    a!1033
                    a!1035
                    (* (- 1) a!123)))))
(let ((a!952 (and (>= v_0_snd_buf 0)
                  (>= v_0_rtx_buf 0)
                  (>= v_0_rcv_buf 0)
                  (>= v_0_rx_chunk 0)
                  (>= v_0_rx_slot_00 0)
                  (>= v_0_rx_slot_01 0)
                  (>= v_0_rx_slot_02 0)
                  (>= v_0_rx_slot_03 0)
                  (>= v_0_rx_slot_04 0)
                  (>= v_0_rx_slot_05 0)
                  (>= v_0_rx_slot_06 0)
                  (>= v_0_rx_slot_07 0)
                  (>= v_0_rx_slot_08 0)
                  (>= v_0_rx_slot_09 0)
                  (>= v_0_rx_slot_10 0)
                  (>= v_0_rx_slot_11 0)
                  (>= v_0_rx_slot_12 0)
                  (>= v_0_rx_slot_13 0)
                  (>= v_0_rx_slot_14 0)
                  (>= v_0_rx_slot_15 0)
                  (>= v_1_snd_buf 0)
                  (>= v_1_rtx_buf 0)
                  (>= v_1_rcv_buf 0)
                  (>= v_1_rx_chunk 0)
                  (>= v_1_rx_slot_00 0)
                  (>= v_1_rx_slot_01 0)
                  (>= v_1_rx_slot_02 0)
                  (>= v_1_rx_slot_03 0)
                  (>= v_1_rx_slot_04 0)
                  (>= v_1_rx_slot_05 0)
                  (>= v_1_rx_slot_06 0)
                  (>= v_1_rx_slot_07 0)
                  (>= v_1_rx_slot_08 0)
                  (>= v_1_rx_slot_09 0)
                  (>= v_1_rx_slot_10 0)
                  (>= v_1_rx_slot_11 0)
                  (>= v_1_rx_slot_12 0)
                  (>= v_1_rx_slot_13 0)
                  (>= v_1_rx_slot_14 0)
                  (>= v_1_rx_slot_15 0)
                  (>= v_0_iss 0)
                  (not (<= 4294967296 v_0_iss))
                  (>= v_0_irs 0)
                  (not (<= 4294967296 v_0_irs))
                  (>= v_0_snd_una 0)
                  (not (<= 4294967296 v_0_snd_una))
                  (>= v_0_snd_nxt 0)
                  (not (<= 4294967296 v_0_snd_nxt))
                  (>= v_0_rcv_nxt 0)
                  (not (<= 4294967296 v_0_rcv_nxt))
                  (>= v_0_tx_seq 0)
                  (not (<= 4294967296 v_0_tx_seq))
                  (>= v_0_tx_ack 0)
                  (not (<= 4294967296 v_0_tx_ack))
                  (>= v_0_snd_wl1 0)
                  (not (<= 4294967296 v_0_snd_wl1))
                  (>= v_0_snd_wl2 0)
                  (not (<= 4294967296 v_0_snd_wl2))
                  (>= v_0_fin_seq 0)
                  (not (<= 4294967296 v_0_fin_seq))
                  (>= v_0_rx_fin_seq 0)
                  (not (<= 4294967296 v_0_rx_fin_seq))
                  (>= v_0_rtt_end 0)
                  (not (<= 4294967296 v_0_rtt_end))
                  (>= v_0_cc_before_una 0)
                  (not (<= 4294967296 v_0_cc_before_una))
                  (>= v_0_fr_before_una 0)
                  (not (<= 4294967296 v_0_fr_before_una))
                  (>= v_0_fr_before_nxt 0)
                  (not (<= 4294967296 v_0_fr_before_nxt))
                  (>= v_0_lt_before_nxt 0)
                  (not (<= 4294967296 v_0_lt_before_nxt))
                  (>= v_0_choice_before_nxt 0)
                  (not (<= 4294967296 v_0_choice_before_nxt))
                  (>= v_0_cb_before_nxt 0)
                  (not (<= 4294967296 v_0_cb_before_nxt))
                  (>= v_0_cb_append_end 0)
                  (not (<= 4294967296 v_0_cb_append_end))
                  (>= v_0_cb_end_00 0)
                  (not (<= 4294967296 v_0_cb_end_00))
                  (>= v_0_cb_end_01 0)
                  (not (<= 4294967296 v_0_cb_end_01))
                  (>= v_0_cb_end_02 0)
                  (not (<= 4294967296 v_0_cb_end_02))
                  (>= v_0_cb_end_03 0)
                  (not (<= 4294967296 v_0_cb_end_03))
                  (>= v_0_cb_end_04 0)
                  (not (<= 4294967296 v_0_cb_end_04))
                  (>= v_0_cb_end_05 0)
                  (not (<= 4294967296 v_0_cb_end_05))
                  (>= v_0_cb_end_06 0)
                  (not (<= 4294967296 v_0_cb_end_06))
                  (>= v_0_cb_end_07 0)
                  (not (<= 4294967296 v_0_cb_end_07))
                  (>= v_0_cb_end_08 0)
                  (not (<= 4294967296 v_0_cb_end_08))
                  (>= v_0_cb_end_09 0)
                  (not (<= 4294967296 v_0_cb_end_09))
                  (>= v_0_cb_end_10 0)
                  (not (<= 4294967296 v_0_cb_end_10))
                  (>= v_0_cb_end_11 0)
                  (not (<= 4294967296 v_0_cb_end_11))
                  (>= v_0_cb_end_12 0)
                  (not (<= 4294967296 v_0_cb_end_12))
                  (>= v_0_cb_end_13 0)
                  (not (<= 4294967296 v_0_cb_end_13))
                  (>= v_0_cb_end_14 0)
                  (not (<= 4294967296 v_0_cb_end_14))
                  (>= v_0_cb_end_15 0)
                  (not (<= 4294967296 v_0_cb_end_15))
                  (>= v_1_iss 0)
                  (not (<= 4294967296 v_1_iss))
                  (>= v_1_irs 0)
                  (not (<= 4294967296 v_1_irs))
                  (>= v_1_snd_una 0)
                  (not (<= 4294967296 v_1_snd_una))
                  (>= v_1_snd_nxt 0)
                  (not (<= 4294967296 v_1_snd_nxt))
                  (>= v_1_rcv_nxt 0)
                  (not (<= 4294967296 v_1_rcv_nxt))
                  (>= v_1_tx_seq 0)
                  (not (<= 4294967296 v_1_tx_seq))
                  (>= v_1_tx_ack 0)
                  (not (<= 4294967296 v_1_tx_ack))
                  (>= v_1_snd_wl1 0)
                  (not (<= 4294967296 v_1_snd_wl1))
                  (>= v_1_snd_wl2 0)
                  (not (<= 4294967296 v_1_snd_wl2))
                  (>= v_1_fin_seq 0)
                  (not (<= 4294967296 v_1_fin_seq))
                  (>= v_1_rx_fin_seq 0)
                  (not (<= 4294967296 v_1_rx_fin_seq))
                  (>= v_1_rtt_end 0)
                  (not (<= 4294967296 v_1_rtt_end))
                  (>= v_1_cc_before_una 0)
                  (not (<= 4294967296 v_1_cc_before_una))
                  (>= v_1_fr_before_una 0)
                  (not (<= 4294967296 v_1_fr_before_una))
                  (>= v_1_fr_before_nxt 0)
                  (not (<= 4294967296 v_1_fr_before_nxt))
                  (>= v_1_lt_before_nxt 0)
                  (not (<= 4294967296 v_1_lt_before_nxt))
                  (>= v_1_choice_before_nxt 0)
                  (not (<= 4294967296 v_1_choice_before_nxt))
                  (>= v_1_cb_before_nxt 0)
                  (not (<= 4294967296 v_1_cb_before_nxt))
                  (>= v_1_cb_append_end 0)
                  (not (<= 4294967296 v_1_cb_append_end))
                  (>= v_1_cb_end_00 0)
                  (not (<= 4294967296 v_1_cb_end_00))
                  (>= v_1_cb_end_01 0)
                  (not (<= 4294967296 v_1_cb_end_01))
                  (>= v_1_cb_end_02 0)
                  (not (<= 4294967296 v_1_cb_end_02))
                  (>= v_1_cb_end_03 0)
                  (not (<= 4294967296 v_1_cb_end_03))
                  (>= v_1_cb_end_04 0)
                  (not (<= 4294967296 v_1_cb_end_04))
                  (>= v_1_cb_end_05 0)
                  (not (<= 4294967296 v_1_cb_end_05))
                  (>= v_1_cb_end_06 0)
                  (not (<= 4294967296 v_1_cb_end_06))
                  (>= v_1_cb_end_07 0)
                  (not (<= 4294967296 v_1_cb_end_07))
                  (>= v_1_cb_end_08 0)
                  (not (<= 4294967296 v_1_cb_end_08))
                  (>= v_1_cb_end_09 0)
                  (not (<= 4294967296 v_1_cb_end_09))
                  (>= v_1_cb_end_10 0)
                  (not (<= 4294967296 v_1_cb_end_10))
                  (>= v_1_cb_end_11 0)
                  (not (<= 4294967296 v_1_cb_end_11))
                  (>= v_1_cb_end_12 0)
                  (not (<= 4294967296 v_1_cb_end_12))
                  (>= v_1_cb_end_13 0)
                  (not (<= 4294967296 v_1_cb_end_13))
                  (>= v_1_cb_end_14 0)
                  (not (<= 4294967296 v_1_cb_end_14))
                  (>= v_1_cb_end_15 0)
                  (not (<= 4294967296 v_1_cb_end_15))
                  true
                  true
                  (>= now_0 0)
                  (or (not active_0_rtx) (>= due_0_rtx now_0))
                  (or (not active_0_user) (>= due_0_user now_0))
                  (or (not active_0_time_wait) (>= due_0_time_wait now_0))
                  (or (not active_0_delack) (>= due_0_delack now_0))
                  (or (not active_0_persist) (>= due_0_persist now_0))
                  (>= input_0_app.send_data 0)
                  (>= input_0_net.data_data 0)
                  (>= input_0_net.fin_segment_data 0)
                  (>= input_0_net.syn_seq 0)
                  (not (<= 4294967296 input_0_net.syn_seq))
                  (>= input_0_net.synack_seq 0)
                  (not (<= 4294967296 input_0_net.synack_seq))
                  (>= input_0_net.synack_ack 0)
                  (not (<= 4294967296 input_0_net.synack_ack))
                  (>= input_0_net.ack_seq 0)
                  (not (<= 4294967296 input_0_net.ack_seq))
                  (>= input_0_net.ack_ack 0)
                  (not (<= 4294967296 input_0_net.ack_ack))
                  (>= input_0_net.fin_seq 0)
                  (not (<= 4294967296 input_0_net.fin_seq))
                  (>= input_0_net.fin_ack 0)
                  (not (<= 4294967296 input_0_net.fin_ack))
                  (>= input_0_net.rst_seq 0)
                  (not (<= 4294967296 input_0_net.rst_seq))
                  (>= input_0_net.rstack_seq 0)
                  (not (<= 4294967296 input_0_net.rstack_seq))
                  (>= input_0_net.rstack_ack 0)
                  (not (<= 4294967296 input_0_net.rstack_ack))
                  (>= input_0_net.data_seq 0)
                  (not (<= 4294967296 input_0_net.data_seq))
                  (>= input_0_net.data_ack 0)
                  (not (<= 4294967296 input_0_net.data_ack))
                  (>= input_0_net.fin_segment_seq 0)
                  (not (<= 4294967296 input_0_net.fin_segment_seq))
                  (>= input_0_net.fin_segment_ack 0)
                  (not (<= 4294967296 input_0_net.fin_segment_ack))
                  (>= now_1 now_0)
                  (<= 0 input_0_net.ack_window)
                  (>= 65535 input_0_net.ack_window)
                  a!9
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!27
                  a!36
                  (not a!37)
                  (or (not active_0_rtx) (not (<= due_0_rtx now_1)))
                  (or (not active_0_user) (not (<= due_0_user now_1)))
                  (or (not active_0_time_wait) (not (<= due_0_time_wait now_1)))
                  (or (not active_0_delack) (not (<= due_0_delack now_1)))
                  (or (not active_0_persist) (not (<= due_0_persist now_1)))
                  (= v_1_iss v_0_iss)
                  (= v_1_irs v_0_irs)
                  (= v_1_snd_una (ite a!40 input_0_net.ack_ack v_0_snd_una))
                  (= v_1_snd_nxt (ite a!110 a!116 v_0_snd_nxt))
                  (= v_1_rcv_nxt v_0_rcv_nxt)
                  (= v_1_tx_seq v_0_tx_seq)
                  (= v_1_tx_ack v_0_tx_ack)
                  (= v_1_tx_flags v_0_tx_flags)
                  a!117
                  (= v_1_retries v_0_retries)
                  (= v_1_active_open v_0_active_open)
                  (= v_1_user_timeout_ms v_0_user_timeout_ms)
                  (= v_1_msl_ms v_0_msl_ms)
                  (= v_1_local_window v_0_local_window)
                  (= v_1_snd_buf (ite a!110 a!121 v_0_snd_buf))
                  (= v_1_rtx_buf a!123)
                  (= v_1_rcv_buf v_0_rcv_buf)
                  (= v_1_snd_wnd (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                  (= v_1_snd_wl1 (ite a!60 input_0_net.ack_seq v_0_snd_wl1))
                  (= v_1_snd_wl2 (ite a!60 input_0_net.ack_ack v_0_snd_wl2))
                  a!124
                  (= v_1_rx_chunk v_0_rx_chunk)
                  (= v_1_rx_slot_00 v_0_rx_slot_00)
                  (= v_1_rx_slot_01 v_0_rx_slot_01)
                  (= v_1_rx_slot_02 v_0_rx_slot_02)
                  (= v_1_rx_slot_03 v_0_rx_slot_03)
                  (= v_1_rx_slot_04 v_0_rx_slot_04)
                  (= v_1_rx_slot_05 v_0_rx_slot_05)
                  (= v_1_rx_slot_06 v_0_rx_slot_06)
                  (= v_1_rx_slot_07 v_0_rx_slot_07)
                  (= v_1_rx_slot_08 v_0_rx_slot_08)
                  (= v_1_rx_slot_09 v_0_rx_slot_09)
                  (= v_1_rx_slot_10 v_0_rx_slot_10)
                  (= v_1_rx_slot_11 v_0_rx_slot_11)
                  (= v_1_rx_slot_12 v_0_rx_slot_12)
                  (= v_1_rx_slot_13 v_0_rx_slot_13)
                  (= v_1_rx_slot_14 v_0_rx_slot_14)
                  (= v_1_rx_slot_15 v_0_rx_slot_15)
                  (= v_1_rx_advance v_0_rx_advance)
                  (= v_1_rx_acceptable v_0_rx_acceptable)
                  a!125
                  a!126
                  (= v_1_ack_is_new (and a!38 a!39))
                  (= v_1_ack_is_future a!37)
                  (= v_1_ack_advance a!40)
                  (= v_1_ack_window_update a!60)
                  (= v_1_fin_requested v_0_fin_requested)
                  (= v_1_fin_sent v_0_fin_sent)
                  (= v_1_fin_seq v_0_fin_seq)
                  (= v_1_fin_acknowledged v_0_fin_acknowledged)
                  (= v_1_rx_fin_pending v_0_rx_fin_pending)
                  (= v_1_rx_fin_seq v_0_rx_fin_seq)
                  (= v_1_rx_fin_offset v_0_rx_fin_offset)
                  (= v_1_rx_fin_done v_0_rx_fin_done)
                  (= v_1_rx_fin_consumed v_0_rx_fin_consumed)
                  (= v_1_srtt_ms (ite a!100 a!102 v_0_srtt_ms))
                  (= v_1_rttvar_ms (ite a!100 a!105 v_0_rttvar_ms))
                  (= v_1_rtt_error_ms (ite a!100 a!104 v_0_rtt_error_ms))
                  (= v_1_rtt_previous_srtt
                     (ite a!100 v_0_srtt_ms v_0_rtt_previous_srtt))
                  (= v_1_rtt_previous_var
                     (ite a!100 v_0_rttvar_ms v_0_rtt_previous_var))
                  (= v_1_rtt_measured (or v_0_rtt_measured a!100))
                  (= v_1_rtt_previous_measured
                     (ite a!100 v_0_rtt_measured v_0_rtt_previous_measured))
                  a!128
                  a!144
                  (= v_1_rtt_sample_at_ms
                     (ite a!100 now_1 v_0_rtt_sample_at_ms))
                  (= v_1_rtt_start_ms (ite a!143 now_1 v_0_rtt_start_ms))
                  (= v_1_rtt_end (ite a!143 a!146 v_0_rtt_end))
                  a!147
                  (= v_1_rtt_start_new a!143)
                  (= v_1_rtt_sample_used a!100)
                  (= v_1_rtt_sample_was_ambiguous
                     (and v_0_rtt_active v_0_rtt_ambiguous))
                  (= v_1_rtt_last_ms a!101)
                  (= v_1_rtt_samples (+ v_0_rtt_samples (ite a!100 1 0)))
                  a!148
                  (= v_1_tx_time_00 (ite a!153 now_1 a!174))
                  (= v_1_tx_time_01 (ite a!177 now_1 a!181))
                  (= v_1_tx_time_02 a!188)
                  (= v_1_tx_time_03 a!195)
                  (= v_1_tx_time_04 a!202)
                  (= v_1_tx_time_05 (ite a!205 now_1 a!208))
                  (= v_1_tx_time_06 a!214)
                  (= v_1_tx_time_07 a!220)
                  (= v_1_tx_time_08 a!226)
                  (= v_1_tx_time_09 (ite a!229 now_1 a!231))
                  (= v_1_tx_time_10 a!236)
                  (= v_1_tx_time_11 a!241)
                  (= v_1_tx_time_12 a!246)
                  (= v_1_tx_time_13 (ite a!249 now_1 a!250))
                  (= v_1_tx_time_14 a!254)
                  (= v_1_tx_time_15 (ite a!257 now_1 a!258))
                  a!259
                  (= v_1_tx_emit_count v_0_tx_emit_count)
                  (= v_1_tx_eligible v_0_tx_eligible)
                  (= v_1_tx_max_previous v_0_tx_max_previous)
                  (not v_1_tx_retransmitted)
                  (= v_1_tx_elapsed v_0_tx_elapsed)
                  (= v_1_tx_previous_rto v_0_tx_previous_rto)
                  (= v_1_tx_is_fin v_0_tx_is_fin)
                  (not v_1_tx_waiting)
                  (= v_1_tx_syn_time 0)
                  (not v_1_tx_syn_pending)
                  (not v_1_syn_timeout_eligible)
                  (= v_1_ack_pending
                     (and (not a!110) (not a!84) v_0_ack_pending))
                  (= v_1_ack_since_ms (ite (or a!110 a!84) 0 v_0_ack_since_ms))
                  (= v_1_ack_bytes (ite (or a!110 a!84) 0 v_0_ack_bytes))
                  (= v_1_ack_full_segments
                     (ite (or a!110 a!84) 0 v_0_ack_full_segments))
                  (= v_1_ack_delay_ms v_0_ack_delay_ms)
                  (= v_1_ack_rmss v_0_ack_rmss)
                  (not v_1_ack_defer_candidate)
                  (not v_1_ack_defer_now)
                  (= v_1_persist_active a!64)
                  (= v_1_persist_eligible a!64)
                  (= v_1_persist_start a!260)
                  (= v_1_persist_was_active v_0_persist_active)
                  (not v_1_persist_first)
                  (not v_1_persist_probe_sent)
                  (not v_1_persist_probe_new)
                  (= v_1_persist_interval_ms (ite a!64 a!261 1000))
                  (= v_1_persist_previous_interval_ms
                     v_0_persist_previous_interval_ms)
                  (= v_1_persist_since_ms
                     (ite a!64 (ite a!260 now_1 v_0_persist_since_ms) 0))
                  (= v_1_persist_last_ms (ite a!64 v_0_persist_last_ms 0))
                  a!262
                  (= v_1_persist_probes (ite a!64 v_0_persist_probes 0))
                  (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)
                  (= v_1_cc_initial_window v_0_cc_initial_window)
                  (= v_1_cc_initial_threshold v_0_cc_initial_threshold)
                  a!263
                  (= v_1_cc_ssthresh (ite a!70 a!76 v_0_cc_ssthresh))
                  (= v_1_cc_ca_credit a!265)
                  (= v_1_cc_acked a!78)
                  (= v_1_cc_before_flight v_0_rtx_buf)
                  (= v_1_cc_before_una v_0_snd_una)
                  (= v_1_cc_before_persist v_0_persist_active)
                  (= v_1_cc_before_window v_0_snd_wnd)
                  (not v_1_cc_loss)
                  (not v_1_cc_threshold_changed)
                  (= v_1_cc_threshold_updates v_0_cc_threshold_updates)
                  (= v_1_cc_growth (ite a!79 0 a!80))
                  (= v_1_cc_before_cwnd v_0_cc_cwnd)
                  (= v_1_cc_send_budget (ite (<= 0 a!266) a!266 0))
                  (= 0 v_1_cc_new_sent)
                  (= v_1_cc_rto_00 a!302)
                  (= v_1_cc_rto_01 a!308)
                  (= v_1_cc_rto_02 a!314)
                  (= v_1_cc_rto_03 a!319)
                  (= v_1_cc_rto_04 a!324)
                  (= v_1_cc_rto_05 a!329)
                  (= v_1_cc_rto_06 a!334)
                  (= v_1_cc_rto_07 a!338)
                  (= v_1_cc_rto_08 a!342)
                  (= v_1_cc_rto_09 a!346)
                  (= v_1_cc_rto_10 a!350)
                  (= v_1_cc_rto_11 a!353)
                  (= v_1_cc_rto_12 a!356)
                  (= v_1_cc_rto_13 a!359)
                  (= v_1_cc_rto_14 a!362)
                  (= v_1_cc_rto_15 a!363)
                  (not v_1_fr_window_ignored)
                  (= v_1_fr_before_wire_window v_0_fr_last_window)
                  (= v_1_fr_before_window_valid v_0_fr_window_valid)
                  (= v_1_fr_active a!72)
                  a!364
                  v_1_fr_window_valid
                  (= v_1_fr_last_window input_0_net.ack_window)
                  (= v_1_fr_was_active v_0_fr_active)
                  (= v_1_fr_before_una v_0_snd_una)
                  (= v_1_fr_before_nxt v_0_snd_nxt)
                  (= v_1_fr_before_flight v_0_rtx_buf)
                  (= v_1_fr_before_rto v_0_rto_ms)
                  (= v_1_fr_before_retries v_0_retries)
                  (= v_1_fr_duplicate a!66)
                  (= v_1_fr_entered a!70)
                  (= v_1_fr_extra a!77)
                  (= v_1_fr_exited a!71)
                  (= v_1_fr_retransmitted a!84)
                  a!365
                  (= v_1_fr_entries (+ v_0_fr_entries (ite a!70 1 0)))
                  (= v_1_idle_data_valid a!366)
                  (= v_1_idle_last_data_ms a!368)
                  (= v_1_idle_event_ms now_1)
                  (= v_1_idle_data_emitted a!369)
                  (not v_1_idle_restart)
                  (= v_1_idle_elapsed_ms a!370)
                  (= v_1_idle_before_cwnd v_0_cc_cwnd)
                  (= v_1_idle_before_rto v_0_rto_ms)
                  (= v_1_idle_before_threshold v_0_cc_ssthresh)
                  (= v_1_idle_restart_count v_0_idle_restart_count)
                  (= v_1_lt_eligible a!110)
                  (= v_1_lt_emitted a!110)
                  a!371
                  (= v_1_lt_epoch_bytes a!373)
                  a!374
                  (= v_1_lt_before_bytes v_0_lt_epoch_bytes)
                  (= v_1_lt_before_cwnd v_0_cc_cwnd)
                  (= v_1_lt_before_nxt v_0_snd_nxt)
                  (= v_1_lt_before_flight v_0_rtx_buf)
                  (= v_1_lt_before_window v_0_snd_wnd)
                  a!375
                  (not v_1_choice_used)
                  (= v_1_choice_count v_0_choice_count)
                  (= v_1_choice_limit v_0_choice_limit)
                  (= v_1_choice_before_nxt v_0_choice_before_nxt)
                  (= v_1_choice_before_flight v_0_choice_before_flight)
                  v_1_sched_open
                  (= v_1_sched_at_ms now_1)
                  (= 2 v_1_sched_cause)
                  (= 0 v_1_sched_bytes)
                  (= 0 v_1_sched_packets)
                  (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf))
                  (= 0 v_1_svc_accept_step)
                  (= v_1_svc_ack_step a!78)
                  (= v_1_svc_drop_step (ite (<= 0 a!376) a!376 0))
                  (= v_1_svc_written_bytes v_0_svc_written_bytes)
                  (= v_1_svc_acked_bytes (+ v_0_svc_acked_bytes a!78))
                  a!377
                  (= v_1_cb_head a!555)
                  a!560
                  (= v_1_cb_count (+ a!561 (ite a!557 1 0) (ite a!558 1 0)))
                  a!562
                  (= v_1_cb_append_length (ite a!558 a!122 (ite a!557 a!89 0)))
                  (= v_1_cb_retired_count
                     (+ a!388
                        a!399
                        a!410
                        a!421
                        a!432
                        a!443
                        a!454
                        a!465
                        a!476
                        a!487
                        a!498
                        a!509
                        a!520
                        a!531
                        a!542
                        a!553))
                  (= v_1_cb_step_bytes
                     (+ a!563
                        a!564
                        a!565
                        a!566
                        a!567
                        a!568
                        a!569
                        a!570
                        a!571
                        a!572
                        a!573
                        a!574
                        a!575
                        a!576
                        a!577
                        a!578))
                  (= v_1_cb_live_total
                     (+ a!582
                        a!585
                        a!587
                        a!589
                        a!591
                        a!593
                        a!595
                        a!597
                        a!599
                        a!601
                        a!603
                        a!605
                        a!607
                        a!609
                        a!611
                        a!613))
                  a!614
                  a!615
                  (= v_1_cb_acked_total
                     (+ v_0_cb_acked_total
                        a!563
                        a!564
                        a!565
                        a!566
                        a!567
                        a!568
                        a!569
                        a!570
                        a!571
                        a!572
                        a!573
                        a!574
                        a!575
                        a!576
                        a!577
                        a!578))
                  (= v_1_cb_abandoned_total (+ v_0_cb_abandoned_total a!632))
                  (= v_1_cb_drop_step a!632)
                  (= v_1_cb_before_nxt v_0_snd_nxt)
                  (= v_1_cb_append_end (ite a!558 a!146 (ite a!557 a!636 0)))
                  (= v_1_cb_is_new a!558)
                  (= v_1_cb_length_00 a!582)
                  a!637
                  a!638
                  (= v_1_cb_length_01 a!585)
                  a!639
                  a!640
                  (= v_1_cb_length_02 a!587)
                  a!641
                  a!642
                  (= v_1_cb_length_03 a!589)
                  a!643
                  a!644
                  (= v_1_cb_length_04 a!591)
                  a!645
                  a!646
                  (= v_1_cb_length_05 a!593)
                  a!647
                  a!648
                  (= v_1_cb_length_06 a!595)
                  a!649
                  a!650
                  (= v_1_cb_length_07 a!597)
                  a!651
                  a!652
                  (= v_1_cb_length_08 a!599)
                  a!653
                  a!654
                  (= v_1_cb_length_09 a!601)
                  a!655
                  a!656
                  (= v_1_cb_length_10 a!603)
                  a!657
                  a!658
                  (= v_1_cb_length_11 a!605)
                  a!659
                  a!660
                  (= v_1_cb_length_12 a!607)
                  a!661
                  a!662
                  (= v_1_cb_length_13 a!609)
                  a!663
                  a!664
                  (= v_1_cb_length_14 a!611)
                  a!665
                  a!666
                  (= v_1_cb_length_15 a!613)
                  a!667
                  a!668
                  (= active_1_rtx (or a!671 a!672))
                  (= active_1_user active_0_user)
                  (= active_1_time_wait active_0_time_wait)
                  (= active_1_delack
                     (and (not a!110) (not a!84) active_0_delack))
                  (= active_1_persist a!673)
                  a!674
                  (= due_1_user due_0_user)
                  (= due_1_time_wait due_0_time_wait)
                  (= due_1_delack due_0_delack)
                  (= due_1_persist (ite a!260 (+ now_1 a!261) due_0_persist))
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  (not active_0_user)
                  (not active_0_time_wait)
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  (<= 1000 v_0_rto_ms)
                  (<= 0 v_0_retries)
                  (<= 1 v_0_msl_ms)
                  (<= 1 v_0_user_timeout_ms)
                  true
                  (>= 16 (+ v_0_snd_buf v_0_rtx_buf))
                  (>= 16 v_0_rcv_buf)
                  (<= 0 v_0_snd_wnd)
                  (>= 65535 v_0_snd_wnd)
                  a!675
                  (>= 1 v_0_rx_slot_00)
                  (or (not (>= v_0_rcv_buf 16)) (= 0 v_0_rx_slot_00))
                  (>= 1 v_0_rx_slot_01)
                  (or (not (>= v_0_rcv_buf 15)) (= 0 v_0_rx_slot_01))
                  (>= 1 v_0_rx_slot_02)
                  (or (not (>= v_0_rcv_buf 14)) (= 0 v_0_rx_slot_02))
                  (>= 1 v_0_rx_slot_03)
                  (or (not (>= v_0_rcv_buf 13)) (= 0 v_0_rx_slot_03))
                  (>= 1 v_0_rx_slot_04)
                  (or (not (>= v_0_rcv_buf 12)) (= 0 v_0_rx_slot_04))
                  (>= 1 v_0_rx_slot_05)
                  (or (not (>= v_0_rcv_buf 11)) (= 0 v_0_rx_slot_05))
                  (>= 1 v_0_rx_slot_06)
                  (or (not (>= v_0_rcv_buf 10)) (= 0 v_0_rx_slot_06))
                  (>= 1 v_0_rx_slot_07)
                  (or (not (>= v_0_rcv_buf 9)) (= 0 v_0_rx_slot_07))
                  (>= 1 v_0_rx_slot_08)
                  (or (not (>= v_0_rcv_buf 8)) (= 0 v_0_rx_slot_08))
                  (>= 1 v_0_rx_slot_09)
                  (or (not (>= v_0_rcv_buf 7)) (= 0 v_0_rx_slot_09))
                  (>= 1 v_0_rx_slot_10)
                  (or (not (>= v_0_rcv_buf 6)) (= 0 v_0_rx_slot_10))
                  (>= 1 v_0_rx_slot_11)
                  (or (not (>= v_0_rcv_buf 5)) (= 0 v_0_rx_slot_11))
                  (>= 1 v_0_rx_slot_12)
                  (or (not (>= v_0_rcv_buf 4)) (= 0 v_0_rx_slot_12))
                  (>= 1 v_0_rx_slot_13)
                  (or (not (>= v_0_rcv_buf 3)) (= 0 v_0_rx_slot_13))
                  (>= 1 v_0_rx_slot_14)
                  (or (not (>= v_0_rcv_buf 2)) (= 0 v_0_rx_slot_14))
                  (>= 1 v_0_rx_slot_15)
                  (or (not (>= v_0_rcv_buf 1)) (= 0 v_0_rx_slot_15))
                  (= 0 v_0_rx_slot_00)
                  a!676
                  (<= 0 v_0_rx_advance)
                  (>= 16 v_0_rx_advance)
                  (= v_0_rx_chunk v_0_rx_advance)
                  (<= 0 v_0_ack_delta)
                  (>= 4294967295 v_0_ack_delta)
                  true
                  (= v_0_snd_nxt a!680)
                  (not v_0_fin_sent)
                  (not v_0_fin_requested)
                  true
                  true
                  true
                  true
                  true
                  (not v_0_rx_fin_done)
                  (or (not v_0_rx_fin_pending) a!681)
                  (<= 0 v_0_rx_fin_offset)
                  (>= 15 v_0_rx_fin_offset)
                  (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset))
                  (or (not v_0_rx_fin_pending) (= v_0_rx_fin_seq a!683))
                  (or (not v_0_rx_fin_done) (= v_0_rcv_nxt a!685))
                  a!686
                  a!687
                  a!688
                  a!689
                  a!690
                  a!691
                  a!692
                  a!693
                  a!694
                  a!695
                  a!696
                  a!697
                  a!698
                  a!699
                  a!700
                  a!701
                  (<= 0.0 v_0_srtt_ms)
                  (<= 0.0 v_0_rttvar_ms)
                  (<= 0.0 v_0_rtt_error_ms)
                  (<= 0.0 v_0_rtt_previous_srtt)
                  (<= 0.0 v_0_rtt_previous_var)
                  (<= 0 v_0_rtt_start_ms)
                  (<= 0 v_0_rtt_last_ms)
                  (<= 0 v_0_rtt_samples)
                  (<= 1000 v_0_rto_base_ms)
                  (>= 60000 v_0_rto_base_ms)
                  (>= v_0_rto_ms v_0_rto_base_ms)
                  (>= 60000 v_0_rto_ms)
                  a!705
                  (= v_0_rtt_measured (<= 1 v_0_rtt_samples))
                  (or (not v_0_rtt_active) a!714)
                  (or v_0_rtt_active (= 0 v_0_rtt_remaining))
                  true
                  (or (not v_0_rtt_sample_used)
                      (and (not v_0_rtt_sample_was_ambiguous)
                           v_0_rtt_measured
                           a!715))
                  (<= 0 v_0_rtt_sample_at_ms)
                  (<= v_0_rtt_sample_at_ms now_0)
                  a!720
                  (<= 0 v_0_tx_time_00)
                  (<= v_0_tx_time_00 now_0)
                  (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00))
                  (<= 0 v_0_tx_time_01)
                  (<= v_0_tx_time_01 now_0)
                  (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))
                  (<= 0 v_0_tx_time_02)
                  (<= v_0_tx_time_02 now_0)
                  (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))
                  (<= 0 v_0_tx_time_03)
                  (<= v_0_tx_time_03 now_0)
                  (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))
                  (<= 0 v_0_tx_time_04)
                  (<= v_0_tx_time_04 now_0)
                  (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))
                  (<= 0 v_0_tx_time_05)
                  (<= v_0_tx_time_05 now_0)
                  (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))
                  (<= 0 v_0_tx_time_06)
                  (<= v_0_tx_time_06 now_0)
                  (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))
                  (<= 0 v_0_tx_time_07)
                  (<= v_0_tx_time_07 now_0)
                  (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))
                  (<= 0 v_0_tx_time_08)
                  (<= v_0_tx_time_08 now_0)
                  (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))
                  (<= 0 v_0_tx_time_09)
                  (<= v_0_tx_time_09 now_0)
                  (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))
                  (<= 0 v_0_tx_time_10)
                  (<= v_0_tx_time_10 now_0)
                  (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))
                  (<= 0 v_0_tx_time_11)
                  (<= v_0_tx_time_11 now_0)
                  (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))
                  (<= 0 v_0_tx_time_12)
                  (<= v_0_tx_time_12 now_0)
                  (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))
                  (<= 0 v_0_tx_time_13)
                  (<= v_0_tx_time_13 now_0)
                  (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))
                  (<= 0 v_0_tx_time_14)
                  (<= v_0_tx_time_14 now_0)
                  (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))
                  (<= 0 v_0_tx_time_15)
                  (<= v_0_tx_time_15 now_0)
                  (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))
                  (<= 0 v_0_tx_fin_time)
                  (<= v_0_tx_fin_time now_0)
                  (<= 0 v_0_tx_emit_count)
                  (>= 4 v_0_tx_emit_count)
                  (<= 0 v_0_tx_eligible)
                  (>= 4 v_0_tx_eligible)
                  (<= 0 v_0_tx_elapsed)
                  (<= 0 v_0_tx_max_previous)
                  (<= v_0_tx_max_previous now_0)
                  (<= 1000 v_0_tx_previous_rto)
                  (>= 60000 v_0_tx_previous_rto)
                  a!721
                  (or (not v_0_tx_retransmitted) (not v_0_tx_waiting))
                  (<= 0 v_0_tx_syn_time)
                  (<= v_0_tx_syn_time now_0)
                  (not v_0_tx_syn_pending)
                  (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time))
                  true
                  (<= 1 v_0_ack_delay_ms)
                  (>= 499 v_0_ack_delay_ms)
                  (= 4 v_0_ack_rmss)
                  (= v_0_ack_pending active_0_delack)
                  (<= 0 v_0_ack_bytes)
                  (>= 7 v_0_ack_bytes)
                  (<= 0 v_0_ack_full_segments)
                  (>= 1 v_0_ack_full_segments)
                  (<= 0 v_0_ack_since_ms)
                  (<= v_0_ack_since_ms now_0)
                  (or (not v_0_ack_pending)
                      (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))
                  a!722
                  (= v_0_persist_active active_0_persist)
                  (= active_0_rtx a!723)
                  a!724
                  (or (not v_0_persist_active)
                      (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))
                  (<= 1000 v_0_persist_interval_ms)
                  (>= 60000 v_0_persist_interval_ms)
                  (<= 1000 v_0_persist_previous_interval_ms)
                  (>= 60000 v_0_persist_previous_interval_ms)
                  (<= 0 v_0_persist_probes)
                  (<= 0 v_0_persist_elapsed_ms)
                  (<= 0 v_0_persist_since_ms)
                  (<= v_0_persist_since_ms now_0)
                  (<= 0 v_0_persist_last_ms)
                  (<= v_0_persist_last_ms now_0)
                  (<= 0 v_0_persist_deadline_ms)
                  (or (not v_0_persist_active) a!725)
                  a!726
                  a!727
                  a!728
                  (<= 4 v_0_cc_initial_window)
                  (>= 16 v_0_cc_initial_window)
                  (<= 8 v_0_cc_initial_threshold)
                  (<= 4 v_0_cc_cwnd)
                  (<= 8 v_0_cc_ssthresh)
                  (<= 0 v_0_cc_ca_credit)
                  (not (>= v_0_cc_ca_credit v_0_cc_cwnd))
                  (<= 0 v_0_cc_growth)
                  (>= 4 v_0_cc_growth)
                  (<= 0 v_0_cc_acked)
                  (>= 16 v_0_cc_acked)
                  (<= 0 v_0_cc_threshold_updates)
                  (<= 0 v_0_cc_new_sent)
                  (<= v_0_cc_new_sent v_0_cc_send_budget)
                  (or (not v_0_cc_rto_00) (not (>= 0 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_01) (not (>= 1 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_02) (not (>= 2 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_03) (not (>= 3 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_04) (not (>= 4 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_05) (not (>= 5 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_06) (not (>= 6 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_07) (not (>= 7 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_08) (not (>= 8 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_09) (not (>= 9 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_10) (not (>= 10 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_11) (not (>= 11 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_12) (not (>= 12 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_13) (not (>= 13 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_14) (not (>= 14 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_15) (not (>= 15 v_0_rtx_buf)))
                  (<= 0 v_0_fr_dupacks)
                  (<= 0 v_0_fr_entries)
                  (<= 0 v_0_fr_emit_count)
                  (>= 4 v_0_fr_emit_count)
                  (<= 0 v_0_fr_last_window)
                  (>= 65535 v_0_fr_last_window)
                  a!729
                  a!730
                  a!731
                  (or v_0_fr_retransmitted (not v_0_fr_entered))
                  (or (not v_0_fr_entered)
                      (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))
                  a!732
                  (<= 0 v_0_idle_last_data_ms)
                  (<= v_0_idle_last_data_ms v_0_idle_event_ms)
                  (<= v_0_idle_event_ms now_0)
                  (<= 0 v_0_idle_elapsed_ms)
                  (<= 0 v_0_idle_restart_count)
                  (or (not v_0_idle_data_emitted)
                      (= v_0_idle_last_data_ms v_0_idle_event_ms))
                  (or (not v_0_idle_restart) a!733)
                  (<= 0 v_0_lt_epoch_bytes)
                  (>= 8 v_0_lt_epoch_bytes)
                  (<= v_0_lt_epoch_bytes v_0_rtx_buf)
                  (<= 0 v_0_lt_epoch_packets)
                  (>= 2 v_0_lt_epoch_packets)
                  (<= v_0_lt_epoch_packets v_0_fr_dupacks)
                  (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets)
                  (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets))
                  (<= 0 v_0_lt_loss_flight)
                  a!736
                  (or (not v_0_fr_entered) a!737)
                  (<= 0 v_0_choice_count)
                  (>= 4 v_0_choice_count)
                  (<= 0 v_0_choice_limit)
                  (>= 4 v_0_choice_limit)
                  a!740
                  (<= 0 v_0_sched_packets)
                  (<= v_0_sched_packets v_0_sched_bytes)
                  (<= v_0_sched_bytes (* 4 v_0_sched_packets))
                  (>= 16 (+ v_0_sched_bytes v_0_snd_buf))
                  (<= 0 v_0_sched_at_ms)
                  (<= v_0_sched_at_ms now_0)
                  (or (not v_0_sched_open)
                      (= 1 v_0_sched_cause)
                      (= 2 v_0_sched_cause))
                  (or (not v_0_choice_used)
                      (and v_0_sched_open (= v_0_sched_at_ms v_0_idle_event_ms)))
                  (<= 0 v_0_svc_written_bytes)
                  (<= 0 v_0_svc_acked_bytes)
                  (<= 0 v_0_svc_abandoned_bytes)
                  (= v_0_svc_written_bytes
                     (+ v_0_svc_acked_bytes
                        v_0_svc_abandoned_bytes
                        v_0_snd_buf
                        v_0_rtx_buf))
                  (= v_0_svc_ack_step v_0_cc_acked)
                  (<= 0 v_0_svc_accept_step)
                  (<= 0 v_0_svc_ack_step)
                  (<= 0 v_0_svc_drop_step)
                  (<= 0 v_0_cb_head)
                  (not (<= 16 v_0_cb_head))
                  (<= 0 v_0_cb_tail)
                  (not (<= 16 v_0_cb_tail))
                  (<= 0 v_0_cb_count)
                  (<= v_0_cb_count v_0_rtx_buf)
                  a!741
                  (<= 0 v_0_cb_new_count)
                  (>= 1 v_0_cb_new_count)
                  (<= 0 v_0_cb_emitted_total)
                  (<= 0 v_0_cb_acked_total)
                  (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix)
                      v_0_svc_acked_bytes)
                  (<= v_0_cb_emitted_total v_0_svc_written_bytes)
                  (<= 0 v_0_cb_abandoned_total)
                  (<= 0 v_0_cb_step_bytes)
                  (>= 19 v_0_cb_step_bytes)
                  (<= 0 v_0_cb_drop_step)
                  (= v_0_cb_emitted_total
                     (+ v_0_cb_acked_total
                        v_0_cb_abandoned_total
                        v_0_cb_live_total))
                  a!742
                  a!743
                  (<= 0 v_0_cb_partial_prefix)
                  (>= 3 v_0_cb_partial_prefix)
                  (<= (+ v_0_cb_emitted_total v_0_snd_buf)
                      v_0_svc_written_bytes)
                  (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00))
                      (>= a!378 v_0_cb_count))
                  (or (not (>= a!378 v_0_cb_count))
                      (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00)))
                  (or a!744 a!753)
                  (or a!754 (= v_0_cb_end_00 a!756))
                  (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01))
                      (>= a!389 v_0_cb_count))
                  (or (not (>= a!389 v_0_cb_count))
                      (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01)))
                  (or a!757 a!766)
                  (or a!767 (= v_0_cb_end_01 a!769))
                  (or (>= a!400 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)))
                  (or (not (>= a!400 v_0_cb_count))
                      (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02)))
                  (or a!770 a!779)
                  (or a!780 (= v_0_cb_end_02 a!782))
                  (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03))
                      (>= a!411 v_0_cb_count))
                  (or (not (>= a!411 v_0_cb_count))
                      (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03)))
                  (or a!783 a!792)
                  (or a!793 (= v_0_cb_end_03 a!795))
                  (or (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04))
                      (>= a!422 v_0_cb_count))
                  (or (not (>= a!422 v_0_cb_count))
                      (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04)))
                  (or a!796 a!805)
                  (or a!806 (= v_0_cb_end_04 a!808))
                  (or (>= a!433 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))
                  (or (not (>= a!433 v_0_cb_count))
                      (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05)))
                  (or a!809 a!818)
                  (or a!819 (= v_0_cb_end_05 a!821))
                  (or (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06))
                      (>= a!444 v_0_cb_count))
                  (or (not (>= a!444 v_0_cb_count))
                      (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06)))
                  (or a!822 a!831)
                  (or a!832 (= v_0_cb_end_06 a!834))
                  (or (>= a!455 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))
                  (or (not (>= a!455 v_0_cb_count))
                      (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07)))
                  (or a!835 a!844)
                  (or a!845 (= v_0_cb_end_07 a!847))
                  (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08))
                      (>= a!466 v_0_cb_count))
                  (or (not (>= a!466 v_0_cb_count))
                      (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08)))
                  (or a!848 a!857)
                  (or a!858 (= v_0_cb_end_08 a!860))
                  (or (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09))
                      (>= a!477 v_0_cb_count))
                  (or (not (>= a!477 v_0_cb_count))
                      (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09)))
                  (or a!861 a!870)
                  (or a!871 (= v_0_cb_end_09 a!873))
                  (or (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10))
                      (>= a!488 v_0_cb_count))
                  (or (not (>= a!488 v_0_cb_count))
                      (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10)))
                  (or a!874 a!883)
                  (or a!884 (= v_0_cb_end_10 a!886))
                  (or (>= a!499 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)))
                  (or (not (>= a!499 v_0_cb_count))
                      (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11)))
                  (or a!887 a!896)
                  (or a!897 (= v_0_cb_end_11 a!899))
                  (or (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12))
                      (>= a!510 v_0_cb_count))
                  (or (not (>= a!510 v_0_cb_count))
                      (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12)))
                  (or a!900 a!909)
                  (or a!910 (= v_0_cb_end_12 a!912))
                  (or (>= a!521 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)))
                  (or (not (>= a!521 v_0_cb_count))
                      (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13)))
                  (or a!913 a!922)
                  (or a!923 (= v_0_cb_end_13 a!925))
                  (or (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14))
                      (>= a!532 v_0_cb_count))
                  (or (not (>= a!532 v_0_cb_count))
                      (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14)))
                  (or a!926 a!935)
                  (or a!936 (= v_0_cb_end_14 a!938))
                  (or (>= a!543 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)))
                  (or (not (>= a!543 v_0_cb_count))
                      (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15)))
                  (or a!939 a!948)
                  (or a!949 (= v_0_cb_end_15 a!951))
                  (= 85 choice_0)
                  (= 4 state_0)
                  (= 4 state_1)
                  (or (not (<= 0 v_1_cb_partial_prefix)))))
      (a!1119 (and (>= v_0_snd_buf 0)
                   (>= v_0_rtx_buf 0)
                   (>= v_0_rcv_buf 0)
                   (>= v_0_rx_chunk 0)
                   (>= v_0_rx_slot_00 0)
                   (>= v_0_rx_slot_01 0)
                   (>= v_0_rx_slot_02 0)
                   (>= v_0_rx_slot_03 0)
                   (>= v_0_rx_slot_04 0)
                   (>= v_0_rx_slot_05 0)
                   (>= v_0_rx_slot_06 0)
                   (>= v_0_rx_slot_07 0)
                   (>= v_0_rx_slot_08 0)
                   (>= v_0_rx_slot_09 0)
                   (>= v_0_rx_slot_10 0)
                   (>= v_0_rx_slot_11 0)
                   (>= v_0_rx_slot_12 0)
                   (>= v_0_rx_slot_13 0)
                   (>= v_0_rx_slot_14 0)
                   (>= v_0_rx_slot_15 0)
                   (>= v_1_snd_buf 0)
                   (>= v_1_rtx_buf 0)
                   (>= v_1_rcv_buf 0)
                   (>= v_1_rx_chunk 0)
                   (>= v_1_rx_slot_00 0)
                   (>= v_1_rx_slot_01 0)
                   (>= v_1_rx_slot_02 0)
                   (>= v_1_rx_slot_03 0)
                   (>= v_1_rx_slot_04 0)
                   (>= v_1_rx_slot_05 0)
                   (>= v_1_rx_slot_06 0)
                   (>= v_1_rx_slot_07 0)
                   (>= v_1_rx_slot_08 0)
                   (>= v_1_rx_slot_09 0)
                   (>= v_1_rx_slot_10 0)
                   (>= v_1_rx_slot_11 0)
                   (>= v_1_rx_slot_12 0)
                   (>= v_1_rx_slot_13 0)
                   (>= v_1_rx_slot_14 0)
                   (>= v_1_rx_slot_15 0)
                   (>= v_0_iss 0)
                   (not (<= 4294967296 v_0_iss))
                   (>= v_0_irs 0)
                   (not (<= 4294967296 v_0_irs))
                   (>= v_0_snd_una 0)
                   (not (<= 4294967296 v_0_snd_una))
                   (>= v_0_snd_nxt 0)
                   (not (<= 4294967296 v_0_snd_nxt))
                   (>= v_0_rcv_nxt 0)
                   (not (<= 4294967296 v_0_rcv_nxt))
                   (>= v_0_tx_seq 0)
                   (not (<= 4294967296 v_0_tx_seq))
                   (>= v_0_tx_ack 0)
                   (not (<= 4294967296 v_0_tx_ack))
                   (>= v_0_snd_wl1 0)
                   (not (<= 4294967296 v_0_snd_wl1))
                   (>= v_0_snd_wl2 0)
                   (not (<= 4294967296 v_0_snd_wl2))
                   (>= v_0_fin_seq 0)
                   (not (<= 4294967296 v_0_fin_seq))
                   (>= v_0_rx_fin_seq 0)
                   (not (<= 4294967296 v_0_rx_fin_seq))
                   (>= v_0_rtt_end 0)
                   (not (<= 4294967296 v_0_rtt_end))
                   (>= v_0_cc_before_una 0)
                   (not (<= 4294967296 v_0_cc_before_una))
                   (>= v_0_fr_before_una 0)
                   (not (<= 4294967296 v_0_fr_before_una))
                   (>= v_0_fr_before_nxt 0)
                   (not (<= 4294967296 v_0_fr_before_nxt))
                   (>= v_0_lt_before_nxt 0)
                   (not (<= 4294967296 v_0_lt_before_nxt))
                   (>= v_0_choice_before_nxt 0)
                   (not (<= 4294967296 v_0_choice_before_nxt))
                   (>= v_0_cb_before_nxt 0)
                   (not (<= 4294967296 v_0_cb_before_nxt))
                   (>= v_0_cb_append_end 0)
                   (not (<= 4294967296 v_0_cb_append_end))
                   (>= v_0_cb_end_00 0)
                   (not (<= 4294967296 v_0_cb_end_00))
                   (>= v_0_cb_end_01 0)
                   (not (<= 4294967296 v_0_cb_end_01))
                   (>= v_0_cb_end_02 0)
                   (not (<= 4294967296 v_0_cb_end_02))
                   (>= v_0_cb_end_03 0)
                   (not (<= 4294967296 v_0_cb_end_03))
                   (>= v_0_cb_end_04 0)
                   (not (<= 4294967296 v_0_cb_end_04))
                   (>= v_0_cb_end_05 0)
                   (not (<= 4294967296 v_0_cb_end_05))
                   (>= v_0_cb_end_06 0)
                   (not (<= 4294967296 v_0_cb_end_06))
                   (>= v_0_cb_end_07 0)
                   (not (<= 4294967296 v_0_cb_end_07))
                   (>= v_0_cb_end_08 0)
                   (not (<= 4294967296 v_0_cb_end_08))
                   (>= v_0_cb_end_09 0)
                   (not (<= 4294967296 v_0_cb_end_09))
                   (>= v_0_cb_end_10 0)
                   (not (<= 4294967296 v_0_cb_end_10))
                   (>= v_0_cb_end_11 0)
                   (not (<= 4294967296 v_0_cb_end_11))
                   (>= v_0_cb_end_12 0)
                   (not (<= 4294967296 v_0_cb_end_12))
                   (>= v_0_cb_end_13 0)
                   (not (<= 4294967296 v_0_cb_end_13))
                   (>= v_0_cb_end_14 0)
                   (not (<= 4294967296 v_0_cb_end_14))
                   (>= v_0_cb_end_15 0)
                   (not (<= 4294967296 v_0_cb_end_15))
                   (>= v_1_iss 0)
                   (not (<= 4294967296 v_1_iss))
                   (>= v_1_irs 0)
                   (not (<= 4294967296 v_1_irs))
                   (>= v_1_snd_una 0)
                   (not (<= 4294967296 v_1_snd_una))
                   (>= v_1_snd_nxt 0)
                   (not (<= 4294967296 v_1_snd_nxt))
                   (>= v_1_rcv_nxt 0)
                   (not (<= 4294967296 v_1_rcv_nxt))
                   (>= v_1_tx_seq 0)
                   (not (<= 4294967296 v_1_tx_seq))
                   (>= v_1_tx_ack 0)
                   (not (<= 4294967296 v_1_tx_ack))
                   (>= v_1_snd_wl1 0)
                   (not (<= 4294967296 v_1_snd_wl1))
                   (>= v_1_snd_wl2 0)
                   (not (<= 4294967296 v_1_snd_wl2))
                   (>= v_1_fin_seq 0)
                   (not (<= 4294967296 v_1_fin_seq))
                   (>= v_1_rx_fin_seq 0)
                   (not (<= 4294967296 v_1_rx_fin_seq))
                   (>= v_1_rtt_end 0)
                   (not (<= 4294967296 v_1_rtt_end))
                   (>= v_1_cc_before_una 0)
                   (not (<= 4294967296 v_1_cc_before_una))
                   (>= v_1_fr_before_una 0)
                   (not (<= 4294967296 v_1_fr_before_una))
                   (>= v_1_fr_before_nxt 0)
                   (not (<= 4294967296 v_1_fr_before_nxt))
                   (>= v_1_lt_before_nxt 0)
                   (not (<= 4294967296 v_1_lt_before_nxt))
                   (>= v_1_choice_before_nxt 0)
                   (not (<= 4294967296 v_1_choice_before_nxt))
                   (>= v_1_cb_before_nxt 0)
                   (not (<= 4294967296 v_1_cb_before_nxt))
                   (>= v_1_cb_append_end 0)
                   (not (<= 4294967296 v_1_cb_append_end))
                   (>= v_1_cb_end_00 0)
                   (not (<= 4294967296 v_1_cb_end_00))
                   (>= v_1_cb_end_01 0)
                   (not (<= 4294967296 v_1_cb_end_01))
                   (>= v_1_cb_end_02 0)
                   (not (<= 4294967296 v_1_cb_end_02))
                   (>= v_1_cb_end_03 0)
                   (not (<= 4294967296 v_1_cb_end_03))
                   (>= v_1_cb_end_04 0)
                   (not (<= 4294967296 v_1_cb_end_04))
                   (>= v_1_cb_end_05 0)
                   (not (<= 4294967296 v_1_cb_end_05))
                   (>= v_1_cb_end_06 0)
                   (not (<= 4294967296 v_1_cb_end_06))
                   (>= v_1_cb_end_07 0)
                   (not (<= 4294967296 v_1_cb_end_07))
                   (>= v_1_cb_end_08 0)
                   (not (<= 4294967296 v_1_cb_end_08))
                   (>= v_1_cb_end_09 0)
                   (not (<= 4294967296 v_1_cb_end_09))
                   (>= v_1_cb_end_10 0)
                   (not (<= 4294967296 v_1_cb_end_10))
                   (>= v_1_cb_end_11 0)
                   (not (<= 4294967296 v_1_cb_end_11))
                   (>= v_1_cb_end_12 0)
                   (not (<= 4294967296 v_1_cb_end_12))
                   (>= v_1_cb_end_13 0)
                   (not (<= 4294967296 v_1_cb_end_13))
                   (>= v_1_cb_end_14 0)
                   (not (<= 4294967296 v_1_cb_end_14))
                   (>= v_1_cb_end_15 0)
                   (not (<= 4294967296 v_1_cb_end_15))
                   true
                   true
                   (>= now_0 0)
                   (or (not active_0_rtx) (>= due_0_rtx now_0))
                   (or (not active_0_user) (>= due_0_user now_0))
                   (or (not active_0_time_wait) (>= due_0_time_wait now_0))
                   (or (not active_0_delack) (>= due_0_delack now_0))
                   (or (not active_0_persist) (>= due_0_persist now_0))
                   (>= input_0_app.send_data 0)
                   (>= input_0_net.data_data 0)
                   (>= input_0_net.fin_segment_data 0)
                   (>= input_0_net.syn_seq 0)
                   (not (<= 4294967296 input_0_net.syn_seq))
                   (>= input_0_net.synack_seq 0)
                   (not (<= 4294967296 input_0_net.synack_seq))
                   (>= input_0_net.synack_ack 0)
                   (not (<= 4294967296 input_0_net.synack_ack))
                   (>= input_0_net.ack_seq 0)
                   (not (<= 4294967296 input_0_net.ack_seq))
                   (>= input_0_net.ack_ack 0)
                   (not (<= 4294967296 input_0_net.ack_ack))
                   (>= input_0_net.fin_seq 0)
                   (not (<= 4294967296 input_0_net.fin_seq))
                   (>= input_0_net.fin_ack 0)
                   (not (<= 4294967296 input_0_net.fin_ack))
                   (>= input_0_net.rst_seq 0)
                   (not (<= 4294967296 input_0_net.rst_seq))
                   (>= input_0_net.rstack_seq 0)
                   (not (<= 4294967296 input_0_net.rstack_seq))
                   (>= input_0_net.rstack_ack 0)
                   (not (<= 4294967296 input_0_net.rstack_ack))
                   (>= input_0_net.data_seq 0)
                   (not (<= 4294967296 input_0_net.data_seq))
                   (>= input_0_net.data_ack 0)
                   (not (<= 4294967296 input_0_net.data_ack))
                   (>= input_0_net.fin_segment_seq 0)
                   (not (<= 4294967296 input_0_net.fin_segment_seq))
                   (>= input_0_net.fin_segment_ack 0)
                   (not (<= 4294967296 input_0_net.fin_segment_ack))
                   (>= now_1 now_0)
                   (<= 0 input_0_net.ack_window)
                   (>= 65535 input_0_net.ack_window)
                   a!9
                   (or (and (= 0 v_0_local_window)
                            (= input_0_net.ack_seq v_0_rcv_nxt))
                       a!18)
                   a!27
                   a!36
                   (not a!37)
                   (or (not active_0_rtx) (not (<= due_0_rtx now_1)))
                   (or (not active_0_user) (not (<= due_0_user now_1)))
                   (or (not active_0_time_wait)
                       (not (<= due_0_time_wait now_1)))
                   (or (not active_0_delack) (not (<= due_0_delack now_1)))
                   (or (not active_0_persist) (not (<= due_0_persist now_1)))
                   (= v_1_iss v_0_iss)
                   (= v_1_irs v_0_irs)
                   (= v_1_snd_una (ite a!40 input_0_net.ack_ack v_0_snd_una))
                   (= v_1_snd_nxt (ite a!110 a!116 v_0_snd_nxt))
                   (= v_1_rcv_nxt v_0_rcv_nxt)
                   (= v_1_tx_seq v_0_tx_seq)
                   (= v_1_tx_ack v_0_tx_ack)
                   (= v_1_tx_flags v_0_tx_flags)
                   a!117
                   (= v_1_retries v_0_retries)
                   (= v_1_active_open v_0_active_open)
                   (= v_1_user_timeout_ms v_0_user_timeout_ms)
                   (= v_1_msl_ms v_0_msl_ms)
                   (= v_1_local_window v_0_local_window)
                   (= v_1_snd_buf (ite a!110 a!121 v_0_snd_buf))
                   (= v_1_rtx_buf a!123)
                   (= v_1_rcv_buf v_0_rcv_buf)
                   (= v_1_snd_wnd (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                   (= v_1_snd_wl1 (ite a!60 input_0_net.ack_seq v_0_snd_wl1))
                   (= v_1_snd_wl2 (ite a!60 input_0_net.ack_ack v_0_snd_wl2))
                   a!124
                   (= v_1_rx_chunk v_0_rx_chunk)
                   (= v_1_rx_slot_00 v_0_rx_slot_00)
                   (= v_1_rx_slot_01 v_0_rx_slot_01)
                   (= v_1_rx_slot_02 v_0_rx_slot_02)
                   (= v_1_rx_slot_03 v_0_rx_slot_03)
                   (= v_1_rx_slot_04 v_0_rx_slot_04)
                   (= v_1_rx_slot_05 v_0_rx_slot_05)
                   (= v_1_rx_slot_06 v_0_rx_slot_06)
                   (= v_1_rx_slot_07 v_0_rx_slot_07)
                   (= v_1_rx_slot_08 v_0_rx_slot_08)
                   (= v_1_rx_slot_09 v_0_rx_slot_09)
                   (= v_1_rx_slot_10 v_0_rx_slot_10)
                   (= v_1_rx_slot_11 v_0_rx_slot_11)
                   (= v_1_rx_slot_12 v_0_rx_slot_12)
                   (= v_1_rx_slot_13 v_0_rx_slot_13)
                   (= v_1_rx_slot_14 v_0_rx_slot_14)
                   (= v_1_rx_slot_15 v_0_rx_slot_15)
                   (= v_1_rx_advance v_0_rx_advance)
                   (= v_1_rx_acceptable v_0_rx_acceptable)
                   a!125
                   a!126
                   (= v_1_ack_is_new (and a!38 a!39))
                   (= v_1_ack_is_future a!37)
                   (= v_1_ack_advance a!40)
                   (= v_1_ack_window_update a!60)
                   (= v_1_fin_requested v_0_fin_requested)
                   (= v_1_fin_sent v_0_fin_sent)
                   (= v_1_fin_seq v_0_fin_seq)
                   (= v_1_fin_acknowledged v_0_fin_acknowledged)
                   (= v_1_rx_fin_pending v_0_rx_fin_pending)
                   (= v_1_rx_fin_seq v_0_rx_fin_seq)
                   (= v_1_rx_fin_offset v_0_rx_fin_offset)
                   (= v_1_rx_fin_done v_0_rx_fin_done)
                   (= v_1_rx_fin_consumed v_0_rx_fin_consumed)
                   (= v_1_srtt_ms (ite a!100 a!102 v_0_srtt_ms))
                   (= v_1_rttvar_ms (ite a!100 a!105 v_0_rttvar_ms))
                   (= v_1_rtt_error_ms (ite a!100 a!104 v_0_rtt_error_ms))
                   (= v_1_rtt_previous_srtt
                      (ite a!100 v_0_srtt_ms v_0_rtt_previous_srtt))
                   (= v_1_rtt_previous_var
                      (ite a!100 v_0_rttvar_ms v_0_rtt_previous_var))
                   (= v_1_rtt_measured (or v_0_rtt_measured a!100))
                   (= v_1_rtt_previous_measured
                      (ite a!100 v_0_rtt_measured v_0_rtt_previous_measured))
                   a!128
                   a!144
                   (= v_1_rtt_sample_at_ms
                      (ite a!100 now_1 v_0_rtt_sample_at_ms))
                   (= v_1_rtt_start_ms (ite a!143 now_1 v_0_rtt_start_ms))
                   (= v_1_rtt_end (ite a!143 a!146 v_0_rtt_end))
                   a!147
                   (= v_1_rtt_start_new a!143)
                   (= v_1_rtt_sample_used a!100)
                   (= v_1_rtt_sample_was_ambiguous
                      (and v_0_rtt_active v_0_rtt_ambiguous))
                   (= v_1_rtt_last_ms a!101)
                   (= v_1_rtt_samples (+ v_0_rtt_samples (ite a!100 1 0)))
                   a!148
                   (= v_1_tx_time_00 (ite a!153 now_1 a!174))
                   (= v_1_tx_time_01 (ite a!177 now_1 a!181))
                   (= v_1_tx_time_02 a!188)
                   (= v_1_tx_time_03 a!195)
                   (= v_1_tx_time_04 a!202)
                   (= v_1_tx_time_05 (ite a!205 now_1 a!208))
                   (= v_1_tx_time_06 a!214)
                   (= v_1_tx_time_07 a!220)
                   (= v_1_tx_time_08 a!226)
                   (= v_1_tx_time_09 (ite a!229 now_1 a!231))
                   (= v_1_tx_time_10 a!236)
                   (= v_1_tx_time_11 a!241)
                   (= v_1_tx_time_12 a!246)
                   (= v_1_tx_time_13 (ite a!249 now_1 a!250))
                   (= v_1_tx_time_14 a!254)
                   (= v_1_tx_time_15 (ite a!257 now_1 a!258))
                   a!259
                   (= v_1_tx_emit_count v_0_tx_emit_count)
                   (= v_1_tx_eligible v_0_tx_eligible)
                   (= v_1_tx_max_previous v_0_tx_max_previous)
                   (not v_1_tx_retransmitted)
                   (= v_1_tx_elapsed v_0_tx_elapsed)
                   (= v_1_tx_previous_rto v_0_tx_previous_rto)
                   (= v_1_tx_is_fin v_0_tx_is_fin)
                   (not v_1_tx_waiting)
                   (= v_1_tx_syn_time 0)
                   (not v_1_tx_syn_pending)
                   (not v_1_syn_timeout_eligible)
                   (= v_1_ack_pending
                      (and (not a!110) (not a!84) v_0_ack_pending))
                   (= v_1_ack_since_ms (ite (or a!110 a!84) 0 v_0_ack_since_ms))
                   (= v_1_ack_bytes (ite (or a!110 a!84) 0 v_0_ack_bytes))
                   (= v_1_ack_full_segments
                      (ite (or a!110 a!84) 0 v_0_ack_full_segments))
                   (= v_1_ack_delay_ms v_0_ack_delay_ms)
                   (= v_1_ack_rmss v_0_ack_rmss)
                   (not v_1_ack_defer_candidate)
                   (not v_1_ack_defer_now)
                   (= v_1_persist_active a!64)
                   (= v_1_persist_eligible a!64)
                   (= v_1_persist_start a!260)
                   (= v_1_persist_was_active v_0_persist_active)
                   (not v_1_persist_first)
                   (not v_1_persist_probe_sent)
                   (not v_1_persist_probe_new)
                   (= v_1_persist_interval_ms (ite a!64 a!261 1000))
                   (= v_1_persist_previous_interval_ms
                      v_0_persist_previous_interval_ms)
                   (= v_1_persist_since_ms
                      (ite a!64 (ite a!260 now_1 v_0_persist_since_ms) 0))
                   (= v_1_persist_last_ms (ite a!64 v_0_persist_last_ms 0))
                   a!262
                   (= v_1_persist_probes (ite a!64 v_0_persist_probes 0))
                   (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)
                   (= v_1_cc_initial_window v_0_cc_initial_window)
                   (= v_1_cc_initial_threshold v_0_cc_initial_threshold)
                   a!263
                   (= v_1_cc_ssthresh (ite a!70 a!76 v_0_cc_ssthresh))
                   (= v_1_cc_ca_credit a!265)
                   (= v_1_cc_acked a!78)
                   (= v_1_cc_before_flight v_0_rtx_buf)
                   (= v_1_cc_before_una v_0_snd_una)
                   (= v_1_cc_before_persist v_0_persist_active)
                   (= v_1_cc_before_window v_0_snd_wnd)
                   (not v_1_cc_loss)
                   (not v_1_cc_threshold_changed)
                   (= v_1_cc_threshold_updates v_0_cc_threshold_updates)
                   (= v_1_cc_growth (ite a!79 0 a!80))
                   (= v_1_cc_before_cwnd v_0_cc_cwnd)
                   (= v_1_cc_send_budget (ite (<= 0 a!266) a!266 0))
                   (= 0 v_1_cc_new_sent)
                   (= v_1_cc_rto_00 a!302)
                   (= v_1_cc_rto_01 a!308)
                   (= v_1_cc_rto_02 a!314)
                   (= v_1_cc_rto_03 a!319)
                   (= v_1_cc_rto_04 a!324)
                   (= v_1_cc_rto_05 a!329)
                   (= v_1_cc_rto_06 a!334)
                   (= v_1_cc_rto_07 a!338)
                   (= v_1_cc_rto_08 a!342)
                   (= v_1_cc_rto_09 a!346)
                   (= v_1_cc_rto_10 a!350)
                   (= v_1_cc_rto_11 a!353)
                   (= v_1_cc_rto_12 a!356)
                   (= v_1_cc_rto_13 a!359)
                   (= v_1_cc_rto_14 a!362)
                   (= v_1_cc_rto_15 a!363)
                   (not v_1_fr_window_ignored)
                   (= v_1_fr_before_wire_window v_0_fr_last_window)
                   (= v_1_fr_before_window_valid v_0_fr_window_valid)
                   (= v_1_fr_active a!72)
                   a!364
                   v_1_fr_window_valid
                   (= v_1_fr_last_window input_0_net.ack_window)
                   (= v_1_fr_was_active v_0_fr_active)
                   (= v_1_fr_before_una v_0_snd_una)
                   (= v_1_fr_before_nxt v_0_snd_nxt)
                   (= v_1_fr_before_flight v_0_rtx_buf)
                   (= v_1_fr_before_rto v_0_rto_ms)
                   (= v_1_fr_before_retries v_0_retries)
                   (= v_1_fr_duplicate a!66)
                   (= v_1_fr_entered a!70)
                   (= v_1_fr_extra a!77)
                   (= v_1_fr_exited a!71)
                   (= v_1_fr_retransmitted a!84)
                   a!365
                   (= v_1_fr_entries (+ v_0_fr_entries (ite a!70 1 0)))
                   (= v_1_idle_data_valid a!366)
                   (= v_1_idle_last_data_ms a!368)
                   (= v_1_idle_event_ms now_1)
                   (= v_1_idle_data_emitted a!369)
                   (not v_1_idle_restart)
                   (= v_1_idle_elapsed_ms a!370)
                   (= v_1_idle_before_cwnd v_0_cc_cwnd)
                   (= v_1_idle_before_rto v_0_rto_ms)
                   (= v_1_idle_before_threshold v_0_cc_ssthresh)
                   (= v_1_idle_restart_count v_0_idle_restart_count)
                   (= v_1_lt_eligible a!110)
                   (= v_1_lt_emitted a!110)
                   a!371
                   (= v_1_lt_epoch_bytes a!373)
                   a!374
                   (= v_1_lt_before_bytes v_0_lt_epoch_bytes)
                   (= v_1_lt_before_cwnd v_0_cc_cwnd)
                   (= v_1_lt_before_nxt v_0_snd_nxt)
                   (= v_1_lt_before_flight v_0_rtx_buf)
                   (= v_1_lt_before_window v_0_snd_wnd)
                   a!375
                   (not v_1_choice_used)
                   (= v_1_choice_count v_0_choice_count)
                   (= v_1_choice_limit v_0_choice_limit)
                   (= v_1_choice_before_nxt v_0_choice_before_nxt)
                   (= v_1_choice_before_flight v_0_choice_before_flight)
                   v_1_sched_open
                   (= v_1_sched_at_ms now_1)
                   (= 2 v_1_sched_cause)
                   (= 0 v_1_sched_bytes)
                   (= 0 v_1_sched_packets)
                   (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf))
                   (= 0 v_1_svc_accept_step)
                   (= v_1_svc_ack_step a!78)
                   (= v_1_svc_drop_step (ite (<= 0 a!376) a!376 0))
                   (= v_1_svc_written_bytes v_0_svc_written_bytes)
                   (= v_1_svc_acked_bytes (+ v_0_svc_acked_bytes a!78))
                   a!377
                   (= v_1_cb_head a!986)
                   a!560
                   (= v_1_cb_count (+ a!987 (ite a!557 1 0) (ite a!558 1 0)))
                   a!562
                   (= v_1_cb_append_length (ite a!558 a!122 (ite a!557 a!89 0)))
                   (= v_1_cb_retired_count
                      (+ a!954
                         a!956
                         a!958
                         a!960
                         a!962
                         a!964
                         a!966
                         a!968
                         a!970
                         a!972
                         a!974
                         a!976
                         a!978
                         a!980
                         a!982
                         a!984))
                   (= v_1_cb_step_bytes
                      (+ a!988
                         a!989
                         a!990
                         a!991
                         a!992
                         a!993
                         a!994
                         a!995
                         a!996
                         a!997
                         a!998
                         a!999
                         a!1000
                         a!1001
                         a!1002
                         a!1003))
                   (= v_1_cb_live_total
                      (+ a!1005
                         a!1007
                         a!1009
                         a!1011
                         a!1013
                         a!1015
                         a!1017
                         a!1019
                         a!1021
                         a!1023
                         a!1025
                         a!1027
                         a!1029
                         a!1031
                         a!1033
                         a!1035))
                   a!1036
                   a!615
                   (= v_1_cb_acked_total
                      (+ v_0_cb_acked_total
                         a!988
                         a!989
                         a!990
                         a!991
                         a!992
                         a!993
                         a!994
                         a!995
                         a!996
                         a!997
                         a!998
                         a!999
                         a!1000
                         a!1001
                         a!1002
                         a!1003))
                   (= v_1_cb_abandoned_total (+ v_0_cb_abandoned_total a!1053))
                   (= v_1_cb_drop_step a!1053)
                   (= v_1_cb_before_nxt v_0_snd_nxt)
                   (= v_1_cb_append_end (ite a!558 a!146 (ite a!557 a!636 0)))
                   (= v_1_cb_is_new a!558)
                   (= v_1_cb_length_00 a!1005)
                   a!1054
                   a!1055
                   (= v_1_cb_length_01 a!1007)
                   a!1056
                   a!1057
                   (= v_1_cb_length_02 a!1009)
                   a!1058
                   a!1059
                   (= v_1_cb_length_03 a!1011)
                   a!1060
                   a!1061
                   (= v_1_cb_length_04 a!1013)
                   a!1062
                   a!1063
                   (= v_1_cb_length_05 a!1015)
                   a!1064
                   a!1065
                   (= v_1_cb_length_06 a!1017)
                   a!1066
                   a!1067
                   (= v_1_cb_length_07 a!1019)
                   a!1068
                   a!1069
                   (= v_1_cb_length_08 a!1021)
                   a!1070
                   a!1071
                   (= v_1_cb_length_09 a!1023)
                   a!1072
                   a!1073
                   (= v_1_cb_length_10 a!1025)
                   a!1074
                   a!1075
                   (= v_1_cb_length_11 a!1027)
                   a!1076
                   a!1077
                   (= v_1_cb_length_12 a!1029)
                   a!1078
                   a!1079
                   (= v_1_cb_length_13 a!1031)
                   a!1080
                   a!1081
                   (= v_1_cb_length_14 a!1033)
                   a!1082
                   a!1083
                   (= v_1_cb_length_15 a!1035)
                   a!1084
                   a!1085
                   (= active_1_rtx (or a!671 a!672))
                   (= active_1_user active_0_user)
                   (= active_1_time_wait active_0_time_wait)
                   (= active_1_delack
                      (and (not a!110) (not a!84) active_0_delack))
                   (= active_1_persist a!673)
                   a!674
                   (= due_1_user due_0_user)
                   (= due_1_time_wait due_0_time_wait)
                   (= due_1_delack due_0_delack)
                   (= due_1_persist (ite a!260 (+ now_1 a!261) due_0_persist))
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   (not active_0_user)
                   (not active_0_time_wait)
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   true
                   (<= 1000 v_0_rto_ms)
                   (<= 0 v_0_retries)
                   (<= 1 v_0_msl_ms)
                   (<= 1 v_0_user_timeout_ms)
                   true
                   (>= 16 (+ v_0_snd_buf v_0_rtx_buf))
                   (>= 16 v_0_rcv_buf)
                   (<= 0 v_0_snd_wnd)
                   (>= 65535 v_0_snd_wnd)
                   a!675
                   (>= 1 v_0_rx_slot_00)
                   (or (not (>= v_0_rcv_buf 16)) (= 0 v_0_rx_slot_00))
                   (>= 1 v_0_rx_slot_01)
                   (or (not (>= v_0_rcv_buf 15)) (= 0 v_0_rx_slot_01))
                   (>= 1 v_0_rx_slot_02)
                   (or (not (>= v_0_rcv_buf 14)) (= 0 v_0_rx_slot_02))
                   (>= 1 v_0_rx_slot_03)
                   (or (not (>= v_0_rcv_buf 13)) (= 0 v_0_rx_slot_03))
                   (>= 1 v_0_rx_slot_04)
                   (or (not (>= v_0_rcv_buf 12)) (= 0 v_0_rx_slot_04))
                   (>= 1 v_0_rx_slot_05)
                   (or (not (>= v_0_rcv_buf 11)) (= 0 v_0_rx_slot_05))
                   (>= 1 v_0_rx_slot_06)
                   (or (not (>= v_0_rcv_buf 10)) (= 0 v_0_rx_slot_06))
                   (>= 1 v_0_rx_slot_07)
                   (or (not (>= v_0_rcv_buf 9)) (= 0 v_0_rx_slot_07))
                   (>= 1 v_0_rx_slot_08)
                   (or (not (>= v_0_rcv_buf 8)) (= 0 v_0_rx_slot_08))
                   (>= 1 v_0_rx_slot_09)
                   (or (not (>= v_0_rcv_buf 7)) (= 0 v_0_rx_slot_09))
                   (>= 1 v_0_rx_slot_10)
                   (or (not (>= v_0_rcv_buf 6)) (= 0 v_0_rx_slot_10))
                   (>= 1 v_0_rx_slot_11)
                   (or (not (>= v_0_rcv_buf 5)) (= 0 v_0_rx_slot_11))
                   (>= 1 v_0_rx_slot_12)
                   (or (not (>= v_0_rcv_buf 4)) (= 0 v_0_rx_slot_12))
                   (>= 1 v_0_rx_slot_13)
                   (or (not (>= v_0_rcv_buf 3)) (= 0 v_0_rx_slot_13))
                   (>= 1 v_0_rx_slot_14)
                   (or (not (>= v_0_rcv_buf 2)) (= 0 v_0_rx_slot_14))
                   (>= 1 v_0_rx_slot_15)
                   (or (not (>= v_0_rcv_buf 1)) (= 0 v_0_rx_slot_15))
                   (= 0 v_0_rx_slot_00)
                   a!676
                   (<= 0 v_0_rx_advance)
                   (>= 16 v_0_rx_advance)
                   (= v_0_rx_chunk v_0_rx_advance)
                   (<= 0 v_0_ack_delta)
                   (>= 4294967295 v_0_ack_delta)
                   true
                   (= v_0_snd_nxt a!680)
                   (not v_0_fin_sent)
                   (not v_0_fin_requested)
                   true
                   true
                   true
                   true
                   true
                   (not v_0_rx_fin_done)
                   (or (not v_0_rx_fin_pending) a!681)
                   (<= 0 v_0_rx_fin_offset)
                   (>= 15 v_0_rx_fin_offset)
                   (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset))
                   (or (not v_0_rx_fin_pending) (= v_0_rx_fin_seq a!683))
                   (or (not v_0_rx_fin_done) (= v_0_rcv_nxt a!685))
                   a!686
                   a!687
                   a!688
                   a!689
                   a!690
                   a!691
                   a!692
                   a!693
                   a!694
                   a!695
                   a!696
                   a!697
                   a!698
                   a!699
                   a!700
                   a!701
                   (<= 0.0 v_0_srtt_ms)
                   (<= 0.0 v_0_rttvar_ms)
                   (<= 0.0 v_0_rtt_error_ms)
                   (<= 0.0 v_0_rtt_previous_srtt)
                   (<= 0.0 v_0_rtt_previous_var)
                   (<= 0 v_0_rtt_start_ms)
                   (<= 0 v_0_rtt_last_ms)
                   (<= 0 v_0_rtt_samples)
                   (<= 1000 v_0_rto_base_ms)
                   (>= 60000 v_0_rto_base_ms)
                   (>= v_0_rto_ms v_0_rto_base_ms)
                   (>= 60000 v_0_rto_ms)
                   a!705
                   (= v_0_rtt_measured (<= 1 v_0_rtt_samples))
                   (or (not v_0_rtt_active) a!714)
                   (or v_0_rtt_active (= 0 v_0_rtt_remaining))
                   true
                   (or (not v_0_rtt_sample_used)
                       (and (not v_0_rtt_sample_was_ambiguous)
                            v_0_rtt_measured
                            a!715))
                   (<= 0 v_0_rtt_sample_at_ms)
                   (<= v_0_rtt_sample_at_ms now_0)
                   a!720
                   (<= 0 v_0_tx_time_00)
                   (<= v_0_tx_time_00 now_0)
                   (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00))
                   (<= 0 v_0_tx_time_01)
                   (<= v_0_tx_time_01 now_0)
                   (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))
                   (<= 0 v_0_tx_time_02)
                   (<= v_0_tx_time_02 now_0)
                   (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))
                   (<= 0 v_0_tx_time_03)
                   (<= v_0_tx_time_03 now_0)
                   (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))
                   (<= 0 v_0_tx_time_04)
                   (<= v_0_tx_time_04 now_0)
                   (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))
                   (<= 0 v_0_tx_time_05)
                   (<= v_0_tx_time_05 now_0)
                   (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))
                   (<= 0 v_0_tx_time_06)
                   (<= v_0_tx_time_06 now_0)
                   (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))
                   (<= 0 v_0_tx_time_07)
                   (<= v_0_tx_time_07 now_0)
                   (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))
                   (<= 0 v_0_tx_time_08)
                   (<= v_0_tx_time_08 now_0)
                   (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))
                   (<= 0 v_0_tx_time_09)
                   (<= v_0_tx_time_09 now_0)
                   (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))
                   (<= 0 v_0_tx_time_10)
                   (<= v_0_tx_time_10 now_0)
                   (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))
                   (<= 0 v_0_tx_time_11)
                   (<= v_0_tx_time_11 now_0)
                   (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))
                   (<= 0 v_0_tx_time_12)
                   (<= v_0_tx_time_12 now_0)
                   (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))
                   (<= 0 v_0_tx_time_13)
                   (<= v_0_tx_time_13 now_0)
                   (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))
                   (<= 0 v_0_tx_time_14)
                   (<= v_0_tx_time_14 now_0)
                   (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))
                   (<= 0 v_0_tx_time_15)
                   (<= v_0_tx_time_15 now_0)
                   (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))
                   (<= 0 v_0_tx_fin_time)
                   (<= v_0_tx_fin_time now_0)
                   (<= 0 v_0_tx_emit_count)
                   (>= 4 v_0_tx_emit_count)
                   (<= 0 v_0_tx_eligible)
                   (>= 4 v_0_tx_eligible)
                   (<= 0 v_0_tx_elapsed)
                   (<= 0 v_0_tx_max_previous)
                   (<= v_0_tx_max_previous now_0)
                   (<= 1000 v_0_tx_previous_rto)
                   (>= 60000 v_0_tx_previous_rto)
                   a!721
                   (or (not v_0_tx_retransmitted) (not v_0_tx_waiting))
                   (<= 0 v_0_tx_syn_time)
                   (<= v_0_tx_syn_time now_0)
                   (not v_0_tx_syn_pending)
                   (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time))
                   true
                   (<= 1 v_0_ack_delay_ms)
                   (>= 499 v_0_ack_delay_ms)
                   (= 4 v_0_ack_rmss)
                   (= v_0_ack_pending active_0_delack)
                   (<= 0 v_0_ack_bytes)
                   (>= 7 v_0_ack_bytes)
                   (<= 0 v_0_ack_full_segments)
                   (>= 1 v_0_ack_full_segments)
                   (<= 0 v_0_ack_since_ms)
                   (<= v_0_ack_since_ms now_0)
                   (or (not v_0_ack_pending)
                       (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))
                   a!722
                   (= v_0_persist_active active_0_persist)
                   (= active_0_rtx a!723)
                   a!724
                   (or (not v_0_persist_active)
                       (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))
                   (<= 1000 v_0_persist_interval_ms)
                   (>= 60000 v_0_persist_interval_ms)
                   (<= 1000 v_0_persist_previous_interval_ms)
                   (>= 60000 v_0_persist_previous_interval_ms)
                   (<= 0 v_0_persist_probes)
                   (<= 0 v_0_persist_elapsed_ms)
                   (<= 0 v_0_persist_since_ms)
                   (<= v_0_persist_since_ms now_0)
                   (<= 0 v_0_persist_last_ms)
                   (<= v_0_persist_last_ms now_0)
                   (<= 0 v_0_persist_deadline_ms)
                   (or (not v_0_persist_active) a!725)
                   a!726
                   a!727
                   a!728
                   (<= 4 v_0_cc_initial_window)
                   (>= 16 v_0_cc_initial_window)
                   (<= 8 v_0_cc_initial_threshold)
                   (<= 4 v_0_cc_cwnd)
                   (<= 8 v_0_cc_ssthresh)
                   (<= 0 v_0_cc_ca_credit)
                   (not (>= v_0_cc_ca_credit v_0_cc_cwnd))
                   (<= 0 v_0_cc_growth)
                   (>= 4 v_0_cc_growth)
                   (<= 0 v_0_cc_acked)
                   (>= 16 v_0_cc_acked)
                   (<= 0 v_0_cc_threshold_updates)
                   (<= 0 v_0_cc_new_sent)
                   (<= v_0_cc_new_sent v_0_cc_send_budget)
                   (or (not v_0_cc_rto_00) (not (>= 0 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_01) (not (>= 1 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_02) (not (>= 2 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_03) (not (>= 3 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_04) (not (>= 4 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_05) (not (>= 5 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_06) (not (>= 6 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_07) (not (>= 7 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_08) (not (>= 8 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_09) (not (>= 9 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_10) (not (>= 10 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_11) (not (>= 11 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_12) (not (>= 12 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_13) (not (>= 13 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_14) (not (>= 14 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_15) (not (>= 15 v_0_rtx_buf)))
                   (<= 0 v_0_fr_dupacks)
                   (<= 0 v_0_fr_entries)
                   (<= 0 v_0_fr_emit_count)
                   (>= 4 v_0_fr_emit_count)
                   (<= 0 v_0_fr_last_window)
                   (>= 65535 v_0_fr_last_window)
                   a!729
                   a!730
                   a!731
                   (or v_0_fr_retransmitted (not v_0_fr_entered))
                   (or (not v_0_fr_entered)
                       (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))
                   a!732
                   (<= 0 v_0_idle_last_data_ms)
                   (<= v_0_idle_last_data_ms v_0_idle_event_ms)
                   (<= v_0_idle_event_ms now_0)
                   (<= 0 v_0_idle_elapsed_ms)
                   (<= 0 v_0_idle_restart_count)
                   (or (not v_0_idle_data_emitted)
                       (= v_0_idle_last_data_ms v_0_idle_event_ms))
                   (or (not v_0_idle_restart) a!733)
                   (<= 0 v_0_lt_epoch_bytes)
                   (>= 8 v_0_lt_epoch_bytes)
                   (<= v_0_lt_epoch_bytes v_0_rtx_buf)
                   (<= 0 v_0_lt_epoch_packets)
                   (>= 2 v_0_lt_epoch_packets)
                   (<= v_0_lt_epoch_packets v_0_fr_dupacks)
                   (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets)
                   (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets))
                   (<= 0 v_0_lt_loss_flight)
                   a!736
                   (or (not v_0_fr_entered) a!737)
                   (<= 0 v_0_choice_count)
                   (>= 4 v_0_choice_count)
                   (<= 0 v_0_choice_limit)
                   (>= 4 v_0_choice_limit)
                   a!740
                   (<= 0 v_0_sched_packets)
                   (<= v_0_sched_packets v_0_sched_bytes)
                   (<= v_0_sched_bytes (* 4 v_0_sched_packets))
                   (>= 16 (+ v_0_sched_bytes v_0_snd_buf))
                   (<= 0 v_0_sched_at_ms)
                   (<= v_0_sched_at_ms now_0)
                   (or (not v_0_sched_open)
                       (= 1 v_0_sched_cause)
                       (= 2 v_0_sched_cause))
                   (or (not v_0_choice_used)
                       (and v_0_sched_open
                            (= v_0_sched_at_ms v_0_idle_event_ms)))
                   (<= 0 v_0_svc_written_bytes)
                   (<= 0 v_0_svc_acked_bytes)
                   (<= 0 v_0_svc_abandoned_bytes)
                   (= v_0_svc_written_bytes
                      (+ v_0_svc_acked_bytes
                         v_0_svc_abandoned_bytes
                         v_0_snd_buf
                         v_0_rtx_buf))
                   (= v_0_svc_ack_step v_0_cc_acked)
                   (<= 0 v_0_svc_accept_step)
                   (<= 0 v_0_svc_ack_step)
                   (<= 0 v_0_svc_drop_step)
                   (<= 0 15)
                   (not (<= 16 15))
                   (<= 0 v_0_cb_tail)
                   (not (<= 16 v_0_cb_tail))
                   (<= 0 v_0_cb_count)
                   (<= v_0_cb_count v_0_rtx_buf)
                   a!1086
                   (<= 0 v_0_cb_new_count)
                   (>= 1 v_0_cb_new_count)
                   (<= 0 v_0_cb_emitted_total)
                   (<= 0 v_0_cb_acked_total)
                   (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix)
                       v_0_svc_acked_bytes)
                   (<= v_0_cb_emitted_total v_0_svc_written_bytes)
                   (<= 0 v_0_cb_abandoned_total)
                   (<= 0 v_0_cb_step_bytes)
                   (>= 19 v_0_cb_step_bytes)
                   (<= 0 v_0_cb_drop_step)
                   (= v_0_cb_emitted_total
                      (+ v_0_cb_acked_total
                         v_0_cb_abandoned_total
                         v_0_cb_live_total))
                   a!742
                   a!743
                   (<= 0 v_0_cb_partial_prefix)
                   (>= 3 v_0_cb_partial_prefix)
                   (<= (+ v_0_cb_emitted_total v_0_snd_buf)
                       v_0_svc_written_bytes)
                   (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00))
                       (>= a!953 v_0_cb_count))
                   (or (not (>= a!953 v_0_cb_count))
                       (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00)))
                   (or a!1087 a!753)
                   (or a!1088 (= v_0_cb_end_00 a!756))
                   (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01))
                       (>= a!955 v_0_cb_count))
                   (or (not (>= a!955 v_0_cb_count))
                       (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01)))
                   (or a!1089 a!766)
                   (or a!1090 (= v_0_cb_end_01 a!769))
                   (or (>= a!957 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)))
                   (or (not (>= a!957 v_0_cb_count))
                       (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02)))
                   (or a!1091 a!779)
                   (or a!1092 (= v_0_cb_end_02 a!782))
                   (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03))
                       (>= a!959 v_0_cb_count))
                   (or (not (>= a!959 v_0_cb_count))
                       (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03)))
                   (or a!1093 a!792)
                   (or a!1094 (= v_0_cb_end_03 a!795))
                   (or (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04))
                       (>= a!961 v_0_cb_count))
                   (or (not (>= a!961 v_0_cb_count))
                       (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04)))
                   (or a!1095 a!805)
                   (or a!1096 (= v_0_cb_end_04 a!808))
                   (or (>= a!963 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))
                   (or (not (>= a!963 v_0_cb_count))
                       (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05)))
                   (or a!1097 a!818)
                   (or a!1098 (= v_0_cb_end_05 a!821))
                   (or (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06))
                       (>= a!965 v_0_cb_count))
                   (or (not (>= a!965 v_0_cb_count))
                       (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06)))
                   (or a!1099 a!831)
                   (or a!1100 (= v_0_cb_end_06 a!834))
                   (or (>= a!967 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))
                   (or (not (>= a!967 v_0_cb_count))
                       (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07)))
                   (or a!1101 a!844)
                   (or a!1102 (= v_0_cb_end_07 a!847))
                   (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08))
                       (>= a!969 v_0_cb_count))
                   (or (not (>= a!969 v_0_cb_count))
                       (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08)))
                   (or a!1103 a!857)
                   (or a!1104 (= v_0_cb_end_08 a!860))
                   (or (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09))
                       (>= a!971 v_0_cb_count))
                   (or (not (>= a!971 v_0_cb_count))
                       (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09)))
                   (or a!1105 a!870)
                   (or a!1106 (= v_0_cb_end_09 a!873))
                   (or (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10))
                       (>= a!973 v_0_cb_count))
                   (or (not (>= a!973 v_0_cb_count))
                       (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10)))
                   (or a!1107 a!883)
                   (or a!1108 (= v_0_cb_end_10 a!886))
                   (or (>= a!975 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)))
                   (or (not (>= a!975 v_0_cb_count))
                       (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11)))
                   (or a!1109 a!896)
                   (or a!1110 (= v_0_cb_end_11 a!899))
                   (or (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12))
                       (>= a!977 v_0_cb_count))
                   (or (not (>= a!977 v_0_cb_count))
                       (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12)))
                   (or a!1111 a!909)
                   (or a!1112 (= v_0_cb_end_12 a!912))
                   (or (>= a!979 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)))
                   (or (not (>= a!979 v_0_cb_count))
                       (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13)))
                   (or a!1113 a!922)
                   (or a!1114 (= v_0_cb_end_13 a!925))
                   (or (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14))
                       (>= a!981 v_0_cb_count))
                   (or (not (>= a!981 v_0_cb_count))
                       (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14)))
                   (or a!1115 a!935)
                   (or a!1116 (= v_0_cb_end_14 a!938))
                   (or (>= a!983 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)))
                   (or (not (>= a!983 v_0_cb_count))
                       (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15)))
                   (or a!1117 a!948)
                   (or a!1118 (= v_0_cb_end_15 a!951))
                   (= 85 choice_0)
                   (= 4 state_0)
                   (= 4 state_1)
                   (or (not (<= 0 v_1_cb_partial_prefix))))))
  (xor a!952 a!1119))))))))))))))))))))))))
(check-sat)

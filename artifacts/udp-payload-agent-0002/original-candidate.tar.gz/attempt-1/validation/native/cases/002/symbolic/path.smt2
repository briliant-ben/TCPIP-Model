; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_last_data () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_last_data () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun state_2 () Int)
(declare-fun v_3_last_data () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun state_3 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_last_data () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.datagram_source_port () Int)
(declare-fun input_0_net.datagram_destination_port () Int)
(declare-fun input_0_net.datagram_length () Int)
(declare-fun input_0_net.datagram_checksum () Int)
(declare-fun input_0_net.datagram_sum_valid () Bool)
(declare-fun input_0_net.datagram_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.datagram_source_port () Int)
(declare-fun input_1_net.datagram_destination_port () Int)
(declare-fun input_1_net.datagram_length () Int)
(declare-fun input_1_net.datagram_checksum () Int)
(declare-fun input_1_net.datagram_sum_valid () Bool)
(declare-fun input_1_net.datagram_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.datagram_source_port () Int)
(declare-fun input_2_net.datagram_destination_port () Int)
(declare-fun input_2_net.datagram_length () Int)
(declare-fun input_2_net.datagram_checksum () Int)
(declare-fun input_2_net.datagram_sum_valid () Bool)
(declare-fun input_2_net.datagram_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x184 (= v_1_last_data (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv8 8))))))
 (let (($x179 (= 0 state_1)))
 (let (($x194 (= state_0 0)))
 (and $x194 (>= 0 now_0) $x179 v_1_checksums_enabled $x184)))))
(assert
 true)
(assert
 (let (($x12 (= v_2_last_data v_1_last_data)))
 (let (($x76 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x22 (= 0 state_2)))
 (let (($x110 (= state_1 0)))
 (and $x110 $x22 $x76 $x12))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x45 (= v_3_last_data v_2_last_data)))
 (let (($x49 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x241 (= 0 state_3)))
 (let (($x147 (= state_2 0)))
 (and $x147 $x241 $x49 $x45))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_last_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 2 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 7000 input_0_net.datagram_source_port))
(assert
 (= 8080 input_0_net.datagram_destination_port))
(assert
 (= 10 input_0_net.datagram_length))
(assert
 (= 65535 input_0_net.datagram_checksum))
(assert
 (= input_0_net.datagram_sum_valid true))
(assert
 (let ((?x187 (seq.unit (_ bv7 8))))
 (let ((?x305 (seq.++ ?x187 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv99 8)) (seq.unit (_ bv100 8)))))))
 (= input_0_net.datagram_data ?x305))))
(assert
 (= 3 choice_1))
(assert
 (= 0 now_2))
(assert
 (= 7000 input_1_net.datagram_source_port))
(assert
 (= 8080 input_1_net.datagram_destination_port))
(assert
 (= 14 input_1_net.datagram_length))
(assert
 (= 1234 input_1_net.datagram_checksum))
(assert
 (= input_1_net.datagram_sum_valid true))
(assert
 (let ((?x187 (seq.unit (_ bv7 8))))
 (let ((?x36 (seq.++ ?x187 (seq.++ (seq.unit (_ bv8 8)) (seq.++ (seq.unit (_ bv9 8)) (seq.unit (_ bv10 8)))))))
 (= input_1_net.datagram_data ?x36))))
(assert
 (= 3 choice_2))
(assert
 (= 0 now_3))
(assert
 (= 7000 input_2_net.datagram_source_port))
(assert
 (= 8080 input_2_net.datagram_destination_port))
(assert
 (= 5 input_2_net.datagram_length))
(assert
 (= 1234 input_2_net.datagram_checksum))
(assert
 (= input_2_net.datagram_sum_valid true))
(assert
 (let ((?x326 (seq.unit (_ bv1 8))))
(= input_2_net.datagram_data ?x326)))
(check-sat)

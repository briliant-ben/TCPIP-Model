; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_last_data () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_last_data () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun state_2 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_last_data () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.configure_checksum_enabled () Bool)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_source_port () Int)
(declare-fun input_1_app.send_destination_port () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x226 (= (as seq.empty (Seq (_ BitVec 8))) v_1_last_data)))
 (let (($x271 (not v_1_checksums_enabled)))
 (let (($x280 (= 0 state_1)))
 (let (($x268 (= state_0 0)))
 (and $x268 (>= 0 now_0) $x280 $x271 $x226))))))
(assert
 true)
(assert
 (let (($x312 (= v_2_last_data v_1_last_data)))
 (let (($x263 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x95 (= 0 state_2)))
 (let (($x66 (= state_1 0)))
 (and $x66 $x95 $x263 $x312))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_last_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (= input_0_app.configure_checksum_enabled false))
(assert
 (= 1 choice_1))
(assert
 (= 0 now_2))
(assert
 (= 65535 input_1_app.send_source_port))
(assert
 (= 8080 input_1_app.send_destination_port))
(assert
 (let ((?x64 (seq.unit (_ bv1 8))))
(let ((?x274 (seq.++ ?x64 (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8))))))
(= input_1_app.send_data ?x274))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_last_data () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun state_1 () Int)
(declare-fun v_2_last_data () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun state_2 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_last_data () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.datagram_source_port () Int)
(declare-fun input_0_net.datagram_destination_port () Int)
(declare-fun input_0_net.datagram_length () Int)
(declare-fun input_0_net.datagram_checksum () Int)
(declare-fun input_0_net.datagram_sum_valid () Bool)
(declare-fun input_0_net.datagram_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.datagram_source_port () Int)
(declare-fun input_1_net.datagram_destination_port () Int)
(declare-fun input_1_net.datagram_length () Int)
(declare-fun input_1_net.datagram_checksum () Int)
(declare-fun input_1_net.datagram_sum_valid () Bool)
(declare-fun input_1_net.datagram_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x89 (= (as seq.empty (Seq (_ BitVec 8))) v_1_last_data)))
 (let (($x310 (= 0 state_1)))
 (let (($x244 (= state_0 0)))
 (and $x244 (>= 0 now_0) $x310 v_1_checksums_enabled $x89)))))
(assert
 true)
(assert
 (let ((?x227 (seq.unit (_ bv65 8))))
 (let (($x45 (= v_2_last_data ?x227)))
 (let (($x256 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x313 (= 0 state_2)))
 (let (($x97 (= state_1 0)))
 (and $x97 $x313 $x256 $x45)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_last_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 3 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 1111 input_0_net.datagram_source_port))
(assert
 (= 8080 input_0_net.datagram_destination_port))
(assert
 (= 9 input_0_net.datagram_length))
(assert
 (= 4242 input_0_net.datagram_checksum))
(assert
 (= input_0_net.datagram_sum_valid false))
(assert
 (let ((?x227 (seq.unit (_ bv65 8))))
 (= input_0_net.datagram_data ?x227)))
(assert
 (= 2 choice_1))
(assert
 (= 0 now_2))
(assert
 (= 1111 input_1_net.datagram_source_port))
(assert
 (= 8080 input_1_net.datagram_destination_port))
(assert
 (= 9 input_1_net.datagram_length))
(assert
 (= 0 input_1_net.datagram_checksum))
(assert
 (= input_1_net.datagram_sum_valid false))
(assert
 (let ((?x227 (seq.unit (_ bv65 8))))
(= input_1_net.datagram_data ?x227)))
(check-sat)

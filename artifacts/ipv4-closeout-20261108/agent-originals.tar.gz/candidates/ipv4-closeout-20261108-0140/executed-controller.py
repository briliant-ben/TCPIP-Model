from pathlib import Path
import concurrent.futures,hashlib,json,os,sys,time,traceback
P=Path('/home/blxu/protocol-flow')
O=P/'candidates/ipv4-closeout-20261108-0140'
O.mkdir(exist_ok=False)
S=P/'releases/ipv4-prototype-963a57f8/source'
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'))
from deepseek_gateway import request
def save(p,x):
 p.write_text(json.dumps(x,indent=2)+'\n')
def status(d,**x):
 save(d/'status.json',dict(pid=os.getpid(),updated_at=time.time(),automatic_API_retry=False,network_executed=False,production_modified=False,**x))
status(O,status='running',stage='two_bounded_closeout_roles')
(O/'executed-controller.py').write_bytes(Path(__file__).read_bytes())
base=dict(repository='briliant-ben/TCPIP-Model',framework_repository='briliant-ben/Formal-Spec-Agent',source_commit='963a57f8e2b0d9a9adad2dd6fb025ce8647112aa',model_file_sha256='7d5a82541ea55cde3ff39b2e1cf883f6c9f942f5dc535a2736e69044d9e154a5',scope='fixed IPv4 endpoint finite TCP/UDP/ARP/ICMP, not full TCP; IR sole authority',original_results={'flow_cases':32,'exploration_rules':10,'flow_trace_distinct_rules':32,'flow_plus_live_distinct_rules':36,'total_rules':335,'formal':'depth1 UNKNOWN 10000ms','assessment':'unresolved'},constraints=['No domain/depth/guard/invariant/oracle narrowing','No model callbacks or host stack as subject','Old evidence immutable, no network config, no main merge','Do not infer formal proof from SAT examples or coverage','No framework extraction yet; separate repository after prototype closeout'])
def role(name):
 d=O/name;d.mkdir();status(d,status='running',stage='preparing_frozen_input')
 try:
  payload=dict(base)
  if name=='formal':
   import z3
   Q=P/'candidates/ipv4-composed-flow-20261108-0138/run/stages/formal/queries'
   rows=[]
   for name_,expected in [('model.smt2','d5b785c0bb5fdc11bf0c92e01fc492bafa27cb22522479f61ddae14b02182f70'),('overlap.smt2','c9f115ed3176504be48467963d0cc0bb64c30f316f0436b023e8cd512cd0e9a9')]:
    raw=(Q/name_).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
    (d/name_).write_bytes(raw)
    solver=z3.Then('propagate-values','solve-eqs','simplify','smt').solver()
    solver.from_string(raw.decode());solver.set(timeout=10000)
    (d/('exact-'+name_)).write_text(solver.to_smt2())
    start=time.monotonic();ans=solver.check()
    row=dict(query=name_,original_sha256=expected,solver_version=z3.get_version_string(),policy='exact-v1',timeout_ms=10000,answer=str(ans),elapsed_s=time.monotonic()-start,scope='diagnostic original formula only; not complete flow or proof')
    if ans==z3.unknown:row['reason']=solver.reason_unknown()
    if ans==z3.sat:row['counterexample_replay']='not performed: diagnosis only, do not accept as validated counterexample'
    rows.append(row);save(d/'exact-diagnostic.json',rows)
   payload.update(actual_diagnostic=rows,source={n:(S/n).read_text() for n in ['protocol_lab/symbolic.py','docs/solver-preprocessing.md']},request='Diagnose exact all-input query bottleneck from actual results. Return JSON blocking/findings/next_bounded_experiment/limitations arrays. Propose at most one exact semantics-preserving experiment. No retries/budget increases/domain restriction; any partition must cover complete original obligation and record equivalence assumptions. Do not claim UNKNOWN solved from partial diagnosis.')
  else:
   payload.update(source={n:(S/n).read_text() for n in ['protocol_lab/pipeline/worker.py','protocol_lab/pipeline/testgen.py']},request='Implement ONLY a standalone pure coverage accounting candidate module, not integration or verdict changes. Return JSON files array of {path,content}, limitations array. Allowed paths protocol_lab/pipeline/coverage.py and tests/test_coverage_accounting.py. API summarize(rule_ids, records): rule_ids unique declared strings; records each {key,origin,initial_override,status,transitions} with initial_override bool, status pass/fail/unknown, transitions list of rule IDs. Reject malformed records, unknown IDs, duplicate keys/rule_ids, invented origins. Origins exactly model_generated/declared_seed/model_generated_rejection/live_observation. Only status pass contributes; negative contributes committed prefix only (caller contract), never rejected-step claim. Report sorted covered/uncovered per origin and overall, plus separate default-initial versus override sets. Do not call this reachability proof. No assessment field or policy changes. Include meaningful tests for failing examples excluded, overrides separate, unknown rules rejected, origins distinct, duplicate handling. Never claim 36/335 completes coverage. This is a data report helper; source/controller approval and integration still required.')
  ms=[dict(role='system',content='Bounded protocol verification closeout role. Return only the requested JSON object. Protocol IR is authoritative. Outputs are untrusted candidates, never approval or execution evidence.'),dict(role='user',content=json.dumps(payload))]
  save(d/'messages.json',ms);status(d,status='running',stage='DeepSeek_request')
  r=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=8192,thinking='disabled',reasoning_effort=None,timeout=600)
  response=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response']
  save(d/'response.json',response);save(d/'usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']})
  status(d,status='proposal_requires_controller_review',stage='finished')
 except Exception as e:
  status(d,status='failed_or_rejected',stage='stopped',error_type=type(e).__name__)
  (d/'traceback.txt').write_text(traceback.format_exc())
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(role,['formal','coverage']))
status(O,status='finished_requires_controller_review',stage='finished',roles={n:json.loads((O/n/'status.json').read_text())['status']for n in ['formal','coverage']})

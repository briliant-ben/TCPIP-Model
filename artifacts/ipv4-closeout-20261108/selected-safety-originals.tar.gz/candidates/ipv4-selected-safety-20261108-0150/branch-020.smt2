; benchmark generated from python API
(set-info :status unknown)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun now_1 () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun choice_0 () Int)
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!0
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!0
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!0
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x20404 (= due_1_T.time_wait 0)))
 (let (($x20396 (= due_1_T.user 0)))
 (let (($x20392 (= due_1_T.rtx 0)))
 (let (($x20388 (= due_1_L.cache 0)))
 (let ((?x4643 (+ 1000 now_1)))
 (let (($x16204 (= due_1_L.query ?x4643)))
 (let (($x7000 (not active_1_T.time_wait)))
 (let (($x7020 (not active_1_T.user)))
 (let (($x7019 (not active_1_T.rtx)))
 (let (($x4335 (not active_1_L.cache)))
 (let (($x3980 (= v_1_ip_pending_owner "UDP")))
 (let (($x1031 (= v_1_T.control "CLOSED")))
 (let (($x20378 (= v_1_T.wire_disposition "none")))
 (let (($x20374 (= v_1_T.wire_flags 0)))
 (let (($x16235 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x18035 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x18034 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x17273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x17272 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x6980 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x15931 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x19915 (= v_1_T.take 0)))
 (let (($x16030 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x16038 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x14807 (= v_1_T.snd_wnd 8)))
 (let (($x10410 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x10408 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x10407 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x10409 (= v_1_T.local_window 16)))
 (let (($x16035 (= v_1_T.msl_ms 60000)))
 (let (($x16039 (= v_1_T.user_timeout_ms 30000)))
 (let (($x6981 (= v_1_T.retries 0)))
 (let (($x6982 (= v_1_T.rto_ms 1000)))
 (let (($x3322 (= v_1_T.tx_flags "S")))
 (let (($x6978 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x16040 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x16041 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x16042 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x16045 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x16053 (= v_1_T.irs (_ bv0 32))))
 (let (($x16050 (= v_1_T.iss (_ bv1000 32))))
 (let (($x1242 (= v_1_L.control "PENDING")))
 (let (($x16054 (= v_1_L.echo_disposition "none")))
 (let (($x5804 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x5803 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x5802 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x5801 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x16055 (= v_1_L.rxudp_disposition "none")))
 (let (($x5339 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x15930 (not v_1_L.rxudp_require_checksum)))
 (let ((?x394 (seq.unit (_ bv0 8))))
 (let ((?x4822 (seq.++ ?x394 (seq.++ ?x394 input_0_L.app.send_data))))
 (let ((?x3910 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (+ 8 (seq.len input_0_L.app.send_data)))))))
 (let ((?x4823 (seq.++ ?x3910 ?x4822)))
 (let ((?x3912 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (+ 8 (seq.len input_0_L.app.send_data)))))))
 (let ((?x4824 (seq.++ ?x3912 ?x4823)))
 (let ((?x381 (seq.unit (_ bv144 8))))
 (let ((?x4825 (seq.++ ?x381 ?x4824)))
 (let ((?x383 (seq.unit (_ bv31 8))))
 (let ((?x4826 (seq.++ ?x383 ?x4825)))
 (let ((?x370 (seq.unit (_ bv64 8))))
 (let ((?x4827 (seq.++ ?x370 ?x4826)))
 (let ((?x372 (seq.unit (_ bv156 8))))
 (let ((?x4828 (seq.++ ?x372 ?x4827)))
 (let ((?x4903 (seq.++ ?x3912 (seq.++ ?x3910 ?x4828))))
 (let ((?x3612 (seq.unit (_ bv17 8))))
 (let ((?x4904 (seq.++ ?x3612 ?x4903)))
 (let ((?x4905 (seq.++ ?x394 ?x4904)))
 (let ((?x392 (seq.unit (_ bv2 8))))
 (let ((?x4906 (seq.++ ?x392 ?x4905)))
 (let ((?x4907 (seq.++ ?x392 ?x4906)))
 (let ((?x4908 (seq.++ ?x394 ?x4907)))
 (let ((?x397 (seq.unit (_ bv192 8))))
 (let ((?x4909 (seq.++ ?x397 ?x4908)))
 (let ((?x390 (seq.unit (_ bv1 8))))
 (let ((?x4910 (seq.++ ?x390 ?x4909)))
 (let ((?x4911 (seq.++ ?x392 ?x4910)))
 (let ((?x4912 (seq.++ ?x394 ?x4911)))
 (let ((?x4913 (seq.++ ?x397 ?x4912)))
 (let ((?x4915 (bvnot ((_ ir4_ones_sum16_checksum_instance!0 0) ?x4913))))
 (let ((?x4916 (ubv_to_int ?x4915)))
 (let ((?x19326 (ite (= ?x4915 (_ bv0 16)) 65535 ?x4916)))
 (let ((?x14651 ((_ int_to_bv 16) ?x19326)))
 (let ((?x19209 (seq.++ (seq.unit ((_ extract 15 8) ?x14651)) (seq.++ (seq.unit ((_ extract 7 0) ?x14651)) input_0_L.app.send_data))))
 (let ((?x17043 (seq.++ ?x370 (seq.++ ?x383 (seq.++ ?x381 (seq.++ ?x3912 (seq.++ ?x3910 ?x19209)))))))
 (let ((?x19112 (seq.++ ?x372 ?x17043)))
 (let ((?x16327 (seq.++ ?x390 (seq.++ ?x397 (seq.++ ?x394 (seq.++ ?x392 (seq.++ ?x392 ?x19112)))))))
 (let ((?x407 (seq.++ ?x392 ?x392)))
 (let ((?x408 (seq.++ ?x394 ?x407)))
 (let ((?x409 (seq.++ ?x397 ?x408)))
 (let ((?x1175 (seq.++ ?x390 ?x409)))
 (let ((?x1176 (seq.++ ?x392 ?x1175)))
 (let ((?x1177 (seq.++ ?x394 ?x1176)))
 (let ((?x1178 (seq.++ ?x397 ?x1177)))
 (let ((?x1179 (seq.++ ?x394 ?x1178)))
 (let ((?x1180 (seq.++ ?x394 ?x1179)))
 (let ((?x5033 (seq.++ ?x3612 ?x1180)))
 (let ((?x5034 (seq.++ ?x370 ?x5033)))
 (let ((?x5035 (seq.++ ?x394 ?x5034)))
 (let ((?x5036 (seq.++ ?x370 ?x5035)))
 (let ((?x5037 (seq.++ ?x394 ?x5036)))
 (let ((?x5038 (seq.++ ?x394 ?x5037)))
 (let ((?x4966 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (+ 28 (seq.len input_0_L.app.send_data)))))))
 (let ((?x5039 (seq.++ ?x4966 ?x5038)))
 (let ((?x4964 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (+ 28 (seq.len input_0_L.app.send_data)))))))
 (let ((?x5040 (seq.++ ?x4964 ?x5039)))
 (let ((?x5041 (seq.++ ?x394 ?x5040)))
 (let ((?x706 (seq.unit (_ bv69 8))))
 (let ((?x5042 (seq.++ ?x706 ?x5041)))
 (let ((?x5053 ((_ ir4_ones_sum16_checksum_instance!0 0) ?x5042)))
 (let ((?x5060 (bvnot ((_ extract 7 0) ?x5053))))
 (let ((?x5061 (seq.unit ?x5060)))
 (let ((?x5057 (bvnot ((_ extract 15 8) ?x5053))))
 (let ((?x5058 (seq.unit ?x5057)))
 (let ((?x16333 (seq.++ ?x5058 (seq.++ ?x5061 (seq.++ ?x397 (seq.++ ?x394 (seq.++ ?x392 ?x16327)))))))
 (let ((?x16415 (seq.++ ?x394 (seq.++ ?x370 (seq.++ ?x394 (seq.++ ?x370 (seq.++ ?x3612 ?x16333)))))))
 (let ((?x16420 (seq.++ ?x706 (seq.++ ?x394 (seq.++ ?x4964 (seq.++ ?x4966 (seq.++ ?x394 ?x16415)))))))
 (let (($x16424 (= v_1_L.pending_packet ?x16420)))
 (let ((?x5054 (bvnot ?x5053)))
 (let ((?x5055 (ubv_to_int ?x5054)))
 (let (($x5187 (= v_1_L.ip_checksum ?x5055)))
 (let (($x16423 (= v_1_L.udp_checksum ?x19326)))
 (let (($x5185 (= v_1_L.udp_raw_checksum ?x4916)))
 (let ((?x3890 (seq.len input_0_L.app.send_data)))
 (let ((?x4961 (+ 28 ?x3890)))
 (let (($x16422 (= v_1_L.ip_length ?x4961)))
 (let ((?x3891 (+ 8 ?x3890)))
 (let (($x3945 (= v_1_L.udp_length ?x3891)))
 (let (($x16421 (= v_1_L.packet ?x16420)))
 (let ((?x5110 (seq.++ ?x5061 ?x1178)))
 (let ((?x5111 (seq.++ ?x5058 ?x5110)))
 (let ((?x5112 (seq.++ ?x3612 ?x5111)))
 (let ((?x5113 (seq.++ ?x370 ?x5112)))
 (let ((?x5114 (seq.++ ?x394 ?x5113)))
 (let ((?x5115 (seq.++ ?x370 ?x5114)))
 (let ((?x5116 (seq.++ ?x394 ?x5115)))
 (let ((?x5117 (seq.++ ?x394 ?x5116)))
 (let ((?x5118 (seq.++ ?x4966 ?x5117)))
 (let ((?x5119 (seq.++ ?x4964 ?x5118)))
 (let ((?x5120 (seq.++ ?x394 ?x5119)))
 (let ((?x5121 (seq.++ ?x706 ?x5120)))
 (let (($x5122 (= v_1_L.ip_wire ?x5121)))
 (let (($x5043 (= v_1_L.ip_zero ?x5042)))
 (let (($x19113 (= v_1_L.udp_wire ?x19112)))
 (let ((?x3913 (seq.++ ?x3912 ?x3910)))
 (let ((?x4870 (seq.++ ?x3612 ?x3913)))
 (let ((?x4871 (seq.++ ?x394 ?x4870)))
 (let ((?x4872 (seq.++ ?x392 ?x4871)))
 (let ((?x4873 (seq.++ ?x392 ?x4872)))
 (let ((?x4874 (seq.++ ?x394 ?x4873)))
 (let ((?x4875 (seq.++ ?x397 ?x4874)))
 (let ((?x4876 (seq.++ ?x390 ?x4875)))
 (let ((?x4877 (seq.++ ?x392 ?x4876)))
 (let ((?x4878 (seq.++ ?x394 ?x4877)))
 (let ((?x4879 (seq.++ ?x397 ?x4878)))
 (let (($x4880 (= v_1_L.pseudoheader ?x4879)))
 (let (($x4829 (= v_1_L.udp_zero ?x4828)))
 (let (($x3972 (= v_1_L.payload input_0_L.app.send_data)))
 (let (($x16086 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x1243 (= 0 v_1_L.retry_count)))
 (let (($x4693 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x330 (= 0 state_1)))
 (let (($x3974 (>= 1472 ?x3890)))
 (let (($x16536 (>= now_1 0)))
 (and $x16536 $x3974 $x330 $x4693 $x1243 $x16086 v_1_L.checksums_enabled $x3972 $x4829 $x4880 $x19113 $x5043 $x5122 $x16421 $x3945 $x16422 $x5185 $x16423 $x5187 $x16424 $x15930 $x5339 $x16055 $x5801 $x5802 $x5803 $x5804 $x16054 $x1242 $x16050 $x16053 $x16045 $x16042 $x16041 $x16040 $x6978 $x3322 $x6982 $x6981 v_1_T.active_open $x16039 $x16035 $x10409 $x10407 $x10408 $x10410 $x14807 $x16038 $x16030 $x19915 $x15931 $x6980 $x17272 $x17273 $x18034 $x18035 $x16235 $x20374 $x20378 $x1031 $x3980 active_1_L.query $x4335 $x7019 $x7020 $x7000 $x16204 $x20388 $x20392 $x20396 $x20404))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 (let ((?x4197 (seq.len v_1_L.pending_packet)))
 (let (($x4198 (= 0 ?x4197)))
 (let (($x3839 (= v_1_ip_pending_owner "none")))
 (let (($x4201 (= $x3839 $x4198)))
 (let (($x3980 (= v_1_ip_pending_owner "UDP")))
 (let (($x1229 (= v_1_ip_pending_owner "TCP")))
 (let (($x1031 (= v_1_T.control "CLOSED")))
 (let (($x1000 (= v_1_T.control "LISTEN")))
 (let (($x972 (= v_1_T.control "SYN-SENT")))
 (let (($x944 (= v_1_T.control "SYN-RECEIVED")))
 (let (($x916 (= v_1_T.control "ESTABLISHED")))
 (let (($x888 (= v_1_T.control "FIN-WAIT-1")))
 (let (($x860 (= v_1_T.control "FIN-WAIT-2")))
 (let (($x832 (= v_1_T.control "CLOSE-WAIT")))
 (let (($x804 (= v_1_T.control "CLOSING")))
 (let (($x776 (= v_1_T.control "LAST-ACK")))
 (let (($x521 (= v_1_T.control "TIME-WAIT")))
 (let ((?x4213 (seq.len v_1_T.wire_packet)))
 (let (($x4214 (>= 1500 ?x4213)))
 (let ((?x4215 (seq.len v_1_T.rtx_buf)))
 (let (($x4216 (<= ?x4215 v_1_T.snd_wnd)))
 (let ((?x4222 (seq.len v_1_T.rcv_buf)))
 (let (($x4230 (= 0 ?x4222)))
 (let (($x4228 (= 0 ?x4215)))
 (let ((?x4225 (seq.len v_1_T.snd_buf)))
 (let (($x4226 (= 0 ?x4225)))
 (let (($x4236 (>= 65535 v_1_T.snd_wnd)))
 (let (($x4234 (<= 0 v_1_T.snd_wnd)))
 (let (($x4238 (>= 16 ?x4222)))
 (let (($x4240 (>= 16 (+ ?x4225 ?x4215))))
 (let (($x4243 (= v_1_T.snd_nxt (bvadd v_1_T.snd_una ((_ int_to_bv 32) ?x4215)))))
 (let (($x4232 (not $x916)))
 (let (($x4250 (<= 1 v_1_T.user_timeout_ms)))
 (let (($x4251 (<= 1 v_1_T.msl_ms)))
 (let (($x4252 (<= 0 v_1_T.retries)))
 (let (($x4253 (<= 1000 v_1_T.rto_ms)))
 (let (($x4254 (= v_1_T.snd_una v_1_T.tx_seq)))
 (let (($x14187 (and (= v_1_T.snd_nxt (bvadd (_ bv1 32) v_1_T.tx_seq)) $x4254)))
 (let (($x3336 (= v_1_L.control "RESOLVED")))
 (let (($x1242 (= v_1_L.control "PENDING")))
 (let (($x3593 (= v_1_L.control "EMPTY")))
 (let ((?x4303 (seq.len v_1_L.echo_reply)))
 (let (($x4304 (= 0 ?x4303)))
 (let (($x3391 (= v_1_L.echo_disposition "reply")))
 (let (($x4306 (>= 1500 ?x4303)))
 (let ((?x4309 (seq.len v_1_L.rxudp_payload)))
 (let (($x4310 (= 0 ?x4309)))
 (let (($x3633 (= v_1_L.rxudp_disposition "deliver")))
 (let (($x4312 (>= 1472 ?x4309)))
 (let (($x4314 (or $x4198 (<= 28 ?x4197))))
 (let (($x4317 (>= 1500 ?x4197)))
 (let ((?x4318 (seq.len v_1_L.packet)))
 (let (($x4319 (= ?x4318 v_1_L.ip_length)))
 (let (($x4321 (or (= 0 ?x4318) $x4319)))
 (let (($x4322 (>= 1500 ?x4318)))
 (let (($x4324 (>= 3600000 v_1_L.cache_ttl_ms)))
 (let (($x4323 (<= 60000 v_1_L.cache_ttl_ms)))
 (let (($x4327 (>= 1 v_1_L.retry_count)))
 (let (($x4326 (<= 0 v_1_L.retry_count)))
 (let (($x4331 (not active_1_L.query)))
 (let ((?x4329 (seq.len v_1_L.peer_mac)))
 (let (($x4330 (= 6 ?x4329)))
 (let (($x16072 (or (not $x1242) (and (= 0 ?x4329) active_1_L.query (not active_1_L.cache)))))
 (let (($x18115 (and (or (not $x3593) (and (= 0 ?x4329) $x4331 (not active_1_L.cache))) $x16072 (or (not $x3336) (and $x4330 $x4331 active_1_L.cache)) $x4326 $x4327 $x4323 $x4324 $x4322 $x4321 $x4317 (or (not (<= 1 ?x4197)) $x1242) $x4314 $x4312 (or $x3633 $x4310) $x4306 (or $x3391 $x4304) (or $x3593 $x1242 $x3336) (or (not active_1_T.rtx) (not $x1031)) (or (not active_1_T.user) (not $x1031)) (or (not active_1_T.time_wait) (not $x1031)) (or (not active_1_T.rtx) (not $x1000)) (or (not active_1_T.user) (not $x1000)) (or (not active_1_T.time_wait) (not $x1000)) (or active_1_T.rtx (not $x972)) (or active_1_T.user (not $x972)) (or (not active_1_T.time_wait) (not $x972)) (or active_1_T.rtx (not $x944)) (or active_1_T.user (not $x944)) (or (not active_1_T.time_wait) (not $x944)) (or $x4232 (not active_1_T.user)) (or $x4232 (not active_1_T.time_wait)) (or active_1_T.rtx (not $x888)) (or active_1_T.user (not $x888)) (or (not active_1_T.time_wait) (not $x888)) (or (not active_1_T.rtx) (not $x860)) (or active_1_T.user (not $x860)) (or (not active_1_T.time_wait) (not $x860)) (or (not active_1_T.rtx) (not $x832)) (or (not active_1_T.user) (not $x832)) (or (not active_1_T.time_wait) (not $x832)) (or active_1_T.rtx (not $x804)) (or active_1_T.user (not $x804)) (or (not active_1_T.time_wait) (not $x804)) (or active_1_T.rtx (not $x776)) (or active_1_T.user (not $x776)) (or (not active_1_T.time_wait) (not $x776)) (or (not active_1_T.rtx) (not $x521)) (or (not active_1_T.user) (not $x521)) (or active_1_T.time_wait (not $x521)) (or (not (or $x776 $x804 $x888 $x944 $x972)) $x14187) $x4253 $x4252 $x4251 $x4250 (or (not $x972) (= v_1_T.snd_una v_1_T.iss)) (or $x4232 (= active_1_T.rtx (<= 1 ?x4215))) (or $x4232 $x4243) $x4240 $x4238 $x4234 $x4236 (or $x916 (and $x4226 $x4228 $x4230)) (= v_1_T.local_window (+ 16 (* (- 1) ?x4222))) (or (not (or $x521 $x832 $x860)) (= v_1_T.snd_una v_1_T.snd_nxt)) $x4216 $x4214 (or $x521 $x776 $x804 $x832 $x860 $x888 $x916 $x944 $x972 $x1000 $x1031) (or $x1229 $x3839 $x3980) $x4201)))
 (not $x18115))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 (= choice_0 18))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun active_1_T.rtx () Bool)
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun choice_0 () Int)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 false)
(assert
 (let ((?x4197 (seq.len v_1_L.pending_packet)))
 (let (($x4198 (= 0 ?x4197)))
 (let (($x3839 (= v_1_ip_pending_owner "none")))
 (let (($x4201 (= $x3839 $x4198)))
 (let (($x3980 (= v_1_ip_pending_owner "UDP")))
 (let (($x1229 (= v_1_ip_pending_owner "TCP")))
 (let (($x1031 (= v_1_T.control "CLOSED")))
 (let (($x1000 (= v_1_T.control "LISTEN")))
 (let (($x972 (= v_1_T.control "SYN-SENT")))
 (let (($x944 (= v_1_T.control "SYN-RECEIVED")))
 (let (($x916 (= v_1_T.control "ESTABLISHED")))
 (let (($x888 (= v_1_T.control "FIN-WAIT-1")))
 (let (($x860 (= v_1_T.control "FIN-WAIT-2")))
 (let (($x832 (= v_1_T.control "CLOSE-WAIT")))
 (let (($x804 (= v_1_T.control "CLOSING")))
 (let (($x776 (= v_1_T.control "LAST-ACK")))
 (let (($x521 (= v_1_T.control "TIME-WAIT")))
 (let ((?x4213 (seq.len v_1_T.wire_packet)))
 (let (($x4214 (>= 1500 ?x4213)))
 (let ((?x4215 (seq.len v_1_T.rtx_buf)))
 (let (($x4216 (<= ?x4215 v_1_T.snd_wnd)))
 (let ((?x4222 (seq.len v_1_T.rcv_buf)))
 (let (($x4230 (= 0 ?x4222)))
 (let (($x4228 (= 0 ?x4215)))
 (let ((?x4225 (seq.len v_1_T.snd_buf)))
 (let (($x4226 (= 0 ?x4225)))
 (let (($x4236 (>= 65535 v_1_T.snd_wnd)))
 (let (($x4234 (<= 0 v_1_T.snd_wnd)))
 (let (($x4238 (>= 16 ?x4222)))
 (let (($x4240 (>= 16 (+ ?x4225 ?x4215))))
 (let (($x4243 (= v_1_T.snd_nxt (bvadd v_1_T.snd_una ((_ int_to_bv 32) ?x4215)))))
 (let (($x4232 (not $x916)))
 (let (($x4250 (<= 1 v_1_T.user_timeout_ms)))
 (let (($x4251 (<= 1 v_1_T.msl_ms)))
 (let (($x4252 (<= 0 v_1_T.retries)))
 (let (($x4253 (<= 1000 v_1_T.rto_ms)))
 (let (($x4254 (= v_1_T.snd_una v_1_T.tx_seq)))
 (let (($x14187 (and (= v_1_T.snd_nxt (bvadd (_ bv1 32) v_1_T.tx_seq)) $x4254)))
 (let (($x3336 (= v_1_L.control "RESOLVED")))
 (let (($x1242 (= v_1_L.control "PENDING")))
 (let (($x3593 (= v_1_L.control "EMPTY")))
 (let ((?x4303 (seq.len v_1_L.echo_reply)))
 (let (($x4304 (= 0 ?x4303)))
 (let (($x3391 (= v_1_L.echo_disposition "reply")))
 (let (($x4306 (>= 1500 ?x4303)))
 (let ((?x4309 (seq.len v_1_L.rxudp_payload)))
 (let (($x4310 (= 0 ?x4309)))
 (let (($x3633 (= v_1_L.rxudp_disposition "deliver")))
 (let (($x4312 (>= 1472 ?x4309)))
 (let (($x4314 (or $x4198 (<= 28 ?x4197))))
 (let (($x4317 (>= 1500 ?x4197)))
 (let ((?x4318 (seq.len v_1_L.packet)))
 (let (($x4319 (= ?x4318 v_1_L.ip_length)))
 (let (($x4321 (or (= 0 ?x4318) $x4319)))
 (let (($x4322 (>= 1500 ?x4318)))
 (let (($x4324 (>= 3600000 v_1_L.cache_ttl_ms)))
 (let (($x4323 (<= 60000 v_1_L.cache_ttl_ms)))
 (let (($x4327 (>= 1 v_1_L.retry_count)))
 (let (($x4326 (<= 0 v_1_L.retry_count)))
 (let (($x4331 (not active_1_L.query)))
 (let ((?x4329 (seq.len v_1_L.peer_mac)))
 (let (($x4330 (= 6 ?x4329)))
 (let (($x16072 (or (not $x1242) (and (= 0 ?x4329) active_1_L.query (not active_1_L.cache)))))
 (let (($x18115 (and (or (not $x3593) (and (= 0 ?x4329) $x4331 (not active_1_L.cache))) $x16072 (or (not $x3336) (and $x4330 $x4331 active_1_L.cache)) $x4326 $x4327 $x4323 $x4324 $x4322 $x4321 $x4317 (or (not (<= 1 ?x4197)) $x1242) $x4314 $x4312 (or $x3633 $x4310) $x4306 (or $x3391 $x4304) (or $x3593 $x1242 $x3336) (or (not active_1_T.rtx) (not $x1031)) (or (not active_1_T.user) (not $x1031)) (or (not active_1_T.time_wait) (not $x1031)) (or (not active_1_T.rtx) (not $x1000)) (or (not active_1_T.user) (not $x1000)) (or (not active_1_T.time_wait) (not $x1000)) (or active_1_T.rtx (not $x972)) (or active_1_T.user (not $x972)) (or (not active_1_T.time_wait) (not $x972)) (or active_1_T.rtx (not $x944)) (or active_1_T.user (not $x944)) (or (not active_1_T.time_wait) (not $x944)) (or $x4232 (not active_1_T.user)) (or $x4232 (not active_1_T.time_wait)) (or active_1_T.rtx (not $x888)) (or active_1_T.user (not $x888)) (or (not active_1_T.time_wait) (not $x888)) (or (not active_1_T.rtx) (not $x860)) (or active_1_T.user (not $x860)) (or (not active_1_T.time_wait) (not $x860)) (or (not active_1_T.rtx) (not $x832)) (or (not active_1_T.user) (not $x832)) (or (not active_1_T.time_wait) (not $x832)) (or active_1_T.rtx (not $x804)) (or active_1_T.user (not $x804)) (or (not active_1_T.time_wait) (not $x804)) (or active_1_T.rtx (not $x776)) (or active_1_T.user (not $x776)) (or (not active_1_T.time_wait) (not $x776)) (or (not active_1_T.rtx) (not $x521)) (or (not active_1_T.user) (not $x521)) (or active_1_T.time_wait (not $x521)) (or (not (or $x776 $x804 $x888 $x944 $x972)) $x14187) $x4253 $x4252 $x4251 $x4250 (or (not $x972) (= v_1_T.snd_una v_1_T.iss)) (or $x4232 (= active_1_T.rtx (<= 1 ?x4215))) (or $x4232 $x4243) $x4240 $x4238 $x4234 $x4236 (or $x916 (and $x4226 $x4228 $x4230)) (= v_1_T.local_window (+ 16 (* (- 1) ?x4222))) (or (not (or $x521 $x832 $x860)) (= v_1_T.snd_una v_1_T.snd_nxt)) $x4216 $x4214 (or $x521 $x776 $x804 $x832 $x860 $x888 $x916 $x944 $x972 $x1000 $x1031) (or $x1229 $x3839 $x3980) $x4201)))
 (not $x18115))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 (= choice_0 300))
(check-sat)

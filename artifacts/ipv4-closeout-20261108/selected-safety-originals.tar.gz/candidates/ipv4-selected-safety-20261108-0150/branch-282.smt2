; benchmark generated from python API
(set-info :status unknown)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun now_1 () Int)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun choice_0 () Int)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x20404 (= due_1_T.time_wait 0)))
 (let (($x20396 (= due_1_T.user 0)))
 (let (($x20392 (= due_1_T.rtx 0)))
 (let (($x20388 (= due_1_L.cache 0)))
 (let (($x20384 (= due_1_L.query 0)))
 (let (($x7000 (not active_1_T.time_wait)))
 (let (($x7020 (not active_1_T.user)))
 (let (($x7019 (not active_1_T.rtx)))
 (let (($x4335 (not active_1_L.cache)))
 (let (($x4331 (not active_1_L.query)))
 (let (($x3839 (= v_1_ip_pending_owner "none")))
 (let (($x1031 (= v_1_T.control "CLOSED")))
 (let (($x329 (= v_1_T.wire_disposition "drop_ip_length")))
 (let (($x20374 (= v_1_T.wire_flags 0)))
 (let (($x16235 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x18035 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x18034 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x17273 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x17272 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x6980 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x15931 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x19915 (= v_1_T.take 0)))
 (let (($x16030 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x16038 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x14807 (= v_1_T.snd_wnd 8)))
 (let (($x10410 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x10408 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x10407 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x10409 (= v_1_T.local_window 16)))
 (let (($x16035 (= v_1_T.msl_ms 60000)))
 (let (($x16039 (= v_1_T.user_timeout_ms 30000)))
 (let (($x6981 (= v_1_T.retries 0)))
 (let (($x6982 (= v_1_T.rto_ms 1000)))
 (let (($x3322 (= v_1_T.tx_flags "S")))
 (let (($x6978 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x16040 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x16041 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x16042 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x16045 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x16053 (= v_1_T.irs (_ bv0 32))))
 (let (($x16050 (= v_1_T.iss (_ bv1000 32))))
 (let (($x3593 (= v_1_L.control "EMPTY")))
 (let (($x16054 (= v_1_L.echo_disposition "none")))
 (let (($x5804 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x5803 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x5802 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x5801 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x16055 (= v_1_L.rxudp_disposition "none")))
 (let (($x5339 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x15930 (not v_1_L.rxudp_require_checksum)))
 (let (($x5204 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x16057 (= v_1_L.ip_checksum 0)))
 (let (($x16060 (= v_1_L.udp_checksum 0)))
 (let (($x16068 (= v_1_L.udp_raw_checksum 0)))
 (let (($x16065 (= v_1_L.ip_length 0)))
 (let (($x16069 (= v_1_L.udp_length 0)))
 (let (($x15889 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x15888 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x15859 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x18789 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x18788 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x16996 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x16995 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x16086 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x4630 (= v_1_L.retry_count 0)))
 (let (($x4693 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x330 (= 0 state_1)))
 (let ((?x5240 (seq.nth_i input_0_L.net.frame_frame 17)))
 (let ((?x5241 (seq.nth_u input_0_L.net.frame_frame 17)))
 (let ((?x346 (seq.len input_0_L.net.frame_frame)))
 (let (($x5237 (<= ?x346 17)))
 (let ((?x5243 (ite $x5237 ?x5241 ?x5240)))
 (let ((?x5245 (ite $x5237 0 (ubv_to_int ?x5243))))
 (let ((?x5230 (seq.nth_i input_0_L.net.frame_frame 16)))
 (let ((?x5231 (seq.nth_u input_0_L.net.frame_frame 16)))
 (let (($x5227 (<= ?x346 16)))
 (let ((?x5233 (ite $x5227 ?x5231 ?x5230)))
 (let ((?x5235 (ite $x5227 0 (ubv_to_int ?x5233))))
 (let ((?x5236 (* 256 ?x5235)))
 (let ((?x5247 (+ 14 ?x5236 ?x5245)))
 (let (($x16430 (= ?x346 ?x5247)))
 (let (($x17891 (or $x16430 (= ?x346 (ite (>= 46 (+ ?x5236 ?x5245)) 60 ?x5247)))))
 (let ((?x5246 (+ ?x5236 ?x5245)))
 (let (($x16429 (>= 1500 ?x5246)))
 (let (($x18474 (<= 40 ?x5246)))
 (let ((?x383 (seq.unit (_ bv31 8))))
 (let ((?x532 (seq.++ ?x383 (seq.++ (seq.unit (_ bv144 8)) (seq.++ (seq.unit (_ bv156 8)) (seq.unit (_ bv64 8)))))))
 (let (($x5611 (= (seq.extract input_0_L.net.frame_frame 34 4) ?x532)))
 (let ((?x390 (seq.unit (_ bv1 8))))
 (let ((?x392 (seq.unit (_ bv2 8))))
 (let ((?x393 (seq.++ ?x392 ?x390)))
 (let ((?x394 (seq.unit (_ bv0 8))))
 (let ((?x395 (seq.++ ?x394 ?x393)))
 (let ((?x397 (seq.unit (_ bv192 8))))
 (let ((?x398 (seq.++ ?x397 ?x395)))
 (let (($x7212 (= (seq.extract input_0_L.net.frame_frame 30 4) ?x398)))
 (let ((?x407 (seq.++ ?x392 ?x392)))
 (let ((?x408 (seq.++ ?x394 ?x407)))
 (let ((?x409 (seq.++ ?x397 ?x408)))
 (let (($x7206 (= (seq.extract input_0_L.net.frame_frame 26 4) ?x409)))
 (let (($x6065 (<= ?x346 23)))
 (let (($x6067 (not $x6065)))
 (let ((?x6069 (seq.nth_i input_0_L.net.frame_frame 23)))
 (let ((?x6070 (seq.nth_u input_0_L.net.frame_frame 23)))
 (let ((?x6072 (ite $x6065 ?x6070 ?x6069)))
 (let (($x18472 (= ?x6072 (_ bv6 8))))
 (let ((?x4734 (seq.nth_i input_0_L.net.frame_frame 22)))
 (let ((?x4735 (seq.nth_u input_0_L.net.frame_frame 22)))
 (let (($x4731 (<= ?x346 22)))
 (let ((?x4737 (ite $x4731 ?x4735 ?x4734)))
 (let ((?x4739 (ite $x4731 0 (ubv_to_int ?x4737))))
 (let (($x18468 (>= 255 ?x4739)))
 (let (($x15281 (<= 1 ?x4739)))
 (let ((?x7198 (seq.nth_i input_0_L.net.frame_frame 21)))
 (let ((?x7199 (seq.nth_u input_0_L.net.frame_frame 21)))
 (let (($x7194 (<= ?x346 21)))
 (let ((?x7201 (ite $x7194 ?x7199 ?x7198)))
 (let (($x18467 (or $x7194 (= ?x7201 (_ bv0 8)))))
 (let (($x7184 (<= ?x346 20)))
 (let (($x7186 (not $x7184)))
 (let ((?x7188 (seq.nth_i input_0_L.net.frame_frame 20)))
 (let ((?x7189 (seq.nth_u input_0_L.net.frame_frame 20)))
 (let ((?x7191 (ite $x7184 ?x7189 ?x7188)))
 (let (($x18466 (= ?x7191 (_ bv64 8))))
 (let ((?x7178 (seq.nth_i input_0_L.net.frame_frame 15)))
 (let ((?x7179 (seq.nth_u input_0_L.net.frame_frame 15)))
 (let (($x7174 (<= ?x346 15)))
 (let ((?x7181 (ite $x7174 ?x7179 ?x7178)))
 (let (($x18123 (or $x7174 (= ?x7181 (_ bv0 8)))))
 (let (($x7165 (<= ?x346 14)))
 (let (($x7166 (not $x7165)))
 (let ((?x7168 (seq.nth_i input_0_L.net.frame_frame 14)))
 (let ((?x7169 (seq.nth_u input_0_L.net.frame_frame 14)))
 (let ((?x7171 (ite $x7165 ?x7169 ?x7168)))
 (let (($x17234 (= ?x7171 (_ bv69 8))))
 (let ((?x469 (seq.unit (_ bv8 8))))
 (let ((?x470 (seq.++ ?x469 ?x394)))
 (let (($x7164 (= (seq.extract input_0_L.net.frame_frame 12 2) ?x470)))
 (let ((?x480 (seq.++ ?x392 (seq.++ ?x394 (seq.++ ?x394 (seq.++ ?x394 (seq.++ ?x394 ?x392)))))))
 (let ((?x4726 (seq.extract input_0_L.net.frame_frame 6 6)))
 (let (($x7161 (= ?x4726 ?x480)))
 (let ((?x489 (seq.++ ?x392 (seq.++ ?x394 (seq.++ ?x394 (seq.++ ?x394 (seq.++ ?x394 ?x390)))))))
 (let ((?x4708 (seq.extract input_0_L.net.frame_frame 0 6)))
 (let (($x4709 (= ?x4708 ?x489)))
 (let (($x495 (>= 1514 ?x346)))
 (let (($x536 (<= 54 ?x346)))
 (let ((?x5265 (seq.extract input_0_L.net.frame_frame 14 ?x5246)))
 (let ((?x5268 (seq.len ?x5265)))
 (let (($x5260 (<= 0 ?x5246)))
 (let ((?x16475 (ite $x5260 ?x5268 0)))
 (let (($x5310 (<= ?x5268 3)))
 (let (($x5261 (not $x5260)))
 (let (($x19755 (or $x5261 $x5310)))
 (let ((?x19764 (ite $x19755 (ite $x5260 (seq.nth_u ?x5265 3) (seq.nth_u (as seq.empty (Seq (_ BitVec 8))) 3)) (seq.nth_i (ite $x5260 ?x5265 (as seq.empty (Seq (_ BitVec 8)))) 3))))
 (let (($x5291 (<= ?x5268 2)))
 (let (($x19660 (or $x5261 $x5291)))
 (let ((?x19672 (ite $x19660 (ite $x5260 (seq.nth_u ?x5265 2) (seq.nth_u (as seq.empty (Seq (_ BitVec 8))) 2)) (seq.nth_i (ite $x5260 ?x5265 (as seq.empty (Seq (_ BitVec 8)))) 2))))
 (let ((?x19767 (+ (* 256 (ite $x19660 0 (ubv_to_int ?x19672))) (ite $x19755 0 (ubv_to_int ?x19764)))))
 (let (($x19768 (= ?x19767 ?x16475)))
 (let (($x22604 (not $x19768)))
 (let ((?x684 (seq.++ ?x392 (seq.++ ?x397 (seq.++ ?x394 (seq.++ ?x392 (seq.++ ?x390 ?x532)))))))
 (let ((?x687 (seq.++ ?x397 (seq.++ ?x394 (seq.++ ?x392 ?x684)))))
 (let (($x19657 (= (ite $x5260 (seq.extract ?x5265 12 12) (as seq.empty (Seq (_ BitVec 8)))) ?x687)))
 (let (($x5717 (<= ?x5268 9)))
 (let (($x15422 (or $x5261 $x5717)))
 (let (($x18719 (not $x15422)))
 (let ((?x16224 (ite $x15422 (ite $x5260 (seq.nth_u ?x5265 9) (seq.nth_u (as seq.empty (Seq (_ BitVec 8))) 9)) (seq.nth_i (ite $x5260 ?x5265 (as seq.empty (Seq (_ BitVec 8)))) 9))))
 (let (($x19771 (= ?x16224 (_ bv6 8))))
 (let (($x5771 (<= ?x5268 8)))
 (let (($x15801 (or $x5261 $x5771)))
 (let ((?x16162 (ite $x15801 (ite $x5260 (seq.nth_u ?x5265 8) (seq.nth_u (as seq.empty (Seq (_ BitVec 8))) 8)) (seq.nth_i (ite $x5260 ?x5265 (as seq.empty (Seq (_ BitVec 8)))) 8))))
 (let (($x16172 (<= 1 (ite $x15801 0 (ubv_to_int ?x16162)))))
 (let ((?x370 (seq.unit (_ bv64 8))))
 (let ((?x711 (seq.++ ?x370 ?x394)))
 (let (($x19485 (= (ite $x5260 (seq.extract ?x5265 6 2) (as seq.empty (Seq (_ BitVec 8)))) ?x711)))
 (let ((?x706 (seq.unit (_ bv69 8))))
 (let ((?x707 (seq.++ ?x706 ?x394)))
 (let (($x16481 (= (ite $x5260 (seq.extract ?x5265 0 2) (as seq.empty (Seq (_ BitVec 8)))) ?x707)))
 (let (($x16477 (>= 1500 ?x16475)))
 (let (($x14745 (<= 40 ?x16475)))
 (let (($x16536 (>= now_1 0)))
 (and $x16536 $x14745 $x16477 $x16481 $x19485 $x16172 $x19771 $x18719 $x19657 $x22604 $x536 $x495 $x4709 $x7161 $x7164 $x17234 $x7166 $x18123 $x18466 $x7186 $x18467 $x15281 $x18468 $x18472 $x6067 $x7206 $x7212 $x5611 $x18474 $x16429 $x17891 $x330 $x4693 $x4630 $x16086 v_1_L.checksums_enabled $x16995 $x16996 $x18788 $x18789 $x15859 $x15888 $x15889 $x16069 $x16065 $x16068 $x16060 $x16057 $x5204 $x15930 $x5339 $x16055 $x5801 $x5802 $x5803 $x5804 $x16054 $x3593 $x16050 $x16053 $x16045 $x16042 $x16041 $x16040 $x6978 $x3322 $x6982 $x6981 v_1_T.active_open $x16039 $x16035 $x10409 $x10407 $x10408 $x10410 $x14807 $x16038 $x16030 $x19915 $x15931 $x6980 $x17272 $x17273 $x18034 $x18035 $x16235 $x20374 $x329 $x1031 $x3839 $x4331 $x4335 $x7019 $x7020 $x7000 $x20384 $x20388 $x20392 $x20396 $x20404)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 (let ((?x4197 (seq.len v_1_L.pending_packet)))
 (let (($x4198 (= 0 ?x4197)))
 (let (($x3839 (= v_1_ip_pending_owner "none")))
 (let (($x4201 (= $x3839 $x4198)))
 (let (($x3980 (= v_1_ip_pending_owner "UDP")))
 (let (($x1229 (= v_1_ip_pending_owner "TCP")))
 (let (($x1031 (= v_1_T.control "CLOSED")))
 (let (($x1000 (= v_1_T.control "LISTEN")))
 (let (($x972 (= v_1_T.control "SYN-SENT")))
 (let (($x944 (= v_1_T.control "SYN-RECEIVED")))
 (let (($x916 (= v_1_T.control "ESTABLISHED")))
 (let (($x888 (= v_1_T.control "FIN-WAIT-1")))
 (let (($x860 (= v_1_T.control "FIN-WAIT-2")))
 (let (($x832 (= v_1_T.control "CLOSE-WAIT")))
 (let (($x804 (= v_1_T.control "CLOSING")))
 (let (($x776 (= v_1_T.control "LAST-ACK")))
 (let (($x521 (= v_1_T.control "TIME-WAIT")))
 (let ((?x4213 (seq.len v_1_T.wire_packet)))
 (let (($x4214 (>= 1500 ?x4213)))
 (let ((?x4215 (seq.len v_1_T.rtx_buf)))
 (let (($x4216 (<= ?x4215 v_1_T.snd_wnd)))
 (let ((?x4222 (seq.len v_1_T.rcv_buf)))
 (let (($x4230 (= 0 ?x4222)))
 (let (($x4228 (= 0 ?x4215)))
 (let ((?x4225 (seq.len v_1_T.snd_buf)))
 (let (($x4226 (= 0 ?x4225)))
 (let (($x4236 (>= 65535 v_1_T.snd_wnd)))
 (let (($x4234 (<= 0 v_1_T.snd_wnd)))
 (let (($x4238 (>= 16 ?x4222)))
 (let (($x4240 (>= 16 (+ ?x4225 ?x4215))))
 (let (($x4243 (= v_1_T.snd_nxt (bvadd v_1_T.snd_una ((_ int_to_bv 32) ?x4215)))))
 (let (($x4232 (not $x916)))
 (let (($x4250 (<= 1 v_1_T.user_timeout_ms)))
 (let (($x4251 (<= 1 v_1_T.msl_ms)))
 (let (($x4252 (<= 0 v_1_T.retries)))
 (let (($x4253 (<= 1000 v_1_T.rto_ms)))
 (let (($x4254 (= v_1_T.snd_una v_1_T.tx_seq)))
 (let (($x14187 (and (= v_1_T.snd_nxt (bvadd (_ bv1 32) v_1_T.tx_seq)) $x4254)))
 (let (($x3336 (= v_1_L.control "RESOLVED")))
 (let (($x1242 (= v_1_L.control "PENDING")))
 (let (($x3593 (= v_1_L.control "EMPTY")))
 (let ((?x4303 (seq.len v_1_L.echo_reply)))
 (let (($x4304 (= 0 ?x4303)))
 (let (($x3391 (= v_1_L.echo_disposition "reply")))
 (let (($x4306 (>= 1500 ?x4303)))
 (let ((?x4309 (seq.len v_1_L.rxudp_payload)))
 (let (($x4310 (= 0 ?x4309)))
 (let (($x3633 (= v_1_L.rxudp_disposition "deliver")))
 (let (($x4312 (>= 1472 ?x4309)))
 (let (($x4314 (or $x4198 (<= 28 ?x4197))))
 (let (($x4317 (>= 1500 ?x4197)))
 (let ((?x4318 (seq.len v_1_L.packet)))
 (let (($x4319 (= ?x4318 v_1_L.ip_length)))
 (let (($x4321 (or (= 0 ?x4318) $x4319)))
 (let (($x4322 (>= 1500 ?x4318)))
 (let (($x4324 (>= 3600000 v_1_L.cache_ttl_ms)))
 (let (($x4323 (<= 60000 v_1_L.cache_ttl_ms)))
 (let (($x4327 (>= 1 v_1_L.retry_count)))
 (let (($x4326 (<= 0 v_1_L.retry_count)))
 (let (($x4331 (not active_1_L.query)))
 (let ((?x4329 (seq.len v_1_L.peer_mac)))
 (let (($x4330 (= 6 ?x4329)))
 (let (($x16072 (or (not $x1242) (and (= 0 ?x4329) active_1_L.query (not active_1_L.cache)))))
 (let (($x18115 (and (or (not $x3593) (and (= 0 ?x4329) $x4331 (not active_1_L.cache))) $x16072 (or (not $x3336) (and $x4330 $x4331 active_1_L.cache)) $x4326 $x4327 $x4323 $x4324 $x4322 $x4321 $x4317 (or (not (<= 1 ?x4197)) $x1242) $x4314 $x4312 (or $x3633 $x4310) $x4306 (or $x3391 $x4304) (or $x3593 $x1242 $x3336) (or (not active_1_T.rtx) (not $x1031)) (or (not active_1_T.user) (not $x1031)) (or (not active_1_T.time_wait) (not $x1031)) (or (not active_1_T.rtx) (not $x1000)) (or (not active_1_T.user) (not $x1000)) (or (not active_1_T.time_wait) (not $x1000)) (or active_1_T.rtx (not $x972)) (or active_1_T.user (not $x972)) (or (not active_1_T.time_wait) (not $x972)) (or active_1_T.rtx (not $x944)) (or active_1_T.user (not $x944)) (or (not active_1_T.time_wait) (not $x944)) (or $x4232 (not active_1_T.user)) (or $x4232 (not active_1_T.time_wait)) (or active_1_T.rtx (not $x888)) (or active_1_T.user (not $x888)) (or (not active_1_T.time_wait) (not $x888)) (or (not active_1_T.rtx) (not $x860)) (or active_1_T.user (not $x860)) (or (not active_1_T.time_wait) (not $x860)) (or (not active_1_T.rtx) (not $x832)) (or (not active_1_T.user) (not $x832)) (or (not active_1_T.time_wait) (not $x832)) (or active_1_T.rtx (not $x804)) (or active_1_T.user (not $x804)) (or (not active_1_T.time_wait) (not $x804)) (or active_1_T.rtx (not $x776)) (or active_1_T.user (not $x776)) (or (not active_1_T.time_wait) (not $x776)) (or (not active_1_T.rtx) (not $x521)) (or (not active_1_T.user) (not $x521)) (or active_1_T.time_wait (not $x521)) (or (not (or $x776 $x804 $x888 $x944 $x972)) $x14187) $x4253 $x4252 $x4251 $x4250 (or (not $x972) (= v_1_T.snd_una v_1_T.iss)) (or $x4232 (= active_1_T.rtx (<= 1 ?x4215))) (or $x4232 $x4243) $x4240 $x4238 $x4234 $x4236 (or $x916 (and $x4226 $x4228 $x4230)) (= v_1_T.local_window (+ 16 (* (- 1) ?x4222))) (or (not (or $x521 $x832 $x860)) (= v_1_T.snd_una v_1_T.snd_nxt)) $x4216 $x4214 (or $x521 $x776 $x804 $x832 $x860 $x888 $x916 $x944 $x972 $x1000 $x1031) (or $x1229 $x3839 $x3980) $x4201)))
 (not $x18115))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 (= choice_0 280))
(check-sat)

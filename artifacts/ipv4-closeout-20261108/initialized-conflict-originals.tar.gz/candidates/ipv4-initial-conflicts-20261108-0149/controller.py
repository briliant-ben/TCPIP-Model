from pathlib import Path
import hashlib,json,os,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/ipv4-initial-conflicts-20261108-0149';O.mkdir(exist_ok=False);R=P/'releases/ipv4-prototype-963a57f8';S=R/'source'
def save(n,x):p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def status(**x):save('status.json',dict(pid=os.getpid(),updated_at=time.time(),production_modified=False,network_executed=False,automatic_API_retry=False,**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());status(status='running',stage='build_exact_initialized_conflict_disjuncts')
try:
 import z3
 sys.path.insert(0,str(P/'candidates/ipv4-prestate-gate-20261108-0148/candidate'));from prestate_reduce import reduce_initial_constants
 original=P/'candidates/ipv4-prestate-gate-20261108-0148/overlap.smt2/original.smt2';raw=original.read_bytes();assert hashlib.sha256(raw).hexdigest()=='c9f115ed3176504be48467963d0cc0bb64c30f316f0436b023e8cd512cd0e9a9';(O/'original-overlap.smt2').write_bytes(raw)
 assertions=list(z3.parse_smt2_string(raw.decode()));reduced=reduce_initial_constants(assertions);assert len(reduced['assertions'])==len(assertions)and all(any(z3.eq(b,t)for t in assertions)for b in reduced['bindings'])
 goal=reduced['assertions'][-1];(O/'initialized-goal.sexpr').write_text(goal.sexpr());save('explicit-binding-sources.json',[x.sexpr()for x in reduced['bindings']])
 stack=[goal];leaves=[]
 while stack:
  node=stack.pop()
  if z3.is_or(node):stack.extend(reversed(node.children()))
  elif not z3.is_false(node):leaves.append(node)
 unique={x.sexpr():x for x in leaves};assert 0<len(unique)<=300,'Bounded diagnostic refuses unexpected goal size';save('decomposition.json',dict(original_assertions=len(assertions),explicit_bindings=len(reduced['bindings']),nonfalse_leaves=len(leaves),unique_clauses=len(unique),goal_sha256=hashlib.sha256(goal.sexpr().encode()).hexdigest(),strategy='F implies reduced-last-conflict-goal under original explicit unit initial bindings; each OR leaf is checked as stronger independent obligation',scope='initialized guard-overlap at original depth1, not all-state/unbounded/fullprotocol proof',omitted_relation_constraints='intentional strengthening: UNSAT leaf suffices, SAT needs actual original-domain/reference replay',byte_domain='full SeqBV8; no length restriction introduced'))
 rows=[];confirmed=None
 for i,clause in enumerate(unique.values()):
  status(status='running',stage='actual_initialized_conflict_clause',index=i+1,total=len(unique),API_in_progress=False)
  solver=z3.Solver();solver.set(timeout=10000);solver.add(clause);q=solver.to_smt2();(O/('clause-'+str(i).zfill(3)+'.smt2')).write_text(q);start=time.monotonic();ans=solver.check();row=dict(index=i,answer=str(ans),query_sha256=hashlib.sha256(q.encode()).hexdigest(),solver_version=z3.get_version_string(),timeout_ms=10000,solve_s=time.monotonic()-start)
  if ans==z3.unknown:row['reason']=solver.reason_unknown()
  if ans==z3.sat:
   sol=solver.model();(O/('clause-'+str(i).zfill(3)+'-model.sexpr')).write_text(sol.sexpr());frame=z3.Const('input_0_L.net.frame_frame',z3.SeqSort(z3.BitVecSort(8)));length=sol.eval(z3.Length(frame),model_completion=True).as_long();at=sol.eval(z3.Int('now_1'),model_completion=True).as_long();row.update(frame_length=length,at_ms=at,sat_scope='strengthened guard obligation, not yet original-model counterexample')
   if 0<=length<=4096 and at>=0:
    fields={'frame':[sol.eval(frame[j],model_completion=True).as_long()for j in range(length)]};save('clause-'+str(i).zfill(3)+'-input.json',dict(event='L.net.frame',at_ms=at,fields=fields))
    sys.path.insert(0,str(S));from protocol_lab.ir import load,Machine,Conflict,ModelError
    from protocol_lab.codegen.execute import commands
    model_path=S/'model/ipv4-endpoint-virtual-link.json';assert hashlib.sha256(model_path.read_bytes()).hexdigest()=='7d5a82541ea55cde3ff39b2e1cf883f6c9f942f5dc535a2736e69044d9e154a5';m=load(model_path);machine=Machine(m);before=machine.snapshot()
    try:machine.dispatch('L.net.frame',fields,at);row['reference_replay']='no_conflict'
    except Conflict as error:row.update(reference_replay='confirmed_rule_conflict',reference_error=str(error),reference_atomic=machine.snapshot()==before);confirmed=dict(index=i,**fields,at_ms=at,error=str(error))
    except ModelError as error:row.update(reference_replay='other_model_rejection',reference_error=str(error))
    if confirmed:
     scene=dict(id='initialized-conflict-'+str(i),initial={},steps=[dict(at_ms=at,event='L.net.frame',fields=fields)]);data=commands(m,scene);(O/'counterexample-native-input.txt').write_text(data);binary=R/'build/protocol-native';run=subprocess.run([str(binary)],input=data,text=True,capture_output=True,timeout=30);(O/'counterexample-native.stdout').write_text(run.stdout);(O/'counterexample-native.stderr').write_text(run.stderr);obs=[json.loads(x)for x in run.stdout.splitlines()];row.update(native_returncode=run.returncode,native_ELF_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),native_errors=[x for x in obs if x.get('status')=='error']);save('confirmed-counterexample.json',confirmed)
  rows.append(row);save('results.json',rows)
  if confirmed:break
 counts={a:sum(r['answer']==a for r in rows)for a in ['sat','unsat','unknown']};save('summary.json',dict(total_clauses=len(unique),completed=len(rows),answers=counts,confirmed_original_model_conflict=bool(confirmed),status='confirmed_model_conflict'if confirmed else'all_initialized_disjuncts_unsat'if len(rows)==len(unique)and counts['unsat']==len(unique)else'unresolved',original_full_input_UNKNOWN_unchanged=True,production_backend_unchanged=True))
 status(status='running',stage='independent_DeepSeek_review',API_in_progress=True)
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 payload=dict(controller=(O/'controller.py').read_text(),decomposition=json.loads((O/'decomposition.json').read_text()),actual_summary=json.loads((O/'summary.json').read_text()),actual_counterexample=confirmed,actual_rows=[r for r in rows if r['answer']!='unsat'],audit_questions=['Original last assertion is OR of all encoded conflicts; reduce only original explicit70unit initials. F implies G; G OR-leaves allUNSAT suffices for initial overlap, no scheduler/poststate assumptions needed. Weaker conjunctive constraints mean SAT leaf alone is not accepted; actual original Machine and generatedC checks recorded if materializable. Identify concrete missing-disjunct/derivation/overclaim defects.','No typed byte domain/length narrowing, no solverbudgetincrease or retry. Unknown rows retained, complete count required for negative conclusion. Original fullflow UNKNOWN remains; not allstate/compiler/unbounded proof.'],required_output={'blocking':[],'findings':[],'limitations':[]})
 ms=[dict(role='system',content='Independent audit only. Exact JSON blocking/findings/limitations arrays, no source patches. Concrete supported defects; distinguish strengthening of UNSAT obligation from narrowing inputs.'),dict(role='user',content=json.dumps(payload))];save('review-messages.json',ms);rr=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=8192,thinking='disabled',reasoning_effort=None,timeout=600);a=json.loads((P/'private/api-ledger'/rr['response_file']).read_text())['response'];save('review-response.json',a);save('review-usage.json',{k:rr.get(k)for k in ['usage','cached','request_sha256']});assert set(a)=={'blocking','findings','limitations'}and all(isinstance(v,list)for v in a.values()),'Invalid review';status(status='review_rejected'if a['blocking']else'diagnostic_requires_controller_approval',stage='finished',API_in_progress=False)
except Exception as e:status(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__,API_in_progress=False);(O/'traceback.txt').write_text(traceback.format_exc());raise

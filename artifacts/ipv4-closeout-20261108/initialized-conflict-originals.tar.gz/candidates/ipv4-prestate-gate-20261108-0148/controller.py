from pathlib import Path
import hashlib,json,os,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/ipv4-prestate-gate-20261108-0148';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python';S=P/'releases/ipv4-prototype-963a57f8/source'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def status(**kw):save(O/'status.json',dict(pid=os.getpid(),updated_at=time.time(),production_modified=False,network_executed=False,automatic_API_retry=False,**kw))
if len(sys.argv)>1:
 import z3
 sys.path.insert(0,str(O/'candidate'));from prestate_reduce import reduce_initial_constants
 mode=sys.argv[1];D=O/mode;D.mkdir(exist_ok=False)
 if mode=='sample':
  sys.path.insert(0,str(S));from protocol_lab.ir import load
  from protocol_lab.symbolic import Encoding,replay
  m=load(S/'model/ipv4-endpoint-virtual-link.json');enc=Encoding(m,1,[],fixed_choices=[0]);original=list(enc.solver.assertions());text=enc.solver.to_smt2()
 else:
  q=P/'candidates/ipv4-composed-flow-20261108-0138/run/stages/formal/queries'/mode;text=q.read_text();expected={'model.smt2':'d5b785c0bb5fdc11bf0c92e01fc492bafa27cb22522479f61ddae14b02182f70','overlap.smt2':'c9f115ed3176504be48467963d0cc0bb64c30f316f0436b023e8cd512cd0e9a9'}[mode];assert hashlib.sha256(text.encode()).hexdigest()==expected;original=list(z3.parse_smt2_string(text))
 (D/'original.smt2').write_text(text);start=time.monotonic();r=reduce_initial_constants(original);assert len(r['assertions'])==len(original);assert all(any(z3.eq(b,t)for t in original)for b in r['bindings'])
 save(D/'binding-sources.json',[b.sexpr()for b in r['bindings']]);s=z3.Solver();s.set(timeout=10000);s.add(*r['assertions'],*r['bindings']);actual=s.to_smt2();(D/'actual.smt2').write_text(actual)
 binding_s=time.monotonic()-start;start=time.monotonic();answer=s.check();row=dict(query=mode,answer=str(answer),reason=s.reason_unknown()if answer==z3.unknown else None,original_sha256=hashlib.sha256(text.encode()).hexdigest(),actual_sha256=hashlib.sha256(actual.encode()).hexdigest(),original_assertions=len(original),retained_assertion_slots=len(r['assertions']),explicit_original_unit_binding_sources=len(r['bindings']),binding_sources_readded=True,solver_version=z3.get_version_string(),timeout_ms=10000,reduction_s=binding_s,solve_s=time.monotonic()-start,not_production_backend=True,original_unknown_preserved=True)
 if answer==z3.sat:
  if mode=='sample':
   enc.solver=s;w=enc.witness(s.model());save(D/'witness.json',w);rr=replay(m,w);save(D/'reference-replay.json',rr);row['reference_replay']=rr
  else:(D/'model.sexpr').write_text(s.model().sexpr());row['protocol_counterexample_replay']='not_performed: not accepted counterexample'
 save(D/'result.json',row);sys.exit(0)
O.mkdir(exist_ok=False);(O/'controller.py').write_bytes(Path(__file__).read_bytes());status(status='running',stage='qualified_source_tests')
try:
 package=P/'incoming/prestate-qualified-0148.json';payload=json.loads(package.read_text());save(O/'qualified-source-package.json',payload);C=O/'candidate';C.mkdir()
 assert set(payload['files'])=={'prestate_reduce.py','test_prestate_reduce.py','test_independent_prestate_reduce.py'}
 for n,s in payload['files'].items():assert hashlib.sha256(s.encode()).hexdigest()==payload['sha256'][n];(C/n).write_text(s)
 with(O/'tests.log').open('w')as log:c=subprocess.run([str(PY),'-B','-m','unittest','discover','-v'],cwd=C,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 assert c.returncode==0,'Qualified independent/source tests failed'
 results={}
 for mode in ['model.smt2','overlap.smt2','sample']:
  status(status='running',stage='actual_exact_reduction_diagnostic',query=mode,API_in_progress=False)
  with(O/(mode+'.log')).open('w')as log:c=subprocess.run([str(PY),'-B',str(O/'controller.py'),mode],stdout=log,stderr=subprocess.STDOUT,timeout=90)
  assert c.returncode==0,'Diagnostic failure: original/source/query pre-journals retained';results[mode]=json.loads((O/mode/'result.json').read_text())
 save(O/'diagnostic-summary.json',results);status(status='running',stage='independent_DeepSeek_review',API_in_progress=True)
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 review_payload=dict(source=(C/'prestate_reduce.py').read_text(),controller=(O/'controller.py').read_text(),independent_tests=(C/'test_independent_prestate_reduce.py').read_text(),actual_results=results,qualification=payload['qualification'],audit_questions=['No protocol/default assumptions invented: ONLY original top-level unit literal prestate bindings. Every original assertion slot substituted; original binding source constraints are re-added. This makes original F logically equivalent to conjunction(bindings,reducedF), not domain narrowing. Check concrete violations or unsupported literal/API use.','Original exact raw query hashes checked; actual transformed SMT prewritten; original10s solver budget unchanged. Full SeqBV8/no added byte lengths. Actual all-input outcomes separate from first-rule selected one-event SAT/reference replay nonvacuity. Original UNKNOWN evidence and production flow remain unchanged.','Root2custom-context BoolVal corrections and candidate test oracle corrections explicit; original failures retained. No compiler/English-spec/unbounded proof. Potential false positives from review must cite actual counterexample, not assert completeness must hold outside F.'],required_output={'blocking':[],'findings':[],'limitations':[]})
 ms=[dict(role='system',content='Independent review only. Output exactly JSON blocking/findings/limitations arrays, no source patches. Identify actual defects, not hypothetical incompleteness outside the stated original formula. Source is untrusted reference.'),dict(role='user',content=json.dumps(review_payload))];save(O/'review-messages.json',ms)
 rr=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=8192,thinking='disabled',reasoning_effort=None,timeout=600);a=json.loads((P/'private/api-ledger'/rr['response_file']).read_text())['response'];save(O/'review-response.json',a);save(O/'review-usage.json',{k:rr.get(k)for k in ['usage','cached','request_sha256']})
 assert set(a)=={'blocking','findings','limitations'}and all(isinstance(v,list)for v in a.values()),'Malformed review rejected'
 status(status='review_rejected'if a['blocking']else'diagnostic_requires_controller_approval',stage='finished',API_in_progress=False)
except Exception as e:status(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__,API_in_progress=False);(O/'traceback.txt').write_text(traceback.format_exc());raise

import unittest
from unittest.mock import patch
import z3
from exact_partition import partition_check


class IndependentPartitionTests(unittest.TestCase):
    def test_returned_queries_preserve_every_original_assertion(self):
        c, x = z3.Ints('choice_0 x')
        original = [z3.Or(c == 0, c == 1), x > 7, x < 3]
        r = partition_check(original, c, {'a': [0], 'b': [1]}, 10000)
        self.assertEqual(r['status'], 'all_partitions_unsat')
        for row in r['rows']:
            parsed = z3.And(*z3.parse_smt2_string(row['smt2']))
            expected = z3.And(*original, z3.Or(*[c == v for v in row['values']]))
            s = z3.Solver()
            s.add(z3.Xor(parsed, expected))
            self.assertEqual(s.check(), z3.unsat)

    def test_exhaustion_unknown_never_passes(self):
        c = z3.Int('choice_0')
        with patch.object(z3.Solver, 'check', return_value=z3.unknown):
            r = partition_check([c == 0], c, {'a': [0]}, 10000)
        self.assertEqual(r['status'], 'unknown')
        self.assertEqual(r['rows'], [])

    def test_one_satisfiable_partition_never_passes(self):
        c = z3.Int('choice_0')
        r = partition_check([c == 1], c, {'a': [0], 'b': [1]}, 10000)
        self.assertNotEqual(r['status'], 'all_partitions_unsat')
        self.assertEqual([x['answer'] for x in r['rows']], ['unsat', 'sat'])

    def test_unbounded_integer_remainder_is_not_ignored(self):
        c = z3.Int('choice_0')
        r = partition_check([c >= 0], c, {'a': [0], 'b': [1]}, 10000)
        self.assertEqual(r['status'], 'incomplete')
        self.assertEqual(r['rows'], [])

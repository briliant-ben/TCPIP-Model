### core partition checker for exact BMC

import hashlib


def _validate_groups(groups):
    """Validate group structure and indices; raises ValueError on malformed input."""
    if not isinstance(groups, dict):
        raise ValueError("groups must be a dict")
    seen = set()
    for name, values in groups.items():
        if not isinstance(name, str) or not name:
            raise ValueError("group name must be non-empty str")
        if not isinstance(values, (list, tuple)) or len(values) == 0:
            raise ValueError(f"group {name}: values must be a non-empty list/tuple")
        vals = list(values)
        if any(isinstance(v, bool) or not isinstance(v, int) for v in vals):
            raise ValueError(f"group {name}: all values must be int and not bool")
        if len(set(vals)) != len(vals):
            raise ValueError(f"group {name}: duplicate int values")
        for v in vals:
            if v in seen:
                raise ValueError(f"value {v} appears in multiple groups")
            seen.add(v)
    if not seen:
        raise ValueError("groups must contain at least one index overall")
    return {k: list(v) for k, v in groups.items()}


def partition_check(assertions, choice, groups, timeout_ms=10000):
    """
    Exhaustive partition check of the original SMT obligation.

    Parameters
    ----------
    assertions : list of z3.BoolRef
        The COMPLETE already encoded original obligation (all constraints and
        the safety/overlap query). Must be non-empty and contain only BoolRef.
    choice : z3.IntRef
        The symbolic integer representing transition choice (typically 'choice_0').
    groups : dict
        Mapping group names to lists of distinct int values.
        Every value across all groups must be unique (no overlap).
        The groups collectively partition the allowed choice domain for the
        depth-1 obligation; the checker verifies exhaustiveness by solving
        the original assertions with NOT (choice in any group). If that
        formula is not UNSAT, the check is incomplete (returns unresolved).
    timeout_ms : int
        Solver timeout per check (exhaustion + each group). Must be positive.

    Returns
    -------
    dict with status and per-group details. The status is one of:
    - 'all_partitions_unsat' : every group UNSAT and exhaustion UNSAT.
    - 'counterexample'       : at least one group has SAT, with model sexpr.
    - 'unknown'              : any timeout/unknown in exhaustion or group.
    - 'incomplete'           : exhaustion not UNSAT (domain not covered).
    - 'invalid'              : input validation error.

    The returned dict includes `smt2_base` (the supplied original assertions)
    and `rows` with per-group query and answer.
    """
    import z3

    # --- input validation ----------------------------------------------------
    try:
        if not isinstance(assertions, (list, tuple)) or len(assertions) == 0:
            raise ValueError("assertions must be a non-empty list/tuple of BoolRef")
        if not all(isinstance(a, z3.BoolRef) for a in assertions):
            raise ValueError("all assertions must be z3.BoolRef")
        if not isinstance(choice, z3.ArithRef) or not choice.is_int():
            raise ValueError("choice must be an IntRef (z3.Int)")
        if not isinstance(timeout_ms, int) or timeout_ms <= 0:
            raise ValueError("timeout_ms must be a positive int")
        groups = _validate_groups(groups)
    except ValueError as e:
        return {"status": "invalid", "error": str(e)}

    # reset timeout on any solver consistently
    def _solver():
        s = z3.Solver()
        s.set(timeout=timeout_ms)
        return s

    # base query as a string (original assertions only)
    base_solver = _solver()
    base_solver.add(*assertions)
    base_smt = base_solver.to_smt2()

    rows = []

    # --- exhaustiveness check -------------------------------------------------
    # groups cover all allowed indices: not(choice in any group) must be UNSAT
    exhaustive_solver = _solver()
    exhaustive_solver.add(*assertions)
    # not( Or(choice == v for all groups values) )
    exhaustive_solver.add(z3.Not(z3.Or(*[choice == v for vals in groups.values() for v in vals])))
    exhaust_smt = exhaustive_solver.to_smt2()
    exhaust_res = exhaustive_solver.check()
    if exhaust_res == z3.sat:
        return {
            "status": "incomplete",
            "reason": "exhaustiveness check SAT: domain not fully partitioned",
            "smt2_base": base_smt,
            "exhaustion_query": exhaust_smt,
            "exhaustion_result": "sat",
            "rows": rows,
        }
    if exhaust_res == z3.unknown:
        return {
            "status": "unknown",
            "reason": "exhaustiveness check unknown: " + (exhaustive_solver.reason_unknown() or ""),
            "smt2_base": base_smt,
            "exhaustion_query": exhaust_smt,
            "exhaustion_result": "unknown",
            "rows": rows,
        }
    # exhaust_res == unsat
    exhaust_result_str = "unsat"

    # --- per group check ------------------------------------------------------
    all_unsat = True
    for gname, vals in groups.items():
        s = _solver()
        s.add(*assertions)
        s.add(z3.Or(*[choice == v for v in vals]))
        per_group_smt = s.to_smt2()
        res = s.check()
        row = {
            "group": gname,
            "values": vals,
            "smt2": per_group_smt,
            "answer": str(res),
        }
        if res == z3.sat:
            try:
                m = s.model()
                row["model_sexpr"] = m.sexpr()
            except Exception:
                row["model_sexpr"] = "<unavailable>"
            row["counterexample"] = True
            all_unsat = False
            # we can continue checking other groups, but final status is counterexample
        elif res == z3.unknown:
            row["reason_unknown"] = s.reason_unknown() or ""
            all_unsat = False
            # status will be unknown if any unknown
        else:
            row["counterexample"] = False
        rows.append(row)

    if not all_unsat:
        # if any group had unknown, status unknown; else if any sat, counterexample
        has_unknown = any(r["answer"] == "unknown" for r in rows)
        status = "unknown" if has_unknown else "counterexample"
    else:
        status = "all_partitions_unsat"

    return {
        "status": status,
        "smt2_base": base_smt,
        "exhaustion_query": exhaust_smt,
        "exhaustion_result": exhaust_result_str,
        "rows": rows,
    }

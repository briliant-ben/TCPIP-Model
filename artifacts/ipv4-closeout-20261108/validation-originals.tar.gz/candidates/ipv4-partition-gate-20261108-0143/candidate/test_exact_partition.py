import unittest
import z3
from exact_partition import partition_check


class TestExactPartition(unittest.TestCase):
    def test_complete_unsat_partition(self):
        x = z3.Int('x')
        choice = z3.Int('choice_0')
        assertions = [x > 10, x < 0, choice >= -1, choice <= 1]  # contradictory, unsat
        groups = {'g1': [0], 'g2': [-1], 'g3': [1]}
        result = partition_check(assertions, choice, groups, timeout_ms=2000)
        self.assertEqual(result['status'], 'all_partitions_unsat')
        self.assertEqual(len(result['rows']), 3)
        self.assertTrue(all(r['answer'] == 'unsat' for r in result['rows']))
        self.assertEqual(result['exhaustion_result'], 'unsat')

    def test_sat_preserved(self):
        x = z3.Int('x')
        choice = z3.Int('choice_0')
        assertions = [x == 1, choice >= 0, choice <= 1]
        groups = {'even': [0], 'odd': [1]}
        result = partition_check(assertions, choice, groups, timeout_ms=2000)
        self.assertEqual(result['status'], 'counterexample')
        # the SAT must occur in the group containing satisfying choice (0)
        sat_rows = [r for r in result['rows'] if r['answer'] == 'sat']
        self.assertTrue(any(r['group'] == 'even' for r in sat_rows))
        self.assertIn('model_sexpr', sat_rows[0])

    def test_omitted_value_rejects_completeness(self):
        x = z3.Int('x')
        choice = z3.Int('choice_0')
        assertions = [x == 1, choice >= 0, choice <= 2]
        groups = {'g0': [0], 'g1': [1]}  # missing 2
        result = partition_check(assertions, choice, groups, timeout_ms=2000)
        self.assertEqual(result['status'], 'incomplete')
        # The exhaustion query should be SAT because choice=2 is possible
        self.assertEqual(result['exhaustion_result'], 'sat')

    def test_overlapping_group_rejected(self):
        x = z3.Int('x')
        choice = z3.Int('choice_0')
        assertions = [x == 1]
        groups = {'a': [0, 1], 'b': [1, 2]}
        result = partition_check(assertions, choice, groups, timeout_ms=2000)
        self.assertEqual(result['status'], 'invalid')
        self.assertIn('error', result)

    def test_bool_index_rejected(self):
        x = z3.Int('x')
        choice = z3.Int('choice_0')
        assertions = [x == 1]
        groups = {'a': [True]}  # bool is subclass of int but forbidden
        result = partition_check(assertions, choice, groups, timeout_ms=2000)
        self.assertEqual(result['status'], 'invalid')


if __name__ == '__main__':
    unittest.main()

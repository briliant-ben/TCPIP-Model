from pathlib import Path
import hashlib,json,os,sys,time,traceback
P=Path('/home/blxu/protocol-flow');R=P/'releases/ipv4-prototype-963a57f8';S=R/'source';O=P/'candidates/ipv4-legacy-profile-20261108-0144';O.mkdir(exist_ok=False)
sys.path.insert(0,str(S))
from protocol_lab.ir import load
from protocol_lab.flow import run_scenario
from protocol_lab.codegen.execute import run
from protocol_lab.symbolic import crosscheck_trace
def save(n,v):p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),updated_at=time.time(),API_calls=0,network_executed=False,production_modified=False,**v))
(O/'controller.py').write_bytes(Path(__file__).read_bytes())
try:
 f=P/'candidates/tcp-coupling-complete-deps-20261107-0081/regression-0001/frozen-projected-oracles.json';assert hashlib.sha256(f.read_bytes()).hexdigest()=='1494d7445a0f66560232751c5f7c3a2daf604d0bb79dda6cda349157fa1053e0';(O/'frozen-projected-oracles.json').write_bytes(f.read_bytes())
 mfile=S/'model/ipv4-endpoint-virtual-link.json';assert hashlib.sha256(mfile.read_bytes()).hexdigest()=='7d5a82541ea55cde3ff39b2e1cf883f6c9f942f5dc535a2736e69044d9e154a5';m=load(mfile)
 save('bindings.json',dict(model_sha256=hashlib.sha256(mfile.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),generation_sha256=hashlib.sha256((R/'generation/generation.json').read_bytes()).hexdigest(),ELF_sha256=hashlib.sha256((R/'build/protocol-native').read_bytes()).hexdigest(),scope='Fresh execution of unchanged45 old frozen literal scenarios against final virtual-link IR; not new network or full-input proof'))
 rows=[]
 for i,scene in enumerate(json.loads(f.read_text())):
  name=scene['id'];status(status='running',stage='actual_reference_native',index=i+1,total=45,case=name);save(name+'/scenario.json',scene)
  ref=run_scenario(m,scene);save(name+'/reference-trace.json',ref.trace)
  native=run(R/'generation',R/'build',O/name/'scenario.json',O/name/'native');assert native['status']=='pass',str(native)
  row=dict(id=name,literal='pass',native='pass',initial_override=bool(scene.get('initial')),transitions=[r['transition']for r in ref.trace]);rows.append(row);save('results.json',rows)
  if name.startswith('T-'):
   status(status='running',stage='independent_fixed_input_Z3',index=i+1,total=45,case=name)
   r=crosscheck_trace(m,ref.trace,O/name/'symbolic');assert r.get('query')=='sat'and r.get('status')=='match','Fixed-input query unresolved or mismatch';row['fixed_Z3']='sat_replay_match';save('results.json',rows)
 status(status='literal_regression_pass_requires_review',stage='finished',cases=len(rows),transitions=sum(len(r['transitions'])for r in rows),unique_rules=len({v for r in rows for v in r['transitions']}),fixed_Z3=sum('fixed_Z3'in r for r in rows))
except Exception as e:status(status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__,error=str(e)[:1200]);(O/'traceback.txt').write_text(traceback.format_exc());raise

from pathlib import Path
import copy,hashlib,importlib.util,json,subprocess,sys
W,O=map(Path,sys.argv[1:]);sys.path.insert(0,str(W))
from protocol_lab.ir import load,Machine,Uncovered
from protocol_lab.symbolic import model_hash,crosscheck_trace
from protocol_lab.flow import run_scenario
from protocol_lab.pipeline.worker import reference_case,compare_case,apply
from protocol_lab.codegen import generate
from protocol_lab.codegen.execute import build,commands
from tools.ipv4_endpoint_virtual_link import build_virtual_endpoint

def save(n,x):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=load(W/'model/tcp-ipv4-virtual-link.json');A=load(W/'model/ipv4-udp-icmp-endpoint.json');B=load(W/'model/ipv4-udp-icmp-tap.json');candidate=build_virtual_endpoint(base,A,B)
f=W/'model/ipv4-endpoint-virtual-link.json';f.write_text(json.dumps(candidate,indent=2)+'\n');assert sha(f)=='7d5a82541ea55cde3ff39b2e1cf883f6c9f942f5dc535a2736e69044d9e154a5';assert model_hash(candidate)=='6882e6187f029d16df5c2124a9cad0e815d2aba7ea0f0b08488de6df3a29488e'
# Byte-structural whole IR assertion: guard/source/scope changes only30 L ingress;
# every other rule/guard/action remains equal to the pinned TCP virtual model.
changed=[]
for old,new in zip(base['transitions'],candidate['transitions']):
 if old!=new:
  assert new['id'].startswith(('L.UDPRX-','L.ECHO-'));changed.append(new['id']);a,b=copy.deepcopy(old),copy.deepcopy(new)
  for k in ('guard','requirements'):a.pop(k);b.pop(k)
  assert a==b
assert len(changed)==30
for key in base:
 if key not in ('transitions','scope','requirements'):assert base[key]==candidate[key]
assert sha(W/'spec/ipv4-endpoint-virtual-link-oracle.json')=='4c8e8106b55327fb8dc5e72119bb93ac0a3dea89d75b770461ef02291764580c'
oracle=json.loads((W/'spec/ipv4-endpoint-virtual-link-oracle.json').read_text());assert sha(W/'spec/ipv4-udp-icmp-tap-oracle.json')==oracle['source_sha256']
G,C=O/'generation',O/'build';generate(f,G);assert build(G,C)['status']=='pass'
records=[]

def check(scene,formal=False,negative=False):
 folder=O/'cases'/scene['id'];folder.mkdir(parents=True,exist_ok=False);ref=reference_case(candidate,scene)
 if negative:assert ref['error']and ref['error']['classification']=='model_gap'and not ref['trace']
 else:assert ref['error']is None
 data=commands(candidate,scene);(folder/'native-input.txt').write_text(data);cp=subprocess.run([str(C/'protocol-native')],input=data,text=True,capture_output=True,timeout=30);(folder/'native.stdout').write_text(cp.stdout);(folder/'native.stderr').write_text(cp.stderr);diff=compare_case(ref,[json.loads(x)for x in cp.stdout.splitlines()],cp.returncode,negative);assert diff['status']=='pass',scene['id'];save('cases/'+scene['id']+'/scene.json',scene);save('cases/'+scene['id']+'/difference.json',diff)
 if formal:
  machine=Machine(candidate,scene.get('initial',{}))
  for step in scene['steps']:apply(machine,step)
  if 'settle_ms'in scene:machine.tick(scene['settle_ms'])
  proof=crosscheck_trace(candidate,machine.trace,folder/'symbolic');assert proof['query']=='sat'and proof['status']=='match',scene['id']
 records.append(dict(id=scene['id'],reference_native='pass',negative_atomic_rejection=negative,fixed_input_Z3='SAT_match'if formal else'not_run'));save('progress.json',records)
 return ref

for scene in oracle['positive_scenes']:
 run_scenario(candidate,scene)
 check(scene,formal=scene['id']in {'L-udp-empty','L-echo-empty','L-udp-odd','L-echo-odd','L-mtu-mixed','L-pending-ingress-retains-queue'})
for directory in ['tcp-ipv4-endpoint','tcp-ipv4-virtual-link']:
 for p in sorted((W/'scenarios'/directory).glob('*.json')):
  scene=json.loads(p.read_text());run_scenario(base,scene);run_scenario(candidate,scene);check(scene)
for name,raw in oracle['negative_frames'].items():
 check(dict(scenario_version='0.2',id='gap-'+name,initial={},steps=[dict(at_ms=0,event='L.net.frame',fields=dict(frame=list(bytes.fromhex(raw)))))]),negative=True)
scene=oracle['actual_replay_scene'];scene['id']='actual-e70-original-input-offline-replay';old=reference_case(base,scene);assert old['error']['classification']=='model_gap';ref=check(scene,formal=True);expected=oracle['actual_replay_expect'];assert all(ref['final']['variables'][k]==v for k,v in expected['variables'].items());assert ref['trace'][-1]['emitted']==expected['last_emitted'];assert ref['trace'][:-1]==old['trace']
save('model-binding.json',dict(base_semantic_sha256=model_hash(base),candidate_semantic_sha256=model_hash(candidate),model_file_sha256=sha(f),changed_L_guards=changed,new_oracle_sha256=sha(W/'spec/ipv4-endpoint-virtual-link-oracle.json'),runtime_actions_unchanged=True,TCP_ARP_guards_unchanged=True,new_network=False))
save('validation-summary.json',dict(status='finite_virtual_endpoint_gate_pass',cases=records,positive_cases=22,negative_cases=6,fixed_input_Z3_cases=7,all_input_or_compiler_proof=False,new_network=False,old_failures_not_upgraded=True))
print('28cases/7actualfixedZ3/30Lguard contract passed; no new network')

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x681 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x680 (= due_1_T.user due_0_T.user)))
 (let (($x679 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x678 (= due_1_L.cache due_0_L.cache)))
 (let (($x671 (= due_1_L.query due_0_L.query)))
 (let (($x670 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x669 (= active_1_T.user active_0_T.user)))
 (let (($x668 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x667 (= active_1_L.cache active_0_L.cache)))
 (let (($x666 (= active_1_L.query active_0_L.query)))
 (let (($x3611 (= v_1_T.wire_flags 0)))
 (let (($x32836 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x32835 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x32834 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x32833 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x32832 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x32831 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x32830 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3622 (= v_1_T.take 0)))
 (let (($x3623 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3624 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x3640 (= v_1_T.snd_wnd 8)))
 (let (($x32829 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x32828 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x32827 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3625 (= v_1_T.local_window 16)))
 (let (($x3646 (= v_1_T.msl_ms 60000)))
 (let (($x3649 (= v_1_T.user_timeout_ms 30000)))
 (let (($x3920 (= v_1_T.retries 0)))
 (let (($x3921 (= v_1_T.rto_ms 1000)))
 (let (($x4035 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x4021 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x4022 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x4031 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x4043 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x4046 (= v_1_T.irs (_ bv0 32))))
 (let (($x4044 (= v_1_T.iss (_ bv1000 32))))
 (let (($x627 (= v_1_L.control "EMPTY")))
 (let (($x626 (= v_1_L.echo_disposition "reply")))
 (let ((?x3023 (seq.unit (_ bv192 8))))
 (let ((?x2286 (seq.++ ?x3023 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x2313 (seq.unit (_ bv1 8))))
 (let ((?x2484 (seq.unit (_ bv2 8))))
 (let ((?x306 (seq.unit (_ bv0 8))))
 (let ((?x506 (seq.++ ?x306 (seq.++ ?x3023 (seq.++ ?x306 (seq.++ ?x2484 (seq.++ ?x2313 ?x2286)))))))
 (let ((?x1097 (seq.unit (_ bv64 8))))
 (let ((?x512 (seq.++ ?x1097 (seq.++ ?x306 (seq.++ ?x1097 (seq.++ ?x2313 (seq.++ ?x306 ?x506)))))))
 (let ((?x514 (seq.++ ?x306 (seq.++ ?x306 ?x512))))
 (let ((?x32396 (seq.unit (_ bv33 8))))
 (let ((?x1095 (seq.unit (_ bv69 8))))
 (let (($x32826 (= v_1_L.echo_ip_zero (seq.++ ?x1095 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x32396 ?x514)))))))
 (let ((?x2550 (seq.unit (_ bv128 8))))
 (let ((?x3459 (seq.++ ?x306 (seq.++ ?x2550 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x306))))))
 (let ((?x1074 (seq.unit (_ bv205 8))))
 (let ((?x2980 (seq.unit (_ bv171 8))))
 (let ((?x32483 (seq.unit (_ bv52 8))))
 (let ((?x32374 (seq.unit (_ bv18 8))))
 (let ((?x2373 (seq.++ ?x32374 (seq.++ ?x32483 (seq.++ ?x2980 (seq.++ ?x1074 ?x3459))))))
 (let ((?x3317 (seq.unit (_ bv118 8))))
 (let ((?x3120 (seq.++ ?x3317 ?x2373)))
 (let ((?x32766 (seq.++ ?x306 (seq.++ ?x306 (seq.++ (seq.unit (_ bv66 8)) ?x3120)))))
 (let (($x32825 (= v_1_L.echo_icmp_wire ?x32766)))
 (let (($x32824 (= v_1_L.echo_icmp_zero (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x306 ?x2373)))))))
 (let ((?x32807 (seq.++ ?x2313 (seq.++ ?x3023 (seq.++ ?x306 (seq.++ ?x2484 (seq.++ ?x2484 ?x32766)))))))
 (let ((?x32129 (seq.unit (_ bv216 8))))
 (let ((?x32812 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x32129 (seq.++ ?x3023 (seq.++ ?x306 (seq.++ ?x2484 ?x32807)))))))
 (let ((?x32817 (seq.++ ?x306 (seq.++ ?x1097 (seq.++ ?x306 (seq.++ ?x1097 (seq.++ ?x2313 ?x32812)))))))
 (let ((?x32822 (seq.++ ?x1095 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x32396 (seq.++ ?x306 ?x32817)))))))
 (let (($x32823 (= v_1_L.echo_reply ?x32822)))
 (let (($x3344 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x3343 (not v_1_L.rxudp_require_checksum)))
 (let (($x3204 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x3811 (= v_1_L.ip_checksum 0)))
 (let (($x3599 (= v_1_L.udp_checksum 0)))
 (let (($x3595 (= v_1_L.udp_raw_checksum 0)))
 (let (($x3902 (= v_1_L.ip_length 0)))
 (let (($x3903 (= v_1_L.udp_length 0)))
 (let (($x2687 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x3001 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x2982 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x2882 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x1085 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x31963 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x2984 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x3652 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x3653 (= v_1_L.retry_count 0)))
 (let (($x2881 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x600 (= 0 state_1)))
 (let (($x31928 (not active_0_T.time_wait)))
 (let (($x3194 (or $x31928 (not (<= due_0_T.time_wait 0)))))
 (let (($x3490 (not active_0_T.user)))
 (let (($x2981 (or $x3490 (not (<= due_0_T.user 0)))))
 (let (($x3491 (not active_0_T.rtx)))
 (let (($x3488 (or $x3491 (not (<= due_0_T.rtx 0)))))
 (let (($x3492 (not active_0_L.cache)))
 (let (($x31775 (or $x3492 (not (<= due_0_L.cache 0)))))
 (let (($x2318 (not active_0_L.query)))
 (let (($x3033 (or $x2318 (not (<= due_0_L.query 0)))))
 (let (($x32609 (= state_0 0)))
 (and $x32609 (>= 0 now_0) $x3033 $x31775 $x3488 $x2981 $x3194 $x600 $x2881 $x3653 $x3652 v_1_L.checksums_enabled $x2984 $x31963 $x1085 $x2882 $x2982 $x3001 $x2687 $x3903 $x3902 $x3595 $x3599 $x3811 $x3204 $x3343 $x3344 (= v_1_L.rxudp_disposition "none") $x32823 $x32824 $x32825 $x32826 $x626 $x627 $x4044 $x4046 $x4043 $x4031 $x4022 $x4021 $x4035 (= v_1_T.tx_flags "S") $x3921 $x3920 v_1_T.active_open $x3649 $x3646 $x3625 $x32827 $x32828 $x32829 $x3640 $x3624 $x3623 $x3622 $x32830 $x32831 $x32832 $x32833 $x32834 $x32835 $x32836 $x3611 (= v_1_T.wire_disposition "none") (= v_1_T.control "CLOSED") (= v_1_ip_pending_owner "none") $x666 $x667 $x668 $x669 $x670 $x671 $x678 $x679 $x680 $x681)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 54 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2550 (seq.unit (_ bv128 8))))
(let ((?x3458 (seq.++ ?x2550 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x306 (seq.unit (_ bv0 8))))
(let ((?x1074 (seq.unit (_ bv205 8))))
(let ((?x2980 (seq.unit (_ bv171 8))))
(let ((?x32483 (seq.unit (_ bv52 8))))
(let ((?x32374 (seq.unit (_ bv18 8))))
(let ((?x2373 (seq.++ ?x32374 (seq.++ ?x32483 (seq.++ ?x2980 (seq.++ ?x1074 (seq.++ ?x306 ?x3458)))))))
(let ((?x3317 (seq.unit (_ bv118 8))))
(let ((?x3120 (seq.++ ?x3317 ?x2373)))
(let ((?x994 (seq.unit (_ bv58 8))))
(let ((?x3511 (seq.unit (_ bv8 8))))
(let ((?x2313 (seq.unit (_ bv1 8))))
(let ((?x2484 (seq.unit (_ bv2 8))))
(let ((?x32578 (seq.++ ?x2484 (seq.++ ?x2313 (seq.++ ?x3511 (seq.++ ?x306 (seq.++ ?x994 ?x3120)))))))
(let ((?x3023 (seq.unit (_ bv192 8))))
(let ((?x31773 (seq.++ ?x306 (seq.++ ?x2484 (seq.++ ?x2484 (seq.++ ?x3023 (seq.++ ?x306 ?x32578)))))))
(let ((?x32129 (seq.unit (_ bv216 8))))
(let ((?x32376 (seq.unit (_ bv245 8))))
(let ((?x31857 (seq.++ ?x2313 (seq.++ ?x2313 (seq.++ ?x32376 (seq.++ ?x32129 (seq.++ ?x3023 ?x31773)))))))
(let ((?x1097 (seq.unit (_ bv64 8))))
(let ((?x2336 (seq.unit (_ bv255 8))))
(let ((?x32396 (seq.unit (_ bv33 8))))
(let ((?x32649 (seq.++ ?x32396 (seq.++ ?x2336 (seq.++ ?x2336 (seq.++ ?x1097 (seq.++ ?x306 ?x31857)))))))
(let ((?x1095 (seq.unit (_ bv69 8))))
(let ((?x3465 (seq.++ ?x3511 (seq.++ ?x306 (seq.++ ?x1095 (seq.++ ?x306 (seq.++ ?x306 ?x32649)))))))
(let ((?x2338 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x2484 ?x3465)))))))
(let ((?x189 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x306 (seq.++ ?x2313 (seq.++ ?x2484 ?x2338)))))))
(let ((?x3509 (seq.++ ?x2484 (seq.++ ?x306 ?x189))))
(= input_0_L.net.frame_frame ?x3509)))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x1099 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x1098 (= due_1_T.user due_0_T.user)))
 (let (($x1097 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x1096 (= due_1_L.cache due_0_L.cache)))
 (let (($x1102 (= due_1_L.query due_0_L.query)))
 (let (($x1095 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x1094 (= active_1_T.user active_0_T.user)))
 (let (($x1093 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x1092 (= active_1_L.cache active_0_L.cache)))
 (let (($x1091 (= active_1_L.query active_0_L.query)))
 (let (($x2816 (= v_1_T.wire_flags 0)))
 (let (($x32690 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x32689 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x32688 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x32687 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x32686 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x32685 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x32684 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x2827 (= v_1_T.take 0)))
 (let (($x2828 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x2829 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x2845 (= v_1_T.snd_wnd 8)))
 (let (($x32683 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x32682 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x32681 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x2830 (= v_1_T.local_window 16)))
 (let (($x2851 (= v_1_T.msl_ms 60000)))
 (let (($x2854 (= v_1_T.user_timeout_ms 30000)))
 (let (($x2858 (= v_1_T.retries 0)))
 (let (($x2846 (= v_1_T.rto_ms 1000)))
 (let (($x2861 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x2870 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x2871 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x2872 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x2867 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x2873 (= v_1_T.irs (_ bv0 32))))
 (let (($x2874 (= v_1_T.iss (_ bv1000 32))))
 (let (($x1058 (= v_1_L.control "EMPTY")))
 (let (($x1057 (= v_1_L.echo_disposition "reply")))
 (let ((?x137 (seq.unit (_ bv192 8))))
 (let ((?x140 (seq.++ ?x137 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x2440 (seq.unit (_ bv1 8))))
 (let ((?x890 (seq.unit (_ bv2 8))))
 (let ((?x889 (seq.unit (_ bv0 8))))
 (let ((?x946 (seq.++ ?x889 (seq.++ ?x137 (seq.++ ?x889 (seq.++ ?x890 (seq.++ ?x2440 ?x140)))))))
 (let ((?x505 (seq.unit (_ bv64 8))))
 (let ((?x951 (seq.++ ?x505 (seq.++ ?x889 (seq.++ ?x505 (seq.++ ?x2440 (seq.++ ?x889 ?x946)))))))
 (let ((?x953 (seq.++ ?x889 (seq.++ ?x889 ?x951))))
 (let ((?x2421 (seq.unit (_ bv28 8))))
 (let ((?x499 (seq.unit (_ bv69 8))))
 (let (($x32680 (= v_1_L.echo_ip_zero (seq.++ ?x499 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x2421 ?x953)))))))
 (let ((?x32126 (seq.unit (_ bv18 8))))
 (let ((?x31917 (seq.++ ?x32126 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x32246 (seq.unit (_ bv254 8))))
 (let ((?x31918 (seq.++ ?x32246 ?x31917)))
 (let ((?x32620 (seq.++ ?x889 (seq.++ ?x889 (seq.++ (seq.unit (_ bv65 8)) ?x31918)))))
 (let (($x32679 (= v_1_L.echo_icmp_wire ?x32620)))
 (let (($x32678 (= v_1_L.echo_icmp_zero (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x889 ?x31917)))))))
 (let ((?x32661 (seq.++ ?x2440 (seq.++ ?x137 (seq.++ ?x889 (seq.++ ?x890 (seq.++ ?x890 ?x32620)))))))
 (let ((?x2619 (seq.unit (_ bv221 8))))
 (let ((?x32666 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x2619 (seq.++ ?x137 (seq.++ ?x889 (seq.++ ?x890 ?x32661)))))))
 (let ((?x32671 (seq.++ ?x889 (seq.++ ?x505 (seq.++ ?x889 (seq.++ ?x505 (seq.++ ?x2440 ?x32666)))))))
 (let ((?x32676 (seq.++ ?x499 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x2421 (seq.++ ?x889 ?x32671)))))))
 (let (($x32677 (= v_1_L.echo_reply ?x32676)))
 (let (($x32234 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x31746 (not v_1_L.rxudp_require_checksum)))
 (let (($x31868 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x2892 (= v_1_L.ip_checksum 0)))
 (let (($x2893 (= v_1_L.udp_checksum 0)))
 (let (($x2895 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2897 (= v_1_L.ip_length 0)))
 (let (($x2898 (= v_1_L.udp_length 0)))
 (let (($x31867 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x31869 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x32207 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x32060 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x31979 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x31978 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x2681 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x2915 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x2916 (= v_1_L.retry_count 0)))
 (let (($x31872 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x1032 (= 0 state_1)))
 (let (($x2444 (not active_0_T.time_wait)))
 (let (($x31899 (or $x2444 (not (<= due_0_T.time_wait 0)))))
 (let (($x32295 (not active_0_T.user)))
 (let (($x32010 (or $x32295 (not (<= due_0_T.user 0)))))
 (let (($x32294 (not active_0_T.rtx)))
 (let (($x32007 (or $x32294 (not (<= due_0_T.rtx 0)))))
 (let (($x32293 (not active_0_L.cache)))
 (let (($x32004 (or $x32293 (not (<= due_0_L.cache 0)))))
 (let (($x2429 (not active_0_L.query)))
 (let (($x32000 (or $x2429 (not (<= due_0_L.query 0)))))
 (let (($x265 (= state_0 0)))
 (and $x265 (>= 0 now_0) $x32000 $x32004 $x32007 $x32010 $x31899 $x1032 $x31872 $x2916 $x2915 v_1_L.checksums_enabled $x2681 $x31978 $x31979 $x32060 $x32207 $x31869 $x31867 $x2898 $x2897 $x2895 $x2893 $x2892 $x31868 $x31746 $x32234 (= v_1_L.rxudp_disposition "none") $x32677 $x32678 $x32679 $x32680 $x1057 $x1058 $x2874 $x2873 $x2867 $x2872 $x2871 $x2870 $x2861 (= v_1_T.tx_flags "S") $x2846 $x2858 v_1_T.active_open $x2854 $x2851 $x2830 $x32681 $x32682 $x32683 $x2845 $x2829 $x2828 $x2827 $x32684 $x32685 $x32686 $x32687 $x32688 $x32689 $x32690 $x2816 (= v_1_T.wire_disposition "none") (= v_1_T.control "CLOSED") (= v_1_ip_pending_owner "none") $x1091 $x1092 $x1093 $x1094 $x1095 $x1102 $x1096 $x1097 $x1098 $x1099))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 54 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x32126 (seq.unit (_ bv18 8))))
(let ((?x31917 (seq.++ ?x32126 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
(let ((?x32246 (seq.unit (_ bv254 8))))
(let ((?x31918 (seq.++ ?x32246 ?x31917)))
(let ((?x283 (seq.unit (_ bv57 8))))
(let ((?x889 (seq.unit (_ bv0 8))))
(let ((?x2515 (seq.unit (_ bv8 8))))
(let ((?x2440 (seq.unit (_ bv1 8))))
(let ((?x890 (seq.unit (_ bv2 8))))
(let ((?x31923 (seq.++ ?x890 (seq.++ ?x2440 (seq.++ ?x2515 (seq.++ ?x889 (seq.++ ?x283 ?x31918)))))))
(let ((?x137 (seq.unit (_ bv192 8))))
(let ((?x31928 (seq.++ ?x889 (seq.++ ?x890 (seq.++ ?x890 (seq.++ ?x137 (seq.++ ?x889 ?x31923)))))))
(let ((?x2619 (seq.unit (_ bv221 8))))
(let ((?x177 (seq.unit (_ bv245 8))))
(let ((?x31933 (seq.++ ?x2440 (seq.++ ?x2440 (seq.++ ?x177 (seq.++ ?x2619 (seq.++ ?x137 ?x31928)))))))
(let ((?x505 (seq.unit (_ bv64 8))))
(let ((?x2691 (seq.unit (_ bv255 8))))
(let ((?x2421 (seq.unit (_ bv28 8))))
(let ((?x181 (seq.++ ?x2421 (seq.++ ?x2691 (seq.++ ?x2691 (seq.++ ?x505 (seq.++ ?x889 ?x31933)))))))
(let ((?x499 (seq.unit (_ bv69 8))))
(let ((?x2442 (seq.++ ?x2515 (seq.++ ?x889 (seq.++ ?x499 (seq.++ ?x889 (seq.++ ?x889 ?x181)))))))
(let ((?x2481 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x890 ?x2442)))))))
(let ((?x217 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x889 (seq.++ ?x2440 (seq.++ ?x890 ?x2481)))))))
(let ((?x32013 (seq.++ ?x890 (seq.++ ?x889 ?x217))))
(= input_0_L.net.frame_frame ?x32013))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (let ((?x405 (seq.unit (_ bv8 8))))
 (let ((?x613 (seq.++ ?x405 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv6 8)) (seq.unit (_ bv4 8)))))))
 (let ((?x397 (seq.unit (_ bv1 8))))
 (let ((?x370 (seq.unit (_ bv0 8))))
 (let ((?x407 (seq.unit (_ bv6 8))))
 (let ((?x617 (seq.++ ?x405 (seq.++ ?x407 (seq.++ ?x370 (seq.++ ?x397 ?x613))))))
 (= (seq.extract input_0_L.net.frame_frame 12 8) ?x617))))))))
(assert
 (let ((?x370 (seq.unit (_ bv0 8))))
(let ((?x405 (seq.unit (_ bv8 8))))
(let ((?x900 (seq.++ ?x405 ?x370)))
(let ((?x7513 (seq.extract input_0_L.net.frame_frame 12 2)))
(= ?x7513 ?x900))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (let ((?x370 (seq.unit (_ bv0 8))))
 (let ((?x405 (seq.unit (_ bv8 8))))
 (let ((?x900 (seq.++ ?x405 ?x370)))
 (let ((?x6415 (seq.extract input_0_L.net.frame_frame 34 2)))
 (= ?x6415 ?x900))))))
(assert
 (let ((?x1056 (seq.unit (_ bv144 8))))
(let ((?x1054 (seq.unit (_ bv31 8))))
(let ((?x1598 (seq.++ ?x1054 ?x1056)))
(let ((?x6415 (seq.extract input_0_L.net.frame_frame 34 2)))
(= ?x6415 ?x1598))))))
(check-sat)

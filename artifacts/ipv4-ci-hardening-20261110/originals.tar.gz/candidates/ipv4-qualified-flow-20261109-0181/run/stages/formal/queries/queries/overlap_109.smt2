; benchmark generated from python API
(set-info :status unknown)
(declare-fun input_0_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (let ((?x370 (seq.unit (_ bv0 8))))
 (let ((?x405 (seq.unit (_ bv8 8))))
 (let ((?x900 (seq.++ ?x405 ?x370)))
 (let ((?x6415 (seq.extract input_0_L.net.frame_frame 34 2)))
 (= ?x6415 ?x900))))))
(assert
 (let ((?x1054 (seq.unit (_ bv31 8))))
(let ((?x1061 (seq.++ ?x1054 (seq.++ (seq.unit (_ bv144 8)) (seq.++ (seq.unit (_ bv156 8)) (seq.unit (_ bv64 8)))))))
(let ((?x5934 (seq.extract input_0_L.net.frame_frame 34 4)))
(= ?x5934 ?x1061)))))
(check-sat)

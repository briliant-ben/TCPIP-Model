from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/ipv4-qualified-flow-20261109-0181';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def st(**x):save('status.json',dict(pid=os.getpid(),updated_at=time.time(),production_modified=False,network_executed=False,automatic_API_retry=False,**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(status='running',stage='frozen_current_source_validation',API_in_progress=False)
try:
 archive=P/'incoming/qualified-source-0181.tar.gz';assert sha(archive)=='93dea8916734cddb7c6b03f439bf79d2f525791700c38a847f3cbf485f2d3d87'
 mf=P/'incoming/qualified-source-manifest-0181.json';manifest=json.loads(mf.read_text());save('source-manifest.json',manifest);W=O/'workspace';W.mkdir()
 with tarfile.open(archive)as tar:
  members=tar.getmembers();assert len(members)==len(manifest) and len({m.name for m in members})==len(members)
  for m in members:
   assert m.isfile()and m.name in manifest and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts
   target=W/m.name;target.parent.mkdir(parents=True,exist_ok=True);data=tar.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name];target.write_bytes(data)
 env=dict(os.environ,PYTHONPATH=str(W),PYTHONDONTWRITEBYTECODE='1')
 for pat in ['test_initial_*.py','test_reference_observation.py','test_pipeline.py','test_sequence_induction.py','test_symbolic_timer_replay.py','test_symbolic_witness.py','test_formal_cli_journal.py']:
  st(status='running',stage='actual_unittest',pattern=pat,API_in_progress=False)
  r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p',pat,'-v'],cwd=W,env=env,capture_output=True,text=True,timeout=600)
  (O/(pat.replace('*','all')+'.stdout')).write_text(r.stdout);(O/(pat.replace('*','all')+'.stderr')).write_text(r.stderr)
  if r.returncode:raise ValueError('Actual unittest failed:'+pat)
 st(status='running',stage='actual_ten_stage_finite_ipv4_flow',API_in_progress=False)
 sys.path.insert(0,str(W));from protocol_lab.pipeline.runner import run,verify
 task=W/'flows/ipv4-prototype-closeout.json';pin=sha(task);r=run(task,W,O/'run',pin);save('actual-flow-summary.json',dict(assessment=r['assessment'],stages={n:dict(status=v['status'],classification=v['classification'])for n,v in r['stages'].items()},task_sha256=pin))
 assert r['stages']['formal']['status']=='pass',str(r['stages']['formal'])[:500]
 assert all(v['status']=='pass' for n,v in r['stages'].items()if n!='tests')
 assert r['stages']['tests']['status'] in ['pass','unknown'];v=verify(O/'run',W,pin);save('actual-verification.json',v)
 formal=r['stages']['formal']['data'];assert formal['status']=='initial_step_contracts_pass'

 old=P/'candidates/ipv4-qualified-flow-20261109-0179/run';new=O/'run'
 refrows=json.loads((new/'stages/reference/result.json').read_text())['data']['cases'];assert len(refrows)==77
 for row in refrows:
  relative=row['path'];assert (new/relative).read_bytes()==(old/relative).read_bytes(),relative
 save('reference-equivalence.json',dict(cases=77,comparison='BYTE_IDENTICAL to original accepted reference JSON, including literal checked traces, every operation snapshot, initial/final and negative error',old_source='bcf0ce25',new_source='938dfe57',no_checks_removed=True))
 names=['choice_cover']+['safety_'+str(i)for i in list(range(335))+[-1,-2]]+['original_safety','original_overlap']
 for name in names:
  relative='stages/formal/queries/queries/'+name+'.smt2';assert (new/relative).read_bytes()==(old/relative).read_bytes(),name
 import z3
 from protocol_lab.initial_overlap import necessary_literal_clash
 derived=[]
 for i in range(225):
  relative='stages/formal/queries/queries/overlap_'+str(i)+'.smt2';ctx=z3.Context();a=z3.parse_smt2_string((old/relative).read_text(),ctx=ctx);b=z3.parse_smt2_string((new/relative).read_text(),ctx=ctx);parts=[]
  def flatten(e):
   if z3.is_and(e):
    for child in e.children():flatten(child)
   else:parts.append(e)
  flatten(a[0]);row=formal['queries'][338+i]
  assert row['id']=='overlap_'+str(i)
  if row['derivation']=='necessary_literal_conjunct_pair':
   assert len(b)==2 and all(any(z3.simplify(x).eq(z3.simplify(y))for y in parts)for x in b),i;derived.append(i)
  else:assert len(b)==1 and z3.simplify(a[0]).eq(z3.simplify(b[0])),i
 save('query-equivalence.json',dict(original_globals_and_safety_queries_byte_identical=340,overlap_leaves=225,necessary_original_conjunct_pairs=len(derived),unchanged_leafs=225-len(derived),input_domain_or_budget_changed=False,solver_checks_for_this_audit=0))

 summary=dict(status='actual_flow_contracts_pass_execution_coverage_separately_unresolved',formal_status=formal['status'],counts=formal['counts'],task_sha256=pin,old_task_unchanged=True,new_flow_assessment=r['assessment'],cases=len(r['stages']['tests']['data']['cases']),scope='Finite initialized1step; literal native/reference paths; no new network/compiler/deeper/unbounded proof');save('summary.json',summary)
 st(status='running',stage='independent_DeepSeek_final_review',API_in_progress=True)
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 payload=dict(actual=summary,checker=(W/'protocol_lab/initial_step.py').read_text(),overlap_helper=(W/'protocol_lab/initial_overlap.py').read_text(),reference_observer=(W/'protocol_lab/flow.py').read_text().split('def run_scenario',1)[1].split('def build',1)[0],reference_stage=(W/'protocol_lab/pipeline/worker.py').read_text().split("    if name=='reference':",1)[1].split("    if name=='generate':",1)[0],reference_equivalence=json.loads((O/'reference-equivalence.json').read_text()),query_equivalence=json.loads((O/'query-equivalence.json').read_text()),planner=(W/'protocol_lab/initial_plan.py').read_text(),units=(W/'protocol_lab/initial_units.py').read_text(),controller_tests=(W/'tests/test_initial_step.py').read_text(),integration_delta=dict(task='explicit spec-flow-task-v5; formalinitial-step-contracts; fixed depth1 defaults; oldschemas unchanged',worker=(W/'protocol_lab/pipeline/worker.py').read_text().split("    if name=='formal':",1)[1].split("    if name=='tests':",1)[0],verifier=(W/'protocol_lab/pipeline/runner.py').read_text().split("        expected_formal=",1)[1].split("        if name=='sources'",1)[0]),scope=(W/'docs/ipv4-prototype-acceptance.md').read_text(),questions=['Find concrete soundness/evidence weaknesses; distinguish alltyped initializeddepth1 vsallstate/deeperproof, no domainshrinking. Each225overlapleaf strongerUNSAT; complete337choice split +exhaustion +nonvac strictreplay. Do not call missing deeperproof a blocking when explicitlyexcluded.', 'Actual immutable source gated relevant old/new unittest and actualflow+verify. Old UNKNOWN preserved, oldtask unchanged; newflowstillunresolved coverage. Approval is for scopedbackend/prototype delivery contract, notcompleteTCP/IP proof.', 'Query journal trust explicitly consistency not externalexecutionattestation; coherentforgeryneeds provenance/certificates. Report real currentdefects, no inventedmodules/API. Output exactly blocking/findings/limitations arrays, no source.'])
 ms=[dict(role='system',content='Independent final technical review. ExactJSON blocking/findings/limitations lists. Only concrete actionable defects, no blanket proofoverclaim or patches.'),dict(role='user',content=json.dumps(payload))];save('review-messages.json',ms)
 rr=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=10000,thinking='disabled',reasoning_effort=None,timeout=900);a=json.loads((P/'private/api-ledger'/rr['response_file']).read_text())['response'];save('review-response.json',a);save('review-usage.json',{k:rr.get(k)for k in ['usage','cached','request_sha256']});assert set(a)=={'blocking','findings','limitations'}and all(type(v)is list for v in a.values());st(status='review_rejected'if a['blocking']else'validated_source_requires_controller_approval',stage='finished',API_in_progress=False)
except Exception as e:st(status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__,error=str(e)[:1200],API_in_progress=False);(O/'traceback.txt').write_text(traceback.format_exc());raise

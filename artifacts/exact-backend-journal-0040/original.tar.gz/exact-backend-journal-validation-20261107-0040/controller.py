from pathlib import Path
import json,os,subprocess,time
out=Path(__file__).parent;w=out/"workspace"
def state(**kw):(out/"status.json").write_text(json.dumps(dict(provider="controller-zeroAPI",pid=os.getpid(),production_modified=False,**kw),indent=2))
state(status="running",stage="actual_tests");codes={}
try:
 for pattern in ("test_solver_query_journal.py","test_solver_preprocessing.py"):
  with(out/(pattern+".log")).open("w")as log:
   r=subprocess.run(["/home/blxu/protocol-flow/releases/udp-transmit-1b13a36f/venv/bin/python","-m","unittest","discover","-s","tests","-p",pattern,"-v"],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=360,env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"})
   codes[pattern]=r.returncode
 state(status="controller_review_required",stage="tests_finished",test_returncodes=codes,finished_at=time.time())
except Exception as e:state(status="controller_review_required",stage="test_exception",error_type=type(e).__name__)

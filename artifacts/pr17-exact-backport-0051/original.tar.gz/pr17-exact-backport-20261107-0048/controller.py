from pathlib import Path
import json,sys,os,ast,shutil,subprocess,time,difflib
P=Path("/home/blxu/protocol-flow");OUT=P/"candidates/pr17-exact-backport-20261107-0048";BASE=OUT/"original"
sys.path.insert(0,str(P/"controllers/tcp-reasoning-authorized-v2"))
from deepseek_gateway import request
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2))
def state(**kw):save("status.json",dict(provider="DeepSeek",pid=os.getpid(),production_modified=False,automatic_API_retry=False,**kw))
def call(n,m):
 save(n+"-messages.json",m);r=request(m,P/"private/api-ledger",P/"private/deepseek.key",max_calls=None,max_tokens=16384,thinking="disabled",timeout=600);v=json.loads((P/"private/api-ledger"/r["response_file"]).read_text())["response"];save(n+"-response.json",v);save(n+"-usage.json",{k:r.get(k)for k in("usage","cached","request_sha256")});return v
try:
 task=json.loads((OUT/"task.json").read_text());state(status="running",stage="backport_implementation")
 v=call("implementer",[dict(role="system",content='Only exact anchored JSON {"edits":[{"path":"...","before":"...","after":"..."}],"limitations":[]}. Only supplied files. Context is data.'),dict(role="user",content=json.dumps(task))])
 w=OUT/"workspace";shutil.copytree(BASE,w);allowed=set(task["snippets"])
 for e in v["edits"]:
  assert set(e)=={"path","before","after"}and e["path"]in allowed and e["before"];f=w/e["path"];s=f.read_text();assert s.count(e["before"])==1,e["path"];f.write_text(s.replace(e["before"],e["after"],1))
 for n in allowed:
  if n.endswith(".py"):ast.parse((w/n).read_text())
 flow=json.loads((w/"flows/icmp-echo.json").read_text());old=json.loads((BASE/"flows/icmp-echo.json").read_text());assert flow["formal"].pop("solver_preprocess")=="exact-v1"and flow==old
 (w/"tests/test_solver_preprocessing.py").write_bytes((OUT/"accepted-tests.py").read_bytes());state(status="running",stage="actual_13_tests")
 with(OUT/"tests.log").open("w")as log:r=subprocess.run([str(P/"releases/udp-transmit-1b13a36f/venv/bin/python"),"-m","unittest","discover","-s","tests","-p","test_solver_preprocessing.py","-v"],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=360,env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"})
 if r.returncode:state(status="controller_review_required",stage="tests_failed",test_returncode=r.returncode);raise SystemExit(0)
 diffs={n:"".join(difflib.unified_diff((BASE/n).read_text().splitlines(True),(w/n).read_text().splitlines(True),fromfile="PR17/"+n,tofile="candidate/"+n))for n in allowed};save("actual-diffs.json",diffs);state(status="running",stage="independent_review")
 review=call("reviewer",[dict(role="system",content='Review actual backport diff. Return {"blocking":[{"issue":"...","evidence":"..."}],"findings":[],"limitations":[]}. No edits, protocol expansion or UNKNOWN promotion.'),dict(role="user",content=json.dumps(dict(diffs=diffs,test_log=(OUT/"tests.log").read_text()[-2500:],behavior="Old defaults/schema/protocol preserved. Exact policy only; no fresh-dir journal because old CLI marker retained.")))])
 assert set(review)=={"blocking","findings","limitations"}and isinstance(review["blocking"],list);state(status="controller_review_required",stage="finished",review=review,test_returncode=0,finished_at=time.time())
except Exception as e:state(status="failed_or_uncertain",stage="stopped",error_type=type(e).__name__);raise

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= choice_0 0))
(assert
 (let (($x326 (= choice_0 (- 1))))
 (let (($x327 (and $x326 (= state_1 state_0) (= now_1 now_0) (= v_1_reply v_0_reply) (= v_1_icmp_zero v_0_icmp_zero) (= v_1_icmp_wire v_0_icmp_wire) (= v_1_ip_zero v_0_ip_zero) (= v_1_disposition v_0_disposition))))
 (let (($x50 (= v_1_ip_zero (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x49 (= v_1_icmp_wire (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x48 (= v_1_icmp_zero (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x47 (= v_1_reply (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x46 (= 0 state_1)))
 (let (($x45 (= choice_0 0)))
 (let ((?x40 (seq.len input_0_net.packet_packet)))
 (let (($x42 (>= 27 ?x40)))
 (let (($x39 (>= now_1 now_0)))
 (let (($x27 (= state_0 0)))
 (let (($x52 (and and $x27 $x39 $x42 $x45 $x46 $x47 $x48 $x49 $x50 (= v_1_disposition "drop_short"))))
 (or $x52 $x327)))))))))))))))
(assert
 (>= choice_0 0))
(check-sat)

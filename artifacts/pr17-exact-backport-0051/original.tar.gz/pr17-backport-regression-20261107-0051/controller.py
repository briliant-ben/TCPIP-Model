from pathlib import Path
import json,subprocess,os,time,hashlib
out=Path(__file__).parent;w=out/"workspace";codes={}
def state(**kw):(out/"status.json").write_text(json.dumps(dict(pid=os.getpid(),paid_requests=0,production_modified=False,results=codes,**kw),indent=2))
py="/home/blxu/protocol-flow/releases/udp-transmit-1b13a36f/venv/bin/python"
env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"}
for pattern in json.loads((out/"task.json").read_text())["patterns"]:
 state(status="running",stage=pattern)
 with(out/(pattern+".log")).open("w")as log:
  try:r=subprocess.run([py,"-m","unittest","discover","-s","tests","-p",pattern,"-v"],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=600,env=env);codes[pattern]=dict(returncode=r.returncode)
  except subprocess.TimeoutExpired:codes[pattern]=dict(status="timeout",no_retry=True)
state(status="running",stage="actual_ICMP_ten_stage_flow")
task=w/"flows/icmp-echo.json";pin=hashlib.sha256(task.read_bytes()).hexdigest()
with(out/"flow.log").open("w")as log:
 try:r=subprocess.run([py,str(w/"examples/run_spec_candidate.py"),"--workspace",str(w),"--task",str(task),"--task-sha256",pin,"--out",str(out/"flow")],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=600,env=env);codes["actual_flow"]=dict(returncode=r.returncode)
 except subprocess.TimeoutExpired:codes["actual_flow"]=dict(status="timeout",no_retry=True)
state(status="controller_review_required",stage="finished",all_pass=all(v.get("returncode")==0 for v in codes.values()),finished_at=time.time())

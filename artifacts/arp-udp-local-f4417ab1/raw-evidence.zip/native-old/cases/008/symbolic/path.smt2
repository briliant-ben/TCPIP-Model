; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x699 (= due_1_cache 60000)))
 (let (($x656 (= due_1_query due_0_query)))
 (let (($x680 (not active_1_query)))
 (let (($x1622 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x574 (= v_1_ip_checksum 0)))
 (let (($x1296 (= v_1_udp_checksum 0)))
 (let (($x109 (= v_1_udp_raw_checksum 0)))
 (let (($x1071 (= v_1_ip_length 0)))
 (let (($x454 (= v_1_udp_length 0)))
 (let (($x582 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x802 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1086 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1108 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1618 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1617 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x531 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1237 (= v_1_cache_ttl_ms 60000)))
 (let (($x773 (= 0 v_1_retry_count)))
 (let ((?x749 (seq.unit (_ bv0 8))))
 (let ((?x1611 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.unit (_ bv2 8))))))))
 (let ((?x963 (seq.unit (_ bv2 8))))
 (let (($x904 (= v_1_peer_mac (seq.++ ?x963 ?x1611))))
 (let (($x745 (= 2 state_1)))
 (let (($x157 (not active_0_cache)))
 (let (($x796 (or $x157 (not (<= due_0_cache 0)))))
 (let (($x1147 (not active_0_query)))
 (let (($x1111 (or $x1147 (not (<= due_0_query 0)))))
 (let (($x259 (= state_0 0)))
 (and $x259 (>= 0 now_0) $x1111 $x796 $x745 $x904 $x773 $x1237 v_1_checksums_enabled $x531 $x1617 $x1618 $x1108 $x1086 $x802 $x582 $x454 $x1071 $x109 $x1296 $x574 $x1622 $x680 active_1_cache $x656 $x699))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x395 (= due_2_query due_1_query)))
 (let (($x1363 (not active_2_query)))
 (let (($x1417 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x215 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1102 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x889 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x888 (= v_2_ip_length v_1_ip_length)))
 (let (($x456 (= v_2_udp_length v_1_udp_length)))
 (let (($x1072 (= v_2_packet v_1_packet)))
 (let (($x911 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1408 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x502 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x434 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x169 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1055 (= v_2_payload v_1_payload)))
 (let (($x1054 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x931 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1410 (= 0 v_2_retry_count)))
 (let ((?x749 (seq.unit (_ bv0 8))))
 (let ((?x607 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.unit (_ bv3 8))))))))
 (let ((?x963 (seq.unit (_ bv2 8))))
 (let (($x639 (= v_2_peer_mac (seq.++ ?x963 ?x607))))
 (let (($x801 (= 2 state_2)))
 (let (($x774 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x680 (not active_1_query)))
 (let (($x1083 (or $x680 (not (<= due_1_query 5)))))
 (let (($x327 (= state_1 2)))
 (and $x327 $x1083 $x774 $x801 $x639 $x1410 $x931 $x1054 $x1055 $x169 $x434 $x502 $x1408 $x911 $x1072 $x456 $x888 $x889 $x1102 $x215 $x1417 $x1363 active_2_cache $x395 (= due_2_cache (+ 5 v_1_cache_ttl_ms)))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1558 (= due_3_cache due_2_cache)))
 (let (($x1542 (= due_3_query due_2_query)))
 (let (($x1551 (= active_3_cache active_2_cache)))
 (let (($x1550 (= active_3_query active_2_query)))
 (let (($x1478 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x251 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x408 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x51 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x738 (= v_3_ip_length v_2_ip_length)))
 (let (($x1179 (= v_3_udp_length v_2_udp_length)))
 (let (($x1256 (= v_3_packet v_2_packet)))
 (let (($x117 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x1258 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x1175 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x118 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1181 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x264 (= v_3_payload v_2_payload)))
 (let (($x70 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x1536 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x88 (= v_3_retry_count v_2_retry_count)))
 (let (($x742 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x1252 (= 2 state_3)))
 (let (($x111 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x1363 (not active_2_query)))
 (let (($x1103 (or $x1363 (not (<= due_2_query 10)))))
 (let (($x1089 (= state_2 2)))
 (and $x1089 $x1103 $x111 $x1252 $x742 $x88 $x1536 $x70 $x264 $x1181 $x118 $x1175 $x1258 $x117 $x1256 $x1179 $x738 $x51 $x408 $x251 $x1478 $x1550 $x1551 $x1542 $x1558))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x393 (seq.unit (_ bv192 8))))
 (let ((?x1361 (seq.++ ?x393 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x716 (seq.unit (_ bv1 8))))
 (let ((?x749 (seq.unit (_ bv0 8))))
 (let ((?x31 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x716 ?x1361)))))))
 (let ((?x963 (seq.unit (_ bv2 8))))
 (let ((?x303 (seq.++ ?x393 (seq.++ ?x749 (seq.++ ?x963 (seq.++ ?x963 (seq.++ ?x963 ?x31)))))))
 (let ((?x249 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x963 ?x303)))))))
 (let ((?x473 (seq.unit (_ bv4 8))))
 (let ((?x1061 (seq.unit (_ bv6 8))))
 (let ((?x1210 (seq.++ ?x1061 (seq.++ ?x473 (seq.++ ?x749 (seq.++ ?x963 (seq.++ ?x963 ?x249)))))))
 (let ((?x283 (seq.unit (_ bv8 8))))
 (let ((?x1629 (seq.++ ?x1061 (seq.++ ?x749 (seq.++ ?x716 (seq.++ ?x283 (seq.++ ?x749 ?x1210)))))))
 (let ((?x1434 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x963 (seq.++ ?x283 ?x1629)))))))
 (let ((?x1395 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x716 (seq.++ ?x963 (seq.++ ?x749 ?x1434)))))))
 (let ((?x1494 (seq.++ ?x963 (seq.++ ?x749 (seq.++ ?x749 ?x1395)))))
 (= input_0_net.frame_frame ?x1494))))))))))))))))))
(assert
 (= 16 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x393 (seq.unit (_ bv192 8))))
 (let ((?x1361 (seq.++ ?x393 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x716 (seq.unit (_ bv1 8))))
 (let ((?x749 (seq.unit (_ bv0 8))))
 (let ((?x31 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x716 ?x1361)))))))
 (let ((?x963 (seq.unit (_ bv2 8))))
 (let ((?x303 (seq.++ ?x393 (seq.++ ?x749 (seq.++ ?x963 (seq.++ ?x963 (seq.++ ?x963 ?x31)))))))
 (let ((?x202 (seq.unit (_ bv3 8))))
 (let ((?x1167 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x202 ?x303)))))))
 (let ((?x473 (seq.unit (_ bv4 8))))
 (let ((?x1061 (seq.unit (_ bv6 8))))
 (let ((?x1157 (seq.++ ?x1061 (seq.++ ?x473 (seq.++ ?x749 (seq.++ ?x963 (seq.++ ?x963 ?x1167)))))))
 (let ((?x283 (seq.unit (_ bv8 8))))
 (let ((?x268 (seq.++ ?x1061 (seq.++ ?x749 (seq.++ ?x716 (seq.++ ?x283 (seq.++ ?x749 ?x1157)))))))
 (let ((?x1621 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x202 (seq.++ ?x283 ?x268)))))))
 (let ((?x21 (seq.++ ?x749 (seq.++ ?x749 (seq.++ ?x716 (seq.++ ?x963 (seq.++ ?x749 ?x1621)))))))
 (let ((?x629 (seq.++ ?x963 (seq.++ ?x749 (seq.++ ?x749 ?x21)))))
 (= input_1_net.frame_frame ?x629)))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x393 (seq.unit (_ bv192 8))))
(let ((?x274 (seq.++ ?x393 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x274))))
(check-sat)

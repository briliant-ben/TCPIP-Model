; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x158 (= due_1_cache 60000)))
 (let (($x1106 (= due_1_query due_0_query)))
 (let (($x719 (not active_1_query)))
 (let (($x718 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x672 (= v_1_ip_checksum 0)))
 (let (($x835 (= v_1_udp_checksum 0)))
 (let (($x1552 (= v_1_udp_raw_checksum 0)))
 (let (($x1257 (= v_1_ip_length 0)))
 (let (($x62 (= v_1_udp_length 0)))
 (let (($x717 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x677 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x45 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x613 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x44 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x612 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x43 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x453 (= v_1_cache_ttl_ms 60000)))
 (let (($x1149 (= 0 v_1_retry_count)))
 (let ((?x498 (seq.unit (_ bv0 8))))
 (let ((?x1483 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 (seq.unit (_ bv2 8))))))))
 (let ((?x1161 (seq.unit (_ bv2 8))))
 (let (($x611 (= v_1_peer_mac (seq.++ ?x1161 ?x1483))))
 (let (($x1405 (= 2 state_1)))
 (let (($x131 (not active_0_cache)))
 (let (($x42 (or $x131 (not (<= due_0_cache 0)))))
 (let (($x658 (not active_0_query)))
 (let (($x39 (or $x658 (not (<= due_0_query 0)))))
 (let (($x1435 (= state_0 0)))
 (and $x1435 (>= 0 now_0) $x39 $x42 $x1405 $x611 $x1149 $x453 v_1_checksums_enabled $x43 $x612 $x44 $x613 $x45 $x677 $x717 $x62 $x1257 $x1552 $x835 $x672 $x718 $x719 active_1_cache $x1106 $x158))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x307 (seq.unit (_ bv14 8))))
(let ((?x316 (seq.++ ?x307 (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
(let ((?x313 (seq.unit (_ bv13 8))))
(let ((?x884 (seq.unit (_ bv12 8))))
(let ((?x949 (seq.unit (_ bv11 8))))
(let ((?x309 (seq.unit (_ bv10 8))))
(let ((?x806 (seq.unit (_ bv9 8))))
(let ((?x321 (seq.++ ?x806 (seq.++ ?x309 (seq.++ ?x949 (seq.++ ?x884 (seq.++ ?x313 ?x316)))))))
(let ((?x648 (seq.unit (_ bv8 8))))
(let ((?x890 (seq.unit (_ bv7 8))))
(let ((?x1472 (seq.unit (_ bv6 8))))
(let ((?x305 (seq.unit (_ bv5 8))))
(let ((?x66 (seq.unit (_ bv4 8))))
(let ((?x326 (seq.++ ?x66 (seq.++ ?x305 (seq.++ ?x1472 (seq.++ ?x890 (seq.++ ?x648 ?x321)))))))
(let ((?x303 (seq.unit (_ bv3 8))))
(let ((?x1161 (seq.unit (_ bv2 8))))
(let ((?x1147 (seq.unit (_ bv1 8))))
(let ((?x498 (seq.unit (_ bv0 8))))
(let ((?x332 (seq.++ ?x1147 (seq.++ ?x498 (seq.++ ?x1147 (seq.++ ?x1161 (seq.++ ?x303 ?x326)))))))
(let ((?x496 (seq.unit (_ bv192 8))))
(let ((?x820 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x496 (seq.++ ?x498 (seq.++ ?x1161 ?x332)))))))
(let ((?x216 (seq.++ ?x1161 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 ?x820)))))))
(let ((?x661 (seq.++ ?x498 (seq.++ ?x1161 (seq.++ ?x496 (seq.++ ?x498 (seq.++ ?x1161 ?x216)))))))
(let ((?x943 (seq.++ ?x1147 (seq.++ ?x1161 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 ?x661)))))))
(let ((?x125 (seq.++ ?x648 (seq.++ ?x498 (seq.++ ?x1472 (seq.++ ?x66 (seq.++ ?x498 ?x943)))))))
(let ((?x1228 (seq.++ ?x1161 (seq.++ ?x648 (seq.++ ?x1472 (seq.++ ?x498 (seq.++ ?x1147 ?x125)))))))
(let ((?x929 (seq.++ ?x1161 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 (seq.++ ?x498 ?x1228)))))))
(let ((?x941 (seq.unit (_ bv255 8))))
(let ((?x1259 (seq.++ ?x941 (seq.++ ?x941 (seq.++ ?x941 (seq.++ ?x941 (seq.++ ?x941 ?x929)))))))
(let ((?x894 (seq.++ ?x941 ?x1259)))
(= input_0_net.frame_frame ?x894))))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x29 (= due_1_cache due_0_cache)))
 (let (($x741 (= due_1_query 1000)))
 (let (($x426 (= active_1_cache active_0_cache)))
 (let (($x747 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x484 (= v_1_ip_checksum 0)))
 (let (($x485 (= v_1_udp_checksum 0)))
 (let (($x1230 (= v_1_udp_raw_checksum 0)))
 (let (($x1058 (= v_1_ip_length 0)))
 (let (($x1068 (= v_1_udp_length 0)))
 (let (($x150 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x13 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1313 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1010 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x583 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x920 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1150 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x119 (= v_1_cache_ttl_ms 60000)))
 (let (($x613 (= 0 v_1_retry_count)))
 (let (($x919 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x44 (= 1 state_1)))
 (let (($x287 (not active_0_cache)))
 (let (($x1261 (or $x287 (not (<= due_0_cache 0)))))
 (let (($x164 (not active_0_query)))
 (let (($x1070 (or $x164 (not (<= due_0_query 0)))))
 (let (($x1227 (= state_0 0)))
 (and $x1227 (>= 0 now_0) $x1070 $x1261 $x44 $x919 $x613 $x119 v_1_checksums_enabled $x1150 $x920 $x583 $x1010 $x1313 $x13 $x150 $x1068 $x1058 $x1230 $x485 $x484 $x747 active_1_query $x426 $x741 $x29)))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1076 (= due_2_cache due_1_cache)))
 (let (($x1492 (= due_2_query due_1_query)))
 (let (($x455 (= active_2_cache active_1_cache)))
 (let (($x454 (= active_2_query active_1_query)))
 (let (($x1071 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x606 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x766 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x800 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1079 (= v_2_ip_length v_1_ip_length)))
 (let (($x744 (= v_2_udp_length v_1_udp_length)))
 (let (($x1165 (= v_2_packet v_1_packet)))
 (let (($x188 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x681 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x947 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x60 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x390 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x430 (= v_2_payload v_1_payload)))
 (let (($x290 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1166 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x189 (= v_2_retry_count v_1_retry_count)))
 (let (($x1310 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1312 (= 1 state_2)))
 (let (($x228 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x837 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x1532 (= state_1 1)))
 (and $x1532 $x837 $x228 $x1312 $x1310 $x189 $x1166 $x290 $x430 $x390 $x60 $x947 $x681 $x188 $x1165 $x744 $x1079 $x800 $x766 $x606 $x1071 $x454 $x455 $x1492 $x1076)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x460 (= due_3_query due_2_query)))
 (let (($x1578 (not active_3_query)))
 (let (($x1063 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x1062 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x682 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x136 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x777 (= v_3_ip_length v_2_ip_length)))
 (let (($x877 (= v_3_udp_length v_2_udp_length)))
 (let (($x736 (= v_3_packet v_2_packet)))
 (let (($x137 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x530 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x106 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1057 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1056 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x669 (= v_3_payload v_2_payload)))
 (let (($x734 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x743 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x683 (= 0 v_3_retry_count)))
 (let ((?x409 (seq.unit (_ bv0 8))))
 (let ((?x18 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.unit (_ bv2 8))))))))
 (let ((?x94 (seq.unit (_ bv2 8))))
 (let (($x1577 (= v_3_peer_mac (seq.++ ?x94 ?x18))))
 (let (($x380 (= 2 state_3)))
 (let (($x1468 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x841 (or (not active_2_query) (not (<= due_2_query 10)))))
 (let ((?x370 (seq.len v_2_pending_packet)))
 (let (($x1390 (= 0 ?x370)))
 (let (($x1284 (= state_2 1)))
 (and $x1284 $x1390 $x841 $x1468 $x380 $x1577 $x683 $x743 $x734 $x669 $x1056 $x1057 $x106 $x530 $x137 $x736 $x877 $x777 $x136 $x682 $x1062 $x1063 $x1578 active_3_cache $x460 (= due_3_cache (+ 10 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1158 (seq.unit (_ bv192 8))))
 (let ((?x1428 (seq.++ ?x1158 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x1428))))
(assert
 (= 12 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x1158 (seq.unit (_ bv192 8))))
 (let ((?x758 (seq.++ ?x1158 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x409 (seq.unit (_ bv0 8))))
 (let ((?x1162 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 ?x758)))))))
 (let ((?x94 (seq.unit (_ bv2 8))))
 (let ((?x863 (seq.++ ?x1158 (seq.++ ?x409 (seq.++ ?x94 (seq.++ ?x94 (seq.++ ?x409 ?x1162)))))))
 (let ((?x35 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x94 ?x863)))))))
 (let ((?x724 (seq.unit (_ bv1 8))))
 (let ((?x1491 (seq.unit (_ bv4 8))))
 (let ((?x1379 (seq.unit (_ bv6 8))))
 (let ((?x254 (seq.++ ?x1379 (seq.++ ?x1491 (seq.++ ?x409 (seq.++ ?x724 (seq.++ ?x94 ?x35)))))))
 (let ((?x397 (seq.unit (_ bv8 8))))
 (let ((?x23 (seq.++ ?x1379 (seq.++ ?x409 (seq.++ ?x724 (seq.++ ?x397 (seq.++ ?x409 ?x254)))))))
 (let ((?x203 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x94 (seq.++ ?x397 ?x23)))))))
 (let ((?x913 (seq.unit (_ bv255 8))))
 (let ((?x1299 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x94 (seq.++ ?x409 ?x203)))))))
 (let ((?x553 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 ?x1299)))))
 (= input_1_net.frame_frame ?x553)))))))))))))))))))
(assert
 (= 29 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x1158 (seq.unit (_ bv192 8))))
(let ((?x1362 (seq.++ ?x1158 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x724 (seq.unit (_ bv1 8))))
(let ((?x409 (seq.unit (_ bv0 8))))
(let ((?x710 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x724 ?x1362)))))))
(let ((?x94 (seq.unit (_ bv2 8))))
(let ((?x997 (seq.++ ?x1158 (seq.++ ?x409 (seq.++ ?x94 (seq.++ ?x94 (seq.++ ?x94 ?x710)))))))
(let ((?x1360 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x94 ?x997)))))))
(let ((?x1491 (seq.unit (_ bv4 8))))
(let ((?x1379 (seq.unit (_ bv6 8))))
(let ((?x138 (seq.++ ?x1379 (seq.++ ?x1491 (seq.++ ?x409 (seq.++ ?x94 (seq.++ ?x94 ?x1360)))))))
(let ((?x397 (seq.unit (_ bv8 8))))
(let ((?x1369 (seq.++ ?x1379 (seq.++ ?x409 (seq.++ ?x724 (seq.++ ?x397 (seq.++ ?x409 ?x138)))))))
(let ((?x172 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x94 (seq.++ ?x397 ?x1369)))))))
(let ((?x218 (seq.++ ?x409 (seq.++ ?x409 (seq.++ ?x724 (seq.++ ?x94 (seq.++ ?x409 ?x172)))))))
(let ((?x168 (seq.++ ?x94 (seq.++ ?x409 (seq.++ ?x409 ?x218)))))
(= input_2_net.frame_frame ?x168))))))))))))))))))
(check-sat)

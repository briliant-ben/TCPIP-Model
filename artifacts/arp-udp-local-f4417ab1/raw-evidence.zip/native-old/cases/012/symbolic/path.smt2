; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x728 (= due_1_cache due_0_cache)))
 (let (($x1639 (= due_1_query 1000)))
 (let (($x726 (= active_1_cache active_0_cache)))
 (let (($x402 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1396 (= v_1_ip_checksum 0)))
 (let (($x1028 (= v_1_udp_checksum 0)))
 (let (($x1510 (= v_1_udp_raw_checksum 0)))
 (let (($x1269 (= v_1_ip_length 0)))
 (let (($x1123 (= v_1_udp_length 0)))
 (let (($x134 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x886 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x903 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x769 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1577 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x537 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1426 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x546 (= v_1_cache_ttl_ms 60000)))
 (let (($x1021 (= 0 v_1_retry_count)))
 (let (($x683 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1270 (= 1 state_1)))
 (let (($x1636 (not active_0_cache)))
 (let (($x1039 (or $x1636 (not (<= due_0_cache 0)))))
 (let (($x231 (not active_0_query)))
 (let (($x1076 (or $x231 (not (<= due_0_query 0)))))
 (let (($x826 (= state_0 0)))
 (and $x826 (>= 0 now_0) $x1076 $x1039 $x1270 $x683 $x1021 $x546 v_1_checksums_enabled $x1426 $x537 $x1577 $x769 $x903 $x886 $x134 $x1123 $x1269 $x1510 $x1028 $x1396 $x402 active_1_query $x726 $x1639 $x728)))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x76 (= due_2_query due_1_query)))
 (let (($x1331 (not active_2_query)))
 (let (($x1112 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x439 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1168 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x438 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x733 (= v_2_ip_length v_1_ip_length)))
 (let (($x1366 (= v_2_udp_length v_1_udp_length)))
 (let (($x1080 (= v_2_packet v_1_packet)))
 (let (($x565 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1146 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1145 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1144 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1143 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x980 (= v_2_payload v_1_payload)))
 (let (($x1134 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1142 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1141 (= 0 v_2_retry_count)))
 (let ((?x1157 (seq.unit (_ bv0 8))))
 (let ((?x102 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.unit (_ bv3 8))))))))
 (let ((?x759 (seq.unit (_ bv2 8))))
 (let (($x1138 (= v_2_peer_mac (seq.++ ?x759 ?x102))))
 (let (($x188 (= 2 state_2)))
 (let (($x1330 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x998 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let ((?x1579 (seq.len v_1_pending_packet)))
 (let (($x849 (= 0 ?x1579)))
 (let (($x1075 (= state_1 1)))
 (and $x1075 $x849 $x998 $x1330 $x188 $x1138 $x1141 $x1142 $x1134 $x980 $x1143 $x1144 $x1145 $x1146 $x565 $x1080 $x1366 $x733 $x438 $x1168 $x439 $x1112 $x1331 active_2_cache $x76 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x889 (seq.unit (_ bv192 8))))
 (let ((?x392 (seq.++ ?x889 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x392))))
(assert
 (= 27 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x889 (seq.unit (_ bv192 8))))
(let ((?x1475 (seq.++ ?x889 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x1157 (seq.unit (_ bv0 8))))
(let ((?x633 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 ?x1475)))))))
(let ((?x759 (seq.unit (_ bv2 8))))
(let ((?x1250 (seq.++ ?x889 (seq.++ ?x1157 (seq.++ ?x759 (seq.++ ?x759 (seq.++ ?x1157 ?x633)))))))
(let ((?x47 (seq.unit (_ bv3 8))))
(let ((?x385 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x47 ?x1250)))))))
(let ((?x668 (seq.unit (_ bv1 8))))
(let ((?x331 (seq.unit (_ bv4 8))))
(let ((?x1631 (seq.unit (_ bv6 8))))
(let ((?x1245 (seq.++ ?x1631 (seq.++ ?x331 (seq.++ ?x1157 (seq.++ ?x668 (seq.++ ?x759 ?x385)))))))
(let ((?x15 (seq.unit (_ bv8 8))))
(let ((?x1169 (seq.++ ?x1631 (seq.++ ?x1157 (seq.++ ?x668 (seq.++ ?x15 (seq.++ ?x1157 ?x1245)))))))
(let ((?x355 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x1157 (seq.++ ?x47 (seq.++ ?x15 ?x1169)))))))
(let ((?x1359 (seq.unit (_ bv255 8))))
(let ((?x367 (seq.++ ?x1359 (seq.++ ?x1359 (seq.++ ?x1359 (seq.++ ?x759 (seq.++ ?x1157 ?x355)))))))
(let ((?x1160 (seq.++ ?x1359 (seq.++ ?x1359 (seq.++ ?x1359 ?x367)))))
(= input_1_net.frame_frame ?x1160))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_checksum () Int)
(declare-fun v_4_udp_checksum () Int)
(declare-fun v_4_udp_raw_checksum () Int)
(declare-fun v_4_ip_length () Int)
(declare-fun v_4_udp_length () Int)
(declare-fun v_4_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_checksums_enabled () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x868 (= due_1_cache due_0_cache)))
 (let (($x273 (= due_1_query 1000)))
 (let (($x861 (= active_1_cache active_0_cache)))
 (let (($x1295 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1345 (= v_1_ip_checksum 0)))
 (let (($x500 (= v_1_udp_checksum 0)))
 (let (($x770 (= v_1_udp_raw_checksum 0)))
 (let (($x863 (= v_1_ip_length 0)))
 (let (($x168 (= v_1_udp_length 0)))
 (let (($x515 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x308 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1005 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1414 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1500 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1499 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x244 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1271 (= v_1_cache_ttl_ms 60000)))
 (let (($x473 (= 0 v_1_retry_count)))
 (let (($x552 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1047 (= 1 state_1)))
 (let (($x203 (not active_0_cache)))
 (let (($x1391 (or $x203 (not (<= due_0_cache 0)))))
 (let (($x1324 (not active_0_query)))
 (let (($x655 (or $x1324 (not (<= due_0_query 0)))))
 (let (($x749 (= state_0 0)))
 (and $x749 (>= 0 now_0) $x655 $x1391 $x1047 $x552 $x473 $x1271 v_1_checksums_enabled $x244 $x1499 $x1500 $x1414 $x1005 $x308 $x515 $x168 $x863 $x770 $x500 $x1345 $x1295 active_1_query $x861 $x273 $x868)))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x793 (= due_2_cache due_1_cache)))
 (let (($x628 (= due_2_query due_1_query)))
 (let (($x592 (= active_2_cache active_1_cache)))
 (let (($x798 (= active_2_query active_1_query)))
 (let (($x545 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x520 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x544 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x519 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x543 (= v_2_ip_length v_1_ip_length)))
 (let (($x1117 (= v_2_udp_length v_1_udp_length)))
 (let (($x1152 (= v_2_packet v_1_packet)))
 (let (($x572 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x570 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x447 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1243 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1253 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x56 (= v_2_payload v_1_payload)))
 (let (($x912 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1194 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1193 (= v_2_retry_count v_1_retry_count)))
 (let (($x728 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x726 (= 1 state_2)))
 (let (($x1234 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x577 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x1490 (= state_1 1)))
 (and $x1490 $x577 $x1234 $x726 $x728 $x1193 $x1194 $x912 $x56 $x1253 $x1243 $x447 $x570 $x572 $x1152 $x1117 $x543 $x519 $x544 $x520 $x545 $x798 $x592 $x628 $x793)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x985 (= due_3_cache due_2_cache)))
 (let (($x1021 (= due_3_query 2000)))
 (let (($x224 (= active_3_cache active_2_cache)))
 (let (($x1270 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x767 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1015 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x934 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x350 (= v_3_ip_length v_2_ip_length)))
 (let (($x163 (= v_3_udp_length v_2_udp_length)))
 (let (($x1022 (= v_3_packet v_2_packet)))
 (let (($x698 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x296 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x250 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1197 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1235 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x86 (= v_3_payload v_2_payload)))
 (let (($x1529 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x856 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x883 (= 1 v_3_retry_count)))
 (let (($x19 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x1164 (= 1 state_3)))
 (let (($x1230 (= 0 v_2_retry_count)))
 (let (($x1428 (= state_2 1)))
 (and $x1428 $x1230 active_2_query (= 1000 due_2_query) (or (not active_2_cache) (not (<= due_2_cache due_2_query))) $x1164 $x19 $x883 $x856 $x1529 $x86 $x1235 $x1197 $x250 $x296 $x698 $x1022 $x163 $x350 $x934 $x1015 $x767 $x1270 active_3_query $x224 $x1021 $x985)))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x576 (= due_4_cache due_3_cache)))
 (let (($x1475 (= due_4_query due_3_query)))
 (let (($x240 (= active_4_cache active_3_cache)))
 (let (($x1497 (not active_4_query)))
 (let (($x926 (= v_4_pending_packet v_3_pending_packet)))
 (let (($x1546 (= v_4_ip_checksum v_3_ip_checksum)))
 (let (($x615 (= v_4_udp_checksum v_3_udp_checksum)))
 (let (($x493 (= v_4_udp_raw_checksum v_3_udp_raw_checksum)))
 (let (($x15 (= v_4_ip_length v_3_ip_length)))
 (let (($x472 (= v_4_udp_length v_3_udp_length)))
 (let (($x924 (= v_4_packet v_3_packet)))
 (let (($x1599 (= v_4_ip_wire v_3_ip_wire)))
 (let (($x174 (= v_4_ip_zero v_3_ip_zero)))
 (let (($x415 (= v_4_udp_wire v_3_udp_wire)))
 (let (($x668 (= v_4_pseudoheader v_3_pseudoheader)))
 (let (($x1595 (= v_4_udp_zero v_3_udp_zero)))
 (let (($x425 (= v_4_payload v_3_payload)))
 (let (($x62 (= v_4_checksums_enabled v_3_checksums_enabled)))
 (let (($x1335 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x1334 (= 0 v_4_retry_count)))
 (let (($x1561 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x688 (= 0 state_4)))
 (let ((?x347 (seq.len v_3_pending_packet)))
 (let (($x72 (= 0 ?x347)))
 (let (($x883 (= 1 v_3_retry_count)))
 (let (($x269 (= state_3 1)))
 (and $x269 $x883 $x72 active_3_query (= 2000 due_3_query) (or (not active_3_cache) (not (<= due_3_cache due_3_query))) $x688 $x1561 $x1334 $x1335 $x62 $x425 $x1595 $x668 $x415 $x174 $x1599 $x924 $x472 $x15 $x493 $x615 $x1546 $x926 $x1497 $x240 $x1475 $x576))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1300 (seq.unit (_ bv192 8))))
 (let ((?x623 (seq.++ ?x1300 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x623))))
(assert
 (= 1 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x1300 (seq.unit (_ bv192 8))))
 (let ((?x623 (seq.++ ?x1300 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_1_app.resolve_ip ?x623))))
(assert
 (= 3 choice_2))
(assert
 (= 1000 now_3))
(assert
 (= 25 choice_3))
(assert
 (= 2000 now_4))
(check-sat)

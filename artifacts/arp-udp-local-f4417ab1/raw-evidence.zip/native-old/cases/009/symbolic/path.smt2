; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x434 (= due_1_cache due_0_cache)))
 (let (($x371 (= due_1_query 1000)))
 (let (($x169 (= active_1_cache active_0_cache)))
 (let (($x213 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1645 (= v_1_ip_checksum 0)))
 (let (($x1646 (= v_1_udp_checksum 0)))
 (let (($x1340 (= v_1_udp_raw_checksum 0)))
 (let (($x1532 (= v_1_ip_length 0)))
 (let (($x868 (= v_1_udp_length 0)))
 (let (($x758 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x861 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x667 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x933 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1344 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x138 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x233 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x87 (= v_1_cache_ttl_ms 60000)))
 (let (($x1083 (= 0 v_1_retry_count)))
 (let (($x1376 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1556 (= 1 state_1)))
 (let (($x1262 (not active_0_cache)))
 (let (($x778 (or $x1262 (not (<= due_0_cache 0)))))
 (let (($x1424 (not active_0_query)))
 (let (($x361 (or $x1424 (not (<= due_0_query 0)))))
 (let (($x112 (= state_0 0)))
 (and $x112 (>= 0 now_0) $x361 $x778 $x1556 $x1376 $x1083 $x87 v_1_checksums_enabled $x233 $x138 $x1344 $x933 $x667 $x861 $x758 $x868 $x1532 $x1340 $x1646 $x1645 $x213 active_1_query $x169 $x371 $x434)))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x343 (= due_2_query due_1_query)))
 (let (($x671 (not active_2_query)))
 (let (($x1042 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x521 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1323 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x550 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x551 (= v_2_ip_length v_1_ip_length)))
 (let (($x879 (= v_2_udp_length v_1_udp_length)))
 (let (($x1044 (= v_2_packet v_1_packet)))
 (let (($x1041 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1116 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1184 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1420 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1000 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x1221 (= v_2_payload v_1_payload)))
 (let (($x1007 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x539 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x857 (= 0 v_2_retry_count)))
 (let ((?x523 (seq.unit (_ bv0 8))))
 (let ((?x1635 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.unit (_ bv2 8))))))))
 (let ((?x325 (seq.unit (_ bv2 8))))
 (let (($x1482 (= v_2_peer_mac (seq.++ ?x325 ?x1635))))
 (let (($x1216 (= 2 state_2)))
 (let (($x703 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x1577 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let ((?x446 (seq.len v_1_pending_packet)))
 (let (($x461 (= 0 ?x446)))
 (let (($x804 (= state_1 1)))
 (and $x804 $x461 $x1577 $x703 $x1216 $x1482 $x857 $x539 $x1007 $x1221 $x1000 $x1420 $x1184 $x1116 $x1041 $x1044 $x879 $x551 $x550 $x1323 $x521 $x1042 $x671 active_2_cache $x343 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1470 (= due_3_cache due_2_cache)))
 (let (($x339 (= due_3_query due_2_query)))
 (let (($x916 (= active_3_cache active_2_cache)))
 (let (($x294 (= active_3_query active_2_query)))
 (let (($x960 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x750 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1520 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x1327 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x771 (= v_3_ip_length v_2_ip_length)))
 (let (($x593 (= v_3_udp_length v_2_udp_length)))
 (let (($x1324 (= v_3_packet v_2_packet)))
 (let (($x80 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x836 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x915 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x102 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1005 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x1094 (= v_3_payload v_2_payload)))
 (let (($x930 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x123 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x171 (= v_3_retry_count v_2_retry_count)))
 (let (($x1322 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x818 (= 2 state_3)))
 (let (($x1634 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x671 (not active_2_query)))
 (let (($x929 (or $x671 (not (<= due_2_query 20)))))
 (let (($x310 (= state_2 2)))
 (and $x310 $x929 $x1634 $x818 $x1322 $x171 $x123 $x930 $x1094 $x1005 $x102 $x915 $x836 $x80 $x1324 $x593 $x771 $x1327 $x1520 $x750 $x960 $x294 $x916 $x339 $x1470))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x317 (seq.unit (_ bv192 8))))
 (let ((?x111 (seq.++ ?x317 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x111))))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x317 (seq.unit (_ bv192 8))))
 (let ((?x1317 (seq.++ ?x317 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x1268 (seq.unit (_ bv1 8))))
 (let ((?x523 (seq.unit (_ bv0 8))))
 (let ((?x746 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x1268 ?x1317)))))))
 (let ((?x325 (seq.unit (_ bv2 8))))
 (let ((?x38 (seq.++ ?x317 (seq.++ ?x523 (seq.++ ?x325 (seq.++ ?x325 (seq.++ ?x325 ?x746)))))))
 (let ((?x1003 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x325 ?x38)))))))
 (let ((?x844 (seq.unit (_ bv4 8))))
 (let ((?x358 (seq.unit (_ bv6 8))))
 (let ((?x318 (seq.++ ?x358 (seq.++ ?x844 (seq.++ ?x523 (seq.++ ?x325 (seq.++ ?x325 ?x1003)))))))
 (let ((?x118 (seq.unit (_ bv8 8))))
 (let ((?x326 (seq.++ ?x358 (seq.++ ?x523 (seq.++ ?x1268 (seq.++ ?x118 (seq.++ ?x523 ?x318)))))))
 (let ((?x1404 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x325 (seq.++ ?x118 ?x326)))))))
 (let ((?x659 (seq.++ ?x523 (seq.++ ?x523 (seq.++ ?x1268 (seq.++ ?x325 (seq.++ ?x523 ?x1404)))))))
 (let ((?x961 (seq.++ ?x325 (seq.++ ?x523 (seq.++ ?x523 ?x659)))))
 (= input_1_net.frame_frame ?x961))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x317 (seq.unit (_ bv192 8))))
(let ((?x111 (seq.++ ?x317 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x111))))
(check-sat)

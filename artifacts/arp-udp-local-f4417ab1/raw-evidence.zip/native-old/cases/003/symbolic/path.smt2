; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x784 (= due_1_cache 60000)))
 (let (($x419 (= due_1_query due_0_query)))
 (let (($x1161 (not active_1_query)))
 (let (($x777 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x647 (= v_1_ip_checksum 0)))
 (let (($x781 (= v_1_udp_checksum 0)))
 (let (($x1094 (= v_1_udp_raw_checksum 0)))
 (let (($x368 (= v_1_ip_length 0)))
 (let (($x369 (= v_1_udp_length 0)))
 (let (($x1463 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1462 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1341 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1340 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x657 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x26 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x701 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1327 (= v_1_cache_ttl_ms 60000)))
 (let (($x771 (= 0 v_1_retry_count)))
 (let ((?x703 (seq.unit (_ bv0 8))))
 (let ((?x1038 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.unit (_ bv2 8))))))))
 (let ((?x1088 (seq.unit (_ bv2 8))))
 (let (($x1272 (= v_1_peer_mac (seq.++ ?x1088 ?x1038))))
 (let (($x217 (= 2 state_1)))
 (let (($x1255 (not active_0_cache)))
 (let (($x1274 (or $x1255 (not (<= due_0_cache 0)))))
 (let (($x1257 (not active_0_query)))
 (let (($x1522 (or $x1257 (not (<= due_0_query 0)))))
 (let (($x835 (= state_0 0)))
 (and $x835 (>= 0 now_0) $x1522 $x1274 $x217 $x1272 $x771 $x1327 v_1_checksums_enabled $x701 $x26 $x657 $x1340 $x1341 $x1462 $x1463 $x369 $x368 $x1094 $x781 $x647 $x777 $x1161 active_1_cache $x419 $x784))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x205 (= due_2_query due_1_query)))
 (let (($x715 (= active_2_query active_1_query)))
 (let (($x181 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x222 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x799 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x798 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x520 (= v_2_ip_length v_1_ip_length)))
 (let (($x519 (= v_2_udp_length v_1_udp_length)))
 (let (($x1152 (= v_2_packet v_1_packet)))
 (let (($x1151 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1185 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1184 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x373 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x372 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x793 (= v_2_payload v_1_payload)))
 (let (($x792 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x281 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x278 (= v_2_retry_count v_1_retry_count)))
 (let ((?x703 (seq.unit (_ bv0 8))))
 (let ((?x1328 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.unit (_ bv3 8))))))))
 (let ((?x1088 (seq.unit (_ bv2 8))))
 (let (($x673 (= v_2_peer_mac (seq.++ ?x1088 ?x1328))))
 (let (($x343 (= 2 state_2)))
 (let (($x6 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x1161 (not active_1_query)))
 (let (($x1041 (or $x1161 (not (<= due_1_query 10)))))
 (let (($x34 (= state_1 2)))
 (and $x34 $x1041 $x6 $x343 $x673 $x278 $x281 $x792 $x793 $x372 $x373 $x1184 $x1185 $x1151 $x1152 $x519 $x520 $x798 $x799 $x222 $x181 $x715 active_2_cache $x205 (= due_2_cache (+ 10 v_1_cache_ttl_ms)))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x90 (= due_3_cache due_2_cache)))
 (let (($x754 (= due_3_query due_2_query)))
 (let (($x753 (= active_3_cache active_2_cache)))
 (let (($x1156 (= active_3_query active_2_query)))
 (let (($x1155 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x1210 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1209 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x1091 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x1106 (= v_3_ip_length v_2_ip_length)))
 (let (($x614 (= v_3_udp_length v_2_udp_length)))
 (let (($x755 (= v_3_packet v_2_packet)))
 (let (($x1200 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x1199 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x1150 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1149 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x813 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x812 (= v_3_payload v_2_payload)))
 (let (($x1263 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x1262 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x403 (= v_3_retry_count v_2_retry_count)))
 (let (($x870 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x928 (= 2 state_3)))
 (let (($x600 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x47 (or (not active_2_query) (not (<= due_2_query 20)))))
 (let (($x365 (= state_2 2)))
 (and $x365 $x47 $x600 $x928 $x870 $x403 $x1262 $x1263 $x812 $x813 $x1149 $x1150 $x1199 $x1200 $x755 $x614 $x1106 $x1091 $x1209 $x1210 $x1155 $x1156 $x753 $x754 $x90)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1241 (seq.unit (_ bv192 8))))
 (let ((?x1168 (seq.++ ?x1241 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x703 (seq.unit (_ bv0 8))))
 (let ((?x789 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 ?x1168)))))))
 (let ((?x1088 (seq.unit (_ bv2 8))))
 (let ((?x1488 (seq.++ ?x1241 (seq.++ ?x703 (seq.++ ?x1088 (seq.++ ?x1088 (seq.++ ?x703 ?x789)))))))
 (let ((?x133 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x1088 ?x1488)))))))
 (let ((?x1080 (seq.unit (_ bv1 8))))
 (let ((?x196 (seq.unit (_ bv4 8))))
 (let ((?x533 (seq.unit (_ bv6 8))))
 (let ((?x126 (seq.++ ?x533 (seq.++ ?x196 (seq.++ ?x703 (seq.++ ?x1080 (seq.++ ?x1088 ?x133)))))))
 (let ((?x1008 (seq.unit (_ bv8 8))))
 (let ((?x938 (seq.++ ?x533 (seq.++ ?x703 (seq.++ ?x1080 (seq.++ ?x1008 (seq.++ ?x703 ?x126)))))))
 (let ((?x665 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x1088 (seq.++ ?x1008 ?x938)))))))
 (let ((?x1084 (seq.unit (_ bv255 8))))
 (let ((?x659 (seq.++ ?x1084 (seq.++ ?x1084 (seq.++ ?x1084 (seq.++ ?x1088 (seq.++ ?x703 ?x665)))))))
 (let ((?x240 (seq.++ ?x1084 (seq.++ ?x1084 (seq.++ ?x1084 ?x659)))))
 (= input_0_net.frame_frame ?x240)))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x1241 (seq.unit (_ bv192 8))))
 (let ((?x890 (seq.++ ?x1241 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x703 (seq.unit (_ bv0 8))))
 (let ((?x908 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 ?x890)))))))
 (let ((?x1088 (seq.unit (_ bv2 8))))
 (let ((?x1006 (seq.++ ?x1241 (seq.++ ?x703 (seq.++ ?x1088 (seq.++ ?x1088 (seq.++ ?x703 ?x908)))))))
 (let ((?x1296 (seq.unit (_ bv3 8))))
 (let ((?x397 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x1296 ?x1006)))))))
 (let ((?x1080 (seq.unit (_ bv1 8))))
 (let ((?x196 (seq.unit (_ bv4 8))))
 (let ((?x533 (seq.unit (_ bv6 8))))
 (let ((?x706 (seq.++ ?x533 (seq.++ ?x196 (seq.++ ?x703 (seq.++ ?x1080 (seq.++ ?x1088 ?x397)))))))
 (let ((?x1008 (seq.unit (_ bv8 8))))
 (let ((?x1371 (seq.++ ?x533 (seq.++ ?x703 (seq.++ ?x1080 (seq.++ ?x1008 (seq.++ ?x703 ?x706)))))))
 (let ((?x1277 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x703 (seq.++ ?x1296 (seq.++ ?x1008 ?x1371)))))))
 (let ((?x1084 (seq.unit (_ bv255 8))))
 (let ((?x1115 (seq.++ ?x1084 (seq.++ ?x1084 (seq.++ ?x1084 (seq.++ ?x1088 (seq.++ ?x703 ?x1277)))))))
 (let ((?x712 (seq.++ ?x1084 (seq.++ ?x1084 (seq.++ ?x1084 ?x1115)))))
 (= input_1_net.frame_frame ?x712))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x1241 (seq.unit (_ bv192 8))))
(let ((?x64 (seq.++ ?x1241 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x64))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x936 (= due_1_cache 60000)))
 (let (($x119 (= due_1_query due_0_query)))
 (let (($x1448 (not active_1_query)))
 (let (($x186 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1415 (= v_1_ip_checksum 0)))
 (let (($x1325 (= v_1_udp_checksum 0)))
 (let (($x781 (= v_1_udp_raw_checksum 0)))
 (let (($x526 (= v_1_ip_length 0)))
 (let (($x43 (= v_1_udp_length 0)))
 (let (($x1518 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1517 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x165 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x12 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1125 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1496 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x761 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1023 (= v_1_cache_ttl_ms 60000)))
 (let (($x1227 (= 0 v_1_retry_count)))
 (let ((?x1262 (seq.unit (_ bv0 8))))
 (let ((?x1615 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.unit (_ bv2 8))))))))
 (let ((?x1403 (seq.unit (_ bv2 8))))
 (let (($x435 (= v_1_peer_mac (seq.++ ?x1403 ?x1615))))
 (let (($x656 (= 2 state_1)))
 (let (($x1183 (not active_0_cache)))
 (let (($x431 (or $x1183 (not (<= due_0_cache 0)))))
 (let (($x1021 (not active_0_query)))
 (let (($x1474 (or $x1021 (not (<= due_0_query 0)))))
 (let (($x28 (= state_0 0)))
 (and $x28 (>= 0 now_0) $x1474 $x431 $x656 $x435 $x1227 $x1023 v_1_checksums_enabled $x761 $x1496 $x1125 $x12 $x165 $x1517 $x1518 $x43 $x526 $x781 $x1325 $x1415 $x186 $x1448 active_1_cache $x119 $x936))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x745 (= due_2_query due_1_query)))
 (let (($x797 (= active_2_query active_1_query)))
 (let (($x261 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x902 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1260 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1247 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x571 (= v_2_ip_length v_1_ip_length)))
 (let (($x1219 (= v_2_udp_length v_1_udp_length)))
 (let (($x1215 (= v_2_packet v_1_packet)))
 (let (($x471 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1138 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1239 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1537 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1090 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x702 (= v_2_payload v_1_payload)))
 (let (($x872 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x731 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x732 (= v_2_retry_count v_1_retry_count)))
 (let ((?x1262 (seq.unit (_ bv0 8))))
 (let ((?x132 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.unit (_ bv3 8))))))))
 (let ((?x1403 (seq.unit (_ bv2 8))))
 (let (($x772 (= v_2_peer_mac (seq.++ ?x1403 ?x132))))
 (let (($x1273 (= 2 state_2)))
 (let (($x864 (or (not active_1_cache) (not (<= due_1_cache 59999)))))
 (let (($x1448 (not active_1_query)))
 (let (($x876 (or $x1448 (not (<= due_1_query 59999)))))
 (let (($x1174 (= state_1 2)))
 (and $x1174 $x876 $x864 $x1273 $x772 $x732 $x731 $x872 $x702 $x1090 $x1537 $x1239 $x1138 $x471 $x1215 $x1219 $x571 $x1247 $x1260 $x902 $x261 $x797 active_2_cache $x745 (= due_2_cache (+ 59999 v_1_cache_ttl_ms)))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x382 (= due_3_cache due_2_cache)))
 (let (($x1187 (= due_3_query due_2_query)))
 (let (($x1148 (= active_3_cache active_2_cache)))
 (let (($x937 (= active_3_query active_2_query)))
 (let (($x641 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x640 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1061 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x1060 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x501 (= v_3_ip_length v_2_ip_length)))
 (let (($x500 (= v_3_udp_length v_2_udp_length)))
 (let (($x374 (= v_3_packet v_2_packet)))
 (let (($x273 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x805 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x804 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x1069 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x371 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x65 (= v_3_payload v_2_payload)))
 (let (($x1073 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x1177 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x375 (= v_3_retry_count v_2_retry_count)))
 (let (($x651 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x650 (= 2 state_3)))
 (let (($x463 (or (not active_2_cache) (not (<= due_2_cache 60001)))))
 (let (($x1082 (or (not active_2_query) (not (<= due_2_query 60001)))))
 (let (($x828 (= state_2 2)))
 (and $x828 $x1082 $x463 $x650 $x651 $x375 $x1177 $x1073 $x65 $x371 $x1069 $x804 $x805 $x273 $x374 $x500 $x501 $x1060 $x1061 $x640 $x641 $x937 $x1148 $x1187 $x382)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x579 (seq.unit (_ bv192 8))))
 (let ((?x1079 (seq.++ ?x579 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x661 (seq.unit (_ bv1 8))))
 (let ((?x1262 (seq.unit (_ bv0 8))))
 (let ((?x1266 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x661 ?x1079)))))))
 (let ((?x1403 (seq.unit (_ bv2 8))))
 (let ((?x231 (seq.++ ?x579 (seq.++ ?x1262 (seq.++ ?x1403 (seq.++ ?x1403 (seq.++ ?x1403 ?x1266)))))))
 (let ((?x1540 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1403 ?x231)))))))
 (let ((?x1578 (seq.unit (_ bv4 8))))
 (let ((?x1063 (seq.unit (_ bv6 8))))
 (let ((?x180 (seq.++ ?x1063 (seq.++ ?x1578 (seq.++ ?x1262 (seq.++ ?x1403 (seq.++ ?x1403 ?x1540)))))))
 (let ((?x1062 (seq.unit (_ bv8 8))))
 (let ((?x1180 (seq.++ ?x1063 (seq.++ ?x1262 (seq.++ ?x661 (seq.++ ?x1062 (seq.++ ?x1262 ?x180)))))))
 (let ((?x466 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1403 (seq.++ ?x1062 ?x1180)))))))
 (let ((?x288 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x661 (seq.++ ?x1403 (seq.++ ?x1262 ?x466)))))))
 (let ((?x523 (seq.++ ?x1403 (seq.++ ?x1262 (seq.++ ?x1262 ?x288)))))
 (= input_0_net.frame_frame ?x523))))))))))))))))))
(assert
 (= 17 choice_1))
(assert
 (= 59999 now_2))
(assert
 (let ((?x579 (seq.unit (_ bv192 8))))
 (let ((?x1050 (seq.++ ?x579 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x1262 (seq.unit (_ bv0 8))))
 (let ((?x1308 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 ?x1050)))))))
 (let ((?x1403 (seq.unit (_ bv2 8))))
 (let ((?x84 (seq.++ ?x579 (seq.++ ?x1262 (seq.++ ?x1403 (seq.++ ?x1403 (seq.++ ?x1262 ?x1308)))))))
 (let ((?x861 (seq.unit (_ bv3 8))))
 (let ((?x364 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x861 ?x84)))))))
 (let ((?x661 (seq.unit (_ bv1 8))))
 (let ((?x1578 (seq.unit (_ bv4 8))))
 (let ((?x1063 (seq.unit (_ bv6 8))))
 (let ((?x259 (seq.++ ?x1063 (seq.++ ?x1578 (seq.++ ?x1262 (seq.++ ?x661 (seq.++ ?x1403 ?x364)))))))
 (let ((?x1062 (seq.unit (_ bv8 8))))
 (let ((?x1526 (seq.++ ?x1063 (seq.++ ?x1262 (seq.++ ?x661 (seq.++ ?x1062 (seq.++ ?x1262 ?x259)))))))
 (let ((?x898 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x1262 (seq.++ ?x861 (seq.++ ?x1062 ?x1526)))))))
 (let ((?x736 (seq.unit (_ bv255 8))))
 (let ((?x1052 (seq.++ ?x736 (seq.++ ?x736 (seq.++ ?x736 (seq.++ ?x1403 (seq.++ ?x1262 ?x898)))))))
 (let ((?x923 (seq.++ ?x736 (seq.++ ?x736 (seq.++ ?x736 ?x1052)))))
 (= input_1_net.frame_frame ?x923))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 60001 now_3))
(assert
 (let ((?x579 (seq.unit (_ bv192 8))))
(let ((?x332 (seq.++ ?x579 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x332))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1326 (= due_1_cache 60000)))
 (let (($x713 (= due_1_query due_0_query)))
 (let (($x1325 (not active_1_query)))
 (let (($x1324 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x254 (= v_1_ip_checksum 0)))
 (let (($x263 (= v_1_udp_checksum 0)))
 (let (($x901 (= v_1_udp_raw_checksum 0)))
 (let (($x899 (= v_1_ip_length 0)))
 (let (($x900 (= v_1_udp_length 0)))
 (let (($x1323 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1322 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x1321 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1320 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1319 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1318 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1317 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x402 (= v_1_cache_ttl_ms 60000)))
 (let (($x5 (= 0 v_1_retry_count)))
 (let ((?x109 (seq.unit (_ bv0 8))))
 (let ((?x80 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.unit (_ bv2 8))))))))
 (let ((?x1172 (seq.unit (_ bv2 8))))
 (let (($x1316 (= v_1_peer_mac (seq.++ ?x1172 ?x80))))
 (let (($x1479 (= 2 state_1)))
 (let (($x81 (not active_0_cache)))
 (let (($x1315 (or $x81 (not (<= due_0_cache 0)))))
 (let (($x1166 (not active_0_query)))
 (let (($x1312 (or $x1166 (not (<= due_0_query 0)))))
 (let (($x21 (= state_0 0)))
 (and $x21 (>= 0 now_0) $x1312 $x1315 $x1479 $x1316 $x5 $x402 v_1_checksums_enabled $x1317 $x1318 $x1319 $x1320 $x1321 $x1322 $x1323 $x900 $x899 $x901 $x263 $x254 $x1324 $x1325 active_1_cache $x713 $x1326))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x573 (= due_2_cache due_1_cache)))
 (let (($x572 (= due_2_query due_1_query)))
 (let (($x765 (not active_2_cache)))
 (let (($x570 (= active_2_query active_1_query)))
 (let (($x569 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x568 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x567 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x566 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x565 (= v_2_ip_length v_1_ip_length)))
 (let (($x564 (= v_2_udp_length v_1_udp_length)))
 (let (($x563 (= v_2_packet v_1_packet)))
 (let (($x562 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x561 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x560 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x559 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x558 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x557 (= v_2_payload v_1_payload)))
 (let (($x556 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x555 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x554 (= 0 v_2_retry_count)))
 (let (($x764 (= (as seq.empty (Seq (_ BitVec 8))) v_2_peer_mac)))
 (let (($x552 (= 0 state_2)))
 (let (($x256 (= state_1 2)))
 (and $x256 active_1_cache (= 60000 due_1_cache) (or (not active_1_query) (<= due_1_cache due_1_query)) $x552 $x764 $x554 $x555 $x556 $x557 $x558 $x559 $x560 $x561 $x562 $x563 $x564 $x565 $x566 $x567 $x568 $x569 $x570 $x765 $x572 $x573)))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x434 (= due_3_cache due_2_cache)))
 (let (($x896 (= due_3_query 61000)))
 (let (($x432 (= active_3_cache active_2_cache)))
 (let (($x430 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x429 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x428 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x427 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x426 (= v_3_ip_length v_2_ip_length)))
 (let (($x425 (= v_3_udp_length v_2_udp_length)))
 (let (($x424 (= v_3_packet v_2_packet)))
 (let (($x423 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x422 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x421 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x420 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x419 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x418 (= v_3_payload v_2_payload)))
 (let (($x417 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x416 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x415 (= 0 v_3_retry_count)))
 (let (($x414 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x936 (= 1 state_3)))
 (let (($x765 (not active_2_cache)))
 (let (($x771 (or $x765 (not (<= due_2_cache 60000)))))
 (let (($x905 (or (not active_2_query) (not (<= due_2_query 60000)))))
 (let (($x903 (= state_2 0)))
 (and $x903 $x905 $x771 $x936 $x414 $x415 $x416 $x417 $x418 $x419 $x420 $x421 $x422 $x423 $x424 $x425 $x426 $x427 $x428 $x429 $x430 active_3_query $x432 $x896 $x434)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x85 (seq.unit (_ bv192 8))))
 (let ((?x610 (seq.++ ?x85 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x940 (seq.unit (_ bv1 8))))
 (let ((?x109 (seq.unit (_ bv0 8))))
 (let ((?x1074 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x940 ?x610)))))))
 (let ((?x1172 (seq.unit (_ bv2 8))))
 (let ((?x1079 (seq.++ ?x85 (seq.++ ?x109 (seq.++ ?x1172 (seq.++ ?x1172 (seq.++ ?x1172 ?x1074)))))))
 (let ((?x1084 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x1172 ?x1079)))))))
 (let ((?x953 (seq.unit (_ bv4 8))))
 (let ((?x952 (seq.unit (_ bv6 8))))
 (let ((?x1089 (seq.++ ?x952 (seq.++ ?x953 (seq.++ ?x109 (seq.++ ?x1172 (seq.++ ?x1172 ?x1084)))))))
 (let ((?x951 (seq.unit (_ bv8 8))))
 (let ((?x1094 (seq.++ ?x952 (seq.++ ?x109 (seq.++ ?x940 (seq.++ ?x951 (seq.++ ?x109 ?x1089)))))))
 (let ((?x1099 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x1172 (seq.++ ?x951 ?x1094)))))))
 (let ((?x1104 (seq.++ ?x109 (seq.++ ?x109 (seq.++ ?x940 (seq.++ ?x1172 (seq.++ ?x109 ?x1099)))))))
 (let ((?x1107 (seq.++ ?x1172 (seq.++ ?x109 (seq.++ ?x109 ?x1104)))))
 (= input_0_net.frame_frame ?x1107))))))))))))))))))
(assert
 (= 4 choice_1))
(assert
 (= 60000 now_2))
(assert
 (= 0 choice_2))
(assert
 (= 60000 now_3))
(assert
 (let ((?x85 (seq.unit (_ bv192 8))))
(let ((?x1173 (seq.++ ?x85 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x1173))))
(check-sat)

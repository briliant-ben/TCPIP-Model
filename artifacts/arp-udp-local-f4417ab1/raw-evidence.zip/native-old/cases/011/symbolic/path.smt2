; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x665 (= due_1_cache due_0_cache)))
 (let (($x1197 (= due_1_query due_0_query)))
 (let (($x326 (= active_1_cache active_0_cache)))
 (let (($x1235 (= active_1_query active_0_query)))
 (let (($x65 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1153 (= v_1_ip_checksum 0)))
 (let (($x688 (= v_1_udp_checksum 0)))
 (let (($x1560 (= v_1_udp_raw_checksum 0)))
 (let (($x1561 (= v_1_ip_length 0)))
 (let (($x72 (= v_1_udp_length 0)))
 (let (($x171 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x574 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x245 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x325 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1322 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1411 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1609 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x640 (= v_1_cache_ttl_ms 60000)))
 (let (($x116 (= v_1_retry_count 0)))
 (let (($x1628 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x503 (= 0 state_1)))
 (let (($x821 (not active_0_cache)))
 (let (($x123 (or $x821 (not (<= due_0_cache 0)))))
 (let (($x1555 (not active_0_query)))
 (let (($x1626 (or $x1555 (not (<= due_0_query 0)))))
 (let (($x335 (= state_0 0)))
 (and $x335 (>= 0 now_0) $x1626 $x123 $x503 $x1628 $x116 $x640 v_1_checksums_enabled $x1609 $x1411 $x1322 $x325 $x245 $x574 $x171 $x72 $x1561 $x1560 $x688 $x1153 $x65 $x1235 $x326 $x1197 $x665))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x924 (seq.unit (_ bv0 8))))
(let ((?x742 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 ?x924)))))))
(let ((?x1288 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 ?x742)))))))
(let ((?x1072 (seq.++ ?x924 (seq.++ ?x924 (seq.++ ?x924 ?x1288)))))
(= input_0_net.frame_frame ?x1072))))))
(check-sat)

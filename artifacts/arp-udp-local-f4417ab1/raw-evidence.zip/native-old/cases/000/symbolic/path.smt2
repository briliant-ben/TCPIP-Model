; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_checksum () Int)
(declare-fun v_4_udp_checksum () Int)
(declare-fun v_4_udp_raw_checksum () Int)
(declare-fun v_4_ip_length () Int)
(declare-fun v_4_udp_length () Int)
(declare-fun v_4_packet () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_4_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_4_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_4_payload () (Seq (_ BitVec 8)))
(declare-fun v_4_checksums_enabled () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.cache_ttl_milliseconds () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.cache_ttl_milliseconds () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x244 (= due_1_cache due_0_cache)))
 (let (($x243 (= due_1_query due_0_query)))
 (let (($x242 (= active_1_cache active_0_cache)))
 (let (($x241 (= active_1_query active_0_query)))
 (let (($x393 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x698 (= v_1_ip_checksum 0)))
 (let (($x699 (= v_1_udp_checksum 0)))
 (let (($x667 (= v_1_udp_raw_checksum 0)))
 (let (($x731 (= v_1_ip_length 0)))
 (let (($x732 (= v_1_udp_length 0)))
 (let (($x396 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x395 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x173 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x158 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x719 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x718 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x717 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x677 (= v_1_cache_ttl_ms 120000)))
 (let (($x1006 (= v_1_retry_count 0)))
 (let (($x713 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x223 (= 0 state_1)))
 (let (($x177 (not active_0_cache)))
 (let (($x712 (or $x177 (not (<= due_0_cache 0)))))
 (let (($x175 (not active_0_query)))
 (let (($x705 (or $x175 (not (<= due_0_query 0)))))
 (let (($x121 (= state_0 0)))
 (and $x121 (>= 0 now_0) $x705 $x712 $x223 $x713 $x1006 $x677 v_1_checksums_enabled $x717 $x718 $x719 $x158 $x173 $x395 $x396 $x732 $x731 $x667 $x699 $x698 $x393 $x241 $x242 $x243 $x244))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x618 (= due_2_query due_1_query)))
 (let (($x1478 (not active_2_query)))
 (let (($x615 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x614 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x613 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x612 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x611 (= v_2_ip_length v_1_ip_length)))
 (let (($x610 (= v_2_udp_length v_1_udp_length)))
 (let (($x609 (= v_2_packet v_1_packet)))
 (let (($x608 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x607 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x606 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x605 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x604 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x603 (= v_2_payload v_1_payload)))
 (let (($x602 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x601 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x600 (= 0 v_2_retry_count)))
 (let ((?x192 (seq.unit (_ bv0 8))))
 (let ((?x162 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.unit (_ bv2 8))))))))
 (let ((?x194 (seq.unit (_ bv2 8))))
 (let (($x1477 (= v_2_peer_mac (seq.++ ?x194 ?x162))))
 (let (($x598 (= 2 state_2)))
 (let (($x1476 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x1472 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x412 (= state_1 0)))
 (and $x412 $x1472 $x1476 $x598 $x1477 $x600 $x601 $x602 $x603 $x604 $x605 $x606 $x607 $x608 $x609 $x610 $x611 $x612 $x613 $x614 $x615 $x1478 active_2_cache $x618 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1003 (= due_3_cache 60020)))
 (let (($x960 (= due_3_query due_2_query)))
 (let (($x958 (= active_3_query active_2_query)))
 (let (($x957 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x956 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x955 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x954 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x953 (= v_3_ip_length v_2_ip_length)))
 (let (($x952 (= v_3_udp_length v_2_udp_length)))
 (let (($x951 (= v_3_packet v_2_packet)))
 (let (($x950 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x949 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x948 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x947 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x946 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x945 (= v_3_payload v_2_payload)))
 (let (($x944 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x703 (= v_3_cache_ttl_ms 60000)))
 (let (($x942 (= v_3_retry_count v_2_retry_count)))
 (let (($x941 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x940 (= 2 state_3)))
 (let (($x672 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x1478 (not active_2_query)))
 (let (($x404 (or $x1478 (not (<= due_2_query 20)))))
 (let (($x738 (= state_2 2)))
 (and $x738 $x404 $x672 $x940 $x941 $x942 $x703 $x944 $x945 $x946 $x947 $x948 $x949 $x950 $x951 $x952 $x953 $x954 $x955 $x956 $x957 $x958 active_3_cache $x960 $x1003)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1182 (= due_4_cache due_3_cache)))
 (let (($x1181 (= due_4_query due_3_query)))
 (let (($x411 (not active_4_cache)))
 (let (($x1179 (= active_4_query active_3_query)))
 (let (($x1178 (= v_4_pending_packet v_3_pending_packet)))
 (let (($x1177 (= v_4_ip_checksum v_3_ip_checksum)))
 (let (($x1176 (= v_4_udp_checksum v_3_udp_checksum)))
 (let (($x1175 (= v_4_udp_raw_checksum v_3_udp_raw_checksum)))
 (let (($x1174 (= v_4_ip_length v_3_ip_length)))
 (let (($x1173 (= v_4_udp_length v_3_udp_length)))
 (let (($x1172 (= v_4_packet v_3_packet)))
 (let (($x1171 (= v_4_ip_wire v_3_ip_wire)))
 (let (($x1170 (= v_4_ip_zero v_3_ip_zero)))
 (let (($x1169 (= v_4_udp_wire v_3_udp_wire)))
 (let (($x1168 (= v_4_pseudoheader v_3_pseudoheader)))
 (let (($x1167 (= v_4_udp_zero v_3_udp_zero)))
 (let (($x1166 (= v_4_payload v_3_payload)))
 (let (($x1165 (= v_4_checksums_enabled v_3_checksums_enabled)))
 (let (($x1164 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x1163 (= 0 v_4_retry_count)))
 (let (($x1005 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x1161 (= 0 state_4)))
 (let (($x1020 (= state_3 2)))
 (and $x1020 active_3_cache (= 60020 due_3_cache) (or (not active_3_query) (<= due_3_cache due_3_query)) $x1161 $x1005 $x1163 $x1164 $x1165 $x1166 $x1167 $x1168 $x1169 $x1170 $x1171 $x1172 $x1173 $x1174 $x1175 $x1176 $x1177 $x1178 $x1179 $x411 $x1181 $x1182)))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 5 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 120000 input_0_app.cache_ttl_milliseconds))
(assert
 (= 8 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x190 (seq.unit (_ bv192 8))))
 (let ((?x342 (seq.++ ?x190 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x262 (seq.unit (_ bv1 8))))
 (let ((?x192 (seq.unit (_ bv0 8))))
 (let ((?x1405 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x262 ?x342)))))))
 (let ((?x194 (seq.unit (_ bv2 8))))
 (let ((?x1410 (seq.++ ?x190 (seq.++ ?x192 (seq.++ ?x194 (seq.++ ?x194 (seq.++ ?x194 ?x1405)))))))
 (let ((?x1415 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x194 ?x1410)))))))
 (let ((?x291 (seq.unit (_ bv4 8))))
 (let ((?x289 (seq.unit (_ bv6 8))))
 (let ((?x1420 (seq.++ ?x289 (seq.++ ?x291 (seq.++ ?x192 (seq.++ ?x194 (seq.++ ?x194 ?x1415)))))))
 (let ((?x287 (seq.unit (_ bv8 8))))
 (let ((?x1425 (seq.++ ?x289 (seq.++ ?x192 (seq.++ ?x262 (seq.++ ?x287 (seq.++ ?x192 ?x1420)))))))
 (let ((?x1430 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x194 (seq.++ ?x287 ?x1425)))))))
 (let ((?x1435 (seq.++ ?x192 (seq.++ ?x192 (seq.++ ?x262 (seq.++ ?x194 (seq.++ ?x192 ?x1430)))))))
 (let ((?x1438 (seq.++ ?x194 (seq.++ ?x192 (seq.++ ?x192 ?x1435)))))
 (= input_1_net.frame_frame ?x1438))))))))))))))))))
(assert
 (= 13 choice_2))
(assert
 (= 20 now_3))
(assert
 (= 60000 input_2_app.cache_ttl_milliseconds))
(assert
 (= 4 choice_3))
(assert
 (= 60020 now_4))
(check-sat)

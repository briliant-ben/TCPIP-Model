; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x463 (= due_1_cache 60000)))
 (let (($x21 (= due_1_query due_0_query)))
 (let (($x462 (not active_1_query)))
 (let (($x461 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x766 (= v_1_ip_checksum 0)))
 (let (($x199 (= v_1_udp_checksum 0)))
 (let (($x188 (= v_1_udp_raw_checksum 0)))
 (let (($x1110 (= v_1_ip_length 0)))
 (let (($x1222 (= v_1_udp_length 0)))
 (let (($x460 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x459 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x458 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x457 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x456 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x455 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x454 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x723 (= v_1_cache_ttl_ms 60000)))
 (let (($x563 (= 0 v_1_retry_count)))
 (let ((?x1555 (seq.unit (_ bv0 8))))
 (let ((?x628 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.unit (_ bv2 8))))))))
 (let ((?x1557 (seq.unit (_ bv2 8))))
 (let (($x453 (= v_1_peer_mac (seq.++ ?x1557 ?x628))))
 (let (($x562 (= 2 state_1)))
 (let (($x1540 (not active_0_cache)))
 (let (($x452 (or $x1540 (not (<= due_0_cache 0)))))
 (let (($x1538 (not active_0_query)))
 (let (($x450 (or $x1538 (not (<= due_0_query 0)))))
 (let (($x1088 (= state_0 0)))
 (and $x1088 (>= 0 now_0) $x450 $x452 $x562 $x453 $x563 $x723 v_1_checksums_enabled $x454 $x455 $x456 $x457 $x458 $x459 $x460 $x1222 $x1110 $x188 $x199 $x766 $x461 $x462 active_1_cache $x21 $x463))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1553 (seq.unit (_ bv192 8))))
(let ((?x1436 (seq.++ ?x1553 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x1555 (seq.unit (_ bv0 8))))
(let ((?x537 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 ?x1436)))))))
(let ((?x1557 (seq.unit (_ bv2 8))))
(let ((?x542 (seq.++ ?x1553 (seq.++ ?x1555 (seq.++ ?x1557 (seq.++ ?x1557 (seq.++ ?x1555 ?x537)))))))
(let ((?x547 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1557 ?x542)))))))
(let ((?x694 (seq.unit (_ bv1 8))))
(let ((?x904 (seq.unit (_ bv4 8))))
(let ((?x765 (seq.unit (_ bv6 8))))
(let ((?x521 (seq.++ ?x765 (seq.++ ?x904 (seq.++ ?x1555 (seq.++ ?x694 (seq.++ ?x1557 ?x547)))))))
(let ((?x905 (seq.unit (_ bv8 8))))
(let ((?x529 (seq.++ ?x765 (seq.++ ?x1555 (seq.++ ?x694 (seq.++ ?x905 (seq.++ ?x1555 ?x521)))))))
(let ((?x583 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1555 (seq.++ ?x1557 (seq.++ ?x905 ?x529)))))))
(let ((?x308 (seq.unit (_ bv255 8))))
(let ((?x588 (seq.++ ?x308 (seq.++ ?x308 (seq.++ ?x308 (seq.++ ?x1557 (seq.++ ?x1555 ?x583)))))))
(let ((?x591 (seq.++ ?x308 (seq.++ ?x308 (seq.++ ?x308 ?x588)))))
(= input_0_net.frame_frame ?x591)))))))))))))))))))
(check-sat)

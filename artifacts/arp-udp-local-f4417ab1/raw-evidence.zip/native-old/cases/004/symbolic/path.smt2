; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x537 (= due_1_cache due_0_cache)))
 (let (($x793 (= due_1_query due_0_query)))
 (let (($x536 (= active_1_cache active_0_cache)))
 (let (($x792 (= active_1_query active_0_query)))
 (let (($x214 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x1274 (= v_1_ip_checksum 0)))
 (let (($x217 (= v_1_udp_checksum 0)))
 (let (($x784 (= v_1_udp_raw_checksum 0)))
 (let (($x1027 (= v_1_ip_length 0)))
 (let (($x48 (= v_1_udp_length 0)))
 (let (($x1217 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x823 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x822 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x76 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x444 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x439 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x438 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1366 (= v_1_cache_ttl_ms 60000)))
 (let (($x1367 (= v_1_retry_count 0)))
 (let (($x437 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1161 (= 0 state_1)))
 (let (($x1275 (not active_0_cache)))
 (let (($x498 (or $x1275 (not (<= due_0_cache 0)))))
 (let (($x1345 (not active_0_query)))
 (let (($x495 (or $x1345 (not (<= due_0_query 0)))))
 (let (($x131 (= state_0 0)))
 (and $x131 (>= 0 now_0) $x495 $x498 $x1161 $x437 $x1367 $x1366 v_1_checksums_enabled $x438 $x439 $x444 $x76 $x822 $x823 $x1217 $x48 $x1027 $x784 $x217 $x1274 $x214 $x792 $x536 $x793 $x537))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x147 (seq.unit (_ bv192 8))))
(let ((?x420 (seq.++ ?x147 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
(let ((?x64 (seq.unit (_ bv0 8))))
(let ((?x1429 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x64 ?x420)))))))
(let ((?x360 (seq.unit (_ bv2 8))))
(let ((?x692 (seq.++ ?x147 (seq.++ ?x64 (seq.++ ?x360 (seq.++ ?x360 (seq.++ ?x64 ?x1429)))))))
(let ((?x1248 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x360 ?x692)))))))
(let ((?x1033 (seq.unit (_ bv1 8))))
(let ((?x870 (seq.unit (_ bv4 8))))
(let ((?x1402 (seq.unit (_ bv6 8))))
(let ((?x29 (seq.++ ?x1402 (seq.++ ?x870 (seq.++ ?x64 (seq.++ ?x1033 (seq.++ ?x360 ?x1248)))))))
(let ((?x1401 (seq.unit (_ bv8 8))))
(let ((?x429 (seq.++ ?x1402 (seq.++ ?x64 (seq.++ ?x1033 (seq.++ ?x1401 (seq.++ ?x64 ?x29)))))))
(let ((?x1166 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x64 (seq.++ ?x360 (seq.++ ?x1401 ?x429)))))))
(let ((?x855 (seq.unit (_ bv255 8))))
(let ((?x291 (seq.++ ?x855 (seq.++ ?x855 (seq.++ ?x855 (seq.++ ?x360 (seq.++ ?x64 ?x1166)))))))
(let ((?x1313 (seq.++ ?x855 (seq.++ ?x855 (seq.++ ?x855 ?x291)))))
(= input_0_net.frame_frame ?x1313)))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1960 (= due_1_cache due_0_cache)))
 (let (($x1980 (= due_1_query 1000)))
 (let (($x1303 (= active_1_cache active_0_cache)))
 (let ((?x1173 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x2930 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x1173)))))
 (let ((?x669 (seq.unit (_ bv8 8))))
 (let ((?x1041 (seq.unit (_ bv6 8))))
 (let ((?x3353 (seq.++ ?x1041 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x669 (seq.++ (seq.unit (_ bv9 8)) ?x2930))))))
 (let ((?x2891 (seq.unit (_ bv4 8))))
 (let ((?x2080 (seq.unit (_ bv2 8))))
 (let ((?x264 (seq.++ ?x2080 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x2891 (seq.++ (seq.unit (_ bv5 8)) ?x3353))))))
 (let ((?x3302 (seq.unit (_ bv1 8))))
 (let ((?x913 (seq.unit (_ bv0 8))))
 (let ((?x1281 (seq.++ ?x913 (seq.++ ?x3302 ?x264))))
 (let ((?x1227 (seq.unit (_ bv25 8))))
 (let ((?x3325 (seq.++ ?x913 (seq.++ ?x1227 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv167 8)) ?x1281))))))
 (let ((?x3369 (seq.unit (_ bv144 8))))
 (let ((?x2924 (seq.unit (_ bv31 8))))
 (let ((?x1225 (seq.unit (_ bv64 8))))
 (let ((?x1035 (seq.unit (_ bv156 8))))
 (let ((?x2904 (seq.++ ?x1035 (seq.++ ?x1225 (seq.++ ?x2924 (seq.++ ?x3369 ?x3325))))))
 (let ((?x2568 (seq.unit (_ bv192 8))))
 (let ((?x1195 (seq.++ ?x3302 (seq.++ ?x2568 (seq.++ ?x913 (seq.++ ?x2080 (seq.++ ?x2080 ?x2904)))))))
 (let ((?x1909 (seq.unit (_ bv188 8))))
 (let ((?x3128 (seq.unit (_ bv182 8))))
 (let ((?x480 (seq.++ ?x3128 (seq.++ ?x1909 (seq.++ ?x2568 (seq.++ ?x913 (seq.++ ?x2080 ?x1195)))))))
 (let ((?x3324 (seq.unit (_ bv17 8))))
 (let ((?x694 (seq.++ ?x913 (seq.++ ?x1225 (seq.++ ?x913 (seq.++ ?x1225 (seq.++ ?x3324 ?x480)))))))
 (let ((?x260 (seq.unit (_ bv45 8))))
 (let ((?x2527 (seq.unit (_ bv69 8))))
 (let ((?x2435 (seq.++ ?x2527 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x260 (seq.++ ?x913 ?x694)))))))
 (let (($x1083 (= v_1_pending_packet ?x2435)))
 (let (($x1829 (= v_1_ip_checksum 46780)))
 (let (($x2491 (= v_1_udp_checksum 30631)))
 (let (($x2197 (= v_1_udp_raw_checksum 30631)))
 (let (($x714 (= v_1_ip_length 45)))
 (let (($x2065 (= v_1_udp_length 25)))
 (let (($x2166 (= v_1_packet ?x2435)))
 (let ((?x3107 (seq.++ ?x2080 (seq.++ ?x3302 (seq.++ ?x2568 (seq.++ ?x913 (seq.++ ?x2080 ?x2080)))))))
 (let ((?x3109 (seq.++ ?x2568 (seq.++ ?x913 ?x3107))))
 (let ((?x2945 (seq.++ ?x913 (seq.++ ?x1225 (seq.++ ?x3324 (seq.++ ?x3128 (seq.++ ?x1909 ?x3109)))))))
 (let ((?x2947 (seq.++ ?x913 (seq.++ ?x260 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x1225 ?x2945)))))))
 (let (($x1918 (= v_1_ip_wire (seq.++ ?x2527 (seq.++ ?x913 ?x2947)))))
 (let ((?x666 (seq.++ ?x913 (seq.++ ?x1225 (seq.++ ?x3324 (seq.++ ?x913 (seq.++ ?x913 ?x3109)))))))
 (let ((?x2810 (seq.++ ?x913 (seq.++ ?x260 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x1225 ?x666)))))))
 (let (($x1602 (= v_1_ip_zero (seq.++ ?x2527 (seq.++ ?x913 ?x2810)))))
 (let (($x1723 (= v_1_udp_wire ?x2904)))
 (let ((?x2921 (seq.++ ?x2080 (seq.++ ?x2080 (seq.++ ?x913 (seq.++ ?x3324 (seq.++ ?x913 ?x1227)))))))
 (let ((?x1131 (seq.++ ?x913 (seq.++ ?x2080 (seq.++ ?x3302 (seq.++ ?x2568 (seq.++ ?x913 ?x2921)))))))
 (let (($x2927 (= v_1_pseudoheader (seq.++ ?x2568 ?x1131))))
 (let ((?x3192 (seq.++ ?x3369 (seq.++ ?x913 (seq.++ ?x1227 (seq.++ ?x913 (seq.++ ?x913 ?x1281)))))))
 (let (($x3102 (= v_1_udp_zero (seq.++ ?x1035 (seq.++ ?x1225 (seq.++ ?x2924 ?x3192))))))
 (let (($x627 (= v_1_payload ?x1281)))
 (let (($x2157 (= v_1_cache_ttl_ms 60000)))
 (let (($x1887 (= 0 v_1_retry_count)))
 (let (($x882 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x2440 (= 1 state_1)))
 (let (($x441 (not active_0_cache)))
 (let (($x848 (or $x441 (not (<= due_0_cache 0)))))
 (let (($x2138 (not active_0_query)))
 (let (($x1824 (or $x2138 (not (<= due_0_query 0)))))
 (let (($x3002 (= state_0 0)))
 (and $x3002 (>= 0 now_0) $x1824 $x848 $x2440 $x882 $x1887 $x2157 v_1_checksums_enabled $x627 $x3102 $x2927 $x1723 $x1602 $x1918 $x2166 $x2065 $x714 $x2197 $x2491 $x1829 $x1083 active_1_query $x1303 $x1980 $x1960))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1238 (= due_2_query due_1_query)))
 (let (($x1828 (not active_2_query)))
 (let (($x1808 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x248 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2507 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x737 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1260 (= v_2_ip_length v_1_ip_length)))
 (let (($x188 (= v_2_udp_length v_1_udp_length)))
 (let (($x24 (= v_2_packet v_1_packet)))
 (let (($x2035 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x647 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x1009 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x699 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x588 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x795 (= v_2_payload v_1_payload)))
 (let (($x1177 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x845 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2241 (= 0 v_2_retry_count)))
 (let ((?x913 (seq.unit (_ bv0 8))))
 (let ((?x3442 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.unit (_ bv2 8))))))))
 (let ((?x2080 (seq.unit (_ bv2 8))))
 (let (($x3389 (= v_2_peer_mac (seq.++ ?x2080 ?x3442))))
 (let (($x2827 (= 2 state_2)))
 (let (($x1542 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x2957 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x2191 (seq.len v_1_pending_packet)))
 (let (($x2187 (<= 28 ?x2191)))
 (let (($x590 (= state_1 1)))
 (and $x590 $x2187 $x2957 $x1542 $x2827 $x3389 $x2241 $x845 $x1177 $x795 $x588 $x699 $x1009 $x647 $x2035 $x24 $x188 $x1260 $x737 $x2507 $x248 $x1808 $x1828 active_2_cache $x1238 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1173 (seq.++ (seq.unit (_ bv13 8)) (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.unit (_ bv16 8)))))))
 (let ((?x2930 (seq.++ (seq.unit (_ bv10 8)) (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) ?x1173)))))
 (let ((?x669 (seq.unit (_ bv8 8))))
 (let ((?x1041 (seq.unit (_ bv6 8))))
 (let ((?x3353 (seq.++ ?x1041 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x669 (seq.++ (seq.unit (_ bv9 8)) ?x2930))))))
 (let ((?x2891 (seq.unit (_ bv4 8))))
 (let ((?x2080 (seq.unit (_ bv2 8))))
 (let ((?x264 (seq.++ ?x2080 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x2891 (seq.++ (seq.unit (_ bv5 8)) ?x3353))))))
 (let ((?x3302 (seq.unit (_ bv1 8))))
 (let ((?x913 (seq.unit (_ bv0 8))))
 (let ((?x1281 (seq.++ ?x913 (seq.++ ?x3302 ?x264))))
 (= input_0_app.send_data ?x1281)))))))))))))
(assert
 (= 28 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x2568 (seq.unit (_ bv192 8))))
(let ((?x621 (seq.++ ?x2568 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x3302 (seq.unit (_ bv1 8))))
(let ((?x913 (seq.unit (_ bv0 8))))
(let ((?x116 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x3302 ?x621)))))))
(let ((?x2080 (seq.unit (_ bv2 8))))
(let ((?x1091 (seq.++ ?x2568 (seq.++ ?x913 (seq.++ ?x2080 (seq.++ ?x2080 (seq.++ ?x2080 ?x116)))))))
(let ((?x3321 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x2080 ?x1091)))))))
(let ((?x2891 (seq.unit (_ bv4 8))))
(let ((?x1041 (seq.unit (_ bv6 8))))
(let ((?x3433 (seq.++ ?x1041 (seq.++ ?x2891 (seq.++ ?x913 (seq.++ ?x2080 (seq.++ ?x2080 ?x3321)))))))
(let ((?x669 (seq.unit (_ bv8 8))))
(let ((?x23401 (seq.++ ?x1041 (seq.++ ?x913 (seq.++ ?x3302 (seq.++ ?x669 (seq.++ ?x913 ?x3433)))))))
(let ((?x320 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x2080 (seq.++ ?x669 ?x23401)))))))
(let ((?x3435 (seq.++ ?x913 (seq.++ ?x913 (seq.++ ?x3302 (seq.++ ?x2080 (seq.++ ?x913 ?x320)))))))
(let ((?x2430 (seq.++ ?x2080 (seq.++ ?x913 (seq.++ ?x913 ?x3435)))))
(= input_1_net.frame_frame ?x2430))))))))))))))))))
(check-sat)

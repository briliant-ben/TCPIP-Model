; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1351 (= due_1_cache due_0_cache)))
 (let (($x2671 (= due_1_query 1000)))
 (let (($x2635 (= active_1_cache active_0_cache)))
 (let (($x2660 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2347 (= v_1_ip_checksum 0)))
 (let (($x1056 (= v_1_udp_checksum 0)))
 (let (($x6 (= v_1_udp_raw_checksum 0)))
 (let (($x3433 (= v_1_ip_length 0)))
 (let (($x2188 (= v_1_udp_length 0)))
 (let (($x147 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x304 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x5 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x7232 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1479 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1063 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x1405 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x320 (= v_1_cache_ttl_ms 60000)))
 (let (($x1499 (= 0 v_1_retry_count)))
 (let (($x2926 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x863 (= 1 state_1)))
 (let (($x1801 (not active_0_cache)))
 (let (($x1682 (or $x1801 (not (<= due_0_cache 0)))))
 (let (($x2000 (not active_0_query)))
 (let (($x3300 (or $x2000 (not (<= due_0_query 0)))))
 (let (($x1975 (= state_0 0)))
 (and $x1975 (>= 0 now_0) $x3300 $x1682 $x863 $x2926 $x1499 $x320 v_1_checksums_enabled $x1405 $x1063 $x1479 $x7232 $x5 $x304 $x147 $x2188 $x3433 $x6 $x1056 $x2347 $x2660 active_1_query $x2635 $x2671 $x1351)))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2703 (= due_2_cache due_1_cache)))
 (let (($x23394 (= due_2_query 2000)))
 (let (($x669 (= active_2_cache active_1_cache)))
 (let (($x3196 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x3185 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2873 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x2161 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x11283 (= v_2_ip_length v_1_ip_length)))
 (let (($x2774 (= v_2_udp_length v_1_udp_length)))
 (let (($x1227 (= v_2_packet v_1_packet)))
 (let (($x1195 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1241 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x3171 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x1970 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2527 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2152 (= v_2_payload v_1_payload)))
 (let (($x1935 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x343 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x260 (= 1 v_2_retry_count)))
 (let (($x1308 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x2986 (= 1 state_2)))
 (let (($x1499 (= 0 v_1_retry_count)))
 (let (($x3247 (= state_1 1)))
 (and $x3247 $x1499 active_1_query (= 1000 due_1_query) (or (not active_1_cache) (not (<= due_1_cache due_1_query))) $x2986 $x1308 $x260 $x343 $x1935 $x2152 $x2527 $x1970 $x3171 $x1241 $x1195 $x1227 $x2774 $x11283 $x2161 $x2873 $x3185 $x3196 active_2_query $x669 $x23394 $x2703)))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3109 (= due_3_cache due_2_cache)))
 (let (($x2946 (= due_3_query due_2_query)))
 (let (($x2943 (= active_3_cache active_2_cache)))
 (let (($x578 (not active_3_query)))
 (let (($x3423 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x803 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x45 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x2989 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x2059 (= v_3_ip_length v_2_ip_length)))
 (let (($x3000 (= v_3_udp_length v_2_udp_length)))
 (let (($x3001 (= v_3_packet v_2_packet)))
 (let (($x763 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x1550 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x337 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x742 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x1957 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x370 (= v_3_payload v_2_payload)))
 (let (($x2165 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2384 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x2719 (= 0 v_3_retry_count)))
 (let (($x2374 (= (as seq.empty (Seq (_ BitVec 8))) v_3_peer_mac)))
 (let (($x1444 (= 0 state_3)))
 (let ((?x432 (seq.len v_2_pending_packet)))
 (let (($x2352 (= 0 ?x432)))
 (let (($x260 (= 1 v_2_retry_count)))
 (let (($x2793 (= state_2 1)))
 (and $x2793 $x260 $x2352 active_2_query (= 2000 due_2_query) (or (not active_2_cache) (not (<= due_2_cache due_2_query))) $x1444 $x2374 $x2719 $x2384 $x2165 $x370 $x1957 $x742 $x337 $x1550 $x763 $x3001 $x3000 $x2059 $x2989 $x45 $x803 $x3423 $x578 $x2943 $x2946 $x3109))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x821 (seq.unit (_ bv192 8))))
 (let ((?x2914 (seq.++ ?x821 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x2914))))
(assert
 (= 3 choice_1))
(assert
 (= 1000 now_2))
(assert
 (= 25 choice_2))
(assert
 (= 2000 now_3))
(check-sat)

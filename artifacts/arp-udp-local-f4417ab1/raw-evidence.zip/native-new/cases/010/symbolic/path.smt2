; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1591 (= due_1_cache due_0_cache)))
 (let (($x2036 (= due_1_query 1000)))
 (let (($x626 (= active_1_cache active_0_cache)))
 (let (($x2181 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2532 (= v_1_ip_checksum 0)))
 (let (($x2900 (= v_1_udp_checksum 0)))
 (let (($x1070 (= v_1_udp_raw_checksum 0)))
 (let (($x3237 (= v_1_ip_length 0)))
 (let (($x324 (= v_1_udp_length 0)))
 (let (($x2297 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x2820 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x270 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x539 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x2166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x714 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x3314 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x1980 (= v_1_cache_ttl_ms 60000)))
 (let (($x2973 (= 0 v_1_retry_count)))
 (let (($x2233 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x2945 (= 1 state_1)))
 (let (($x1712 (not active_0_cache)))
 (let (($x16011 (or $x1712 (not (<= due_0_cache 0)))))
 (let (($x1201 (not active_0_query)))
 (let (($x3100 (or $x1201 (not (<= due_0_query 0)))))
 (let (($x2509 (= state_0 0)))
 (and $x2509 (>= 0 now_0) $x3100 $x16011 $x2945 $x2233 $x2973 $x1980 v_1_checksums_enabled $x3314 $x714 $x2166 $x539 $x270 $x2820 $x2297 $x324 $x3237 $x1070 $x2900 $x2532 $x2181 active_1_query $x626 $x2036 $x1591)))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x60 (= due_2_cache due_1_cache)))
 (let (($x1362 (= due_2_query due_1_query)))
 (let (($x3296 (= active_2_cache active_1_cache)))
 (let (($x3295 (= active_2_query active_1_query)))
 (let ((?x3014 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2111 (seq.unit (_ bv0 8))))
 (let ((?x1057 (seq.++ ?x2111 ?x3014)))
 (let ((?x2671 (seq.++ (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49271 0)))) ?x1057)))
 (let ((?x2323 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) (ite v_1_checksums_enabled 49271 0)))) ?x2671)))
 (let ((?x3355 (seq.unit (_ bv13 8))))
 (let ((?x325 (seq.unit (_ bv144 8))))
 (let ((?x2927 (seq.unit (_ bv31 8))))
 (let ((?x3292 (seq.unit (_ bv64 8))))
 (let ((?x1926 (seq.++ ?x3292 (seq.++ ?x2927 (seq.++ ?x325 (seq.++ ?x2111 (seq.++ ?x3355 ?x2323)))))))
 (let ((?x2298 (seq.unit (_ bv156 8))))
 (let ((?x752 (seq.++ ?x2298 ?x1926)))
 (let ((?x1036 (seq.unit (_ bv2 8))))
 (let ((?x1039 (seq.unit (_ bv192 8))))
 (let ((?x374 (seq.unit (_ bv1 8))))
 (let ((?x255 (seq.++ ?x374 (seq.++ ?x1039 (seq.++ ?x2111 (seq.++ ?x1036 (seq.++ ?x1036 ?x752)))))))
 (let ((?x313 (seq.unit (_ bv200 8))))
 (let ((?x1570 (seq.unit (_ bv182 8))))
 (let ((?x286 (seq.++ ?x1570 (seq.++ ?x313 (seq.++ ?x1039 (seq.++ ?x2111 (seq.++ ?x1036 ?x255)))))))
 (let ((?x2288 (seq.unit (_ bv17 8))))
 (let ((?x1477 (seq.++ ?x2111 (seq.++ ?x3292 (seq.++ ?x2111 (seq.++ ?x3292 (seq.++ ?x2288 ?x286)))))))
 (let ((?x1357 (seq.unit (_ bv33 8))))
 (let ((?x3223 (seq.unit (_ bv69 8))))
 (let ((?x1246 (seq.++ ?x3223 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x1357 (seq.++ ?x2111 ?x1477)))))))
 (let (($x2344 (= v_2_pending_packet ?x1246)))
 (let (($x1615 (= v_2_ip_checksum 46792)))
 (let ((?x520 (ite v_1_checksums_enabled 49271 0)))
 (let (($x1440 (= v_2_udp_checksum ?x520)))
 (let (($x1999 (= v_2_udp_raw_checksum 49271)))
 (let (($x814 (= v_2_ip_length 33)))
 (let (($x1333 (= v_2_udp_length 13)))
 (let (($x1650 (= v_2_packet ?x1246)))
 (let ((?x147 (seq.++ ?x1036 (seq.++ ?x374 (seq.++ ?x1039 (seq.++ ?x2111 (seq.++ ?x1036 ?x1036)))))))
 (let ((?x2764 (seq.++ ?x1039 (seq.++ ?x2111 ?x147))))
 (let ((?x1024 (seq.++ ?x2111 (seq.++ ?x3292 (seq.++ ?x2288 (seq.++ ?x1570 (seq.++ ?x313 ?x2764)))))))
 (let ((?x1958 (seq.++ ?x2111 (seq.++ ?x1357 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x3292 ?x1024)))))))
 (let (($x2855 (= v_2_ip_wire (seq.++ ?x3223 (seq.++ ?x2111 ?x1958)))))
 (let ((?x2978 (seq.++ ?x2111 (seq.++ ?x3292 (seq.++ ?x2288 (seq.++ ?x2111 (seq.++ ?x2111 ?x2764)))))))
 (let ((?x2615 (seq.++ ?x2111 (seq.++ ?x1357 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x3292 ?x2978)))))))
 (let (($x956 (= v_2_ip_zero (seq.++ ?x3223 (seq.++ ?x2111 ?x2615)))))
 (let (($x2374 (= v_2_udp_wire ?x752)))
 (let ((?x747 (seq.++ ?x1036 (seq.++ ?x1036 (seq.++ ?x2111 (seq.++ ?x2288 (seq.++ ?x2111 ?x3355)))))))
 (let ((?x3115 (seq.++ ?x2111 (seq.++ ?x1036 (seq.++ ?x374 (seq.++ ?x1039 (seq.++ ?x2111 ?x747)))))))
 (let (($x565 (= v_2_pseudoheader (seq.++ ?x1039 ?x3115))))
 (let ((?x2598 (seq.++ ?x325 (seq.++ ?x2111 (seq.++ ?x3355 (seq.++ ?x2111 (seq.++ ?x2111 ?x1057)))))))
 (let (($x3006 (= v_2_udp_zero (seq.++ ?x2298 (seq.++ ?x3292 (seq.++ ?x2927 ?x2598))))))
 (let (($x1816 (= v_2_payload ?x1057)))
 (let (($x3022 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2565 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1507 (= v_2_retry_count v_1_retry_count)))
 (let (($x2232 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x966 (= 1 state_2)))
 (let (($x2683 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x3170 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x19600 (= state_1 1)))
 (and $x19600 $x3170 $x2683 $x966 $x2232 $x1507 $x2565 $x3022 $x1816 $x3006 $x565 $x2374 $x956 $x2855 $x1650 $x1333 $x814 $x1999 $x1440 $x1615 $x2344 $x3295 $x3296 $x1362 $x60)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x766 (= due_3_query due_2_query)))
 (let (($x980 (not active_3_query)))
 (let (($x2189 (= (as seq.empty (Seq (_ BitVec 8))) v_3_pending_packet)))
 (let (($x1802 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x106 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x726 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x3066 (= v_3_ip_length v_2_ip_length)))
 (let (($x3364 (= v_3_udp_length v_2_udp_length)))
 (let (($x1619 (= v_3_packet v_2_packet)))
 (let (($x731 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x67 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x7996 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x509 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x2127 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x2894 (= v_3_payload v_2_payload)))
 (let (($x1315 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2087 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x3121 (= 0 v_3_retry_count)))
 (let ((?x2111 (seq.unit (_ bv0 8))))
 (let ((?x3003 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.unit (_ bv2 8))))))))
 (let ((?x1036 (seq.unit (_ bv2 8))))
 (let (($x1992 (= v_3_peer_mac (seq.++ ?x1036 ?x3003))))
 (let (($x1468 (= 2 state_3)))
 (let (($x193 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x511 (or (not active_2_query) (not (<= due_2_query 10)))))
 (let ((?x1285 (seq.len v_2_pending_packet)))
 (let (($x2046 (<= 28 ?x1285)))
 (let (($x1977 (= state_2 1)))
 (and $x1977 $x2046 $x511 $x193 $x1468 $x1992 $x3121 $x2087 $x1315 $x2894 $x2127 $x509 $x7996 $x67 $x731 $x1619 $x3364 $x3066 $x726 $x106 $x1802 $x2189 $x980 active_3_cache $x766 (= due_3_cache (+ 10 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1039 (seq.unit (_ bv192 8))))
 (let ((?x1975 (seq.++ ?x1039 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x1975))))
(assert
 (= 20 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x3014 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2111 (seq.unit (_ bv0 8))))
 (let ((?x1057 (seq.++ ?x2111 ?x3014)))
 (= input_1_app.send_data ?x1057)))))
(assert
 (= 28 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x1039 (seq.unit (_ bv192 8))))
(let ((?x2479 (seq.++ ?x1039 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x374 (seq.unit (_ bv1 8))))
(let ((?x2111 (seq.unit (_ bv0 8))))
(let ((?x141 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x374 ?x2479)))))))
(let ((?x1036 (seq.unit (_ bv2 8))))
(let ((?x1997 (seq.++ ?x1039 (seq.++ ?x2111 (seq.++ ?x1036 (seq.++ ?x1036 (seq.++ ?x1036 ?x141)))))))
(let ((?x2547 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x1036 ?x1997)))))))
(let ((?x3318 (seq.unit (_ bv4 8))))
(let ((?x1539 (seq.unit (_ bv6 8))))
(let ((?x3133 (seq.++ ?x1539 (seq.++ ?x3318 (seq.++ ?x2111 (seq.++ ?x1036 (seq.++ ?x1036 ?x2547)))))))
(let ((?x2016 (seq.unit (_ bv8 8))))
(let ((?x2504 (seq.++ ?x1539 (seq.++ ?x2111 (seq.++ ?x374 (seq.++ ?x2016 (seq.++ ?x2111 ?x3133)))))))
(let ((?x3452 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x1036 (seq.++ ?x2016 ?x2504)))))))
(let ((?x2566 (seq.++ ?x2111 (seq.++ ?x2111 (seq.++ ?x374 (seq.++ ?x1036 (seq.++ ?x2111 ?x3452)))))))
(let ((?x645 (seq.++ ?x1036 (seq.++ ?x2111 (seq.++ ?x2111 ?x2566)))))
(= input_2_net.frame_frame ?x645))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x3184 (= due_1_cache 60000)))
 (let (($x2854 (= due_1_query due_0_query)))
 (let (($x3217 (not active_1_query)))
 (let (($x3433 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pending_packet)))
 (let (($x2642 (= v_1_ip_checksum 0)))
 (let (($x241 (= v_1_udp_checksum 0)))
 (let (($x1504 (= v_1_udp_raw_checksum 0)))
 (let (($x1091 (= v_1_ip_length 0)))
 (let (($x3265 (= v_1_udp_length 0)))
 (let (($x3059 (= (as seq.empty (Seq (_ BitVec 8))) v_1_packet)))
 (let (($x1720 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_wire)))
 (let (($x2943 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x3067 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_wire)))
 (let (($x1013 (= (as seq.empty (Seq (_ BitVec 8))) v_1_pseudoheader)))
 (let (($x1837 (= (as seq.empty (Seq (_ BitVec 8))) v_1_udp_zero)))
 (let (($x760 (= (as seq.empty (Seq (_ BitVec 8))) v_1_payload)))
 (let (($x2249 (= v_1_cache_ttl_ms 60000)))
 (let (($x952 (= 0 v_1_retry_count)))
 (let ((?x3028 (seq.unit (_ bv0 8))))
 (let ((?x2784 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.unit (_ bv2 8))))))))
 (let ((?x1029 (seq.unit (_ bv2 8))))
 (let (($x2532 (= v_1_peer_mac (seq.++ ?x1029 ?x2784))))
 (let (($x528 (= 2 state_1)))
 (let (($x1405 (not active_0_cache)))
 (let (($x167 (or $x1405 (not (<= due_0_cache 0)))))
 (let (($x547 (not active_0_query)))
 (let (($x2470 (or $x547 (not (<= due_0_query 0)))))
 (let (($x2741 (= state_0 0)))
 (and $x2741 (>= 0 now_0) $x2470 $x167 $x528 $x2532 $x952 $x2249 v_1_checksums_enabled $x760 $x1837 $x1013 $x3067 $x2943 $x1720 $x3059 $x3265 $x1091 $x1504 $x241 $x2642 $x3433 $x3217 active_1_cache $x2854 $x3184))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1446 (= due_2_cache due_1_cache)))
 (let (($x1267 (= due_2_query due_1_query)))
 (let (($x170 (= active_2_cache active_1_cache)))
 (let (($x602 (= active_2_query active_1_query)))
 (let (($x307 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x637 (= v_2_ip_checksum 46797)))
 (let ((?x534 (ite v_1_checksums_enabled 49161 0)))
 (let (($x11281 (= v_2_udp_checksum ?x534)))
 (let (($x1953 (= v_2_udp_raw_checksum 49161)))
 (let (($x2439 (= v_2_ip_length 28)))
 (let (($x2498 (= v_2_udp_length 8)))
 (let ((?x2787 (seq.++ (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) ?x534))) (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) ?x534))))))
 (let ((?x2398 (seq.unit (_ bv8 8))))
 (let ((?x3028 (seq.unit (_ bv0 8))))
 (let ((?x846 (seq.unit (_ bv144 8))))
 (let ((?x1707 (seq.unit (_ bv31 8))))
 (let ((?x1509 (seq.unit (_ bv64 8))))
 (let ((?x485 (seq.++ ?x1509 (seq.++ ?x1707 (seq.++ ?x846 (seq.++ ?x3028 (seq.++ ?x2398 ?x2787)))))))
 (let ((?x425 (seq.unit (_ bv156 8))))
 (let ((?x8048 (seq.++ ?x425 ?x485)))
 (let ((?x1029 (seq.unit (_ bv2 8))))
 (let ((?x293 (seq.unit (_ bv192 8))))
 (let ((?x1545 (seq.unit (_ bv1 8))))
 (let ((?x3181 (seq.++ ?x1545 (seq.++ ?x293 (seq.++ ?x3028 (seq.++ ?x1029 (seq.++ ?x1029 ?x8048)))))))
 (let ((?x3468 (seq.unit (_ bv205 8))))
 (let ((?x1515 (seq.unit (_ bv182 8))))
 (let ((?x1970 (seq.++ ?x1515 (seq.++ ?x3468 (seq.++ ?x293 (seq.++ ?x3028 (seq.++ ?x1029 ?x3181)))))))
 (let ((?x1355 (seq.unit (_ bv17 8))))
 (let ((?x2437 (seq.++ ?x3028 (seq.++ ?x1509 (seq.++ ?x3028 (seq.++ ?x1509 (seq.++ ?x1355 ?x1970)))))))
 (let ((?x1465 (seq.unit (_ bv28 8))))
 (let ((?x706 (seq.unit (_ bv69 8))))
 (let ((?x2389 (seq.++ ?x706 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1465 (seq.++ ?x3028 ?x2437)))))))
 (let (($x3347 (= v_2_packet ?x2389)))
 (let ((?x571 (seq.++ ?x1029 (seq.++ ?x1545 (seq.++ ?x293 (seq.++ ?x3028 (seq.++ ?x1029 ?x1029)))))))
 (let ((?x1492 (seq.++ ?x293 (seq.++ ?x3028 ?x571))))
 (let ((?x1129 (seq.++ ?x3028 (seq.++ ?x1509 (seq.++ ?x1355 (seq.++ ?x1515 (seq.++ ?x3468 ?x1492)))))))
 (let ((?x723 (seq.++ ?x3028 (seq.++ ?x1465 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1509 ?x1129)))))))
 (let (($x805 (= v_2_ip_wire (seq.++ ?x706 (seq.++ ?x3028 ?x723)))))
 (let ((?x1124 (seq.++ ?x3028 (seq.++ ?x1509 (seq.++ ?x1355 (seq.++ ?x3028 (seq.++ ?x3028 ?x1492)))))))
 (let ((?x1151 (seq.++ ?x3028 (seq.++ ?x1465 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1509 ?x1124)))))))
 (let (($x2534 (= v_2_ip_zero (seq.++ ?x706 (seq.++ ?x3028 ?x1151)))))
 (let (($x311 (= v_2_udp_wire ?x8048)))
 (let ((?x522 (seq.++ ?x1029 (seq.++ ?x1029 (seq.++ ?x3028 (seq.++ ?x1355 (seq.++ ?x3028 ?x2398)))))))
 (let ((?x1583 (seq.++ ?x3028 (seq.++ ?x1029 (seq.++ ?x1545 (seq.++ ?x293 (seq.++ ?x3028 ?x522)))))))
 (let (($x19538 (= v_2_pseudoheader (seq.++ ?x293 ?x1583))))
 (let ((?x2333 (seq.++ ?x1707 (seq.++ ?x846 (seq.++ ?x3028 (seq.++ ?x2398 (seq.++ ?x3028 ?x3028)))))))
 (let (($x841 (= v_2_udp_zero (seq.++ ?x425 (seq.++ ?x1509 ?x2333)))))
 (let (($x2606 (= (as seq.empty (Seq (_ BitVec 8))) v_2_payload)))
 (let (($x1242 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3448 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x2723 (= v_2_retry_count v_1_retry_count)))
 (let (($x2832 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1567 (= 2 state_2)))
 (let (($x2757 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x3217 (not active_1_query)))
 (let (($x7113 (or $x3217 (not (<= due_1_query 1)))))
 (let (($x2669 (= state_1 2)))
 (and $x2669 $x7113 $x2757 $x1567 $x2832 $x2723 $x3448 $x1242 $x2606 $x841 $x19538 $x311 $x2534 $x805 $x3347 $x2498 $x2439 $x1953 $x11281 $x637 $x307 $x602 $x170 $x1267 $x1446)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x636 (= due_3_cache due_2_cache)))
 (let (($x352 (= due_3_query due_2_query)))
 (let (($x1053 (= active_3_cache active_2_cache)))
 (let (($x2517 (= active_3_query active_2_query)))
 (let (($x1969 (= v_3_pending_packet v_2_pending_packet)))
 (let (($x2053 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x1233 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x2770 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x1818 (= v_3_ip_length v_2_ip_length)))
 (let (($x1881 (= v_3_udp_length v_2_udp_length)))
 (let (($x1052 (= v_3_packet v_2_packet)))
 (let (($x2365 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x3259 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x2998 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x679 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x853 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x1856 (= v_3_payload v_2_payload)))
 (let (($x1264 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x327 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x1958 (= v_3_retry_count v_2_retry_count)))
 (let (($x62 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x2496 (= 2 state_3)))
 (let (($x799 (or (not active_2_cache) (not (<= due_2_cache 2)))))
 (let (($x3101 (or (not active_2_query) (not (<= due_2_query 2)))))
 (let (($x970 (= state_2 2)))
 (and $x970 $x3101 $x799 $x2496 $x62 $x1958 $x327 $x1264 $x1856 $x853 $x679 $x2998 $x3259 $x2365 $x1052 $x1881 $x1818 $x2770 $x1233 $x2053 $x1969 $x2517 $x1053 $x352 $x636)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x293 (seq.unit (_ bv192 8))))
 (let ((?x1541 (seq.++ ?x293 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x1545 (seq.unit (_ bv1 8))))
 (let ((?x3028 (seq.unit (_ bv0 8))))
 (let ((?x3205 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1545 ?x1541)))))))
 (let ((?x1029 (seq.unit (_ bv2 8))))
 (let ((?x364 (seq.++ ?x293 (seq.++ ?x3028 (seq.++ ?x1029 (seq.++ ?x1029 (seq.++ ?x1029 ?x3205)))))))
 (let ((?x3236 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1029 ?x364)))))))
 (let ((?x3328 (seq.unit (_ bv4 8))))
 (let ((?x652 (seq.unit (_ bv6 8))))
 (let ((?x3073 (seq.++ ?x652 (seq.++ ?x3328 (seq.++ ?x3028 (seq.++ ?x1029 (seq.++ ?x1029 ?x3236)))))))
 (let ((?x2398 (seq.unit (_ bv8 8))))
 (let ((?x921 (seq.++ ?x652 (seq.++ ?x3028 (seq.++ ?x1545 (seq.++ ?x2398 (seq.++ ?x3028 ?x3073)))))))
 (let ((?x2060 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1029 (seq.++ ?x2398 ?x921)))))))
 (let ((?x251 (seq.++ ?x3028 (seq.++ ?x3028 (seq.++ ?x1545 (seq.++ ?x1029 (seq.++ ?x3028 ?x2060)))))))
 (let ((?x1931 (seq.++ ?x1029 (seq.++ ?x3028 (seq.++ ?x3028 ?x251)))))
 (= input_0_net.frame_frame ?x1931))))))))))))))))))
(assert
 (= 22 choice_1))
(assert
 (= 1 now_2))
(assert
 (= input_1_app.send_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 2 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x293 (seq.unit (_ bv192 8))))
(let ((?x2093 (seq.++ ?x293 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x2093))))
(check-sat)

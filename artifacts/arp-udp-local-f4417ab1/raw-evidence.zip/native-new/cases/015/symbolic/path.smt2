; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1292 (= due_1_cache due_0_cache)))
 (let (($x1136 (= due_1_query 1000)))
 (let (($x2867 (= active_1_cache active_0_cache)))
 (let ((?x2438 (seq.unit (_ bv255 8))))
 (let ((?x615 (seq.unit (_ bv10 8))))
 (let ((?x1746 (seq.++ ?x615 (seq.++ ?x2438 (seq.++ ?x2438 (seq.++ (seq.unit (_ bv192 8)) (seq.unit (_ bv5 8))))))))
 (let ((?x946 (seq.unit (_ bv0 8))))
 (let ((?x3108 (seq.unit (_ bv144 8))))
 (let ((?x2339 (seq.unit (_ bv31 8))))
 (let ((?x3093 (seq.unit (_ bv64 8))))
 (let ((?x163 (seq.unit (_ bv156 8))))
 (let ((?x1144 (seq.++ ?x163 (seq.++ ?x3093 (seq.++ ?x2339 (seq.++ ?x3108 (seq.++ ?x946 ?x1746)))))))
 (let ((?x128 (seq.unit (_ bv2 8))))
 (let ((?x766 (seq.unit (_ bv192 8))))
 (let ((?x2908 (seq.unit (_ bv1 8))))
 (let ((?x291 (seq.++ ?x2908 (seq.++ ?x766 (seq.++ ?x946 (seq.++ ?x128 (seq.++ ?x128 ?x1144)))))))
 (let ((?x2474 (seq.unit (_ bv203 8))))
 (let ((?x23355 (seq.unit (_ bv182 8))))
 (let ((?x2975 (seq.++ ?x23355 (seq.++ ?x2474 (seq.++ ?x766 (seq.++ ?x946 (seq.++ ?x128 ?x291)))))))
 (let ((?x2113 (seq.unit (_ bv17 8))))
 (let ((?x2184 (seq.++ ?x946 (seq.++ ?x3093 (seq.++ ?x946 (seq.++ ?x3093 (seq.++ ?x2113 ?x2975)))))))
 (let ((?x2968 (seq.unit (_ bv30 8))))
 (let ((?x2179 (seq.unit (_ bv69 8))))
 (let ((?x1844 (seq.++ ?x2179 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x2968 (seq.++ ?x946 ?x2184)))))))
 (let (($x2287 (= v_1_pending_packet ?x1844)))
 (let (($x1609 (= v_1_ip_checksum 46795)))
 (let (($x891 (= v_1_udp_checksum 65535)))
 (let (($x3184 (= v_1_udp_raw_checksum 0)))
 (let (($x3217 (= v_1_ip_length 30)))
 (let (($x1269 (= v_1_udp_length 10)))
 (let (($x2045 (= v_1_packet ?x1844)))
 (let ((?x3431 (seq.++ ?x128 (seq.++ ?x2908 (seq.++ ?x766 (seq.++ ?x946 (seq.++ ?x128 ?x128)))))))
 (let ((?x3359 (seq.++ ?x766 (seq.++ ?x946 ?x3431))))
 (let ((?x23040 (seq.++ ?x946 (seq.++ ?x3093 (seq.++ ?x2113 (seq.++ ?x23355 (seq.++ ?x2474 ?x3359)))))))
 (let ((?x2741 (seq.++ ?x946 (seq.++ ?x2968 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x3093 ?x23040)))))))
 (let (($x215 (= v_1_ip_wire (seq.++ ?x2179 (seq.++ ?x946 ?x2741)))))
 (let ((?x1029 (seq.++ ?x946 (seq.++ ?x3093 (seq.++ ?x2113 (seq.++ ?x946 (seq.++ ?x946 ?x3359)))))))
 (let ((?x843 (seq.++ ?x946 (seq.++ ?x2968 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x3093 ?x1029)))))))
 (let (($x2696 (= v_1_ip_zero (seq.++ ?x2179 (seq.++ ?x946 ?x843)))))
 (let (($x3433 (= v_1_udp_wire ?x1144)))
 (let ((?x1506 (seq.++ ?x128 (seq.++ ?x128 (seq.++ ?x946 (seq.++ ?x2113 (seq.++ ?x946 ?x615)))))))
 (let ((?x2661 (seq.++ ?x946 (seq.++ ?x128 (seq.++ ?x2908 (seq.++ ?x766 (seq.++ ?x946 ?x1506)))))))
 (let (($x3059 (= v_1_pseudoheader (seq.++ ?x766 ?x2661))))
 (let ((?x783 (seq.++ ?x615 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x766 (seq.unit (_ bv5 8))))))))
 (let ((?x910 (seq.++ ?x163 (seq.++ ?x3093 (seq.++ ?x2339 (seq.++ ?x3108 (seq.++ ?x946 ?x783)))))))
 (let (($x1720 (= v_1_udp_zero ?x910)))
 (let ((?x441 (seq.++ ?x766 (seq.unit (_ bv5 8)))))
 (let (($x2943 (= v_1_payload ?x441)))
 (let (($x1437 (= v_1_cache_ttl_ms 60000)))
 (let (($x2949 (= 0 v_1_retry_count)))
 (let (($x1013 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x760 (= 1 state_1)))
 (let (($x868 (not active_0_cache)))
 (let (($x422 (or $x868 (not (<= due_0_cache 0)))))
 (let (($x2332 (not active_0_query)))
 (let (($x84 (or $x2332 (not (<= due_0_query 0)))))
 (let (($x3408 (= state_0 0)))
 (and $x3408 (>= 0 now_0) $x84 $x422 $x760 $x1013 $x2949 $x1437 v_1_checksums_enabled $x2943 $x1720 $x3059 $x3433 $x2696 $x215 $x2045 $x1269 $x3217 $x3184 $x891 $x1609 $x2287 active_1_query $x2867 $x1136 $x1292)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x3203 (= due_2_query due_1_query)))
 (let (($x1569 (not active_2_query)))
 (let (($x3063 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x2972 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x786 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1185 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x887 (= v_2_ip_length v_1_ip_length)))
 (let (($x2199 (= v_2_udp_length v_1_udp_length)))
 (let (($x657 (= v_2_packet v_1_packet)))
 (let (($x1455 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x2568 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x954 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x533 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1686 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2625 (= v_2_payload v_1_payload)))
 (let (($x42 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3206 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x3140 (= 0 v_2_retry_count)))
 (let ((?x946 (seq.unit (_ bv0 8))))
 (let ((?x1018 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.unit (_ bv2 8))))))))
 (let ((?x128 (seq.unit (_ bv2 8))))
 (let (($x1070 (= v_2_peer_mac (seq.++ ?x128 ?x1018))))
 (let (($x1259 (= 2 state_2)))
 (let (($x3208 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x2429 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x2239 (seq.len v_1_pending_packet)))
 (let (($x3156 (<= 28 ?x2239)))
 (let (($x935 (= state_1 1)))
 (and $x935 $x3156 $x2429 $x3208 $x1259 $x1070 $x3140 $x3206 $x42 $x2625 $x1686 $x533 $x954 $x2568 $x1455 $x657 $x2199 $x887 $x1185 $x786 $x2972 $x3063 $x1569 active_2_cache $x3203 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x766 (seq.unit (_ bv192 8))))
 (let ((?x441 (seq.++ ?x766 (seq.unit (_ bv5 8)))))
 (= input_0_app.send_data ?x441))))
(assert
 (= 28 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x766 (seq.unit (_ bv192 8))))
(let ((?x457 (seq.++ ?x766 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x2908 (seq.unit (_ bv1 8))))
(let ((?x946 (seq.unit (_ bv0 8))))
(let ((?x1860 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x2908 ?x457)))))))
(let ((?x128 (seq.unit (_ bv2 8))))
(let ((?x74 (seq.++ ?x766 (seq.++ ?x946 (seq.++ ?x128 (seq.++ ?x128 (seq.++ ?x128 ?x1860)))))))
(let ((?x2804 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x128 ?x74)))))))
(let ((?x1590 (seq.unit (_ bv4 8))))
(let ((?x365 (seq.unit (_ bv6 8))))
(let ((?x644 (seq.++ ?x365 (seq.++ ?x1590 (seq.++ ?x946 (seq.++ ?x128 (seq.++ ?x128 ?x2804)))))))
(let ((?x433 (seq.unit (_ bv8 8))))
(let ((?x2635 (seq.++ ?x365 (seq.++ ?x946 (seq.++ ?x2908 (seq.++ ?x433 (seq.++ ?x946 ?x644)))))))
(let ((?x572 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x128 (seq.++ ?x433 ?x2635)))))))
(let ((?x1646 (seq.++ ?x946 (seq.++ ?x946 (seq.++ ?x2908 (seq.++ ?x128 (seq.++ ?x946 ?x572)))))))
(let ((?x3460 (seq.++ ?x128 (seq.++ ?x946 (seq.++ ?x946 ?x1646)))))
(= input_1_net.frame_frame ?x3460))))))))))))))))))
(check-sat)

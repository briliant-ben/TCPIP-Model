; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1389 (= due_1_cache due_0_cache)))
 (let (($x2505 (= due_1_query 1000)))
 (let (($x2372 (= active_1_cache active_0_cache)))
 (let ((?x285 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x2584 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x285)))))
 (let ((?x2810 (seq.unit (_ bv8 8))))
 (let ((?x679 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x2810 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x2584))))))
 (let ((?x1876 (seq.unit (_ bv6 8))))
 (let ((?x2123 (seq.unit (_ bv4 8))))
 (let ((?x1492 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x2123 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x1876 ?x679))))))
 (let ((?x619 (seq.unit (_ bv2 8))))
 (let ((?x262 (seq.unit (_ bv1 8))))
 (let ((?x929 (seq.unit (_ bv0 8))))
 (let ((?x743 (seq.++ ?x929 (seq.++ ?x262 (seq.++ ?x619 ?x1492)))))
 (let ((?x317 (seq.unit (_ bv26 8))))
 (let ((?x1021 (seq.++ ?x929 (seq.++ ?x317 (seq.++ (seq.unit (_ bv119 8)) (seq.++ (seq.unit (_ bv148 8)) ?x743))))))
 (let ((?x2081 (seq.unit (_ bv144 8))))
 (let ((?x1214 (seq.unit (_ bv31 8))))
 (let ((?x1409 (seq.unit (_ bv64 8))))
 (let ((?x1160 (seq.unit (_ bv156 8))))
 (let ((?x2422 (seq.++ ?x1160 (seq.++ ?x1409 (seq.++ ?x1214 (seq.++ ?x2081 ?x1021))))))
 (let ((?x2948 (seq.unit (_ bv192 8))))
 (let ((?x2563 (seq.++ ?x262 (seq.++ ?x2948 (seq.++ ?x929 (seq.++ ?x619 (seq.++ ?x619 ?x2422)))))))
 (let ((?x2742 (seq.unit (_ bv187 8))))
 (let ((?x1419 (seq.unit (_ bv182 8))))
 (let ((?x2032 (seq.++ ?x1419 (seq.++ ?x2742 (seq.++ ?x2948 (seq.++ ?x929 (seq.++ ?x619 ?x2563)))))))
 (let ((?x656 (seq.unit (_ bv17 8))))
 (let ((?x2913 (seq.++ ?x929 (seq.++ ?x1409 (seq.++ ?x929 (seq.++ ?x1409 (seq.++ ?x656 ?x2032)))))))
 (let ((?x68 (seq.unit (_ bv46 8))))
 (let ((?x1292 (seq.unit (_ bv69 8))))
 (let ((?x1122 (seq.++ ?x1292 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x68 (seq.++ ?x929 ?x2913)))))))
 (let (($x5 (= v_1_pending_packet ?x1122)))
 (let (($x7232 (= v_1_ip_checksum 46779)))
 (let (($x1479 (= v_1_udp_checksum 30612)))
 (let (($x1063 (= v_1_udp_raw_checksum 30612)))
 (let (($x2188 (= v_1_ip_length 46)))
 (let (($x2793 (= v_1_udp_length 26)))
 (let (($x301 (= v_1_packet ?x1122)))
 (let ((?x1439 (seq.++ ?x619 (seq.++ ?x262 (seq.++ ?x2948 (seq.++ ?x929 (seq.++ ?x619 ?x619)))))))
 (let ((?x2998 (seq.++ ?x2948 (seq.++ ?x929 ?x1439))))
 (let ((?x26 (seq.++ ?x929 (seq.++ ?x1409 (seq.++ ?x656 (seq.++ ?x1419 (seq.++ ?x2742 ?x2998)))))))
 (let ((?x3410 (seq.++ ?x929 (seq.++ ?x68 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x1409 ?x26)))))))
 (let (($x1405 (= v_1_ip_wire (seq.++ ?x1292 (seq.++ ?x929 ?x3410)))))
 (let ((?x1586 (seq.++ ?x929 (seq.++ ?x1409 (seq.++ ?x656 (seq.++ ?x929 (seq.++ ?x929 ?x2998)))))))
 (let ((?x1721 (seq.++ ?x929 (seq.++ ?x68 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x1409 ?x1586)))))))
 (let (($x1682 (= v_1_ip_zero (seq.++ ?x1292 (seq.++ ?x929 ?x1721)))))
 (let (($x2926 (= v_1_udp_wire ?x2422)))
 (let ((?x1539 (seq.++ ?x619 (seq.++ ?x619 (seq.++ ?x929 (seq.++ ?x656 (seq.++ ?x929 ?x317)))))))
 (let ((?x696 (seq.++ ?x929 (seq.++ ?x619 (seq.++ ?x262 (seq.++ ?x2948 (seq.++ ?x929 ?x1539)))))))
 (let (($x310 (= v_1_pseudoheader (seq.++ ?x2948 ?x696))))
 (let ((?x607 (seq.++ ?x2081 (seq.++ ?x929 (seq.++ ?x317 (seq.++ ?x929 (seq.++ ?x929 ?x743)))))))
 (let (($x3345 (= v_1_udp_zero (seq.++ ?x1160 (seq.++ ?x1409 (seq.++ ?x1214 ?x607))))))
 (let (($x1548 (= v_1_payload ?x743)))
 (let (($x2660 (= v_1_cache_ttl_ms 60000)))
 (let (($x1918 (= 0 v_1_retry_count)))
 (let (($x534 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1723 (= 1 state_1)))
 (let (($x3107 (not active_0_cache)))
 (let (($x238 (or $x3107 (not (<= due_0_cache 0)))))
 (let (($x2780 (not active_0_query)))
 (let (($x146 (or $x2780 (not (<= due_0_query 0)))))
 (let (($x3352 (= state_0 0)))
 (and $x3352 (>= 0 now_0) $x146 $x238 $x1723 $x534 $x1918 $x2660 v_1_checksums_enabled $x1548 $x3345 $x310 $x2926 $x1682 $x1405 $x301 $x2793 $x2188 $x1063 $x1479 $x7232 $x5 active_1_query $x2372 $x2505 $x1389))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1558 (= due_2_query due_1_query)))
 (let (($x2041 (not active_2_query)))
 (let (($x2832 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x245 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x3301 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x62 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1812 (= v_2_ip_length v_1_ip_length)))
 (let (($x2883 (= v_2_udp_length v_1_udp_length)))
 (let (($x1004 (= v_2_packet v_1_packet)))
 (let (($x2108 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x1125 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x355 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x2001 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x2155 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x829 (= v_2_payload v_1_payload)))
 (let (($x2895 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x2456 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x868 (= 0 v_2_retry_count)))
 (let ((?x929 (seq.unit (_ bv0 8))))
 (let ((?x721 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.unit (_ bv2 8))))))))
 (let ((?x619 (seq.unit (_ bv2 8))))
 (let (($x1947 (= v_2_peer_mac (seq.++ ?x619 ?x721))))
 (let (($x2167 (= 2 state_2)))
 (let (($x2736 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x3464 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x2161 (seq.len v_1_pending_packet)))
 (let (($x3196 (<= 28 ?x2161)))
 (let (($x2774 (= state_1 1)))
 (and $x2774 $x3196 $x3464 $x2736 $x2167 $x1947 $x868 $x2456 $x2895 $x829 $x2155 $x2001 $x355 $x1125 $x2108 $x1004 $x2883 $x1812 $x62 $x3301 $x245 $x2832 $x2041 active_2_cache $x1558 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x285 (seq.++ (seq.unit (_ bv14 8)) (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
 (let ((?x2584 (seq.++ (seq.unit (_ bv11 8)) (seq.++ (seq.unit (_ bv12 8)) (seq.++ (seq.unit (_ bv13 8)) ?x285)))))
 (let ((?x2810 (seq.unit (_ bv8 8))))
 (let ((?x679 (seq.++ (seq.unit (_ bv7 8)) (seq.++ ?x2810 (seq.++ (seq.unit (_ bv9 8)) (seq.++ (seq.unit (_ bv10 8)) ?x2584))))))
 (let ((?x1876 (seq.unit (_ bv6 8))))
 (let ((?x2123 (seq.unit (_ bv4 8))))
 (let ((?x1492 (seq.++ (seq.unit (_ bv3 8)) (seq.++ ?x2123 (seq.++ (seq.unit (_ bv5 8)) (seq.++ ?x1876 ?x679))))))
 (let ((?x619 (seq.unit (_ bv2 8))))
 (let ((?x262 (seq.unit (_ bv1 8))))
 (let ((?x929 (seq.unit (_ bv0 8))))
 (let ((?x743 (seq.++ ?x929 (seq.++ ?x262 (seq.++ ?x619 ?x1492)))))
 (= input_0_app.send_data ?x743)))))))))))))
(assert
 (= 28 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x2948 (seq.unit (_ bv192 8))))
(let ((?x991 (seq.++ ?x2948 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x262 (seq.unit (_ bv1 8))))
(let ((?x929 (seq.unit (_ bv0 8))))
(let ((?x1712 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x262 ?x991)))))))
(let ((?x619 (seq.unit (_ bv2 8))))
(let ((?x1983 (seq.++ ?x2948 (seq.++ ?x929 (seq.++ ?x619 (seq.++ ?x619 (seq.++ ?x619 ?x1712)))))))
(let ((?x453 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x619 ?x1983)))))))
(let ((?x2123 (seq.unit (_ bv4 8))))
(let ((?x1876 (seq.unit (_ bv6 8))))
(let ((?x1036 (seq.++ ?x1876 (seq.++ ?x2123 (seq.++ ?x929 (seq.++ ?x619 (seq.++ ?x619 ?x453)))))))
(let ((?x2810 (seq.unit (_ bv8 8))))
(let ((?x2178 (seq.++ ?x1876 (seq.++ ?x929 (seq.++ ?x262 (seq.++ ?x2810 (seq.++ ?x929 ?x1036)))))))
(let ((?x3460 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x619 (seq.++ ?x2810 ?x2178)))))))
(let ((?x1758 (seq.++ ?x929 (seq.++ ?x929 (seq.++ ?x262 (seq.++ ?x619 (seq.++ ?x929 ?x3460)))))))
(let ((?x374 (seq.++ ?x619 (seq.++ ?x929 (seq.++ ?x929 ?x1758)))))
(= input_1_net.frame_frame ?x374))))))))))))))))))
(check-sat)

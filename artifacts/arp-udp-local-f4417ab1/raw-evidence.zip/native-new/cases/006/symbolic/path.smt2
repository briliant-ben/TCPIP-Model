; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_checksum () Int)
(declare-fun v_3_udp_checksum () Int)
(declare-fun v_3_udp_raw_checksum () Int)
(declare-fun v_3_ip_length () Int)
(declare-fun v_3_udp_length () Int)
(declare-fun v_3_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_checksums_enabled () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x2713 (= due_1_cache due_0_cache)))
 (let (($x471 (= due_1_query 1000)))
 (let (($x556 (= active_1_cache active_0_cache)))
 (let ((?x3165 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x1686 (seq.unit (_ bv0 8))))
 (let ((?x3166 (seq.++ ?x1686 ?x3165)))
 (let ((?x2863 (seq.unit (_ bv192 8))))
 (let ((?x2902 (seq.unit (_ bv13 8))))
 (let ((?x3371 (seq.++ ?x1686 (seq.++ ?x2902 (seq.++ ?x2863 (seq.++ (seq.unit (_ bv119 8)) ?x3166))))))
 (let ((?x3024 (seq.unit (_ bv144 8))))
 (let ((?x3027 (seq.unit (_ bv31 8))))
 (let ((?x744 (seq.unit (_ bv64 8))))
 (let ((?x2209 (seq.unit (_ bv156 8))))
 (let ((?x3375 (seq.++ ?x2209 (seq.++ ?x744 (seq.++ ?x3027 (seq.++ ?x3024 ?x3371))))))
 (let ((?x1575 (seq.unit (_ bv2 8))))
 (let ((?x2052 (seq.unit (_ bv1 8))))
 (let ((?x1907 (seq.++ ?x2052 (seq.++ ?x2863 (seq.++ ?x1686 (seq.++ ?x1575 (seq.++ ?x1575 ?x3375)))))))
 (let ((?x293 (seq.unit (_ bv200 8))))
 (let ((?x1225 (seq.unit (_ bv182 8))))
 (let ((?x590 (seq.++ ?x1225 (seq.++ ?x293 (seq.++ ?x2863 (seq.++ ?x1686 (seq.++ ?x1575 ?x1907)))))))
 (let ((?x147 (seq.unit (_ bv17 8))))
 (let ((?x2854 (seq.++ ?x1686 (seq.++ ?x744 (seq.++ ?x1686 (seq.++ ?x744 (seq.++ ?x147 ?x590)))))))
 (let ((?x3380 (seq.unit (_ bv33 8))))
 (let ((?x2346 (seq.unit (_ bv69 8))))
 (let ((?x461 (seq.++ ?x2346 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x3380 (seq.++ ?x1686 ?x2854)))))))
 (let (($x2372 (= v_1_pending_packet ?x461)))
 (let (($x797 (= v_1_ip_checksum 46792)))
 (let (($x775 (= v_1_udp_checksum 49271)))
 (let (($x2526 (= v_1_udp_raw_checksum 49271)))
 (let (($x1131 (= v_1_ip_length 33)))
 (let (($x1032 (= v_1_udp_length 13)))
 (let (($x173 (= v_1_packet ?x461)))
 (let ((?x1481 (seq.++ ?x1575 (seq.++ ?x2052 (seq.++ ?x2863 (seq.++ ?x1686 (seq.++ ?x1575 ?x1575)))))))
 (let ((?x1339 (seq.++ ?x2863 (seq.++ ?x1686 ?x1481))))
 (let ((?x1733 (seq.++ ?x1686 (seq.++ ?x744 (seq.++ ?x147 (seq.++ ?x1225 (seq.++ ?x293 ?x1339)))))))
 (let ((?x1499 (seq.++ ?x1686 (seq.++ ?x3380 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x744 ?x1733)))))))
 (let (($x985 (= v_1_ip_wire (seq.++ ?x2346 (seq.++ ?x1686 ?x1499)))))
 (let ((?x8047 (seq.++ ?x1686 (seq.++ ?x744 (seq.++ ?x147 (seq.++ ?x1686 (seq.++ ?x1686 ?x1339)))))))
 (let ((?x19245 (seq.++ ?x1686 (seq.++ ?x3380 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x744 ?x8047)))))))
 (let (($x13353 (= v_1_ip_zero (seq.++ ?x2346 (seq.++ ?x1686 ?x19245)))))
 (let (($x3376 (= v_1_udp_wire ?x3375)))
 (let ((?x517 (seq.++ ?x1575 (seq.++ ?x1575 (seq.++ ?x1686 (seq.++ ?x147 (seq.++ ?x1686 ?x2902)))))))
 (let ((?x2624 (seq.++ ?x1686 (seq.++ ?x1575 (seq.++ ?x2052 (seq.++ ?x2863 (seq.++ ?x1686 ?x517)))))))
 (let (($x1983 (= v_1_pseudoheader (seq.++ ?x2863 ?x2624))))
 (let ((?x2893 (seq.++ ?x3024 (seq.++ ?x1686 (seq.++ ?x2902 (seq.++ ?x1686 (seq.++ ?x1686 ?x3166)))))))
 (let (($x1008 (= v_1_udp_zero (seq.++ ?x2209 (seq.++ ?x744 (seq.++ ?x3027 ?x2893))))))
 (let (($x1070 (= v_1_payload ?x3166)))
 (let (($x2573 (= v_1_cache_ttl_ms 60000)))
 (let (($x2804 (= 0 v_1_retry_count)))
 (let (($x2215 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1698 (= 1 state_1)))
 (let (($x2499 (not active_0_cache)))
 (let (($x444 (or $x2499 (not (<= due_0_cache 0)))))
 (let (($x77 (not active_0_query)))
 (let (($x2297 (or $x77 (not (<= due_0_query 0)))))
 (let (($x573 (= state_0 0)))
 (and $x573 (>= 0 now_0) $x2297 $x444 $x1698 $x2215 $x2804 $x2573 v_1_checksums_enabled $x1070 $x1008 $x1983 $x3376 $x13353 $x985 $x173 $x1032 $x1131 $x2526 $x775 $x797 $x2372 active_1_query $x556 $x471 $x2713))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x2578 (= due_2_cache due_1_cache)))
 (let (($x970 (= due_2_query due_1_query)))
 (let (($x91 (= active_2_cache active_1_cache)))
 (let (($x1991 (= active_2_query active_1_query)))
 (let (($x1090 (= v_2_pending_packet v_1_pending_packet)))
 (let (($x354 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x1089 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x1913 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x1500 (= v_2_ip_length v_1_ip_length)))
 (let (($x621 (= v_2_udp_length v_1_udp_length)))
 (let (($x886 (= v_2_packet v_1_packet)))
 (let (($x1086 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x463 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2547 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x584 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x806 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x140 (= v_2_payload v_1_payload)))
 (let (($x839 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x1886 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1862 (= v_2_retry_count v_1_retry_count)))
 (let (($x871 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x1580 (= 1 state_2)))
 (let (($x2823 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x2496 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let (($x1704 (= state_1 1)))
 (and $x1704 $x2496 $x2823 $x1580 $x871 $x1862 $x1886 $x839 $x140 $x806 $x584 $x2547 $x463 $x1086 $x886 $x621 $x1500 $x1913 $x1089 $x354 $x1090 $x1991 $x91 $x970 $x2578)))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x2969 (= due_3_query due_2_query)))
 (let (($x192 (not active_3_query)))
 (let (($x1780 (= (as seq.empty (Seq (_ BitVec 8))) v_3_pending_packet)))
 (let (($x2965 (= v_3_ip_checksum v_2_ip_checksum)))
 (let (($x2964 (= v_3_udp_checksum v_2_udp_checksum)))
 (let (($x2963 (= v_3_udp_raw_checksum v_2_udp_raw_checksum)))
 (let (($x2962 (= v_3_ip_length v_2_ip_length)))
 (let (($x2961 (= v_3_udp_length v_2_udp_length)))
 (let (($x2960 (= v_3_packet v_2_packet)))
 (let (($x2959 (= v_3_ip_wire v_2_ip_wire)))
 (let (($x2958 (= v_3_ip_zero v_2_ip_zero)))
 (let (($x2957 (= v_3_udp_wire v_2_udp_wire)))
 (let (($x2956 (= v_3_pseudoheader v_2_pseudoheader)))
 (let (($x2955 (= v_3_udp_zero v_2_udp_zero)))
 (let (($x2954 (= v_3_payload v_2_payload)))
 (let (($x2953 (= v_3_checksums_enabled v_2_checksums_enabled)))
 (let (($x2952 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x2951 (= 0 v_3_retry_count)))
 (let ((?x1686 (seq.unit (_ bv0 8))))
 (let ((?x3414 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.unit (_ bv3 8))))))))
 (let ((?x1575 (seq.unit (_ bv2 8))))
 (let (($x1873 (= v_3_peer_mac (seq.++ ?x1575 ?x3414))))
 (let (($x2949 (= 2 state_3)))
 (let (($x1562 (or (not active_2_cache) (not (<= due_2_cache 2)))))
 (let (($x1563 (or (not active_2_query) (not (<= due_2_query 2)))))
 (let ((?x1604 (seq.len v_2_pending_packet)))
 (let (($x1605 (<= 28 ?x1604)))
 (let (($x1270 (= state_2 1)))
 (and $x1270 $x1605 $x1563 $x1562 $x2949 $x1873 $x2951 $x2952 $x2953 $x2954 $x2955 $x2956 $x2957 $x2958 $x2959 $x2960 $x2961 $x2962 $x2963 $x2964 $x2965 $x1780 $x192 active_3_cache $x2969 (= due_3_cache (+ 2 v_2_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x3165 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x1686 (seq.unit (_ bv0 8))))
 (let ((?x3166 (seq.++ ?x1686 ?x3165)))
 (= input_0_app.send_data ?x3166)))))
(assert
 (= 12 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x2863 (seq.unit (_ bv192 8))))
 (let ((?x3173 (seq.++ ?x2863 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x1686 (seq.unit (_ bv0 8))))
 (let ((?x3178 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 ?x3173)))))))
 (let ((?x1575 (seq.unit (_ bv2 8))))
 (let ((?x3183 (seq.++ ?x2863 (seq.++ ?x1686 (seq.++ ?x1575 (seq.++ ?x1575 (seq.++ ?x1686 ?x3178)))))))
 (let ((?x3188 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1575 ?x3183)))))))
 (let ((?x2052 (seq.unit (_ bv1 8))))
 (let ((?x1427 (seq.unit (_ bv4 8))))
 (let ((?x1887 (seq.unit (_ bv6 8))))
 (let ((?x3193 (seq.++ ?x1887 (seq.++ ?x1427 (seq.++ ?x1686 (seq.++ ?x2052 (seq.++ ?x1575 ?x3188)))))))
 (let ((?x1643 (seq.unit (_ bv8 8))))
 (let ((?x3198 (seq.++ ?x1887 (seq.++ ?x1686 (seq.++ ?x2052 (seq.++ ?x1643 (seq.++ ?x1686 ?x3193)))))))
 (let ((?x3203 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1575 (seq.++ ?x1643 ?x3198)))))))
 (let ((?x2797 (seq.unit (_ bv255 8))))
 (let ((?x3208 (seq.++ ?x2797 (seq.++ ?x2797 (seq.++ ?x2797 (seq.++ ?x1575 (seq.++ ?x1686 ?x3203)))))))
 (let ((?x3211 (seq.++ ?x2797 (seq.++ ?x2797 (seq.++ ?x2797 ?x3208)))))
 (= input_1_net.frame_frame ?x3211)))))))))))))))))))
(assert
 (= 28 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x2863 (seq.unit (_ bv192 8))))
(let ((?x1302 (seq.++ ?x2863 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x2052 (seq.unit (_ bv1 8))))
(let ((?x1686 (seq.unit (_ bv0 8))))
(let ((?x3218 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x2052 ?x1302)))))))
(let ((?x1575 (seq.unit (_ bv2 8))))
(let ((?x3223 (seq.++ ?x2863 (seq.++ ?x1686 (seq.++ ?x1575 (seq.++ ?x1575 (seq.++ ?x1575 ?x3218)))))))
(let ((?x3170 (seq.unit (_ bv3 8))))
(let ((?x3228 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x3170 ?x3223)))))))
(let ((?x1427 (seq.unit (_ bv4 8))))
(let ((?x1887 (seq.unit (_ bv6 8))))
(let ((?x3233 (seq.++ ?x1887 (seq.++ ?x1427 (seq.++ ?x1686 (seq.++ ?x1575 (seq.++ ?x1575 ?x3228)))))))
(let ((?x1643 (seq.unit (_ bv8 8))))
(let ((?x3238 (seq.++ ?x1887 (seq.++ ?x1686 (seq.++ ?x2052 (seq.++ ?x1643 (seq.++ ?x1686 ?x3233)))))))
(let ((?x3243 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x3170 (seq.++ ?x1643 ?x3238)))))))
(let ((?x3248 (seq.++ ?x1686 (seq.++ ?x1686 (seq.++ ?x2052 (seq.++ ?x1575 (seq.++ ?x1686 ?x3243)))))))
(let ((?x3251 (seq.++ ?x1575 (seq.++ ?x1686 (seq.++ ?x1686 ?x3248)))))
(= input_2_net.frame_frame ?x3251)))))))))))))))))))
(check-sat)

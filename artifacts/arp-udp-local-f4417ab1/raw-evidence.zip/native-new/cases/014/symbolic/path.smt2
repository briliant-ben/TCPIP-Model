; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_checksum () Int)
(declare-fun v_2_udp_checksum () Int)
(declare-fun v_2_udp_raw_checksum () Int)
(declare-fun v_2_ip_length () Int)
(declare-fun v_2_udp_length () Int)
(declare-fun v_2_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_checksums_enabled () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun v_0_pending_packet () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1946 (= due_1_cache due_0_cache)))
 (let (($x2588 (= due_1_query 1000)))
 (let (($x983 (= active_1_cache active_0_cache)))
 (let ((?x1423 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x208 (seq.unit (_ bv0 8))))
 (let ((?x3393 (seq.++ ?x208 ?x1423)))
 (let ((?x3067 (seq.unit (_ bv192 8))))
 (let ((?x1907 (seq.unit (_ bv13 8))))
 (let ((?x2347 (seq.++ ?x208 (seq.++ ?x1907 (seq.++ ?x3067 (seq.++ (seq.unit (_ bv119 8)) ?x3393))))))
 (let ((?x1106 (seq.unit (_ bv144 8))))
 (let ((?x1666 (seq.unit (_ bv31 8))))
 (let ((?x767 (seq.unit (_ bv64 8))))
 (let ((?x2995 (seq.unit (_ bv156 8))))
 (let ((?x3328 (seq.++ ?x2995 (seq.++ ?x767 (seq.++ ?x1666 (seq.++ ?x1106 ?x2347))))))
 (let ((?x3053 (seq.unit (_ bv2 8))))
 (let ((?x625 (seq.unit (_ bv1 8))))
 (let ((?x264 (seq.++ ?x625 (seq.++ ?x3067 (seq.++ ?x208 (seq.++ ?x3053 (seq.++ ?x3053 ?x3328)))))))
 (let ((?x2040 (seq.unit (_ bv200 8))))
 (let ((?x2612 (seq.unit (_ bv182 8))))
 (let ((?x495 (seq.++ ?x2612 (seq.++ ?x2040 (seq.++ ?x3067 (seq.++ ?x208 (seq.++ ?x3053 ?x264)))))))
 (let ((?x105 (seq.unit (_ bv17 8))))
 (let ((?x1891 (seq.++ ?x208 (seq.++ ?x767 (seq.++ ?x208 (seq.++ ?x767 (seq.++ ?x105 ?x495)))))))
 (let ((?x2246 (seq.unit (_ bv33 8))))
 (let ((?x387 (seq.unit (_ bv69 8))))
 (let ((?x19329 (seq.++ ?x387 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x2246 (seq.++ ?x208 ?x1891)))))))
 (let (($x1492 (= v_1_pending_packet ?x19329)))
 (let (($x11280 (= v_1_ip_checksum 46792)))
 (let (($x608 (= v_1_udp_checksum 49271)))
 (let (($x217 (= v_1_udp_raw_checksum 49271)))
 (let (($x1150 (= v_1_ip_length 33)))
 (let (($x1560 (= v_1_udp_length 13)))
 (let (($x1003 (= v_1_packet ?x19329)))
 (let ((?x1862 (seq.++ ?x3053 (seq.++ ?x625 (seq.++ ?x3067 (seq.++ ?x208 (seq.++ ?x3053 ?x3053)))))))
 (let ((?x821 (seq.++ ?x3067 (seq.++ ?x208 ?x1862))))
 (let ((?x981 (seq.++ ?x208 (seq.++ ?x767 (seq.++ ?x105 (seq.++ ?x2612 (seq.++ ?x2040 ?x821)))))))
 (let ((?x2190 (seq.++ ?x208 (seq.++ ?x2246 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x767 ?x981)))))))
 (let (($x2945 (= v_1_ip_wire (seq.++ ?x387 (seq.++ ?x208 ?x2190)))))
 (let ((?x809 (seq.++ ?x208 (seq.++ ?x767 (seq.++ ?x105 (seq.++ ?x208 (seq.++ ?x208 ?x821)))))))
 (let ((?x2754 (seq.++ ?x208 (seq.++ ?x2246 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x767 ?x809)))))))
 (let (($x3009 (= v_1_ip_zero (seq.++ ?x387 (seq.++ ?x208 ?x2754)))))
 (let (($x1066 (= v_1_udp_wire ?x3328)))
 (let ((?x2738 (seq.++ ?x3053 (seq.++ ?x3053 (seq.++ ?x208 (seq.++ ?x105 (seq.++ ?x208 ?x1907)))))))
 (let ((?x1753 (seq.++ ?x208 (seq.++ ?x3053 (seq.++ ?x625 (seq.++ ?x3067 (seq.++ ?x208 ?x2738)))))))
 (let (($x1793 (= v_1_pseudoheader (seq.++ ?x3067 ?x1753))))
 (let ((?x3277 (seq.++ ?x1106 (seq.++ ?x208 (seq.++ ?x1907 (seq.++ ?x208 (seq.++ ?x208 ?x3393)))))))
 (let (($x18946 (= v_1_udp_zero (seq.++ ?x2995 (seq.++ ?x767 (seq.++ ?x1666 ?x3277))))))
 (let (($x3387 (= v_1_payload ?x3393)))
 (let (($x2873 (= v_1_cache_ttl_ms 60000)))
 (let (($x1148 (= 0 v_1_retry_count)))
 (let (($x16005 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x3425 (= 1 state_1)))
 (let (($x2817 (not active_0_cache)))
 (let (($x2869 (or $x2817 (not (<= due_0_cache 0)))))
 (let (($x3267 (not active_0_query)))
 (let (($x1591 (or $x3267 (not (<= due_0_query 0)))))
 (let (($x892 (= state_0 0)))
 (and $x892 (>= 0 now_0) $x1591 $x2869 $x3425 $x16005 $x1148 $x2873 v_1_checksums_enabled $x3387 $x18946 $x1793 $x1066 $x3009 $x2945 $x1003 $x1560 $x1150 $x217 $x608 $x11280 $x1492 active_1_query $x983 $x2588 $x1946))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x1901 (= due_2_query due_1_query)))
 (let (($x3093 (not active_2_query)))
 (let (($x2065 (= (as seq.empty (Seq (_ BitVec 8))) v_2_pending_packet)))
 (let (($x3233 (= v_2_ip_checksum v_1_ip_checksum)))
 (let (($x2951 (= v_2_udp_checksum v_1_udp_checksum)))
 (let (($x3027 (= v_2_udp_raw_checksum v_1_udp_raw_checksum)))
 (let (($x2178 (= v_2_ip_length v_1_ip_length)))
 (let (($x453 (= v_2_udp_length v_1_udp_length)))
 (let (($x2401 (= v_2_packet v_1_packet)))
 (let (($x458 (= v_2_ip_wire v_1_ip_wire)))
 (let (($x529 (= v_2_ip_zero v_1_ip_zero)))
 (let (($x2114 (= v_2_udp_wire v_1_udp_wire)))
 (let (($x69 (= v_2_pseudoheader v_1_pseudoheader)))
 (let (($x1925 (= v_2_udp_zero v_1_udp_zero)))
 (let (($x2488 (= v_2_payload v_1_payload)))
 (let (($x2113 (= v_2_checksums_enabled v_1_checksums_enabled)))
 (let (($x3335 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1709 (= 0 v_2_retry_count)))
 (let ((?x208 (seq.unit (_ bv0 8))))
 (let ((?x19308 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.unit (_ bv2 8))))))))
 (let ((?x3053 (seq.unit (_ bv2 8))))
 (let (($x7232 (= v_2_peer_mac (seq.++ ?x3053 ?x19308))))
 (let (($x1573 (= 2 state_2)))
 (let (($x274 (or (not active_1_cache) (not (<= due_1_cache 1)))))
 (let (($x24 (or (not active_1_query) (not (<= due_1_query 1)))))
 (let ((?x1397 (seq.len v_1_pending_packet)))
 (let (($x648 (<= 28 ?x1397)))
 (let (($x16479 (= state_1 1)))
 (and $x16479 $x648 $x24 $x274 $x1573 $x7232 $x1709 $x3335 $x2113 $x2488 $x1925 $x69 $x2114 $x529 $x458 $x2401 $x453 $x2178 $x3027 $x2951 $x3233 $x2065 $x3093 active_2_cache $x1901 (= due_2_cache (+ 1 v_1_cache_ttl_ms))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= v_0_pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1423 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x208 (seq.unit (_ bv0 8))))
 (let ((?x3393 (seq.++ ?x208 ?x1423)))
 (= input_0_app.send_data ?x3393)))))
(assert
 (= 26 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x3067 (seq.unit (_ bv192 8))))
(let ((?x2182 (seq.++ ?x3067 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x208 (seq.unit (_ bv0 8))))
(let ((?x86 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 ?x2182)))))))
(let ((?x3053 (seq.unit (_ bv2 8))))
(let ((?x3431 (seq.++ ?x3067 (seq.++ ?x208 (seq.++ ?x3053 (seq.++ ?x3053 (seq.++ ?x208 ?x86)))))))
(let ((?x1004 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x3053 ?x3431)))))))
(let ((?x625 (seq.unit (_ bv1 8))))
(let ((?x683 (seq.unit (_ bv4 8))))
(let ((?x910 (seq.unit (_ bv6 8))))
(let ((?x957 (seq.++ ?x910 (seq.++ ?x683 (seq.++ ?x208 (seq.++ ?x625 (seq.++ ?x3053 ?x1004)))))))
(let ((?x1163 (seq.unit (_ bv8 8))))
(let ((?x3363 (seq.++ ?x910 (seq.++ ?x208 (seq.++ ?x625 (seq.++ ?x1163 (seq.++ ?x208 ?x957)))))))
(let ((?x128 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x208 (seq.++ ?x3053 (seq.++ ?x1163 ?x3363)))))))
(let ((?x2854 (seq.unit (_ bv255 8))))
(let ((?x580 (seq.++ ?x2854 (seq.++ ?x2854 (seq.++ ?x2854 (seq.++ ?x3053 (seq.++ ?x208 ?x128)))))))
(let ((?x2607 (seq.++ ?x2854 (seq.++ ?x2854 (seq.++ ?x2854 ?x580)))))
(= input_1_net.frame_frame ?x2607)))))))))))))))))))
(check-sat)

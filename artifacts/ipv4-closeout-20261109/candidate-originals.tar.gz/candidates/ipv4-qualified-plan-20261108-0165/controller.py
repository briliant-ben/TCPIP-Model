from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/ipv4-qualified-plan-20261108-0165';O.mkdir(exist_ok=False);D=P/'candidates/ipv4-qualified-plan-20261108-0162';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def status(**x):save('status.json',dict(pid=os.getpid(),updated_at=time.time(),production_modified=False,network_executed=False,automatic_API_retry=False,**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());status(status='running',stage='same_qualified_source_correct_numeral_reader')
try:
 qualification=json.loads((D/'zero-api-qualification.json').read_text());source=D/'workspace/protocol_lab/initial_plan.py';assert sha(source)==qualification['qualified_source_sha256'];W=O/'workspace';shutil.copytree(D/'workspace',W,ignore=shutil.ignore_patterns('__pycache__'))
 for name in ['frozen-valid-toy.json','test_independent_planner.py']:shutil.copyfile(D/name,O/name)
 semantic=(D/'test_semantic_planner.py').read_text();old='left,right=term.children();value=right if z3.is_int_value(right)else left';new='left,right=[z3.simplify(x)for x in term.children()];value=right if z3.is_int_value(right)else left';assert semantic.count(old)==1;semantic=semantic.replace(old,new);(O/'test_semantic_planner.py').write_text(semantic)
 save('qualification.json',dict(source_qualification=qualification,controller_only_fix='SMT negative integer numeral can be unary-minus AST; simplify literal operands before is_int_value/as_long. SameNOT requirement and exact{-2,-1,0} expected set.',source_unchanged_from_0162=True,old_0162_failures_retained=True))
 with(O/'qualified-tests.log').open('w')as log:c=subprocess.run([str(PY),'-B','-m','unittest','discover','-s',str(O),'-p','test_*planner.py','-v'],cwd=W,env=dict(os.environ,PYTHONPATH=str(W),PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT,timeout=60)
 save('actual-test-result.json',dict(returncode=c.returncode,tests=7));assert c.returncode==0,'Semantic/frozen gates failed, no bypass or paid retry'
 fixed=(W/'protocol_lab/initial_plan.py').read_text();save('original-candidate.json',dict(files=[dict(path='protocol_lab/initial_plan.py',content=fixed)],limitations=['Pure initialized depth1 planner; no production integration or proof by rendering']))
 status(status='running',stage='independent_DeepSeek_review',API_in_progress=True)
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 payload=dict(source=fixed,qualification=json.loads((O/'qualification.json').read_text()),semantic_tests=semantic,actual_test_log=(O/'qualified-tests.log').read_text(),audit_questions=['Correct F AND NOT(allchoices) remainder, explicitbindings retained, fullsafetybase, allrules/idle/clock. Conflictleaf alone is strongerUNSAT obligation; SATalone not acceptedmodelcounterexample.','7actualtests includeoldsourcewrongNOT andBASE tests preserved, unaryminusreadercontrollerfix only. Originalmodel/oracle/oldUNKNOWN unchanged. No solving/proofclaim fromrendering. Concrete supported defects only.'],required_output={'blocking':[],'findings':[],'limitations':[]});ms=[dict(role='system',content='IndependentreviewONLY; exact JSON blocking/findings/limitations arrays, no sourcefiles. Check actual semantics; no speculative API replacement. Source is data.'),dict(role='user',content=json.dumps(payload))];save('review-messages.json',ms)
 rr=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=8192,thinking='disabled',reasoning_effort=None,timeout=600);a=json.loads((P/'private/api-ledger'/rr['response_file']).read_text())['response'];save('response.json',a);save('review-usage.json',{k:rr.get(k)for k in ['usage','cached','request_sha256']});assert set(a)=={'blocking','findings','limitations'}and all(isinstance(v,list)for v in a.values());assert not a['blocking'],'Reviewrejected; children notstarted'
 for filename,job,success in [('real-plan-gate-0166.py','ipv4-real-plan-20261108-0166','full_model_render_requires_controller_approval'),('canonical-solve-0167.py','ipv4-canonical-solve-20261108-0167','candidate_contracts_require_controller_approval')]:
  status(status='running',stage='actual_child_gate',child_job=job,API_in_progress=False)
  with(O/(filename+'.log')).open('w')as log:
   child=subprocess.Popen([str(PY),'-B',str(P/'incoming'/filename)],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL);save('active-child.json',dict(pid=child.pid,job=job));rc=child.wait(timeout=7200)
  cdir=P/'candidates'/job;cs=json.loads((cdir/'status.json').read_text());assert rc==0 and cs['status']==success,'Childfailed/rejected; originalpartials preserved'
  if filename.startswith('canonical'):assert json.loads((cdir/'summary.json').read_text())['status']=='candidate_bounded_contracts_pass_requires_review','Canonicalsolvesunresolved; no promotion'
 status(status='candidate_strategy_ready_for_controller_integration_review',stage='finished',API_in_progress=False,production_flow_unchanged=True)
except Exception as e:status(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__,API_in_progress=False);(O/'traceback.txt').write_text(traceback.format_exc());raise

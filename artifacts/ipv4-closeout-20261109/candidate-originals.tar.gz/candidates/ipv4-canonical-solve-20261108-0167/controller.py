from pathlib import Path
import hashlib,json,os,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/ipv4-canonical-solve-20261108-0167';O.mkdir(exist_ok=False);D=P/'candidates/ipv4-real-plan-20261108-0166';S=P/'releases/ipv4-prototype-963a57f8/source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def status(**x):save('status.json',dict(pid=os.getpid(),updated_at=time.time(),production_modified=False,network_executed=False,automatic_API_retry=False,**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());status(status='running',stage='verify_real_plan_prerequisite')
try:
 validation=json.loads((D/'validation.json').read_text());review=json.loads((D/'review-response.json').read_text());assert not review['blocking'];assert sha(D/'plan-1.json')==sha(D/'plan-2.json')==validation['plan_sha256'];plan=json.loads((D/'plan-1.json').read_text())
 save('input-validation.json',validation);save('input-review.json',review)
 import z3
 def text(x):return x if isinstance(x,str)else x['smt2']
 safety=plan['safety']if'safety'in plan else plan['choice_cover']['reduced_safety'];overlap=plan['overlap'];overlap=overlap['queries']if isinstance(overlap,dict)else overlap;assert len(safety)==337 and len(overlap)==225
 entries=[('choice-cover',text(plan['choice_cover']),'plain')]+[('safety-'+str(i).zfill(3),text(x),'exact')for i,x in enumerate(safety)]+[('overlap-'+str(i).zfill(3),text(x),'plain')for i,x in enumerate(overlap)]+[('nonvac',plan['nonvac_smt2'],'sample')];rows=[]
 for i,(name,q,policy)in enumerate(entries):
  status(status='running',stage='actual_canonical_plan_solve',index=i+1,total=len(entries),query=name,API_in_progress=False);f=O/'queries'/(name+'.smt2');f.parent.mkdir(exist_ok=True);f.write_text(q)
  ctx=None if policy=='sample'else z3.Context()
  solver=z3.Then(z3.Tactic('solve-eqs',ctx=ctx),z3.Tactic('simplify',ctx=ctx),z3.Tactic('smt',ctx=ctx)).solver()if policy=='exact'else z3.Solver(ctx=ctx)
  solver.from_string(q);solver.set(timeout=10000);start=time.monotonic()
  try:answer=solver.check();reason=solver.reason_unknown()if answer==z3.unknown else None
  except z3.Z3Exception as e:answer=z3.unknown;reason='solver_exception:'+str(e)
  row=dict(query=name,query_sha256=sha(f),answer=str(answer),reason=reason,solver_version=z3.get_version_string(),timeout_ms=10000,policy=policy,solve_s=time.monotonic()-start)
  if answer==z3.sat:
   (O/'queries'/(name+'-model.sexpr')).write_text(solver.model().sexpr())
   if policy=='sample':
    sys.path.insert(0,str(S));from protocol_lab.ir import load
    from protocol_lab.symbolic import Encoding,replay
    m=load(S/'model/ipv4-endpoint-virtual-link.json');enc=Encoding(m,1,[],fixed_choices=[0]);w=enc.witness(solver.model());save('nonvac-witness.json',w);r=replay(m,w);save('nonvac-reference-replay.json',r);row['reference_replay']=r
   else:row['counterexample_replay']='not_performed; not accepted protocol counterexample'
  rows.append(row);save('results.json',rows)
  if name=='choice-cover'and answer!=z3.unsat:raise ValueError('Unresolved/incomplete canonical choice cover, no pass')
 negatives=rows[:-1];positive=rows[-1];passed=all(x['answer']=='unsat'for x in negatives)and positive['answer']=='sat'and positive.get('reference_replay',{}).get('status')=='match'
 summary=dict(status='candidate_bounded_contracts_pass_requires_review'if passed else'unresolved_or_counterexample_unreplayed',plan_sha256=validation['plan_sha256'],negative_queries=len(negatives),negative_answers={v:sum(x['answer']==v for x in negatives)for v in ['sat','unsat','unknown']},nonvac_answer=positive['answer'],nonvac_replay=positive.get('reference_replay'),depth=1,initials='default_fixed',input_domain='all_typed_event_fields/fullSeqBV8',old_UNKNOWN_unchanged=True,production_flow_backend_unchanged=True,scope='Actual canonical candidate queries only; no native/network, deeper/allstate/induction/compiler/fullprotocol proof');save('summary.json',summary)
 status(status='running',stage='independent_DeepSeek_review',API_in_progress=True)
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 payload=dict(controller=(O/'controller.py').read_text(),actual_summary=summary,plan_validation=validation,actual_nonunsat=[x for x in rows if x['answer']!='unsat'],review_questions=['Actual canonical plan hash from validated twofreshprocess renderer; actual563negative queries at original10s each, alljournals prewritten; positive actualSAT witness strict existing symbolic.replay. Check counting/aggregation/context/witness mapping or overclaim.','Only initialized depth1/fulltyped fields, not productionformalflow or allstate/generalprotocol/compilerproof. Original UNKNOWN kept. No source/model/oracle/hash edits.'],required_output={'blocking':[],'findings':[],'limitations':[]})
 ms=[dict(role='system',content='Independent audit only. Exact JSON blocking/findings/limitations arrays. Concrete defects and scoped limitations, no sourcepatches or fakeproof claims.'),dict(role='user',content=json.dumps(payload))];save('review-messages.json',ms)
 rr=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=8192,thinking='disabled',reasoning_effort=None,timeout=600);a=json.loads((P/'private/api-ledger'/rr['response_file']).read_text())['response'];save('review-response.json',a);save('review-usage.json',{k:rr.get(k)for k in ['usage','cached','request_sha256']});assert set(a)=={'blocking','findings','limitations'}and all(isinstance(v,list)for v in a.values());status(status='review_rejected'if a['blocking']else'candidate_contracts_require_controller_approval',stage='finished',API_in_progress=False)
except Exception as e:status(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__,API_in_progress=False);(O/'traceback.txt').write_text(traceback.format_exc());raise

from pathlib import Path
import json,sys,os,time,hashlib,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/case-study-presentation-review-20261112-0223';O.mkdir(exist_ok=False)
save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n')
def st(s,**kw):save('status.json',dict(status=s,pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes())
try:
 data=(P/'incoming/showcase-review-0223-input.json').read_bytes();(O/'input.json').write_bytes(data);save('input-hash.json',{'sha256':hashlib.sha256(data).hexdigest()});ms=[dict(role='system',content='Independent software/modeling framework extraction reviewer. Source-only. StrictJSON findings, never execute proposed code.'),dict(role='user',content=data.decode())];assert len(json.dumps(ms).encode())<85000;st('running',stage='DeepSeek_case_study_presentation_review');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 a=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=6000,thinking='disabled',reasoning_effort=None,timeout=900);r=json.loads((P/'private/api-ledger'/a['response_file']).read_text())['response'];save('response.json',r);save('usage.json',{k:a.get(k)for k in ['usage','cached','request_sha256']});assert all(type(r.get(k))is list and all(type(x)is str for x in r[k])for k in ['blocking','findings','limitations']);st('review_returned_requires_operator_decision',blocking=len(r['blocking']),findings=len(r['findings']))
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st('failed_or_rejected_no_retry',error_type=type(e).__name__)

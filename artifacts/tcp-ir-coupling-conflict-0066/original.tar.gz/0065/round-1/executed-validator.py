import ast,builtins,copy,hashlib,json,resource,struct,sys,traceback
from pathlib import Path
P=Path('/home/blxu/protocol-flow');J=P/'candidates/tcp-ir-coupling-repair-20261107-0065';W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace';O=J/'validation-0001';O.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_CPU,(240,240));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
sys.path.insert(0,str(W))
from protocol_lab.ir import load,validate,Machine
from protocol_lab.compose.lower_component_state import lower_component_state
from protocol_lab.compose.namespace_component import namespace_component
from protocol_lab.compose.disjoint_union import merge_disjoint_components

def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def pure(path,fixture=False):
 tree=ast.parse(path.read_text());defs={n.name for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)}
 names={'isinstance','str','int','bool','bytes','bytearray','list','dict','set','tuple','len','enumerate','zip','sorted','any','all','range','min','max','sum','next','iter','ValueError','TypeError','KeyError','RuntimeError','AssertionError'}
 methods={'items','keys','values','get','append','extend','add','update','pop','copy','startswith','endswith','setdefault','insert','index','remove'}
 for n in ast.walk(tree):
  need(not isinstance(n,(ast.ClassDef,ast.AsyncFunctionDef,ast.With,ast.AsyncWith,ast.Global,ast.Nonlocal,ast.Try,ast.Lambda)),'unsupported source construct')
  if isinstance(n,ast.Import):need(all(a.name in ({'copy','struct'}if fixture else{'copy'})and a.asname is None for a in n.names),'import not allowed')
  if isinstance(n,ast.ImportFrom):need(not fixture and n.module=='protocol_lab.ir' and all(a.name=='validate' and a.asname is None for a in n.names),'import not allowed')
  if isinstance(n,ast.Name):need(not n.id.startswith('__'),'private runtime access')
  if isinstance(n,ast.Attribute):
   special=(isinstance(n.value,ast.Name)and(n.value.id,n.attr)in{('copy','deepcopy'),('struct','pack'),('struct','unpack'),('bytes','fromhex')})
   need(n.attr in methods or special,'attribute not allowed: '+n.attr)
  if isinstance(n,ast.Call):
   f=n.func
   need((isinstance(f,ast.Name)and f.id in defs|names|({'validate'}if not fixture else set()))or isinstance(f,ast.Attribute),'call not allowed')
  if isinstance(n,(ast.Assign,ast.AnnAssign,ast.AugAssign)):
   ts=n.targets if isinstance(n,ast.Assign)else[n.target]
   need(not any(isinstance(x,ast.Attribute)and isinstance(x.ctx,ast.Store)for t in ts for x in ast.walk(t)),'attribute mutation forbidden')
 for n in tree.body:need(isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Expr)),'module-level executable statement')
 tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
 ns={'__builtins__':{k:getattr(builtins,k)for k in names},'copy':copy,'struct':struct,'validate':validate}
 exec(compile(tree,str(path),'exec'),ns)
 return ns
stage='freeze_fixture'
try:
 fp=P/'candidates/tcp-ir-coupling-code-20261107-0064/independent_fixture/proposals/coupled_oracle.py';mp=J/'round-1/couple_tcp.py'
 save('status.json',dict(status='running',stage=stage,API_calls=0))
 f=pure(fp,True);tcp=json.loads((W/'spec/tcp-wire-endpoint-oracle.json').read_text());arp=json.loads((W/'spec/arp-endpoint-oracle.json').read_text());old=copy.deepcopy((tcp,arp));cases=f['build_cases'](tcp,arp);need((tcp,arp)==old,'fixture mutated independent inputs')
 save('frozen-independent-fixture.json',cases)
 save('freeze-receipt.json',dict(source_sha256=hashlib.sha256(fp.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256((O/'frozen-independent-fixture.json').read_bytes()).hexdigest(),source_oracle_sha256={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [W/'spec/tcp-wire-endpoint-oracle.json',W/'spec/arp-endpoint-oracle.json']},model_constructed_before_freeze=False,oracle_approved=False))
 # Deterministic interface qualification under the controller's pre-existing contract.
 event_map={'app.connect':'T.app.connect','app.abort':'T.app.abort','app.resolve':'L.app.resolve','net.frame':'L.net.frame'}
 message_map={'ethernet.tx':'L.ethernet.tx','neighbor.resolved':'L.neighbor.resolved','application':'T.application'}
 qualified=copy.deepcopy(cases)
 for c in qualified['cases']:
  for step in c['steps']:
   need(step['event'] in event_map,'unexpected fixture event');step['event']=event_map[step['event']]
   for emitted in step['expected_emitted']:
    need(emitted['message'] in message_map,'unexpected fixture message');emitted['message']=message_map[emitted['message']]
    if emitted['message']=='L.ethernet.tx':
     frame=emitted['fields']['frame']
     if frame[12:14]==[8,0]:
      raw=tcp['cases']['bidirectional-cumulative-close']['steps'][0]['expect_trace'][0]['emitted'][0]['fields']['packet']
      need(frame==[2,0,0,0,0,2,2,0,0,0,0,1,8,0]+raw+[0]*6,'literal SYN Ethernet bytes differ from independent source')
     else:need(frame==list(bytes.fromhex(arp['request_hex'])),'literal ARP request differs')
 save('qualified-independent-fixture.json',qualified)
 save('qualification-receipt.json',dict(event_map=event_map,message_map=message_map,byte_values_and_expectations_unchanged=True,root_contract='0064/controller-contract.txt',qualified_sha256=hashlib.sha256((O/'qualified-independent-fixture.json').read_bytes()).hexdigest(),approved_scope='three finite cold/cached/abort-before-resolution stimulus cases only',model_constructed_before_qualification=False))
 stage='restricted_builder_validation';save('status.json',dict(status='running',stage=stage,API_calls=0))
 fn=pure(mp)['couple_tcp'];parts=[namespace_component(lower_component_state(load(W/n),'control','COMPOSED'),prefix)[0]for n,prefix in [('model/ipv4-udp-icmp-endpoint.json','L'),('model/tcp-wire-endpoint.json','T')]];base=merge_disjoint_components(parts,'finite-ipv4-tcp-udp-icmp-arp');frozen=copy.deepcopy(base);m=fn(base);need(base==frozen,'builder mutated input');validate(m)
 save('candidate-model.json',m)
 from protocol_lab.codegen import generate
 from protocol_lab.codegen.execute import build,run
 from protocol_lab.symbolic import crosscheck_trace
 references=[];scenes=[]
 for case in qualified['cases']:
  machine=Machine(m,case.get('initial',{}));scene=dict(scenario_version='0.2',id=case['id'],initial=case.get('initial',{}),steps=[])
  for step in case['steps']:
   before=len(machine.trace);machine.dispatch(step['event'],step.get('fields',{}),step['at_ms']);observed=machine.trace[before:]
   need(len(observed)==1,'fixture operation transition count differs')
   need(observed[0]['emitted']==step['expected_emitted'],'independent emitted bytes differ in '+case['id'])
   for k,v in step['expected_variables'].items():need(machine.values.get(k)==v,'independent variable differs '+case['id']+':'+k)
   need(machine.timers==step['expected_timers'],'independent timers differ '+case['id'])
   scene['steps'].append(dict(at_ms=step['at_ms'],event=step['event'],fields=step.get('fields',{}),expect_trace=[dict(at_ms=step['at_ms'],emitted=step['expected_emitted'])]))
  scene['expect']=dict(state='COMPOSED',variables=step['expected_variables'],timers=step['expected_timers'])
  save(case['id']+'-scenario.json',scene);save(case['id']+'-reference-trace.json',machine.trace);references.append(machine.trace);scenes.append(scene)
 stage='actual_native';save('status.json',dict(status='running',stage=stage,API_calls=0,reference_cases=len(scenes)))
 generate(O/'candidate-model.json',O/'generated');built=build(O/'generated',O/'build');need(built['status']=='pass','native build failed')
 for scene in scenes:
  native=run(O/'generated',O/'build',O/(scene['id']+'-scenario.json'),O/(scene['id']+'-native'));need(native['status']=='pass','native/reference differed')
 stage='independent_fixed_Z3';save('status.json',dict(status='running',stage=stage,API_calls=0,native_cases=len(scenes)))
 for scene,trace in zip(scenes,references):
  result=crosscheck_trace(m,trace,O/(scene['id']+'-symbolic'));need(result.get('query')=='sat'and result.get('status')=='match','fixed-input symbolic unresolved or mismatch')
 save('status.json',dict(status='finite_candidate_gate_pass_controller_review_required',stage='finished',API_calls=0,rules=len(m['transitions']),variables=len(m['variables']),literal_cases=len(scenes),native_cases=len(scenes),fixed_Z3_cases=len(scenes),all_input_safety='not_claimed',live_network=False,prototype_complete=False))
except Exception as e:
 save('status.json',dict(status='candidate_rejected',stage=stage,error_type=type(e).__name__,error=str(e)[:1800],API_calls=0,prototype_complete=False));(O/'traceback.txt').write_text(traceback.format_exc());raise

from pathlib import Path
import ast,hashlib,json,os,resource,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-tap-pure-support-20261108-0103';O.mkdir(exist_ok=False);PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request

def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def status(**x):save('status.json',dict(pid=os.getpid(),production_modified=False,network_executed=False,automatic_API_retry=False,prototype_complete=False,**x))
def call(name,system,data):
 messages=[dict(role='system',content=system),dict(role='user',content=json.dumps(data))];assert len(json.dumps(messages).encode())<96000;save(name+'-messages.json',messages)
 r=request(messages,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=16384,thinking='enabled',reasoning_effort='low',timeout=600)
 a=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response'];save(name+'-response.json',a);save(name+'-usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']});return a
CONTRACT='''Implement a SMALL PURE validation/helper layer for a later live single-IR TCP IPv4 TAP probe. This is deliberate decomposition after completed0102 driver review exposed trivial tests/wrong namespace/PCAP/quiet/error classification. Do NOT rewrite driver/main, access network or declare wholeprototype done. Return JSON {files:[{path,content}],limitations:[]} EXACT paths support.py and test_support.py. Both files standalone in samefolder. Support imports ONLY re,struct, no subprocess/socket/fcntl/os/network/fileIO. Test imports ONLY unittest,struct,support,copy. No exec/eval/dynamicimports. Tests must exercise functions with literal expected values, not pass/skip/assertTrue(True).
API EXACT:
1 elapsed_ms(origin_ns,sample_ns): both exact Python int notbool, origin>=0,sample>=origin else ValueError; return integerfloor difference/1000000. One origin for all runtime D/T; no time calls here.
2 capture_stats(text): parse exactly one line EACH N packets captured / N packets received by filter / N packets dropped by kernel (allow singular packet). Missing/duplicate/malformed negative stats ValueError, output dict(captured=int,received=int,dropped=int). MUST reject dropped!=0. Do NOT assume captured==received (filter cansee extra traffic). This is evidence validation, missing notzero.
3 pcap_records(raw): bytes classicPCAP little/big microsecondmagic only; globalversion2.4 Ethernetlinktype1,snaplen1..65535; HHIIII aftermagic means major,minor,thiszone,sigfig,snap,link. Everypacket uint sec/frac withfrac<1000000; captured<=snap,captured==original (rejecttruncatedcapture), original>=14, completeheaders/data, timestampsnondecreasing. Return list[{timestamp_ns:int,raw:bytes}]. EmptyPCAPvalidparser butquietrejects. NOprotocoldecoding/padding/filter/synthesis, rawunmodified. Unsupportedmagic inclnanosecond explicitlyValueError.
4 quiet_ok(records,stop_request_wall_ns,quiet_ms=100): intnotbool stop>=0/quiet>=0, recordsnonempty; timestamp oflastrecord<=stop; return difference>=quiet_ms*1000000, elseFalse. This function only verifies snapshot; live caller must keep sampling captureuntilactualdeadline, verifyprocessalive, stopcaptureBEFORE closing. No sleep here.
5 operation_result(rows): require nonemptylist terminalrow dictstatus 'ok' or 'error'; precedingrows dictstatus 'transition'. terminalerror failure required nonemptystr -> dict(status='error',category=...,failure=...,frames=[],services=[]), regardless prior emitteddata. category uncovered_event=model_gap,rule_conflict=rule_conflict, failure starts invariant:=invariant_failure, otherwise driver_failure. Terminalok inspect emissions fromprecedingtransition rows only: item{message,fields}, ethernet.tx fields EXACT frame:list octets intnotbool -> frames listbytes, othermessageitems deepcopies into services. Invalidshape/value raisesValueError; no rawforwarding ormutations here. Return dict(status='ok',category=None,failure=None,frames=[...],services=[...]). Failed op never returns frames toforward. Terminalemittednonempty onok mustreject (onlytransitionemitsvalid).
6 record_error(report,category,reason): report dict with error None or dict and secondary_errors list(defaultcreate); iferrorNone set dict(category=category,reason=reason); else appendnewerror; preservefirst. allowedcategories blocked_preflight,driver_failure,model_gap,rule_conflict,invariant_failure,capture_invalid,cleanup_failure. No collapsingblocked/runtime/gap/conflict. Callerdecidesclassification, noIO. Return None. Validate exactstrings.
No model/oracle/backend logic; this layer validates transport/evidence only. Root fixed tests run independently of yourtests. Then independent source review. Pure tests do not constitute live/TAP/PCAPmeasurement/compilerproof. Max~200lines support plus meaningful~150lines tests.'''
# Independently frozen before API. Not generated from candidate output.
FIXED='''import copy,struct,unittest
import support as s
class ControllerContracts(unittest.TestCase):
 def test_clock(self):
  self.assertEqual(s.elapsed_ms(900000000000,900001999999),1)
  for pair in [(True,2),(1,False),(2,1),(-1,0)]:
   with self.assertRaises(ValueError):s.elapsed_ms(*pair)
 def test_stats(self):
  self.assertEqual(s.capture_stats('2 packets captured\\n3 packets received by filter\\n0 packets dropped by kernel\\n'),dict(captured=2,received=3,dropped=0))
  for text in ['', '2 packets captured\\n0 packets dropped by kernel', '2 packets captured\\n2 packets received by filter\\n1 packet dropped by kernel', '2 packets captured\\n2 packets captured\\n2 packets received by filter\\n0 packets dropped by kernel']:
   with self.assertRaises(ValueError):s.capture_stats(text)
 def test_pcap(self):
  frame=bytes(range(14))
  for e,magic in [('<',bytes.fromhex('d4c3b2a1')),('>',bytes.fromhex('a1b2c3d4'))]:
   raw=magic+struct.pack(e+'HHIIII',2,4,0,0,65535,1)+struct.pack(e+'IIII',1,123,14,14)+frame
   self.assertEqual(s.pcap_records(raw),[dict(timestamp_ns=1000123000,raw=frame)])
   for bad in [raw[:-1],raw[:4]+struct.pack(e+'HHIIII',0,0,2,4,65535,1)+raw[24:],raw[:24]+struct.pack(e+'IIII',1,1000000,14,14)+frame,raw[:24]+struct.pack(e+'IIII',1,123,14,15)+frame]:
    with self.assertRaises(ValueError):s.pcap_records(bad)
 def test_quiet(self):
  self.assertFalse(s.quiet_ok([],1000000000));self.assertFalse(s.quiet_ok([dict(timestamp_ns=1000000000)],1099999999));self.assertTrue(s.quiet_ok([dict(timestamp_ns=1000000000)],1100000000))
 def test_forward_and_failures(self):
  rows=[dict(status='transition',emitted=[dict(message='ethernet.tx',fields=dict(frame=[0,128,255])),dict(message='T.application_data',fields=dict(data=[7]))]),dict(status='ok')]
  before=copy.deepcopy(rows);r=s.operation_result(rows);self.assertEqual(r['frames'],[b'\\x00\\x80\\xff']);self.assertEqual(r['services'],[dict(message='T.application_data',fields=dict(data=[7]))]);self.assertEqual(rows,before)
  for failure,category in [('uncovered_event','model_gap'),('rule_conflict','rule_conflict'),('invariant:bad','invariant_failure'),('other','driver_failure')]:
   r=s.operation_result([rows[0],dict(status='error',failure=failure)]);self.assertEqual(r['frames'],[]);self.assertEqual(r['category'],category)
  for bad in [[dict(status='ready')],[dict(status='ok',emitted=[{}])],[dict(status='transition',emitted=[dict(message='ethernet.tx',fields=dict(frame=[True]))]),dict(status='ok')]]:
   with self.assertRaises(ValueError):s.operation_result(bad)
 def test_primary_error(self):
  report=dict(error=None);s.record_error(report,'model_gap','uncovered_event');s.record_error(report,'cleanup_failure','close');self.assertEqual(report['error'],dict(category='model_gap',reason='uncovered_event'));self.assertEqual(report['secondary_errors'],[dict(category='cleanup_failure',reason='close')])
if __name__=='__main__':unittest.main()
'''
try:
 status(status='running',stage='pure_helpers_implementation',started_at=time.time());(O/'contract.txt').write_text(CONTRACT);(O/'controller-tests-frozen.txt').write_text(FIXED);save('controller-test-freeze.json',dict(sha256=hashlib.sha256(FIXED.encode()).hexdigest(),frozen_before_API=True))
 r=call('implementation','You implement small pure Python helpers and meaningful tests. JSON files only, no command/network/private access, no execution claims. Follow exact function signatures and contracts.',dict(task=CONTRACT))
 files=r.get('files');assert isinstance(files,list)and{f['path']for f in files}=={'support.py','test_support.py'}and len(files)==2
 d=O/'proposals';d.mkdir()
 for f in files:
  assert set(f)=={'path','content'};tree=ast.parse(f['content']);allowed={'re','struct'}if f['path']=='support.py'else{'unittest','struct','support','copy'}
  for n in ast.walk(tree):
   if isinstance(n,ast.Import):assert all(x.name in allowed for x in n.names)
   if isinstance(n,ast.ImportFrom):assert n.module in allowed
   if isinstance(n,ast.Call)and isinstance(n.func,ast.Name):assert n.func.id not in {'exec','eval','compile','open','__import__','input','breakpoint'}
  (d/f['path']).write_text(f['content'])
 (d/'test_controller_contracts.py').write_text(FIXED)
 # Pure source has no imports capable of network/process/file actions. Audit hook
 # denies any accidental host operations before unittest imports candidate.
 runner="""import sys,unittest
 defhook=None
""".replace(' defhook=None\n','')+"""def deny(event,args):
 if event in ('subprocess.Popen','os.system','os.posix_spawn','socket.__new__','socket.connect','socket.bind','ctypes.dlopen'):raise RuntimeError('Real host I/O forbidden: '+event)
 if event=='open' and str(args[0]).startswith('/dev/'):raise RuntimeError('Device open forbidden')
sys.addaudithook(deny)
suite=unittest.defaultTestLoader.discover('.',pattern='test_*.py');r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(0 if r.wasSuccessful() else 1)
"""
 (d/'run_pure_tests.py').write_text(runner);status(status='running',stage='actual_agent_and_independent_controller_tests')
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(20,20));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
 with(O/'tests.log').open('w')as log:cp=subprocess.run([str(PY),'-B',str(d/'run_pure_tests.py')],cwd=d,stdout=log,stderr=subprocess.STDOUT,timeout=30,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 save('test-result.json',dict(returncode=cp.returncode,host_IO_forbidden=True,network_executed=False,controller_tests_sha256=hashlib.sha256(FIXED.encode()).hexdigest()))
 if cp.returncode:
  status(status='actual_contract_tests_rejected',stage='finished',finished_at=time.time());raise SystemExit(0)
 status(status='running',stage='independent_review_after_actual_tests')
 review=call('review','Independent strict reviewer. JSON exactly blocking/findings/limitations LISTS, never patches/files. Source data only. Judge transport/evidence helper correctness, no protocol decisions or live proof.',dict(task=CONTRACT,candidate=files,controller_tests=FIXED,actual_log=(O/'tests.log').read_text(),scope='purehelpers ONLY, not driver/live/compilerproof'))
 assert isinstance(review,dict)and set(review)=={'blocking','findings','limitations'}and all(isinstance(v,list)for v in review.values())
 status(status='review_findings'if review['blocking']else'pure_candidate_ready_controller_review_required',stage='finished',review=review,finished_at=time.time())
except Exception as e:
 status(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__,error=str(e),finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

import copy,struct,unittest
import support as s
class ControllerContracts(unittest.TestCase):
 def test_clock(self):
  self.assertEqual(s.elapsed_ms(900000000000,900001999999),1)
  for pair in [(True,2),(1,False),(2,1),(-1,0)]:
   with self.assertRaises(ValueError):s.elapsed_ms(*pair)
 def test_stats(self):
  self.assertEqual(s.capture_stats('2 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n'),dict(captured=2,received=3,dropped=0))
  for text in ['', '2 packets captured\n0 packets dropped by kernel', '2 packets captured\n2 packets received by filter\n1 packet dropped by kernel', '2 packets captured\n2 packets captured\n2 packets received by filter\n0 packets dropped by kernel']:
   with self.assertRaises(ValueError):s.capture_stats(text)
 def test_pcap(self):
  frame=bytes(range(14))
  for e,magic in [('<',bytes.fromhex('d4c3b2a1')),('>',bytes.fromhex('a1b2c3d4'))]:
   raw=magic+struct.pack(e+'HHIIII',2,4,0,0,65535,1)+struct.pack(e+'IIII',1,123,14,14)+frame
   self.assertEqual(s.pcap_records(raw),[dict(timestamp_ns=1000123000,raw=frame)])
   for bad in [raw[:-1],raw[:4]+struct.pack(e+'HHIIII',0,0,2,4,65535,1)+raw[24:],raw[:24]+struct.pack(e+'IIII',1,1000000,14,14)+frame,raw[:24]+struct.pack(e+'IIII',1,123,14,15)+frame]:
    with self.assertRaises(ValueError):s.pcap_records(bad)
 def test_quiet(self):
  self.assertFalse(s.quiet_ok([],1000000000));self.assertFalse(s.quiet_ok([dict(timestamp_ns=1000000000)],1099999999));self.assertTrue(s.quiet_ok([dict(timestamp_ns=1000000000)],1100000000))
 def test_forward_and_failures(self):
  rows=[dict(status='transition',emitted=[dict(message='ethernet.tx',fields=dict(frame=[0,128,255])),dict(message='T.application_data',fields=dict(data=[7]))]),dict(status='ok')]
  before=copy.deepcopy(rows);r=s.operation_result(rows);self.assertEqual(r['frames'],[b'\x00\x80\xff']);self.assertEqual(r['services'],[dict(message='T.application_data',fields=dict(data=[7]))]);self.assertEqual(rows,before)
  for failure,category in [('uncovered_event','model_gap'),('rule_conflict','rule_conflict'),('invariant:bad','invariant_failure'),('other','driver_failure')]:
   r=s.operation_result([rows[0],dict(status='error',failure=failure)]);self.assertEqual(r['frames'],[]);self.assertEqual(r['category'],category)
  for bad in [[dict(status='ready')],[dict(status='ok',emitted=[{}])],[dict(status='transition',emitted=[dict(message='ethernet.tx',fields=dict(frame=[True]))]),dict(status='ok')]]:
   with self.assertRaises(ValueError):s.operation_result(bad)
 def test_primary_error(self):
  report=dict(error=None);s.record_error(report,'model_gap','uncovered_event');s.record_error(report,'cleanup_failure','close');self.assertEqual(report['error'],dict(category='model_gap',reason='uncovered_event'));self.assertEqual(report['secondary_errors'],[dict(category='cleanup_failure',reason='close')])
if __name__=='__main__':unittest.main()

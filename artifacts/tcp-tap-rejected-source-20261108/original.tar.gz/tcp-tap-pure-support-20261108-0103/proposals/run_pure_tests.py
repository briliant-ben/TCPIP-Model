import sys,unittest
def deny(event,args):
 if event in ('subprocess.Popen','os.system','os.posix_spawn','socket.__new__','socket.connect','socket.bind','ctypes.dlopen'):raise RuntimeError('Real host I/O forbidden: '+event)
 if event=='open' and str(args[0]).startswith('/dev/'):raise RuntimeError('Device open forbidden')
sys.addaudithook(deny)
suite=unittest.defaultTestLoader.discover('.',pattern='test_*.py');r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(0 if r.wasSuccessful() else 1)

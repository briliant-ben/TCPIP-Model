#!/usr/bin/env python3
"""First-ingress TCP/IPv4 diagnostic probe. Not a full peer exchange."""
import argparse
import errno
import fcntl
import hashlib
import json
import os
import platform
import re
import select
import signal
import socket
import struct
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PORT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PORT))

from ports.native_session import Session
from protocol_lab.codegen import generate, sha
from protocol_lab.codegen.execute import build, commands
from protocol_lab.ir import load
from ports.linux_arp_udp_peer.capture import records

QUIET_MS = 100
DEFAULT_TIMEOUT_S = 10
TAP_IFNAME = "probe0"
SUBJECT_MAC = "02:00:00:00:00:01"
SUBJECT_IP = "192.0.2.1"
PEER_MAC = "02:00:00:00:00:02"
PEER_IP = "192.0.2.2"
PEER_PORT = 8080


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def classify_ethertype(frame: bytes) -> str:
    if len(frame) < 14:
        raise ValueError("Short frame")
    et = frame[12:14]
    if et == b"\x08\x06":
        return "arp"
    if et == b"\x08\x00":
        return "ipv4"
    return "other"


def is_ipv4_tcp(frame: bytes) -> bool:
    try:
        return classify_ethertype(frame) == "ipv4" and len(frame) >= 34 and frame[14 + 9] == 6
    except ValueError:
        return False


def commands_dict(model, scenario):
    return commands(load(model), scenario).splitlines()


def save_raw(data: bytes, out: Path, name: str) -> Path:
    path = out / name
    path.write_bytes(data)
    return path


def namespace_proof(parent_ns: str, current_ns: str, out: Path) -> None:
    if parent_ns == current_ns:
        raise ValueError("Parent and current netns identical")
    (out / "namespace_proof.json").write_text(
        json.dumps({"parent_netns": parent_ns, "current_netns": current_ns, "distinct": True}, indent=2) + "\n"
    )


def pcap_quiet_ok(records: list, stop_wall_ns: int, quiet_ms: int) -> bool:
    if not records:
        return False
    last_ts = records[-1]["timestamp_ns"]
    return (stop_wall_ns - last_ts) >= quiet_ms * 1_000_000


def parse_drop_count(log_text: str) -> int:
    match = re.search(r"(\d+)\s+packets?\s+dropped\s+by\s+kernel", log_text)
    return int(match.group(1)) if match else 0


def parse_pcap(path: Path) -> list:
    raw = path.read_bytes()
    magics = {
        b'\xd4\xc3\xb2\xa1': ('<', 1000),
        b'\xa1\xb2\xc3\xd4': ('>', 1000),
        b'\x4d\x3c\xb2\xa1': ('<', 1),
        b'\xa1\xb2\x3c\x4d': ('>', 1),
    }
    if len(raw) < 24 or raw[:4] not in magics:
        raise ValueError("Classic PCAP required")
    endian, factor = magics[raw[:4]]
    major, minor, zone, accuracy, snap, link = struct.unpack(endian + 'HHIIII', raw[4:24])
    if (major, minor) != (2, 4) or snap <= 0 or link != 1:
        raise ValueError("Ethernet PCAP version 2.4 required")
    pos = 24
    previous = -1
    records = []
    while pos < len(raw):
        if pos + 16 > len(raw):
            raise ValueError("Truncated PCAP header")
        sec, frac, n, original = struct.unpack(endian + 'IIII', raw[pos:pos+16])
        pos += 16
        stamp = sec * 1_000_000_000 + frac * factor
        if frac >= 1_000_000_000 // factor or n != original or n > snap or pos+n > len(raw) or stamp < previous:
            raise ValueError("Invalid PCAP length/time")
        frame = raw[pos:pos+n]
        pos += n
        previous = stamp
        records.append({"timestamp_ns": stamp, "raw": frame})
    return records


def command(args, out, name, timeout=10):
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    (out / name).write_text(p.stdout + p.stderr)
    if p.returncode != 0:
        raise RuntimeError("Command failed: " + str(args))
    return dict(command=args, returncode=p.returncode, log=name, stdout=p.stdout, stderr=p.stderr)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True, help="fresh diagnostic output directory")
    p.add_argument("--model", type=Path, required=True, help="IR model JSON path")
    p.add_argument("--executable", type=Path, required=True, help="native protocol binary")
    p.add_argument("--parent-pid", type=int, default=os.getppid(), help="parent PID for namespace proof")
    p.add_argument("--server-script", type=Path, default=PORT / "server.py")
    p.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT_S)
    args = p.parse_args()

    out = args.out
    if out.exists():
        raise ValueError("Output directory must be fresh")
    out.mkdir(parents=True)

    report = {
        "outcomes": {
            "blocked": False,
            "driver_failure": False,
            "captured_model_gap": False,
            "first_tcp_ingress_admitted": False,
            "full_TCP_exchange_complete": False,
            "whole_ipv4_endpoint_complete": False,
            "physical_ethernet": False,
        },
        "error": None,
        "model": str(args.model),
        "model_sha256": None,
        "executable": str(args.executable),
        "executable_sha256": None,
        "namespace": None,
        "capture": None,
        "server": None,
        "native": None,
        "events": [],
        "missing_z3": "not verified",
    }
    resources = {"capture": None, "actor": None, "server": None, "tap_fd": None}
    report_written = False

    try:
        # Preflight
        if platform.system() != "Linux" or os.geteuid() != 0:
            raise RuntimeError("Linux root required")
        if not Path("/dev/net/tun").exists():
            raise RuntimeError("TUN/TAP device missing")
        parent_ns = os.readlink(f"/proc/{args.parent_pid}/ns/net")
        current_ns = os.readlink("/proc/self/ns/net")
        namespace_proof(parent_ns, current_ns, out)
        report["namespace"] = {"parent": parent_ns, "current": current_ns, "distinct": True}

        for tool in ("ip", "tcpdump"):
            if not any(os.access(os.path.join(path, tool), os.X_OK) for path in os.environ["PATH"].split(os.pathsep)):
                raise RuntimeError(f"Missing required tool: {tool}")
        if not args.server_script.exists():
            raise RuntimeError(f"Server script not found: {args.server_script}")
        if not args.executable.exists():
            raise RuntimeError(f"Native executable not found: {args.executable}")
        if not args.model.exists():
            raise RuntimeError(f"Model file not found: {args.model}")
        report["model_sha256"] = sha256_file(args.model)
        report["executable_sha256"] = sha256_file(args.executable)

        # Prepare TAP device
        tap_fd = os.open("/dev/net/tun", os.O_RDWR)
        resources["tap_fd"] = tap_fd
        ifr = struct.pack("16sH22x", TAP_IFNAME.encode(), 0x1002)  # IFF_TAP | IFF_NO_PI, flags only
        fcntl.ioctl(tap_fd, 0x400454CA, ifr)

        # Start tcpdump capture
        capture_log_path = out / "capture.log"
        capture_pcap_path = out / "capture.pcap"
        capture_cmd = [
            "tcpdump", "--immediate-mode", "-Z", "root", "-U", "-n",
            "-s", "65535", "-i", TAP_IFNAME, "-w", str(capture_pcap_path),
            "ether proto 0x0800 or ether proto 0x0806"
        ]
        with open(capture_log_path, 'w') as capture_log:
            capture = subprocess.Popen(capture_cmd, stdout=capture_log, stderr=capture_log)
            resources["capture"] = capture
            ready_deadline = time.monotonic() + 5
            while True:
                if capture.poll() is not None:
                    raise RuntimeError("tcpdump failed to start")
                log_content = capture_log_path.read_text()
                if "listening on" in log_content:
                    break
                if time.monotonic() > ready_deadline:
                    raise RuntimeError("tcpdump readiness timeout")
                time.sleep(0.02)

        # Configure TAP device
        setup_commands = [
            ["ip", "link", "set", "lo", "up"],
            ["ip", "link", "set", TAP_IFNAME, "address", SUBJECT_MAC],
            ["ip", "addr", "add", SUBJECT_IP + "/24", "dev", TAP_IFNAME],
            ["ip", "link", "set", TAP_IFNAME, "mtu", "1500", "up"],
            ["ip", "addr", "show"],
            ["ip", "route", "show"],
        ]
        for i, cmd in enumerate(setup_commands):
            command(cmd, out, f"setup-{i}.log")

        # Start independent TCP server with stdin PIPE held open
        server_out = out / "server"
        server_out.mkdir()
        server_cmd = [
            sys.executable, str(args.server_script),
            "--out", str(server_out),
            "--ip", PEER_IP,
            "--port", str(PEER_PORT),
            "--count", "4",
        ]
        server = subprocess.Popen(server_cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        resources["server"] = server
        server_events_file = server_out / "server-events.jsonl"
        server_ready = False
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if server.poll() is not None:
                raise RuntimeError("Server process exited before listening")
            if server_events_file.exists():
                for line in server_events_file.read_text().splitlines():
                    try:
                        ev = json.loads(line)
                        if ev.get("event") == "listening":
                            server_ready = True
                            break
                    except json.JSONDecodeError:
                        pass
            if server_ready:
                break
            time.sleep(0.05)
        if not server_ready:
            raise RuntimeError("Server readiness timeout")

        # Start native model session
        native_out = out / "native"
        actor = Session(args.executable, native_out)
        resources["actor"] = actor
        clock_origin = time.monotonic_ns()

        # Commission subject using T.app.connect
        connect_row = commands_dict(args.model, dict(initial={}, steps=[
            dict(event='T.app.connect', at_ms=0)
        ]))[1]
        connect_rows = actor.operation(connect_row)
        if connect_rows[-1]["status"] != "ok":
            raise RuntimeError(f"app.connect returned status {connect_rows[-1]['status']}")

        events = []
        link_index = 0
        unselected_index = 0
        raw_link_files = []

        def deliver_emitted(rows, tap_fd, link_idx):
            nonlocal link_index
            for row in rows:
                for item in row.get("emitted", []):
                    if item["message"] == "ethernet.tx":
                        if set(item["fields"]) != {'frame'}:
                            raise RuntimeError("Unexpected ethernet.tx fields")
                        raw = bytes(item["fields"]["frame"])
                        save_raw(raw, out, f"link-{link_idx}.raw")
                        os.write(tap_fd, raw)
                        events.append({"type": "tx", "index": link_idx, "timestamp_ns": time.monotonic_ns()})
                        link_idx += 1

        deliver_emitted(connect_rows, tap_fd, link_index)

        admitted = False
        error_encountered = None
        deadline = time.monotonic() + args.timeout

        while time.monotonic() < deadline and not admitted and error_encountered is None:
            # Tick handling
            if actor.snapshot and actor.snapshot.get("timers"):
                due_ms = min(actor.snapshot["timers"].values())
                now_ms = int((time.monotonic_ns() - clock_origin) // 1_000_000)
                if now_ms >= due_ms:
                    tick_line = commands_dict(args.model, dict(initial={}, steps=[
                        dict(tick=True, at_ms=now_ms)
                    ]))[1]
                    rows = actor.operation(tick_line)
                    if rows[-1]["status"] != "ok":
                        error_encountered = {"category": "driver_failure", "reason": f"tick returned status {rows[-1]['status']}"}
                        break
                    deliver_emitted(rows, tap_fd, link_index)
                    continue

            timeout = 0.1
            if actor.snapshot and actor.snapshot.get("timers"):
                due_ms = min(actor.snapshot["timers"].values())
                now_ms = int((time.monotonic_ns() - clock_origin) // 1_000_000)
                timeout = max(0, min(0.1, (due_ms - now_ms) / 1000))

            readable, _, _ = select.select([tap_fd], [], [], timeout)
            if tap_fd in readable:
                raw = os.read(tap_fd, 65535)
                if len(raw) < 14:
                    save_raw(raw, out, f"unselected-{unselected_index}.raw")
                    events.append({"type": "rx_unselected", "index": unselected_index, "ethertype": "short", "timestamp_ns": time.monotonic_ns()})
                    unselected_index += 1
                    continue
                et = classify_ethertype(raw)
                if et in ("arp", "ipv4"):
                    idx = link_index
                    save_raw(raw, out, f"link-{idx}.raw")
                    raw_link_files.append(out / f"link-{idx}.raw")
                    events.append({"type": "rx_selected", "index": idx, "ethertype": et, "timestamp_ns": time.monotonic_ns()})
                    link_index += 1
                    at_ms = int((time.monotonic_ns() - clock_origin) // 1_000_000)
                    net_frame_line = commands_dict(args.model, dict(initial={}, steps=[
                        dict(event='net.frame', fields=dict(frame=list(raw)), at_ms=at_ms)
                    ]))[1]
                    try:
                        rows = actor.operation(net_frame_line)
                    except Exception as e:
                        error_encountered = {"category": "driver_failure", "reason": str(e)}
                        break
                    last_row = rows[-1]
                    if last_row["status"] not in ("ok", "error"):
                        error_encountered = {"category": "driver_failure", "reason": f"unexpected status {last_row['status']}"}
                        break
                    if last_row["status"] == "error":
                        reason = last_row.get("failure", "unknown")
                        if reason.startswith("uncovered_event"):
                            category = "captured_model_gap"
                        elif reason.startswith("rule_conflict") or reason.startswith("invariant:"):
                            category = "captured_model_gap"
                        else:
                            category = "driver_failure"
                        error_encountered = {"category": category, "reason": reason}
                        break
                    deliver_emitted(rows, tap_fd, link_index)
                    if is_ipv4_tcp(raw):
                        admitted = True
                else:
                    idx = unselected_index
                    save_raw(raw, out, f"unselected-{idx}.raw")
                    events.append({"type": "rx_unselected", "index": idx, "ethertype": et, "timestamp_ns": time.monotonic_ns()})
                    unselected_index += 1

        # Quiet gate: continue until actual quiet of QUIET_MS from last selected PCAP timestamp
        quiet_achieved = False
        while time.monotonic() < deadline and not quiet_achieved:
            if actor.snapshot and actor.snapshot.get("timers"):
                due_ms = min(actor.snapshot["timers"].values())
                now_ms = int((time.monotonic_ns() - clock_origin) // 1_000_000)
                if now_ms >= due_ms:
                    tick_line = commands_dict(args.model, dict(initial={}, steps=[
                        dict(tick=True, at_ms=now_ms)
                    ]))[1]
                    rows = actor.operation(tick_line)
                    if rows[-1]["status"] != "ok":
                        error_encountered = {"category": "driver_failure", "reason": f"tick returned status {rows[-1]['status']}"}
                        break
                    deliver_emitted(rows, tap_fd, link_index)
                    continue
            timeout = 0.01
            if actor.snapshot and actor.snapshot.get("timers"):
                due_ms = min(actor.snapshot["timers"].values())
                now_ms = int((time.monotonic_ns() - clock_origin) // 1_000_000)
                timeout = max(0, min(0.01, (due_ms - now_ms) / 1000))
            readable, _, _ = select.select([tap_fd], [], [], timeout)
            if tap_fd in readable:
                raw = os.read(tap_fd, 65535)
                if len(raw) < 14:
                    save_raw(raw, out, f"unselected-{unselected_index}.raw")
                    events.append({"type": "rx_unselected", "index": unselected_index, "ethertype": "short", "timestamp_ns": time.monotonic_ns()})
                    unselected_index += 1
                    continue
                et = classify_ethertype(raw)
                if et in ("arp", "ipv4"):
                    idx = link_index
                    save_raw(raw, out, f"link-{idx}.raw")
                    raw_link_files.append(out / f"link-{idx}.raw")
                    events.append({"type": "rx_selected", "index": idx, "ethertype": et, "timestamp_ns": time.monotonic_ns()})
                    link_index += 1
                    at_ms = int((time.monotonic_ns() - clock_origin) // 1_000_000)
                    net_frame_line = commands_dict(args.model, dict(initial={}, steps=[
                        dict(event='net.frame', fields=dict(frame=list(raw)), at_ms=at_ms)
                    ]))[1]
                    try:
                        rows = actor.operation(net_frame_line)
                    except Exception as e:
                        error_encountered = {"category": "driver_failure", "reason": str(e)}
                        break
                    last_row = rows[-1]
                    if last_row["status"] not in ("ok", "error"):
                        error_encountered = {"category": "driver_failure", "reason": f"unexpected status {last_row['status']}"}
                        break
                    if last_row["status"] == "error":
                        reason = last_row.get("failure", "unknown")
                        if reason.startswith("uncovered_event"):
                            category = "captured_model_gap"
                        elif reason.startswith("rule_conflict") or reason.startswith("invariant:"):
                            category = "captured_model_gap"
                        else:
                            category = "driver_failure"
                        error_encountered = {"category": category, "reason": reason}
                        break
                    deliver_emitted(rows, tap_fd, link_index)
                else:
                    idx = unselected_index
                    save_raw(raw, out, f"unselected-{idx}.raw")
                    events.append({"type": "rx_unselected", "index": idx, "ethertype": et, "timestamp_ns": time.monotonic_ns()})
                    unselected_index += 1
            # Check quiet: last selected PCAP timestamp at least QUIET_MS before now
            pcap_records_now = parse_pcap(capture_pcap_path) if capture_pcap_path.exists() else []
            selected_now = [r for r in pcap_records_now if classify_ethertype(r["raw"]) in ("arp", "ipv4")]
            if selected_now and (time.time_ns() - selected_now[-1]["timestamp_ns"]) >= QUIET_MS * 1_000_000:
                quiet_achieved = True
            if not selected_now and time.time_ns() - last_activity_ns >= QUIET_MS * 1_000_000:
                quiet_achieved = True

        # Verify all processes alive before requesting capture stop
        if capture.poll() is not None:
            raise RuntimeError("tcpdump process ended prematurely")
        if actor.process.poll() is not None:
            raise RuntimeError("native session ended prematurely")
        if server.poll() is not None:
            raise RuntimeError("server process ended prematurely")

        # Request capture stop
        stop_request_wall_ns = time.time_ns()
        capture.send_signal(signal.SIGINT)
        capture_rc = capture.wait(timeout=5)
        capture_stop_wall_ns = time.time_ns()

        # Parse capture and validate stats
        pcap_records = parse_pcap(capture_pcap_path) if capture_pcap_path.exists() else []
        selected_pcap_records = [r for r in pcap_records if classify_ethertype(r["raw"]) in ("arp", "ipv4")]
        if not selected_pcap_records:
            raise RuntimeError("Zero selected ARP/IPv4 packets in capture")
        drop_log = capture_log_path.read_text()
        drops = parse_drop_count(drop_log)
        if drops > 0:
            raise RuntimeError(f"tcpdump reported {drops} dropped packets")
        # Ensure captured, filtered, and PCAP counts match (all stats required)
        captured_match = re.search(r"(\d+) packets captured", drop_log)
        filtered_match = re.search(r"(\d+) packets received by filter", drop_log)
        if not captured_match or not filtered_match:
            raise RuntimeError("Capture stats missing from tcpdump log")
        captured_count = int(captured_match.group(1))
        filtered_count = int(filtered_match.group(1))
        if captured_count != filtered_count or filtered_count != len(selected_pcap_records):
            raise RuntimeError("Capture count mismatch")
        if capture_rc != 0:
            raise RuntimeError(f"tcpdump exited with non-zero: {capture_rc}")
        if not pcap_quiet_ok(selected_pcap_records, stop_request_wall_ns, QUIET_MS):
            raise RuntimeError("Quiet gate failed")
        # Verify raw link files match selected PCAP exactly
        if len(raw_link_files) != len(selected_pcap_records):
            raise RuntimeError("Number of raw link files does not match selected PCAP records")
        for i, (raw_file, pcap_rec) in enumerate(zip(raw_link_files, selected_pcap_records)):
            if raw_file.read_bytes() != pcap_rec["raw"]:
                raise RuntimeError(f"Raw link file {i} differs from PCAP record")

        # Close resources in order: actor, server, TAP
        actor_return = actor.close()
        actor_pid = actor.process.pid
        server_terminated = False
        try:
            server.terminate()
            server.wait(timeout=5)
            server_terminated = True
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait()
            server_terminated = True
        finally:
            if server.stdin:
                server.stdin.close()
        os.close(tap_fd)

        # Server acceptance check
        server_accepted = False
        if server_events_file.exists():
            for line in server_events_file.read_text().splitlines():
                try:
                    ev = json.loads(line)
                    if ev.get("event") == "accepted":
                        server_accepted = True
                except json.JSONDecodeError:
                    pass

        report.update({
            "outcomes": {
                "blocked": False,
                "driver_failure": error_encountered is not None and error_encountered["category"] == "driver_failure",
                "captured_model_gap": error_encountered is not None and error_encountered["category"] == "captured_model_gap",
                "first_tcp_ingress_admitted": admitted,
                "full_TCP_exchange_complete": False,
                "whole_ipv4_endpoint_complete": False,
                "physical_ethernet": False,
            },
            "error": error_encountered,
            "clock_origin_actor_started_ns": actor.started,
            "clock_origin_separate_ns": clock_origin,
            "capture": {
                "pcap": str(capture_pcap_path),
                "log": str(capture_log_path),
                "returncode": capture_rc,
                "stop_request_wall_ns": stop_request_wall_ns,
                "capture_stop_wall_ns": capture_stop_wall_ns,
                "last_selected_pcap_ts": selected_pcap_records[-1]["timestamp_ns"],
                "quiet_ms": QUIET_MS,
                "drops": drops,
                "captured_count": captured_count,
                "filtered_count": filtered_count,
                "pcap_count": len(selected_pcap_records),
            },
            "server": {"script": str(args.server_script), "accepted": server_accepted, "terminated": server_terminated},
            "native": {"pid": actor_pid, "returncode": actor_return},
            "events": events,
        })
        report_written = True
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    except Exception as e:
        if report["error"] is None:
            report["error"] = {"category": "driver_failure", "reason": str(e)}
            report["outcomes"]["blocked"] = True
        else:
            # Preserve first semantic error, but add secondary cleanup errors
            report["secondary_errors"] = report.get("secondary_errors", [])
            report["secondary_errors"].append({"category": "driver_failure", "reason": str(e)})
    finally:
        if resources["capture"] and resources["capture"].poll() is None:
            try:
                resources["capture"].send_signal(signal.SIGINT)
                resources["capture"].wait(timeout=5)
            except Exception:
                pass
        if resources["actor"] and not resources["actor"].closed:
            try:
                resources["actor"].close()
            except Exception:
                pass
        if resources["server"] and resources["server"].poll() is None:
            try:
                resources["server"].terminate()
                resources["server"].wait(timeout=5)
            except Exception:
                pass
        if resources["tap_fd"] is not None:
            try:
                os.close(resources["tap_fd"])
            except Exception:
                pass
        if not report_written:
            try:
                (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
            except Exception:
                pass


if __name__ == "__main__":
    main()

"""Proposed test cases for the pure disjoint union builder.

These are a proposal only; they are not executed here and the result remains
unapproved until external structural/reference/native gates pass. All test
components are artificial atomic-v1 fragments built to the declared contract.
"""
import copy

import pytest
from protocol_lab.compose.disjoint_union import merge_disjoint_components


def _comp(ver="0.6", vars_=None, events=None, timers=None, messages=None,
          requirements=None, transitions=None, invariants=None, scope=None):
    return {
        "ir_version": ver,
        "semantics": "flat-efsm-atomic-ordered-v1",
        "protocol": "frag",
        "scope": scope if scope is not None else {"terminal_states": []},
        "states": ["READY"],
        "initial_state": "READY",
        "variables": vars_ or {},
        "events": events or {},
        "timers": timers or {},
        "messages": messages or {},
        "requirements": requirements or {},
        "transitions": transitions or [],
        "invariants": invariants or [],
    }


def _two():
    a = _comp(vars_={"a.x": {"id": "a.x", "type": "bool"}},
              events={"a.e": {"id": "a.e"}},
              transitions=[{"id": "a.t", "from": "READY", "to": "READY"}],
              invariants=[{"id": "a.i", "expr": "true"}],
              scope={"terminal_states": [], "excluded": ["X"]})
    b = _comp(ver="0.5", vars_={"b.y": {"id": "b.y", "type": "bool"}},
              events={"b.e": {"id": "b.e"}},
              transitions=[{"id": "b.t", "from": "READY", "to": "READY"}],
              invariants=[{"id": "b.i", "expr": "true"}],
              scope={"terminal_states": [], "excluded": ["Y"]})
    return a, b


def test_union_basic():
    a, b = _two()
    out = merge_disjoint_components([a, b], "combined")
    assert out["ir_version"] == "0.6"
    assert out["semantics"] == "flat-efsm-atomic-ordered-v1"
    assert out["protocol"] == "combined"
    assert out["states"] == ["READY"]
    assert out["initial_state"] == "READY"
    assert list(out["variables"]) == ["a.x", "b.y"]
    assert list(out["events"]) == ["a.e", "b.e"]
    assert [t["id"] for t in out["transitions"]] == ["a.t", "b.t"]
    assert [i["id"] for i in out["invariants"]] == ["a.i", "b.i"]


def test_version_floor_is_min():
    a = _comp(ver="0.5")
    b = _comp(ver="0.5")
    assert merge_disjoint_components([a, b], "p")["ir_version"] == "0.5"


def test_version_any_06_wins():
    a = _comp(ver="0.5")
    b = _comp(ver="0.6")
    assert merge_disjoint_components([a, b], "p")["ir_version"] == "0.6"


def test_inputs_immutable():
    a, b = _two()
    snap_a = copy.deepcopy(a)
    snap_b = copy.deepcopy(b)
    out = merge_disjoint_components([a, b], "combined")
    assert a == snap_a and b == snap_b
    out["variables"]["a.x"]["type"] = "int"
    assert a["variables"]["a.x"]["type"] == "bool"


def test_scope_preserved():
    a, b = _two()
    out = merge_disjoint_components([a, b], "c")
    assert out["scope"]["terminal_states"] == []
    assert out["scope"]["component_scopes"] == [a["scope"], b["scope"]]


def test_duplicate_key_rejected():
    a = _comp(vars_={"k": {"id": "k"}})
    b = _comp(vars_={"k": {"id": "k"}})
    with pytest.raises(ValueError):
        merge_disjoint_components([a, b], "p")


def test_duplicate_id_rejected():
    a = _comp(transitions=[{"id": "t", "from": "READY", "to": "READY"}])
    b = _comp(transitions=[{"id": "t", "from": "READY", "to": "READY"}])
    with pytest.raises(ValueError):
        merge_disjoint_components([a, b], "p")


def test_terminal_states_rejected():
    a = _comp(scope={"terminal_states": ["DONE"]})
    with pytest.raises(ValueError):
        merge_disjoint_components([a], "p")


def test_state_mismatch_rejected():
    a = _comp()
    b = _comp()
    b["states"] = ["OTHER"]
    b["initial_state"] = "OTHER"
    with pytest.raises(ValueError):
        merge_disjoint_components([a, b], "p")


def test_extra_field_rejected():
    a = _comp()
    a["extends"] = "x"
    with pytest.raises(ValueError):
        merge_disjoint_components([a], "p")


def test_bad_semantics_rejected():
    a = _comp()
    a["semantics"] = "atomic-v1"
    with pytest.raises(ValueError):
        merge_disjoint_components([a], "p")


def test_rational_in_fields_rejected():
    a = _comp(events={"e": {"id": "e", "fields": [{"name": "r", "kind": "rational"}]}})
    with pytest.raises(ValueError):
        merge_disjoint_components([a], "p")


def test_empty_components_rejected():
    with pytest.raises(ValueError):
        merge_disjoint_components([], "p")


def test_empty_protocol_rejected():
    a = _comp()
    with pytest.raises(ValueError):
        merge_disjoint_components([a], "")

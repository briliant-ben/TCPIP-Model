(declare-fun proved_conclusion_0 () Bool)
(declare-fun shared_context () Bool)
(declare-fun proved_conclusion_1 () Bool)
(declare-fun proved_conclusion_2 () Bool)
(declare-fun proved_conclusion_3 () Bool)
(declare-fun proved_conclusion_4 () Bool)
(declare-fun proved_conclusion_5 () Bool)
(declare-fun proved_conclusion_6 () Bool)
(declare-fun proved_conclusion_7 () Bool)
(declare-fun proved_conclusion_8 () Bool)
(declare-fun proved_conclusion_9 () Bool)
(declare-fun proved_conclusion_10 () Bool)
(declare-fun proved_conclusion_11 () Bool)
(declare-fun proved_conclusion_12 () Bool)
(declare-fun proved_conclusion_13 () Bool)
(declare-fun proved_conclusion_14 () Bool)
(declare-fun proved_conclusion_15 () Bool)
(declare-fun proved_conclusion_16 () Bool)
(declare-fun proved_conclusion_17 () Bool)
(declare-fun proved_conclusion_18 () Bool)
(declare-fun proved_conclusion_19 () Bool)
(declare-fun proved_conclusion_20 () Bool)
(declare-fun proved_conclusion_21 () Bool)
(declare-fun proved_conclusion_22 () Bool)
(declare-fun proved_conclusion_23 () Bool)
(declare-fun proved_conclusion_24 () Bool)
(declare-fun proved_conclusion_25 () Bool)
(declare-fun proved_conclusion_26 () Bool)
(declare-fun proved_conclusion_27 () Bool)
(declare-fun proved_conclusion_28 () Bool)
(declare-fun proved_conclusion_29 () Bool)
(declare-fun proved_conclusion_30 () Bool)
(declare-fun proved_conclusion_31 () Bool)
(declare-fun proved_conclusion_32 () Bool)
(declare-fun proved_conclusion_33 () Bool)
(declare-fun proved_conclusion_34 () Bool)
(declare-fun proved_conclusion_35 () Bool)
(declare-fun proved_conclusion_36 () Bool)
(declare-fun proved_conclusion_37 () Bool)
(declare-fun proved_conclusion_38 () Bool)
(declare-fun proved_conclusion_39 () Bool)
(declare-fun proved_conclusion_40 () Bool)
(declare-fun proved_conclusion_41 () Bool)
(declare-fun proved_conclusion_42 () Bool)
(declare-fun proved_conclusion_43 () Bool)
(declare-fun proved_conclusion_44 () Bool)
(declare-fun proved_conclusion_45 () Bool)
(declare-fun proved_conclusion_46 () Bool)
(declare-fun proved_conclusion_47 () Bool)
(declare-fun proved_conclusion_48 () Bool)
(declare-fun proved_conclusion_49 () Bool)
(declare-fun proved_conclusion_50 () Bool)
(declare-fun proved_conclusion_51 () Bool)
(declare-fun proved_conclusion_52 () Bool)
(declare-fun proved_conclusion_53 () Bool)
(declare-fun proved_conclusion_54 () Bool)
(declare-fun proved_conclusion_55 () Bool)
(declare-fun proved_conclusion_56 () Bool)
(declare-fun proved_conclusion_57 () Bool)
(declare-fun proved_conclusion_58 () Bool)
(declare-fun proved_conclusion_59 () Bool)
(declare-fun proved_conclusion_60 () Bool)
(declare-fun proved_conclusion_61 () Bool)
(declare-fun proved_conclusion_62 () Bool)
(declare-fun proved_conclusion_63 () Bool)
(declare-fun proved_conclusion_64 () Bool)
(declare-fun proved_conclusion_65 () Bool)
(declare-fun proved_conclusion_66 () Bool)
(declare-fun proved_conclusion_67 () Bool)
(declare-fun proved_conclusion_68 () Bool)
(declare-fun proved_conclusion_69 () Bool)
(declare-fun proved_conclusion_70 () Bool)
(declare-fun proved_conclusion_71 () Bool)
(declare-fun proved_conclusion_72 () Bool)
(declare-fun proved_conclusion_73 () Bool)
(declare-fun proved_conclusion_74 () Bool)
(declare-fun proved_conclusion_75 () Bool)
(declare-fun proved_conclusion_76 () Bool)
(declare-fun proved_conclusion_77 () Bool)
(declare-fun proved_conclusion_78 () Bool)
(declare-fun proved_conclusion_79 () Bool)
(declare-fun proved_conclusion_80 () Bool)
(declare-fun proved_conclusion_81 () Bool)
(declare-fun proved_conclusion_82 () Bool)
(declare-fun proved_conclusion_83 () Bool)
(declare-fun proved_conclusion_84 () Bool)
(declare-fun proved_conclusion_85 () Bool)
(declare-fun proved_conclusion_86 () Bool)
(declare-fun proved_conclusion_87 () Bool)
(declare-fun proved_conclusion_88 () Bool)
(declare-fun proved_conclusion_89 () Bool)
(declare-fun proved_conclusion_90 () Bool)
(declare-fun proved_conclusion_91 () Bool)
(declare-fun proved_conclusion_92 () Bool)
(declare-fun proved_conclusion_93 () Bool)
(declare-fun proved_conclusion_94 () Bool)
(declare-fun proved_conclusion_95 () Bool)
(declare-fun proved_conclusion_96 () Bool)
(declare-fun proved_conclusion_97 () Bool)
(declare-fun proved_conclusion_98 () Bool)
(declare-fun proved_conclusion_99 () Bool)
(declare-fun proved_conclusion_100 () Bool)
(declare-fun proved_conclusion_101 () Bool)
(declare-fun proved_conclusion_102 () Bool)
(declare-fun proved_conclusion_103 () Bool)
(declare-fun proved_conclusion_104 () Bool)
(declare-fun proved_conclusion_105 () Bool)
(declare-fun proved_conclusion_106 () Bool)
(declare-fun proved_conclusion_107 () Bool)
(declare-fun proved_conclusion_108 () Bool)
(declare-fun proved_conclusion_109 () Bool)
(declare-fun proved_conclusion_110 () Bool)
(declare-fun proved_conclusion_111 () Bool)
(declare-fun proved_conclusion_112 () Bool)
(declare-fun proved_conclusion_113 () Bool)
(declare-fun proved_conclusion_114 () Bool)
(declare-fun proved_conclusion_115 () Bool)
(declare-fun proved_conclusion_116 () Bool)
(declare-fun proved_conclusion_117 () Bool)
(declare-fun proved_conclusion_118 () Bool)
(declare-fun proved_conclusion_119 () Bool)
(declare-fun proved_conclusion_120 () Bool)
(declare-fun proved_conclusion_121 () Bool)
(declare-fun proved_conclusion_122 () Bool)
(declare-fun proved_conclusion_123 () Bool)
(declare-fun proved_conclusion_124 () Bool)
(declare-fun proved_conclusion_125 () Bool)
(declare-fun proved_conclusion_126 () Bool)
(declare-fun proved_conclusion_127 () Bool)
(declare-fun proved_conclusion_128 () Bool)
(declare-fun proved_conclusion_129 () Bool)
(declare-fun proved_conclusion_130 () Bool)
(declare-fun proved_conclusion_131 () Bool)
(declare-fun proved_conclusion_132 () Bool)
(declare-fun proved_conclusion_133 () Bool)
(declare-fun proved_conclusion_134 () Bool)
(declare-fun proved_conclusion_135 () Bool)
(declare-fun proved_conclusion_136 () Bool)
(declare-fun proved_conclusion_137 () Bool)
(declare-fun proved_conclusion_138 () Bool)
(declare-fun proved_conclusion_139 () Bool)
(declare-fun proved_conclusion_140 () Bool)
(declare-fun proved_conclusion_141 () Bool)
(declare-fun proved_conclusion_142 () Bool)
(declare-fun proved_conclusion_143 () Bool)
(declare-fun proved_conclusion_144 () Bool)
(declare-fun proved_conclusion_145 () Bool)
(declare-fun proved_conclusion_146 () Bool)
(declare-fun proved_conclusion_147 () Bool)
(declare-fun proved_conclusion_148 () Bool)
(declare-fun proved_conclusion_149 () Bool)
(declare-fun proved_conclusion_150 () Bool)
(declare-fun proved_conclusion_151 () Bool)
(declare-fun proved_conclusion_152 () Bool)
(declare-fun proved_conclusion_153 () Bool)
(declare-fun proved_conclusion_154 () Bool)
(declare-fun proved_conclusion_155 () Bool)
(declare-fun proved_conclusion_156 () Bool)
(declare-fun proved_conclusion_157 () Bool)
(declare-fun proved_conclusion_158 () Bool)
(declare-fun proved_conclusion_159 () Bool)
(declare-fun proved_conclusion_160 () Bool)
(declare-fun proved_conclusion_161 () Bool)
(declare-fun proved_conclusion_162 () Bool)
(declare-fun proved_conclusion_163 () Bool)
(declare-fun proved_conclusion_164 () Bool)
(declare-fun proved_conclusion_165 () Bool)
(declare-fun proved_conclusion_166 () Bool)
(declare-fun proved_conclusion_167 () Bool)
(declare-fun proved_conclusion_168 () Bool)
(declare-fun proved_conclusion_169 () Bool)
(declare-fun proved_conclusion_170 () Bool)
(declare-fun proved_conclusion_171 () Bool)
(declare-fun proved_conclusion_172 () Bool)
(declare-fun proved_conclusion_173 () Bool)
(declare-fun proved_conclusion_174 () Bool)
(declare-fun proved_conclusion_175 () Bool)
(declare-fun proved_conclusion_176 () Bool)
(declare-fun proved_conclusion_177 () Bool)
(declare-fun proved_conclusion_178 () Bool)
(declare-fun proved_conclusion_179 () Bool)
(declare-fun proved_conclusion_180 () Bool)
(declare-fun proved_conclusion_181 () Bool)
(declare-fun proved_conclusion_182 () Bool)
(declare-fun proved_conclusion_183 () Bool)
(declare-fun proved_conclusion_184 () Bool)
(declare-fun proved_conclusion_185 () Bool)
(declare-fun proved_conclusion_186 () Bool)
(declare-fun proved_conclusion_187 () Bool)
(declare-fun proved_conclusion_188 () Bool)
(declare-fun proved_conclusion_189 () Bool)
(declare-fun proved_conclusion_190 () Bool)
(declare-fun proved_conclusion_191 () Bool)
(declare-fun proved_conclusion_192 () Bool)
(declare-fun proved_conclusion_193 () Bool)
(declare-fun proved_conclusion_194 () Bool)
(declare-fun proved_conclusion_195 () Bool)
(declare-fun proved_conclusion_196 () Bool)
(declare-fun proved_conclusion_197 () Bool)
(declare-fun proved_conclusion_198 () Bool)
(declare-fun proved_conclusion_199 () Bool)
(declare-fun proved_conclusion_200 () Bool)
(declare-fun proved_conclusion_201 () Bool)
(declare-fun proved_conclusion_202 () Bool)
(declare-fun proved_conclusion_203 () Bool)
(declare-fun proved_conclusion_204 () Bool)
(declare-fun proved_conclusion_205 () Bool)
(declare-fun proved_conclusion_206 () Bool)
(declare-fun proved_conclusion_207 () Bool)
(declare-fun proved_conclusion_208 () Bool)
(declare-fun proved_conclusion_209 () Bool)
(declare-fun proved_conclusion_210 () Bool)
(declare-fun proved_conclusion_211 () Bool)
(declare-fun proved_conclusion_212 () Bool)
(declare-fun proved_conclusion_213 () Bool)
(declare-fun proved_conclusion_214 () Bool)
(declare-fun proved_conclusion_215 () Bool)
(declare-fun proved_conclusion_216 () Bool)
(declare-fun proved_conclusion_217 () Bool)
(declare-fun proved_conclusion_218 () Bool)
(declare-fun proved_conclusion_219 () Bool)
(declare-fun proved_conclusion_220 () Bool)
(declare-fun proved_conclusion_221 () Bool)
(declare-fun proved_conclusion_222 () Bool)
(declare-fun proved_conclusion_223 () Bool)
(declare-fun proved_conclusion_224 () Bool)
(declare-fun proved_conclusion_225 () Bool)
(declare-fun proved_conclusion_226 () Bool)
(declare-fun proved_conclusion_227 () Bool)
(declare-fun proved_conclusion_228 () Bool)
(declare-fun proved_conclusion_229 () Bool)
(declare-fun proved_conclusion_230 () Bool)
(declare-fun proved_conclusion_231 () Bool)
(declare-fun proved_conclusion_232 () Bool)
(declare-fun proved_conclusion_233 () Bool)
(declare-fun proved_conclusion_234 () Bool)
(declare-fun proved_conclusion_235 () Bool)
(declare-fun proved_conclusion_236 () Bool)
(declare-fun proved_conclusion_237 () Bool)
(declare-fun proved_conclusion_238 () Bool)
(declare-fun proved_conclusion_239 () Bool)
(declare-fun proved_conclusion_240 () Bool)
(declare-fun proved_conclusion_241 () Bool)
(declare-fun proved_conclusion_242 () Bool)
(declare-fun proved_conclusion_243 () Bool)
(declare-fun proved_conclusion_244 () Bool)
(declare-fun proved_conclusion_245 () Bool)
(declare-fun proved_conclusion_246 () Bool)
(declare-fun proved_conclusion_247 () Bool)
(declare-fun proved_conclusion_248 () Bool)
(declare-fun proved_conclusion_249 () Bool)
(declare-fun proved_conclusion_250 () Bool)
(declare-fun proved_conclusion_251 () Bool)
(declare-fun proved_conclusion_252 () Bool)
(declare-fun proved_conclusion_253 () Bool)
(declare-fun proved_conclusion_254 () Bool)
(declare-fun proved_conclusion_255 () Bool)
(declare-fun proved_conclusion_256 () Bool)
(declare-fun proved_conclusion_257 () Bool)
(declare-fun proved_conclusion_258 () Bool)
(declare-fun proved_conclusion_259 () Bool)
(declare-fun proved_conclusion_260 () Bool)
(declare-fun proved_conclusion_261 () Bool)
(declare-fun proved_conclusion_262 () Bool)
(declare-fun proved_conclusion_263 () Bool)
(declare-fun proved_conclusion_264 () Bool)
(declare-fun proved_conclusion_265 () Bool)
(declare-fun proved_conclusion_266 () Bool)
(declare-fun proved_conclusion_267 () Bool)
(declare-fun proved_conclusion_268 () Bool)
(declare-fun proved_conclusion_269 () Bool)
(declare-fun proved_conclusion_270 () Bool)
(declare-fun proved_conclusion_271 () Bool)
(declare-fun proved_conclusion_272 () Bool)
(declare-fun proved_conclusion_273 () Bool)
(declare-fun proved_conclusion_274 () Bool)
(declare-fun proved_conclusion_275 () Bool)
(declare-fun proved_conclusion_276 () Bool)
(declare-fun proved_conclusion_277 () Bool)
(declare-fun proved_conclusion_278 () Bool)
(declare-fun proved_conclusion_279 () Bool)
(declare-fun proved_conclusion_280 () Bool)
(declare-fun proved_conclusion_281 () Bool)
(declare-fun proved_conclusion_282 () Bool)
(declare-fun proved_conclusion_283 () Bool)
(declare-fun proved_conclusion_284 () Bool)
(declare-fun proved_conclusion_285 () Bool)
(declare-fun proved_conclusion_286 () Bool)
(declare-fun proved_conclusion_287 () Bool)
(declare-fun proved_conclusion_288 () Bool)
(declare-fun proved_conclusion_289 () Bool)
(declare-fun proved_conclusion_290 () Bool)
(declare-fun proved_conclusion_291 () Bool)
(declare-fun proved_conclusion_292 () Bool)
(declare-fun proved_conclusion_293 () Bool)
(declare-fun proved_conclusion_294 () Bool)
(declare-fun proved_conclusion_295 () Bool)
(declare-fun proved_conclusion_296 () Bool)
(declare-fun proved_conclusion_297 () Bool)
(declare-fun proved_conclusion_298 () Bool)
(declare-fun proved_conclusion_299 () Bool)
(declare-fun proved_conclusion_300 () Bool)
(declare-fun proved_conclusion_301 () Bool)
(declare-fun proved_conclusion_302 () Bool)
(declare-fun proved_conclusion_303 () Bool)
(declare-fun proved_conclusion_304 () Bool)
(declare-fun proved_conclusion_305 () Bool)
(declare-fun proved_conclusion_306 () Bool)
(declare-fun proved_conclusion_307 () Bool)
(declare-fun proved_conclusion_308 () Bool)
(declare-fun proved_conclusion_309 () Bool)
(declare-fun proved_conclusion_310 () Bool)
(declare-fun proved_conclusion_311 () Bool)
(declare-fun proved_conclusion_312 () Bool)
(declare-fun proved_conclusion_313 () Bool)
(declare-fun proved_conclusion_314 () Bool)
(declare-fun proved_conclusion_315 () Bool)
(declare-fun proved_conclusion_316 () Bool)
(declare-fun proved_conclusion_317 () Bool)
(declare-fun proved_conclusion_318 () Bool)
(declare-fun proved_conclusion_319 () Bool)
(declare-fun proved_conclusion_320 () Bool)
(declare-fun proved_conclusion_321 () Bool)
(declare-fun proved_conclusion_322 () Bool)
(declare-fun proved_conclusion_323 () Bool)
(declare-fun proved_conclusion_324 () Bool)
(declare-fun proved_conclusion_325 () Bool)
(declare-fun proved_conclusion_326 () Bool)
(declare-fun proved_conclusion_327 () Bool)
(declare-fun proved_conclusion_328 () Bool)
(declare-fun proved_conclusion_329 () Bool)
(declare-fun proved_conclusion_330 () Bool)
(declare-fun proved_conclusion_331 () Bool)
(declare-fun proved_conclusion_332 () Bool)
(declare-fun proved_conclusion_333 () Bool)
(declare-fun proved_conclusion_334 () Bool)
(declare-fun proved_conclusion_335 () Bool)
(declare-fun proved_conclusion_336 () Bool)
(declare-fun proved_conclusion_337 () Bool)
(declare-fun proved_conclusion_338 () Bool)
(declare-fun proved_conclusion_339 () Bool)
(declare-fun proved_conclusion_340 () Bool)
(declare-fun proved_conclusion_341 () Bool)
(declare-fun proved_conclusion_342 () Bool)
(declare-fun proved_conclusion_343 () Bool)
(declare-fun proved_conclusion_344 () Bool)
(declare-fun proved_conclusion_345 () Bool)
(declare-fun proved_conclusion_346 () Bool)
(declare-fun proved_conclusion_347 () Bool)
(declare-fun proved_conclusion_348 () Bool)
(declare-fun proved_conclusion_349 () Bool)
(declare-fun proved_conclusion_350 () Bool)
(declare-fun target_violation () Bool)
(assert (=> shared_context proved_conclusion_0))
(assert (=> shared_context proved_conclusion_1))
(assert (=> shared_context proved_conclusion_2))
(assert (=> shared_context proved_conclusion_3))
(assert (=> shared_context proved_conclusion_4))
(assert (=> shared_context proved_conclusion_5))
(assert (=> shared_context proved_conclusion_6))
(assert (=> shared_context proved_conclusion_7))
(assert (=> shared_context proved_conclusion_8))
(assert (=> shared_context proved_conclusion_9))
(assert (=> shared_context proved_conclusion_10))
(assert (=> shared_context proved_conclusion_11))
(assert (=> shared_context proved_conclusion_12))
(assert (=> shared_context proved_conclusion_13))
(assert (=> shared_context proved_conclusion_14))
(assert (=> shared_context proved_conclusion_15))
(assert (=> shared_context proved_conclusion_16))
(assert (=> shared_context proved_conclusion_17))
(assert (=> shared_context proved_conclusion_18))
(assert (=> shared_context proved_conclusion_19))
(assert (=> shared_context proved_conclusion_20))
(assert (=> shared_context proved_conclusion_21))
(assert (=> shared_context proved_conclusion_22))
(assert (=> shared_context proved_conclusion_23))
(assert (=> shared_context proved_conclusion_24))
(assert (=> shared_context proved_conclusion_25))
(assert (=> shared_context proved_conclusion_26))
(assert (=> shared_context proved_conclusion_27))
(assert (=> shared_context proved_conclusion_28))
(assert (=> shared_context proved_conclusion_29))
(assert (=> shared_context proved_conclusion_30))
(assert (=> shared_context proved_conclusion_31))
(assert (=> shared_context proved_conclusion_32))
(assert (=> shared_context proved_conclusion_33))
(assert (=> shared_context proved_conclusion_34))
(assert (=> shared_context proved_conclusion_35))
(assert (=> shared_context proved_conclusion_36))
(assert (=> shared_context proved_conclusion_37))
(assert (=> shared_context proved_conclusion_38))
(assert (=> shared_context proved_conclusion_39))
(assert (=> shared_context proved_conclusion_40))
(assert (=> shared_context proved_conclusion_41))
(assert (=> shared_context proved_conclusion_42))
(assert (=> shared_context proved_conclusion_43))
(assert (=> shared_context proved_conclusion_44))
(assert (=> shared_context proved_conclusion_45))
(assert (=> shared_context proved_conclusion_46))
(assert (=> shared_context proved_conclusion_47))
(assert (=> shared_context proved_conclusion_48))
(assert (=> shared_context proved_conclusion_49))
(assert (=> shared_context proved_conclusion_50))
(assert (=> shared_context proved_conclusion_51))
(assert (=> shared_context proved_conclusion_52))
(assert (=> shared_context proved_conclusion_53))
(assert (=> shared_context proved_conclusion_54))
(assert (=> shared_context proved_conclusion_55))
(assert (=> shared_context proved_conclusion_56))
(assert (=> shared_context proved_conclusion_57))
(assert (=> shared_context proved_conclusion_58))
(assert (=> shared_context proved_conclusion_59))
(assert (=> shared_context proved_conclusion_60))
(assert (=> shared_context proved_conclusion_61))
(assert (=> shared_context proved_conclusion_62))
(assert (=> shared_context proved_conclusion_63))
(assert (=> shared_context proved_conclusion_64))
(assert (=> shared_context proved_conclusion_65))
(assert (=> shared_context proved_conclusion_66))
(assert (=> shared_context proved_conclusion_67))
(assert (=> shared_context proved_conclusion_68))
(assert (=> shared_context proved_conclusion_69))
(assert (=> shared_context proved_conclusion_70))
(assert (=> shared_context proved_conclusion_71))
(assert (=> shared_context proved_conclusion_72))
(assert (=> shared_context proved_conclusion_73))
(assert (=> shared_context proved_conclusion_74))
(assert (=> shared_context proved_conclusion_75))
(assert (=> shared_context proved_conclusion_76))
(assert (=> shared_context proved_conclusion_77))
(assert (=> shared_context proved_conclusion_78))
(assert (=> shared_context proved_conclusion_79))
(assert (=> shared_context proved_conclusion_80))
(assert (=> shared_context proved_conclusion_81))
(assert (=> shared_context proved_conclusion_82))
(assert (=> shared_context proved_conclusion_83))
(assert (=> shared_context proved_conclusion_84))
(assert (=> shared_context proved_conclusion_85))
(assert (=> shared_context proved_conclusion_86))
(assert (=> shared_context proved_conclusion_87))
(assert (=> shared_context proved_conclusion_88))
(assert (=> shared_context proved_conclusion_89))
(assert (=> shared_context proved_conclusion_90))
(assert (=> shared_context proved_conclusion_91))
(assert (=> shared_context proved_conclusion_92))
(assert (=> shared_context proved_conclusion_93))
(assert (=> shared_context proved_conclusion_94))
(assert (=> shared_context proved_conclusion_95))
(assert (=> shared_context proved_conclusion_96))
(assert (=> shared_context proved_conclusion_97))
(assert (=> shared_context proved_conclusion_98))
(assert (=> shared_context proved_conclusion_99))
(assert (=> shared_context proved_conclusion_100))
(assert (=> shared_context proved_conclusion_101))
(assert (=> shared_context proved_conclusion_102))
(assert (=> shared_context proved_conclusion_103))
(assert (=> shared_context proved_conclusion_104))
(assert (=> shared_context proved_conclusion_105))
(assert (=> shared_context proved_conclusion_106))
(assert (=> shared_context proved_conclusion_107))
(assert (=> shared_context proved_conclusion_108))
(assert (=> shared_context proved_conclusion_109))
(assert (=> shared_context proved_conclusion_110))
(assert (=> shared_context proved_conclusion_111))
(assert (=> shared_context proved_conclusion_112))
(assert (=> shared_context proved_conclusion_113))
(assert (=> shared_context proved_conclusion_114))
(assert (=> shared_context proved_conclusion_115))
(assert (=> shared_context proved_conclusion_116))
(assert (=> shared_context proved_conclusion_117))
(assert (=> shared_context proved_conclusion_118))
(assert (=> shared_context proved_conclusion_119))
(assert (=> shared_context proved_conclusion_120))
(assert (=> shared_context proved_conclusion_121))
(assert (=> shared_context proved_conclusion_122))
(assert (=> shared_context proved_conclusion_123))
(assert (=> shared_context proved_conclusion_124))
(assert (=> shared_context proved_conclusion_125))
(assert (=> shared_context proved_conclusion_126))
(assert (=> shared_context proved_conclusion_127))
(assert (=> shared_context proved_conclusion_128))
(assert (=> shared_context proved_conclusion_129))
(assert (=> shared_context proved_conclusion_130))
(assert (=> shared_context proved_conclusion_131))
(assert (=> shared_context proved_conclusion_132))
(assert (=> shared_context proved_conclusion_133))
(assert (=> shared_context proved_conclusion_134))
(assert (=> shared_context proved_conclusion_135))
(assert (=> shared_context proved_conclusion_136))
(assert (=> shared_context proved_conclusion_137))
(assert (=> shared_context proved_conclusion_138))
(assert (=> shared_context proved_conclusion_139))
(assert (=> shared_context proved_conclusion_140))
(assert (=> shared_context proved_conclusion_141))
(assert (=> shared_context proved_conclusion_142))
(assert (=> shared_context proved_conclusion_143))
(assert (=> shared_context proved_conclusion_144))
(assert (=> shared_context proved_conclusion_145))
(assert (=> shared_context proved_conclusion_146))
(assert (=> shared_context proved_conclusion_147))
(assert (=> shared_context proved_conclusion_148))
(assert (=> shared_context proved_conclusion_149))
(assert (=> shared_context proved_conclusion_150))
(assert (=> shared_context proved_conclusion_151))
(assert (=> shared_context proved_conclusion_152))
(assert (=> shared_context proved_conclusion_153))
(assert (=> shared_context proved_conclusion_154))
(assert (=> shared_context proved_conclusion_155))
(assert (=> shared_context proved_conclusion_156))
(assert (=> shared_context proved_conclusion_157))
(assert (=> shared_context proved_conclusion_158))
(assert (=> shared_context proved_conclusion_159))
(assert (=> shared_context proved_conclusion_160))
(assert (=> shared_context proved_conclusion_161))
(assert (=> shared_context proved_conclusion_162))
(assert (=> shared_context proved_conclusion_163))
(assert (=> shared_context proved_conclusion_164))
(assert (=> shared_context proved_conclusion_165))
(assert (=> shared_context proved_conclusion_166))
(assert (=> shared_context proved_conclusion_167))
(assert (=> shared_context proved_conclusion_168))
(assert (=> shared_context proved_conclusion_169))
(assert (=> shared_context proved_conclusion_170))
(assert (=> shared_context proved_conclusion_171))
(assert (=> shared_context proved_conclusion_172))
(assert (=> shared_context proved_conclusion_173))
(assert (=> shared_context proved_conclusion_174))
(assert (=> shared_context proved_conclusion_175))
(assert (=> shared_context proved_conclusion_176))
(assert (=> shared_context proved_conclusion_177))
(assert (=> shared_context proved_conclusion_178))
(assert (=> shared_context proved_conclusion_179))
(assert (=> shared_context proved_conclusion_180))
(assert (=> shared_context proved_conclusion_181))
(assert (=> shared_context proved_conclusion_182))
(assert (=> shared_context proved_conclusion_183))
(assert (=> shared_context proved_conclusion_184))
(assert (=> shared_context proved_conclusion_185))
(assert (=> shared_context proved_conclusion_186))
(assert (=> shared_context proved_conclusion_187))
(assert (=> shared_context proved_conclusion_188))
(assert (=> shared_context proved_conclusion_189))
(assert (=> shared_context proved_conclusion_190))
(assert (=> shared_context proved_conclusion_191))
(assert (=> shared_context proved_conclusion_192))
(assert (=> shared_context proved_conclusion_193))
(assert (=> shared_context proved_conclusion_194))
(assert (=> shared_context proved_conclusion_195))
(assert (=> shared_context proved_conclusion_196))
(assert (=> shared_context proved_conclusion_197))
(assert (=> shared_context proved_conclusion_198))
(assert (=> shared_context proved_conclusion_199))
(assert (=> shared_context proved_conclusion_200))
(assert (=> shared_context proved_conclusion_201))
(assert (=> shared_context proved_conclusion_202))
(assert (=> shared_context proved_conclusion_203))
(assert (=> shared_context proved_conclusion_204))
(assert (=> shared_context proved_conclusion_205))
(assert (=> shared_context proved_conclusion_206))
(assert (=> shared_context proved_conclusion_207))
(assert (=> shared_context proved_conclusion_208))
(assert (=> shared_context proved_conclusion_209))
(assert (=> shared_context proved_conclusion_210))
(assert (=> shared_context proved_conclusion_211))
(assert (=> shared_context proved_conclusion_212))
(assert (=> shared_context proved_conclusion_213))
(assert (=> shared_context proved_conclusion_214))
(assert (=> shared_context proved_conclusion_215))
(assert (=> shared_context proved_conclusion_216))
(assert (=> shared_context proved_conclusion_217))
(assert (=> shared_context proved_conclusion_218))
(assert (=> shared_context proved_conclusion_219))
(assert (=> shared_context proved_conclusion_220))
(assert (=> shared_context proved_conclusion_221))
(assert (=> shared_context proved_conclusion_222))
(assert (=> shared_context proved_conclusion_223))
(assert (=> shared_context proved_conclusion_224))
(assert (=> shared_context proved_conclusion_225))
(assert (=> shared_context proved_conclusion_226))
(assert (=> shared_context proved_conclusion_227))
(assert (=> shared_context proved_conclusion_228))
(assert (=> shared_context proved_conclusion_229))
(assert (=> shared_context proved_conclusion_230))
(assert (=> shared_context proved_conclusion_231))
(assert (=> shared_context proved_conclusion_232))
(assert (=> shared_context proved_conclusion_233))
(assert (=> shared_context proved_conclusion_234))
(assert (=> shared_context proved_conclusion_235))
(assert (=> shared_context proved_conclusion_236))
(assert (=> shared_context proved_conclusion_237))
(assert (=> shared_context proved_conclusion_238))
(assert (=> shared_context proved_conclusion_239))
(assert (=> shared_context proved_conclusion_240))
(assert (=> shared_context proved_conclusion_241))
(assert (=> shared_context proved_conclusion_242))
(assert (=> shared_context proved_conclusion_243))
(assert (=> shared_context proved_conclusion_244))
(assert (=> shared_context proved_conclusion_245))
(assert (=> shared_context proved_conclusion_246))
(assert (=> shared_context proved_conclusion_247))
(assert (=> shared_context proved_conclusion_248))
(assert (=> shared_context proved_conclusion_249))
(assert (=> shared_context proved_conclusion_250))
(assert (=> shared_context proved_conclusion_251))
(assert (=> shared_context proved_conclusion_252))
(assert (=> shared_context proved_conclusion_253))
(assert (=> shared_context proved_conclusion_254))
(assert (=> shared_context proved_conclusion_255))
(assert (=> shared_context proved_conclusion_256))
(assert (=> shared_context proved_conclusion_257))
(assert (=> shared_context proved_conclusion_258))
(assert (=> shared_context proved_conclusion_259))
(assert (=> shared_context proved_conclusion_260))
(assert (=> shared_context proved_conclusion_261))
(assert (=> shared_context proved_conclusion_262))
(assert (=> shared_context proved_conclusion_263))
(assert (=> shared_context proved_conclusion_264))
(assert (=> shared_context proved_conclusion_265))
(assert (=> shared_context proved_conclusion_266))
(assert (=> shared_context proved_conclusion_267))
(assert (=> shared_context proved_conclusion_268))
(assert (=> shared_context proved_conclusion_269))
(assert (=> shared_context proved_conclusion_270))
(assert (=> shared_context proved_conclusion_271))
(assert (=> shared_context proved_conclusion_272))
(assert (=> shared_context proved_conclusion_273))
(assert (=> shared_context proved_conclusion_274))
(assert (=> shared_context proved_conclusion_275))
(assert (=> shared_context proved_conclusion_276))
(assert (=> shared_context proved_conclusion_277))
(assert (=> shared_context proved_conclusion_278))
(assert (=> shared_context proved_conclusion_279))
(assert (=> shared_context proved_conclusion_280))
(assert (=> shared_context proved_conclusion_281))
(assert (=> shared_context proved_conclusion_282))
(assert (=> shared_context proved_conclusion_283))
(assert (=> shared_context proved_conclusion_284))
(assert (=> shared_context proved_conclusion_285))
(assert (=> shared_context proved_conclusion_286))
(assert (=> shared_context proved_conclusion_287))
(assert (=> shared_context proved_conclusion_288))
(assert (=> shared_context proved_conclusion_289))
(assert (=> shared_context proved_conclusion_290))
(assert (=> shared_context proved_conclusion_291))
(assert (=> shared_context proved_conclusion_292))
(assert (=> shared_context proved_conclusion_293))
(assert (=> shared_context proved_conclusion_294))
(assert (=> shared_context proved_conclusion_295))
(assert (=> shared_context proved_conclusion_296))
(assert (=> shared_context proved_conclusion_297))
(assert (=> shared_context proved_conclusion_298))
(assert (=> shared_context proved_conclusion_299))
(assert (=> shared_context proved_conclusion_300))
(assert (=> shared_context proved_conclusion_301))
(assert (=> shared_context proved_conclusion_302))
(assert (=> shared_context proved_conclusion_303))
(assert (=> shared_context proved_conclusion_304))
(assert (=> shared_context proved_conclusion_305))
(assert (=> shared_context proved_conclusion_306))
(assert (=> shared_context proved_conclusion_307))
(assert (=> shared_context proved_conclusion_308))
(assert (=> shared_context proved_conclusion_309))
(assert (=> shared_context proved_conclusion_310))
(assert (=> shared_context proved_conclusion_311))
(assert (=> shared_context proved_conclusion_312))
(assert (=> shared_context proved_conclusion_313))
(assert (=> shared_context proved_conclusion_314))
(assert (=> shared_context proved_conclusion_315))
(assert (=> shared_context proved_conclusion_316))
(assert (=> shared_context proved_conclusion_317))
(assert (=> shared_context proved_conclusion_318))
(assert (=> shared_context proved_conclusion_319))
(assert (=> shared_context proved_conclusion_320))
(assert (=> shared_context proved_conclusion_321))
(assert (=> shared_context proved_conclusion_322))
(assert (=> shared_context proved_conclusion_323))
(assert (=> shared_context proved_conclusion_324))
(assert (=> shared_context proved_conclusion_325))
(assert (=> shared_context proved_conclusion_326))
(assert (=> shared_context proved_conclusion_327))
(assert (=> shared_context proved_conclusion_328))
(assert (=> shared_context proved_conclusion_329))
(assert (=> shared_context proved_conclusion_330))
(assert (=> shared_context proved_conclusion_331))
(assert (=> shared_context proved_conclusion_332))
(assert (=> shared_context proved_conclusion_333))
(assert (=> shared_context proved_conclusion_334))
(assert (=> shared_context proved_conclusion_335))
(assert (=> shared_context proved_conclusion_336))
(assert (=> shared_context proved_conclusion_337))
(assert (=> shared_context proved_conclusion_338))
(assert (=> shared_context proved_conclusion_339))
(assert (=> shared_context proved_conclusion_340))
(assert (=> shared_context proved_conclusion_341))
(assert (=> shared_context proved_conclusion_342))
(assert (=> shared_context proved_conclusion_343))
(assert (=> shared_context proved_conclusion_344))
(assert (=> shared_context proved_conclusion_345))
(assert (=> shared_context proved_conclusion_346))
(assert (=> shared_context proved_conclusion_347))
(assert (=> shared_context proved_conclusion_348))
(assert (=> shared_context proved_conclusion_349))
(assert (=> shared_context proved_conclusion_350))
(assert (not (and shared_context
          target_violation
          proved_conclusion_0
          proved_conclusion_1
          proved_conclusion_2
          proved_conclusion_3
          proved_conclusion_4
          proved_conclusion_5
          proved_conclusion_6
          proved_conclusion_7
          proved_conclusion_8
          proved_conclusion_9
          proved_conclusion_10
          proved_conclusion_11
          proved_conclusion_12
          proved_conclusion_13
          proved_conclusion_14
          proved_conclusion_15
          proved_conclusion_16
          proved_conclusion_17
          proved_conclusion_18
          proved_conclusion_19
          proved_conclusion_20
          proved_conclusion_21
          proved_conclusion_22
          proved_conclusion_23
          proved_conclusion_24
          proved_conclusion_25
          proved_conclusion_26
          proved_conclusion_27
          proved_conclusion_28
          proved_conclusion_29
          proved_conclusion_30
          proved_conclusion_31
          proved_conclusion_32
          proved_conclusion_33
          proved_conclusion_34
          proved_conclusion_35
          proved_conclusion_36
          proved_conclusion_37
          proved_conclusion_38
          proved_conclusion_39
          proved_conclusion_40
          proved_conclusion_41
          proved_conclusion_42
          proved_conclusion_43
          proved_conclusion_44
          proved_conclusion_45
          proved_conclusion_46
          proved_conclusion_47
          proved_conclusion_48
          proved_conclusion_49
          proved_conclusion_50
          proved_conclusion_51
          proved_conclusion_52
          proved_conclusion_53
          proved_conclusion_54
          proved_conclusion_55
          proved_conclusion_56
          proved_conclusion_57
          proved_conclusion_58
          proved_conclusion_59
          proved_conclusion_60
          proved_conclusion_61
          proved_conclusion_62
          proved_conclusion_63
          proved_conclusion_64
          proved_conclusion_65
          proved_conclusion_66
          proved_conclusion_67
          proved_conclusion_68
          proved_conclusion_69
          proved_conclusion_70
          proved_conclusion_71
          proved_conclusion_72
          proved_conclusion_73
          proved_conclusion_74
          proved_conclusion_75
          proved_conclusion_76
          proved_conclusion_77
          proved_conclusion_78
          proved_conclusion_79
          proved_conclusion_80
          proved_conclusion_81
          proved_conclusion_82
          proved_conclusion_83
          proved_conclusion_84
          proved_conclusion_85
          proved_conclusion_86
          proved_conclusion_87
          proved_conclusion_88
          proved_conclusion_89
          proved_conclusion_90
          proved_conclusion_91
          proved_conclusion_92
          proved_conclusion_93
          proved_conclusion_94
          proved_conclusion_95
          proved_conclusion_96
          proved_conclusion_97
          proved_conclusion_98
          proved_conclusion_99
          proved_conclusion_100
          proved_conclusion_101
          proved_conclusion_102
          proved_conclusion_103
          proved_conclusion_104
          proved_conclusion_105
          proved_conclusion_106
          proved_conclusion_107
          proved_conclusion_108
          proved_conclusion_109
          proved_conclusion_110
          proved_conclusion_111
          proved_conclusion_112
          proved_conclusion_113
          proved_conclusion_114
          proved_conclusion_115
          proved_conclusion_116
          proved_conclusion_117
          proved_conclusion_118
          proved_conclusion_119
          proved_conclusion_120
          proved_conclusion_121
          proved_conclusion_122
          proved_conclusion_123
          proved_conclusion_124
          proved_conclusion_125
          proved_conclusion_126
          proved_conclusion_127
          proved_conclusion_128
          proved_conclusion_129
          proved_conclusion_130
          proved_conclusion_131
          proved_conclusion_132
          proved_conclusion_133
          proved_conclusion_134
          proved_conclusion_135
          proved_conclusion_136
          proved_conclusion_137
          proved_conclusion_138
          proved_conclusion_139
          proved_conclusion_140
          proved_conclusion_141
          proved_conclusion_142
          proved_conclusion_143
          proved_conclusion_144
          proved_conclusion_145
          proved_conclusion_146
          proved_conclusion_147
          proved_conclusion_148
          proved_conclusion_149
          proved_conclusion_150
          proved_conclusion_151
          proved_conclusion_152
          proved_conclusion_153
          proved_conclusion_154
          proved_conclusion_155
          proved_conclusion_156
          proved_conclusion_157
          proved_conclusion_158
          proved_conclusion_159
          proved_conclusion_160
          proved_conclusion_161
          proved_conclusion_162
          proved_conclusion_163
          proved_conclusion_164
          proved_conclusion_165
          proved_conclusion_166
          proved_conclusion_167
          proved_conclusion_168
          proved_conclusion_169
          proved_conclusion_170
          proved_conclusion_171
          proved_conclusion_172
          proved_conclusion_173
          proved_conclusion_174
          proved_conclusion_175
          proved_conclusion_176
          proved_conclusion_177
          proved_conclusion_178
          proved_conclusion_179
          proved_conclusion_180
          proved_conclusion_181
          proved_conclusion_182
          proved_conclusion_183
          proved_conclusion_184
          proved_conclusion_185
          proved_conclusion_186
          proved_conclusion_187
          proved_conclusion_188
          proved_conclusion_189
          proved_conclusion_190
          proved_conclusion_191
          proved_conclusion_192
          proved_conclusion_193
          proved_conclusion_194
          proved_conclusion_195
          proved_conclusion_196
          proved_conclusion_197
          proved_conclusion_198
          proved_conclusion_199
          proved_conclusion_200
          proved_conclusion_201
          proved_conclusion_202
          proved_conclusion_203
          proved_conclusion_204
          proved_conclusion_205
          proved_conclusion_206
          proved_conclusion_207
          proved_conclusion_208
          proved_conclusion_209
          proved_conclusion_210
          proved_conclusion_211
          proved_conclusion_212
          proved_conclusion_213
          proved_conclusion_214
          proved_conclusion_215
          proved_conclusion_216
          proved_conclusion_217
          proved_conclusion_218
          proved_conclusion_219
          proved_conclusion_220
          proved_conclusion_221
          proved_conclusion_222
          proved_conclusion_223
          proved_conclusion_224
          proved_conclusion_225
          proved_conclusion_226
          proved_conclusion_227
          proved_conclusion_228
          proved_conclusion_229
          proved_conclusion_230
          proved_conclusion_231
          proved_conclusion_232
          proved_conclusion_233
          proved_conclusion_234
          proved_conclusion_235
          proved_conclusion_236
          proved_conclusion_237
          proved_conclusion_238
          proved_conclusion_239
          proved_conclusion_240
          proved_conclusion_241
          proved_conclusion_242
          proved_conclusion_243
          proved_conclusion_244
          proved_conclusion_245
          proved_conclusion_246
          proved_conclusion_247
          proved_conclusion_248
          proved_conclusion_249
          proved_conclusion_250
          proved_conclusion_251
          proved_conclusion_252
          proved_conclusion_253
          proved_conclusion_254
          proved_conclusion_255
          proved_conclusion_256
          proved_conclusion_257
          proved_conclusion_258
          proved_conclusion_259
          proved_conclusion_260
          proved_conclusion_261
          proved_conclusion_262
          proved_conclusion_263
          proved_conclusion_264
          proved_conclusion_265
          proved_conclusion_266
          proved_conclusion_267
          proved_conclusion_268
          proved_conclusion_269
          proved_conclusion_270
          proved_conclusion_271
          proved_conclusion_272
          proved_conclusion_273
          proved_conclusion_274
          proved_conclusion_275
          proved_conclusion_276
          proved_conclusion_277
          proved_conclusion_278
          proved_conclusion_279
          proved_conclusion_280
          proved_conclusion_281
          proved_conclusion_282
          proved_conclusion_283
          proved_conclusion_284
          proved_conclusion_285
          proved_conclusion_286
          proved_conclusion_287
          proved_conclusion_288
          proved_conclusion_289
          proved_conclusion_290
          proved_conclusion_291
          proved_conclusion_292
          proved_conclusion_293
          proved_conclusion_294
          proved_conclusion_295
          proved_conclusion_296
          proved_conclusion_297
          proved_conclusion_298
          proved_conclusion_299
          proved_conclusion_300
          proved_conclusion_301
          proved_conclusion_302
          proved_conclusion_303
          proved_conclusion_304
          proved_conclusion_305
          proved_conclusion_306
          proved_conclusion_307
          proved_conclusion_308
          proved_conclusion_309
          proved_conclusion_310
          proved_conclusion_311
          proved_conclusion_312
          proved_conclusion_313
          proved_conclusion_314
          proved_conclusion_315
          proved_conclusion_316
          proved_conclusion_317
          proved_conclusion_318
          proved_conclusion_319
          proved_conclusion_320
          proved_conclusion_321
          proved_conclusion_322
          proved_conclusion_323
          proved_conclusion_324
          proved_conclusion_325
          proved_conclusion_326
          proved_conclusion_327
          proved_conclusion_328
          proved_conclusion_329
          proved_conclusion_330
          proved_conclusion_331
          proved_conclusion_332
          proved_conclusion_333
          proved_conclusion_334
          proved_conclusion_335
          proved_conclusion_336
          proved_conclusion_337
          proved_conclusion_338
          proved_conclusion_339
          proved_conclusion_340
          proved_conclusion_341
          proved_conclusion_342
          proved_conclusion_343
          proved_conclusion_344
          proved_conclusion_345
          proved_conclusion_346
          proved_conclusion_347
          proved_conclusion_348
          proved_conclusion_349
          proved_conclusion_350)))
(assert shared_context)
(assert target_violation)
(check-sat)

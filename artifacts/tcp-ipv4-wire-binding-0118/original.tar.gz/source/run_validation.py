import sys,unittest
def deny(event,args):
 if event in ('subprocess.Popen','os.system','os.posix_spawn','socket.__new__','socket.connect','socket.bind','fcntl.ioctl','ctypes.dlopen'):raise RuntimeError('Actual host I/O forbidden: '+event)
 if event=='open' and str(args[0]).startswith('/dev/'):raise RuntimeError('Device open forbidden')
sys.addaudithook(deny)
s=unittest.TestSuite()
for p in ['test_linux_tcp_ipv4_probe.py', 'test_tcp_ipv4_probe_lifecycle.py', 'test_support.py', 'test_controller_contracts.py', 'test_real_tcpdump_log.py', 'test_malformed_singular_stats.py', 'test_tcp_ipv4_capture_contract.py']:s.addTests(unittest.defaultTestLoader.discover('tests',pattern=p))
r=unittest.TextTestRunner(verbosity=2).run(s);sys.exit(0 if r.wasSuccessful() else 1)

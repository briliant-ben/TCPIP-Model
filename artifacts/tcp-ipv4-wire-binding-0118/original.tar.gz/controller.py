from pathlib import Path
import json,hashlib,os,shutil,tarfile,subprocess,sys,time,traceback,resource,re
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-wire-binding-validation-20261108-0118';O.mkdir(exist_ok=False);PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python';BASE=P/'candidates/tcp-probe-category-qualification-20261108-0117/workspace'
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request

def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def status(**x):save('status.json',dict(pid=os.getpid(),production_modified=False,network_executed=False,prototype_complete=False,automatic_API_retry=False,**x))
try:
 status(status='running',stage='actual_namespace_binding_regressions',started_at=time.time());a=P/'incoming/tcp-wire-binding-0118.tar';assert hashlib.sha256(a.read_bytes()).hexdigest()=='56fd21aa950aeec0b9624b3e05a5b99f9ac344c819bd7853982e6bfb33c5b5e1';W=O/'workspace';shutil.copytree(BASE,W,ignore=shutil.ignore_patterns('__pycache__'))
 names={'ports/linux-tcp-ipv4-peer/probe.py','ports/tcp_ipv4_probe_support.py','tests/test_linux_tcp_ipv4_probe.py','tests/test_tcp_ipv4_probe_lifecycle.py','tests/test_tcp_ipv4_capture_contract.py','wire-binding.json'}
 with tarfile.open(a)as t:
  assert{m.name for m in t}==names
  for m in t:assert m.isfile();(W/m.name).write_bytes(t.extractfile(m).read())
 (W/'support.py').write_bytes((W/'ports/tcp_ipv4_probe_support.py').read_bytes());meta=json.loads((W/'wire-binding.json').read_text());assert meta['declared_messages']['L.ethernet.tx']==dict(fields=dict(frame='bytes'))
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
 with(O/'tests.log').open('w')as log:cp=subprocess.run([str(PY),'-B',str(W/'run_validation.py')],cwd=W,stdout=log,stderr=subprocess.STDOUT,timeout=45,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 text=(O/'tests.log').read_text();count=int(re.search(r'Ran (\d+) tests',text).group(1));save('test-result.json',dict(returncode=cp.returncode,methods=count,source_tar_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),actual_metadata=meta,host_IO_forbidden=True));assert cp.returncode==0 and count==94
 status(status='running',stage='independent_review_with_actual_IR_and_native_message_schema')
 data=dict(audit_questions=['Original liveLinux run failedzeroARP because driver matched ethernet.tx but actualIR/C emitted L.ethernet.tx. Originalfailure retained, notmodelgap/RFCbug.', 'Generic helper now has explicitwire_message argument defaultethernet.tx preserved, driver selects exact L.ethernet.tx andvalidatesIRfieldsframebytes BEFORE linkmutation. No alias guessing, packetrewrite orprotocoldecision introduced.', 'Actual94methods including qualifiedwire forwarding/servicepreservation andpartialwritefault pass. Review transportbinding against suppliedactualIRmetadata andnativeemission. Original0captured remainsinvalid.', 'No fullpeer/compiler/model/unboundedclaim. Capture/source/cleanup gates unchanged.'],source={n:(W/n).read_text()for n in names if n.endswith('.py')},actual_IR_native_schema=meta,actual_test_log=text,required_output=dict(blocking=[],findings=[],limitations=[]));ms=[dict(role='system',content='Independent source reviewer. ONLY blocking/findings/limitations arrays, NEVERfiles/patches. Judge actualprovidedIRschema not guessedunqualifiednames. No fabricated execution.'),dict(role='user',content=json.dumps(data))];assert len(json.dumps(ms).encode())<96000;save('review-messages.json',ms)
 r=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=12288,thinking='enabled',reasoning_effort='low',timeout=600);review=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response'];save('review-response.json',review);save('review-usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']});assert isinstance(review,dict)and set(review)=={'blocking','findings','limitations'}and all(isinstance(v,list)for v in review.values())
 status(status='review_findings'if review['blocking']else'wire_binding_source_ready_controller_integration',stage='finished',methods=count,review=review,finished_at=time.time())
except Exception as e:
 status(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__,error=str(e),finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

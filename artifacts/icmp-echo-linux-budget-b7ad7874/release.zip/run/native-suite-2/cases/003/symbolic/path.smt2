; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x926 (= due_1_cache 60000)))
 (let (($x1263 (= due_1_query due_0_query)))
 (let (($x925 (not active_1_query)))
 (let (($x423 (= v_1_cache_ttl_ms 60000)))
 (let (($x1257 (= 0 v_1_retry_count)))
 (let ((?x1019 (seq.unit (_ bv0 8))))
 (let ((?x465 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.unit (_ bv2 8))))))))
 (let ((?x1067 (seq.unit (_ bv2 8))))
 (let (($x1232 (= v_1_peer_mac (seq.++ ?x1067 ?x465))))
 (let (($x1255 (= 2 state_1)))
 (let (($x1065 (not active_0_cache)))
 (let (($x1231 (or $x1065 (not (<= due_0_cache 0)))))
 (let (($x633 (not active_0_query)))
 (let (($x74 (or $x633 (not (<= due_0_query 0)))))
 (let (($x421 (= state_0 0)))
 (and $x421 (>= 0 now_0) $x74 $x1231 $x1255 $x1232 $x1257 $x423 $x925 active_1_cache $x1263 $x926)))))))))))))))))
(assert
 true)
(assert
 (let (($x841 (= due_2_query due_1_query)))
 (let (($x839 (= active_2_query active_1_query)))
 (let (($x838 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x837 (= v_2_retry_count v_1_retry_count)))
 (let ((?x1019 (seq.unit (_ bv0 8))))
 (let ((?x318 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.unit (_ bv3 8))))))))
 (let ((?x1067 (seq.unit (_ bv2 8))))
 (let (($x169 (= v_2_peer_mac (seq.++ ?x1067 ?x318))))
 (let (($x836 (= 2 state_2)))
 (let (($x1009 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x925 (not active_1_query)))
 (let (($x1163 (or $x925 (not (<= due_1_query 10)))))
 (let (($x11 (= state_1 2)))
 (and $x11 $x1163 $x1009 $x836 $x169 $x837 $x838 $x839 active_2_cache $x841 (= due_2_cache (+ 10 v_1_cache_ttl_ms)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1101 (= due_3_cache due_2_cache)))
 (let (($x312 (= due_3_query due_2_query)))
 (let (($x316 (= active_3_cache active_2_cache)))
 (let (($x1096 (= active_3_query active_2_query)))
 (let (($x233 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x232 (= v_3_retry_count v_2_retry_count)))
 (let (($x171 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x166 (= 2 state_3)))
 (let (($x1042 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x1038 (or (not active_2_query) (not (<= due_2_query 20)))))
 (let (($x809 (= state_2 2)))
 (and $x809 $x1038 $x1042 $x166 $x171 $x232 $x233 $x1096 $x316 $x312 $x1101)))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x834 (seq.unit (_ bv192 8))))
 (let ((?x964 (seq.++ ?x834 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x1019 (seq.unit (_ bv0 8))))
 (let ((?x615 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 ?x964)))))))
 (let ((?x1067 (seq.unit (_ bv2 8))))
 (let ((?x235 (seq.++ ?x834 (seq.++ ?x1019 (seq.++ ?x1067 (seq.++ ?x1067 (seq.++ ?x1019 ?x615)))))))
 (let ((?x9 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1067 ?x235)))))))
 (let ((?x951 (seq.unit (_ bv1 8))))
 (let ((?x547 (seq.unit (_ bv4 8))))
 (let ((?x352 (seq.unit (_ bv6 8))))
 (let ((?x243 (seq.++ ?x352 (seq.++ ?x547 (seq.++ ?x1019 (seq.++ ?x951 (seq.++ ?x1067 ?x9)))))))
 (let ((?x827 (seq.unit (_ bv8 8))))
 (let ((?x619 (seq.++ ?x352 (seq.++ ?x1019 (seq.++ ?x951 (seq.++ ?x827 (seq.++ ?x1019 ?x243)))))))
 (let ((?x43 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1067 (seq.++ ?x827 ?x619)))))))
 (let ((?x24 (seq.unit (_ bv255 8))))
 (let ((?x20 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x1067 (seq.++ ?x1019 ?x43)))))))
 (let ((?x875 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x24 ?x20)))))
 (= input_0_net.frame_frame ?x875)))))))))))))))))))
(assert
 (= 20 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x834 (seq.unit (_ bv192 8))))
 (let ((?x248 (seq.++ ?x834 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x1019 (seq.unit (_ bv0 8))))
 (let ((?x565 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 ?x248)))))))
 (let ((?x1067 (seq.unit (_ bv2 8))))
 (let ((?x596 (seq.++ ?x834 (seq.++ ?x1019 (seq.++ ?x1067 (seq.++ ?x1067 (seq.++ ?x1019 ?x565)))))))
 (let ((?x687 (seq.unit (_ bv3 8))))
 (let ((?x737 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x687 ?x596)))))))
 (let ((?x951 (seq.unit (_ bv1 8))))
 (let ((?x547 (seq.unit (_ bv4 8))))
 (let ((?x352 (seq.unit (_ bv6 8))))
 (let ((?x497 (seq.++ ?x352 (seq.++ ?x547 (seq.++ ?x1019 (seq.++ ?x951 (seq.++ ?x1067 ?x737)))))))
 (let ((?x827 (seq.unit (_ bv8 8))))
 (let ((?x411 (seq.++ ?x352 (seq.++ ?x1019 (seq.++ ?x951 (seq.++ ?x827 (seq.++ ?x1019 ?x497)))))))
 (let ((?x1193 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x1019 (seq.++ ?x687 (seq.++ ?x827 ?x411)))))))
 (let ((?x24 (seq.unit (_ bv255 8))))
 (let ((?x1168 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x1067 (seq.++ ?x1019 ?x1193)))))))
 (let ((?x1044 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x24 ?x1168)))))
 (= input_1_net.frame_frame ?x1044))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x834 (seq.unit (_ bv192 8))))
(let ((?x1045 (seq.++ ?x834 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x1045))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x106 (= due_1_cache due_0_cache)))
 (let (($x682 (= due_1_query 1000)))
 (let (($x775 (= active_1_cache active_0_cache)))
 (let (($x943 (= v_1_cache_ttl_ms 60000)))
 (let (($x543 (= 0 v_1_retry_count)))
 (let (($x1087 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1194 (= 1 state_1)))
 (let (($x1097 (not active_0_cache)))
 (let (($x1273 (or $x1097 (not (<= due_0_cache 0)))))
 (let (($x260 (not active_0_query)))
 (let (($x563 (or $x260 (not (<= due_0_query 0)))))
 (let (($x226 (= state_0 0)))
 (and $x226 (>= 0 now_0) $x563 $x1273 $x1194 $x1087 $x543 $x943 active_1_query $x775 $x682 $x106))))))))))))))
(assert
 true)
(assert
 (let (($x500 (= due_2_query due_1_query)))
 (let (($x1230 (not active_2_query)))
 (let (($x1185 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x735 (= 0 v_2_retry_count)))
 (let ((?x949 (seq.unit (_ bv0 8))))
 (let ((?x115 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.unit (_ bv2 8))))))))
 (let ((?x691 (seq.unit (_ bv2 8))))
 (let (($x1229 (= v_2_peer_mac (seq.++ ?x691 ?x115))))
 (let (($x304 (= 2 state_2)))
 (let (($x54 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x12 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x242 (= state_1 1)))
 (and $x242 $x12 $x54 $x304 $x1229 $x735 $x1185 $x1230 active_2_cache $x500 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x1255 (= due_3_cache due_2_cache)))
 (let (($x421 (= due_3_query due_2_query)))
 (let (($x273 (= active_3_cache active_2_cache)))
 (let (($x641 (= active_3_query active_2_query)))
 (let (($x762 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x322 (= v_3_retry_count v_2_retry_count)))
 (let (($x321 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x608 (= 2 state_3)))
 (let (($x1022 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x1230 (not active_2_query)))
 (let (($x1197 (or $x1230 (not (<= due_2_query 20)))))
 (let (($x749 (= state_2 2)))
 (and $x749 $x1197 $x1022 $x608 $x321 $x322 $x762 $x641 $x273 $x421 $x1255))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x613 (seq.unit (_ bv192 8))))
 (let ((?x1057 (seq.++ ?x613 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x1057))))
(assert
 (= 14 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x613 (seq.unit (_ bv192 8))))
 (let ((?x912 (seq.++ ?x613 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x445 (seq.unit (_ bv1 8))))
 (let ((?x949 (seq.unit (_ bv0 8))))
 (let ((?x334 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x445 ?x912)))))))
 (let ((?x691 (seq.unit (_ bv2 8))))
 (let ((?x452 (seq.++ ?x613 (seq.++ ?x949 (seq.++ ?x691 (seq.++ ?x691 (seq.++ ?x691 ?x334)))))))
 (let ((?x883 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x691 ?x452)))))))
 (let ((?x1168 (seq.unit (_ bv4 8))))
 (let ((?x973 (seq.unit (_ bv6 8))))
 (let ((?x1093 (seq.++ ?x973 (seq.++ ?x1168 (seq.++ ?x949 (seq.++ ?x691 (seq.++ ?x691 ?x883)))))))
 (let ((?x851 (seq.unit (_ bv8 8))))
 (let ((?x1081 (seq.++ ?x973 (seq.++ ?x949 (seq.++ ?x445 (seq.++ ?x851 (seq.++ ?x949 ?x1093)))))))
 (let ((?x65 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x691 (seq.++ ?x851 ?x1081)))))))
 (let ((?x524 (seq.++ ?x949 (seq.++ ?x949 (seq.++ ?x445 (seq.++ ?x691 (seq.++ ?x949 ?x65)))))))
 (let ((?x150 (seq.++ ?x691 (seq.++ ?x949 (seq.++ ?x949 ?x524)))))
 (= input_1_net.frame_frame ?x150))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x613 (seq.unit (_ bv192 8))))
(let ((?x1057 (seq.++ ?x613 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x1057))))
(check-sat)

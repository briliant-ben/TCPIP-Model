; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1192 (= due_1_cache due_0_cache)))
 (let (($x153 (= due_1_query 1000)))
 (let (($x928 (= active_1_cache active_0_cache)))
 (let (($x699 (= v_1_cache_ttl_ms 60000)))
 (let (($x109 (= 0 v_1_retry_count)))
 (let (($x1198 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x938 (= 1 state_1)))
 (let (($x1046 (not active_0_cache)))
 (let (($x1013 (or $x1046 (not (<= due_0_cache 0)))))
 (let (($x827 (not active_0_query)))
 (let (($x967 (or $x827 (not (<= due_0_query 0)))))
 (let (($x697 (= state_0 0)))
 (and $x697 (>= 0 now_0) $x967 $x1013 $x938 $x1198 $x109 $x699 active_1_query $x928 $x153 $x1192))))))))))))))
(assert
 true)
(assert
 (let (($x39 (= due_2_cache due_1_cache)))
 (let (($x533 (= due_2_query due_1_query)))
 (let (($x896 (= active_2_cache active_1_cache)))
 (let (($x1252 (= active_2_query active_1_query)))
 (let (($x620 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x960 (= v_2_retry_count v_1_retry_count)))
 (let (($x629 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x961 (= 1 state_2)))
 (let (($x1114 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x814 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x1136 (= state_1 1)))
 (and $x1136 $x814 $x1114 $x961 $x629 $x960 $x620 $x1252 $x896 $x533 $x39)))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x21 (= due_3_query due_2_query)))
 (let (($x1285 (not active_3_query)))
 (let (($x271 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x93 (= 0 v_3_retry_count)))
 (let ((?x215 (seq.unit (_ bv0 8))))
 (let ((?x369 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.unit (_ bv2 8))))))))
 (let ((?x1024 (seq.unit (_ bv2 8))))
 (let (($x1284 (= v_3_peer_mac (seq.++ ?x1024 ?x369))))
 (let (($x121 (= 2 state_3)))
 (let (($x293 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x142 (or (not active_2_query) (not (<= due_2_query 10)))))
 (let (($x1341 (= state_2 1)))
 (and $x1341 $x142 $x293 $x121 $x1284 $x93 $x271 $x1285 active_3_cache $x21 (= due_3_cache (+ 10 v_2_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x549 (seq.unit (_ bv192 8))))
 (let ((?x339 (seq.++ ?x549 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x339))))
(assert
 (= 15 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x549 (seq.unit (_ bv192 8))))
 (let ((?x878 (seq.++ ?x549 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x215 (seq.unit (_ bv0 8))))
 (let ((?x1266 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 ?x878)))))))
 (let ((?x1024 (seq.unit (_ bv2 8))))
 (let ((?x152 (seq.++ ?x549 (seq.++ ?x215 (seq.++ ?x1024 (seq.++ ?x1024 (seq.++ ?x215 ?x1266)))))))
 (let ((?x416 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x1024 ?x152)))))))
 (let ((?x217 (seq.unit (_ bv1 8))))
 (let ((?x296 (seq.unit (_ bv4 8))))
 (let ((?x809 (seq.unit (_ bv6 8))))
 (let ((?x1230 (seq.++ ?x809 (seq.++ ?x296 (seq.++ ?x215 (seq.++ ?x217 (seq.++ ?x1024 ?x416)))))))
 (let ((?x97 (seq.unit (_ bv8 8))))
 (let ((?x876 (seq.++ ?x809 (seq.++ ?x215 (seq.++ ?x217 (seq.++ ?x97 (seq.++ ?x215 ?x1230)))))))
 (let ((?x486 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x1024 (seq.++ ?x97 ?x876)))))))
 (let ((?x648 (seq.unit (_ bv255 8))))
 (let ((?x401 (seq.++ ?x648 (seq.++ ?x648 (seq.++ ?x648 (seq.++ ?x1024 (seq.++ ?x215 ?x486)))))))
 (let ((?x300 (seq.++ ?x648 (seq.++ ?x648 (seq.++ ?x648 ?x401)))))
 (= input_1_net.frame_frame ?x300)))))))))))))))))))
(assert
 (= 14 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x549 (seq.unit (_ bv192 8))))
(let ((?x415 (seq.++ ?x549 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x217 (seq.unit (_ bv1 8))))
(let ((?x215 (seq.unit (_ bv0 8))))
(let ((?x285 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x217 ?x415)))))))
(let ((?x1024 (seq.unit (_ bv2 8))))
(let ((?x893 (seq.++ ?x549 (seq.++ ?x215 (seq.++ ?x1024 (seq.++ ?x1024 (seq.++ ?x1024 ?x285)))))))
(let ((?x965 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x1024 ?x893)))))))
(let ((?x296 (seq.unit (_ bv4 8))))
(let ((?x809 (seq.unit (_ bv6 8))))
(let ((?x783 (seq.++ ?x809 (seq.++ ?x296 (seq.++ ?x215 (seq.++ ?x1024 (seq.++ ?x1024 ?x965)))))))
(let ((?x97 (seq.unit (_ bv8 8))))
(let ((?x592 (seq.++ ?x809 (seq.++ ?x215 (seq.++ ?x217 (seq.++ ?x97 (seq.++ ?x215 ?x783)))))))
(let ((?x260 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x1024 (seq.++ ?x97 ?x592)))))))
(let ((?x426 (seq.++ ?x215 (seq.++ ?x215 (seq.++ ?x217 (seq.++ ?x1024 (seq.++ ?x215 ?x260)))))))
(let ((?x672 (seq.++ ?x1024 (seq.++ ?x215 (seq.++ ?x215 ?x426)))))
(= input_2_net.frame_frame ?x672))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x613 (= due_1_cache due_0_cache)))
 (let (($x1339 (= due_1_query 1000)))
 (let (($x709 (= active_1_cache active_0_cache)))
 (let (($x524 (= v_1_cache_ttl_ms 60000)))
 (let (($x137 (= 0 v_1_retry_count)))
 (let (($x1152 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x398 (= 1 state_1)))
 (let (($x539 (not active_0_cache)))
 (let (($x1001 (or $x539 (not (<= due_0_cache 0)))))
 (let (($x243 (not active_0_query)))
 (let (($x46 (or $x243 (not (<= due_0_query 0)))))
 (let (($x330 (= state_0 0)))
 (and $x330 (>= 0 now_0) $x46 $x1001 $x398 $x1152 $x137 $x524 active_1_query $x709 $x1339 $x613))))))))))))))
(assert
 true)
(assert
 (let (($x849 (= due_2_query due_1_query)))
 (let (($x717 (not active_2_query)))
 (let (($x1099 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1137 (= 0 v_2_retry_count)))
 (let ((?x281 (seq.unit (_ bv0 8))))
 (let ((?x307 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.unit (_ bv3 8))))))))
 (let ((?x121 (seq.unit (_ bv2 8))))
 (let (($x371 (= v_2_peer_mac (seq.++ ?x121 ?x307))))
 (let (($x616 (= 2 state_2)))
 (let (($x643 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x707 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x518 (= state_1 1)))
 (and $x518 $x707 $x643 $x616 $x371 $x1137 $x1099 $x717 active_2_cache $x849 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x292 (seq.unit (_ bv192 8))))
 (let ((?x550 (seq.++ ?x292 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x550))))
(assert
 (= 13 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x292 (seq.unit (_ bv192 8))))
(let ((?x1060 (seq.++ ?x292 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x281 (seq.unit (_ bv0 8))))
(let ((?x1126 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 ?x1060)))))))
(let ((?x121 (seq.unit (_ bv2 8))))
(let ((?x296 (seq.++ ?x292 (seq.++ ?x281 (seq.++ ?x121 (seq.++ ?x121 (seq.++ ?x281 ?x1126)))))))
(let ((?x631 (seq.unit (_ bv3 8))))
(let ((?x171 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x631 ?x296)))))))
(let ((?x1203 (seq.unit (_ bv1 8))))
(let ((?x883 (seq.unit (_ bv4 8))))
(let ((?x485 (seq.unit (_ bv6 8))))
(let ((?x498 (seq.++ ?x485 (seq.++ ?x883 (seq.++ ?x281 (seq.++ ?x1203 (seq.++ ?x121 ?x171)))))))
(let ((?x478 (seq.unit (_ bv8 8))))
(let ((?x111 (seq.++ ?x485 (seq.++ ?x281 (seq.++ ?x1203 (seq.++ ?x478 (seq.++ ?x281 ?x498)))))))
(let ((?x893 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x281 (seq.++ ?x631 (seq.++ ?x478 ?x111)))))))
(let ((?x1128 (seq.unit (_ bv255 8))))
(let ((?x831 (seq.++ ?x1128 (seq.++ ?x1128 (seq.++ ?x1128 (seq.++ ?x121 (seq.++ ?x281 ?x893)))))))
(let ((?x890 (seq.++ ?x1128 (seq.++ ?x1128 (seq.++ ?x1128 ?x831)))))
(= input_1_net.frame_frame ?x890))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x933 (= due_1_cache 60000)))
 (let (($x515 (= due_1_query due_0_query)))
 (let (($x1169 (not active_1_query)))
 (let (($x965 (= v_1_cache_ttl_ms 60000)))
 (let (($x699 (= 0 v_1_retry_count)))
 (let ((?x34 (seq.unit (_ bv0 8))))
 (let ((?x284 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.unit (_ bv2 8))))))))
 (let ((?x912 (seq.unit (_ bv2 8))))
 (let (($x1212 (= v_1_peer_mac (seq.++ ?x912 ?x284))))
 (let (($x1198 (= 2 state_1)))
 (let (($x670 (not active_0_cache)))
 (let (($x1223 (or $x670 (not (<= due_0_cache 0)))))
 (let (($x206 (not active_0_query)))
 (let (($x444 (or $x206 (not (<= due_0_query 0)))))
 (let (($x860 (= state_0 0)))
 (and $x860 (>= 0 now_0) $x444 $x1223 $x1198 $x1212 $x699 $x965 $x1169 active_1_cache $x515 $x933)))))))))))))))))
(assert
 true)
(assert
 (let (($x600 (= due_2_query due_1_query)))
 (let (($x1349 (= active_2_query active_1_query)))
 (let (($x690 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x881 (= v_2_retry_count v_1_retry_count)))
 (let ((?x34 (seq.unit (_ bv0 8))))
 (let ((?x736 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.unit (_ bv3 8))))))))
 (let ((?x912 (seq.unit (_ bv2 8))))
 (let (($x476 (= v_2_peer_mac (seq.++ ?x912 ?x736))))
 (let (($x558 (= 2 state_2)))
 (let (($x1148 (or (not active_1_cache) (not (<= due_1_cache 59999)))))
 (let (($x1169 (not active_1_query)))
 (let (($x1108 (or $x1169 (not (<= due_1_query 59999)))))
 (let (($x890 (= state_1 2)))
 (and $x890 $x1108 $x1148 $x558 $x476 $x881 $x690 $x1349 active_2_cache $x600 (= due_2_cache (+ 59999 v_1_cache_ttl_ms)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x831 (= due_3_cache due_2_cache)))
 (let (($x625 (= due_3_query due_2_query)))
 (let (($x657 (= active_3_cache active_2_cache)))
 (let (($x181 (= active_3_query active_2_query)))
 (let (($x582 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x111 (= v_3_retry_count v_2_retry_count)))
 (let (($x743 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x553 (= 2 state_3)))
 (let (($x345 (or (not active_2_cache) (not (<= due_2_cache 60001)))))
 (let (($x189 (or (not active_2_query) (not (<= due_2_query 60001)))))
 (let (($x1105 (= state_2 2)))
 (and $x1105 $x189 $x345 $x553 $x743 $x111 $x582 $x181 $x657 $x625 $x831)))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1040 (seq.unit (_ bv192 8))))
 (let ((?x106 (seq.++ ?x1040 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x1336 (seq.unit (_ bv1 8))))
 (let ((?x34 (seq.unit (_ bv0 8))))
 (let ((?x591 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x1336 ?x106)))))))
 (let ((?x912 (seq.unit (_ bv2 8))))
 (let ((?x812 (seq.++ ?x1040 (seq.++ ?x34 (seq.++ ?x912 (seq.++ ?x912 (seq.++ ?x912 ?x591)))))))
 (let ((?x614 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x912 ?x812)))))))
 (let ((?x1064 (seq.unit (_ bv4 8))))
 (let ((?x666 (seq.unit (_ bv6 8))))
 (let ((?x1322 (seq.++ ?x666 (seq.++ ?x1064 (seq.++ ?x34 (seq.++ ?x912 (seq.++ ?x912 ?x614)))))))
 (let ((?x1016 (seq.unit (_ bv8 8))))
 (let ((?x880 (seq.++ ?x666 (seq.++ ?x34 (seq.++ ?x1336 (seq.++ ?x1016 (seq.++ ?x34 ?x1322)))))))
 (let ((?x94 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x912 (seq.++ ?x1016 ?x880)))))))
 (let ((?x717 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x1336 (seq.++ ?x912 (seq.++ ?x34 ?x94)))))))
 (let ((?x835 (seq.++ ?x912 (seq.++ ?x34 (seq.++ ?x34 ?x717)))))
 (= input_0_net.frame_frame ?x835))))))))))))))))))
(assert
 (= 20 choice_1))
(assert
 (= 59999 now_2))
(assert
 (let ((?x1040 (seq.unit (_ bv192 8))))
 (let ((?x850 (seq.++ ?x1040 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x34 (seq.unit (_ bv0 8))))
 (let ((?x221 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 ?x850)))))))
 (let ((?x912 (seq.unit (_ bv2 8))))
 (let ((?x1158 (seq.++ ?x1040 (seq.++ ?x34 (seq.++ ?x912 (seq.++ ?x912 (seq.++ ?x34 ?x221)))))))
 (let ((?x449 (seq.unit (_ bv3 8))))
 (let ((?x929 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x449 ?x1158)))))))
 (let ((?x1336 (seq.unit (_ bv1 8))))
 (let ((?x1064 (seq.unit (_ bv4 8))))
 (let ((?x666 (seq.unit (_ bv6 8))))
 (let ((?x1115 (seq.++ ?x666 (seq.++ ?x1064 (seq.++ ?x34 (seq.++ ?x1336 (seq.++ ?x912 ?x929)))))))
 (let ((?x1016 (seq.unit (_ bv8 8))))
 (let ((?x946 (seq.++ ?x666 (seq.++ ?x34 (seq.++ ?x1336 (seq.++ ?x1016 (seq.++ ?x34 ?x1115)))))))
 (let ((?x521 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x34 (seq.++ ?x449 (seq.++ ?x1016 ?x946)))))))
 (let ((?x373 (seq.unit (_ bv255 8))))
 (let ((?x311 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x912 (seq.++ ?x34 ?x521)))))))
 (let ((?x700 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 ?x311)))))
 (= input_1_net.frame_frame ?x700))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 60001 now_3))
(assert
 (let ((?x1040 (seq.unit (_ bv192 8))))
(let ((?x147 (seq.++ ?x1040 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x147))))
(check-sat)

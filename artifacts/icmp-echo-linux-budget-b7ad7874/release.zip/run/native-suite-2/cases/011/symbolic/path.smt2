; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x908 (= due_1_cache due_0_cache)))
 (let (($x1082 (= due_1_query due_0_query)))
 (let (($x615 (= active_1_cache active_0_cache)))
 (let (($x834 (= active_1_query active_0_query)))
 (let (($x195 (= v_1_cache_ttl_ms 60000)))
 (let (($x441 (= v_1_retry_count 0)))
 (let (($x280 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x149 (= 0 state_1)))
 (let (($x1138 (not active_0_cache)))
 (let (($x1163 (or $x1138 (not (<= due_0_cache 0)))))
 (let (($x334 (not active_0_query)))
 (let (($x93 (or $x334 (not (<= due_0_query 0)))))
 (let (($x346 (= state_0 0)))
 (and $x346 (>= 0 now_0) $x93 $x1163 $x149 $x280 $x441 $x195 $x834 $x615 $x1082 $x908)))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1031 (seq.unit (_ bv0 8))))
(let ((?x817 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 ?x1031)))))))
(let ((?x560 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 ?x817)))))))
(let ((?x830 (seq.++ ?x1031 (seq.++ ?x1031 (seq.++ ?x1031 ?x560)))))
(= input_0_net.frame_frame ?x830))))))
(check-sat)

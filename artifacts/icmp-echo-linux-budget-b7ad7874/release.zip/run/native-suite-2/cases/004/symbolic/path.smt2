; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x958 (= due_1_cache due_0_cache)))
 (let (($x286 (= due_1_query due_0_query)))
 (let (($x674 (= active_1_cache active_0_cache)))
 (let (($x252 (= active_1_query active_0_query)))
 (let (($x1041 (= v_1_cache_ttl_ms 60000)))
 (let (($x1263 (= v_1_retry_count 0)))
 (let (($x763 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x894 (= 0 state_1)))
 (let (($x235 (not active_0_cache)))
 (let (($x762 (or $x235 (not (<= due_0_cache 0)))))
 (let (($x1048 (not active_0_query)))
 (let (($x223 (or $x1048 (not (<= due_0_query 0)))))
 (let (($x1018 (= state_0 0)))
 (and $x1018 (>= 0 now_0) $x223 $x762 $x894 $x763 $x1263 $x1041 $x252 $x674 $x286 $x958)))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 10 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x315 (seq.unit (_ bv192 8))))
(let ((?x521 (seq.++ ?x315 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
(let ((?x535 (seq.unit (_ bv0 8))))
(let ((?x1268 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x535 ?x521)))))))
(let ((?x619 (seq.unit (_ bv2 8))))
(let ((?x1273 (seq.++ ?x315 (seq.++ ?x535 (seq.++ ?x619 (seq.++ ?x619 (seq.++ ?x535 ?x1268)))))))
(let ((?x97 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x619 ?x1273)))))))
(let ((?x276 (seq.unit (_ bv1 8))))
(let ((?x294 (seq.unit (_ bv4 8))))
(let ((?x830 (seq.unit (_ bv6 8))))
(let ((?x195 (seq.++ ?x830 (seq.++ ?x294 (seq.++ ?x535 (seq.++ ?x276 (seq.++ ?x619 ?x97)))))))
(let ((?x148 (seq.unit (_ bv8 8))))
(let ((?x200 (seq.++ ?x830 (seq.++ ?x535 (seq.++ ?x276 (seq.++ ?x148 (seq.++ ?x535 ?x195)))))))
(let ((?x205 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x535 (seq.++ ?x619 (seq.++ ?x148 ?x200)))))))
(let ((?x1168 (seq.unit (_ bv255 8))))
(let ((?x210 (seq.++ ?x1168 (seq.++ ?x1168 (seq.++ ?x1168 (seq.++ ?x619 (seq.++ ?x535 ?x205)))))))
(let ((?x213 (seq.++ ?x1168 (seq.++ ?x1168 (seq.++ ?x1168 ?x210)))))
(= input_0_net.frame_frame ?x213)))))))))))))))))))
(check-sat)

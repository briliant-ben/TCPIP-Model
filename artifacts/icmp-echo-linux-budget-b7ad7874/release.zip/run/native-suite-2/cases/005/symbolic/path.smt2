; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x781 (= due_1_cache 60000)))
 (let (($x233 (= due_1_query due_0_query)))
 (let (($x780 (not active_1_query)))
 (let (($x949 (= v_1_cache_ttl_ms 60000)))
 (let (($x1253 (= 0 v_1_retry_count)))
 (let ((?x212 (seq.unit (_ bv0 8))))
 (let ((?x160 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 (seq.unit (_ bv2 8))))))))
 (let ((?x9 (seq.unit (_ bv2 8))))
 (let (($x779 (= v_1_peer_mac (seq.++ ?x9 ?x160))))
 (let (($x171 (= 2 state_1)))
 (let (($x199 (not active_0_cache)))
 (let (($x778 (or $x199 (not (<= due_0_cache 0)))))
 (let (($x197 (not active_0_query)))
 (let (($x299 (or $x197 (not (<= due_0_query 0)))))
 (let (($x954 (= state_0 0)))
 (and $x954 (>= 0 now_0) $x299 $x778 $x171 $x779 $x1253 $x949 $x780 active_1_cache $x233 $x781)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x700 (seq.unit (_ bv14 8))))
(let ((?x331 (seq.++ ?x700 (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
(let ((?x698 (seq.unit (_ bv13 8))))
(let ((?x696 (seq.unit (_ bv12 8))))
(let ((?x694 (seq.unit (_ bv11 8))))
(let ((?x692 (seq.unit (_ bv10 8))))
(let ((?x27 (seq.unit (_ bv9 8))))
(let ((?x1122 (seq.++ ?x27 (seq.++ ?x692 (seq.++ ?x694 (seq.++ ?x696 (seq.++ ?x698 ?x331)))))))
(let ((?x1064 (seq.unit (_ bv8 8))))
(let ((?x905 (seq.unit (_ bv7 8))))
(let ((?x984 (seq.unit (_ bv6 8))))
(let ((?x340 (seq.unit (_ bv5 8))))
(let ((?x1135 (seq.unit (_ bv4 8))))
(let ((?x370 (seq.++ ?x1135 (seq.++ ?x340 (seq.++ ?x984 (seq.++ ?x905 (seq.++ ?x1064 ?x1122)))))))
(let ((?x902 (seq.unit (_ bv3 8))))
(let ((?x9 (seq.unit (_ bv2 8))))
(let ((?x579 (seq.unit (_ bv1 8))))
(let ((?x212 (seq.unit (_ bv0 8))))
(let ((?x964 (seq.++ ?x579 (seq.++ ?x212 (seq.++ ?x579 (seq.++ ?x9 (seq.++ ?x902 ?x370)))))))
(let ((?x210 (seq.unit (_ bv192 8))))
(let ((?x173 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x210 (seq.++ ?x212 (seq.++ ?x9 ?x964)))))))
(let ((?x24 (seq.++ ?x9 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 ?x173)))))))
(let ((?x784 (seq.++ ?x212 (seq.++ ?x9 (seq.++ ?x210 (seq.++ ?x212 (seq.++ ?x9 ?x24)))))))
(let ((?x1138 (seq.++ ?x579 (seq.++ ?x9 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 ?x784)))))))
(let ((?x31 (seq.++ ?x1064 (seq.++ ?x212 (seq.++ ?x984 (seq.++ ?x1135 (seq.++ ?x212 ?x1138)))))))
(let ((?x1097 (seq.++ ?x9 (seq.++ ?x1064 (seq.++ ?x984 (seq.++ ?x212 (seq.++ ?x579 ?x31)))))))
(let ((?x125 (seq.++ ?x9 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 (seq.++ ?x212 ?x1097)))))))
(let ((?x688 (seq.unit (_ bv255 8))))
(let ((?x329 (seq.++ ?x688 (seq.++ ?x688 (seq.++ ?x688 (seq.++ ?x688 (seq.++ ?x688 ?x125)))))))
(let ((?x1144 (seq.++ ?x688 ?x329)))
(= input_0_net.frame_frame ?x1144))))))))))))))))))))))))))))))))
(check-sat)

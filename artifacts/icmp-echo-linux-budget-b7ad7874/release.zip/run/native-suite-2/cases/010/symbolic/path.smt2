; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1102 (= due_1_cache due_0_cache)))
 (let (($x1236 (= due_1_query 1000)))
 (let (($x1273 (= active_1_cache active_0_cache)))
 (let (($x378 (= v_1_cache_ttl_ms 60000)))
 (let (($x201 (= 0 v_1_retry_count)))
 (let (($x978 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x913 (= 1 state_1)))
 (let (($x693 (not active_0_cache)))
 (let (($x941 (or $x693 (not (<= due_0_cache 0)))))
 (let (($x271 (not active_0_query)))
 (let (($x648 (or $x271 (not (<= due_0_query 0)))))
 (let (($x922 (= state_0 0)))
 (and $x922 (>= 0 now_0) $x648 $x941 $x913 $x978 $x201 $x378 active_1_query $x1273 $x1236 $x1102))))))))))))))
(assert
 true)
(assert
 (let (($x540 (= due_2_cache due_1_cache)))
 (let (($x398 (= due_2_query due_1_query)))
 (let (($x397 (= active_2_cache active_1_cache)))
 (let (($x1267 (= active_2_query active_1_query)))
 (let (($x1269 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x130 (= v_2_retry_count v_1_retry_count)))
 (let (($x530 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x774 (= 1 state_2)))
 (let (($x196 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x615 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x309 (= state_1 1)))
 (and $x309 $x615 $x196 $x774 $x530 $x130 $x1269 $x1267 $x397 $x398 $x540)))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x326 (= due_3_cache due_2_cache)))
 (let (($x1335 (= due_3_query 2000)))
 (let (($x81 (= active_3_cache active_2_cache)))
 (let (($x969 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x234 (= 1 v_3_retry_count)))
 (let (($x698 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x1046 (= 1 state_3)))
 (let (($x1074 (= 0 v_2_retry_count)))
 (let (($x602 (= state_2 1)))
 (and $x602 $x1074 active_2_query (= 1000 due_2_query) (or (not active_2_cache) (not (<= due_2_cache due_2_query))) $x1046 $x698 $x234 $x969 active_3_query $x81 $x1335 $x326)))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x861 (= due_4_cache due_3_cache)))
 (let (($x412 (= due_4_query due_3_query)))
 (let (($x968 (= active_4_cache active_3_cache)))
 (let (($x856 (not active_4_query)))
 (let (($x1031 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x1125 (= 0 v_4_retry_count)))
 (let (($x19 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x555 (= 0 state_4)))
 (let (($x234 (= 1 v_3_retry_count)))
 (let (($x594 (= state_3 1)))
 (and $x594 $x234 active_3_query (= 2000 due_3_query) (or (not active_3_cache) (not (<= due_3_cache due_3_query))) $x555 $x19 $x1125 $x1031 $x856 $x968 $x412 $x861))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x783 (seq.unit (_ bv192 8))))
 (let ((?x32 (seq.++ ?x783 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x32))))
(assert
 (= 1 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x783 (seq.unit (_ bv192 8))))
 (let ((?x32 (seq.++ ?x783 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_1_app.resolve_ip ?x32))))
(assert
 (= 3 choice_2))
(assert
 (= 1000 now_3))
(assert
 (= 4 choice_3))
(assert
 (= 2000 now_4))
(check-sat)

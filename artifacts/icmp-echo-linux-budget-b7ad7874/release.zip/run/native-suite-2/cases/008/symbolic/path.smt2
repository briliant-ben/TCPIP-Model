; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x403 (= due_1_cache 60000)))
 (let (($x339 (= due_1_query due_0_query)))
 (let (($x897 (not active_1_query)))
 (let (($x1159 (= v_1_cache_ttl_ms 60000)))
 (let (($x935 (= 0 v_1_retry_count)))
 (let ((?x373 (seq.unit (_ bv0 8))))
 (let ((?x782 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.unit (_ bv2 8))))))))
 (let ((?x848 (seq.unit (_ bv2 8))))
 (let (($x710 (= v_1_peer_mac (seq.++ ?x848 ?x782))))
 (let (($x670 (= 2 state_1)))
 (let (($x192 (not active_0_cache)))
 (let (($x205 (or $x192 (not (<= due_0_cache 0)))))
 (let (($x69 (not active_0_query)))
 (let (($x443 (or $x69 (not (<= due_0_query 0)))))
 (let (($x1209 (= state_0 0)))
 (and $x1209 (>= 0 now_0) $x443 $x205 $x670 $x710 $x935 $x1159 $x897 active_1_cache $x339 $x403)))))))))))))))))
(assert
 true)
(assert
 (let (($x1347 (= due_2_query due_1_query)))
 (let (($x588 (not active_2_query)))
 (let (($x362 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x776 (= 0 v_2_retry_count)))
 (let ((?x373 (seq.unit (_ bv0 8))))
 (let ((?x204 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.unit (_ bv3 8))))))))
 (let ((?x848 (seq.unit (_ bv2 8))))
 (let (($x363 (= v_2_peer_mac (seq.++ ?x848 ?x204))))
 (let (($x942 (= 2 state_2)))
 (let (($x518 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x897 (not active_1_query)))
 (let (($x306 (or $x897 (not (<= due_1_query 5)))))
 (let (($x984 (= state_1 2)))
 (and $x984 $x306 $x518 $x942 $x363 $x776 $x362 $x588 active_2_cache $x1347 (= due_2_cache (+ 5 v_1_cache_ttl_ms)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x134 (= due_3_cache due_2_cache)))
 (let (($x251 (= due_3_query due_2_query)))
 (let (($x709 (= active_3_cache active_2_cache)))
 (let (($x543 (= active_3_query active_2_query)))
 (let (($x1194 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x1193 (= v_3_retry_count v_2_retry_count)))
 (let (($x931 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x930 (= 2 state_3)))
 (let (($x635 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x588 (not active_2_query)))
 (let (($x813 (or $x588 (not (<= due_2_query 10)))))
 (let (($x1058 (= state_2 2)))
 (and $x1058 $x813 $x635 $x930 $x931 $x1193 $x1194 $x543 $x709 $x251 $x134))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x843 (seq.unit (_ bv192 8))))
 (let ((?x1083 (seq.++ ?x843 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x277 (seq.unit (_ bv1 8))))
 (let ((?x373 (seq.unit (_ bv0 8))))
 (let ((?x923 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x277 ?x1083)))))))
 (let ((?x848 (seq.unit (_ bv2 8))))
 (let ((?x369 (seq.++ ?x843 (seq.++ ?x373 (seq.++ ?x848 (seq.++ ?x848 (seq.++ ?x848 ?x923)))))))
 (let ((?x20 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x848 ?x369)))))))
 (let ((?x189 (seq.unit (_ bv4 8))))
 (let ((?x427 (seq.unit (_ bv6 8))))
 (let ((?x1005 (seq.++ ?x427 (seq.++ ?x189 (seq.++ ?x373 (seq.++ ?x848 (seq.++ ?x848 ?x20)))))))
 (let ((?x769 (seq.unit (_ bv8 8))))
 (let ((?x764 (seq.++ ?x427 (seq.++ ?x373 (seq.++ ?x277 (seq.++ ?x769 (seq.++ ?x373 ?x1005)))))))
 (let ((?x1097 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x848 (seq.++ ?x769 ?x764)))))))
 (let ((?x510 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x277 (seq.++ ?x848 (seq.++ ?x373 ?x1097)))))))
 (let ((?x117 (seq.++ ?x848 (seq.++ ?x373 (seq.++ ?x373 ?x510)))))
 (= input_0_net.frame_frame ?x117))))))))))))))))))
(assert
 (= 19 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x843 (seq.unit (_ bv192 8))))
 (let ((?x1083 (seq.++ ?x843 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x277 (seq.unit (_ bv1 8))))
 (let ((?x373 (seq.unit (_ bv0 8))))
 (let ((?x923 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x277 ?x1083)))))))
 (let ((?x848 (seq.unit (_ bv2 8))))
 (let ((?x369 (seq.++ ?x843 (seq.++ ?x373 (seq.++ ?x848 (seq.++ ?x848 (seq.++ ?x848 ?x923)))))))
 (let ((?x646 (seq.unit (_ bv3 8))))
 (let ((?x825 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x646 ?x369)))))))
 (let ((?x189 (seq.unit (_ bv4 8))))
 (let ((?x427 (seq.unit (_ bv6 8))))
 (let ((?x609 (seq.++ ?x427 (seq.++ ?x189 (seq.++ ?x373 (seq.++ ?x848 (seq.++ ?x848 ?x825)))))))
 (let ((?x769 (seq.unit (_ bv8 8))))
 (let ((?x191 (seq.++ ?x427 (seq.++ ?x373 (seq.++ ?x277 (seq.++ ?x769 (seq.++ ?x373 ?x609)))))))
 (let ((?x576 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x646 (seq.++ ?x769 ?x191)))))))
 (let ((?x1333 (seq.++ ?x373 (seq.++ ?x373 (seq.++ ?x277 (seq.++ ?x848 (seq.++ ?x373 ?x576)))))))
 (let ((?x281 (seq.++ ?x848 (seq.++ ?x373 (seq.++ ?x373 ?x1333)))))
 (= input_1_net.frame_frame ?x281)))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x843 (seq.unit (_ bv192 8))))
(let ((?x96 (seq.++ ?x843 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x96))))
(check-sat)

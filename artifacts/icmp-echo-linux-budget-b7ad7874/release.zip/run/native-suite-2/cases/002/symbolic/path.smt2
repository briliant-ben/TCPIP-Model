; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x550 (= due_1_cache 60000)))
 (let (($x728 (= due_1_query due_0_query)))
 (let (($x549 (not active_1_query)))
 (let (($x515 (= v_1_cache_ttl_ms 60000)))
 (let (($x189 (= 0 v_1_retry_count)))
 (let ((?x959 (seq.unit (_ bv0 8))))
 (let ((?x640 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.unit (_ bv2 8))))))))
 (let ((?x961 (seq.unit (_ bv2 8))))
 (let (($x548 (= v_1_peer_mac (seq.++ ?x961 ?x640))))
 (let (($x1021 (= 2 state_1)))
 (let (($x827 (not active_0_cache)))
 (let (($x547 (or $x827 (not (<= due_0_cache 0)))))
 (let (($x825 (not active_0_query)))
 (let (($x351 (or $x825 (not (<= due_0_query 0)))))
 (let (($x712 (= state_0 0)))
 (and $x712 (>= 0 now_0) $x351 $x547 $x1021 $x548 $x189 $x515 $x549 active_1_cache $x728 $x550)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x957 (seq.unit (_ bv192 8))))
(let ((?x183 (seq.++ ?x957 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x959 (seq.unit (_ bv0 8))))
(let ((?x415 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 ?x183)))))))
(let ((?x961 (seq.unit (_ bv2 8))))
(let ((?x419 (seq.++ ?x957 (seq.++ ?x959 (seq.++ ?x961 (seq.++ ?x961 (seq.++ ?x959 ?x415)))))))
(let ((?x424 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x961 ?x419)))))))
(let ((?x1253 (seq.unit (_ bv1 8))))
(let ((?x670 (seq.unit (_ bv4 8))))
(let ((?x665 (seq.unit (_ bv6 8))))
(let ((?x443 (seq.++ ?x665 (seq.++ ?x670 (seq.++ ?x959 (seq.++ ?x1253 (seq.++ ?x961 ?x424)))))))
(let ((?x894 (seq.unit (_ bv8 8))))
(let ((?x448 (seq.++ ?x665 (seq.++ ?x959 (seq.++ ?x1253 (seq.++ ?x894 (seq.++ ?x959 ?x443)))))))
(let ((?x626 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x961 (seq.++ ?x894 ?x448)))))))
(let ((?x1261 (seq.unit (_ bv255 8))))
(let ((?x630 (seq.++ ?x1261 (seq.++ ?x1261 (seq.++ ?x1261 (seq.++ ?x961 (seq.++ ?x959 ?x626)))))))
(let ((?x633 (seq.++ ?x1261 (seq.++ ?x1261 (seq.++ ?x1261 ?x630)))))
(= input_0_net.frame_frame ?x633)))))))))))))))))))
(check-sat)

"""Exact remainder expansion of the remaining original ACK query partitions."""
from pathlib import Path
import hashlib,json,subprocess,sys,tarfile,time
sys.path.insert(0,str(Path('formal').resolve()))
import modular_piecewise as p
root=Path('/tmp/tcp-piecewise-remaining68')
if root.exists():raise ValueError('Use a fresh run; do not restart live work')
root.mkdir();(root/'driver.py').write_bytes(Path(__file__).read_bytes())
original=Path('artifacts/sent-ledger-single-target-unknown')
manifest=json.loads((original/'members.json').read_text());archive=original/'exact-single-disjunct-attempt.tar.gz'
start=time.monotonic();rows=[];common=None
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
p.n.write(root/'started.json',dict(status='running',git_commit=commit,driver_sha256=p.n.sha(__file__),
 archive_sha256=p.n.sha(archive),members_sha256=p.n.sha(original/'members.json'),
 normalizer_sha256=p.n.sha('formal/modular_piecewise.py'),timeout_ms=10000))
with tarfile.open(archive,'r:gz')as stream:
 prior=json.load(stream.extractfile('result.json'))
 selected=[row for row in prior['groups']if row['query']=='unknown'and row['disjunct_indices'][0]not in (52,92)]
 assert len(selected)==68
 for row in selected:
  name=row['file'];source=root/name;data=stream.extractfile(name).read()
  if hashlib.sha256(data).hexdigest()!=manifest[name]:raise ValueError('Original member changed')
  source.write_bytes(data);terms=p.n.read_query(source)
  if common is None:
   common=terms[:-1];(root/'context.smt2').write_text(p.script(common))
   context=p.n.cli(root/'context.smt2',root/'context.log')
   fresh_context=p.n.cli(root/'context.smt2',root/'context.independent.log')
   p.n.write(root/'context.json',dict(producer=context,fresh=fresh_context))
  elif len(common)!=len(terms)-1 or any(not a.eq(b)for a,b in zip(common,terms[:-1])):
   raise ValueError('Different nonvacuity context')
  out=root/Path(name).stem
  result=p.produce(source,out);verified=p.verify(out,source)
  p.n.write(out/'verification.json',verified)
  answer=p.n.cli(out/'normalized.smt2',out/'query.log')
  fresh=p.n.cli(out/'normalized.smt2',out/'query.independent.log')if answer['query']=='unsat'else None
  record=dict(file=name,disjunct=row['disjunct_indices'][0],source_sha256=manifest[name],
   rewrites=result['rewrite_count'],producer=answer,fresh=fresh,
   accepted_unsat=answer['query']=='unsat'and fresh['query']=='unsat'if fresh else False)
  rows.append(record)
  with (root/'progress.jsonl').open('a')as handle:handle.write(json.dumps(record)+'\n')
  print(record['disjunct'],record['producer']['query'],record['fresh']['query']if fresh else '',flush=True)
p.n.write(root/'result.json',dict(status='terminal_exact_refinement',git_commit=commit,
 seconds=time.monotonic()-start,groups=rows,accepted_unsat=sum(x['accepted_unsat']for x in rows),
 unknown=sum(x['producer']['query']=='unknown'or x['fresh']is not None and x['fresh']['query']=='unknown'for x in rows),
 context=context,fresh_context=fresh_context,normalizer_sha256=p.n.sha('formal/modular_piecewise.py'),
 scope='68 original exact exported disjuncts, no whole-model, kernel, translator or protocol proof'))

import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ports/linux-tcp-ipv4-peer'))
import probe
class ControllerContracts(unittest.TestCase):
 def test_actual_protocol_offset(self):
  for proto in (6,17):
   frame=b'\x00'*12+b'\x08\x00'+bytes([0x45,0,0,40,0,0,0x40,0,64,proto])+b'\x00'*10
   self.assertEqual(probe.is_tcp_ipv4(frame),proto==6)
 def test_actual_capture_stop_deadline_and_exact_bytes(self):
  frame=b'\x00'*12+b'\x08\x06'+b'\x00'*46
  records=[dict(timestamp_ns=1000000000,raw=frame)]
  stats=dict(captured=1,received=2,dropped=0)
  probe.verify_capture_final(records,[frame],stats,1100000000,100)
  for selected,st,stop in [([frame],stats,1099999999),([],stats,1100000000),([frame+b'\x00'],stats,1100000000),([frame],dict(captured=1,received=2,dropped=1),1100000000),([frame],dict(captured=2,received=2,dropped=0),1100000000)]:
   with self.assertRaises((ValueError,RuntimeError)):probe.verify_capture_final(records,selected,st,stop,100)

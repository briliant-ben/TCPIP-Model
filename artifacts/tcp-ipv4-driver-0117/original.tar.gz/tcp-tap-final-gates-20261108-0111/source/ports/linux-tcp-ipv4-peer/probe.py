#!/usr/bin/env python3
"""First-TCP-ingress diagnostic for generated C subject using isolated Linux peer."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
PORT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PORT))

from ports.native_session import Session
from ports.tcp_ipv4_probe_support import elapsed_ms, capture_stats, pcap_records, quiet_ok, operation_result, record_error
from protocol_lab.ir import load
from protocol_lab.codegen.execute import commands

TAP_NAME = 'tap0'
SUBJECT_IP = '192.0.2.1'
PEER_IP = '192.0.2.2'
PEER_MAC = '02:00:00:00:00:02'
PEER_PORT = 8080
SERVER_COUNT = 4
QUIET_MS = 100
OVERALL_TIMEOUT_S = 10
QUIET_TIMEOUT_S = 5


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def run_command(args, out, name):
    p = subprocess.run(args, capture_output=True, text=True, timeout=10)
    (out / name).write_text(p.stdout + p.stderr)
    if p.returncode != 0:
        raise RuntimeError(f"Command failed: {args}")
    return {'command': args, 'returncode': p.returncode, 'log': name}


def preflight(parent_netns):
    if not (sys.platform.startswith('linux') and os.geteuid() == 0):
        raise RuntimeError('Linux root required')
    if not Path('/dev/net/tun').exists():
        raise RuntimeError('/dev/net/tun missing')
    tools = {name: shutil.which(name) for name in ('ip', 'tcpdump', 'sysctl', 'sha256sum')}
    missing = [name for name, path in tools.items() if not path]
    if missing:
        raise RuntimeError(f'Missing tools: {missing}')
    current = os.readlink('/proc/self/ns/net')
    if not current.startswith('net:[') or not parent_netns.startswith('net:[') or current == parent_netns:
        raise RuntimeError('Distinct network namespace required')
    return tools


def configure_peer(tap_fd, out_dir):
    mac = PEER_MAC
    setup_commands = [
        ['ip', 'link', 'set', 'lo', 'up'],
        ['ip', 'link', 'set', TAP_NAME, 'address', mac],
        ['ip', 'addr', 'add', PEER_IP + '/24', 'dev', TAP_NAME],
        ['ip', 'link', 'set', TAP_NAME, 'mtu', '1500', 'up'],
    ]
    for i, cmd in enumerate(setup_commands):
        run_command(cmd, out_dir, f'setup-{i}.log')


def start_server(out_dir):
    server_out = out_dir / 'server'
    server_out.mkdir()
    server_script = ROOT / 'ports/linux-tcp-wire-peer/server.py'
    server = subprocess.Popen(
        [sys.executable, str(server_script), '--out', str(server_out),
         '--ip', PEER_IP, '--port', str(PEER_PORT), '--count', str(SERVER_COUNT)],
        stdin=subprocess.PIPE, stdout=open(server_out / 'stdout.log', 'wb'),
        stderr=open(server_out / 'stderr.log', 'wb')
    )
    deadline = time.monotonic() + 5
    events_file = server_out / 'server-events.jsonl'
    while not events_file.exists() and time.monotonic() < deadline:
        if server.poll() is not None:
            raise RuntimeError('Server exited before listening')
        time.sleep(0.05)
    if not events_file.exists():
        raise RuntimeError('Server readiness timeout')
    with open(events_file) as f:
        lines = f.readlines()
    if not any('"event": "listening"' in line for line in lines):
        raise RuntimeError('Server listening event not found')
    return server


def start_capture(out_dir):
    cap_log = open(out_dir / 'capture.log', 'w')
    cap_cmd = ['tcpdump', '--immediate-mode', '-U', '-n', '-s', '65535',
               '-i', TAP_NAME, '-w', str(out_dir / 'capture.pcap'), 'arp or ip']
    capture = subprocess.Popen(cap_cmd, stdout=cap_log, stderr=cap_log)
    deadline = time.monotonic() + 5
    while True:
        if capture.poll() is not None:
            raise RuntimeError('tcpdump failed to start')
        cap_log.flush()
        if 'listening on' in (out_dir / 'capture.log').read_text():
            break
        if time.monotonic() > deadline:
            raise RuntimeError('tcpdump readiness timeout')
        time.sleep(0.02)
    return capture, cap_log


def is_tcp_ipv4(raw):
    if len(raw) < 14 + 20:
        return False
    if raw[12:14] != b'\x08\x00':
        return False
    return raw[23] == 6  # IP protocol TCP


def save_raw_frame(raw, direction, index, out_dir, subdir='links'):
    d = out_dir / subdir
    d.mkdir(exist_ok=True)
    filename = f'{direction}-{index:04d}.raw'
    path = d / filename
    path.write_bytes(raw)
    return str(path.relative_to(out_dir))


def process_model_operation(rows, tap_fd, origin, out_dir, links, services, logger):
    """Process operation_result and write emitted frames to TAP."""
    result = operation_result(rows)
    if result['status'] == 'error':
        return result
    for frame in result['frames']:
        raw = bytes(frame)
        path = save_raw_frame(raw, 'egress', len(links), out_dir)
        links.append({'direction': 'egress', 'file': path, 'raw': raw.hex(), 'monotonic_ns': time.monotonic_ns()})
        os.write(tap_fd, raw)
    services.extend(result['services'])
    return result


def read_tap_frame(fd, out_dir, index, processing, observations):
    raw = os.read(fd, 65535)
    stamp = time.monotonic_ns()
    if len(raw) < 14:
        raise RuntimeError('Short frame from TAP')
    ethertype = raw[12:14]
    if ethertype not in (b'\x08\x06', b'\x08\x00'):
        path = save_raw_frame(raw, 'unselected', len(observations), out_dir, 'unselected')
        observations.append({'file': path, 'ethertype': ethertype.hex()})
        return None, stamp
    # Selected frame: always save as ingress and return frame_info
    path = save_raw_frame(raw, 'ingress', index, out_dir)
    frame_info = {'raw': raw, 'file': path, 'monotonic_ns': stamp}
    if not processing:
        # Late observation, still include in selected links but mark not fed
        frame_info['fed'] = False
    else:
        frame_info['fed'] = True
    return frame_info, stamp


def verify_capture_final(records, selected_raw, stats, stop_request_wall_ns, quiet_ms=100):
    """Validate final capture consistency and quiet period."""
    if not isinstance(records, list) or not records:
        raise ValueError("records must be non-empty list")
    for rec in records:
        if not isinstance(rec, dict) or 'timestamp_ns' not in rec or 'raw' not in rec:
            raise ValueError("records must be dicts with timestamp_ns and raw")
        if not isinstance(rec['timestamp_ns'], int):
            raise ValueError("timestamp_ns must be int")
        if not isinstance(rec['raw'], bytes):
            raise ValueError("raw must be bytes")
        if len(rec['raw']) < 14:
            raise ValueError("record raw too short")
        ethertype = rec['raw'][12:14]
        if ethertype not in (b'\x08\x06', b'\x08\x00'):
            raise ValueError("record with unexpected ethertype")
    if not selected_raw:
        raise ValueError("selected_raw must not be empty")
    if not all(isinstance(x, bytes) for x in selected_raw):
        raise ValueError("selected_raw must be list of bytes")
    if not isinstance(stats, dict) or 'captured' not in stats or 'received' not in stats or 'dropped' not in stats:
        raise ValueError("stats missing keys")
    if not all(isinstance(stats[k], int) for k in ('captured', 'received', 'dropped')):
        raise ValueError("stats values must be ints")
    if stats['dropped'] != 0:
        raise RuntimeError("tcpdump dropped packets")
    if stats['captured'] != len(records):
        raise RuntimeError(f"stats captured {stats['captured']} but records {len(records)}")
    if len(selected_raw) != len(records):
        raise RuntimeError("selected_raw count does not match records count")
    for i, (sel, rec) in enumerate(zip(selected_raw, records)):
        if sel != rec['raw']:
            raise RuntimeError(f"selected_raw mismatch at index {i}")
    if not quiet_ok(records, stop_request_wall_ns, quiet_ms):
        raise RuntimeError("quiet period not satisfied")
    return {"selected_count": len(selected_raw), "record_count": len(records),
            "captured": stats['captured'], "received": stats['received'], "dropped": stats['dropped']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--executable', type=Path, required=True)
    parser.add_argument('--parent-netns', required=True)
    args = parser.parse_args()

    out_dir = args.out.resolve()
    out_dir.mkdir(parents=True, exist_ok=False)
    report = {
        'status': 'not_run',
        'error': None,
        'secondary_errors': [],
        'blocked_preflight': False,
        'driver_failure': False,
        'model_gap': False,
        'rule_conflict': False,
        'invariant_failure': False,
        'capture_invalid': False,
        'first_ingress_admitted': False,
        'full_TCP_exchange_complete': False,
        'whole_ipv4_endpoint_complete': False,
        'physical_ethernet': False,
    }

    # Initialize variables for artifacts
    links = []
    observations = []
    services = []
    operations_log = []
    ns_info = {}
    actor = None
    server = None
    capture = None
    cap_log = None
    fd = None

    try:
        # Compute initial source hashes before any network mutation
        source_paths = {
            'model': args.model,
            'executable': args.executable,
            'helper': ROOT / 'ports/tcp_ipv4_probe_support.py',
            'probe': PORT / 'probe.py',
            'session': ROOT / 'ports/native_session.py',
            'server': ROOT / 'ports/linux-tcp-wire-peer/server.py',
        }
        for name, path in source_paths.items():
            if not path.exists():
                record_error(report, 'driver_failure', f"Source file missing: {name} ({path})")
                raise RuntimeError(f"Missing source: {name}")
        initial_hashes = {name: sha256_file(path) for name, path in source_paths.items()}

        # Preflight and isolation check
        tools = preflight(args.parent_netns)
        report['blocked_preflight'] = True
        ns_info = {
            'platform': sys.platform,
            'kernel': os.uname().release,
            'parent_netns': args.parent_netns,
            'current_netns': os.readlink('/proc/self/ns/net'),
            'tools': tools,
            'initial_hashes': initial_hashes,
        }
        (out_dir / 'preflight.json').write_text(json.dumps(ns_info, indent=2))
        report['blocked_preflight'] = False

        # TAP setup
        fd = os.open('/dev/net/tun', os.O_RDWR)
        ifr = struct.pack('16sH22x', TAP_NAME.encode(), 0x1002)  # IFF_TAP | IFF_NO_PI
        fcntl.ioctl(fd, 0x400454ca, ifr)
        configure_peer(fd, out_dir)

        # Start server
        server = start_server(out_dir)
        # Start capture
        capture, cap_log = start_capture(out_dir)

        # Start C subject session
        actor = Session(args.executable, out_dir / 'native')
        origin = time.monotonic_ns()
        ns_info['clock_origin_monotonic_ns'] = origin
        ns_info['native_pid'] = actor.process.pid

        model = load(args.model)
        first_ingress_admitted = False
        processing_inputs = True
        error_encountered = None
        overall_deadline = time.monotonic() + OVERALL_TIMEOUT_S
        ingress_index = 0

        def current_ms():
            return (time.monotonic_ns() - origin) // 1_000_000

        def send_operation(step, description):
            nonlocal first_ingress_admitted, processing_inputs, error_encountered
            sample = time.monotonic_ns()
            at_ms = elapsed_ms(origin, sample)
            step['at_ms'] = at_ms
            line = commands(model, {'initial': {}, 'steps': [step]}).splitlines()[1]
            rows = actor.operation(line)
            operations_log.append({
                'step': step,
                'description': description,
                'sampled_monotonic_ns': sample,
                'reply_monotonic_ns': time.monotonic_ns(),
                'at_ms': at_ms,
            })
            result = process_model_operation(rows, fd, origin, out_dir, links, services, operations_log)
            if result['status'] == 'error':
                error_encountered = result
                processing_inputs = False
                return result
            if (step.get('event') == 'net.frame' and
                is_tcp_ipv4(bytes(step['fields']['frame'])) and
                not first_ingress_admitted):
                first_ingress_admitted = True
                processing_inputs = False
            return result

        # Send app.connect
        connect_step = {'event': 'T.app.connect', 'fields': {}}
        result = send_operation(connect_step, 'app.connect')
        if result['status'] == 'error':
            record_error(report, result['category'], result['failure'])
            raise RuntimeError(f'Model error: {result["category"]}: {result["failure"]}')

        # Main loop
        while not first_ingress_admitted and error_encountered is None and time.monotonic() < overall_deadline:
            timers = actor.snapshot.get('timers', {})
            if timers:
                due_ms = min(timers.values())
                if current_ms() >= due_ms:
                    tick_step = {'tick': True}
                    result = send_operation(tick_step, 'tick')
                    if result['status'] == 'error':
                        record_error(report, result['category'], result['failure'])
                        raise RuntimeError(f'Tick error: {result["failure"]}')
                    continue
            timeout = 0.01
            ready = select.select([fd], [], [], timeout)[0]
            if fd in ready:
                frame_info, stamp = read_tap_frame(fd, out_dir, ingress_index, processing_inputs, observations)
                if frame_info is not None:
                    raw = frame_info['raw']
                    path = frame_info['file']
                    fed = frame_info.get('fed', True)
                    links.append({'direction': 'ingress', 'file': path, 'raw': raw.hex(),
                                  'monotonic_ns': stamp, 'fed': fed})
                    ingress_index += 1
                    if processing_inputs:
                        step = {'event': 'net.frame', 'fields': {'frame': list(raw)}}
                        result = send_operation(step, 'ingress')
                        if result['status'] == 'error':
                            record_error(report, result['category'], result['failure'])
                            raise RuntimeError(f'Ingress error: {result["failure"]}')
                        if first_ingress_admitted:
                            break
            if actor.process.poll() is not None:
                raise RuntimeError('Native process died')
            if capture.poll() is not None:
                raise RuntimeError('Capture process died')
            if server.poll() is not None:
                raise RuntimeError('Server process died')

        if error_encountered is not None:
            pass
        elif not first_ingress_admitted:
            record_error(report, 'driver_failure', 'Diagnostic timeout before first TCP ingress admission')
            raise RuntimeError('Timeout')
        else:
            # Quiet period: read frames, refresh pcap until quiet
            quiet_deadline = time.monotonic() + QUIET_TIMEOUT_S
            stop_request_wall_ns = None
            while time.monotonic() < quiet_deadline:
                ready = select.select([fd], [], [], 0.01)[0]
                if fd in ready:
                    frame_info, stamp = read_tap_frame(fd, out_dir, ingress_index, False, observations)
                    if frame_info is not None:
                        raw = frame_info['raw']
                        path = frame_info['file']
                        fed = frame_info.get('fed', False)
                        links.append({'direction': 'ingress', 'file': path, 'raw': raw.hex(),
                                      'monotonic_ns': stamp, 'fed': fed})
                        ingress_index += 1
                try:
                    raw_pcap = (out_dir / 'capture.pcap').read_bytes()
                    pcap_recs = pcap_records(raw_pcap)
                    if pcap_recs:
                        last_pcap_ts = pcap_recs[-1]['timestamp_ns']
                        if (time.time_ns() - last_pcap_ts) >= (QUIET_MS * 1_000_000):
                            stop_request_wall_ns = time.time_ns()
                            break
                except (ValueError, FileNotFoundError):
                    pass
                if actor.process.poll() is not None or capture.poll() is not None or server.poll() is not None:
                    raise RuntimeError('Process died during quiet period')
            if stop_request_wall_ns is None:
                record_error(report, 'driver_failure', 'Quiet period timeout')
                raise RuntimeError('Quiet timeout')

        # Stop capture first
        if capture.poll() is None:
            capture.send_signal(2)  # SIGINT
            try:
                capture.wait(timeout=5)
            except subprocess.TimeoutExpired:
                capture.kill()
                capture.wait(timeout=5)
                record_error(report, 'driver_failure', 'Capture did not exit after SIGINT')
        cap_log.close()

        # Final capture validation
        raw_pcap = (out_dir / 'capture.pcap').read_bytes()
        pcap_recs = pcap_records(raw_pcap)
        cap_stats = capture_stats((out_dir / 'capture.log').read_text())
        # Build selected_raw from links (ordered)
        selected_raw = [bytes.fromhex(link['raw']) for link in links]
        try:
            verify_capture_final(pcap_recs, selected_raw, cap_stats, stop_request_wall_ns, QUIET_MS)
        except (ValueError, RuntimeError) as e:
            record_error(report, 'capture_invalid', str(e))

        # Close server and actor with bounded waits
        if server.poll() is None:
            server.stdin.close()
            try:
                server.wait(timeout=2)
            except subprocess.TimeoutExpired:
                server.terminate()
                server.wait(timeout=2)
        actor_return = actor.close()

        # Write artifacts
        (out_dir / 'links.json').write_text(json.dumps(links, indent=2))
        (out_dir / 'observations.json').write_text(json.dumps(observations, indent=2))
        (out_dir / 'services.json').write_text(json.dumps(services, indent=2))
        (out_dir / 'operations.json').write_text(json.dumps(operations_log, indent=2))

        ns_info.update({
            'capture_command': ['tcpdump', '--immediate-mode', '-U', '-n', '-s', '65535',
                                '-i', TAP_NAME, '-w', str(out_dir / 'capture.pcap'), 'arp or ip'],
            'capture_stats': cap_stats,
            'pcap_record_count': len(pcap_recs),
            'links_count': len(links),
            'observations_count': len(observations),
            'native_returncode': actor_return,
            'server_returncode': server.returncode if server else None,
            'first_ingress_admitted': first_ingress_admitted,
            'stop_request_wall_ns': stop_request_wall_ns,
        })
        (out_dir / 'namespace.json').write_text(json.dumps(ns_info, indent=2))

        # Compute final hashes and compare
        final_hashes = {name: sha256_file(path) for name, path in source_paths.items()}
        changed_files = [name for name in initial_hashes if initial_hashes[name] != final_hashes.get(name)]
        if changed_files:
            record_error(report, 'driver_failure', f'Source files changed during execution: {changed_files}')

        hashes = initial_hashes.copy()
        hashes.update(final_hashes)
        report['source_hashes'] = hashes

        if report['error'] is None and not report['secondary_errors'] and first_ingress_admitted:
            report['status'] = 'pass'
        else:
            report['status'] = 'failed_or_blocked'
        report['first_ingress_admitted'] = first_ingress_admitted
        report['full_TCP_exchange_complete'] = False
        report['whole_ipv4_endpoint_complete'] = False
        report['physical_ethernet'] = False

        (out_dir / 'report.json').write_text(json.dumps(report, indent=2))

        return 0 if report['status'] == 'pass' else 1

    except Exception as e:
        if report['error'] is None:
            category = 'driver_failure'
            if isinstance(e, RuntimeError) and 'blocked' in str(e).lower():
                category = 'blocked_preflight'
            record_error(report, category, str(e))
        report['status'] = 'failed_or_blocked'
        # Attempt to write available artifacts
        try:
            if links:
                (out_dir / 'links.json').write_text(json.dumps(links, indent=2))
            if observations:
                (out_dir / 'observations.json').write_text(json.dumps(observations, indent=2))
            if services:
                (out_dir / 'services.json').write_text(json.dumps(services, indent=2))
            if operations_log:
                (out_dir / 'operations.json').write_text(json.dumps(operations_log, indent=2))
        except Exception:
            pass
        try:
            if ns_info:
                ns_info['error'] = str(e)
                (out_dir / 'namespace.json').write_text(json.dumps(ns_info, indent=2))
        except Exception:
            pass
        (out_dir / 'report.json').write_text(json.dumps(report, indent=2))
        return 1
    finally:
        # Cleanup order: capture, server, actor, fd
        if 'capture' in locals() and capture is not None and capture.poll() is None:
            capture.send_signal(2)
            try:
                capture.wait(timeout=5)
            except subprocess.TimeoutExpired:
                capture.kill()
                capture.wait(timeout=5)
        if 'server' in locals() and server is not None and server.poll() is None:
            server.stdin.close()
            try:
                server.wait(timeout=2)
            except subprocess.TimeoutExpired:
                server.terminate()
                server.wait(timeout=2)
        if 'actor' in locals() and actor is not None and not actor.closed:
            try:
                actor.close()
            except Exception:
                pass
        if 'fd' in locals() and fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass


if __name__ == '__main__':
    sys.exit(main())

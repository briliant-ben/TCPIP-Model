; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_octet () Int)
(declare-fun choice_0 () Int)
(declare-fun v_1_octet () Int)
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(declare-fun input_0_peek_offset () Int)
(declare-fun input_0_peek_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= 0 v_0_octet))
(assert
 (= choice_0 0))
(assert
 (let (($x57 (= choice_0 (- 1))))
 (let (($x58 (and $x57 (= state_1 state_0) (= now_1 now_0) (= v_1_octet v_0_octet))))
 (let (($x42 (>= input_0_peek_offset 0)))
 (let ((?x48 (ite (and $x42 (< input_0_peek_offset (seq.len input_0_peek_data))) (ubv_to_int (seq.nth input_0_peek_data input_0_peek_offset)) 0)))
 (let (($x49 (= choice_0 0)))
 (let (($x40 (>= now_1 now_0)))
 (let (($x15 (= state_0 0)))
 (let (($x52 (and and $x15 $x40 true $x49 (= 0 state_1) (= v_1_octet ?x48))))
 (or $x52 $x58))))))))))
(assert
 (>= choice_0 0))
(check-sat)

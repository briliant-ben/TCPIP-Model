#define STRING_COUNT 17
/* Native support primitives. Protocol guards/actions are generated C below. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#define LOG_CAP 131072
#define FIELD_CAP 64
#define SEQ_MOD INT64_C(4294967296)
typedef struct { char data[LOG_CAP]; size_t size; } Buffer;
const char *failure = NULL;
void text(Buffer *b, const char *s) {
    size_t n=strlen(s);
    if(n>=LOG_CAP-b->size) { failure="output_capacity"; return; }
    memcpy(b->data+b->size,s,n+1); b->size+=n;
}
void number(Buffer *b,int64_t n) { char s[32]; snprintf(s,sizeof(s),"%" PRId64,n); text(b,s); }
int64_t add(int64_t a,int64_t b) {
    if((b>0 && a>INT64_MAX-b)||(b<0 && a<INT64_MIN-b)) {failure="integer_overflow";return 0;}
    return a+b;
}
int64_t sub(int64_t a,int64_t b) {
    if((b>0 && a<INT64_MIN+b)||(b<0 && a>INT64_MAX+b)) {failure="integer_overflow";return 0;}
    return a-b;
}
int64_t mul(int64_t a,int64_t b) {
    if(a==0||b==0)return 0;
    if((a==-1&&b==INT64_MIN)||(b==-1&&a==INT64_MIN)) {failure="integer_overflow";return 0;}
    if((a>0 && b>0 && a>INT64_MAX/b)||(a>0 && b<0 && b<INT64_MIN/a)||
       (a<0 && b>0 && a<INT64_MIN/b)||(a<0 && b<0 && a<INT64_MAX/b)) {
        failure="integer_overflow";return 0;
    }
    return a*b;
}
int64_t seqadd(int64_t a,int64_t b) {
    int64_t n=(a+b%SEQ_MOD)%SEQ_MOD; return n<0?n+SEQ_MOD:n;
}
int64_t distance(int64_t a,int64_t b) { return (b-a+SEQ_MOD)%SEQ_MOD; }
int64_t minimum(int64_t a,int64_t b) { return a<b?a:b; }
int valid(int64_t n,int kind) {
    return kind==0 || (kind==1 && (n==0||n==1)) || (kind==2 && n>=0 && n<SEQ_MOD) || (kind==4 && n>=0 && n<STRING_COUNT);
}

void json_string(Buffer *out,const char *s) {
    const unsigned char *p=(const unsigned char *)s;char escaped[8];
    text(out,"\"");
    for(;*p;p++) {
        if(*p=='"'||*p=='\\'){escaped[0]='\\';escaped[1]=(char)*p;escaped[2]=0;text(out,escaped);}
        else if(*p<32){snprintf(escaped,sizeof(escaped),"\\u%04x",*p);text(out,escaped);}
        else {escaped[0]=(char)*p;escaped[1]=0;text(out,escaped);}
    }
    text(out,"\"");
}
/* Bytes are value types. Capacity is an explicit execution domain, never silent
   truncation. IR slice arguments are OFFSET and COUNT, clamped independently. */
#define BYTE_CAP 4096
#define INPUT_CAP (2*BYTE_CAP*FIELD_CAP+4096)
typedef struct { size_t len; unsigned char data[BYTE_CAP]; } Bytes;
Bytes byte_literal(const unsigned char *p,size_t n) {
    Bytes out={0};
    if(n>BYTE_CAP){failure="byte_capacity";return out;}
    out.len=n;if(n)memcpy(out.data,p,n);return out;
}
Bytes byte_concat(Bytes a,Bytes b) {
    Bytes out={0};
    if(a.len>BYTE_CAP||b.len>BYTE_CAP||b.len>BYTE_CAP-a.len){failure="byte_capacity";return out;}
    out.len=a.len+b.len;memcpy(out.data,a.data,a.len);memcpy(out.data+a.len,b.data,b.len);return out;
}
Bytes byte_slice(Bytes a,int64_t offset,int64_t count) {
    Bytes out={0};size_t start,n;
    if(a.len>BYTE_CAP){failure="byte_capacity";return out;}
    start=offset<0?0:(uint64_t)offset>a.len?a.len:(size_t)offset;
    n=count<0?0:(uint64_t)count>a.len-start?a.len-start:(size_t)count;
    out.len=n;if(n)memcpy(out.data,a.data+start,n);return out;
}
int byte_equal(Bytes a,Bytes b) {return a.len==b.len&&memcmp(a.data,b.data,a.len)==0;}
int64_t byte_at_or_zero(Bytes a,int64_t offset) {
    if(a.len>BYTE_CAP){failure="byte_capacity";return 0;}
    if(offset<0||(uint64_t)offset>=a.len)return 0;
    return a.data[(size_t)offset];
}
Bytes byte_pack8(int64_t n) {
    unsigned char b[1]={(uint8_t)n};return byte_literal(b,1);
}
Bytes byte_pack16be(int64_t n) {
    uint16_t v=(uint16_t)n;unsigned char b[2]={(unsigned char)(v>>8),(unsigned char)(v&255)};
    return byte_literal(b,2);
}
int64_t byte_checksum16(Bytes a) {
    size_t i;uint32_t sum=0;
    if(a.len>BYTE_CAP){failure="byte_capacity";return 0;}
    for(i=0;i<a.len;i+=2){
        uint32_t word=((uint32_t)a.data[i]<<8)+(i+1<a.len?a.data[i+1]:0);
        sum+=word;sum=(sum&UINT32_C(65535))+(sum>>16);
    }
    return (int64_t)(UINT32_C(65535)-sum);
}
void byte_json(Buffer *out,Bytes a) {
    size_t i;text(out,"[");for(i=0;i<a.len;i++){if(i)text(out,",");number(out,a.data[i]);}text(out,"]");
}
int byte_nibble(char c) {
    if(c>='0'&&c<='9')return c-'0';
    if(c>='a'&&c<='f')return c-'a'+10;
    if(c>='A'&&c<='F')return c-'A'+10;
    return -1;
}
int parse_bytes(const char *s,Bytes *out) {
    size_t n,i;*out=(Bytes){0};
    if(!s||s[0]!='b'||s[1]!=':'){failure="invalid_bytes_token";return 0;}
    n=strlen(s+2);
    if(n%2){failure="invalid_bytes_token";return 0;}
    if(n/2>BYTE_CAP){failure="byte_capacity";return 0;}
    for(i=0;i<n/2;i++){
        int a=byte_nibble(s[2+2*i]),b=byte_nibble(s[3+2*i]);
        if(a<0||b<0){failure="invalid_bytes_token";return 0;}out->data[i]=(unsigned char)((a<<4)|b);
    }
    out->len=n/2;return 1;
}

enum { NV=22, NB=4, NT=3 };
typedef struct { int state; int64_t now,v[NV?NV:1],due[NT?NT:1]; Bytes b[NB?NB:1]; int active[NT?NT:1]; } Machine;
const char *state_names[]={"\103\114\117\123\105\104","\114\111\123\124\105\116","\123\131\116\055\123\105\116\124","\123\131\116\055\122\105\103\105\111\126\105\104","\105\123\124\101\102\114\111\123\110\105\104","\106\111\116\055\127\101\111\124\055\061","\106\111\116\055\127\101\111\124\055\062","\103\114\117\123\105\055\127\101\111\124","\103\114\117\123\111\116\107","\114\101\123\124\055\101\103\113","\124\111\115\105\055\127\101\111\124"};
const char *event_names[]={"\141\160\160\056\143\157\156\156\145\143\164","\141\160\160\056\154\151\163\164\145\156","\141\160\160\056\143\154\157\163\145","\141\160\160\056\141\142\157\162\164","\156\145\164\056\163\171\156","\156\145\164\056\163\171\156\141\143\153","\156\145\164\056\141\143\153","\156\145\164\056\146\151\156","\156\145\164\056\162\163\164","\156\145\164\056\162\163\164\141\143\153","\164\151\155\145\162\056\162\164\170","\164\151\155\145\162\056\165\163\145\162","\164\151\155\145\162\056\164\151\155\145\137\167\141\151\164","\141\160\160\056\163\145\156\144","\141\160\160\056\164\162\141\156\163\155\151\164","\141\160\160\056\162\145\143\145\151\166\145","\156\145\164\056\144\141\164\141"};
const char *timer_names[]={"\162\164\170","\165\163\145\162","\164\151\155\145\137\167\141\151\164"};
int event_origin[]={0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0};
int event_fields[]={0,0,0,0,1,3,3,2,1,2,0,0,0,1,0,1,4};
int event_kinds[17][FIELD_CAP]={{0},{0},{0},{0},{2},{2,2,0},{2,2,0},{2,2},{2},{2,2},{0},{0},{0},{3},{0},{0},{2,2,0,3}};
int timer_events[]={10,11,12};
int variable_kinds[]={2,2,2,2,2,2,2,4,0,0,1,0,0,0,3,3,3,0,2,2,0,3};
int variable_byte_index[]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,1,2,-1,-1,-1,-1,3};
const char *variable_names[]={"\151\163\163","\151\162\163","\163\156\144\137\165\156\141","\163\156\144\137\156\170\164","\162\143\166\137\156\170\164","\164\170\137\163\145\161","\164\170\137\141\143\153","\164\170\137\146\154\141\147\163","\162\164\157\137\155\163","\162\145\164\162\151\145\163","\141\143\164\151\166\145\137\157\160\145\156","\165\163\145\162\137\164\151\155\145\157\165\164\137\155\163","\155\163\154\137\155\163","\154\157\143\141\154\137\167\151\156\144\157\167","\163\156\144\137\142\165\146","\162\164\170\137\142\165\146","\162\143\166\137\142\165\146","\163\156\144\137\167\156\144","\163\156\144\137\167\154\061","\163\156\144\137\167\154\062","\164\141\153\145","\162\170\137\143\150\165\156\153"};
const char *source_json_strings[]={"\042\101\042","\042\106\101\042","\042\122\042","\042\122\101\042","\042\123\042","\042\123\101\042","\042\141\142\157\162\164\145\144\042","\042\141\154\162\145\141\144\171\137\143\154\157\163\151\156\147\042","\042\143\154\157\163\145\144\042","\042\143\157\156\156\145\143\164\145\144\042","\042\145\155\160\164\171\137\163\145\156\144\042","\042\160\145\145\162\137\145\157\146\042","\042\161\165\145\165\145\144\042","\042\162\145\146\165\163\145\144\042","\042\162\145\163\145\164\042","\042\163\145\156\144\137\142\165\146\146\145\162\137\146\165\154\154\042","\042\164\151\155\145\157\165\164\042"};
const char *source_json(int64_t i) { if(i<0||i>=STRING_COUNT){failure="string_domain";return "\042\042";}return source_json_strings[i];}
void initialize(Machine *m) { memset(m,0,sizeof(*m)); m->state=0;
m->v[0]=INT64_C(1000);
m->v[1]=INT64_C(0);
m->v[2]=INT64_C(1000);
m->v[3]=INT64_C(1000);
m->v[4]=INT64_C(0);
m->v[5]=INT64_C(1000);
m->v[6]=INT64_C(0);
m->v[7]=4;
m->v[8]=INT64_C(1000);
m->v[9]=INT64_C(0);
m->v[10]=1;
m->v[11]=INT64_C(30000);
m->v[12]=INT64_C(60000);
m->v[13]=INT64_C(16);
m->b[0]=byte_literal((const unsigned char[]){0},0);
m->b[1]=byte_literal((const unsigned char[]){0},0);
m->b[2]=byte_literal((const unsigned char[]){0},0);
m->v[17]=INT64_C(8);
m->v[18]=INT64_C(0);
m->v[19]=INT64_C(0);
m->v[20]=INT64_C(0);
m->b[3]=byte_literal((const unsigned char[]){0},0);
}
int invariants(Machine *m) { (void)m; if(failure)return 0;
if(!((!(m->state==0)||(m->active[0]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\105\104\055\162\164\170";return 0;}
if(!((!(m->state==0)||(m->active[1]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\105\104\055\165\163\145\162";return 0;}
if(!((!(m->state==0)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\105\104\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==1)||(m->active[0]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\114\111\123\124\105\116\055\162\164\170";return 0;}
if(!((!(m->state==1)||(m->active[1]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\114\111\123\124\105\116\055\165\163\145\162";return 0;}
if(!((!(m->state==1)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\114\111\123\124\105\116\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==2)||(m->active[0]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\123\131\116\055\123\105\116\124\055\162\164\170";return 0;}
if(!((!(m->state==2)||(m->active[1]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\123\131\116\055\123\105\116\124\055\165\163\145\162";return 0;}
if(!((!(m->state==2)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\123\131\116\055\123\105\116\124\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==3)||(m->active[0]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\123\131\116\055\122\105\103\105\111\126\105\104\055\162\164\170";return 0;}
if(!((!(m->state==3)||(m->active[1]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\123\131\116\055\122\105\103\105\111\126\105\104\055\165\163\145\162";return 0;}
if(!((!(m->state==3)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\123\131\116\055\122\105\103\105\111\126\105\104\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==4)||(m->active[1]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\105\123\124\101\102\114\111\123\110\105\104\055\165\163\145\162";return 0;}
if(!((!(m->state==4)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\105\123\124\101\102\114\111\123\110\105\104\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==5)||(m->active[0]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\106\111\116\055\127\101\111\124\055\061\055\162\164\170";return 0;}
if(!((!(m->state==5)||(m->active[1]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\106\111\116\055\127\101\111\124\055\061\055\165\163\145\162";return 0;}
if(!((!(m->state==5)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\106\111\116\055\127\101\111\124\055\061\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==6)||(m->active[0]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\106\111\116\055\127\101\111\124\055\062\055\162\164\170";return 0;}
if(!((!(m->state==6)||(m->active[1]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\106\111\116\055\127\101\111\124\055\062\055\165\163\145\162";return 0;}
if(!((!(m->state==6)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\106\111\116\055\127\101\111\124\055\062\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==7)||(m->active[0]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\105\055\127\101\111\124\055\162\164\170";return 0;}
if(!((!(m->state==7)||(m->active[1]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\105\055\127\101\111\124\055\165\163\145\162";return 0;}
if(!((!(m->state==7)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\105\055\127\101\111\124\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==8)||(m->active[0]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\111\116\107\055\162\164\170";return 0;}
if(!((!(m->state==8)||(m->active[1]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\111\116\107\055\165\163\145\162";return 0;}
if(!((!(m->state==8)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\103\114\117\123\111\116\107\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==9)||(m->active[0]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\114\101\123\124\055\101\103\113\055\162\164\170";return 0;}
if(!((!(m->state==9)||(m->active[1]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\114\101\123\124\055\101\103\113\055\165\163\145\162";return 0;}
if(!((!(m->state==9)||(m->active[2]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\114\101\123\124\055\101\103\113\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(m->state==10)||(m->active[0]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\124\111\115\105\055\127\101\111\124\055\162\164\170";return 0;}
if(!((!(m->state==10)||(m->active[1]==0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\124\111\115\105\055\127\101\111\124\055\165\163\145\162";return 0;}
if(!((!(m->state==10)||(m->active[2]==1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\124\111\115\105\122\055\124\111\115\105\055\127\101\111\124\055\164\151\155\145\137\167\141\151\164";return 0;}
if(!((!(((((0||(m->state==2))||(m->state==3))||(m->state==5))||(m->state==8))||(m->state==9))||((m->v[3]==seqadd(m->v[5],INT64_C(1)))&&(m->v[2]==m->v[5]))))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\117\125\124\123\124\101\116\104\111\116\107\055\103\117\116\124\122\117\114";return 0;}
if(!((m->v[8]>=INT64_C(1000)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\102\117\125\116\104\055\162\164\157\137\155\163";return 0;}
if(!((m->v[9]>=INT64_C(0)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\102\117\125\116\104\055\162\145\164\162\151\145\163";return 0;}
if(!((m->v[12]>=INT64_C(1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\102\117\125\116\104\055\155\163\154\137\155\163";return 0;}
if(!((m->v[11]>=INT64_C(1)))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\102\117\125\116\104\055\165\163\145\162\137\164\151\155\145\157\165\164\137\155\163";return 0;}
if(!((!(m->state==2)||(m->v[2]==m->v[0])))) {failure="\151\156\166\141\162\151\141\156\164\072\103\055\111\116\126\055\123\131\116\055\123\105\116\124\055\111\123\123";return 0;}
if(!((!(m->state==4)||(m->active[0]==(((int64_t)(m->b[1]).len)>=INT64_C(1)))))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\124\111\115\105\122";return 0;}
if(!((!(m->state==4)||(m->v[3]==seqadd(m->v[2],((int64_t)(m->b[1]).len)))))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\123\105\121\125\105\116\103\105\055\102\125\106\106\105\122";return 0;}
if(!((add(((int64_t)(m->b[0]).len),((int64_t)(m->b[1]).len))<=INT64_C(16)))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\123\105\116\104\055\103\101\120\101\103\111\124\131";return 0;}
if(!((((int64_t)(m->b[2]).len)<=INT64_C(16)))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\122\105\103\105\111\126\105\055\103\101\120\101\103\111\124\131";return 0;}
if(!(((1&&(m->v[17]>=INT64_C(0)))&&(m->v[17]<=INT64_C(65535))))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\127\111\116\104\117\127";return 0;}
if(!((!(!(m->state==4))||(((1&&(((int64_t)(m->b[0]).len)==INT64_C(0)))&&(((int64_t)(m->b[1]).len)==INT64_C(0)))&&(((int64_t)(m->b[2]).len)==INT64_C(0)))))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\116\117\055\104\101\124\101\055\117\125\124\123\111\104\105\055\105\123\124\101\102\114\111\123\110\105\104";return 0;}
if(!((m->v[13]==sub(INT64_C(16),((int64_t)(m->b[2]).len))))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\101\104\126\105\122\124\111\123\105\104\055\127\111\116\104\117\127";return 0;}
if(!((!(((0||(m->state==7))||(m->state==6))||(m->state==10))||(m->v[2]==m->v[3])))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\103\117\116\124\122\117\114\055\104\122\101\111\116\105\104";return 0;}
if(!((((int64_t)(m->b[1]).len)<=m->v[17]))) {failure="\151\156\166\141\162\151\141\156\164\072\104\055\111\116\126\055\106\114\111\107\110\124\055\127\111\116\104\117\127";return 0;}
return failure==NULL; }
void snapshot(Buffer *out,Machine *m) { int first=1;
text(out,"\173\042\163\164\141\164\145\042\072");
switch(m->state) {
case 0:
text(out,"\042\103\114\117\123\105\104\042");
break;
case 1:
text(out,"\042\114\111\123\124\105\116\042");
break;
case 2:
text(out,"\042\123\131\116\055\123\105\116\124\042");
break;
case 3:
text(out,"\042\123\131\116\055\122\105\103\105\111\126\105\104\042");
break;
case 4:
text(out,"\042\105\123\124\101\102\114\111\123\110\105\104\042");
break;
case 5:
text(out,"\042\106\111\116\055\127\101\111\124\055\061\042");
break;
case 6:
text(out,"\042\106\111\116\055\127\101\111\124\055\062\042");
break;
case 7:
text(out,"\042\103\114\117\123\105\055\127\101\111\124\042");
break;
case 8:
text(out,"\042\103\114\117\123\111\116\107\042");
break;
case 9:
text(out,"\042\114\101\123\124\055\101\103\113\042");
break;
case 10:
text(out,"\042\124\111\115\105\055\127\101\111\124\042");
break;
default:failure="invalid_state";}
text(out,"\054\042\166\141\162\151\141\142\154\145\163\042\072\173");
text(out,"\042\151\163\163\042\072");
number(out,m->v[0]);
text(out,"\054\042\151\162\163\042\072");
number(out,m->v[1]);
text(out,"\054\042\163\156\144\137\165\156\141\042\072");
number(out,m->v[2]);
text(out,"\054\042\163\156\144\137\156\170\164\042\072");
number(out,m->v[3]);
text(out,"\054\042\162\143\166\137\156\170\164\042\072");
number(out,m->v[4]);
text(out,"\054\042\164\170\137\163\145\161\042\072");
number(out,m->v[5]);
text(out,"\054\042\164\170\137\141\143\153\042\072");
number(out,m->v[6]);
text(out,"\054\042\164\170\137\146\154\141\147\163\042\072");
text(out,source_json(m->v[7]));
text(out,"\054\042\162\164\157\137\155\163\042\072");
number(out,m->v[8]);
text(out,"\054\042\162\145\164\162\151\145\163\042\072");
number(out,m->v[9]);
text(out,"\054\042\141\143\164\151\166\145\137\157\160\145\156\042\072");
text(out,m->v[10]?"true":"false");
text(out,"\054\042\165\163\145\162\137\164\151\155\145\157\165\164\137\155\163\042\072");
number(out,m->v[11]);
text(out,"\054\042\155\163\154\137\155\163\042\072");
number(out,m->v[12]);
text(out,"\054\042\154\157\143\141\154\137\167\151\156\144\157\167\042\072");
number(out,m->v[13]);
text(out,"\054\042\163\156\144\137\142\165\146\042\072");
byte_json(out,m->b[0]);
text(out,"\054\042\162\164\170\137\142\165\146\042\072");
byte_json(out,m->b[1]);
text(out,"\054\042\162\143\166\137\142\165\146\042\072");
byte_json(out,m->b[2]);
text(out,"\054\042\163\156\144\137\167\156\144\042\072");
number(out,m->v[17]);
text(out,"\054\042\163\156\144\137\167\154\061\042\072");
number(out,m->v[18]);
text(out,"\054\042\163\156\144\137\167\154\062\042\072");
number(out,m->v[19]);
text(out,"\054\042\164\141\153\145\042\072");
number(out,m->v[20]);
text(out,"\054\042\162\170\137\143\150\165\156\153\042\072");
byte_json(out,m->b[3]);
text(out,"\175\054\042\164\151\155\145\162\163\042\072\173");
if(m->active[0]) { if(!first)text(out,",");first=0;
text(out,"\042\162\164\170\042\072");
number(out,m->due[0]);}
if(m->active[1]) { if(!first)text(out,",");first=0;
text(out,"\042\165\163\145\162\042\072");
number(out,m->due[1]);}
if(m->active[2]) { if(!first)text(out,",");first=0;
text(out,"\042\164\151\155\145\137\167\141\151\164\042\072");
number(out,m->due[2]);}
(void)first;
text(out,"\175\175");
}
int fire(Machine *m,int event,int64_t *f,Bytes *bf,int expiring,Buffer *log) { int match=-1,count=0; Buffer messages={{0},0}; int emitted=0; (void)f; (void)bf; (void)emitted;
if(m->state==0&&event==0&&(1)) {match=0;count++;}
if(m->state==0&&event==1&&(1)) {match=1;count++;}
if(m->state==1&&event==4&&(1)) {match=2;count++;}
if(m->state==2&&event==4&&(1)) {match=3;count++;}
if(m->state==2&&event==5&&((((f[1]==m->v[3])&&(m->v[9]==INT64_C(0)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=4;count++;}
if(m->state==3&&event==6&&(((((f[1]==m->v[3])&&(f[0]==m->v[4]))&&(m->v[9]==INT64_C(0)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=5;count++;}
if(m->state==3&&event==5&&(((((f[1]==m->v[3])&&(f[0]==m->v[1]))&&(m->v[9]==INT64_C(0)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=6;count++;}
if(m->state==2&&event==5&&((((f[1]==m->v[3])&&(m->v[9]==INT64_C(1)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=7;count++;}
if(m->state==3&&event==6&&(((((f[1]==m->v[3])&&(f[0]==m->v[4]))&&(m->v[9]==INT64_C(1)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=8;count++;}
if(m->state==3&&event==5&&(((((f[1]==m->v[3])&&(f[0]==m->v[1]))&&(m->v[9]==INT64_C(1)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=9;count++;}
if(m->state==2&&event==5&&((((f[1]==m->v[3])&&(m->v[9]>=INT64_C(2)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=10;count++;}
if(m->state==3&&event==6&&(((((f[1]==m->v[3])&&(f[0]==m->v[4]))&&(m->v[9]>=INT64_C(2)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=11;count++;}
if(m->state==3&&event==5&&(((((f[1]==m->v[3])&&(f[0]==m->v[1]))&&(m->v[9]>=INT64_C(2)))&&((1&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))))) {match=12;count++;}
if(m->state==2&&event==6&&((f[1]!=m->v[3]))) {match=13;count++;}
if(m->state==2&&event==5&&((f[1]!=m->v[3]))) {match=14;count++;}
if(m->state==2&&event==6&&((f[1]==m->v[3]))) {match=15;count++;}
if(m->state==3&&event==6&&(((f[0]==m->v[4])&&(f[1]!=m->v[3])))) {match=16;count++;}
if(m->state==4&&event==2&&((1&&(((1&&(((int64_t)(m->b[0]).len)==INT64_C(0)))&&(((int64_t)(m->b[1]).len)==INT64_C(0)))&&(((int64_t)(m->b[2]).len)==INT64_C(0)))))) {match=17;count++;}
if(m->state==7&&event==2&&(1)) {match=18;count++;}
if(m->state==1&&event==2&&(1)) {match=19;count++;}
if(m->state==2&&event==2&&(1)) {match=20;count++;}
if(m->state==5&&event==2&&(1)) {match=21;count++;}
if(m->state==6&&event==2&&(1)) {match=22;count++;}
if(m->state==8&&event==2&&(1)) {match=23;count++;}
if(m->state==9&&event==2&&(1)) {match=24;count++;}
if(m->state==10&&event==2&&(1)) {match=25;count++;}
if(m->state==7&&event==6&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=26;count++;}
if(m->state==6&&event==6&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=27;count++;}
if(m->state==5&&event==6&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=28;count++;}
if(m->state==5&&event==6&&(((f[0]==m->v[4])&&(f[1]==m->v[2])))) {match=29;count++;}
if(m->state==8&&event==6&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=30;count++;}
if(m->state==8&&event==6&&(((f[0]==m->v[4])&&(f[1]==m->v[2])))) {match=31;count++;}
if(m->state==9&&event==6&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=32;count++;}
if(m->state==9&&event==6&&(((f[0]==m->v[4])&&(f[1]==m->v[2])))) {match=33;count++;}
if(m->state==4&&event==7&&((((f[1]==m->v[3])&&(f[0]==m->v[4]))&&(((1&&(((int64_t)(m->b[0]).len)==INT64_C(0)))&&(((int64_t)(m->b[1]).len)==INT64_C(0)))&&(((int64_t)(m->b[2]).len)==INT64_C(0)))))) {match=34;count++;}
if(m->state==6&&event==7&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=35;count++;}
if(m->state==5&&event==7&&(((f[1]==m->v[3])&&(f[0]==m->v[4])))) {match=36;count++;}
if(m->state==5&&event==7&&(((f[0]==m->v[4])&&(f[1]==m->v[2])))) {match=37;count++;}
if(m->state==7&&event==7&&(((seqadd(f[0],INT64_C(1))==m->v[4])&&((f[1]==m->v[2])||(f[1]==m->v[3]))))) {match=38;count++;}
if(m->state==8&&event==7&&(((seqadd(f[0],INT64_C(1))==m->v[4])&&((f[1]==m->v[2])||(f[1]==m->v[3]))))) {match=39;count++;}
if(m->state==9&&event==7&&(((seqadd(f[0],INT64_C(1))==m->v[4])&&((f[1]==m->v[2])||(f[1]==m->v[3]))))) {match=40;count++;}
if(m->state==10&&event==7&&(((seqadd(f[0],INT64_C(1))==m->v[4])&&((f[1]==m->v[2])||(f[1]==m->v[3]))))) {match=41;count++;}
if(m->state==2&&event==10&&(1)) {match=42;count++;}
if(m->state==3&&event==10&&(1)) {match=43;count++;}
if(m->state==5&&event==10&&(1)) {match=44;count++;}
if(m->state==8&&event==10&&(1)) {match=45;count++;}
if(m->state==9&&event==10&&(1)) {match=46;count++;}
if(m->state==2&&event==11&&(1)) {match=47;count++;}
if(m->state==3&&event==11&&(1)) {match=48;count++;}
if(m->state==5&&event==11&&(1)) {match=49;count++;}
if(m->state==6&&event==11&&(1)) {match=50;count++;}
if(m->state==8&&event==11&&(1)) {match=51;count++;}
if(m->state==9&&event==11&&(1)) {match=52;count++;}
if(m->state==10&&event==12&&(1)) {match=53;count++;}
if(m->state==0&&event==3&&(1)) {match=54;count++;}
if(m->state==1&&event==3&&(1)) {match=55;count++;}
if(m->state==2&&event==3&&(1)) {match=56;count++;}
if(m->state==3&&event==3&&(1)) {match=57;count++;}
if(m->state==4&&event==3&&(1)) {match=58;count++;}
if(m->state==5&&event==3&&(1)) {match=59;count++;}
if(m->state==6&&event==3&&(1)) {match=60;count++;}
if(m->state==7&&event==3&&(1)) {match=61;count++;}
if(m->state==8&&event==3&&(1)) {match=62;count++;}
if(m->state==9&&event==3&&(1)) {match=63;count++;}
if(m->state==10&&event==3&&(1)) {match=64;count++;}
if(m->state==0&&event==8&&(1)) {match=65;count++;}
if(m->state==1&&event==8&&(1)) {match=66;count++;}
if(m->state==2&&event==8&&(1)) {match=67;count++;}
if(m->state==3&&event==8&&(((f[0]==m->v[4])&&(m->v[10]==0)))) {match=68;count++;}
if(m->state==3&&event==8&&(((f[0]==m->v[4])&&(m->v[10]==1)))) {match=69;count++;}
if(m->state==4&&event==8&&((f[0]==m->v[4]))) {match=70;count++;}
if(m->state==5&&event==8&&((f[0]==m->v[4]))) {match=71;count++;}
if(m->state==6&&event==8&&((f[0]==m->v[4]))) {match=72;count++;}
if(m->state==7&&event==8&&((f[0]==m->v[4]))) {match=73;count++;}
if(m->state==8&&event==8&&((f[0]==m->v[4]))) {match=74;count++;}
if(m->state==9&&event==8&&((f[0]==m->v[4]))) {match=75;count++;}
if(m->state==10&&event==8&&((f[0]==m->v[4]))) {match=76;count++;}
if(m->state==0&&event==9&&(1)) {match=77;count++;}
if(m->state==1&&event==9&&(1)) {match=78;count++;}
if(m->state==2&&event==9&&((f[1]==m->v[3]))) {match=79;count++;}
if(m->state==3&&event==9&&(((f[0]==m->v[4])&&(m->v[10]==0)))) {match=80;count++;}
if(m->state==3&&event==9&&(((f[0]==m->v[4])&&(m->v[10]==1)))) {match=81;count++;}
if(m->state==4&&event==9&&((f[0]==m->v[4]))) {match=82;count++;}
if(m->state==5&&event==9&&((f[0]==m->v[4]))) {match=83;count++;}
if(m->state==6&&event==9&&((f[0]==m->v[4]))) {match=84;count++;}
if(m->state==7&&event==9&&((f[0]==m->v[4]))) {match=85;count++;}
if(m->state==8&&event==9&&((f[0]==m->v[4]))) {match=86;count++;}
if(m->state==9&&event==9&&((f[0]==m->v[4]))) {match=87;count++;}
if(m->state==10&&event==9&&((f[0]==m->v[4]))) {match=88;count++;}
if(m->state==0&&event==6&&(1)) {match=89;count++;}
if(m->state==1&&event==6&&(1)) {match=90;count++;}
if(m->state==0&&event==5&&(1)) {match=91;count++;}
if(m->state==1&&event==5&&(1)) {match=92;count++;}
if(m->state==0&&event==7&&(1)) {match=93;count++;}
if(m->state==1&&event==7&&(1)) {match=94;count++;}
if(m->state==0&&event==4&&(1)) {match=95;count++;}
if(m->state==4&&event==13&&(((1&&(((int64_t)(bf[0]).len)>=INT64_C(1)))&&(add(add(((int64_t)(m->b[0]).len),((int64_t)(m->b[1]).len)),((int64_t)(bf[0]).len))<=INT64_C(16))))) {match=96;count++;}
if(m->state==4&&event==13&&((((int64_t)(bf[0]).len)==INT64_C(0)))) {match=97;count++;}
if(m->state==4&&event==13&&((add(add(((int64_t)(m->b[0]).len),((int64_t)(m->b[1]).len)),((int64_t)(bf[0]).len))>=INT64_C(17)))) {match=98;count++;}
if(m->state==4&&event==14&&(((1&&((1&&(((int64_t)(m->b[0]).len)>=INT64_C(1)))&&(sub(m->v[17],((int64_t)(m->b[1]).len))>=INT64_C(1))))&&(((int64_t)(m->b[1]).len)==INT64_C(0))))) {match=99;count++;}
if(m->state==4&&event==14&&(((1&&((1&&(((int64_t)(m->b[0]).len)>=INT64_C(1)))&&(sub(m->v[17],((int64_t)(m->b[1]).len))>=INT64_C(1))))&&(((int64_t)(m->b[1]).len)>=INT64_C(1))))) {match=100;count++;}
if(m->state==4&&event==14&&((!((1&&(((int64_t)(m->b[0]).len)>=INT64_C(1)))&&(sub(m->v[17],((int64_t)(m->b[1]).len))>=INT64_C(1)))))) {match=101;count++;}
if(m->state==4&&event==6&&((((((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&((1&&(distance(m->v[2],f[1])>=INT64_C(1)))&&(distance(m->v[2],f[1])<=((int64_t)(m->b[1]).len))))&&(distance(m->v[2],f[1])==((int64_t)(m->b[1]).len)))&&(f[2]>=sub(((int64_t)(m->b[1]).len),distance(m->v[2],f[1]))))&&((0||(distance(m->v[18],f[0])>0&&distance(m->v[18],f[0])<INT64_C(2147483648)))||((1&&(m->v[18]==f[0]))&&(distance(m->v[19],f[1])<INT64_C(2147483648))))))) {match=102;count++;}
if(m->state==4&&event==6&&((((((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&((1&&(distance(m->v[2],f[1])>=INT64_C(1)))&&(distance(m->v[2],f[1])<=((int64_t)(m->b[1]).len))))&&(distance(m->v[2],f[1])==((int64_t)(m->b[1]).len)))&&(f[2]>=sub(((int64_t)(m->b[1]).len),distance(m->v[2],f[1]))))&&(!((0||(distance(m->v[18],f[0])>0&&distance(m->v[18],f[0])<INT64_C(2147483648)))||((1&&(m->v[18]==f[0]))&&(distance(m->v[19],f[1])<INT64_C(2147483648)))))))) {match=103;count++;}
if(m->state==4&&event==6&&((((((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&((1&&(distance(m->v[2],f[1])>=INT64_C(1)))&&(distance(m->v[2],f[1])<=((int64_t)(m->b[1]).len))))&&(!(distance(m->v[2],f[1])==((int64_t)(m->b[1]).len))))&&(f[2]>=sub(((int64_t)(m->b[1]).len),distance(m->v[2],f[1]))))&&((0||(distance(m->v[18],f[0])>0&&distance(m->v[18],f[0])<INT64_C(2147483648)))||((1&&(m->v[18]==f[0]))&&(distance(m->v[19],f[1])<INT64_C(2147483648))))))) {match=104;count++;}
if(m->state==4&&event==6&&((((((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&((1&&(distance(m->v[2],f[1])>=INT64_C(1)))&&(distance(m->v[2],f[1])<=((int64_t)(m->b[1]).len))))&&(!(distance(m->v[2],f[1])==((int64_t)(m->b[1]).len))))&&(f[2]>=sub(((int64_t)(m->b[1]).len),distance(m->v[2],f[1]))))&&(!((0||(distance(m->v[18],f[0])>0&&distance(m->v[18],f[0])<INT64_C(2147483648)))||((1&&(m->v[18]==f[0]))&&(distance(m->v[19],f[1])<INT64_C(2147483648)))))))) {match=105;count++;}
if(m->state==4&&event==6&&(((((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&(f[1]==m->v[2]))&&(f[2]>=((int64_t)(m->b[1]).len)))&&((0||(distance(m->v[18],f[0])>0&&distance(m->v[18],f[0])<INT64_C(2147483648)))||((1&&(m->v[18]==f[0]))&&(distance(m->v[19],f[1])<INT64_C(2147483648))))))) {match=106;count++;}
if(m->state==4&&event==6&&(((((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&(f[1]==m->v[2]))&&(f[2]>=((int64_t)(m->b[1]).len)))&&(!((0||(distance(m->v[18],f[0])>0&&distance(m->v[18],f[0])<INT64_C(2147483648)))||((1&&(m->v[18]==f[0]))&&(distance(m->v[19],f[1])<INT64_C(2147483648)))))))) {match=107;count++;}
if(m->state==4&&event==6&&(((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&(distance(f[1],m->v[2])>0&&distance(f[1],m->v[2])<INT64_C(2147483648))))) {match=108;count++;}
if(m->state==4&&event==6&&(((1&&(((((1&&(f[0]==m->v[4]))&&(f[2]>=INT64_C(0)))&&(f[2]<=INT64_C(65535)))&&(distance(m->v[2],f[1])!=INT64_C(2147483648)))&&(distance(m->v[3],f[1])!=INT64_C(2147483648))))&&((distance(m->v[2],f[1])>=add(((int64_t)(m->b[1]).len),INT64_C(1)))&&(distance(m->v[2],f[1])<=INT64_C(2147483647)))))) {match=109;count++;}
if(m->state==4&&event==10&&((((int64_t)(m->b[1]).len)>=INT64_C(1)))) {match=110;count++;}
if(m->state==4&&event==16&&(((((1&&((((1&&(f[1]==m->v[2]))&&(f[2]==m->v[17]))&&(((int64_t)(bf[3]).len)>=INT64_C(1)))&&(((int64_t)(bf[3]).len)<=INT64_C(16))))&&(f[0]==m->v[4]))&&(INT64_C(0)<=sub(((int64_t)(bf[3]).len),INT64_C(1))))&&(sub(INT64_C(16),((int64_t)(m->b[2]).len))>=INT64_C(1))))) {match=111;count++;}
if(m->state==4&&event==16&&(((((1&&((((1&&(f[1]==m->v[2]))&&(f[2]==m->v[17]))&&(((int64_t)(bf[3]).len)>=INT64_C(1)))&&(((int64_t)(bf[3]).len)<=INT64_C(16))))&&(distance(f[0],m->v[4])>0&&distance(f[0],m->v[4])<INT64_C(2147483648)))&&(distance(f[0],m->v[4])<=sub(((int64_t)(bf[3]).len),INT64_C(1))))&&(sub(INT64_C(16),((int64_t)(m->b[2]).len))>=INT64_C(1))))) {match=112;count++;}
if(m->state==4&&event==16&&(((1&&((((1&&(f[1]==m->v[2]))&&(f[2]==m->v[17]))&&(((int64_t)(bf[3]).len)>=INT64_C(1)))&&(((int64_t)(bf[3]).len)<=INT64_C(16))))&&((1&&(distance(f[0],m->v[4])>0&&distance(f[0],m->v[4])<INT64_C(2147483648)))&&(distance(f[0],m->v[4])>=((int64_t)(bf[3]).len)))))) {match=113;count++;}
if(m->state==4&&event==16&&(((1&&((((1&&(f[1]==m->v[2]))&&(f[2]==m->v[17]))&&(((int64_t)(bf[3]).len)>=INT64_C(1)))&&(((int64_t)(bf[3]).len)<=INT64_C(16))))&&(distance(m->v[4],f[0])>0&&distance(m->v[4],f[0])<INT64_C(2147483648))))) {match=114;count++;}
if(m->state==4&&event==16&&((((((1&&((((1&&(f[1]==m->v[2]))&&(f[2]==m->v[17]))&&(((int64_t)(bf[3]).len)>=INT64_C(1)))&&(((int64_t)(bf[3]).len)<=INT64_C(16))))&&(sub(INT64_C(16),((int64_t)(m->b[2]).len))==INT64_C(0)))&&(distance(f[0],m->v[4])!=INT64_C(2147483648)))&&(!((1&&(distance(f[0],m->v[4])>0&&distance(f[0],m->v[4])<INT64_C(2147483648)))&&(distance(f[0],m->v[4])>=((int64_t)(bf[3]).len)))))&&(!(distance(m->v[4],f[0])>0&&distance(m->v[4],f[0])<INT64_C(2147483648)))))) {match=115;count++;}
if(m->state==4&&event==15&&((f[0]>=INT64_C(1)))) {match=116;count++;}
if(failure)return 0;
if(count!=1){failure=count?"rule_conflict":"uncovered_event";return 0;} if(expiring>=0)m->active[expiring]=0; switch(match) {
case 0: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
m->v[8]=INT64_C(1000);
if(failure)return 0;
m->v[9]=INT64_C(0);
if(failure)return 0;
m->v[2]=m->v[0];
if(failure)return 0;
m->v[3]=seqadd(m->v[0],INT64_C(1));
if(failure)return 0;
m->v[10]=1;
if(failure)return 0;
m->v[7]=4;
if(failure)return 0;
m->v[5]=m->v[0];
if(failure)return 0;
m->v[6]=INT64_C(0);
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
{
int64_t delay=m->v[11]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[1]=add(m->now,delay);m->active[1]=1;}
if(failure)return 0;
m->state=2; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\124\111\126\105\055\117\120\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\117\120\105\116\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\157\156\156\145\143\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 1: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
m->v[10]=0;
if(failure)return 0;
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\120\101\123\123\111\126\105\055\117\120\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\117\120\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\154\151\163\164\145\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 2: {
m->v[8]=INT64_C(1000);
if(failure)return 0;
m->v[9]=INT64_C(0);
if(failure)return 0;
m->v[2]=m->v[0];
if(failure)return 0;
m->v[3]=seqadd(m->v[0],INT64_C(1));
if(failure)return 0;
m->v[1]=f[0];
if(failure)return 0;
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[7]=5;
if(failure)return 0;
m->v[5]=m->v[0];
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
{
int64_t delay=m->v[11]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[1]=add(m->now,delay);m->active[1]=1;}
if(failure)return 0;
m->state=3; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\114\111\123\124\105\116\055\123\131\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\114\111\123\124\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 3: {
m->v[1]=f[0];
if(failure)return 0;
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[7]=5;
if(failure)return 0;
m->v[5]=m->v[0];
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=3; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\111\115\125\114\124\101\116\105\117\125\123\055\123\131\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\054\040\042\103\117\116\116\055\123\111\115\125\114\124\101\116\105\117\125\123\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 4: {
m->v[1]=f[0];
if(failure)return 0;
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\103\105\120\124\055\123\131\116\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 5: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\103\105\120\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 6: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\111\115\125\114\124\101\116\105\117\125\123\055\123\131\116\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\111\115\125\114\124\101\116\105\117\125\123\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 7: {
m->v[1]=f[0];
if(failure)return 0;
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[8]=INT64_C(3000);
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\103\105\120\124\055\123\131\116\101\103\113\055\101\106\124\105\122\055\122\105\124\122\131\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 8: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[8]=INT64_C(3000);
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\103\105\120\124\055\101\103\113\055\101\106\124\105\122\055\122\105\124\122\131\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 9: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[8]=INT64_C(3000);
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\111\115\125\114\124\101\116\105\117\125\123\055\123\131\116\101\103\113\055\101\106\124\105\122\055\122\105\124\122\131\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\111\115\125\114\124\101\116\105\117\125\123\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 10: {
m->v[1]=f[0];
if(failure)return 0;
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\103\105\120\124\055\123\131\116\101\103\113\055\101\106\124\105\122\055\115\125\114\124\111\120\114\105\055\122\105\124\122\111\105\123\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 11: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\103\103\105\120\124\055\101\103\113\055\101\106\124\105\122\055\115\125\114\124\111\120\114\105\055\122\105\124\122\111\105\123\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 12: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(9));
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\111\115\125\114\124\101\116\105\117\125\123\055\123\131\116\101\103\113\055\101\106\124\105\122\055\115\125\114\124\111\120\114\105\055\122\105\124\122\111\105\123\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\111\115\125\114\124\101\116\105\117\125\123\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 13: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=2; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\123\105\116\124\055\102\101\104\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 14: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=2; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\123\105\116\124\055\102\101\104\055\123\131\116\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 15: {
m->state=2; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\123\105\116\124\055\102\101\122\105\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 16: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=3; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\122\105\103\105\111\126\105\104\055\102\101\104\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 17: {
m->v[9]=INT64_C(0);
if(failure)return 0;
m->v[7]=1;
if(failure)return 0;
m->v[5]=m->v[3];
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[3]=seqadd(m->v[3],INT64_C(1));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
{
int64_t delay=m->v[11]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[1]=add(m->now,delay);m->active[1]=1;}
if(failure)return 0;
m->state=5; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\103\114\117\123\105\055\105\123\124\101\102\114\111\123\110\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 18: {
m->v[9]=INT64_C(0);
if(failure)return 0;
m->v[7]=1;
if(failure)return 0;
m->v[5]=m->v[3];
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[3]=seqadd(m->v[3],INT64_C(1));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
{
int64_t delay=m->v[11]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[1]=add(m->now,delay);m->active[1]=1;}
if(failure)return 0;
m->state=9; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\103\114\117\123\105\055\103\114\117\123\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 19: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(8));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\103\114\117\123\105\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 20: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(8));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\103\114\117\123\105\055\123\131\116\055\123\105\116\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 21: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(7));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=5; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\120\105\101\124\105\104\055\103\114\117\123\105\055\106\111\116\055\127\101\111\124\055\061\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 22: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(7));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=6; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\120\105\101\124\105\104\055\103\114\117\123\105\055\106\111\116\055\127\101\111\124\055\062\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 23: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(7));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=8; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\120\105\101\124\105\104\055\103\114\117\123\105\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 24: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(7));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=9; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\120\105\101\124\105\104\055\103\114\117\123\105\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 25: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(7));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=10; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\120\105\101\124\105\104\055\103\114\117\123\105\055\124\111\115\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\154\157\163\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 26: {
m->state=7; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\104\125\120\114\111\103\101\124\105\055\101\103\113\055\103\114\117\123\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 27: {
m->state=6; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\104\125\120\114\111\103\101\124\105\055\101\103\113\055\106\111\116\055\127\101\111\124\055\062\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 28: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
m->state=6; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\106\111\116\055\101\103\113\055\106\111\116\055\127\101\111\124\055\061\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 29: {
m->state=5; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\117\114\104\055\101\103\113\055\106\111\116\055\127\101\111\124\055\061\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 30: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
int64_t delay=mul(m->v[12],INT64_C(2)); if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[2]=add(m->now,delay);m->active[2]=1;}
if(failure)return 0;
m->state=10; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\106\111\116\055\101\103\113\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 31: {
m->state=8; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\117\114\104\055\101\103\113\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 32: {
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(8));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\106\111\116\055\101\103\113\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 33: {
m->state=9; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\117\114\104\055\101\103\113\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 34: {
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(11));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=7; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\120\105\105\122\055\106\111\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 35: {
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(11));
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
int64_t delay=mul(m->v[12],INT64_C(2)); if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[2]=add(m->now,delay);m->active[2]=1;}
if(failure)return 0;
m->state=10; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\120\105\105\122\055\106\111\116\055\106\127\062\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 36: {
m->v[2]=f[1];
if(failure)return 0;
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(11));
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
{
int64_t delay=mul(m->v[12],INT64_C(2)); if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[2]=add(m->now,delay);m->active[2]=1;}
if(failure)return 0;
m->state=10; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\120\105\105\122\055\106\111\116\055\106\127\061\055\101\103\113\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 37: {
m->v[4]=seqadd(f[0],INT64_C(1));
if(failure)return 0;
m->v[6]=m->v[4];
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(11));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=8; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\111\115\125\114\124\101\116\105\117\125\123\055\106\111\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 38: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=7; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\104\125\120\114\111\103\101\124\105\055\106\111\116\055\103\114\117\123\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 39: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=8; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\104\125\120\114\111\103\101\124\105\055\106\111\116\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 40: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=9; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\104\125\120\114\111\103\101\124\105\055\106\111\116\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 41: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
{
int64_t delay=mul(m->v[12],INT64_C(2)); if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[2]=add(m->now,delay);m->active[2]=1;}
if(failure)return 0;
m->state=10; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\104\125\120\114\111\103\101\124\105\055\106\111\116\055\124\111\115\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\106\111\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 42: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[9]=add(m->v[9],INT64_C(1));
if(failure)return 0;
m->v[8]=mul(m->v[8],INT64_C(2));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=2; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\124\122\101\116\123\115\111\124\055\123\131\116\055\123\105\116\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\162\164\170\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 43: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[9]=add(m->v[9],INT64_C(1));
if(failure)return 0;
m->v[8]=mul(m->v[8],INT64_C(2));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=3; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\124\122\101\116\123\115\111\124\055\123\131\116\055\122\105\103\105\111\126\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\162\164\170\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 44: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[9]=add(m->v[9],INT64_C(1));
if(failure)return 0;
m->v[8]=mul(m->v[8],INT64_C(2));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=5; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\124\122\101\116\123\115\111\124\055\106\111\116\055\127\101\111\124\055\061\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\162\164\170\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 45: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[9]=add(m->v[9],INT64_C(1));
if(failure)return 0;
m->v[8]=mul(m->v[8],INT64_C(2));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=8; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\124\122\101\116\123\115\111\124\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\162\164\170\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 46: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(m->v[7]));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[5]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[6]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[9]=add(m->v[9],INT64_C(1));
if(failure)return 0;
m->v[8]=mul(m->v[8],INT64_C(2));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=9; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\124\122\101\116\123\115\111\124\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\054\040\042\122\124\117\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\162\164\170\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 47: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(16));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\125\123\105\122\055\124\111\115\105\117\125\124\055\123\131\116\055\123\105\116\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\165\163\145\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 48: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(16));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\125\123\105\122\055\124\111\115\105\117\125\124\055\123\131\116\055\122\105\103\105\111\126\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\165\163\145\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 49: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(16));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\125\123\105\122\055\124\111\115\105\117\125\124\055\106\111\116\055\127\101\111\124\055\061\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\165\163\145\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 50: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(16));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\125\123\105\122\055\124\111\115\105\117\125\124\055\106\111\116\055\127\101\111\124\055\062\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\165\163\145\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 51: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(16));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\125\123\105\122\055\124\111\115\105\117\125\124\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\165\163\145\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 52: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(16));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\125\123\105\122\055\124\111\115\105\117\125\124\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\165\163\145\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 53: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(8));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\124\111\115\105\055\127\101\111\124\055\105\130\120\111\122\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\124\111\115\105\117\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\164\151\155\145\137\167\141\151\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 54: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\103\114\117\123\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 55: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 56: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\123\131\116\055\123\105\116\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 57: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\123\131\116\055\122\105\103\105\111\126\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 58: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->b[0]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->b[1]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->b[2]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->v[13]=INT64_C(16);
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\105\123\124\101\102\114\111\123\110\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 59: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\106\111\116\055\127\101\111\124\055\061\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 60: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\106\111\116\055\127\101\111\124\055\062\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 61: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\103\114\117\123\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 62: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\103\114\117\123\111\116\107\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 63: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\114\101\123\124\055\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 64: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(6));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\101\102\117\122\124\055\124\111\115\105\055\127\101\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\101\102\117\122\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\141\142\157\162\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 65: {
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\111\107\116\117\122\105\055\116\105\124\055\122\123\124\055\103\114\117\123\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\104\055\111\116\120\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 66: {
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\111\107\116\117\122\105\055\116\105\124\055\122\123\124\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\114\111\123\124\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 67: {
m->state=2; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\123\105\116\124\055\116\105\124\055\122\123\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 68: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\122\105\103\105\111\126\105\104\055\116\105\124\055\122\123\124\055\120\101\123\123\111\126\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 69: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(13));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\122\105\103\105\111\126\105\104\055\116\105\124\055\122\123\124\055\101\103\124\111\126\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 70: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->b[0]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->b[1]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->b[2]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->v[13]=INT64_C(16);
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\105\123\124\101\102\114\111\123\110\105\104\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 71: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\106\111\116\055\127\101\111\124\055\061\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 72: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\106\111\116\055\127\101\111\124\055\062\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 73: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\103\114\117\123\105\055\127\101\111\124\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 74: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\103\114\117\123\111\116\107\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 75: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\114\101\123\124\055\101\103\113\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 76: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\124\111\115\105\055\127\101\111\124\055\162\163\164\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 77: {
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\111\107\116\117\122\105\055\116\105\124\055\122\123\124\101\103\113\055\103\114\117\123\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\104\055\111\116\120\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 78: {
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\111\107\116\117\122\105\055\116\105\124\055\122\123\124\101\103\113\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\114\111\123\124\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 79: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(13));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\123\105\116\124\055\116\105\124\055\122\123\124\101\103\113\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\123\131\116\055\123\105\116\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 80: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\122\105\103\105\111\126\105\104\055\116\105\124\055\122\123\124\101\103\113\055\120\101\123\123\111\126\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 81: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(13));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\123\131\116\055\122\105\103\105\111\126\105\104\055\116\105\124\055\122\123\124\101\103\113\055\101\103\124\111\126\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 82: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->b[0]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->b[1]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->b[2]=byte_literal((const unsigned char[]){0},0);
if(failure)return 0;
m->v[13]=INT64_C(16);
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\105\123\124\101\102\114\111\123\110\105\104\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 83: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\106\111\116\055\127\101\111\124\055\061\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 84: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\106\111\116\055\127\101\111\124\055\062\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 85: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\103\114\117\123\105\055\127\101\111\124\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 86: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\103\114\117\123\111\116\107\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 87: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\114\101\123\124\055\101\103\113\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 88: {
if(1)m->active[0]=0;
if(failure)return 0;
if(1)m->active[1]=0;
if(failure)return 0;
if(1)m->active[2]=0;
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(14));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\123\105\124\055\124\111\115\105\055\127\101\111\124\055\162\163\164\141\143\153\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\122\105\123\105\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\162\163\164\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 89: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\112\105\103\124\055\101\103\113\055\103\114\117\123\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\104\055\111\116\120\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 90: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\112\105\103\124\055\101\103\113\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\114\111\123\124\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 91: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\112\105\103\124\055\123\131\116\101\103\113\055\103\114\117\123\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\104\055\111\116\120\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 92: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\112\105\103\124\055\123\131\116\101\103\113\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\114\111\123\124\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 93: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\112\105\103\124\055\106\111\116\055\103\114\117\123\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\104\055\111\116\120\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 94: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(2));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=1; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\122\105\112\105\103\124\055\106\111\116\055\114\111\123\124\105\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\114\111\123\124\105\116\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\146\151\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 95: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(3));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,INT64_C(0));
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,seqadd(f[0],INT64_C(1)));
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,m->v[13]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\103\055\103\114\117\123\105\104\055\123\131\116\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\103\117\116\116\055\103\114\117\123\105\104\055\111\116\120\125\124\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\163\171\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 96: {
m->b[0]=byte_concat(m->b[0],bf[0]);
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(12));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\121\125\105\125\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\123\105\116\104\042\054\040\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\163\145\156\144\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\144\141\164\141\042\072");
byte_json(log,bf[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 97: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(10));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\123\105\116\104\055\105\115\120\124\131\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\163\145\156\144\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\144\141\164\141\042\072");
byte_json(log,bf[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 98: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\143\157\144\145\042\072");
text(&messages,source_json(15));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\123\105\116\104\055\106\125\114\114\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\163\145\156\144\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\144\141\164\141\042\072");
byte_json(log,bf[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 99: {
m->v[20]=minimum(INT64_C(4),minimum(((int64_t)(m->b[0]).len),sub(m->v[17],((int64_t)(m->b[1]).len))));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_slice(m->b[0],INT64_C(0),m->v[20]));
text(&messages,"\175\175");
}
if(failure)return 0;
m->b[1]=byte_concat(m->b[1],byte_slice(m->b[0],INT64_C(0),m->v[20]));
if(failure)return 0;
m->b[0]=byte_slice(m->b[0],m->v[20],((int64_t)(m->b[0]).len));
if(failure)return 0;
m->v[3]=seqadd(m->v[3],m->v[20]);
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\106\114\125\123\110\055\106\111\122\123\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\123\105\116\104\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\122\124\117\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\164\162\141\156\163\155\151\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 100: {
m->v[20]=minimum(INT64_C(4),minimum(((int64_t)(m->b[0]).len),sub(m->v[17],((int64_t)(m->b[1]).len))));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_slice(m->b[0],INT64_C(0),m->v[20]));
text(&messages,"\175\175");
}
if(failure)return 0;
m->b[1]=byte_concat(m->b[1],byte_slice(m->b[0],INT64_C(0),m->v[20]));
if(failure)return 0;
m->b[0]=byte_slice(m->b[0],m->v[20],((int64_t)(m->b[0]).len));
if(failure)return 0;
m->v[3]=seqadd(m->v[3],m->v[20]);
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\106\114\125\123\110\055\115\117\122\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\123\105\116\104\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\122\124\117\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\164\162\141\156\163\155\151\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 101: {
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\106\114\125\123\110\055\102\114\117\103\113\105\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\164\162\141\156\163\155\151\164\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 102: {
m->b[1]=byte_slice(m->b[1],distance(m->v[2],f[1]),((int64_t)(m->b[1]).len));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\106\125\114\114\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\122\124\117\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 103: {
m->b[1]=byte_slice(m->b[1],distance(m->v[2],f[1]),((int64_t)(m->b[1]).len));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
if(1)m->active[0]=0;
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\106\125\114\114\055\123\124\101\114\105\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\122\124\117\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 104: {
m->b[1]=byte_slice(m->b[1],distance(m->v[2],f[1]),((int64_t)(m->b[1]).len));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\120\101\122\124\111\101\114\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\122\124\117\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 105: {
m->b[1]=byte_slice(m->b[1],distance(m->v[2],f[1]),((int64_t)(m->b[1]).len));
if(failure)return 0;
m->v[2]=f[1];
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\120\101\122\124\111\101\114\055\123\124\101\114\105\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\122\124\117\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 106: {
m->v[17]=f[2];
if(failure)return 0;
m->v[18]=f[0];
if(failure)return 0;
m->v[19]=f[1];
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\104\125\120\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 107: {
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\104\125\120\055\123\124\101\114\105\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\054\040\042\104\101\124\101\055\127\111\116\104\117\127\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 108: {
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\117\114\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 109: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\103\113\055\106\125\124\125\122\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\101\103\113\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\141\143\153\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 110: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[2]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_slice(m->b[1],INT64_C(0),INT64_C(4)));
text(&messages,"\175\175");
}
if(failure)return 0;
m->v[8]=mul(m->v[8],INT64_C(2));
if(failure)return 0;
m->v[9]=add(m->v[9],INT64_C(1));
if(failure)return 0;
{
int64_t delay=m->v[8]; if(delay<=0){failure="invalid_timer_delay";return 0;}
m->due[0]=add(m->now,delay);m->active[0]=1;}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\122\105\124\122\101\116\123\115\111\124\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\124\130\042\054\040\042\104\101\124\101\055\122\124\117\042\054\040\042\104\101\124\101\055\123\105\121\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\164\151\155\145\162\056\162\164\170\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 111: {
m->b[3]=byte_slice(bf[3],INT64_C(0),minimum(sub(INT64_C(16),((int64_t)(m->b[2]).len)),sub(((int64_t)(bf[3]).len),INT64_C(0))));
if(failure)return 0;
m->b[2]=byte_concat(m->b[2],m->b[3]);
if(failure)return 0;
m->v[4]=seqadd(m->v[4],((int64_t)(m->b[3]).len));
if(failure)return 0;
m->v[13]=sub(INT64_C(16),((int64_t)(m->b[2]).len));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\122\105\103\105\111\126\105\055\111\116\055\117\122\104\105\122\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\105\103\105\111\126\105\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\054\042\144\141\164\141\042\072");
byte_json(log,bf[3]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 112: {
m->b[3]=byte_slice(bf[3],distance(f[0],m->v[4]),minimum(sub(INT64_C(16),((int64_t)(m->b[2]).len)),sub(((int64_t)(bf[3]).len),distance(f[0],m->v[4]))));
if(failure)return 0;
m->b[2]=byte_concat(m->b[2],m->b[3]);
if(failure)return 0;
m->v[4]=seqadd(m->v[4],((int64_t)(m->b[3]).len));
if(failure)return 0;
m->v[13]=sub(INT64_C(16),((int64_t)(m->b[2]).len));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\122\105\103\105\111\126\105\055\117\126\105\122\114\101\120\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\105\103\105\111\126\105\042\054\040\042\104\101\124\101\055\123\105\121\042\054\040\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\054\042\144\141\164\141\042\072");
byte_json(log,bf[3]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 113: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\122\105\103\105\111\126\105\055\104\125\120\114\111\103\101\124\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\105\103\105\111\126\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\054\042\144\141\164\141\042\072");
byte_json(log,bf[3]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 114: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\122\105\103\105\111\126\105\055\101\110\105\101\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\105\103\105\111\126\105\042\054\040\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\054\042\144\141\164\141\042\072");
byte_json(log,bf[3]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 115: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\122\105\103\105\111\126\105\055\132\105\122\117\055\127\111\116\104\117\127\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\105\103\105\111\126\105\042\054\040\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\145\161\042\072");
number(log,f[0]);
text(log,"\054\042\141\143\153\042\072");
number(log,f[1]);
text(log,"\054\042\167\151\156\144\157\167\042\072");
number(log,f[2]);
text(log,"\054\042\144\141\164\141\042\072");
byte_json(log,bf[3]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 116: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\141\160\160\154\151\143\141\164\151\157\156\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\144\141\164\141\042\072");
byte_json(&messages,byte_slice(m->b[2],INT64_C(0),f[0]));
text(&messages,"\175\175");
}
if(failure)return 0;
m->b[2]=byte_slice(m->b[2],f[0],((int64_t)(m->b[2]).len));
if(failure)return 0;
m->v[13]=sub(INT64_C(16),((int64_t)(m->b[2]).len));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\164\143\160\137\144\141\164\141\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\146\154\141\147\163\042\072");
text(&messages,source_json(0));
text(&messages,"\054\042\163\145\161\042\072");
number(&messages,m->v[3]);
text(&messages,"\054\042\141\143\153\042\072");
number(&messages,m->v[4]);
text(&messages,"\054\042\167\151\156\144\157\167\042\072");
number(&messages,sub(INT64_C(16),((int64_t)(m->b[2]).len)));
text(&messages,"\054\042\160\141\171\154\157\141\144\042\072");
byte_json(&messages,byte_literal((const unsigned char[]){0},0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=4; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\104\055\101\120\120\114\111\103\101\124\111\117\116\055\122\105\101\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\104\101\124\101\055\122\105\103\105\111\126\105\042\054\040\042\104\101\124\101\055\123\103\117\120\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\162\145\143\145\151\166\145\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\143\157\165\156\164\042\072");
number(log,f[0]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
default:failure="invalid_rule";return 0;} return failure==NULL; }
/* Line interface for independent execution; no JSON model is read at runtime.
   I variable-index integer (before B), B, D milliseconds event integer-fields,
   T milliseconds. Each operation is committed atomically after all checks. */
int advance(Machine *m,int64_t at,Buffer *log) {
    int steps=0;
    if(at<m->now){failure="nonmonotonic_time";return 0;}
    for(;;) {
        int next=-1,i;
        for(i=0;i<NT;i++)if(m->active[i] && (next<0||m->due[i]<m->due[next]||
             (m->due[i]==m->due[next]&&strcmp(timer_names[i],timer_names[next])<0)))next=i;
        if(next<0||m->due[next]>at)break;
        if(++steps>4096){failure="timer_step_capacity";return 0;}
        m->now=m->due[next];
        if(!fire(m,timer_events[next],NULL,NULL,next,log)){if(!failure)failure="internal_transition_failure";return 0;}
    }
    m->now=at;return 1;
}
int parse_integer(const char *s,int64_t *out) {
    char *end; long long n;
    if(!s||!*s)return 0;
    errno=0;n=strtoll(s,&end,10);
    if(errno||*end||n<INT64_MIN||n>INT64_MAX)return 0;
    *out=(int64_t)n;return 1;
}
void reply(Machine *m,const char *status,const char *error) {
    Buffer out={{0},0};
    text(&out,"{\"status\":\"");text(&out,status);text(&out,"\"");
    if(error){text(&out,",\"failure\":");json_string(&out,error);}
    text(&out,",\"snapshot\":");snapshot(&out,m);text(&out,"}\n");fputs(out.data,stdout);
}
int snapshot_fits(Machine *m) {
    Buffer preview={{0},0};snapshot(&preview,m);
    if(preview.size>LOG_CAP-4096)failure="output_capacity";
    return failure==NULL;
}
int main(void) {
    Machine committed;char line[INPUT_CAP];int begun=0,errors=0;
    initialize(&committed);
    while(fgets(line,sizeof(line),stdin)) {
        char *tokens[FIELD_CAP+4];int count=0,overflow=0,i,event=-1;char *token;
        int64_t at=0,fields[FIELD_CAP]={0};Bytes byte_fields[FIELD_CAP]={{0}};Machine candidate=committed;Buffer log={{0},0};
        failure=NULL;
        if(!strchr(line,'\n')&&!feof(stdin)){failure="input_capacity";while((i=getchar())!='\n'&&i!=EOF){} }
        token=strtok(line," \t\r\n");
        while(token){if(count<(int)(sizeof(tokens)/sizeof(tokens[0])))tokens[count++]=token;else overflow=1;token=strtok(NULL," \t\r\n");}
        if(!count)continue;
        if(overflow)failure="input_capacity";
        if(!failure && !strcmp(tokens[0],"I")) {
            int64_t index,value;
            if(begun||count!=3||!parse_integer(tokens[1],&index)||index<0||index>=NV)failure="invalid_initial_override";
            else if(variable_kinds[index]==3)parse_bytes(tokens[2],&candidate.b[variable_byte_index[index]]);
            else if(!parse_integer(tokens[2],&value)||!valid(value,variable_kinds[index]))failure="invalid_initial_override";
            else candidate.v[index]=value;
            if(!failure&&snapshot_fits(&candidate)){committed=candidate;continue;}
        } else if(!failure && !strcmp(tokens[0],"B")) {
            if(begun||count!=1)failure="invalid_begin";
            else if(invariants(&candidate)){begun=1;reply(&committed,"ready",NULL);continue;}
        } else if(!failure && (!strcmp(tokens[0],"D")||!strcmp(tokens[0],"T")
#ifdef WIRE_PROFILE
                  ||!strcmp(tokens[0],"P")
#endif
                  )) {
            if(!begun||count<2||!parse_integer(tokens[1],&at))failure="invalid_command";
            if(!failure && !strcmp(tokens[0],"D")) {
                if(count<3)failure="invalid_command";
                else {
                    for(i=0;i<(int)(sizeof(event_names)/sizeof(event_names[0]));i++)if(!strcmp(tokens[2],event_names[i]))event=i;
                    if(event<0)failure="unknown_event";
                    else if(event_origin[event])failure="timer_injection";
                    else if(count!=3+event_fields[event])failure="event_field_mismatch";
                    else for(i=0;i<event_fields[event]&&!failure;i++) {
                        if(event_kinds[event][i]==3)parse_bytes(tokens[3+i],&byte_fields[i]);
                        else if(!parse_integer(tokens[3+i],&fields[i])||!valid(fields[i],event_kinds[event][i]))failure="invalid_event_value";
                    }
                }
            }
#ifdef WIRE_PROFILE
            else if(!failure && !strcmp(tokens[0],"P")) {
                if(count!=3)failure="invalid_wire_command";
                else if(wire_decode(tokens[2],fields))event=WIRE_EVENT;
            }
#endif
            else if(!failure && count!=2)failure="invalid_command";
            if(!failure && advance(&candidate,at,&log)) {
                if(event>=0){if(!fire(&candidate,event,fields,byte_fields,-1,&log)&&!failure)failure="internal_transition_failure";}
                else if(!invariants(&candidate)&&!failure)failure="internal_invariant_failure";
            }
            if(!failure&&snapshot_fits(&candidate)){committed=candidate;fputs(log.data,stdout);reply(&committed,"ok",NULL);continue;}
        } else if(!failure)failure="invalid_command";
        errors++;reply(&committed,"error",failure?failure:"internal_error");
    }
    if(ferror(stdin))return 2;
    if(!begun)return 2;
    return errors?1:0;
}


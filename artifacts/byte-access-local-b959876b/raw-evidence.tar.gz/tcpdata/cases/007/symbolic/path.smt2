; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun due_2_time_wait () Int)
(declare-fun due_2_user () Int)
(declare-fun due_2_rtx () Int)
(declare-fun active_2_time_wait () Bool)
(declare-fun active_2_user () Bool)
(declare-fun active_2_rtx () Bool)
(declare-fun v_2_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_take () Int)
(declare-fun v_2_snd_wl2 () (_ BitVec 32))
(declare-fun v_2_snd_wl1 () (_ BitVec 32))
(declare-fun v_2_snd_wnd () Int)
(declare-fun v_2_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_local_window () Int)
(declare-fun v_2_msl_ms () Int)
(declare-fun v_2_user_timeout_ms () Int)
(declare-fun v_2_active_open () Bool)
(declare-fun v_2_retries () Int)
(declare-fun v_2_rto_ms () Int)
(declare-fun v_2_tx_flags () String)
(declare-fun v_2_tx_ack () (_ BitVec 32))
(declare-fun v_2_tx_seq () (_ BitVec 32))
(declare-fun v_2_rcv_nxt () (_ BitVec 32))
(declare-fun v_2_snd_nxt () (_ BitVec 32))
(declare-fun v_2_snd_una () (_ BitVec 32))
(declare-fun v_2_irs () (_ BitVec 32))
(declare-fun v_2_iss () (_ BitVec 32))
(declare-fun state_2 () Int)
(declare-fun due_3_time_wait () Int)
(declare-fun due_3_user () Int)
(declare-fun due_3_rtx () Int)
(declare-fun active_3_time_wait () Bool)
(declare-fun active_3_user () Bool)
(declare-fun active_3_rtx () Bool)
(declare-fun v_3_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_take () Int)
(declare-fun v_3_snd_wl2 () (_ BitVec 32))
(declare-fun v_3_snd_wl1 () (_ BitVec 32))
(declare-fun v_3_snd_wnd () Int)
(declare-fun v_3_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_local_window () Int)
(declare-fun v_3_msl_ms () Int)
(declare-fun v_3_user_timeout_ms () Int)
(declare-fun v_3_active_open () Bool)
(declare-fun v_3_retries () Int)
(declare-fun v_3_rto_ms () Int)
(declare-fun v_3_tx_flags () String)
(declare-fun v_3_tx_ack () (_ BitVec 32))
(declare-fun v_3_tx_seq () (_ BitVec 32))
(declare-fun v_3_rcv_nxt () (_ BitVec 32))
(declare-fun v_3_snd_nxt () (_ BitVec 32))
(declare-fun v_3_snd_una () (_ BitVec 32))
(declare-fun v_3_irs () (_ BitVec 32))
(declare-fun v_3_iss () (_ BitVec 32))
(declare-fun state_3 () Int)
(declare-fun due_4_time_wait () Int)
(declare-fun due_4_user () Int)
(declare-fun due_4_rtx () Int)
(declare-fun active_4_time_wait () Bool)
(declare-fun active_4_user () Bool)
(declare-fun active_4_rtx () Bool)
(declare-fun v_4_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_4_take () Int)
(declare-fun v_4_snd_wl2 () (_ BitVec 32))
(declare-fun v_4_snd_wl1 () (_ BitVec 32))
(declare-fun v_4_snd_wnd () Int)
(declare-fun v_4_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_local_window () Int)
(declare-fun v_4_msl_ms () Int)
(declare-fun v_4_user_timeout_ms () Int)
(declare-fun v_4_active_open () Bool)
(declare-fun v_4_retries () Int)
(declare-fun v_4_rto_ms () Int)
(declare-fun v_4_tx_flags () String)
(declare-fun v_4_tx_ack () (_ BitVec 32))
(declare-fun v_4_tx_seq () (_ BitVec 32))
(declare-fun v_4_rcv_nxt () (_ BitVec 32))
(declare-fun v_4_snd_nxt () (_ BitVec 32))
(declare-fun v_4_snd_una () (_ BitVec 32))
(declare-fun v_4_irs () (_ BitVec 32))
(declare-fun v_4_iss () (_ BitVec 32))
(declare-fun state_4 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.synack_seq () (_ BitVec 32))
(declare-fun input_1_net.synack_ack () (_ BitVec 32))
(declare-fun input_1_net.synack_window () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.data_seq () (_ BitVec 32))
(declare-fun input_2_net.data_ack () (_ BitVec 32))
(declare-fun input_2_net.data_window () Int)
(declare-fun input_2_net.data_data () (Seq (_ BitVec 8)))
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(declare-fun input_3_net.data_seq () (_ BitVec 32))
(declare-fun input_3_net.data_ack () (_ BitVec 32))
(declare-fun input_3_net.data_window () Int)
(declare-fun input_3_net.data_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x588 (= due_1_time_wait due_0_time_wait)))
 (let (($x5879 (= due_1_user 30000)))
 (let (($x3041 (= due_1_rtx 1000)))
 (let (($x5880 (not active_1_time_wait)))
 (let (($x5882 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x2236 (= v_1_take 0)))
 (let (($x841 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x2202 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x2254 (= v_1_snd_wnd 8)))
 (let (($x197 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x4525 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x3506 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x2242 (= v_1_local_window 16)))
 (let (($x962 (= v_1_msl_ms 60000)))
 (let (($x2243 (= v_1_user_timeout_ms 30000)))
 (let (($x8224 (= 0 v_1_retries)))
 (let (($x9100 (= 1000 v_1_rto_ms)))
 (let (($x8223 (= v_1_tx_flags "S")))
 (let (($x2256 (= v_1_tx_ack (_ bv0 32))))
 (let (($x2270 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x2271 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x4524 (= v_1_snd_nxt (_ bv1001 32))))
 (let (($x2275 (= v_1_snd_una (_ bv1000 32))))
 (let (($x8373 (= v_1_irs (_ bv0 32))))
 (let (($x3406 (= v_1_iss (_ bv1000 32))))
 (let (($x5833 (= 2 state_1)))
 (let (($x4938 (not active_0_time_wait)))
 (let (($x1744 (or $x4938 (not (<= due_0_time_wait 0)))))
 (let (($x2706 (not active_0_user)))
 (let (($x8335 (or $x2706 (not (<= due_0_user 0)))))
 (let (($x5850 (not active_0_rtx)))
 (let (($x543 (or $x5850 (not (<= due_0_rtx 0)))))
 (let (($x8064 (= state_0 0)))
 (and $x8064 (>= 0 now_0) $x543 $x8335 $x1744 $x5833 $x3406 $x8373 $x2275 $x4524 $x2271 $x2270 $x2256 $x8223 $x9100 $x8224 v_1_active_open $x2243 $x962 $x2242 $x3506 $x4525 $x197 $x2254 $x2202 $x841 $x2236 $x5882 active_1_rtx active_1_user $x5880 $x3041 $x5879 $x588)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x7063 (= due_2_time_wait due_1_time_wait)))
 (let (($x137 (= due_2_user due_1_user)))
 (let (($x2399 (= due_2_rtx due_1_rtx)))
 (let (($x2398 (= active_2_time_wait active_1_time_wait)))
 (let (($x8789 (not active_2_user)))
 (let (($x8794 (not active_2_rtx)))
 (let (($x364 (= v_2_rx_chunk v_1_rx_chunk)))
 (let (($x363 (= v_2_take v_1_take)))
 (let (($x5521 (= v_2_snd_wl2 (_ bv1001 32))))
 (let (($x8366 (= v_2_snd_wl1 (_ bv9000 32))))
 (let (($x8658 (= v_2_snd_wnd 8)))
 (let (($x266 (= v_2_rcv_buf v_1_rcv_buf)))
 (let (($x361 (= v_2_rtx_buf v_1_rtx_buf)))
 (let (($x360 (= v_2_snd_buf v_1_snd_buf)))
 (let (($x289 (= v_2_local_window v_1_local_window)))
 (let (($x359 (= v_2_msl_ms v_1_msl_ms)))
 (let (($x358 (= v_2_user_timeout_ms v_1_user_timeout_ms)))
 (let (($x357 (= v_2_active_open v_1_active_open)))
 (let (($x356 (= v_2_retries v_1_retries)))
 (let (($x271 (= v_2_rto_ms v_1_rto_ms)))
 (let (($x355 (= v_2_tx_flags v_1_tx_flags)))
 (let (($x354 (= v_2_tx_ack v_1_tx_ack)))
 (let (($x353 (= v_2_tx_seq v_1_tx_seq)))
 (let (($x7255 (= v_2_rcv_nxt (_ bv9001 32))))
 (let (($x352 (= v_2_snd_nxt v_1_snd_nxt)))
 (let (($x5881 (= v_2_snd_una (_ bv1001 32))))
 (let (($x2258 (= v_2_irs (_ bv9000 32))))
 (let (($x349 (= v_2_iss v_1_iss)))
 (let (($x1248 (= 4 state_2)))
 (let (($x5880 (not active_1_time_wait)))
 (let (($x1743 (or $x5880 (not (<= due_1_time_wait 10)))))
 (let (($x2269 (or (not active_1_user) (not (<= due_1_user 10)))))
 (let (($x3965 (or (not active_1_rtx) (not (<= due_1_rtx 10)))))
 (let (($x8224 (= 0 v_1_retries)))
 (let (($x4524 (= v_1_snd_nxt (_ bv1001 32))))
 (let (($x8787 (= state_1 2)))
 (and $x8787 $x4524 $x8224 $x3965 $x2269 $x1743 $x1248 $x349 $x2258 $x5881 $x352 $x7255 $x353 $x354 $x355 $x271 $x356 $x357 $x358 $x359 $x289 $x360 $x361 $x266 $x8658 $x8366 $x5521 $x363 $x364 $x8794 $x8789 $x2398 $x2399 $x137 $x7063))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x5952 (= due_3_time_wait due_2_time_wait)))
 (let (($x8413 (= due_3_user due_2_user)))
 (let (($x8412 (= due_3_rtx due_2_rtx)))
 (let (($x5919 (= active_3_time_wait active_2_time_wait)))
 (let (($x5911 (= active_3_user active_2_user)))
 (let (($x5323 (= active_3_rtx active_2_rtx)))
 (let ((?x171 (seq.unit (_ bv1 8))))
 (let ((?x808 (seq.len v_2_rcv_buf)))
 (let (($x3703 (<= ?x808 15)))
 (let (($x1129 (>= ?x808 13)))
 (let (($x837 (not $x1129)))
 (let (($x8653 (or $x837 $x3703)))
 (let ((?x711 (ite $x1129 (+ 16 (* (- 1) ?x808)) 3)))
 (let (($x1128 (<= 0 ?x711)))
 (let (($x8879 (and $x1128 $x8653)))
 (let ((?x3519 (seq.unit (_ bv2 8))))
 (let ((?x2247 (seq.++ ?x171 ?x3519)))
 (let (($x2267 (or $x837 (<= ?x808 14))))
 (let (($x2732 (and $x1128 $x2267)))
 (let ((?x1572 (seq.unit (_ bv3 8))))
 (let ((?x3518 (seq.++ ?x3519 ?x1572)))
 (let ((?x4532 (seq.++ ?x171 ?x3518)))
 (let (($x2278 (or $x837 (<= ?x808 13))))
 (let (($x3131 (and $x1128 $x2278)))
 (let ((?x5533 (ite $x3131 ?x4532 (ite $x2732 ?x2247 (ite $x8879 ?x171 (as seq.empty (Seq (_ BitVec 8))))))))
 (let (($x5949 (= v_3_take v_2_take)))
 (let (($x1920 (= v_3_snd_wl2 v_2_snd_wl2)))
 (let (($x8389 (= v_3_snd_wl1 v_2_snd_wl1)))
 (let (($x5901 (= v_3_snd_wnd v_2_snd_wnd)))
 (let (($x5312 (= v_3_rtx_buf v_2_rtx_buf)))
 (let (($x7699 (= v_3_snd_buf v_2_snd_buf)))
 (let (($x2109 (= v_3_local_window (+ 16 (* (- 1) ?x808) (* (- 1) (seq.len ?x5533))))))
 (let (($x5924 (= v_3_msl_ms v_2_msl_ms)))
 (let (($x4582 (= v_3_user_timeout_ms v_2_user_timeout_ms)))
 (let (($x3937 (= v_3_active_open v_2_active_open)))
 (let (($x341 (= v_3_retries v_2_retries)))
 (let (($x218 (= v_3_rto_ms v_2_rto_ms)))
 (let (($x4533 (= v_3_tx_flags v_2_tx_flags)))
 (let (($x4568 (= v_3_tx_ack v_2_tx_ack)))
 (let (($x1941 (= v_3_tx_seq v_2_tx_seq)))
 (let ((?x1958 (bvadd v_2_rcv_nxt ((_ int_to_bv 32) (ite $x3131 3 (ite $x2732 2 (ite $x8879 1 0)))))))
 (let (($x5876 (= v_3_snd_nxt v_2_snd_nxt)))
 (let (($x8340 (= v_3_snd_una v_2_snd_una)))
 (let (($x8341 (= v_3_irs v_2_irs)))
 (let (($x5929 (= v_3_iss v_2_iss)))
 (let (($x2827 (= 4 state_3)))
 (let (($x2259 (or (not active_2_time_wait) (not (<= due_2_time_wait 30)))))
 (let (($x8789 (not active_2_user)))
 (let (($x2223 (or $x8789 (not (<= due_2_user 30)))))
 (let (($x8794 (not active_2_rtx)))
 (let (($x968 (or $x8794 (not (<= due_2_rtx 30)))))
 (let (($x7255 (= v_2_rcv_nxt (_ bv9001 32))))
 (let (($x5881 (= v_2_snd_una (_ bv1001 32))))
 (let (($x710 (= state_2 4)))
 (and $x710 $x5881 (= 8 v_2_snd_wnd) $x7255 $x3703 $x968 $x2223 $x2259 $x2827 $x5929 $x8341 $x8340 $x5876 (= v_3_rcv_nxt ?x1958) $x1941 $x4568 $x4533 $x218 $x341 $x3937 $x4582 $x5924 $x2109 $x7699 $x5312 (= v_3_rcv_buf (seq.++ v_2_rcv_buf ?x5533)) $x5901 $x8389 $x1920 $x5949 (= v_3_rx_chunk ?x5533) $x5323 $x5911 $x5919 $x8412 $x8413 $x5952))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x143 (= due_4_time_wait due_3_time_wait)))
 (let (($x900 (= due_4_user due_3_user)))
 (let (($x2705 (= due_4_rtx due_3_rtx)))
 (let (($x899 (= active_4_time_wait active_3_time_wait)))
 (let (($x898 (= active_4_user active_3_user)))
 (let (($x1118 (= active_4_rtx active_3_rtx)))
 (let ((?x3519 (seq.unit (_ bv2 8))))
 (let ((?x3129 (ubv_to_int (bvadd (_ bv4294958294 32) v_3_rcv_nxt))))
 (let ((?x965 (* (- 1) ?x3129)))
 (let ((?x3698 (+ 4 ?x965)))
 (let ((?x7444 (seq.len v_3_rcv_buf)))
 (let ((?x7460 (* (- 1) ?x7444)))
 (let ((?x3291 (+ 16 ?x7460)))
 (let ((?x5181 (ite (<= ?x7460 (+ (- 12) ?x965)) ?x3291 ?x3698)))
 (let (($x61 (<= 0 ?x5181)))
 (let ((?x1572 (seq.unit (_ bv3 8))))
 (let ((?x3518 (seq.++ ?x3519 ?x1572)))
 (let ((?x3209 (ite (and $x61 (>= ?x5181 2)) ?x3518 (ite (and $x61 (>= ?x5181 1)) ?x3519 (as seq.empty (Seq (_ BitVec 8)))))))
 (let ((?x8829 (seq.++ ?x3519 (seq.++ ?x1572 (seq.unit (_ bv4 8))))))
 (let ((?x8062 (seq.++ ?x3519 (seq.++ ?x1572 (seq.++ (seq.unit (_ bv4 8)) (seq.unit (_ bv5 8)))))))
 (let ((?x5153 (ite (and $x61 (>= ?x5181 4)) ?x8062 (ite (and $x61 (>= ?x5181 3)) ?x8829 ?x3209))))
 (let ((?x5233 (ite (<= 0 ?x3129) (ite $x61 (seq.extract ?x8062 ?x3129 ?x5181) (as seq.empty (Seq (_ BitVec 8)))) ?x5153)))
 (let (($x792 (= v_4_take v_3_take)))
 (let (($x1117 (= v_4_snd_wl2 v_3_snd_wl2)))
 (let (($x1116 (= v_4_snd_wl1 v_3_snd_wl1)))
 (let (($x1115 (= v_4_snd_wnd v_3_snd_wnd)))
 (let (($x1113 (= v_4_rtx_buf v_3_rtx_buf)))
 (let (($x1112 (= v_4_snd_buf v_3_snd_buf)))
 (let (($x1111 (= v_4_msl_ms v_3_msl_ms)))
 (let (($x2701 (= v_4_user_timeout_ms v_3_user_timeout_ms)))
 (let (($x2697 (= v_4_active_open v_3_active_open)))
 (let (($x2693 (= v_4_retries v_3_retries)))
 (let (($x1110 (= v_4_rto_ms v_3_rto_ms)))
 (let (($x2695 (= v_4_tx_flags v_3_tx_flags)))
 (let (($x889 (= v_4_tx_ack v_3_tx_ack)))
 (let (($x1101 (= v_4_tx_seq v_3_tx_seq)))
 (let (($x836 (= v_4_snd_nxt v_3_snd_nxt)))
 (let (($x888 (= v_4_snd_una v_3_snd_una)))
 (let (($x887 (= v_4_irs v_3_irs)))
 (let (($x1100 (= v_4_iss v_3_iss)))
 (let (($x1099 (= 4 state_4)))
 (let (($x8364 (or (not active_3_time_wait) (not (<= due_3_time_wait 31)))))
 (let (($x279 (or (not active_3_user) (not (<= due_3_user 31)))))
 (let (($x2255 (or (not active_3_rtx) (not (<= due_3_rtx 31)))))
 (let (($x3994 (<= ?x7444 15)))
 (let (($x4033 (<= ?x3129 3)))
 (let (($x3207 (bvule (_ bv2147492650 32) v_3_rcv_nxt)))
 (let (($x2277 (and (= ((_ extract 31 14) v_3_rcv_nxt) (_ bv0 18)) (bvule ((_ extract 13 0) v_3_rcv_nxt) (_ bv9001 14)))))
 (let (($x2911 (not (= v_3_rcv_nxt (_ bv9002 32)))))
 (let (($x2250 (= v_3_snd_una (_ bv1001 32))))
 (let (($x5809 (= state_3 4)))
 (and $x5809 $x2250 (= 8 v_3_snd_wnd) $x2911 (not (or $x2277 $x3207)) $x4033 $x3994 $x2255 $x279 $x8364 $x1099 $x1100 $x887 $x888 $x836 (= v_4_rcv_nxt (bvadd v_3_rcv_nxt ((_ int_to_bv 32) (seq.len ?x5233)))) $x1101 $x889 $x2695 $x1110 $x2693 $x2697 $x2701 $x1111 (= v_4_local_window (+ 16 ?x7460 (* (- 1) (seq.len ?x5233)))) $x1112 $x1113 (= v_4_rcv_buf (seq.++ v_3_rcv_buf ?x5233)) $x1115 $x1116 $x1117 $x792 (= v_4_rx_chunk ?x5233) $x1118 $x898 $x899 $x2705 $x900 $x143)))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 4 choice_1))
(assert
 (= 10 now_2))
(assert
 (= (_ bv9000 32) input_1_net.synack_seq))
(assert
 (= (_ bv1001 32) input_1_net.synack_ack))
(assert
 (= 8 input_1_net.synack_window))
(assert
 (= 111 choice_2))
(assert
 (= 30 now_3))
(assert
 (= (_ bv9001 32) input_2_net.data_seq))
(assert
 (= (_ bv1001 32) input_2_net.data_ack))
(assert
 (= 8 input_2_net.data_window))
(assert
 (let ((?x1572 (seq.unit (_ bv3 8))))
 (let ((?x3519 (seq.unit (_ bv2 8))))
 (let ((?x3518 (seq.++ ?x3519 ?x1572)))
 (let ((?x171 (seq.unit (_ bv1 8))))
 (let ((?x4532 (seq.++ ?x171 ?x3518)))
 (= input_2_net.data_data ?x4532)))))))
(assert
 (= 112 choice_3))
(assert
 (= 31 now_4))
(assert
 (= (_ bv9002 32) input_3_net.data_seq))
(assert
 (= (_ bv1001 32) input_3_net.data_ack))
(assert
 (= 8 input_3_net.data_window))
(assert
 (let ((?x3519 (seq.unit (_ bv2 8))))
(let ((?x8062 (seq.++ ?x3519 (seq.++ (seq.unit (_ bv3 8)) (seq.++ (seq.unit (_ bv4 8)) (seq.unit (_ bv5 8)))))))
(= input_3_net.data_data ?x8062))))
(check-sat)

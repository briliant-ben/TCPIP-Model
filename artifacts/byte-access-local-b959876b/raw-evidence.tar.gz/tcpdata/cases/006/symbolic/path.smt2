; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_rtx () Bool)
(declare-fun due_0_rtx () Int)
(declare-fun active_0_user () Bool)
(declare-fun due_0_user () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_1_user () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () (_ BitVec 32))
(declare-fun v_1_snd_wl1 () (_ BitVec 32))
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_1_tx_flags () String)
(declare-fun v_1_tx_ack () (_ BitVec 32))
(declare-fun v_1_tx_seq () (_ BitVec 32))
(declare-fun v_1_rcv_nxt () (_ BitVec 32))
(declare-fun v_1_snd_nxt () (_ BitVec 32))
(declare-fun v_1_snd_una () (_ BitVec 32))
(declare-fun v_1_irs () (_ BitVec 32))
(declare-fun v_1_iss () (_ BitVec 32))
(declare-fun state_1 () Int)
(declare-fun due_2_time_wait () Int)
(declare-fun due_2_user () Int)
(declare-fun due_2_rtx () Int)
(declare-fun active_2_time_wait () Bool)
(declare-fun active_2_user () Bool)
(declare-fun active_2_rtx () Bool)
(declare-fun v_2_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_take () Int)
(declare-fun v_2_snd_wl2 () (_ BitVec 32))
(declare-fun v_2_snd_wl1 () (_ BitVec 32))
(declare-fun v_2_snd_wnd () Int)
(declare-fun v_2_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_local_window () Int)
(declare-fun v_2_msl_ms () Int)
(declare-fun v_2_user_timeout_ms () Int)
(declare-fun v_2_active_open () Bool)
(declare-fun v_2_retries () Int)
(declare-fun v_2_rto_ms () Int)
(declare-fun v_2_tx_flags () String)
(declare-fun v_2_tx_ack () (_ BitVec 32))
(declare-fun v_2_tx_seq () (_ BitVec 32))
(declare-fun v_2_rcv_nxt () (_ BitVec 32))
(declare-fun v_2_snd_nxt () (_ BitVec 32))
(declare-fun v_2_snd_una () (_ BitVec 32))
(declare-fun v_2_irs () (_ BitVec 32))
(declare-fun v_2_iss () (_ BitVec 32))
(declare-fun state_2 () Int)
(declare-fun due_3_time_wait () Int)
(declare-fun due_3_user () Int)
(declare-fun due_3_rtx () Int)
(declare-fun active_3_time_wait () Bool)
(declare-fun active_3_user () Bool)
(declare-fun active_3_rtx () Bool)
(declare-fun v_3_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_take () Int)
(declare-fun v_3_snd_wl2 () (_ BitVec 32))
(declare-fun v_3_snd_wl1 () (_ BitVec 32))
(declare-fun v_3_snd_wnd () Int)
(declare-fun v_3_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_local_window () Int)
(declare-fun v_3_msl_ms () Int)
(declare-fun v_3_user_timeout_ms () Int)
(declare-fun v_3_active_open () Bool)
(declare-fun v_3_retries () Int)
(declare-fun v_3_rto_ms () Int)
(declare-fun v_3_tx_flags () String)
(declare-fun v_3_tx_ack () (_ BitVec 32))
(declare-fun v_3_tx_seq () (_ BitVec 32))
(declare-fun v_3_rcv_nxt () (_ BitVec 32))
(declare-fun v_3_snd_nxt () (_ BitVec 32))
(declare-fun v_3_snd_una () (_ BitVec 32))
(declare-fun v_3_irs () (_ BitVec 32))
(declare-fun v_3_iss () (_ BitVec 32))
(declare-fun state_3 () Int)
(declare-fun due_4_time_wait () Int)
(declare-fun due_4_user () Int)
(declare-fun due_4_rtx () Int)
(declare-fun active_4_time_wait () Bool)
(declare-fun active_4_user () Bool)
(declare-fun active_4_rtx () Bool)
(declare-fun v_4_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_4_take () Int)
(declare-fun v_4_snd_wl2 () (_ BitVec 32))
(declare-fun v_4_snd_wl1 () (_ BitVec 32))
(declare-fun v_4_snd_wnd () Int)
(declare-fun v_4_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_4_local_window () Int)
(declare-fun v_4_msl_ms () Int)
(declare-fun v_4_user_timeout_ms () Int)
(declare-fun v_4_active_open () Bool)
(declare-fun v_4_retries () Int)
(declare-fun v_4_rto_ms () Int)
(declare-fun v_4_tx_flags () String)
(declare-fun v_4_tx_ack () (_ BitVec 32))
(declare-fun v_4_tx_seq () (_ BitVec 32))
(declare-fun v_4_rcv_nxt () (_ BitVec 32))
(declare-fun v_4_snd_nxt () (_ BitVec 32))
(declare-fun v_4_snd_una () (_ BitVec 32))
(declare-fun v_4_irs () (_ BitVec 32))
(declare-fun v_4_iss () (_ BitVec 32))
(declare-fun state_4 () Int)
(declare-fun due_5_time_wait () Int)
(declare-fun due_5_user () Int)
(declare-fun due_5_rtx () Int)
(declare-fun active_5_time_wait () Bool)
(declare-fun active_5_user () Bool)
(declare-fun active_5_rtx () Bool)
(declare-fun v_5_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_5_take () Int)
(declare-fun v_5_snd_wl2 () (_ BitVec 32))
(declare-fun v_5_snd_wl1 () (_ BitVec 32))
(declare-fun v_5_snd_wnd () Int)
(declare-fun v_5_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_5_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_5_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_5_local_window () Int)
(declare-fun v_5_msl_ms () Int)
(declare-fun v_5_user_timeout_ms () Int)
(declare-fun v_5_active_open () Bool)
(declare-fun v_5_retries () Int)
(declare-fun v_5_rto_ms () Int)
(declare-fun v_5_tx_flags () String)
(declare-fun v_5_tx_ack () (_ BitVec 32))
(declare-fun v_5_tx_seq () (_ BitVec 32))
(declare-fun v_5_rcv_nxt () (_ BitVec 32))
(declare-fun v_5_snd_nxt () (_ BitVec 32))
(declare-fun v_5_snd_una () (_ BitVec 32))
(declare-fun v_5_irs () (_ BitVec 32))
(declare-fun v_5_iss () (_ BitVec 32))
(declare-fun state_5 () Int)
(declare-fun v_0_iss () (_ BitVec 32))
(declare-fun v_0_irs () (_ BitVec 32))
(declare-fun v_0_snd_una () (_ BitVec 32))
(declare-fun v_0_snd_nxt () (_ BitVec 32))
(declare-fun v_0_rcv_nxt () (_ BitVec 32))
(declare-fun v_0_tx_seq () (_ BitVec 32))
(declare-fun v_0_tx_ack () (_ BitVec 32))
(declare-fun v_0_tx_flags () String)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_snd_wl1 () (_ BitVec 32))
(declare-fun v_0_snd_wl2 () (_ BitVec 32))
(declare-fun v_0_take () Int)
(declare-fun v_0_rx_chunk () (Seq (_ BitVec 8)))
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.synack_seq () (_ BitVec 32))
(declare-fun input_1_net.synack_ack () (_ BitVec 32))
(declare-fun input_1_net.synack_window () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.data_seq () (_ BitVec 32))
(declare-fun input_2_net.data_ack () (_ BitVec 32))
(declare-fun input_2_net.data_window () Int)
(declare-fun input_2_net.data_data () (Seq (_ BitVec 8)))
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(declare-fun input_3_net.data_seq () (_ BitVec 32))
(declare-fun input_3_net.data_ack () (_ BitVec 32))
(declare-fun input_3_net.data_window () Int)
(declare-fun input_3_net.data_data () (Seq (_ BitVec 8)))
(declare-fun choice_4 () Int)
(declare-fun now_5 () Int)
(declare-fun input_4_net.data_seq () (_ BitVec 32))
(declare-fun input_4_net.data_ack () (_ BitVec 32))
(declare-fun input_4_net.data_window () Int)
(declare-fun input_4_net.data_data () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_rtx))
(assert
 (= due_0_rtx 0))
(assert
 (not active_0_user))
(assert
 (= due_0_user 0))
(assert
 (not active_0_time_wait))
(assert
 (= due_0_time_wait 0))
(assert
 true)
(assert
 (let (($x3896 (= due_1_time_wait due_0_time_wait)))
 (let (($x9697 (= due_1_user 30000)))
 (let (($x7519 (= due_1_rtx 1000)))
 (let (($x499 (not active_1_time_wait)))
 (let (($x1516 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rx_chunk)))
 (let (($x5836 (= v_1_take 0)))
 (let (($x5837 (= v_1_snd_wl2 (_ bv0 32))))
 (let (($x5838 (= v_1_snd_wl1 (_ bv0 32))))
 (let (($x5839 (= v_1_snd_wnd 8)))
 (let (($x1515 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rcv_buf)))
 (let (($x3058 (= (as seq.empty (Seq (_ BitVec 8))) v_1_rtx_buf)))
 (let (($x7686 (= (as seq.empty (Seq (_ BitVec 8))) v_1_snd_buf)))
 (let (($x164 (= v_1_local_window 16)))
 (let (($x5425 (= v_1_msl_ms 60000)))
 (let (($x4657 (= v_1_user_timeout_ms 30000)))
 (let (($x6090 (= 0 v_1_retries)))
 (let (($x1151 (= 1000 v_1_rto_ms)))
 (let (($x3318 (= v_1_tx_flags "S")))
 (let (($x1508 (= v_1_tx_ack (_ bv0 32))))
 (let (($x3889 (= v_1_tx_seq (_ bv1000 32))))
 (let (($x3890 (= v_1_rcv_nxt (_ bv0 32))))
 (let (($x7687 (= v_1_snd_nxt (_ bv1001 32))))
 (let (($x6684 (= v_1_snd_una (_ bv1000 32))))
 (let (($x5130 (= v_1_irs (_ bv0 32))))
 (let (($x5134 (= v_1_iss (_ bv1000 32))))
 (let (($x8181 (= 2 state_1)))
 (let (($x8166 (not active_0_time_wait)))
 (let (($x1432 (or $x8166 (not (<= due_0_time_wait 0)))))
 (let (($x7394 (not active_0_user)))
 (let (($x1318 (or $x7394 (not (<= due_0_user 0)))))
 (let (($x7076 (not active_0_rtx)))
 (let (($x8945 (or $x7076 (not (<= due_0_rtx 0)))))
 (let (($x8356 (= state_0 0)))
 (and $x8356 (>= 0 now_0) $x8945 $x1318 $x1432 $x8181 $x5134 $x5130 $x6684 $x7687 $x3890 $x3889 $x1508 $x3318 $x1151 $x6090 v_1_active_open $x4657 $x5425 $x164 $x7686 $x3058 $x1515 $x5839 $x5838 $x5837 $x5836 $x1516 active_1_rtx active_1_user $x499 $x7519 $x9697 $x3896)))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x8038 (= due_2_time_wait due_1_time_wait)))
 (let (($x2836 (= due_2_user due_1_user)))
 (let (($x5527 (= due_2_rtx due_1_rtx)))
 (let (($x8851 (= active_2_time_wait active_1_time_wait)))
 (let (($x8401 (not active_2_user)))
 (let (($x9721 (not active_2_rtx)))
 (let (($x5786 (= v_2_rx_chunk v_1_rx_chunk)))
 (let (($x8968 (= v_2_take v_1_take)))
 (let (($x7511 (= v_2_snd_wl2 (_ bv1001 32))))
 (let (($x1137 (= v_2_snd_wl1 (_ bv9000 32))))
 (let (($x7508 (= v_2_snd_wnd 8)))
 (let (($x8913 (= v_2_rcv_buf v_1_rcv_buf)))
 (let (($x5615 (= v_2_rtx_buf v_1_rtx_buf)))
 (let (($x5614 (= v_2_snd_buf v_1_snd_buf)))
 (let (($x2095 (= v_2_local_window v_1_local_window)))
 (let (($x2096 (= v_2_msl_ms v_1_msl_ms)))
 (let (($x1791 (= v_2_user_timeout_ms v_1_user_timeout_ms)))
 (let (($x5624 (= v_2_active_open v_1_active_open)))
 (let (($x5125 (= v_2_retries v_1_retries)))
 (let (($x7583 (= v_2_rto_ms v_1_rto_ms)))
 (let (($x5611 (= v_2_tx_flags v_1_tx_flags)))
 (let (($x6082 (= v_2_tx_ack v_1_tx_ack)))
 (let (($x7582 (= v_2_tx_seq v_1_tx_seq)))
 (let (($x7525 (= v_2_rcv_nxt (_ bv9001 32))))
 (let (($x8035 (= v_2_snd_nxt v_1_snd_nxt)))
 (let (($x5539 (= v_2_snd_una (_ bv1001 32))))
 (let (($x7050 (= v_2_irs (_ bv9000 32))))
 (let (($x3467 (= v_2_iss v_1_iss)))
 (let (($x8033 (= 4 state_2)))
 (let (($x499 (not active_1_time_wait)))
 (let (($x5727 (or $x499 (not (<= due_1_time_wait 10)))))
 (let (($x347 (or (not active_1_user) (not (<= due_1_user 10)))))
 (let (($x4617 (or (not active_1_rtx) (not (<= due_1_rtx 10)))))
 (let (($x6090 (= 0 v_1_retries)))
 (let (($x7687 (= v_1_snd_nxt (_ bv1001 32))))
 (let (($x2007 (= state_1 2)))
 (and $x2007 $x7687 $x6090 $x4617 $x347 $x5727 $x8033 $x3467 $x7050 $x5539 $x8035 $x7525 $x7582 $x6082 $x5611 $x7583 $x5125 $x5624 $x1791 $x2096 $x2095 $x5614 $x5615 $x8913 $x7508 $x1137 $x7511 $x8968 $x5786 $x9721 $x8401 $x8851 $x5527 $x2836 $x8038))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x3962 (= due_3_time_wait due_2_time_wait)))
 (let (($x3961 (= due_3_user due_2_user)))
 (let (($x3960 (= due_3_rtx due_2_rtx)))
 (let (($x3959 (= active_3_time_wait active_2_time_wait)))
 (let (($x3958 (= active_3_user active_2_user)))
 (let (($x3957 (= active_3_rtx active_2_rtx)))
 (let (($x3956 (= v_3_rx_chunk v_2_rx_chunk)))
 (let (($x3955 (= v_3_take v_2_take)))
 (let (($x3921 (= v_3_snd_wl2 v_2_snd_wl2)))
 (let (($x3954 (= v_3_snd_wl1 v_2_snd_wl1)))
 (let (($x3953 (= v_3_snd_wnd v_2_snd_wnd)))
 (let (($x3952 (= v_3_rcv_buf v_2_rcv_buf)))
 (let (($x3920 (= v_3_rtx_buf v_2_rtx_buf)))
 (let (($x3951 (= v_3_snd_buf v_2_snd_buf)))
 (let (($x3950 (= v_3_local_window v_2_local_window)))
 (let (($x3949 (= v_3_msl_ms v_2_msl_ms)))
 (let (($x3948 (= v_3_user_timeout_ms v_2_user_timeout_ms)))
 (let (($x3947 (= v_3_active_open v_2_active_open)))
 (let (($x3946 (= v_3_retries v_2_retries)))
 (let (($x3945 (= v_3_rto_ms v_2_rto_ms)))
 (let (($x3944 (= v_3_tx_flags v_2_tx_flags)))
 (let (($x3943 (= v_3_tx_ack v_2_tx_ack)))
 (let (($x3942 (= v_3_tx_seq v_2_tx_seq)))
 (let (($x3941 (= v_3_rcv_nxt v_2_rcv_nxt)))
 (let (($x3940 (= v_3_snd_nxt v_2_snd_nxt)))
 (let (($x3939 (= v_3_snd_una v_2_snd_una)))
 (let (($x3508 (= v_3_irs v_2_irs)))
 (let (($x4526 (= v_3_iss v_2_iss)))
 (let (($x483 (= 4 state_3)))
 (let (($x5139 (or (not active_2_time_wait) (not (<= due_2_time_wait 30)))))
 (let (($x8401 (not active_2_user)))
 (let (($x8812 (or $x8401 (not (<= due_2_user 30)))))
 (let (($x9721 (not active_2_rtx)))
 (let (($x8816 (or $x9721 (not (<= due_2_rtx 30)))))
 (let (($x5830 (or (not (= ((_ extract 31 31) (bvmul (_ bv4294967295 32) v_2_rcv_nxt)) (_ bv0 1))) (bvule (_ bv2147474645 31) (bvmul (_ bv2147483647 31) ((_ extract 30 0) v_2_rcv_nxt))))))
 (let (($x8780 (not (and (bvule (bvmul (_ bv4294967295 32) v_2_rcv_nxt) (_ bv4294958292 32)) $x5830))))
 (let (($x5844 (not (= v_2_rcv_nxt (_ bv9003 32)))))
 (let (($x5539 (= v_2_snd_una (_ bv1001 32))))
 (let (($x4035 (= state_2 4)))
 (and $x4035 $x5539 (= 8 v_2_snd_wnd) $x5844 $x8780 $x8816 $x8812 $x5139 $x483 $x4526 $x3508 $x3939 $x3940 $x3941 $x3942 $x3943 $x3944 $x3945 $x3946 $x3947 $x3948 $x3949 $x3950 $x3951 $x3920 $x3952 $x3953 $x3954 $x3921 $x3955 $x3956 $x3957 $x3958 $x3959 $x3960 $x3961 $x3962)))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x8247 (= due_4_time_wait due_3_time_wait)))
 (let (($x6597 (= due_4_user due_3_user)))
 (let (($x8246 (= due_4_rtx due_3_rtx)))
 (let (($x8245 (= active_4_time_wait active_3_time_wait)))
 (let (($x8244 (= active_4_user active_3_user)))
 (let (($x8243 (= active_4_rtx active_3_rtx)))
 (let ((?x7198 (seq.unit (_ bv1 8))))
 (let ((?x6459 (seq.len v_3_rcv_buf)))
 (let (($x3290 (<= ?x6459 15)))
 (let (($x7771 (>= ?x6459 14)))
 (let (($x8820 (not $x7771)))
 (let (($x588 (or $x8820 $x3290)))
 (let ((?x8793 (ite $x7771 (+ 16 (* (- 1) ?x6459)) 2)))
 (let (($x8795 (<= 0 ?x8793)))
 (let (($x589 (and $x8795 $x588)))
 (let ((?x7202 (seq.++ ?x7198 (seq.unit (_ bv2 8)))))
 (let (($x8823 (or $x8820 (<= ?x6459 14))))
 (let (($x582 (and $x8795 $x8823)))
 (let ((?x1687 (ite $x582 ?x7202 (ite $x589 ?x7198 (as seq.empty (Seq (_ BitVec 8)))))))
 (let (($x8241 (= v_4_take v_3_take)))
 (let (($x6600 (= v_4_snd_wl2 v_3_snd_wl2)))
 (let (($x8240 (= v_4_snd_wl1 v_3_snd_wl1)))
 (let (($x8239 (= v_4_snd_wnd v_3_snd_wnd)))
 (let (($x8238 (= v_4_rtx_buf v_3_rtx_buf)))
 (let (($x8237 (= v_4_snd_buf v_3_snd_buf)))
 (let (($x3974 (= v_4_local_window (+ 16 (* (- 1) ?x6459) (* (- 1) (seq.len ?x1687))))))
 (let (($x8236 (= v_4_msl_ms v_3_msl_ms)))
 (let (($x8235 (= v_4_user_timeout_ms v_3_user_timeout_ms)))
 (let (($x8234 (= v_4_active_open v_3_active_open)))
 (let (($x8233 (= v_4_retries v_3_retries)))
 (let (($x8232 (= v_4_rto_ms v_3_rto_ms)))
 (let (($x8231 (= v_4_tx_flags v_3_tx_flags)))
 (let (($x8230 (= v_4_tx_ack v_3_tx_ack)))
 (let (($x8229 (= v_4_tx_seq v_3_tx_seq)))
 (let ((?x2410 (bvadd v_3_rcv_nxt ((_ int_to_bv 32) (ite $x582 2 (ite $x589 1 0))))))
 (let (($x8227 (= v_4_snd_nxt v_3_snd_nxt)))
 (let (($x8226 (= v_4_snd_una v_3_snd_una)))
 (let (($x8225 (= v_4_irs v_3_irs)))
 (let (($x8224 (= v_4_iss v_3_iss)))
 (let (($x8223 (= 4 state_4)))
 (let (($x9737 (or (not active_3_time_wait) (not (<= due_3_time_wait 31)))))
 (let (($x6698 (or (not active_3_user) (not (<= due_3_user 31)))))
 (let (($x5831 (or (not active_3_rtx) (not (<= due_3_rtx 31)))))
 (let (($x5827 (= v_3_rcv_nxt (_ bv9001 32))))
 (let (($x5826 (= v_3_snd_una (_ bv1001 32))))
 (let (($x5857 (= state_3 4)))
 (and $x5857 $x5826 (= 8 v_3_snd_wnd) $x5827 $x3290 $x5831 $x6698 $x9737 $x8223 $x8224 $x8225 $x8226 $x8227 (= v_4_rcv_nxt ?x2410) $x8229 $x8230 $x8231 $x8232 $x8233 $x8234 $x8235 $x8236 $x3974 $x8237 $x8238 (= v_4_rcv_buf (seq.++ v_3_rcv_buf ?x1687)) $x8239 $x8240 $x6600 $x8241 (= v_4_rx_chunk ?x1687) $x8243 $x8244 $x8245 $x8246 $x6597 $x8247))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x8736 (= due_5_time_wait due_4_time_wait)))
 (let (($x8735 (= due_5_user due_4_user)))
 (let (($x8734 (= due_5_rtx due_4_rtx)))
 (let (($x8702 (= active_5_time_wait active_4_time_wait)))
 (let (($x8733 (= active_5_user active_4_user)))
 (let (($x8732 (= active_5_rtx active_4_rtx)))
 (let ((?x7182 (seq.unit (_ bv3 8))))
 (let ((?x5721 (seq.len v_4_rcv_buf)))
 (let (($x8707 (<= ?x5721 15)))
 (let (($x8822 (>= ?x5721 14)))
 (let (($x5146 (not $x8822)))
 (let (($x8790 (or $x5146 $x8707)))
 (let ((?x8821 (ite $x8822 (+ 16 (* (- 1) ?x5721)) 2)))
 (let (($x8814 (<= 0 ?x8821)))
 (let (($x8791 (and $x8814 $x8790)))
 (let ((?x7185 (seq.unit (_ bv4 8))))
 (let ((?x7186 (seq.++ ?x7182 ?x7185)))
 (let (($x1514 (or $x5146 (<= ?x5721 14))))
 (let (($x318 (and $x8814 $x1514)))
 (let ((?x8708 (ite $x318 ?x7186 (ite $x8791 ?x7182 (as seq.empty (Seq (_ BitVec 8)))))))
 (let (($x8731 (= v_5_take v_4_take)))
 (let (($x8730 (= v_5_snd_wl2 v_4_snd_wl2)))
 (let (($x8729 (= v_5_snd_wl1 v_4_snd_wl1)))
 (let (($x8728 (= v_5_snd_wnd v_4_snd_wnd)))
 (let (($x8726 (= v_5_rtx_buf v_4_rtx_buf)))
 (let (($x8725 (= v_5_snd_buf v_4_snd_buf)))
 (let (($x8325 (= v_5_local_window (+ 16 (* (- 1) ?x5721) (* (- 1) (seq.len ?x8708))))))
 (let (($x8723 (= v_5_msl_ms v_4_msl_ms)))
 (let (($x7976 (= v_5_user_timeout_ms v_4_user_timeout_ms)))
 (let (($x5720 (= v_5_active_open v_4_active_open)))
 (let (($x5719 (= v_5_retries v_4_retries)))
 (let (($x5718 (= v_5_rto_ms v_4_rto_ms)))
 (let (($x5700 (= v_5_tx_flags v_4_tx_flags)))
 (let (($x5699 (= v_5_tx_ack v_4_tx_ack)))
 (let (($x5698 (= v_5_tx_seq v_4_tx_seq)))
 (let ((?x5823 (bvadd v_4_rcv_nxt ((_ int_to_bv 32) (ite $x318 2 (ite $x8791 1 0))))))
 (let (($x5716 (= v_5_snd_nxt v_4_snd_nxt)))
 (let (($x5715 (= v_5_snd_una v_4_snd_una)))
 (let (($x8722 (= v_5_irs v_4_irs)))
 (let (($x5714 (= v_5_iss v_4_iss)))
 (let (($x5713 (= 4 state_5)))
 (let (($x3992 (or (not active_4_time_wait) (not (<= due_4_time_wait 32)))))
 (let (($x8804 (or (not active_4_user) (not (<= due_4_user 32)))))
 (let (($x8798 (or (not active_4_rtx) (not (<= due_4_rtx 32)))))
 (let (($x8352 (= v_4_rcv_nxt (_ bv9003 32))))
 (let (($x8792 (= v_4_snd_una (_ bv1001 32))))
 (let (($x1507 (= state_4 4)))
 (and $x1507 $x8792 (= 8 v_4_snd_wnd) $x8352 $x8707 $x8798 $x8804 $x3992 $x5713 $x5714 $x8722 $x5715 $x5716 (= v_5_rcv_nxt ?x5823) $x5698 $x5699 $x5700 $x5718 $x5719 $x5720 $x7976 $x8723 $x8325 $x8725 $x8726 (= v_5_rcv_buf (seq.++ v_4_rcv_buf ?x8708)) $x8728 $x8729 $x8730 $x8731 (= v_5_rx_chunk ?x8708) $x8732 $x8733 $x8702 $x8734 $x8735 $x8736)))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= (_ bv1000 32) v_0_iss))
(assert
 (= (_ bv0 32) v_0_irs))
(assert
 (= (_ bv1000 32) v_0_snd_una))
(assert
 (= (_ bv1000 32) v_0_snd_nxt))
(assert
 (= (_ bv0 32) v_0_rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_tx_seq))
(assert
 (= (_ bv0 32) v_0_tx_ack))
(assert
 (= v_0_tx_flags "S"))
(assert
 (= 1000 v_0_rto_ms))
(assert
 (= 0 v_0_retries))
(assert
 (= v_0_active_open true))
(assert
 (= 30000 v_0_user_timeout_ms))
(assert
 (= 60000 v_0_msl_ms))
(assert
 (= 16 v_0_local_window))
(assert
 (= v_0_snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_snd_wnd))
(assert
 (= (_ bv0 32) v_0_snd_wl1))
(assert
 (= (_ bv0 32) v_0_snd_wl2))
(assert
 (= 0 v_0_take))
(assert
 (= v_0_rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 4 choice_1))
(assert
 (= 10 now_2))
(assert
 (= (_ bv9000 32) input_1_net.synack_seq))
(assert
 (= (_ bv1001 32) input_1_net.synack_ack))
(assert
 (= 8 input_1_net.synack_window))
(assert
 (= 114 choice_2))
(assert
 (= 30 now_3))
(assert
 (= (_ bv9003 32) input_2_net.data_seq))
(assert
 (= (_ bv1001 32) input_2_net.data_ack))
(assert
 (= 8 input_2_net.data_window))
(assert
 (let ((?x7185 (seq.unit (_ bv4 8))))
 (let ((?x7182 (seq.unit (_ bv3 8))))
 (let ((?x7186 (seq.++ ?x7182 ?x7185)))
 (= input_2_net.data_data ?x7186)))))
(assert
 (= 111 choice_3))
(assert
 (= 31 now_4))
(assert
 (= (_ bv9001 32) input_3_net.data_seq))
(assert
 (= (_ bv1001 32) input_3_net.data_ack))
(assert
 (= 8 input_3_net.data_window))
(assert
 (let ((?x7198 (seq.unit (_ bv1 8))))
 (let ((?x7202 (seq.++ ?x7198 (seq.unit (_ bv2 8)))))
 (= input_3_net.data_data ?x7202))))
(assert
 (= 111 choice_4))
(assert
 (= 32 now_5))
(assert
 (= (_ bv9003 32) input_4_net.data_seq))
(assert
 (= (_ bv1001 32) input_4_net.data_ack))
(assert
 (= 8 input_4_net.data_window))
(assert
 (let ((?x7185 (seq.unit (_ bv4 8))))
(let ((?x7182 (seq.unit (_ bv3 8))))
(let ((?x7186 (seq.++ ?x7182 ?x7185)))
(= input_4_net.data_data ?x7186)))))
(check-sat)

(declare-fun v_0_cb_head () Int)
(declare-fun v_1_rtx_buf () Int)
(declare-fun v_1_cb_count () Int)
(declare-fun state_1 () Int)
(declare-fun state_0 () Int)
(declare-fun choice_0 () Int)
(declare-fun v_0_cb_length_15 () Int)
(declare-fun v_0_cb_end_14 () Int)
(declare-fun v_0_cb_end_15 () Int)
(declare-fun v_0_cb_count () Int)
(declare-fun v_0_cb_length_14 () Int)
(declare-fun v_0_cb_end_13 () Int)
(declare-fun v_0_cb_length_13 () Int)
(declare-fun v_0_cb_end_12 () Int)
(declare-fun v_0_cb_length_12 () Int)
(declare-fun v_0_cb_end_11 () Int)
(declare-fun v_0_cb_length_11 () Int)
(declare-fun v_0_cb_end_10 () Int)
(declare-fun v_0_cb_length_10 () Int)
(declare-fun v_0_cb_end_09 () Int)
(declare-fun v_0_cb_partial_prefix () Int)
(declare-fun v_0_cb_length_09 () Int)
(declare-fun v_0_snd_una () Int)
(declare-fun v_0_cb_length_08 () Int)
(declare-fun v_0_cb_end_07 () Int)
(declare-fun v_0_cb_end_08 () Int)
(declare-fun v_0_cb_length_07 () Int)
(declare-fun v_0_cb_end_06 () Int)
(declare-fun v_0_cb_length_06 () Int)
(declare-fun v_0_cb_end_05 () Int)
(declare-fun v_0_cb_length_05 () Int)
(declare-fun v_0_cb_end_04 () Int)
(declare-fun v_0_cb_length_04 () Int)
(declare-fun v_0_cb_end_03 () Int)
(declare-fun v_0_cb_length_03 () Int)
(declare-fun v_0_cb_end_02 () Int)
(declare-fun v_0_cb_length_02 () Int)
(declare-fun v_0_cb_end_01 () Int)
(declare-fun v_0_cb_length_01 () Int)
(declare-fun v_0_cb_end_00 () Int)
(declare-fun v_0_cb_length_00 () Int)
(declare-fun v_0_svc_written_bytes () Int)
(declare-fun v_0_snd_buf () Int)
(declare-fun v_0_cb_emitted_total () Int)
(declare-fun v_0_rtx_buf () Int)
(declare-fun v_0_cb_live_total () Int)
(declare-fun v_0_cb_abandoned_total () Int)
(declare-fun v_0_cb_acked_total () Int)
(declare-fun v_0_cb_drop_step () Int)
(declare-fun v_0_cb_step_bytes () Int)
(declare-fun v_0_svc_acked_bytes () Int)
(declare-fun v_0_cb_new_count () Int)
(declare-fun v_0_cb_tail () Int)
(declare-fun v_0_svc_drop_step () Int)
(declare-fun v_0_svc_ack_step () Int)
(declare-fun v_0_svc_accept_step () Int)
(declare-fun v_0_cc_acked () Int)
(declare-fun v_0_svc_abandoned_bytes () Int)
(declare-fun v_0_idle_event_ms () Int)
(declare-fun v_0_sched_at_ms () Int)
(declare-fun v_0_sched_open () Bool)
(declare-fun v_0_choice_used () Bool)
(declare-fun v_0_sched_cause () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_sched_bytes () Int)
(declare-fun v_0_sched_packets () Int)
(declare-fun v_0_choice_count () Int)
(declare-fun v_0_choice_before_flight () Int)
(declare-fun v_0_choice_before_nxt () Int)
(declare-fun v_0_snd_nxt () Int)
(declare-fun v_0_cc_send_budget () Int)
(declare-fun v_0_cc_new_sent () Int)
(declare-fun v_0_take () Int)
(declare-fun v_0_choice_limit () Int)
(declare-fun v_0_lt_before_bytes () Int)
(declare-fun v_0_fr_before_flight () Int)
(declare-fun v_0_lt_loss_flight () Int)
(declare-fun v_0_fr_entered () Bool)
(declare-fun v_0_lt_take () Int)
(declare-fun v_0_lt_before_nxt () Int)
(declare-fun v_0_cc_cwnd () Int)
(declare-fun v_0_snd_wnd () Int)
(declare-fun v_0_lt_before_flight () Int)
(declare-fun v_0_lt_before_cwnd () Int)
(declare-fun v_0_fin_sent () Bool)
(declare-fun v_0_fr_active () Bool)
(declare-fun v_0_fr_dupacks () Int)
(declare-fun v_0_fr_duplicate () Bool)
(declare-fun v_0_lt_emitted () Bool)
(declare-fun v_0_lt_epoch_packets () Int)
(declare-fun v_0_lt_epoch_bytes () Int)
(declare-fun v_0_cc_ca_credit () Int)
(declare-fun v_0_idle_before_threshold () Int)
(declare-fun v_0_cc_ssthresh () Int)
(declare-fun v_0_idle_before_cwnd () Int)
(declare-fun v_0_cc_initial_window () Int)
(declare-fun v_0_idle_elapsed_ms () Int)
(declare-fun v_0_idle_before_rto () Int)
(declare-fun v_0_idle_restart () Bool)
(declare-fun v_0_idle_last_data_ms () Int)
(declare-fun v_0_idle_data_emitted () Bool)
(declare-fun v_0_idle_restart_count () Int)
(declare-fun v_0_fr_exited () Bool)
(declare-fun v_0_fr_retransmitted () Bool)
(declare-fun v_0_fr_before_window_valid () Bool)
(declare-fun v_0_fr_window_valid () Bool)
(declare-fun v_0_fr_before_wire_window () Int)
(declare-fun v_0_fr_last_window () Int)
(declare-fun v_0_fr_window_ignored () Bool)
(declare-fun v_0_tx_retransmitted () Bool)
(declare-fun v_0_fr_before_retries () Int)
(declare-fun v_0_retries () Int)
(declare-fun v_0_fr_before_rto () Int)
(declare-fun v_0_rto_ms () Int)
(declare-fun v_0_fr_before_nxt () Int)
(declare-fun v_0_fr_emit_count () Int)
(declare-fun v_0_persist_active () Bool)
(declare-fun v_0_fr_entries () Int)
(declare-fun v_0_cc_rto_15 () Bool)
(declare-fun v_0_cc_rto_14 () Bool)
(declare-fun v_0_cc_rto_13 () Bool)
(declare-fun v_0_cc_rto_12 () Bool)
(declare-fun v_0_cc_rto_11 () Bool)
(declare-fun v_0_cc_rto_10 () Bool)
(declare-fun v_0_cc_rto_09 () Bool)
(declare-fun v_0_cc_rto_08 () Bool)
(declare-fun v_0_cc_rto_07 () Bool)
(declare-fun v_0_cc_rto_06 () Bool)
(declare-fun v_0_cc_rto_05 () Bool)
(declare-fun v_0_cc_rto_04 () Bool)
(declare-fun v_0_cc_rto_03 () Bool)
(declare-fun v_0_cc_rto_02 () Bool)
(declare-fun v_0_cc_rto_01 () Bool)
(declare-fun v_0_cc_rto_00 () Bool)
(declare-fun v_0_cc_threshold_updates () Int)
(declare-fun v_0_cc_growth () Int)
(declare-fun v_0_cc_initial_threshold () Int)
(declare-fun v_0_persist_probes () Int)
(declare-fun v_0_persist_deadline_ms () Int)
(declare-fun v_0_persist_last_ms () Int)
(declare-fun v_0_persist_since_ms () Int)
(declare-fun v_0_tx_time_00 () Int)
(declare-fun v_0_persist_previous_interval_ms () Int)
(declare-fun v_0_persist_elapsed_ms () Int)
(declare-fun v_0_persist_probe_sent () Bool)
(declare-fun v_0_persist_interval_ms () Int)
(declare-fun v_0_rtt_remaining () Int)
(declare-fun v_0_rtt_active () Bool)
(declare-fun active_0_rtx () Bool)
(declare-fun active_0_persist () Bool)
(declare-fun v_0_ack_since_ms () Int)
(declare-fun v_0_ack_full_segments () Int)
(declare-fun v_0_ack_bytes () Int)
(declare-fun v_0_ack_pending () Bool)
(declare-fun v_0_rx_fin_done () Bool)
(declare-fun active_0_delack () Bool)
(declare-fun v_0_ack_rmss () Int)
(declare-fun v_0_ack_delay_ms () Int)
(declare-fun v_0_tx_syn_time () Int)
(declare-fun v_0_tx_syn_pending () Bool)
(declare-fun v_0_tx_waiting () Bool)
(declare-fun v_0_tx_emit_count () Int)
(declare-fun v_0_tx_is_fin () Bool)
(declare-fun v_0_tx_previous_rto () Int)
(declare-fun v_0_tx_elapsed () Int)
(declare-fun v_0_tx_max_previous () Int)
(declare-fun v_0_tx_eligible () Int)
(declare-fun v_0_tx_fin_time () Int)
(declare-fun v_0_tx_time_15 () Int)
(declare-fun v_0_tx_time_14 () Int)
(declare-fun v_0_tx_time_13 () Int)
(declare-fun v_0_tx_time_12 () Int)
(declare-fun v_0_tx_time_11 () Int)
(declare-fun v_0_tx_time_10 () Int)
(declare-fun v_0_tx_time_09 () Int)
(declare-fun v_0_tx_time_08 () Int)
(declare-fun v_0_tx_time_07 () Int)
(declare-fun v_0_tx_time_06 () Int)
(declare-fun v_0_tx_time_05 () Int)
(declare-fun v_0_tx_time_04 () Int)
(declare-fun v_0_tx_time_03 () Int)
(declare-fun v_0_tx_time_02 () Int)
(declare-fun v_0_tx_time_01 () Int)
(declare-fun v_0_rtt_last_ms () Int)
(declare-fun v_0_rtt_previous_srtt () Real)
(declare-fun v_0_rtt_previous_measured () Bool)
(declare-fun v_0_srtt_ms () Real)
(declare-fun v_0_rtt_previous_var () Real)
(declare-fun v_0_rttvar_ms () Real)
(declare-fun v_0_rtt_sample_used () Bool)
(declare-fun v_0_rtt_sample_at_ms () Int)
(declare-fun v_0_rtt_start_ms () Int)
(declare-fun v_0_rtt_measured () Bool)
(declare-fun v_0_rtt_sample_was_ambiguous () Bool)
(declare-fun v_0_rtt_end () Int)
(declare-fun v_0_rtt_samples () Int)
(declare-fun v_0_rto_base_ms () Int)
(declare-fun v_0_rtt_error_ms () Real)
(declare-fun v_0_rx_slot_15 () Int)
(declare-fun v_0_rx_fin_offset () Int)
(declare-fun v_0_rx_fin_pending () Bool)
(declare-fun v_0_rx_slot_14 () Int)
(declare-fun v_0_rx_slot_13 () Int)
(declare-fun v_0_rx_slot_12 () Int)
(declare-fun v_0_rx_slot_11 () Int)
(declare-fun v_0_rx_slot_10 () Int)
(declare-fun v_0_rx_slot_09 () Int)
(declare-fun v_0_rx_slot_08 () Int)
(declare-fun v_0_rx_slot_07 () Int)
(declare-fun v_0_rx_slot_06 () Int)
(declare-fun v_0_rx_slot_05 () Int)
(declare-fun v_0_rx_slot_04 () Int)
(declare-fun v_0_rx_slot_03 () Int)
(declare-fun v_0_rx_slot_02 () Int)
(declare-fun v_0_rx_slot_01 () Int)
(declare-fun v_0_rx_slot_00 () Int)
(declare-fun v_0_rx_fin_seq () Int)
(declare-fun v_0_rcv_nxt () Int)
(declare-fun v_0_local_window () Int)
(declare-fun v_0_fin_requested () Bool)
(declare-fun v_0_ack_delta () Int)
(declare-fun v_0_rx_advance () Int)
(declare-fun v_0_rx_chunk () Int)
(declare-fun v_0_rcv_buf () Int)
(declare-fun v_0_user_timeout_ms () Int)
(declare-fun v_0_msl_ms () Int)
(declare-fun active_0_time_wait () Bool)
(declare-fun active_0_user () Bool)
(declare-fun due_0_persist () Int)
(declare-fun now_1 () Int)
(declare-fun v_0_rtt_ambiguous () Bool)
(declare-fun input_0_net.ack_ack () Int)
(declare-fun input_0_net.ack_seq () Int)
(declare-fun input_0_net.ack_window () Int)
(declare-fun v_0_snd_wl1 () Int)
(declare-fun v_0_snd_wl2 () Int)
(declare-fun due_1_persist () Int)
(declare-fun due_0_delack () Int)
(declare-fun due_1_delack () Int)
(declare-fun due_0_time_wait () Int)
(declare-fun due_1_time_wait () Int)
(declare-fun due_0_user () Int)
(declare-fun due_1_user () Int)
(declare-fun due_0_rtx () Int)
(declare-fun due_1_rtx () Int)
(declare-fun active_1_persist () Bool)
(declare-fun active_1_delack () Bool)
(declare-fun active_1_time_wait () Bool)
(declare-fun active_1_user () Bool)
(declare-fun active_1_rtx () Bool)
(declare-fun v_1_cb_done_15 () Bool)
(declare-fun v_1_cb_end_15 () Int)
(declare-fun v_1_cb_length_15 () Int)
(declare-fun v_1_cb_done_14 () Bool)
(declare-fun v_1_cb_end_14 () Int)
(declare-fun v_1_cb_length_14 () Int)
(declare-fun v_1_cb_done_13 () Bool)
(declare-fun v_1_cb_end_13 () Int)
(declare-fun v_1_cb_length_13 () Int)
(declare-fun v_1_cb_done_12 () Bool)
(declare-fun v_1_cb_end_12 () Int)
(declare-fun v_1_cb_length_12 () Int)
(declare-fun v_1_cb_done_11 () Bool)
(declare-fun v_1_cb_end_11 () Int)
(declare-fun v_1_cb_length_11 () Int)
(declare-fun v_1_cb_done_10 () Bool)
(declare-fun v_1_cb_end_10 () Int)
(declare-fun v_1_cb_length_10 () Int)
(declare-fun v_1_cb_done_09 () Bool)
(declare-fun v_1_cb_end_09 () Int)
(declare-fun v_1_cb_length_09 () Int)
(declare-fun v_1_cb_done_08 () Bool)
(declare-fun v_1_cb_end_08 () Int)
(declare-fun v_1_cb_length_08 () Int)
(declare-fun v_1_cb_done_07 () Bool)
(declare-fun v_1_cb_end_07 () Int)
(declare-fun v_1_cb_length_07 () Int)
(declare-fun v_1_cb_done_06 () Bool)
(declare-fun v_1_cb_end_06 () Int)
(declare-fun v_1_cb_length_06 () Int)
(declare-fun v_1_cb_done_05 () Bool)
(declare-fun v_1_cb_end_05 () Int)
(declare-fun v_1_cb_length_05 () Int)
(declare-fun v_1_cb_done_04 () Bool)
(declare-fun v_1_cb_end_04 () Int)
(declare-fun v_1_cb_length_04 () Int)
(declare-fun v_1_cb_done_03 () Bool)
(declare-fun v_1_cb_end_03 () Int)
(declare-fun v_1_cb_length_03 () Int)
(declare-fun v_1_cb_done_02 () Bool)
(declare-fun v_1_cb_end_02 () Int)
(declare-fun v_1_cb_length_02 () Int)
(declare-fun v_1_cb_done_01 () Bool)
(declare-fun v_1_cb_end_01 () Int)
(declare-fun v_1_cb_length_01 () Int)
(declare-fun v_1_cb_done_00 () Bool)
(declare-fun v_1_cb_end_00 () Int)
(declare-fun v_1_cb_length_00 () Int)
(declare-fun v_1_cb_is_new () Bool)
(declare-fun v_1_cb_append_end () Int)
(declare-fun v_1_cb_before_nxt () Int)
(declare-fun v_1_cb_drop_step () Int)
(declare-fun v_1_cb_abandoned_total () Int)
(declare-fun v_1_cb_acked_total () Int)
(declare-fun v_1_cb_emitted_total () Int)
(declare-fun v_1_cb_partial_prefix () Int)
(declare-fun v_1_cb_live_total () Int)
(declare-fun v_1_cb_step_bytes () Int)
(declare-fun v_1_cb_retired_count () Int)
(declare-fun v_1_cb_append_length () Int)
(declare-fun v_1_cb_new_count () Int)
(declare-fun v_1_cb_tail () Int)
(declare-fun v_1_cb_head () Int)
(declare-fun v_1_svc_abandoned_bytes () Int)
(declare-fun v_1_svc_acked_bytes () Int)
(declare-fun v_1_svc_written_bytes () Int)
(declare-fun v_1_svc_drop_step () Int)
(declare-fun v_1_svc_ack_step () Int)
(declare-fun v_1_svc_accept_step () Int)
(declare-fun v_1_svc_before_total () Int)
(declare-fun v_1_sched_packets () Int)
(declare-fun v_1_sched_bytes () Int)
(declare-fun v_1_sched_cause () Int)
(declare-fun v_1_sched_at_ms () Int)
(declare-fun v_1_sched_open () Bool)
(declare-fun v_1_choice_before_flight () Int)
(declare-fun v_1_choice_before_nxt () Int)
(declare-fun v_1_choice_limit () Int)
(declare-fun v_1_choice_count () Int)
(declare-fun v_1_choice_used () Bool)
(declare-fun v_1_lt_loss_flight () Int)
(declare-fun v_1_lt_before_window () Int)
(declare-fun v_1_lt_before_flight () Int)
(declare-fun v_1_lt_before_nxt () Int)
(declare-fun v_1_lt_before_cwnd () Int)
(declare-fun v_1_lt_before_bytes () Int)
(declare-fun v_1_lt_epoch_packets () Int)
(declare-fun v_1_lt_epoch_bytes () Int)
(declare-fun v_1_lt_take () Int)
(declare-fun v_1_lt_emitted () Bool)
(declare-fun v_1_lt_eligible () Bool)
(declare-fun v_1_idle_restart_count () Int)
(declare-fun v_1_idle_before_threshold () Int)
(declare-fun v_1_idle_before_rto () Int)
(declare-fun v_1_idle_before_cwnd () Int)
(declare-fun v_0_idle_data_valid () Bool)
(declare-fun v_1_idle_elapsed_ms () Int)
(declare-fun v_1_idle_restart () Bool)
(declare-fun v_1_idle_data_emitted () Bool)
(declare-fun v_1_idle_event_ms () Int)
(declare-fun v_1_idle_last_data_ms () Int)
(declare-fun v_1_idle_data_valid () Bool)
(declare-fun v_1_fr_entries () Int)
(declare-fun v_1_fr_emit_count () Int)
(declare-fun v_1_fr_retransmitted () Bool)
(declare-fun v_1_fr_exited () Bool)
(declare-fun v_1_fr_extra () Bool)
(declare-fun v_1_fr_entered () Bool)
(declare-fun v_1_fr_duplicate () Bool)
(declare-fun v_1_fr_before_retries () Int)
(declare-fun v_1_fr_before_rto () Int)
(declare-fun v_1_fr_before_flight () Int)
(declare-fun v_1_fr_before_nxt () Int)
(declare-fun v_1_fr_before_una () Int)
(declare-fun v_1_fr_was_active () Bool)
(declare-fun v_1_fr_last_window () Int)
(declare-fun v_1_fr_window_valid () Bool)
(declare-fun v_1_fr_dupacks () Int)
(declare-fun v_1_fr_active () Bool)
(declare-fun v_1_fr_before_window_valid () Bool)
(declare-fun v_1_fr_before_wire_window () Int)
(declare-fun v_1_fr_window_ignored () Bool)
(declare-fun v_1_cc_rto_15 () Bool)
(declare-fun v_1_cc_rto_14 () Bool)
(declare-fun v_1_cc_rto_13 () Bool)
(declare-fun v_1_cc_rto_12 () Bool)
(declare-fun v_1_cc_rto_11 () Bool)
(declare-fun v_1_cc_rto_10 () Bool)
(declare-fun v_1_cc_rto_09 () Bool)
(declare-fun v_1_cc_rto_08 () Bool)
(declare-fun v_1_cc_rto_07 () Bool)
(declare-fun v_1_cc_rto_06 () Bool)
(declare-fun v_1_cc_rto_05 () Bool)
(declare-fun v_1_cc_rto_04 () Bool)
(declare-fun v_1_cc_rto_03 () Bool)
(declare-fun v_1_cc_rto_02 () Bool)
(declare-fun v_1_cc_rto_01 () Bool)
(declare-fun v_1_cc_rto_00 () Bool)
(declare-fun v_1_cc_new_sent () Int)
(declare-fun v_1_cc_send_budget () Int)
(declare-fun v_1_cc_before_cwnd () Int)
(declare-fun v_1_cc_growth () Int)
(declare-fun v_1_cc_threshold_updates () Int)
(declare-fun v_1_cc_threshold_changed () Bool)
(declare-fun v_1_cc_loss () Bool)
(declare-fun v_1_cc_before_window () Int)
(declare-fun v_1_cc_before_persist () Bool)
(declare-fun v_1_cc_before_una () Int)
(declare-fun v_1_cc_before_flight () Int)
(declare-fun v_1_cc_acked () Int)
(declare-fun v_1_cc_ca_credit () Int)
(declare-fun v_1_cc_ssthresh () Int)
(declare-fun v_1_cc_cwnd () Int)
(declare-fun v_1_cc_initial_threshold () Int)
(declare-fun v_1_cc_initial_window () Int)
(declare-fun v_1_persist_elapsed_ms () Int)
(declare-fun v_1_persist_probes () Int)
(declare-fun v_1_persist_deadline_ms () Int)
(declare-fun v_1_persist_last_ms () Int)
(declare-fun v_1_persist_since_ms () Int)
(declare-fun v_1_persist_previous_interval_ms () Int)
(declare-fun v_1_persist_interval_ms () Int)
(declare-fun v_1_persist_probe_new () Bool)
(declare-fun v_1_persist_probe_sent () Bool)
(declare-fun v_1_persist_first () Bool)
(declare-fun v_1_persist_was_active () Bool)
(declare-fun v_1_persist_start () Bool)
(declare-fun v_1_persist_eligible () Bool)
(declare-fun v_1_persist_active () Bool)
(declare-fun v_1_ack_defer_now () Bool)
(declare-fun v_1_ack_defer_candidate () Bool)
(declare-fun v_1_ack_rmss () Int)
(declare-fun v_1_ack_delay_ms () Int)
(declare-fun v_1_ack_full_segments () Int)
(declare-fun v_1_ack_bytes () Int)
(declare-fun v_1_ack_since_ms () Int)
(declare-fun v_1_ack_pending () Bool)
(declare-fun v_1_syn_timeout_eligible () Bool)
(declare-fun v_1_tx_syn_pending () Bool)
(declare-fun v_1_tx_syn_time () Int)
(declare-fun v_1_tx_waiting () Bool)
(declare-fun v_1_tx_is_fin () Bool)
(declare-fun v_1_tx_previous_rto () Int)
(declare-fun v_1_tx_elapsed () Int)
(declare-fun v_1_tx_retransmitted () Bool)
(declare-fun v_1_tx_max_previous () Int)
(declare-fun v_1_tx_eligible () Int)
(declare-fun v_1_tx_emit_count () Int)
(declare-fun v_0_fin_acknowledged () Bool)
(declare-fun v_1_tx_fin_time () Int)
(declare-fun v_1_tx_time_15 () Int)
(declare-fun v_1_tx_time_14 () Int)
(declare-fun v_1_tx_time_13 () Int)
(declare-fun v_1_tx_time_12 () Int)
(declare-fun v_1_tx_time_11 () Int)
(declare-fun v_1_tx_time_10 () Int)
(declare-fun v_1_tx_time_09 () Int)
(declare-fun v_1_tx_time_08 () Int)
(declare-fun v_1_tx_time_07 () Int)
(declare-fun v_1_tx_time_06 () Int)
(declare-fun v_1_tx_time_05 () Int)
(declare-fun v_1_tx_time_04 () Int)
(declare-fun v_1_tx_time_03 () Int)
(declare-fun v_1_tx_time_02 () Int)
(declare-fun v_1_tx_time_01 () Int)
(declare-fun v_1_tx_time_00 () Int)
(declare-fun v_1_rto_base_ms () Int)
(declare-fun v_1_rtt_samples () Int)
(declare-fun v_1_rtt_last_ms () Int)
(declare-fun v_1_rtt_sample_was_ambiguous () Bool)
(declare-fun v_1_rtt_sample_used () Bool)
(declare-fun v_1_rtt_start_new () Bool)
(declare-fun v_1_rtt_remaining () Int)
(declare-fun v_1_rtt_end () Int)
(declare-fun v_1_rtt_start_ms () Int)
(declare-fun v_1_rtt_sample_at_ms () Int)
(declare-fun v_1_rtt_ambiguous () Bool)
(declare-fun v_1_rtt_active () Bool)
(declare-fun v_1_rtt_previous_measured () Bool)
(declare-fun v_1_rtt_measured () Bool)
(declare-fun v_1_rtt_previous_var () Real)
(declare-fun v_1_rtt_previous_srtt () Real)
(declare-fun v_1_rtt_error_ms () Real)
(declare-fun v_1_rttvar_ms () Real)
(declare-fun v_1_srtt_ms () Real)
(declare-fun v_0_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_consumed () Bool)
(declare-fun v_1_rx_fin_done () Bool)
(declare-fun v_1_rx_fin_offset () Int)
(declare-fun v_1_rx_fin_seq () Int)
(declare-fun v_1_rx_fin_pending () Bool)
(declare-fun v_1_fin_acknowledged () Bool)
(declare-fun v_0_fin_seq () Int)
(declare-fun v_1_fin_seq () Int)
(declare-fun v_1_fin_sent () Bool)
(declare-fun v_1_fin_requested () Bool)
(declare-fun v_1_ack_window_update () Bool)
(declare-fun v_1_ack_advance () Bool)
(declare-fun v_1_ack_is_future () Bool)
(declare-fun v_1_ack_is_new () Bool)
(declare-fun v_1_ack_delta () Int)
(declare-fun v_1_seg_acceptable () Bool)
(declare-fun v_0_rx_acceptable () Bool)
(declare-fun v_1_rx_acceptable () Bool)
(declare-fun v_1_rx_advance () Int)
(declare-fun v_1_rx_slot_15 () Int)
(declare-fun v_1_rx_slot_14 () Int)
(declare-fun v_1_rx_slot_13 () Int)
(declare-fun v_1_rx_slot_12 () Int)
(declare-fun v_1_rx_slot_11 () Int)
(declare-fun v_1_rx_slot_10 () Int)
(declare-fun v_1_rx_slot_09 () Int)
(declare-fun v_1_rx_slot_08 () Int)
(declare-fun v_1_rx_slot_07 () Int)
(declare-fun v_1_rx_slot_06 () Int)
(declare-fun v_1_rx_slot_05 () Int)
(declare-fun v_1_rx_slot_04 () Int)
(declare-fun v_1_rx_slot_03 () Int)
(declare-fun v_1_rx_slot_02 () Int)
(declare-fun v_1_rx_slot_01 () Int)
(declare-fun v_1_rx_slot_00 () Int)
(declare-fun v_1_rx_chunk () Int)
(declare-fun v_1_take () Int)
(declare-fun v_1_snd_wl2 () Int)
(declare-fun v_1_snd_wl1 () Int)
(declare-fun v_1_snd_wnd () Int)
(declare-fun v_1_rcv_buf () Int)
(declare-fun v_1_snd_buf () Int)
(declare-fun v_1_local_window () Int)
(declare-fun v_1_msl_ms () Int)
(declare-fun v_1_user_timeout_ms () Int)
(declare-fun v_0_active_open () Bool)
(declare-fun v_1_active_open () Bool)
(declare-fun v_1_retries () Int)
(declare-fun v_1_rto_ms () Int)
(declare-fun v_0_tx_flags () String)
(declare-fun v_1_tx_flags () String)
(declare-fun v_0_tx_ack () Int)
(declare-fun v_1_tx_ack () Int)
(declare-fun v_0_tx_seq () Int)
(declare-fun v_1_tx_seq () Int)
(declare-fun v_1_rcv_nxt () Int)
(declare-fun v_1_snd_nxt () Int)
(declare-fun v_1_snd_una () Int)
(declare-fun v_0_irs () Int)
(declare-fun v_1_irs () Int)
(declare-fun v_0_iss () Int)
(declare-fun v_1_iss () Int)
(declare-fun input_0_net.fin_segment_ack () Int)
(declare-fun input_0_net.fin_segment_seq () Int)
(declare-fun input_0_net.data_ack () Int)
(declare-fun input_0_net.data_seq () Int)
(declare-fun input_0_net.rstack_ack () Int)
(declare-fun input_0_net.rstack_seq () Int)
(declare-fun input_0_net.rst_seq () Int)
(declare-fun input_0_net.fin_ack () Int)
(declare-fun input_0_net.fin_seq () Int)
(declare-fun input_0_net.synack_ack () Int)
(declare-fun input_0_net.synack_seq () Int)
(declare-fun input_0_net.syn_seq () Int)
(declare-fun input_0_net.fin_segment_data () Int)
(declare-fun input_0_net.data_data () Int)
(declare-fun input_0_app.send_data () Int)
(declare-fun v_0_cb_append_end () Int)
(declare-fun v_0_cb_before_nxt () Int)
(declare-fun v_0_fr_before_una () Int)
(declare-fun v_0_cc_before_una () Int)
(assert (= v_0_cb_head 9))
(assert (let ((a!1 (>= (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) (- 4294967296)))
      (a!2 (< (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 8589934592))
      (a!3 (< (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 0))
      (a!4 (+ (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!5 (>= (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!6 (- (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!8 (mod (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296))
      (a!10 (>= (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) (- 4294967296)))
      (a!11 (< (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 8589934592))
      (a!12 (< (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 0))
      (a!13 (+ (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!14 (>= (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!15 (- (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!17 (mod (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296))
      (a!19 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) (- 4294967296)))
      (a!20 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 8589934592))
      (a!21 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 0))
      (a!22 (+ (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!23 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!24 (- (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!26 (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296))
      (a!28 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) (- 4294967296)))
      (a!29 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 8589934592))
      (a!30 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 0))
      (a!31 (+ (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!32 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!33 (- (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!35 (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296))
      (a!41 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) (- 4294967296)))
      (a!42 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 8589934592))
      (a!43 (< (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 0))
      (a!44 (+ (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!45 (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!46 (- (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!48 (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296))
      (a!50 (>= (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) (- 4294967296)))
      (a!51 (< (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 8589934592))
      (a!52 (< (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 0))
      (a!53 (+ (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!54 (>= (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!55 (- (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!57 (mod (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296))
      (a!66 (and (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)))
      (a!74 (+ (* (- (/ 1.0 2.0)) (to_real v_0_rtx_buf))
               (* (/ 1.0 2.0) (to_real v_0_lt_epoch_bytes))))
      (a!77 (and (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)
                 v_0_fr_active))
      (a!91 (>= (+ v_0_rtt_end (* (- 1) v_0_snd_una)) (- 4294967296)))
      (a!92 (< (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 8589934592))
      (a!93 (< (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 0))
      (a!94 (+ (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!95 (>= (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!96 (- (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!98 (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296))
      (a!258 (= v_1_tx_fin_time
                (ite (and v_0_fin_sent (not v_0_fin_acknowledged))
                     v_0_tx_fin_time
                     0)))
      (a!265 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd)
                (* (- 1) v_0_rtx_buf)))
      (a!369 (ite v_0_idle_data_valid
                  (+ now_1 (* (- 1) v_0_idle_last_data_ms))
                  0))
      (a!373 (= v_1_lt_loss_flight (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes))))
      (a!376 (ite (>= 0 v_0_cb_head)
                  (* (- 1) v_0_cb_head)
                  (+ 16 (* (- 1) v_0_cb_head))))
      (a!387 (ite (>= 1 v_0_cb_head)
                  (+ 1 (* (- 1) v_0_cb_head))
                  (+ 17 (* (- 1) v_0_cb_head))))
      (a!398 (ite (>= 2 v_0_cb_head)
                  (+ 2 (* (- 1) v_0_cb_head))
                  (+ 18 (* (- 1) v_0_cb_head))))
      (a!409 (ite (>= 3 v_0_cb_head)
                  (+ 3 (* (- 1) v_0_cb_head))
                  (+ 19 (* (- 1) v_0_cb_head))))
      (a!420 (ite (>= 4 v_0_cb_head)
                  (+ 4 (* (- 1) v_0_cb_head))
                  (+ 20 (* (- 1) v_0_cb_head))))
      (a!431 (ite (>= 5 v_0_cb_head)
                  (+ 5 (* (- 1) v_0_cb_head))
                  (+ 21 (* (- 1) v_0_cb_head))))
      (a!442 (ite (>= 6 v_0_cb_head)
                  (+ 6 (* (- 1) v_0_cb_head))
                  (+ 22 (* (- 1) v_0_cb_head))))
      (a!453 (ite (>= 7 v_0_cb_head)
                  (+ 7 (* (- 1) v_0_cb_head))
                  (+ 23 (* (- 1) v_0_cb_head))))
      (a!464 (ite (>= 8 v_0_cb_head)
                  (+ 8 (* (- 1) v_0_cb_head))
                  (+ 24 (* (- 1) v_0_cb_head))))
      (a!475 (ite (>= 9 v_0_cb_head)
                  (+ 9 (* (- 1) v_0_cb_head))
                  (+ 25 (* (- 1) v_0_cb_head))))
      (a!486 (ite (>= 10 v_0_cb_head)
                  (+ 10 (* (- 1) v_0_cb_head))
                  (+ 26 (* (- 1) v_0_cb_head))))
      (a!497 (ite (>= 11 v_0_cb_head)
                  (+ 11 (* (- 1) v_0_cb_head))
                  (+ 27 (* (- 1) v_0_cb_head))))
      (a!508 (ite (>= 12 v_0_cb_head)
                  (+ 12 (* (- 1) v_0_cb_head))
                  (+ 28 (* (- 1) v_0_cb_head))))
      (a!519 (ite (>= 13 v_0_cb_head)
                  (+ 13 (* (- 1) v_0_cb_head))
                  (+ 29 (* (- 1) v_0_cb_head))))
      (a!530 (ite (>= 14 v_0_cb_head)
                  (+ 14 (* (- 1) v_0_cb_head))
                  (+ 30 (* (- 1) v_0_cb_head))))
      (a!541 (ite (>= 15 v_0_cb_head)
                  (+ 15 (* (- 1) v_0_cb_head))
                  (+ 31 (* (- 1) v_0_cb_head))))
      (a!672 (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf))))
      (a!673 (>= 16
                 (+ v_0_rcv_buf
                    v_0_rx_slot_00
                    v_0_rx_slot_01
                    v_0_rx_slot_02
                    v_0_rx_slot_03
                    v_0_rx_slot_04
                    v_0_rx_slot_05
                    v_0_rx_slot_06
                    v_0_rx_slot_07
                    v_0_rx_slot_08
                    v_0_rx_slot_09
                    v_0_rx_slot_10
                    v_0_rx_slot_11
                    v_0_rx_slot_12
                    v_0_rx_slot_13
                    v_0_rx_slot_14
                    v_0_rx_slot_15)))
      (a!674 (and (>= (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                      (- 4294967296))
                  (< (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                     8589934592)))
      (a!675 (ite (>= (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                      4294967296)
                  (- (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                     4294967296)
                  (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))))
      (a!678 (and (not v_0_rx_fin_done)
                  (<= 1 v_0_rx_fin_offset)
                  (<= v_0_rx_fin_offset (+ (- 1) v_0_local_window))))
      (a!679 (ite (< (+ v_0_rcv_nxt v_0_rx_fin_offset) 0)
                  (+ (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                  (ite (>= (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                       (- (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                       (+ v_0_rcv_nxt v_0_rx_fin_offset))))
      (a!681 (ite (< (+ 1 v_0_rx_fin_seq) 0)
                  (+ (+ 1 v_0_rx_fin_seq) 4294967296)
                  (ite (>= (+ 1 v_0_rx_fin_seq) 4294967296)
                       (- (+ 1 v_0_rx_fin_seq) 4294967296)
                       (+ 1 v_0_rx_fin_seq))))
      (a!683 (or (not (and v_0_rx_fin_pending (>= 0 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_00)))
      (a!684 (or (not (and v_0_rx_fin_pending (>= 1 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_01)))
      (a!685 (or (not (and v_0_rx_fin_pending (>= 2 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_02)))
      (a!686 (or (not (and v_0_rx_fin_pending (>= 3 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_03)))
      (a!687 (or (not (and v_0_rx_fin_pending (>= 4 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_04)))
      (a!688 (or (not (and v_0_rx_fin_pending (>= 5 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_05)))
      (a!689 (or (not (and v_0_rx_fin_pending (>= 6 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_06)))
      (a!690 (or (not (and v_0_rx_fin_pending (>= 7 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_07)))
      (a!691 (or (not (and v_0_rx_fin_pending (>= 8 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_08)))
      (a!692 (or (not (and v_0_rx_fin_pending (>= 9 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_09)))
      (a!693 (or (not (and v_0_rx_fin_pending (>= 10 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_10)))
      (a!694 (or (not (and v_0_rx_fin_pending (>= 11 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_11)))
      (a!695 (or (not (and v_0_rx_fin_pending (>= 12 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_12)))
      (a!696 (or (not (and v_0_rx_fin_pending (>= 13 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_13)))
      (a!697 (or (not (and v_0_rx_fin_pending (>= 14 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_14)))
      (a!698 (or (not (and v_0_rx_fin_pending (>= 15 v_0_rx_fin_offset)))
                 (= 0 v_0_rx_slot_15)))
      (a!699 (* (- 1.0)
                (ite (<= v_0_rttvar_ms (/ 1.0 4.0)) 1.0 (* 4.0 v_0_rttvar_ms))))
      (a!703 (>= (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) (- 4294967296)))
      (a!704 (< (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 8589934592))
      (a!705 (< (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 0))
      (a!706 (+ (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!707 (>= (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!708 (- (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!710 (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296))
      (a!712 (= v_0_rtt_last_ms
                (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms))))
      (a!713 (>= (+ v_0_rtt_previous_srtt (* (- 1.0) (to_real v_0_rtt_last_ms)))
                 0.0))
      (a!716 (ite v_0_rtt_previous_measured
                  (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt)
                     (* (/ 1.0 8.0) (to_real v_0_rtt_last_ms)))
                  (to_real v_0_rtt_last_ms)))
      (a!717 (or (not v_0_tx_retransmitted)
                 (and (>= v_0_tx_elapsed v_0_tx_previous_rto)
                      (<= 1 v_0_tx_emit_count)
                      (or (not v_0_tx_is_fin) (= 1 v_0_tx_emit_count)))))
      (a!718 (or v_0_ack_pending
                 (and (= 0 v_0_ack_bytes)
                      (= 0 v_0_ack_full_segments)
                      (= 0 v_0_ack_since_ms))))
      (a!719 (and (<= 1 (+ v_0_rtx_buf (ite v_0_fin_sent 1 0)))
                  (not v_0_persist_active)))
      (a!720 (or (not v_0_persist_active)
                 (and (= 0 v_0_snd_wnd)
                      (not v_0_fin_sent)
                      (<= 1 (+ v_0_rtx_buf v_0_snd_buf))
                      (>= 1 v_0_rtx_buf)
                      (not active_0_rtx))))
      (a!721 (= v_0_persist_deadline_ms
                (+ (ite (= 0 v_0_persist_probes)
                        v_0_persist_since_ms
                        v_0_persist_last_ms)
                   v_0_persist_interval_ms)))
      (a!722 (or (not v_0_persist_probe_sent)
                 (and (>= v_0_persist_elapsed_ms
                          v_0_persist_previous_interval_ms)
                      (= 1 v_0_rtx_buf))))
      (a!723 (or (not (and v_0_persist_active
                           (<= 1 v_0_persist_probes)
                           (= 1 v_0_rtx_buf)))
                 (= v_0_tx_time_00 v_0_persist_last_ms)))
      (a!724 (or v_0_persist_active
                 (and (= 0 v_0_persist_since_ms)
                      (= 0 v_0_persist_last_ms)
                      (= 0 v_0_persist_deadline_ms)
                      (= 0 v_0_persist_probes))))
      (a!725 (or (not v_0_fr_active)
                 (and (<= 3 v_0_fr_dupacks)
                      (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active))))
      (a!726 (or (not v_0_fr_retransmitted)
                 (and v_0_fr_entered
                      (= 3 v_0_fr_dupacks)
                      (<= 1 v_0_fr_emit_count)
                      (= v_0_snd_nxt v_0_fr_before_nxt)
                      (= v_0_rto_ms v_0_fr_before_rto)
                      (= v_0_retries v_0_fr_before_retries)
                      (not v_0_tx_retransmitted))))
      (a!727 (or (not v_0_fr_window_ignored)
                 (and (= v_0_fr_last_window v_0_fr_before_wire_window)
                      (= v_0_fr_window_valid v_0_fr_before_window_valid))))
      (a!728 (or (not v_0_fr_exited)
                 (and (= v_0_cc_cwnd v_0_cc_ssthresh) (= 0 v_0_cc_ca_credit))))
      (a!729 (and (not (>= v_0_idle_before_rto v_0_idle_elapsed_ms))
                  (= v_0_cc_cwnd
                     (ite (<= v_0_cc_initial_window v_0_idle_before_cwnd)
                          v_0_cc_initial_window
                          v_0_idle_before_cwnd))
                  (= v_0_cc_ssthresh v_0_idle_before_threshold)
                  (= 0 v_0_cc_ca_credit)))
      (a!730 (ite (< (+ v_0_lt_before_nxt v_0_lt_take) 0)
                  (+ (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                  (ite (>= (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                       (- (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                       (+ v_0_lt_before_nxt v_0_lt_take))))
      (a!733 (= v_0_lt_loss_flight
                (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes))))
      (a!734 (ite (< (+ v_0_choice_before_nxt v_0_choice_count) 0)
                  (+ (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)
                  (ite (>= (+ v_0_choice_before_nxt v_0_choice_count)
                           4294967296)
                       (- (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)
                       (+ v_0_choice_before_nxt v_0_choice_count))))
      (a!737 (= v_0_cb_tail
                (ite (<= 16 (+ v_0_cb_head v_0_cb_count))
                     (+ (- 16) v_0_cb_head v_0_cb_count)
                     (+ v_0_cb_head v_0_cb_count))))
      (a!738 (= v_0_cb_live_total
                (+ v_0_cb_length_00
                   v_0_cb_length_01
                   v_0_cb_length_02
                   v_0_cb_length_03
                   v_0_cb_length_04
                   v_0_cb_length_05
                   v_0_cb_length_06
                   v_0_cb_length_07
                   v_0_cb_length_08
                   v_0_cb_length_09
                   v_0_cb_length_10
                   v_0_cb_length_11
                   v_0_cb_length_12
                   v_0_cb_length_13
                   v_0_cb_length_14
                   v_0_cb_length_15)))
      (a!739 (= v_0_cb_partial_prefix
                (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf))))
      (a!741 (>= (+ v_0_snd_una
                    v_0_cb_length_00
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!742 (< (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!743 (< (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!744 (+ (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!745 (>= (+ v_0_snd_una
                    v_0_cb_length_00
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!746 (- (+ v_0_snd_una v_0_cb_length_00 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!748 (mod (+ v_0_snd_una
                     v_0_cb_length_00
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!751 (ite (< (+ v_0_cb_end_15 v_0_cb_length_00) 0)
                  (+ (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                  (ite (>= (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                       (- (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                       (+ v_0_cb_end_15 v_0_cb_length_00))))
      (a!754 (>= (+ v_0_snd_una
                    v_0_cb_length_01
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!755 (< (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!756 (< (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!757 (+ (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!758 (>= (+ v_0_snd_una
                    v_0_cb_length_01
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!759 (- (+ v_0_snd_una v_0_cb_length_01 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!761 (mod (+ v_0_snd_una
                     v_0_cb_length_01
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!764 (ite (< (+ v_0_cb_end_00 v_0_cb_length_01) 0)
                  (+ (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                  (ite (>= (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                       (- (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                       (+ v_0_cb_end_00 v_0_cb_length_01))))
      (a!767 (>= (+ v_0_snd_una
                    v_0_cb_length_02
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!768 (< (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!769 (< (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!770 (+ (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!771 (>= (+ v_0_snd_una
                    v_0_cb_length_02
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!772 (- (+ v_0_snd_una v_0_cb_length_02 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!774 (mod (+ v_0_snd_una
                     v_0_cb_length_02
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!777 (ite (< (+ v_0_cb_end_01 v_0_cb_length_02) 0)
                  (+ (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                  (ite (>= (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                       (- (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                       (+ v_0_cb_end_01 v_0_cb_length_02))))
      (a!780 (>= (+ v_0_snd_una
                    v_0_cb_length_03
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!781 (< (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!782 (< (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!783 (+ (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!784 (>= (+ v_0_snd_una
                    v_0_cb_length_03
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!785 (- (+ v_0_snd_una v_0_cb_length_03 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!787 (mod (+ v_0_snd_una
                     v_0_cb_length_03
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!790 (ite (< (+ v_0_cb_end_02 v_0_cb_length_03) 0)
                  (+ (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                  (ite (>= (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                       (- (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                       (+ v_0_cb_end_02 v_0_cb_length_03))))
      (a!793 (>= (+ v_0_snd_una
                    v_0_cb_length_04
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!794 (< (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!795 (< (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!796 (+ (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!797 (>= (+ v_0_snd_una
                    v_0_cb_length_04
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!798 (- (+ v_0_snd_una v_0_cb_length_04 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!800 (mod (+ v_0_snd_una
                     v_0_cb_length_04
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!803 (ite (< (+ v_0_cb_end_03 v_0_cb_length_04) 0)
                  (+ (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                  (ite (>= (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                       (- (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                       (+ v_0_cb_end_03 v_0_cb_length_04))))
      (a!806 (>= (+ v_0_snd_una
                    v_0_cb_length_05
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!807 (< (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!808 (< (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!809 (+ (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!810 (>= (+ v_0_snd_una
                    v_0_cb_length_05
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!811 (- (+ v_0_snd_una v_0_cb_length_05 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!813 (mod (+ v_0_snd_una
                     v_0_cb_length_05
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!816 (ite (< (+ v_0_cb_end_04 v_0_cb_length_05) 0)
                  (+ (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                  (ite (>= (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                       (- (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                       (+ v_0_cb_end_04 v_0_cb_length_05))))
      (a!819 (>= (+ v_0_snd_una
                    v_0_cb_length_06
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!820 (< (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!821 (< (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!822 (+ (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!823 (>= (+ v_0_snd_una
                    v_0_cb_length_06
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!824 (- (+ v_0_snd_una v_0_cb_length_06 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!826 (mod (+ v_0_snd_una
                     v_0_cb_length_06
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!829 (ite (< (+ v_0_cb_end_05 v_0_cb_length_06) 0)
                  (+ (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                  (ite (>= (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                       (- (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                       (+ v_0_cb_end_05 v_0_cb_length_06))))
      (a!832 (>= (+ v_0_snd_una
                    v_0_cb_length_07
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!833 (< (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!834 (< (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!835 (+ (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!836 (>= (+ v_0_snd_una
                    v_0_cb_length_07
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!837 (- (+ v_0_snd_una v_0_cb_length_07 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!839 (mod (+ v_0_snd_una
                     v_0_cb_length_07
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!842 (ite (< (+ v_0_cb_end_06 v_0_cb_length_07) 0)
                  (+ (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                  (ite (>= (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                       (- (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                       (+ v_0_cb_end_06 v_0_cb_length_07))))
      (a!845 (>= (+ v_0_snd_una
                    v_0_cb_length_08
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!846 (< (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!847 (< (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!848 (+ (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!849 (>= (+ v_0_snd_una
                    v_0_cb_length_08
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!850 (- (+ v_0_snd_una v_0_cb_length_08 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!852 (mod (+ v_0_snd_una
                     v_0_cb_length_08
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!855 (ite (< (+ v_0_cb_end_07 v_0_cb_length_08) 0)
                  (+ (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                  (ite (>= (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                       (- (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                       (+ v_0_cb_end_07 v_0_cb_length_08))))
      (a!858 (>= (+ v_0_snd_una
                    v_0_cb_length_09
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!859 (< (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!860 (< (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!861 (+ (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!862 (>= (+ v_0_snd_una
                    v_0_cb_length_09
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!863 (- (+ v_0_snd_una v_0_cb_length_09 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!865 (mod (+ v_0_snd_una
                     v_0_cb_length_09
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!868 (ite (< (+ v_0_cb_end_08 v_0_cb_length_09) 0)
                  (+ (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)
                  (ite (>= (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)
                       (- (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)
                       (+ v_0_cb_end_08 v_0_cb_length_09))))
      (a!871 (>= (+ v_0_snd_una
                    v_0_cb_length_10
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!872 (< (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!873 (< (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!874 (+ (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!875 (>= (+ v_0_snd_una
                    v_0_cb_length_10
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!876 (- (+ v_0_snd_una v_0_cb_length_10 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!878 (mod (+ v_0_snd_una
                     v_0_cb_length_10
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!881 (ite (< (+ v_0_cb_end_09 v_0_cb_length_10) 0)
                  (+ (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                  (ite (>= (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                       (- (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                       (+ v_0_cb_end_09 v_0_cb_length_10))))
      (a!884 (>= (+ v_0_snd_una
                    v_0_cb_length_11
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!885 (< (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!886 (< (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!887 (+ (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!888 (>= (+ v_0_snd_una
                    v_0_cb_length_11
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!889 (- (+ v_0_snd_una v_0_cb_length_11 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!891 (mod (+ v_0_snd_una
                     v_0_cb_length_11
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!894 (ite (< (+ v_0_cb_end_10 v_0_cb_length_11) 0)
                  (+ (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                  (ite (>= (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                       (- (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                       (+ v_0_cb_end_10 v_0_cb_length_11))))
      (a!897 (>= (+ v_0_snd_una
                    v_0_cb_length_12
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!898 (< (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!899 (< (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!900 (+ (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!901 (>= (+ v_0_snd_una
                    v_0_cb_length_12
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!902 (- (+ v_0_snd_una v_0_cb_length_12 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!904 (mod (+ v_0_snd_una
                     v_0_cb_length_12
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!907 (ite (< (+ v_0_cb_end_11 v_0_cb_length_12) 0)
                  (+ (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                  (ite (>= (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                       (- (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                       (+ v_0_cb_end_11 v_0_cb_length_12))))
      (a!910 (>= (+ v_0_snd_una
                    v_0_cb_length_13
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!911 (< (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!912 (< (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!913 (+ (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!914 (>= (+ v_0_snd_una
                    v_0_cb_length_13
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!915 (- (+ v_0_snd_una v_0_cb_length_13 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!917 (mod (+ v_0_snd_una
                     v_0_cb_length_13
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!920 (ite (< (+ v_0_cb_end_12 v_0_cb_length_13) 0)
                  (+ (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                  (ite (>= (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                       (- (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                       (+ v_0_cb_end_12 v_0_cb_length_13))))
      (a!923 (>= (+ v_0_snd_una
                    v_0_cb_length_14
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!924 (< (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!925 (< (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!926 (+ (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!927 (>= (+ v_0_snd_una
                    v_0_cb_length_14
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!928 (- (+ v_0_snd_una v_0_cb_length_14 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!930 (mod (+ v_0_snd_una
                     v_0_cb_length_14
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!933 (ite (< (+ v_0_cb_end_13 v_0_cb_length_14) 0)
                  (+ (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                  (ite (>= (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                       (- (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                       (+ v_0_cb_end_13 v_0_cb_length_14))))
      (a!936 (>= (+ v_0_snd_una
                    v_0_cb_length_15
                    (* (- 1) v_0_cb_partial_prefix))
                 (- 4294967296)))
      (a!937 (< (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                8589934592))
      (a!938 (< (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                0))
      (a!939 (+ (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!940 (>= (+ v_0_snd_una
                    v_0_cb_length_15
                    (* (- 1) v_0_cb_partial_prefix))
                 4294967296))
      (a!941 (- (+ v_0_snd_una v_0_cb_length_15 (* (- 1) v_0_cb_partial_prefix))
                4294967296))
      (a!943 (mod (+ v_0_snd_una
                     v_0_cb_length_15
                     (* (- 1) v_0_cb_partial_prefix))
                  4294967296))
      (a!946 (ite (< (+ v_0_cb_end_14 v_0_cb_length_15) 0)
                  (+ (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                  (ite (>= (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                       (- (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                       (+ v_0_cb_end_14 v_0_cb_length_15))))
      (a!949 (not (<= 8589934592 (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)))))
      (a!951 (ite (>= (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296)
                  (+ (- 4294967296) v_0_rcv_nxt (* (- 1) input_0_net.ack_seq))
                  (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq))))
      (a!954 (not (<= 8589934592 (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)))))
      (a!956 (ite (>= (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296)
                  (+ (- 4294967296) input_0_net.ack_seq (* (- 1) v_0_rcv_nxt))
                  (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt))))
      (a!960 (not (<= 8589934592 (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)))))
      (a!962 (ite (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296)
                  (+ (- 4294967296) input_0_net.ack_ack (* (- 1) v_0_snd_una))
                  (+ input_0_net.ack_ack (* (- 1) v_0_snd_una))))
      (a!965 (not (<= 8589934592 (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)))))
      (a!967 (ite (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296)
                  (+ (- 4294967296) input_0_net.ack_ack (* (- 1) v_0_snd_nxt))
                  (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt))))
      (a!972 (not (<= 8589934592 (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)))))
      (a!974 (ite (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296)
                  (+ (- 4294967296) input_0_net.ack_ack (* (- 1) v_0_snd_wl2))
                  (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2))))
      (a!977 (not (<= 8589934592 (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)))))
      (a!979 (ite (>= (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296)
                  (+ (- 4294967296) input_0_net.ack_seq (* (- 1) v_0_snd_wl1))
                  (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1))))
      (a!993 (to_int (+ (* (- (/ 1.0 2.0)) (to_real v_0_rtx_buf))
                        (* (/ 1.0 2.0) (to_real v_0_lt_epoch_bytes)))))
      (a!1008 (not (<= 8589934592 (+ v_0_rtt_end (* (- 1) v_0_snd_una)))))
      (a!1010 (ite (>= (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296)
                   (+ (- 4294967296) v_0_rtt_end (* (- 1) v_0_snd_una))
                   (+ v_0_rtt_end (* (- 1) v_0_snd_una))))
      (a!1175 (+ (ite (<= v_0_cc_cwnd v_0_snd_wnd) v_0_cc_cwnd v_0_snd_wnd)
                 (* (- 1) v_0_rtx_buf)))
      (a!1252 (= v_1_idle_elapsed_ms
                 (ite v_0_idle_data_valid
                      (+ now_1 (* (- 1) v_0_idle_last_data_ms))
                      0)))
      (a!1409 (not (<= 8589934592
                       (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)))))
      (a!1411 (ite (>= (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                       4294967296)
                   (+ (- 4294967296)
                      v_0_snd_una
                      v_0_rtx_buf
                      (ite v_0_fin_sent 1 0))
                   (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))))
      (a!1414 (or (not v_0_rx_fin_pending)
                  (and (not v_0_rx_fin_done)
                       (<= 1 v_0_rx_fin_offset)
                       (<= v_0_rx_fin_offset (+ (- 1) v_0_local_window)))))
      (a!1415 (and (>= (+ v_0_rcv_nxt v_0_rx_fin_offset) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_rcv_nxt v_0_rx_fin_offset)))))
      (a!1416 (ite (<= 0 (+ v_0_rcv_nxt v_0_rx_fin_offset))
                   (ite (>= (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)
                        (+ (- 4294967296) v_0_rcv_nxt v_0_rx_fin_offset)
                        (+ v_0_rcv_nxt v_0_rx_fin_offset))
                   (+ 4294967296 v_0_rcv_nxt v_0_rx_fin_offset)))
      (a!1418 (ite (and (>= v_0_rx_fin_seq (- 4294967297))
                        (not (<= 8589934591 v_0_rx_fin_seq)))
                   (ite (<= (- 1) v_0_rx_fin_seq)
                        (ite (>= v_0_rx_fin_seq 4294967295)
                             (+ (- 4294967295) v_0_rx_fin_seq)
                             (+ 1 v_0_rx_fin_seq))
                        (+ 4294967297 v_0_rx_fin_seq))
                   (mod (+ 1 v_0_rx_fin_seq) 4294967296)))
      (a!1419 (+ (* (- 1.0) v_0_srtt_ms)
                 (* (- 1.0)
                    (ite (<= v_0_rttvar_ms (/ 1.0 4.0))
                         1.0
                         (* 4.0 v_0_rttvar_ms)))))
      (a!1422 (not (<= 8589934592 (+ v_0_snd_nxt (* (- 1) v_0_snd_una)))))
      (a!1424 (ite (>= (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296)
                   (+ (- 4294967296) v_0_snd_nxt (* (- 1) v_0_snd_una))
                   (+ v_0_snd_nxt (* (- 1) v_0_snd_una))))
      (a!1427 (and (not v_0_rtt_sample_was_ambiguous)
                   v_0_rtt_measured
                   (= v_0_rtt_last_ms
                      (+ v_0_rtt_sample_at_ms (* (- 1) v_0_rtt_start_ms)))))
      (a!1428 (>= (+ v_0_rtt_previous_srtt
                     (* (- 1.0) (to_real v_0_rtt_last_ms)))
                  0.0))
      (a!1431 (ite v_0_rtt_previous_measured
                   (+ (* (/ 7.0 8.0) v_0_rtt_previous_srtt)
                      (* (/ 1.0 8.0) (to_real v_0_rtt_last_ms)))
                   (to_real v_0_rtt_last_ms)))
      (a!1432 (and (>= (+ v_0_lt_before_nxt v_0_lt_take) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_lt_before_nxt v_0_lt_take)))))
      (a!1433 (ite (<= 0 (+ v_0_lt_before_nxt v_0_lt_take))
                   (ite (>= (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)
                        (+ (- 4294967296) v_0_lt_before_nxt v_0_lt_take)
                        (+ v_0_lt_before_nxt v_0_lt_take))
                   (+ 4294967296 v_0_lt_before_nxt v_0_lt_take)))
      (a!1436 (or (not v_0_fr_entered)
                  (= v_0_lt_loss_flight
                     (+ v_0_fr_before_flight (* (- 1) v_0_lt_before_bytes)))))
      (a!1437 (and (>= (+ v_0_choice_before_nxt v_0_choice_count)
                       (- 4294967296))
                   (not (<= 8589934592
                            (+ v_0_choice_before_nxt v_0_choice_count)))))
      (a!1438 (ite (<= 0 (+ v_0_choice_before_nxt v_0_choice_count))
                   (ite (>= (+ v_0_choice_before_nxt v_0_choice_count)
                            4294967296)
                        (+ (- 4294967296)
                           v_0_choice_before_nxt
                           v_0_choice_count)
                        (+ v_0_choice_before_nxt v_0_choice_count))
                   (+ 4294967296 v_0_choice_before_nxt v_0_choice_count)))
      (a!1441 (and (>= (+ v_0_cb_end_15 v_0_cb_length_00) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_15 v_0_cb_length_00)))))
      (a!1442 (ite (<= 0 (+ v_0_cb_end_15 v_0_cb_length_00))
                   (ite (>= (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_15 v_0_cb_length_00)
                        (+ v_0_cb_end_15 v_0_cb_length_00))
                   (+ 4294967296 v_0_cb_end_15 v_0_cb_length_00)))
      (a!1444 (and (>= (+ v_0_cb_end_00 v_0_cb_length_01) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_00 v_0_cb_length_01)))))
      (a!1445 (ite (<= 0 (+ v_0_cb_end_00 v_0_cb_length_01))
                   (ite (>= (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_00 v_0_cb_length_01)
                        (+ v_0_cb_end_00 v_0_cb_length_01))
                   (+ 4294967296 v_0_cb_end_00 v_0_cb_length_01)))
      (a!1447 (and (>= (+ v_0_cb_end_01 v_0_cb_length_02) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_01 v_0_cb_length_02)))))
      (a!1448 (ite (<= 0 (+ v_0_cb_end_01 v_0_cb_length_02))
                   (ite (>= (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_01 v_0_cb_length_02)
                        (+ v_0_cb_end_01 v_0_cb_length_02))
                   (+ 4294967296 v_0_cb_end_01 v_0_cb_length_02)))
      (a!1450 (and (>= (+ v_0_cb_end_02 v_0_cb_length_03) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_02 v_0_cb_length_03)))))
      (a!1451 (ite (<= 0 (+ v_0_cb_end_02 v_0_cb_length_03))
                   (ite (>= (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_02 v_0_cb_length_03)
                        (+ v_0_cb_end_02 v_0_cb_length_03))
                   (+ 4294967296 v_0_cb_end_02 v_0_cb_length_03)))
      (a!1453 (and (>= (+ v_0_cb_end_03 v_0_cb_length_04) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_03 v_0_cb_length_04)))))
      (a!1454 (ite (<= 0 (+ v_0_cb_end_03 v_0_cb_length_04))
                   (ite (>= (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_03 v_0_cb_length_04)
                        (+ v_0_cb_end_03 v_0_cb_length_04))
                   (+ 4294967296 v_0_cb_end_03 v_0_cb_length_04)))
      (a!1456 (and (>= (+ v_0_cb_end_04 v_0_cb_length_05) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_04 v_0_cb_length_05)))))
      (a!1457 (ite (<= 0 (+ v_0_cb_end_04 v_0_cb_length_05))
                   (ite (>= (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_04 v_0_cb_length_05)
                        (+ v_0_cb_end_04 v_0_cb_length_05))
                   (+ 4294967296 v_0_cb_end_04 v_0_cb_length_05)))
      (a!1459 (and (>= (+ v_0_cb_end_05 v_0_cb_length_06) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_05 v_0_cb_length_06)))))
      (a!1460 (ite (<= 0 (+ v_0_cb_end_05 v_0_cb_length_06))
                   (ite (>= (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_05 v_0_cb_length_06)
                        (+ v_0_cb_end_05 v_0_cb_length_06))
                   (+ 4294967296 v_0_cb_end_05 v_0_cb_length_06)))
      (a!1462 (and (>= (+ v_0_cb_end_06 v_0_cb_length_07) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_06 v_0_cb_length_07)))))
      (a!1463 (ite (<= 0 (+ v_0_cb_end_06 v_0_cb_length_07))
                   (ite (>= (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_06 v_0_cb_length_07)
                        (+ v_0_cb_end_06 v_0_cb_length_07))
                   (+ 4294967296 v_0_cb_end_06 v_0_cb_length_07)))
      (a!1465 (and (>= (+ v_0_cb_end_07 v_0_cb_length_08) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_07 v_0_cb_length_08)))))
      (a!1466 (ite (<= 0 (+ v_0_cb_end_07 v_0_cb_length_08))
                   (ite (>= (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_07 v_0_cb_length_08)
                        (+ v_0_cb_end_07 v_0_cb_length_08))
                   (+ 4294967296 v_0_cb_end_07 v_0_cb_length_08)))
      (a!1468 (not (<= 8589934592
                       (+ v_0_snd_una
                          v_0_cb_length_09
                          (* (- 1) v_0_cb_partial_prefix)))))
      (a!1470 (ite (>= (+ v_0_snd_una
                          v_0_cb_length_09
                          (* (- 1) v_0_cb_partial_prefix))
                       4294967296)
                   (+ (- 4294967296)
                      v_0_snd_una
                      v_0_cb_length_09
                      (* (- 1) v_0_cb_partial_prefix))
                   (+ v_0_snd_una
                      v_0_cb_length_09
                      (* (- 1) v_0_cb_partial_prefix))))
      (a!1474 (and (>= (+ v_0_cb_end_09 v_0_cb_length_10) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_09 v_0_cb_length_10)))))
      (a!1475 (ite (<= 0 (+ v_0_cb_end_09 v_0_cb_length_10))
                   (ite (>= (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_09 v_0_cb_length_10)
                        (+ v_0_cb_end_09 v_0_cb_length_10))
                   (+ 4294967296 v_0_cb_end_09 v_0_cb_length_10)))
      (a!1477 (and (>= (+ v_0_cb_end_10 v_0_cb_length_11) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_10 v_0_cb_length_11)))))
      (a!1478 (ite (<= 0 (+ v_0_cb_end_10 v_0_cb_length_11))
                   (ite (>= (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_10 v_0_cb_length_11)
                        (+ v_0_cb_end_10 v_0_cb_length_11))
                   (+ 4294967296 v_0_cb_end_10 v_0_cb_length_11)))
      (a!1480 (and (>= (+ v_0_cb_end_11 v_0_cb_length_12) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_11 v_0_cb_length_12)))))
      (a!1481 (ite (<= 0 (+ v_0_cb_end_11 v_0_cb_length_12))
                   (ite (>= (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_11 v_0_cb_length_12)
                        (+ v_0_cb_end_11 v_0_cb_length_12))
                   (+ 4294967296 v_0_cb_end_11 v_0_cb_length_12)))
      (a!1483 (and (>= (+ v_0_cb_end_12 v_0_cb_length_13) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_12 v_0_cb_length_13)))))
      (a!1484 (ite (<= 0 (+ v_0_cb_end_12 v_0_cb_length_13))
                   (ite (>= (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_12 v_0_cb_length_13)
                        (+ v_0_cb_end_12 v_0_cb_length_13))
                   (+ 4294967296 v_0_cb_end_12 v_0_cb_length_13)))
      (a!1486 (and (>= (+ v_0_cb_end_13 v_0_cb_length_14) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_13 v_0_cb_length_14)))))
      (a!1487 (ite (<= 0 (+ v_0_cb_end_13 v_0_cb_length_14))
                   (ite (>= (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_13 v_0_cb_length_14)
                        (+ v_0_cb_end_13 v_0_cb_length_14))
                   (+ 4294967296 v_0_cb_end_13 v_0_cb_length_14)))
      (a!1489 (and (>= (+ v_0_cb_end_14 v_0_cb_length_15) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_cb_end_14 v_0_cb_length_15)))))
      (a!1490 (ite (<= 0 (+ v_0_cb_end_14 v_0_cb_length_15))
                   (ite (>= (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)
                        (+ (- 4294967296) v_0_cb_end_14 v_0_cb_length_15)
                        (+ v_0_cb_end_14 v_0_cb_length_15))
                   (+ 4294967296 v_0_cb_end_14 v_0_cb_length_15))))
(let ((a!7 (ite a!5 a!6 (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq))))
      (a!16 (ite a!14 a!15 (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt))))
      (a!25 (ite a!23 a!24 (+ input_0_net.ack_ack (* (- 1) v_0_snd_una))))
      (a!34 (ite a!32 a!33 (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt))))
      (a!47 (ite a!45 a!46 (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2))))
      (a!56 (ite a!54 a!55 (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1))))
      (a!75 (<= 8 (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes) (to_int a!74))))
      (a!97 (ite a!95 a!96 (+ v_0_rtt_end (* (- 1) v_0_snd_una))))
      (a!676 (ite (< (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)) 0)
                  (+ (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                     4294967296)
                  a!675))
      (a!680 (ite (and (>= (+ v_0_rcv_nxt v_0_rx_fin_offset) (- 4294967296))
                       (< (+ v_0_rcv_nxt v_0_rx_fin_offset) 8589934592))
                  a!679
                  (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296)))
      (a!682 (ite (and (>= (+ 1 v_0_rx_fin_seq) (- 4294967296))
                       (< (+ 1 v_0_rx_fin_seq) 8589934592))
                  a!681
                  (mod (+ 1 v_0_rx_fin_seq) 4294967296)))
      (a!700 (to_int (+ (* (- 1.0) v_0_srtt_ms) a!699)))
      (a!709 (ite a!707 a!708 (+ v_0_snd_nxt (* (- 1) v_0_snd_una))))
      (a!714 (ite a!713
                  (+ v_0_rtt_previous_srtt
                     (* (- 1.0) (to_real v_0_rtt_last_ms)))
                  (+ (* (- 1.0) v_0_rtt_previous_srtt)
                     (to_real v_0_rtt_last_ms))))
      (a!731 (ite (and (>= (+ v_0_lt_before_nxt v_0_lt_take) (- 4294967296))
                       (< (+ v_0_lt_before_nxt v_0_lt_take) 8589934592))
                  a!730
                  (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296)))
      (a!735 (ite (and (>= (+ v_0_choice_before_nxt v_0_choice_count)
                           (- 4294967296))
                       (< (+ v_0_choice_before_nxt v_0_choice_count) 8589934592))
                  a!734
                  (mod (+ v_0_choice_before_nxt v_0_choice_count) 4294967296)))
      (a!740 (not (and (not (>= a!376 v_0_cb_count)) (= 0 v_0_cb_head))))
      (a!747 (ite a!745
                  a!746
                  (+ v_0_snd_una
                     v_0_cb_length_00
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!750 (not (and (not (>= a!376 v_0_cb_count)) (<= 1 a!376))))
      (a!752 (ite (and (>= (+ v_0_cb_end_15 v_0_cb_length_00) (- 4294967296))
                       (< (+ v_0_cb_end_15 v_0_cb_length_00) 8589934592))
                  a!751
                  (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296)))
      (a!753 (not (and (not (>= a!387 v_0_cb_count)) (= 1 v_0_cb_head))))
      (a!760 (ite a!758
                  a!759
                  (+ v_0_snd_una
                     v_0_cb_length_01
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!763 (not (and (not (>= a!387 v_0_cb_count)) (<= 1 a!387))))
      (a!765 (ite (and (>= (+ v_0_cb_end_00 v_0_cb_length_01) (- 4294967296))
                       (< (+ v_0_cb_end_00 v_0_cb_length_01) 8589934592))
                  a!764
                  (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296)))
      (a!766 (not (and (not (>= a!398 v_0_cb_count)) (= 2 v_0_cb_head))))
      (a!773 (ite a!771
                  a!772
                  (+ v_0_snd_una
                     v_0_cb_length_02
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!776 (not (and (not (>= a!398 v_0_cb_count)) (<= 1 a!398))))
      (a!778 (ite (and (>= (+ v_0_cb_end_01 v_0_cb_length_02) (- 4294967296))
                       (< (+ v_0_cb_end_01 v_0_cb_length_02) 8589934592))
                  a!777
                  (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296)))
      (a!779 (not (and (not (>= a!409 v_0_cb_count)) (= 3 v_0_cb_head))))
      (a!786 (ite a!784
                  a!785
                  (+ v_0_snd_una
                     v_0_cb_length_03
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!789 (not (and (not (>= a!409 v_0_cb_count)) (<= 1 a!409))))
      (a!791 (ite (and (>= (+ v_0_cb_end_02 v_0_cb_length_03) (- 4294967296))
                       (< (+ v_0_cb_end_02 v_0_cb_length_03) 8589934592))
                  a!790
                  (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296)))
      (a!792 (not (and (not (>= a!420 v_0_cb_count)) (= 4 v_0_cb_head))))
      (a!799 (ite a!797
                  a!798
                  (+ v_0_snd_una
                     v_0_cb_length_04
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!802 (not (and (not (>= a!420 v_0_cb_count)) (<= 1 a!420))))
      (a!804 (ite (and (>= (+ v_0_cb_end_03 v_0_cb_length_04) (- 4294967296))
                       (< (+ v_0_cb_end_03 v_0_cb_length_04) 8589934592))
                  a!803
                  (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296)))
      (a!805 (not (and (not (>= a!431 v_0_cb_count)) (= 5 v_0_cb_head))))
      (a!812 (ite a!810
                  a!811
                  (+ v_0_snd_una
                     v_0_cb_length_05
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!815 (not (and (not (>= a!431 v_0_cb_count)) (<= 1 a!431))))
      (a!817 (ite (and (>= (+ v_0_cb_end_04 v_0_cb_length_05) (- 4294967296))
                       (< (+ v_0_cb_end_04 v_0_cb_length_05) 8589934592))
                  a!816
                  (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296)))
      (a!818 (not (and (not (>= a!442 v_0_cb_count)) (= 6 v_0_cb_head))))
      (a!825 (ite a!823
                  a!824
                  (+ v_0_snd_una
                     v_0_cb_length_06
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!828 (not (and (not (>= a!442 v_0_cb_count)) (<= 1 a!442))))
      (a!830 (ite (and (>= (+ v_0_cb_end_05 v_0_cb_length_06) (- 4294967296))
                       (< (+ v_0_cb_end_05 v_0_cb_length_06) 8589934592))
                  a!829
                  (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296)))
      (a!831 (not (and (not (>= a!453 v_0_cb_count)) (= 7 v_0_cb_head))))
      (a!838 (ite a!836
                  a!837
                  (+ v_0_snd_una
                     v_0_cb_length_07
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!841 (not (and (not (>= a!453 v_0_cb_count)) (<= 1 a!453))))
      (a!843 (ite (and (>= (+ v_0_cb_end_06 v_0_cb_length_07) (- 4294967296))
                       (< (+ v_0_cb_end_06 v_0_cb_length_07) 8589934592))
                  a!842
                  (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296)))
      (a!844 (not (and (not (>= a!464 v_0_cb_count)) (= 8 v_0_cb_head))))
      (a!851 (ite a!849
                  a!850
                  (+ v_0_snd_una
                     v_0_cb_length_08
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!854 (not (and (not (>= a!464 v_0_cb_count)) (<= 1 a!464))))
      (a!856 (ite (and (>= (+ v_0_cb_end_07 v_0_cb_length_08) (- 4294967296))
                       (< (+ v_0_cb_end_07 v_0_cb_length_08) 8589934592))
                  a!855
                  (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296)))
      (a!857 (not (and (not (>= a!475 v_0_cb_count)) (= 9 v_0_cb_head))))
      (a!864 (ite a!862
                  a!863
                  (+ v_0_snd_una
                     v_0_cb_length_09
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!867 (not (and (not (>= a!475 v_0_cb_count)) (<= 1 a!475))))
      (a!869 (ite (and (>= (+ v_0_cb_end_08 v_0_cb_length_09) (- 4294967296))
                       (< (+ v_0_cb_end_08 v_0_cb_length_09) 8589934592))
                  a!868
                  (mod (+ v_0_cb_end_08 v_0_cb_length_09) 4294967296)))
      (a!870 (not (and (not (>= a!486 v_0_cb_count)) (= 10 v_0_cb_head))))
      (a!877 (ite a!875
                  a!876
                  (+ v_0_snd_una
                     v_0_cb_length_10
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!880 (not (and (not (>= a!486 v_0_cb_count)) (<= 1 a!486))))
      (a!882 (ite (and (>= (+ v_0_cb_end_09 v_0_cb_length_10) (- 4294967296))
                       (< (+ v_0_cb_end_09 v_0_cb_length_10) 8589934592))
                  a!881
                  (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296)))
      (a!883 (not (and (not (>= a!497 v_0_cb_count)) (= 11 v_0_cb_head))))
      (a!890 (ite a!888
                  a!889
                  (+ v_0_snd_una
                     v_0_cb_length_11
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!893 (not (and (not (>= a!497 v_0_cb_count)) (<= 1 a!497))))
      (a!895 (ite (and (>= (+ v_0_cb_end_10 v_0_cb_length_11) (- 4294967296))
                       (< (+ v_0_cb_end_10 v_0_cb_length_11) 8589934592))
                  a!894
                  (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296)))
      (a!896 (not (and (not (>= a!508 v_0_cb_count)) (= 12 v_0_cb_head))))
      (a!903 (ite a!901
                  a!902
                  (+ v_0_snd_una
                     v_0_cb_length_12
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!906 (not (and (not (>= a!508 v_0_cb_count)) (<= 1 a!508))))
      (a!908 (ite (and (>= (+ v_0_cb_end_11 v_0_cb_length_12) (- 4294967296))
                       (< (+ v_0_cb_end_11 v_0_cb_length_12) 8589934592))
                  a!907
                  (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296)))
      (a!909 (not (and (not (>= a!519 v_0_cb_count)) (= 13 v_0_cb_head))))
      (a!916 (ite a!914
                  a!915
                  (+ v_0_snd_una
                     v_0_cb_length_13
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!919 (not (and (not (>= a!519 v_0_cb_count)) (<= 1 a!519))))
      (a!921 (ite (and (>= (+ v_0_cb_end_12 v_0_cb_length_13) (- 4294967296))
                       (< (+ v_0_cb_end_12 v_0_cb_length_13) 8589934592))
                  a!920
                  (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296)))
      (a!922 (not (and (not (>= a!530 v_0_cb_count)) (= 14 v_0_cb_head))))
      (a!929 (ite a!927
                  a!928
                  (+ v_0_snd_una
                     v_0_cb_length_14
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!932 (not (and (not (>= a!530 v_0_cb_count)) (<= 1 a!530))))
      (a!934 (ite (and (>= (+ v_0_cb_end_13 v_0_cb_length_14) (- 4294967296))
                       (< (+ v_0_cb_end_13 v_0_cb_length_14) 8589934592))
                  a!933
                  (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296)))
      (a!935 (not (and (not (>= a!541 v_0_cb_count)) (= 15 v_0_cb_head))))
      (a!942 (ite a!940
                  a!941
                  (+ v_0_snd_una
                     v_0_cb_length_15
                     (* (- 1) v_0_cb_partial_prefix))))
      (a!945 (not (and (not (>= a!541 v_0_cb_count)) (<= 1 a!541))))
      (a!947 (ite (and (>= (+ v_0_cb_end_14 v_0_cb_length_15) (- 4294967296))
                       (< (+ v_0_cb_end_14 v_0_cb_length_15) 8589934592))
                  a!946
                  (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))
      (a!950 (and (>= (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq))
                      (- 4294967296))
                  a!949))
      (a!952 (ite (<= 0 (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)))
                  a!951
                  (+ 4294967296 v_0_rcv_nxt (* (- 1) input_0_net.ack_seq))))
      (a!955 (and (>= (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt))
                      (- 4294967296))
                  a!954))
      (a!957 (ite (<= 0 (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)))
                  a!956
                  (+ 4294967296 input_0_net.ack_seq (* (- 1) v_0_rcv_nxt))))
      (a!961 (and (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_una))
                      (- 4294967296))
                  a!960))
      (a!963 (ite (<= 0 (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)))
                  a!962
                  (+ 4294967296 input_0_net.ack_ack (* (- 1) v_0_snd_una))))
      (a!966 (and (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt))
                      (- 4294967296))
                  a!965))
      (a!968 (ite (<= 0 (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)))
                  a!967
                  (+ 4294967296 input_0_net.ack_ack (* (- 1) v_0_snd_nxt))))
      (a!973 (and (>= (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2))
                      (- 4294967296))
                  a!972))
      (a!975 (ite (<= 0 (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)))
                  a!974
                  (+ 4294967296 input_0_net.ack_ack (* (- 1) v_0_snd_wl2))))
      (a!978 (and (>= (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1))
                      (- 4294967296))
                  a!977))
      (a!980 (ite (<= 0 (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)))
                  a!979
                  (+ 4294967296 input_0_net.ack_seq (* (- 1) v_0_snd_wl1))))
      (a!994 (ite (<= 8 (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes) a!993))
                  (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes) a!993)
                  8))
      (a!1009 (and (>= (+ v_0_rtt_end (* (- 1) v_0_snd_una)) (- 4294967296))
                   a!1008))
      (a!1011 (ite (<= 0 (+ v_0_rtt_end (* (- 1) v_0_snd_una)))
                   a!1010
                   (+ 4294967296 v_0_rtt_end (* (- 1) v_0_snd_una))))
      (a!1410 (and (>= (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                       (- 4294967296))
                   a!1409))
      (a!1412 (ite (<= 0 (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0)))
                   a!1411
                   (+ 4294967296 v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))))
      (a!1417 (= v_0_rx_fin_seq
                 (ite a!1415
                      a!1416
                      (mod (+ v_0_rcv_nxt v_0_rx_fin_offset) 4294967296))))
      (a!1420 (<= 60000
                  (ite (<= (- 999.0) a!1419) 1000 (* (- 1) (to_int a!1419)))))
      (a!1423 (and (>= (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) (- 4294967296))
                   a!1422))
      (a!1425 (ite (<= 0 (+ v_0_snd_nxt (* (- 1) v_0_snd_una)))
                   a!1424
                   (+ 4294967296 v_0_snd_nxt (* (- 1) v_0_snd_una))))
      (a!1429 (ite a!1428
                   (+ v_0_rtt_previous_srtt
                      (* (- 1.0) (to_real v_0_rtt_last_ms)))
                   (+ (* (- 1.0) v_0_rtt_previous_srtt)
                      (to_real v_0_rtt_last_ms))))
      (a!1434 (= v_0_snd_nxt
                 (ite a!1432
                      a!1433
                      (mod (+ v_0_lt_before_nxt v_0_lt_take) 4294967296))))
      (a!1439 (= v_0_snd_nxt
                 (ite a!1437
                      a!1438
                      (mod (+ v_0_choice_before_nxt v_0_choice_count)
                           4294967296))))
      (a!1443 (= v_0_cb_end_00
                 (ite a!1441
                      a!1442
                      (mod (+ v_0_cb_end_15 v_0_cb_length_00) 4294967296))))
      (a!1446 (= v_0_cb_end_01
                 (ite a!1444
                      a!1445
                      (mod (+ v_0_cb_end_00 v_0_cb_length_01) 4294967296))))
      (a!1449 (= v_0_cb_end_02
                 (ite a!1447
                      a!1448
                      (mod (+ v_0_cb_end_01 v_0_cb_length_02) 4294967296))))
      (a!1452 (= v_0_cb_end_03
                 (ite a!1450
                      a!1451
                      (mod (+ v_0_cb_end_02 v_0_cb_length_03) 4294967296))))
      (a!1455 (= v_0_cb_end_04
                 (ite a!1453
                      a!1454
                      (mod (+ v_0_cb_end_03 v_0_cb_length_04) 4294967296))))
      (a!1458 (= v_0_cb_end_05
                 (ite a!1456
                      a!1457
                      (mod (+ v_0_cb_end_04 v_0_cb_length_05) 4294967296))))
      (a!1461 (= v_0_cb_end_06
                 (ite a!1459
                      a!1460
                      (mod (+ v_0_cb_end_05 v_0_cb_length_06) 4294967296))))
      (a!1464 (= v_0_cb_end_07
                 (ite a!1462
                      a!1463
                      (mod (+ v_0_cb_end_06 v_0_cb_length_07) 4294967296))))
      (a!1467 (= v_0_cb_end_08
                 (ite a!1465
                      a!1466
                      (mod (+ v_0_cb_end_07 v_0_cb_length_08) 4294967296))))
      (a!1469 (and (>= (+ v_0_snd_una
                          v_0_cb_length_09
                          (* (- 1) v_0_cb_partial_prefix))
                       (- 4294967296))
                   a!1468))
      (a!1471 (ite (<= 0
                       (+ v_0_snd_una
                          v_0_cb_length_09
                          (* (- 1) v_0_cb_partial_prefix)))
                   a!1470
                   (+ 4294967296
                      v_0_snd_una
                      v_0_cb_length_09
                      (* (- 1) v_0_cb_partial_prefix))))
      (a!1476 (= v_0_cb_end_10
                 (ite a!1474
                      a!1475
                      (mod (+ v_0_cb_end_09 v_0_cb_length_10) 4294967296))))
      (a!1479 (= v_0_cb_end_11
                 (ite a!1477
                      a!1478
                      (mod (+ v_0_cb_end_10 v_0_cb_length_11) 4294967296))))
      (a!1482 (= v_0_cb_end_12
                 (ite a!1480
                      a!1481
                      (mod (+ v_0_cb_end_11 v_0_cb_length_12) 4294967296))))
      (a!1485 (= v_0_cb_end_13
                 (ite a!1483
                      a!1484
                      (mod (+ v_0_cb_end_12 v_0_cb_length_13) 4294967296))))
      (a!1488 (= v_0_cb_end_14
                 (ite a!1486
                      a!1487
                      (mod (+ v_0_cb_end_13 v_0_cb_length_14) 4294967296))))
      (a!1491 (= v_0_cb_end_15
                 (ite a!1489
                      a!1490
                      (mod (+ v_0_cb_end_14 v_0_cb_length_15) 4294967296)))))
(let ((a!9 (not (= (ite (and a!1 a!2) (ite a!3 a!4 a!7) a!8) 2147483648)))
      (a!18 (and (<= 1 v_0_local_window)
                 (<= (ite (and a!10 a!11) (ite a!12 a!13 a!16) a!17)
                     (+ (- 1) v_0_local_window))))
      (a!27 (not (= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26) 2147483648)))
      (a!36 (not (= (ite (and a!28 a!29) (ite a!30 a!31 a!34) a!35) 2147483648)))
      (a!37 (and (>= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)
                     (+ 1 v_0_rtx_buf))
                 (>= 2147483647 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))))
      (a!38 (<= 1 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!39 (<= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26) v_0_rtx_buf))
      (a!49 (not (<= 2147483648 (ite (and a!41 a!42) (ite a!43 a!44 a!47) a!48))))
      (a!58 (not (<= (ite (and a!50 a!51) (ite a!52 a!53 a!56) a!57) 0)))
      (a!59 (not (<= 2147483648 (ite (and a!50 a!51) (ite a!52 a!53 a!56) a!57))))
      (a!61 (* (- 1) (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!76 (ite a!75
                 (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes) (to_int a!74))
                 8))
      (a!99 (>= (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)
                (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98)))
      (a!153 (not (= 0 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))))
      (a!155 (= 1 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!156 (= 2 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!157 (= 3 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!158 (= 4 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!159 (= 5 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!160 (= 6 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!161 (= 7 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!162 (= 8 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!163 (= 9 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!164 (= 10 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!165 (= 11 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!166 (= 12 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!167 (= 13 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!168 (= 14 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26)))
      (a!169 (ite (= 15 (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))
                  v_0_tx_time_15
                  0))
      (a!677 (ite a!674
                  a!676
                  (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                       4294967296)))
      (a!701 (ite (<= a!700 (- 1000)) (* (- 1) a!700) 1000))
      (a!711 (and (<= v_0_rtt_start_ms now_0)
                  (<= 1 v_0_rtt_remaining)
                  (>= 4 v_0_rtt_remaining)
                  (>= (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98)
                      v_0_rtt_remaining)
                  (<= (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98)
                      (ite (and a!703 a!704) (ite a!705 a!706 a!709) a!710))))
      (a!715 (ite v_0_rtt_previous_measured
                  (+ (* (/ 3.0 4.0) v_0_rtt_previous_var) (* (/ 1.0 4.0) a!714))
                  (* (/ 1.0 2.0) (to_real v_0_rtt_last_ms))))
      (a!732 (or (not v_0_lt_emitted)
                 (and v_0_fr_duplicate
                      (<= 1 v_0_fr_dupacks)
                      (>= 2 v_0_fr_dupacks)
                      (not v_0_fr_active)
                      (not v_0_fin_sent)
                      (<= 1 v_0_lt_take)
                      (>= 4 v_0_lt_take)
                      (= v_0_cc_cwnd v_0_lt_before_cwnd)
                      (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take))
                      (<= v_0_rtx_buf v_0_snd_wnd)
                      (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd))
                      (= v_0_snd_nxt a!731))))
      (a!736 (or (not v_0_choice_used)
                 (and (<= 1 v_0_choice_count)
                      (<= v_0_choice_count v_0_choice_limit)
                      (= v_0_take v_0_choice_count)
                      (= v_0_cc_new_sent v_0_choice_count)
                      (<= v_0_choice_count v_0_cc_send_budget)
                      (= v_0_snd_nxt a!735)
                      (= v_0_rtx_buf
                         (+ v_0_choice_before_flight v_0_choice_count)))))
      (a!749 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_00))
                  (= v_0_cb_end_00
                     (ite (and a!741 a!742) (ite a!743 a!744 a!747) a!748))))
      (a!762 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_01))
                  (= v_0_cb_end_01
                     (ite (and a!754 a!755) (ite a!756 a!757 a!760) a!761))))
      (a!775 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_02))
                  (= v_0_cb_end_02
                     (ite (and a!767 a!768) (ite a!769 a!770 a!773) a!774))))
      (a!788 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_03))
                  (= v_0_cb_end_03
                     (ite (and a!780 a!781) (ite a!782 a!783 a!786) a!787))))
      (a!801 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_04))
                  (= v_0_cb_end_04
                     (ite (and a!793 a!794) (ite a!795 a!796 a!799) a!800))))
      (a!814 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_05))
                  (= v_0_cb_end_05
                     (ite (and a!806 a!807) (ite a!808 a!809 a!812) a!813))))
      (a!827 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_06))
                  (= v_0_cb_end_06
                     (ite (and a!819 a!820) (ite a!821 a!822 a!825) a!826))))
      (a!840 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_07))
                  (= v_0_cb_end_07
                     (ite (and a!832 a!833) (ite a!834 a!835 a!838) a!839))))
      (a!853 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_08))
                  (= v_0_cb_end_08
                     (ite (and a!845 a!846) (ite a!847 a!848 a!851) a!852))))
      (a!866 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09))
                  (= v_0_cb_end_09
                     (ite (and a!858 a!859) (ite a!860 a!861 a!864) a!865))))
      (a!879 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_10))
                  (= v_0_cb_end_10
                     (ite (and a!871 a!872) (ite a!873 a!874 a!877) a!878))))
      (a!892 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_11))
                  (= v_0_cb_end_11
                     (ite (and a!884 a!885) (ite a!886 a!887 a!890) a!891))))
      (a!905 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_12))
                  (= v_0_cb_end_12
                     (ite (and a!897 a!898) (ite a!899 a!900 a!903) a!904))))
      (a!918 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_13))
                  (= v_0_cb_end_13
                     (ite (and a!910 a!911) (ite a!912 a!913 a!916) a!917))))
      (a!931 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_14))
                  (= v_0_cb_end_14
                     (ite (and a!923 a!924) (ite a!925 a!926 a!929) a!930))))
      (a!944 (and (not (>= v_0_cb_partial_prefix v_0_cb_length_15))
                  (= v_0_cb_end_15
                     (ite (and a!936 a!937) (ite a!938 a!939 a!942) a!943))))
      (a!953 (ite a!950
                  a!952
                  (mod (+ v_0_rcv_nxt (* (- 1) input_0_net.ack_seq)) 4294967296)))
      (a!958 (ite a!955
                  a!957
                  (mod (+ input_0_net.ack_seq (* (- 1) v_0_rcv_nxt)) 4294967296)))
      (a!964 (ite a!961
                  a!963
                  (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_una)) 4294967296)))
      (a!969 (ite a!966
                  a!968
                  (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_nxt)) 4294967296)))
      (a!976 (ite a!973
                  a!975
                  (mod (+ input_0_net.ack_ack (* (- 1) v_0_snd_wl2)) 4294967296)))
      (a!981 (ite a!978
                  a!980
                  (mod (+ input_0_net.ack_seq (* (- 1) v_0_snd_wl1)) 4294967296)))
      (a!1012 (ite a!1009
                   a!1011
                   (mod (+ v_0_rtt_end (* (- 1) v_0_snd_una)) 4294967296)))
      (a!1413 (ite a!1410
                   a!1412
                   (mod (+ v_0_snd_una v_0_rtx_buf (ite v_0_fin_sent 1 0))
                        4294967296)))
      (a!1421 (ite a!1420
                   60000
                   (ite (<= (- 999.0) a!1419) 1000 (* (- 1) (to_int a!1419)))))
      (a!1426 (ite a!1423
                   a!1425
                   (mod (+ v_0_snd_nxt (* (- 1) v_0_snd_una)) 4294967296)))
      (a!1430 (= v_0_rttvar_ms
                 (ite v_0_rtt_previous_measured
                      (+ (* (/ 3.0 4.0) v_0_rtt_previous_var)
                         (* (/ 1.0 4.0) a!1429))
                      (* (/ 1.0 2.0) (to_real v_0_rtt_last_ms)))))
      (a!1435 (or (not v_0_lt_emitted)
                  (and v_0_fr_duplicate
                       (<= 1 v_0_fr_dupacks)
                       (>= 2 v_0_fr_dupacks)
                       (not v_0_fr_active)
                       (not v_0_fin_sent)
                       (<= 1 v_0_lt_take)
                       (>= 4 v_0_lt_take)
                       (= v_0_cc_cwnd v_0_lt_before_cwnd)
                       (= v_0_rtx_buf (+ v_0_lt_before_flight v_0_lt_take))
                       (<= v_0_rtx_buf v_0_snd_wnd)
                       (<= v_0_rtx_buf (+ 8 v_0_cc_cwnd))
                       a!1434)))
      (a!1440 (or (not v_0_choice_used)
                  (and (<= 1 v_0_choice_count)
                       (<= v_0_choice_count v_0_choice_limit)
                       (= v_0_take v_0_choice_count)
                       (= v_0_cc_new_sent v_0_choice_count)
                       (<= v_0_choice_count v_0_cc_send_budget)
                       a!1439
                       (= v_0_rtx_buf
                          (+ v_0_choice_before_flight v_0_choice_count)))))
      (a!1472 (ite a!1469
                   a!1471
                   (mod (+ v_0_snd_una
                           v_0_cb_length_09
                           (* (- 1) v_0_cb_partial_prefix))
                        4294967296))))
(let ((a!40 (and (or (and (= 0 v_0_local_window)
                          (= input_0_net.ack_seq v_0_rcv_nxt))
                     a!18)
                 a!38
                 a!39))
      (a!60 (and (or (and (= 0 v_0_local_window)
                          (= input_0_net.ack_seq v_0_rcv_nxt))
                     a!18)
                 a!39
                 (or (and (= v_0_snd_wl1 input_0_net.ack_seq) a!49)
                     (and a!58 a!59))))
      (a!62 (ite (<= v_0_rtx_buf
                     (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))
                 0
                 (+ v_0_rtx_buf a!61)))
      (a!100 (and v_0_rtt_active
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  a!99
                  (not v_0_rtt_ambiguous)))
      (a!125 (= v_1_seg_acceptable
                (or (and (= 0 v_0_local_window)
                         (= input_0_net.ack_seq v_0_rcv_nxt))
                    a!18)))
      (a!126 (and v_0_rtt_active
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  a!99))
      (a!136 (+ (ite (and a!91 a!92) (ite a!93 a!94 a!97) a!98) a!61))
      (a!154 (and (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  a!153))
      (a!170 (ite a!165
                  v_0_tx_time_11
                  (ite a!166
                       v_0_tx_time_12
                       (ite a!167
                            v_0_tx_time_13
                            (ite a!168 v_0_tx_time_14 a!169)))))
      (a!177 (ite a!165
                  v_0_tx_time_12
                  (ite a!166
                       v_0_tx_time_13
                       (ite a!167 v_0_tx_time_14 (ite a!168 v_0_tx_time_15 0)))))
      (a!184 (ite a!164
                  v_0_tx_time_12
                  (ite a!165
                       v_0_tx_time_13
                       (ite a!166 v_0_tx_time_14 (ite a!167 v_0_tx_time_15 0)))))
      (a!191 (ite a!163
                  v_0_tx_time_12
                  (ite a!164
                       v_0_tx_time_13
                       (ite a!165 v_0_tx_time_14 (ite a!166 v_0_tx_time_15 0)))))
      (a!198 (ite a!162
                  v_0_tx_time_12
                  (ite a!163
                       v_0_tx_time_13
                       (ite a!164 v_0_tx_time_14 (ite a!165 v_0_tx_time_15 0)))))
      (a!205 (ite a!161
                  v_0_tx_time_12
                  (ite a!162
                       v_0_tx_time_13
                       (ite a!163 v_0_tx_time_14 (ite a!164 v_0_tx_time_15 0)))))
      (a!211 (ite a!160
                  v_0_tx_time_12
                  (ite a!161
                       v_0_tx_time_13
                       (ite a!162 v_0_tx_time_14 (ite a!163 v_0_tx_time_15 0)))))
      (a!217 (ite a!159
                  v_0_tx_time_12
                  (ite a!160
                       v_0_tx_time_13
                       (ite a!161 v_0_tx_time_14 (ite a!162 v_0_tx_time_15 0)))))
      (a!223 (ite a!158
                  v_0_tx_time_12
                  (ite a!159
                       v_0_tx_time_13
                       (ite a!160 v_0_tx_time_14 (ite a!161 v_0_tx_time_15 0)))))
      (a!229 (ite a!157
                  v_0_tx_time_12
                  (ite a!158
                       v_0_tx_time_13
                       (ite a!159 v_0_tx_time_14 (ite a!160 v_0_tx_time_15 0)))))
      (a!234 (ite a!156
                  v_0_tx_time_12
                  (ite a!157
                       v_0_tx_time_13
                       (ite a!158 v_0_tx_time_14 (ite a!159 v_0_tx_time_15 0)))))
      (a!239 (ite a!155
                  v_0_tx_time_12
                  (ite a!156
                       v_0_tx_time_13
                       (ite a!157 v_0_tx_time_14 (ite a!158 v_0_tx_time_15 0)))))
      (a!702 (= v_0_rto_base_ms
                (ite v_0_rtt_measured (ite (<= 60000 a!701) 60000 a!701) 1000)))
      (a!959 (or (and (= 0 v_0_local_window)
                      (= input_0_net.ack_seq v_0_rcv_nxt))
                 (and (<= 1 v_0_local_window)
                      (<= a!958 (+ (- 1) v_0_local_window)))))
      (a!970 (not (and (>= a!964 (+ 1 v_0_rtx_buf)) (>= 2147483647 a!964))))
      (a!982 (or (and (= v_0_snd_wl1 input_0_net.ack_seq)
                      (not (<= 2147483648 a!976)))
                 (and (not (<= a!981 0)) (not (<= 2147483648 a!981)))))
      (a!984 (ite (<= v_0_rtx_buf a!964) 0 (+ v_0_rtx_buf (* (- 1) a!964))))
      (a!1040 (= v_1_ack_is_future
                 (and (>= a!964 (+ 1 v_0_rtx_buf)) (>= 2147483647 a!964))))
      (a!1048 (not (<= v_0_rtt_remaining (+ a!1012 (* (- 1) a!964)))))
      (a!1063 (ite (= 13 a!964)
                   v_0_tx_time_13
                   (ite (= 14 a!964)
                        v_0_tx_time_14
                        (ite (= 15 a!964) v_0_tx_time_15 0))))
      (a!1072 (ite (= 12 a!964)
                   v_0_tx_time_13
                   (ite (= 13 a!964)
                        v_0_tx_time_14
                        (ite (= 14 a!964) v_0_tx_time_15 0))))
      (a!1081 (ite (= 11 a!964)
                   v_0_tx_time_13
                   (ite (= 12 a!964)
                        v_0_tx_time_14
                        (ite (= 13 a!964) v_0_tx_time_15 0))))
      (a!1090 (ite (= 10 a!964)
                   v_0_tx_time_13
                   (ite (= 11 a!964)
                        v_0_tx_time_14
                        (ite (= 12 a!964) v_0_tx_time_15 0))))
      (a!1098 (ite (= 9 a!964)
                   v_0_tx_time_13
                   (ite (= 10 a!964)
                        v_0_tx_time_14
                        (ite (= 11 a!964) v_0_tx_time_15 0))))
      (a!1106 (ite (= 8 a!964)
                   v_0_tx_time_13
                   (ite (= 9 a!964)
                        v_0_tx_time_14
                        (ite (= 10 a!964) v_0_tx_time_15 0))))
      (a!1114 (ite (= 7 a!964)
                   v_0_tx_time_13
                   (ite (= 8 a!964)
                        v_0_tx_time_14
                        (ite (= 9 a!964) v_0_tx_time_15 0))))
      (a!1121 (ite (= 6 a!964)
                   v_0_tx_time_13
                   (ite (= 7 a!964)
                        v_0_tx_time_14
                        (ite (= 8 a!964) v_0_tx_time_15 0))))
      (a!1128 (ite (= 5 a!964)
                   v_0_tx_time_13
                   (ite (= 6 a!964)
                        v_0_tx_time_14
                        (ite (= 7 a!964) v_0_tx_time_15 0))))
      (a!1135 (ite (= 4 a!964)
                   v_0_tx_time_13
                   (ite (= 5 a!964)
                        v_0_tx_time_14
                        (ite (= 6 a!964) v_0_tx_time_15 0))))
      (a!1141 (ite (= 3 a!964)
                   v_0_tx_time_13
                   (ite (= 4 a!964)
                        v_0_tx_time_14
                        (ite (= 5 a!964) v_0_tx_time_15 0))))
      (a!1147 (ite (= 2 a!964)
                   v_0_tx_time_13
                   (ite (= 3 a!964)
                        v_0_tx_time_14
                        (ite (= 4 a!964) v_0_tx_time_15 0))))
      (a!1153 (ite (= 1 a!964)
                   v_0_tx_time_13
                   (ite (= 2 a!964)
                        v_0_tx_time_14
                        (ite (= 3 a!964) v_0_tx_time_15 0))))
      (a!1473 (or (>= 0 v_0_cb_count)
                  (and (not (>= v_0_cb_partial_prefix v_0_cb_length_09))
                       (= v_0_cb_end_09 a!1472)))))
(let ((a!63 (ite (<= a!62 (ite (<= 0 v_0_rtx_buf) v_0_rtx_buf 0))
                 a!62
                 (ite (<= 0 v_0_rtx_buf) v_0_rtx_buf 0)))
      (a!70 (and (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)
                 (not v_0_fr_active)
                 (= (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks) 3)
                 (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una)))
      (a!71 (and v_0_fr_active
                 (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))))
      (a!101 (ite a!100 (+ now_1 (* (- 1) v_0_rtt_start_ms)) v_0_rtt_last_ms))
      (a!128 (>= (+ v_0_rtt_end
                    (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                 (- 4294967296)))
      (a!129 (< (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                8589934592))
      (a!130 (< (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                0))
      (a!131 (+ (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                4294967296))
      (a!132 (>= (+ v_0_rtt_end
                    (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                 4294967296))
      (a!133 (- (+ v_0_rtt_end
                   (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                4294967296))
      (a!135 (mod (+ v_0_rtt_end
                     (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))
                  4294967296))
      (a!137 (and v_0_rtt_active
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  (not (<= v_0_rtt_remaining a!136))))
      (a!171 (ite a!161
                  v_0_tx_time_07
                  (ite a!162
                       v_0_tx_time_08
                       (ite a!163
                            v_0_tx_time_09
                            (ite a!164 v_0_tx_time_10 a!170)))))
      (a!178 (ite a!161
                  v_0_tx_time_08
                  (ite a!162
                       v_0_tx_time_09
                       (ite a!163
                            v_0_tx_time_10
                            (ite a!164 v_0_tx_time_11 a!177)))))
      (a!185 (ite a!160
                  v_0_tx_time_08
                  (ite a!161
                       v_0_tx_time_09
                       (ite a!162
                            v_0_tx_time_10
                            (ite a!163 v_0_tx_time_11 a!184)))))
      (a!192 (ite a!159
                  v_0_tx_time_08
                  (ite a!160
                       v_0_tx_time_09
                       (ite a!161
                            v_0_tx_time_10
                            (ite a!162 v_0_tx_time_11 a!191)))))
      (a!199 (ite a!158
                  v_0_tx_time_08
                  (ite a!159
                       v_0_tx_time_09
                       (ite a!160
                            v_0_tx_time_10
                            (ite a!161 v_0_tx_time_11 a!198)))))
      (a!206 (ite a!157
                  v_0_tx_time_08
                  (ite a!158
                       v_0_tx_time_09
                       (ite a!159
                            v_0_tx_time_10
                            (ite a!160 v_0_tx_time_11 a!205)))))
      (a!212 (ite a!156
                  v_0_tx_time_08
                  (ite a!157
                       v_0_tx_time_09
                       (ite a!158
                            v_0_tx_time_10
                            (ite a!159 v_0_tx_time_11 a!211)))))
      (a!218 (ite a!155
                  v_0_tx_time_08
                  (ite a!156
                       v_0_tx_time_09
                       (ite a!157
                            v_0_tx_time_10
                            (ite a!158 v_0_tx_time_11 a!217)))))
      (a!224 (ite a!154
                  (ite a!155
                       v_0_tx_time_09
                       (ite a!156
                            v_0_tx_time_10
                            (ite a!157 v_0_tx_time_11 a!223)))
                  v_0_tx_time_08))
      (a!244 (ite a!154
                  (ite a!155
                       v_0_tx_time_13
                       (ite a!156 v_0_tx_time_14 (ite a!157 v_0_tx_time_15 0)))
                  v_0_tx_time_12))
      (a!377 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_00))
                 (- 4294967296)))
      (a!378 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                8589934592))
      (a!379 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                0))
      (a!380 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                4294967296))
      (a!381 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_00))
                 4294967296))
      (a!382 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_00))
                4294967296))
      (a!384 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_00))
                  4294967296))
      (a!388 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_01))
                 (- 4294967296)))
      (a!389 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                8589934592))
      (a!390 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                0))
      (a!391 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                4294967296))
      (a!392 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_01))
                 4294967296))
      (a!393 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_01))
                4294967296))
      (a!395 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_01))
                  4294967296))
      (a!399 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_02))
                 (- 4294967296)))
      (a!400 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                8589934592))
      (a!401 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                0))
      (a!402 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                4294967296))
      (a!403 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_02))
                 4294967296))
      (a!404 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_02))
                4294967296))
      (a!406 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_02))
                  4294967296))
      (a!410 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_03))
                 (- 4294967296)))
      (a!411 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                8589934592))
      (a!412 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                0))
      (a!413 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                4294967296))
      (a!414 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_03))
                 4294967296))
      (a!415 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_03))
                4294967296))
      (a!417 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_03))
                  4294967296))
      (a!421 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_04))
                 (- 4294967296)))
      (a!422 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                8589934592))
      (a!423 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                0))
      (a!424 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                4294967296))
      (a!425 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_04))
                 4294967296))
      (a!426 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_04))
                4294967296))
      (a!428 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_04))
                  4294967296))
      (a!432 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_05))
                 (- 4294967296)))
      (a!433 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                8589934592))
      (a!434 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                0))
      (a!435 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                4294967296))
      (a!436 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_05))
                 4294967296))
      (a!437 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_05))
                4294967296))
      (a!439 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_05))
                  4294967296))
      (a!443 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_06))
                 (- 4294967296)))
      (a!444 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                8589934592))
      (a!445 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                0))
      (a!446 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                4294967296))
      (a!447 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_06))
                 4294967296))
      (a!448 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_06))
                4294967296))
      (a!450 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_06))
                  4294967296))
      (a!454 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_07))
                 (- 4294967296)))
      (a!455 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                8589934592))
      (a!456 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                0))
      (a!457 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                4294967296))
      (a!458 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_07))
                 4294967296))
      (a!459 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_07))
                4294967296))
      (a!461 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_07))
                  4294967296))
      (a!465 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_08))
                 (- 4294967296)))
      (a!466 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                8589934592))
      (a!467 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                0))
      (a!468 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                4294967296))
      (a!469 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_08))
                 4294967296))
      (a!470 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_08))
                4294967296))
      (a!472 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_08))
                  4294967296))
      (a!476 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_09))
                 (- 4294967296)))
      (a!477 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                8589934592))
      (a!478 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                0))
      (a!479 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                4294967296))
      (a!480 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_09))
                 4294967296))
      (a!481 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_09))
                4294967296))
      (a!483 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_09))
                  4294967296))
      (a!487 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_10))
                 (- 4294967296)))
      (a!488 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                8589934592))
      (a!489 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                0))
      (a!490 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                4294967296))
      (a!491 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_10))
                 4294967296))
      (a!492 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_10))
                4294967296))
      (a!494 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_10))
                  4294967296))
      (a!498 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_11))
                 (- 4294967296)))
      (a!499 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                8589934592))
      (a!500 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                0))
      (a!501 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                4294967296))
      (a!502 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_11))
                 4294967296))
      (a!503 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_11))
                4294967296))
      (a!505 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_11))
                  4294967296))
      (a!509 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_12))
                 (- 4294967296)))
      (a!510 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                8589934592))
      (a!511 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                0))
      (a!512 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                4294967296))
      (a!513 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_12))
                 4294967296))
      (a!514 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_12))
                4294967296))
      (a!516 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_12))
                  4294967296))
      (a!520 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_13))
                 (- 4294967296)))
      (a!521 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                8589934592))
      (a!522 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                0))
      (a!523 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                4294967296))
      (a!524 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_13))
                 4294967296))
      (a!525 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_13))
                4294967296))
      (a!527 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_13))
                  4294967296))
      (a!531 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_14))
                 (- 4294967296)))
      (a!532 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                8589934592))
      (a!533 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                0))
      (a!534 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                4294967296))
      (a!535 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_14))
                 4294967296))
      (a!536 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_14))
                4294967296))
      (a!538 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_14))
                  4294967296))
      (a!542 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_15))
                 (- 4294967296)))
      (a!543 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                8589934592))
      (a!544 (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                0))
      (a!545 (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                4294967296))
      (a!546 (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                    (* (- 1) v_0_cb_end_15))
                 4294967296))
      (a!547 (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                   (* (- 1) v_0_cb_end_15))
                4294967296))
      (a!549 (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_15))
                  4294967296))
      (a!971 (ite (and a!959 (<= 1 a!964) (<= a!964 v_0_rtx_buf))
                  input_0_net.ack_ack
                  v_0_snd_una))
      (a!983 (= 0
                (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                     input_0_net.ack_window
                     v_0_snd_wnd)))
      (a!985 (ite (<= a!984 (ite (<= 0 v_0_rtx_buf) v_0_rtx_buf 0))
                  a!984
                  (ite (<= 0 v_0_rtx_buf) v_0_rtx_buf 0)))
      (a!1013 (and v_0_rtt_active
                   a!959
                   (<= 1 a!964)
                   (<= a!964 v_0_rtx_buf)
                   (>= a!964 a!1012)
                   (not v_0_rtt_ambiguous)))
      (a!1036 (= v_1_snd_wnd
                 (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                      input_0_net.ack_window
                      v_0_snd_wnd)))
      (a!1037 (= v_1_snd_wl1
                 (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                      input_0_net.ack_seq
                      v_0_snd_wl1)))
      (a!1038 (= v_1_snd_wl2
                 (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                      input_0_net.ack_ack
                      v_0_snd_wl2)))
      (a!1041 (and v_0_rtt_active
                   a!959
                   (<= 1 a!964)
                   (<= a!964 v_0_rtx_buf)
                   (>= a!964 a!1012)))
      (a!1062 (and a!959 (<= 1 a!964) (<= a!964 v_0_rtx_buf) (not (= 0 a!964))))
      (a!1064 (ite (= 10 a!964)
                   v_0_tx_time_10
                   (ite (= 11 a!964)
                        v_0_tx_time_11
                        (ite (= 12 a!964) v_0_tx_time_12 a!1063))))
      (a!1073 (ite (= 9 a!964)
                   v_0_tx_time_10
                   (ite (= 10 a!964)
                        v_0_tx_time_11
                        (ite (= 11 a!964) v_0_tx_time_12 a!1072))))
      (a!1082 (ite (= 8 a!964)
                   v_0_tx_time_10
                   (ite (= 9 a!964)
                        v_0_tx_time_11
                        (ite (= 10 a!964) v_0_tx_time_12 a!1081))))
      (a!1091 (ite (= 7 a!964)
                   v_0_tx_time_10
                   (ite (= 8 a!964)
                        v_0_tx_time_11
                        (ite (= 9 a!964) v_0_tx_time_12 a!1090))))
      (a!1099 (ite (= 6 a!964)
                   v_0_tx_time_10
                   (ite (= 7 a!964)
                        v_0_tx_time_11
                        (ite (= 8 a!964) v_0_tx_time_12 a!1098))))
      (a!1107 (ite (= 5 a!964)
                   v_0_tx_time_10
                   (ite (= 6 a!964)
                        v_0_tx_time_11
                        (ite (= 7 a!964) v_0_tx_time_12 a!1106))))
      (a!1115 (ite (= 4 a!964)
                   v_0_tx_time_10
                   (ite (= 5 a!964)
                        v_0_tx_time_11
                        (ite (= 6 a!964) v_0_tx_time_12 a!1114))))
      (a!1122 (ite (= 3 a!964)
                   v_0_tx_time_10
                   (ite (= 4 a!964)
                        v_0_tx_time_11
                        (ite (= 5 a!964) v_0_tx_time_12 a!1121))))
      (a!1129 (ite (= 2 a!964)
                   v_0_tx_time_10
                   (ite (= 3 a!964)
                        v_0_tx_time_11
                        (ite (= 4 a!964) v_0_tx_time_12 a!1128))))
      (a!1136 (ite (= 1 a!964)
                   v_0_tx_time_10
                   (ite (= 2 a!964)
                        v_0_tx_time_11
                        (ite (= 3 a!964) v_0_tx_time_12 a!1135)))))
(let ((a!64 (and (= 0 (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                 (not v_0_fin_sent)
                 (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) v_0_snd_buf))
                 (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                 (or v_0_persist_active (= 0 (ite a!40 a!63 v_0_rtx_buf)))))
      (a!73 (+ (ite a!60 input_0_net.ack_window v_0_snd_wnd)
               (* (- 1) (ite a!40 a!63 v_0_rtx_buf))))
      (a!78 (ite (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una)
                 0
                 (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf)))))
      (a!83 (ite (<= (ite a!40 a!63 v_0_rtx_buf)
                     (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                 (ite a!40 a!63 v_0_rtx_buf)
                 (ite a!60 input_0_net.ack_window v_0_snd_wnd)))
      (a!85 (ite (<= (ite a!40 a!63 v_0_rtx_buf) 0)
                 0
                 (ite a!40 a!63 v_0_rtx_buf)))
      (a!102 (ite v_0_rtt_measured
                  (+ (* (/ 7.0 8.0) v_0_srtt_ms)
                     (* (/ 1.0 8.0) (to_real a!101)))
                  (to_real a!101)))
      (a!103 (>= (+ v_0_srtt_ms (* (- 1.0) (to_real a!101))) 0.0))
      (a!134 (ite a!132
                  a!133
                  (+ v_0_rtt_end
                     (* (- 1) (ite a!40 input_0_net.ack_ack v_0_snd_una)))))
      (a!172 (ite a!157
                  v_0_tx_time_03
                  (ite a!158
                       v_0_tx_time_04
                       (ite a!159
                            v_0_tx_time_05
                            (ite a!160 v_0_tx_time_06 a!171)))))
      (a!179 (ite a!157
                  v_0_tx_time_04
                  (ite a!158
                       v_0_tx_time_05
                       (ite a!159
                            v_0_tx_time_06
                            (ite a!160 v_0_tx_time_07 a!178)))))
      (a!186 (ite a!156
                  v_0_tx_time_04
                  (ite a!157
                       v_0_tx_time_05
                       (ite a!158
                            v_0_tx_time_06
                            (ite a!159 v_0_tx_time_07 a!185)))))
      (a!193 (ite a!155
                  v_0_tx_time_04
                  (ite a!156
                       v_0_tx_time_05
                       (ite a!157
                            v_0_tx_time_06
                            (ite a!158 v_0_tx_time_07 a!192)))))
      (a!200 (ite a!154
                  (ite a!155
                       v_0_tx_time_05
                       (ite a!156
                            v_0_tx_time_06
                            (ite a!157 v_0_tx_time_07 a!199)))
                  v_0_tx_time_04))
      (a!207 (ite (>= 5 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!154
                       (ite a!155
                            v_0_tx_time_06
                            (ite a!156 v_0_tx_time_07 a!206))
                       v_0_tx_time_05)))
      (a!230 (ite (>= 9 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!154
                       (ite a!155
                            v_0_tx_time_10
                            (ite a!156 v_0_tx_time_11 a!229))
                       v_0_tx_time_09)))
      (a!249 (ite (>= 13 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!154
                       (ite a!155 v_0_tx_time_14 (ite a!156 v_0_tx_time_15 0))
                       v_0_tx_time_13)))
      (a!257 (ite (or (>= 15 (ite a!40 a!63 v_0_rtx_buf)) a!154)
                  0
                  v_0_tx_time_15))
      (a!259 (and (= 0 (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                  (not v_0_fin_sent)
                  (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) v_0_snd_buf))
                  (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (or v_0_persist_active (= 0 (ite a!40 a!63 v_0_rtx_buf)))
                  (not v_0_persist_active)))
      (a!266 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 0))
      (a!267 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 1))
      (a!269 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 2))
      (a!271 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 3))
      (a!273 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 4))
      (a!275 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 5))
      (a!277 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 6))
      (a!279 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 7))
      (a!281 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 8))
      (a!283 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 9))
      (a!285 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 10))
      (a!287 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 11))
      (a!289 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 12))
      (a!291 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 13))
      (a!293 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 14))
      (a!295 (= (+ v_0_rtx_buf (* (- 1) (ite a!40 a!63 v_0_rtx_buf))) 15))
      (a!383 (ite a!381
                  a!382
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_00))))
      (a!394 (ite a!392
                  a!393
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_01))))
      (a!405 (ite a!403
                  a!404
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_02))))
      (a!416 (ite a!414
                  a!415
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_03))))
      (a!427 (ite a!425
                  a!426
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_04))))
      (a!438 (ite a!436
                  a!437
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_05))))
      (a!449 (ite a!447
                  a!448
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_06))))
      (a!460 (ite a!458
                  a!459
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_07))))
      (a!471 (ite a!469
                  a!470
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_08))))
      (a!482 (ite a!480
                  a!481
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_09))))
      (a!493 (ite a!491
                  a!492
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_10))))
      (a!504 (ite a!502
                  a!503
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_11))))
      (a!515 (ite a!513
                  a!514
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_12))))
      (a!526 (ite a!524
                  a!525
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_13))))
      (a!537 (ite a!535
                  a!536
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_14))))
      (a!548 (ite a!546
                  a!547
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una)
                     (* (- 1) v_0_cb_end_15))))
      (a!666 (and (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  (= 0 (ite a!40 a!63 v_0_rtx_buf))))
      (a!667 (and (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!38
                  a!39
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))))
      (a!986 (ite (and a!959 (<= 1 a!964) (<= a!964 v_0_rtx_buf))
                  a!985
                  v_0_rtx_buf))
      (a!989 (not (and v_0_fr_active (not (= a!971 v_0_snd_una)))))
      (a!990 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  (not v_0_fr_active)
                  (= (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks) 3)
                  (= a!971 v_0_snd_una)))
      (a!1014 (to_real (ite a!1013
                            (+ now_1 (* (- 1) v_0_rtt_start_ms))
                            v_0_rtt_last_ms)))
      (a!1043 (not (<= 8589934592 (+ v_0_rtt_end (* (- 1) a!971)))))
      (a!1045 (ite (>= (+ v_0_rtt_end (* (- 1) a!971)) 4294967296)
                   (+ (- 4294967296) v_0_rtt_end (* (- 1) a!971))
                   (+ v_0_rtt_end (* (- 1) a!971))))
      (a!1058 (= v_1_rtt_last_ms
                 (ite a!1013
                      (+ now_1 (* (- 1) v_0_rtt_start_ms))
                      v_0_rtt_last_ms)))
      (a!1065 (ite (= 7 a!964)
                   v_0_tx_time_07
                   (ite (= 8 a!964)
                        v_0_tx_time_08
                        (ite (= 9 a!964) v_0_tx_time_09 a!1064))))
      (a!1074 (ite (= 6 a!964)
                   v_0_tx_time_07
                   (ite (= 7 a!964)
                        v_0_tx_time_08
                        (ite (= 8 a!964) v_0_tx_time_09 a!1073))))
      (a!1083 (ite (= 5 a!964)
                   v_0_tx_time_07
                   (ite (= 6 a!964)
                        v_0_tx_time_08
                        (ite (= 7 a!964) v_0_tx_time_09 a!1082))))
      (a!1092 (ite (= 4 a!964)
                   v_0_tx_time_07
                   (ite (= 5 a!964)
                        v_0_tx_time_08
                        (ite (= 6 a!964) v_0_tx_time_09 a!1091))))
      (a!1100 (ite (= 3 a!964)
                   v_0_tx_time_07
                   (ite (= 4 a!964)
                        v_0_tx_time_08
                        (ite (= 5 a!964) v_0_tx_time_09 a!1099))))
      (a!1108 (ite (= 2 a!964)
                   v_0_tx_time_07
                   (ite (= 3 a!964)
                        v_0_tx_time_08
                        (ite (= 4 a!964) v_0_tx_time_09 a!1107))))
      (a!1116 (ite (= 1 a!964)
                   v_0_tx_time_07
                   (ite (= 2 a!964)
                        v_0_tx_time_08
                        (ite (= 3 a!964) v_0_tx_time_09 a!1115))))
      (a!1123 (ite a!1062
                   (ite (= 1 a!964)
                        v_0_tx_time_08
                        (ite (= 2 a!964) v_0_tx_time_09 a!1122))
                   v_0_tx_time_07))
      (a!1142 (ite a!1062
                   (ite (= 1 a!964)
                        v_0_tx_time_11
                        (ite (= 2 a!964) v_0_tx_time_12 a!1141))
                   v_0_tx_time_10))
      (a!1158 (ite a!1062
                   (ite (= 1 a!964)
                        v_0_tx_time_14
                        (ite (= 2 a!964) v_0_tx_time_15 0))
                   v_0_tx_time_13))
      (a!1246 (= v_1_fr_exited (and v_0_fr_active (not (= a!971 v_0_snd_una)))))
      (a!1258 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_00)))))
      (a!1260 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_00)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_00))
                   (+ a!971 (* (- 1) v_0_cb_end_00))))
      (a!1264 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_01)))))
      (a!1266 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_01)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_01))
                   (+ a!971 (* (- 1) v_0_cb_end_01))))
      (a!1270 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_02)))))
      (a!1272 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_02)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_02))
                   (+ a!971 (* (- 1) v_0_cb_end_02))))
      (a!1276 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_03)))))
      (a!1278 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_03)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_03))
                   (+ a!971 (* (- 1) v_0_cb_end_03))))
      (a!1282 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_04)))))
      (a!1284 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_04)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_04))
                   (+ a!971 (* (- 1) v_0_cb_end_04))))
      (a!1288 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_05)))))
      (a!1290 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_05)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_05))
                   (+ a!971 (* (- 1) v_0_cb_end_05))))
      (a!1294 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_06)))))
      (a!1296 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_06)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_06))
                   (+ a!971 (* (- 1) v_0_cb_end_06))))
      (a!1300 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_07)))))
      (a!1302 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_07)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_07))
                   (+ a!971 (* (- 1) v_0_cb_end_07))))
      (a!1306 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_08)))))
      (a!1308 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_08)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_08))
                   (+ a!971 (* (- 1) v_0_cb_end_08))))
      (a!1312 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_09)))))
      (a!1314 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_09)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_09))
                   (+ a!971 (* (- 1) v_0_cb_end_09))))
      (a!1318 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_10)))))
      (a!1320 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_10)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_10))
                   (+ a!971 (* (- 1) v_0_cb_end_10))))
      (a!1324 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_11)))))
      (a!1326 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_11)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_11))
                   (+ a!971 (* (- 1) v_0_cb_end_11))))
      (a!1330 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_12)))))
      (a!1332 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_12)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_12))
                   (+ a!971 (* (- 1) v_0_cb_end_12))))
      (a!1336 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_13)))))
      (a!1338 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_13)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_13))
                   (+ a!971 (* (- 1) v_0_cb_end_13))))
      (a!1342 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_14)))))
      (a!1344 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_14)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_14))
                   (+ a!971 (* (- 1) v_0_cb_end_14))))
      (a!1348 (not (<= 8589934592 (+ a!971 (* (- 1) v_0_cb_end_15)))))
      (a!1350 (ite (>= (+ a!971 (* (- 1) v_0_cb_end_15)) 4294967296)
                   (+ (- 4294967296) a!971 (* (- 1) v_0_cb_end_15))
                   (+ a!971 (* (- 1) v_0_cb_end_15)))))
(let ((a!65 (or a!64
                (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                (= 0 (ite a!40 a!63 v_0_rtx_buf))))
      (a!69 (not (or a!64 (= 0 (ite a!40 a!63 v_0_rtx_buf)))))
      (a!79 (or v_0_fr_active
                (not (and (<= 1 a!78)
                          (not v_0_persist_active)
                          (<= 1 v_0_snd_wnd)))))
      (a!80 (ite (>= v_0_cc_cwnd v_0_cc_ssthresh)
                 (ite (>= (+ v_0_cc_ca_credit a!78) v_0_cc_cwnd) 4 0)
                 (ite (>= 4 a!78) a!78 4)))
      (a!84 (<= 1 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!86 (<= 0 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!104 (ite a!103
                  (+ v_0_srtt_ms (* (- 1.0) (to_real a!101)))
                  (+ (* (- 1.0) v_0_srtt_ms) (to_real a!101))))
      (a!138 (+ (ite (and a!128 a!129) (ite a!130 a!131 a!134) a!135)
                (* (- 1)
                   (ite (or a!64 a!126) 0 (ite a!137 a!136 v_0_rtt_remaining)))))
      (a!173 (ite (>= 0 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!154
                       (ite a!155
                            v_0_tx_time_01
                            (ite a!156 v_0_tx_time_02 a!172))
                       v_0_tx_time_00)))
      (a!174 (<= 2 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!180 (ite (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  0
                  (ite a!154
                       (ite a!155
                            v_0_tx_time_02
                            (ite a!156 v_0_tx_time_03 a!179))
                       v_0_tx_time_01)))
      (a!181 (<= 3 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!188 (<= 4 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!195 (<= 5 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!202 (<= 6 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!208 (<= 7 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!215 (<= 8 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!220 (<= 9 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!226 (<= 10 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!231 (<= 11 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!236 (<= 12 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!241 (<= 13 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!246 (<= 14 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!250 (<= 15 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!254 (<= 16 (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!263 (and (>= v_0_cc_cwnd v_0_cc_ssthresh)
                  (not (>= (+ v_0_cc_ca_credit a!78) v_0_cc_cwnd))))
      (a!268 (and a!267
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!270 (and a!269
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!272 (and a!271
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!274 (and a!273
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!276 (and a!275
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!278 (and a!277
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!280 (and a!279
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!282 (and a!281
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!284 (and a!283
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!286 (and a!285
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!288 (and a!287
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!290 (and a!289
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!292 (and a!291
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!294 (and a!293
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))))
      (a!296 (and a!295
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!302 (and a!293
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!308 (and a!291
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!314 (and a!289
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!319 (and a!287
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!324 (and a!285
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!329 (and a!283
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!334 (and a!281
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!338 (and a!279
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!342 (and a!277
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!346 (and a!275
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!350 (and a!273
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!353 (and a!271
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!356 (and a!269
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!359 (and a!267
                  (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una)
                          v_0_snd_una))
                  v_0_cc_rto_15))
      (a!362 (and (not (>= 15 (ite a!40 a!63 v_0_rtx_buf)))
                  (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_15))
      (a!364 (= v_1_fr_emit_count (ite a!70 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!371 (or a!64
                 a!71
                 a!70
                 (not (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                 (= 0 (ite a!40 a!63 v_0_rtx_buf))))
      (a!385 (not (<= 2147483648
                      (ite (and a!377 a!378) (ite a!379 a!380 a!383) a!384))))
      (a!396 (not (<= 2147483648
                      (ite (and a!388 a!389) (ite a!390 a!391 a!394) a!395))))
      (a!407 (not (<= 2147483648
                      (ite (and a!399 a!400) (ite a!401 a!402 a!405) a!406))))
      (a!418 (not (<= 2147483648
                      (ite (and a!410 a!411) (ite a!412 a!413 a!416) a!417))))
      (a!429 (not (<= 2147483648
                      (ite (and a!421 a!422) (ite a!423 a!424 a!427) a!428))))
      (a!440 (not (<= 2147483648
                      (ite (and a!432 a!433) (ite a!434 a!435 a!438) a!439))))
      (a!451 (not (<= 2147483648
                      (ite (and a!443 a!444) (ite a!445 a!446 a!449) a!450))))
      (a!462 (not (<= 2147483648
                      (ite (and a!454 a!455) (ite a!456 a!457 a!460) a!461))))
      (a!473 (not (<= 2147483648
                      (ite (and a!465 a!466) (ite a!467 a!468 a!471) a!472))))
      (a!484 (not (<= 2147483648
                      (ite (and a!476 a!477) (ite a!478 a!479 a!482) a!483))))
      (a!495 (not (<= 2147483648
                      (ite (and a!487 a!488) (ite a!489 a!490 a!493) a!494))))
      (a!506 (not (<= 2147483648
                      (ite (and a!498 a!499) (ite a!500 a!501 a!504) a!505))))
      (a!517 (not (<= 2147483648
                      (ite (and a!509 a!510) (ite a!511 a!512 a!515) a!516))))
      (a!528 (not (<= 2147483648
                      (ite (and a!520 a!521) (ite a!522 a!523 a!526) a!527))))
      (a!539 (not (<= 2147483648
                      (ite (and a!531 a!532) (ite a!533 a!534 a!537) a!538))))
      (a!550 (not (<= 2147483648
                      (ite (and a!542 a!543) (ite a!544 a!545 a!548) a!549))))
      (a!668 (and (not a!64) (or (and (not a!666) active_0_rtx) a!667)))
      (a!670 (and (= 0 (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                  (not v_0_fin_sent)
                  (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) v_0_snd_buf))
                  (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (or v_0_persist_active (= 0 (ite a!40 a!63 v_0_rtx_buf)))
                  (or active_0_persist a!259)))
      (a!987 (and a!983
                  (not v_0_fin_sent)
                  (<= 1 (+ a!986 v_0_snd_buf))
                  (>= 1 a!986)
                  (or v_0_persist_active (= 0 a!986))))
      (a!992 (+ (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                     input_0_net.ack_window
                     v_0_snd_wnd)
                (* (- 1) a!986)))
      (a!995 (ite (= a!971 v_0_snd_una) 0 (+ v_0_rtx_buf (* (- 1) a!986))))
      (a!1000 (<= a!986
                  (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                       input_0_net.ack_window
                       v_0_snd_wnd)))
      (a!1015 (ite a!1013
                   (ite v_0_rtt_measured
                        (+ (* (/ 7.0 8.0) v_0_srtt_ms) (* (/ 1.0 8.0) a!1014))
                        a!1014)
                   v_0_srtt_ms))
      (a!1016 (ite (>= (+ v_0_srtt_ms (* (- 1.0) a!1014)) 0.0)
                   (+ v_0_srtt_ms (* (- 1.0) a!1014))
                   (+ (* (- 1.0) v_0_srtt_ms) a!1014)))
      (a!1044 (and (>= (+ v_0_rtt_end (* (- 1) a!971)) (- 4294967296)) a!1043))
      (a!1046 (ite (<= 0 (+ v_0_rtt_end (* (- 1) a!971)))
                   a!1045
                   (+ 4294967296 v_0_rtt_end (* (- 1) a!971))))
      (a!1066 (ite (= 4 a!964)
                   v_0_tx_time_04
                   (ite (= 5 a!964)
                        v_0_tx_time_05
                        (ite (= 6 a!964) v_0_tx_time_06 a!1065))))
      (a!1075 (ite (= 3 a!964)
                   v_0_tx_time_04
                   (ite (= 4 a!964)
                        v_0_tx_time_05
                        (ite (= 5 a!964) v_0_tx_time_06 a!1074))))
      (a!1084 (ite (= 2 a!964)
                   v_0_tx_time_04
                   (ite (= 3 a!964)
                        v_0_tx_time_05
                        (ite (= 4 a!964) v_0_tx_time_06 a!1083))))
      (a!1093 (ite (= 1 a!964)
                   v_0_tx_time_04
                   (ite (= 2 a!964)
                        v_0_tx_time_05
                        (ite (= 3 a!964) v_0_tx_time_06 a!1092))))
      (a!1101 (ite a!1062
                   (ite (= 1 a!964)
                        v_0_tx_time_05
                        (ite (= 2 a!964) v_0_tx_time_06 a!1100))
                   v_0_tx_time_04))
      (a!1109 (ite (>= 5 a!986)
                   0
                   (ite a!1062
                        (ite (= 1 a!964) v_0_tx_time_06 a!1108)
                        v_0_tx_time_05)))
      (a!1130 (ite (>= 8 a!986)
                   0
                   (ite a!1062
                        (ite (= 1 a!964) v_0_tx_time_09 a!1129)
                        v_0_tx_time_08)))
      (a!1148 (ite (>= 11 a!986)
                   0
                   (ite a!1062
                        (ite (= 1 a!964) v_0_tx_time_12 a!1147)
                        v_0_tx_time_11)))
      (a!1163 (ite (>= 14 a!986)
                   0
                   (ite a!1062
                        (ite (= 1 a!964) v_0_tx_time_15 0)
                        v_0_tx_time_14)))
      (a!1169 (and a!983
                   (not v_0_fin_sent)
                   (<= 1 (+ a!986 v_0_snd_buf))
                   (>= 1 a!986)
                   (or v_0_persist_active (= 0 a!986))
                   (not v_0_persist_active)))
      (a!1172 (or v_0_fr_active
                  (and v_0_fr_active (not (= a!971 v_0_snd_una)))
                  a!990))
      (a!1176 (or (= (+ v_0_rtx_buf (* (- 1) a!986)) 0) (= a!971 v_0_snd_una)))
      (a!1177 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 1)
                   (not (= a!971 v_0_snd_una))))
      (a!1178 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 2)
                   (not (= a!971 v_0_snd_una))))
      (a!1179 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 3)
                   (not (= a!971 v_0_snd_una))))
      (a!1180 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 4)
                   (not (= a!971 v_0_snd_una))))
      (a!1181 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 5)
                   (not (= a!971 v_0_snd_una))))
      (a!1182 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 6)
                   (not (= a!971 v_0_snd_una))))
      (a!1183 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 7)
                   (not (= a!971 v_0_snd_una))))
      (a!1184 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 8)
                   (not (= a!971 v_0_snd_una))))
      (a!1185 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 9)
                   (not (= a!971 v_0_snd_una))))
      (a!1186 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 10)
                   (not (= a!971 v_0_snd_una))))
      (a!1187 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 11)
                   (not (= a!971 v_0_snd_una))))
      (a!1188 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 12)
                   (not (= a!971 v_0_snd_una))))
      (a!1189 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 13)
                   (not (= a!971 v_0_snd_una))))
      (a!1190 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 14)
                   (not (= a!971 v_0_snd_una))))
      (a!1191 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 15)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1196 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 14)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1201 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 13)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1206 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 12)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1211 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 11)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1215 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 10)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1219 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 9)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1223 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 8)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1227 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 7)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1230 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 6)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1233 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 5)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1236 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 4)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1239 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 3)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1241 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 2)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1243 (and (= (+ v_0_rtx_buf (* (- 1) a!986)) 1)
                   (not (= a!971 v_0_snd_una))
                   v_0_cc_rto_15))
      (a!1259 (and (>= (+ a!971 (* (- 1) v_0_cb_end_00)) (- 4294967296)) a!1258))
      (a!1261 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_00)))
                   a!1260
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_00))))
      (a!1265 (and (>= (+ a!971 (* (- 1) v_0_cb_end_01)) (- 4294967296)) a!1264))
      (a!1267 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_01)))
                   a!1266
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_01))))
      (a!1271 (and (>= (+ a!971 (* (- 1) v_0_cb_end_02)) (- 4294967296)) a!1270))
      (a!1273 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_02)))
                   a!1272
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_02))))
      (a!1277 (and (>= (+ a!971 (* (- 1) v_0_cb_end_03)) (- 4294967296)) a!1276))
      (a!1279 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_03)))
                   a!1278
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_03))))
      (a!1283 (and (>= (+ a!971 (* (- 1) v_0_cb_end_04)) (- 4294967296)) a!1282))
      (a!1285 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_04)))
                   a!1284
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_04))))
      (a!1289 (and (>= (+ a!971 (* (- 1) v_0_cb_end_05)) (- 4294967296)) a!1288))
      (a!1291 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_05)))
                   a!1290
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_05))))
      (a!1295 (and (>= (+ a!971 (* (- 1) v_0_cb_end_06)) (- 4294967296)) a!1294))
      (a!1297 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_06)))
                   a!1296
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_06))))
      (a!1301 (and (>= (+ a!971 (* (- 1) v_0_cb_end_07)) (- 4294967296)) a!1300))
      (a!1303 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_07)))
                   a!1302
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_07))))
      (a!1307 (and (>= (+ a!971 (* (- 1) v_0_cb_end_08)) (- 4294967296)) a!1306))
      (a!1309 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_08)))
                   a!1308
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_08))))
      (a!1313 (and (>= (+ a!971 (* (- 1) v_0_cb_end_09)) (- 4294967296)) a!1312))
      (a!1315 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_09)))
                   a!1314
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_09))))
      (a!1319 (and (>= (+ a!971 (* (- 1) v_0_cb_end_10)) (- 4294967296)) a!1318))
      (a!1321 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_10)))
                   a!1320
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_10))))
      (a!1325 (and (>= (+ a!971 (* (- 1) v_0_cb_end_11)) (- 4294967296)) a!1324))
      (a!1327 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_11)))
                   a!1326
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_11))))
      (a!1331 (and (>= (+ a!971 (* (- 1) v_0_cb_end_12)) (- 4294967296)) a!1330))
      (a!1333 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_12)))
                   a!1332
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_12))))
      (a!1337 (and (>= (+ a!971 (* (- 1) v_0_cb_end_13)) (- 4294967296)) a!1336))
      (a!1339 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_13)))
                   a!1338
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_13))))
      (a!1343 (and (>= (+ a!971 (* (- 1) v_0_cb_end_14)) (- 4294967296)) a!1342))
      (a!1345 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_14)))
                   a!1344
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_14))))
      (a!1349 (and (>= (+ a!971 (* (- 1) v_0_cb_end_15)) (- 4294967296)) a!1348))
      (a!1351 (ite (<= 0 (+ a!971 (* (- 1) v_0_cb_end_15)))
                   a!1350
                   (+ 4294967296 a!971 (* (- 1) v_0_cb_end_15))))
      (a!1403 (and (not (and a!959
                             (<= 1 a!964)
                             (<= a!964 v_0_rtx_buf)
                             (= 0 a!986)))
                   active_0_rtx))
      (a!1404 (and a!959 (<= 1 a!964) (<= a!964 v_0_rtx_buf) (<= 1 a!986))))
(let ((a!67 (<= 1 (ite a!65 0 (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks))))
      (a!68 (>= 2 (ite a!65 0 (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks))))
      (a!72 (and a!69 (or a!70 (and (not a!71) v_0_fr_active))))
      (a!81 (ite a!77
                 (+ 4 v_0_cc_cwnd (ite a!79 0 a!80))
                 (ite a!71
                      (ite a!70 a!76 v_0_cc_ssthresh)
                      (+ v_0_cc_cwnd (ite a!79 0 a!80)))))
      (a!87 (and a!86
                 (<= 1 v_0_rtx_buf)
                 (not v_0_persist_active)
                 v_0_fr_window_valid
                 (<= 1 v_0_snd_wnd)
                 (= input_0_net.ack_ack v_0_snd_una)
                 (= input_0_net.ack_window v_0_fr_last_window)
                 (<= 1 input_0_net.ack_window)
                 (not v_0_fr_active)
                 (= (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks) 3)
                 (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una)))
      (a!105 (ite v_0_rtt_measured
                  (+ (* (/ 3.0 4.0) v_0_rttvar_ms)
                     (* (/ 1.0 4.0) (ite a!100 a!104 v_0_rtt_error_ms)))
                  (* (/ 1.0 2.0) (to_real a!101))))
      (a!264 (ite (or v_0_fr_active a!71 a!70)
                  0
                  (ite (and (<= 1 a!78)
                            (not v_0_persist_active)
                            (<= 1 v_0_snd_wnd))
                       (ite a!263 (+ v_0_cc_ca_credit a!78) 0)
                       v_0_cc_ca_credit)))
      (a!297 (ite a!288
                  v_0_cc_rto_11
                  (ite a!290
                       v_0_cc_rto_12
                       (ite a!292 v_0_cc_rto_13 (ite a!294 v_0_cc_rto_14 a!296)))))
      (a!303 (ite a!286
                  v_0_cc_rto_11
                  (ite a!288
                       v_0_cc_rto_12
                       (ite a!290 v_0_cc_rto_13 (ite a!292 v_0_cc_rto_14 a!302)))))
      (a!309 (ite a!284
                  v_0_cc_rto_11
                  (ite a!286
                       v_0_cc_rto_12
                       (ite a!288 v_0_cc_rto_13 (ite a!290 v_0_cc_rto_14 a!308)))))
      (a!315 (ite a!282
                  v_0_cc_rto_11
                  (ite a!284
                       v_0_cc_rto_12
                       (ite a!286 v_0_cc_rto_13 (ite a!288 v_0_cc_rto_14 a!314)))))
      (a!320 (ite a!280
                  v_0_cc_rto_11
                  (ite a!282
                       v_0_cc_rto_12
                       (ite a!284 v_0_cc_rto_13 (ite a!286 v_0_cc_rto_14 a!319)))))
      (a!325 (ite a!278
                  v_0_cc_rto_11
                  (ite a!280
                       v_0_cc_rto_12
                       (ite a!282 v_0_cc_rto_13 (ite a!284 v_0_cc_rto_14 a!324)))))
      (a!330 (ite a!276
                  v_0_cc_rto_11
                  (ite a!278
                       v_0_cc_rto_12
                       (ite a!280 v_0_cc_rto_13 (ite a!282 v_0_cc_rto_14 a!329)))))
      (a!335 (ite a!274
                  v_0_cc_rto_11
                  (ite a!276
                       v_0_cc_rto_12
                       (ite a!278 v_0_cc_rto_13 (ite a!280 v_0_cc_rto_14 a!334)))))
      (a!339 (ite a!272
                  v_0_cc_rto_11
                  (ite a!274
                       v_0_cc_rto_12
                       (ite a!276 v_0_cc_rto_13 (ite a!278 v_0_cc_rto_14 a!338)))))
      (a!343 (ite a!270
                  v_0_cc_rto_11
                  (ite a!272
                       v_0_cc_rto_12
                       (ite a!274 v_0_cc_rto_13 (ite a!276 v_0_cc_rto_14 a!342)))))
      (a!347 (ite a!268
                  v_0_cc_rto_11
                  (ite a!270
                       v_0_cc_rto_12
                       (ite a!272 v_0_cc_rto_13 (ite a!274 v_0_cc_rto_14 a!346)))))
      (a!351 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_11
                  (ite a!268
                       v_0_cc_rto_12
                       (ite a!270 v_0_cc_rto_13 (ite a!272 v_0_cc_rto_14 a!350)))))
      (a!354 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_12
                  (ite a!268 v_0_cc_rto_13 (ite a!270 v_0_cc_rto_14 a!353))))
      (a!357 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_13
                  (ite a!268 v_0_cc_rto_14 a!356)))
      (a!360 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_14
                  a!359))
      (a!363 (= v_1_fr_dupacks
                (ite a!65 0 (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks))))
      (a!386 (ite (and (not (>= a!376 v_0_cb_count)) (<= 1 a!78) a!385) 1 0))
      (a!397 (ite (and (not (>= a!387 v_0_cb_count)) (<= 1 a!78) a!396) 1 0))
      (a!408 (ite (and (not (>= a!398 v_0_cb_count)) (<= 1 a!78) a!407) 1 0))
      (a!419 (ite (and (not (>= a!409 v_0_cb_count)) (<= 1 a!78) a!418) 1 0))
      (a!430 (ite (and (not (>= a!420 v_0_cb_count)) (<= 1 a!78) a!429) 1 0))
      (a!441 (ite (and (not (>= a!431 v_0_cb_count)) (<= 1 a!78) a!440) 1 0))
      (a!452 (ite (and (not (>= a!442 v_0_cb_count)) (<= 1 a!78) a!451) 1 0))
      (a!463 (ite (and (not (>= a!453 v_0_cb_count)) (<= 1 a!78) a!462) 1 0))
      (a!474 (ite (and (not (>= a!464 v_0_cb_count)) (<= 1 a!78) a!473) 1 0))
      (a!485 (ite (and (not (>= a!475 v_0_cb_count)) (<= 1 a!78) a!484) 1 0))
      (a!496 (ite (and (not (>= a!486 v_0_cb_count)) (<= 1 a!78) a!495) 1 0))
      (a!507 (ite (and (not (>= a!497 v_0_cb_count)) (<= 1 a!78) a!506) 1 0))
      (a!518 (ite (and (not (>= a!508 v_0_cb_count)) (<= 1 a!78) a!517) 1 0))
      (a!529 (ite (and (not (>= a!519 v_0_cb_count)) (<= 1 a!78) a!528) 1 0))
      (a!540 (ite (and (not (>= a!530 v_0_cb_count)) (<= 1 a!78) a!539) 1 0))
      (a!551 (ite (and (not (>= a!541 v_0_cb_count)) (<= 1 a!78) a!550) 1 0))
      (a!560 (ite (and (not (>= a!376 v_0_cb_count)) (<= 1 a!78) a!385)
                  v_0_cb_length_00
                  0))
      (a!561 (ite (and (not (>= a!387 v_0_cb_count)) (<= 1 a!78) a!396)
                  v_0_cb_length_01
                  0))
      (a!562 (ite (and (not (>= a!398 v_0_cb_count)) (<= 1 a!78) a!407)
                  v_0_cb_length_02
                  0))
      (a!563 (ite (and (not (>= a!409 v_0_cb_count)) (<= 1 a!78) a!418)
                  v_0_cb_length_03
                  0))
      (a!564 (ite (and (not (>= a!420 v_0_cb_count)) (<= 1 a!78) a!429)
                  v_0_cb_length_04
                  0))
      (a!565 (ite (and (not (>= a!431 v_0_cb_count)) (<= 1 a!78) a!440)
                  v_0_cb_length_05
                  0))
      (a!566 (ite (and (not (>= a!442 v_0_cb_count)) (<= 1 a!78) a!451)
                  v_0_cb_length_06
                  0))
      (a!567 (ite (and (not (>= a!453 v_0_cb_count)) (<= 1 a!78) a!462)
                  v_0_cb_length_07
                  0))
      (a!568 (ite (and (not (>= a!464 v_0_cb_count)) (<= 1 a!78) a!473)
                  v_0_cb_length_08
                  0))
      (a!569 (ite (and (not (>= a!475 v_0_cb_count)) (<= 1 a!78) a!484)
                  v_0_cb_length_09
                  0))
      (a!570 (ite (and (not (>= a!486 v_0_cb_count)) (<= 1 a!78) a!495)
                  v_0_cb_length_10
                  0))
      (a!571 (ite (and (not (>= a!497 v_0_cb_count)) (<= 1 a!78) a!506)
                  v_0_cb_length_11
                  0))
      (a!572 (ite (and (not (>= a!508 v_0_cb_count)) (<= 1 a!78) a!517)
                  v_0_cb_length_12
                  0))
      (a!573 (ite (and (not (>= a!519 v_0_cb_count)) (<= 1 a!78) a!528)
                  v_0_cb_length_13
                  0))
      (a!574 (ite (and (not (>= a!530 v_0_cb_count)) (<= 1 a!78) a!539)
                  v_0_cb_length_14
                  0))
      (a!575 (ite (and (not (>= a!541 v_0_cb_count)) (<= 1 a!78) a!550)
                  v_0_cb_length_15
                  0))
      (a!613 (ite (and (not (>= a!376 v_0_cb_count)) (<= 1 a!78) a!385)
                  0
                  v_0_cb_length_00))
      (a!614 (ite (and (not (>= a!387 v_0_cb_count)) (<= 1 a!78) a!396)
                  0
                  v_0_cb_length_01))
      (a!615 (ite (and (not (>= a!398 v_0_cb_count)) (<= 1 a!78) a!407)
                  0
                  v_0_cb_length_02))
      (a!616 (ite (and (not (>= a!409 v_0_cb_count)) (<= 1 a!78) a!418)
                  0
                  v_0_cb_length_03))
      (a!617 (ite (and (not (>= a!420 v_0_cb_count)) (<= 1 a!78) a!429)
                  0
                  v_0_cb_length_04))
      (a!618 (ite (and (not (>= a!431 v_0_cb_count)) (<= 1 a!78) a!440)
                  0
                  v_0_cb_length_05))
      (a!619 (ite (and (not (>= a!442 v_0_cb_count)) (<= 1 a!78) a!451)
                  0
                  v_0_cb_length_06))
      (a!620 (ite (and (not (>= a!453 v_0_cb_count)) (<= 1 a!78) a!462)
                  0
                  v_0_cb_length_07))
      (a!621 (ite (and (not (>= a!464 v_0_cb_count)) (<= 1 a!78) a!473)
                  0
                  v_0_cb_length_08))
      (a!622 (ite (and (not (>= a!475 v_0_cb_count)) (<= 1 a!78) a!484)
                  0
                  v_0_cb_length_09))
      (a!623 (ite (and (not (>= a!486 v_0_cb_count)) (<= 1 a!78) a!495)
                  0
                  v_0_cb_length_10))
      (a!624 (ite (and (not (>= a!497 v_0_cb_count)) (<= 1 a!78) a!506)
                  0
                  v_0_cb_length_11))
      (a!625 (ite (and (not (>= a!508 v_0_cb_count)) (<= 1 a!78) a!517)
                  0
                  v_0_cb_length_12))
      (a!626 (ite (and (not (>= a!519 v_0_cb_count)) (<= 1 a!78) a!528)
                  0
                  v_0_cb_length_13))
      (a!627 (ite (and (not (>= a!530 v_0_cb_count)) (<= 1 a!78) a!539)
                  0
                  v_0_cb_length_14))
      (a!628 (ite (and (not (>= a!541 v_0_cb_count)) (<= 1 a!78) a!550)
                  0
                  v_0_cb_length_15))
      (a!635 (= v_1_cb_done_00
                (and (not (>= a!376 v_0_cb_count)) (<= 1 a!78) a!385)))
      (a!637 (= v_1_cb_done_01
                (and (not (>= a!387 v_0_cb_count)) (<= 1 a!78) a!396)))
      (a!639 (= v_1_cb_done_02
                (and (not (>= a!398 v_0_cb_count)) (<= 1 a!78) a!407)))
      (a!641 (= v_1_cb_done_03
                (and (not (>= a!409 v_0_cb_count)) (<= 1 a!78) a!418)))
      (a!643 (= v_1_cb_done_04
                (and (not (>= a!420 v_0_cb_count)) (<= 1 a!78) a!429)))
      (a!645 (= v_1_cb_done_05
                (and (not (>= a!431 v_0_cb_count)) (<= 1 a!78) a!440)))
      (a!647 (= v_1_cb_done_06
                (and (not (>= a!442 v_0_cb_count)) (<= 1 a!78) a!451)))
      (a!649 (= v_1_cb_done_07
                (and (not (>= a!453 v_0_cb_count)) (<= 1 a!78) a!462)))
      (a!651 (= v_1_cb_done_08
                (and (not (>= a!464 v_0_cb_count)) (<= 1 a!78) a!473)))
      (a!653 (= v_1_cb_done_09
                (and (not (>= a!475 v_0_cb_count)) (<= 1 a!78) a!484)))
      (a!655 (= v_1_cb_done_10
                (and (not (>= a!486 v_0_cb_count)) (<= 1 a!78) a!495)))
      (a!657 (= v_1_cb_done_11
                (and (not (>= a!497 v_0_cb_count)) (<= 1 a!78) a!506)))
      (a!659 (= v_1_cb_done_12
                (and (not (>= a!508 v_0_cb_count)) (<= 1 a!78) a!517)))
      (a!661 (= v_1_cb_done_13
                (and (not (>= a!519 v_0_cb_count)) (<= 1 a!78) a!528)))
      (a!663 (= v_1_cb_done_14
                (and (not (>= a!530 v_0_cb_count)) (<= 1 a!78) a!539)))
      (a!665 (= v_1_cb_done_15
                (and (not (>= a!541 v_0_cb_count)) (<= 1 a!78) a!550)))
      (a!669 (and v_0_persist_active
                  (not a!64)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (not a!668)))
      (a!988 (ite (or a!987 (= 0 a!986) (not (= a!971 v_0_snd_una)))
                  0
                  (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks)))
      (a!991 (and (not (or a!987 (= 0 a!986)))
                  (or (and a!989 v_0_fr_active) a!990)))
      (a!996 (or v_0_fr_active
                 (not (and (<= 1 a!995)
                           (not v_0_persist_active)
                           (<= 1 v_0_snd_wnd)))))
      (a!997 (ite (>= v_0_cc_cwnd v_0_cc_ssthresh)
                  (ite (>= (+ v_0_cc_ca_credit a!995) v_0_cc_cwnd) 4 0)
                  (ite (>= 4 a!995) a!995 4)))
      (a!1001 (ite a!1000
                   a!986
                   (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                        input_0_net.ack_window
                        v_0_snd_wnd)))
      (a!1017 (ite v_0_rtt_measured
                   (+ (* (/ 3.0 4.0) v_0_rttvar_ms)
                      (* (/ 1.0 4.0) (ite a!1013 a!1016 v_0_rtt_error_ms)))
                   (* (/ 1.0 2.0) a!1014)))
      (a!1047 (ite a!1044
                   a!1046
                   (mod (+ v_0_rtt_end (* (- 1) a!971)) 4294967296)))
      (a!1049 (ite (or a!1041 a!987)
                   0
                   (ite (and v_0_rtt_active
                             a!959
                             (<= 1 a!964)
                             (<= a!964 v_0_rtx_buf)
                             a!1048)
                        (+ a!1012 (* (- 1) a!964))
                        v_0_rtt_remaining)))
      (a!1067 (ite (= 1 a!964)
                   v_0_tx_time_01
                   (ite (= 2 a!964)
                        v_0_tx_time_02
                        (ite (= 3 a!964) v_0_tx_time_03 a!1066))))
      (a!1076 (ite a!1062
                   (ite (= 1 a!964)
                        v_0_tx_time_02
                        (ite (= 2 a!964) v_0_tx_time_03 a!1075))
                   v_0_tx_time_01))
      (a!1085 (ite (>= 2 a!986)
                   0
                   (ite a!1062
                        (ite (= 1 a!964) v_0_tx_time_03 a!1084)
                        v_0_tx_time_02)))
      (a!1173 (and (>= v_0_cc_cwnd v_0_cc_ssthresh)
                   (not (>= (+ v_0_cc_ca_credit a!995) v_0_cc_cwnd))))
      (a!1192 (ite a!1187
                   v_0_cc_rto_11
                   (ite a!1188
                        v_0_cc_rto_12
                        (ite a!1189
                             v_0_cc_rto_13
                             (ite a!1190 v_0_cc_rto_14 a!1191)))))
      (a!1197 (ite a!1186
                   v_0_cc_rto_11
                   (ite a!1187
                        v_0_cc_rto_12
                        (ite a!1188
                             v_0_cc_rto_13
                             (ite a!1189 v_0_cc_rto_14 a!1196)))))
      (a!1202 (ite a!1185
                   v_0_cc_rto_11
                   (ite a!1186
                        v_0_cc_rto_12
                        (ite a!1187
                             v_0_cc_rto_13
                             (ite a!1188 v_0_cc_rto_14 a!1201)))))
      (a!1207 (ite a!1184
                   v_0_cc_rto_11
                   (ite a!1185
                        v_0_cc_rto_12
                        (ite a!1186
                             v_0_cc_rto_13
                             (ite a!1187 v_0_cc_rto_14 a!1206)))))
      (a!1212 (ite a!1183
                   v_0_cc_rto_11
                   (ite a!1184
                        v_0_cc_rto_12
                        (ite a!1185
                             v_0_cc_rto_13
                             (ite a!1186 v_0_cc_rto_14 a!1211)))))
      (a!1216 (ite a!1182
                   v_0_cc_rto_11
                   (ite a!1183
                        v_0_cc_rto_12
                        (ite a!1184
                             v_0_cc_rto_13
                             (ite a!1185 v_0_cc_rto_14 a!1215)))))
      (a!1220 (ite a!1181
                   v_0_cc_rto_11
                   (ite a!1182
                        v_0_cc_rto_12
                        (ite a!1183
                             v_0_cc_rto_13
                             (ite a!1184 v_0_cc_rto_14 a!1219)))))
      (a!1224 (ite a!1180
                   v_0_cc_rto_11
                   (ite a!1181
                        v_0_cc_rto_12
                        (ite a!1182
                             v_0_cc_rto_13
                             (ite a!1183 v_0_cc_rto_14 a!1223)))))
      (a!1228 (ite a!1179
                   v_0_cc_rto_11
                   (ite a!1180
                        v_0_cc_rto_12
                        (ite a!1181
                             v_0_cc_rto_13
                             (ite a!1182 v_0_cc_rto_14 a!1227)))))
      (a!1231 (ite a!1178
                   v_0_cc_rto_11
                   (ite a!1179
                        v_0_cc_rto_12
                        (ite a!1180
                             v_0_cc_rto_13
                             (ite a!1181 v_0_cc_rto_14 a!1230)))))
      (a!1234 (ite a!1177
                   v_0_cc_rto_11
                   (ite a!1178
                        v_0_cc_rto_12
                        (ite a!1179
                             v_0_cc_rto_13
                             (ite a!1180 v_0_cc_rto_14 a!1233)))))
      (a!1237 (ite a!1176
                   v_0_cc_rto_11
                   (ite a!1177
                        v_0_cc_rto_12
                        (ite a!1178
                             v_0_cc_rto_13
                             (ite a!1179 v_0_cc_rto_14 a!1236)))))
      (a!1240 (and (not (>= 12 a!986))
                   (ite a!1176
                        v_0_cc_rto_12
                        (ite a!1177
                             v_0_cc_rto_13
                             (ite a!1178 v_0_cc_rto_14 a!1239)))))
      (a!1242 (= v_1_cc_rto_13
                 (and (not (>= 13 a!986))
                      (ite a!1176
                           v_0_cc_rto_13
                           (ite a!1177 v_0_cc_rto_14 a!1241)))))
      (a!1244 (= v_1_cc_rto_14
                 (and (not (>= 14 a!986)) (ite a!1176 v_0_cc_rto_14 a!1243))))
      (a!1245 (= v_1_cc_rto_15 (and (not (>= 15 a!986)) a!1176 v_0_cc_rto_15)))
      (a!1254 (or (and v_0_fr_active (not (= a!971 v_0_snd_una)))
                  a!987
                  a!990
                  (= 0 a!986)
                  (not (= a!971 v_0_snd_una))))
      (a!1262 (ite a!1259
                   a!1261
                   (mod (+ a!971 (* (- 1) v_0_cb_end_00)) 4294967296)))
      (a!1268 (ite a!1265
                   a!1267
                   (mod (+ a!971 (* (- 1) v_0_cb_end_01)) 4294967296)))
      (a!1274 (ite a!1271
                   a!1273
                   (mod (+ a!971 (* (- 1) v_0_cb_end_02)) 4294967296)))
      (a!1280 (ite a!1277
                   a!1279
                   (mod (+ a!971 (* (- 1) v_0_cb_end_03)) 4294967296)))
      (a!1286 (ite a!1283
                   a!1285
                   (mod (+ a!971 (* (- 1) v_0_cb_end_04)) 4294967296)))
      (a!1292 (ite a!1289
                   a!1291
                   (mod (+ a!971 (* (- 1) v_0_cb_end_05)) 4294967296)))
      (a!1298 (ite a!1295
                   a!1297
                   (mod (+ a!971 (* (- 1) v_0_cb_end_06)) 4294967296)))
      (a!1304 (ite a!1301
                   a!1303
                   (mod (+ a!971 (* (- 1) v_0_cb_end_07)) 4294967296)))
      (a!1310 (ite a!1307
                   a!1309
                   (mod (+ a!971 (* (- 1) v_0_cb_end_08)) 4294967296)))
      (a!1316 (ite a!1313
                   a!1315
                   (mod (+ a!971 (* (- 1) v_0_cb_end_09)) 4294967296)))
      (a!1322 (ite a!1319
                   a!1321
                   (mod (+ a!971 (* (- 1) v_0_cb_end_10)) 4294967296)))
      (a!1328 (ite a!1325
                   a!1327
                   (mod (+ a!971 (* (- 1) v_0_cb_end_11)) 4294967296)))
      (a!1334 (ite a!1331
                   a!1333
                   (mod (+ a!971 (* (- 1) v_0_cb_end_12)) 4294967296)))
      (a!1340 (ite a!1337
                   a!1339
                   (mod (+ a!971 (* (- 1) v_0_cb_end_13)) 4294967296)))
      (a!1346 (ite a!1343
                   a!1345
                   (mod (+ a!971 (* (- 1) v_0_cb_end_14)) 4294967296)))
      (a!1352 (ite a!1349
                   a!1351
                   (mod (+ a!971 (* (- 1) v_0_cb_end_15)) 4294967296)))
      (a!1405 (and v_0_persist_active
                   (not a!987)
                   (<= 1 a!986)
                   (not (and (not a!987) (or a!1403 a!1404)))))
      (a!1407 (= active_1_persist
                 (and a!983
                      (not v_0_fin_sent)
                      (<= 1 (+ a!986 v_0_snd_buf))
                      (>= 1 a!986)
                      (or v_0_persist_active (= 0 a!986))
                      (or active_0_persist a!1169)))))
(let ((a!82 (+ (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)
               (* (- 1) (ite a!40 a!63 v_0_rtx_buf))))
      (a!88 (<= a!85 (ite a!87 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!106 (* (- 1.0)
                (ite (<= (ite a!100 a!105 v_0_rttvar_ms) (/ 1.0 4.0))
                     1.0
                     (* 4.0 (ite a!100 a!105 v_0_rttvar_ms)))))
      (a!111 (+ 8 (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)))
      (a!112 (+ 8
                (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)
                (* (- 1) (ite a!40 a!63 v_0_rtx_buf))))
      (a!262 (= v_1_cc_cwnd
                (ite a!70 (+ 12 (ite a!70 a!76 v_0_cc_ssthresh)) a!81)))
      (a!298 (ite a!280
                  v_0_cc_rto_07
                  (ite a!282
                       v_0_cc_rto_08
                       (ite a!284 v_0_cc_rto_09 (ite a!286 v_0_cc_rto_10 a!297)))))
      (a!304 (ite a!278
                  v_0_cc_rto_07
                  (ite a!280
                       v_0_cc_rto_08
                       (ite a!282 v_0_cc_rto_09 (ite a!284 v_0_cc_rto_10 a!303)))))
      (a!310 (ite a!276
                  v_0_cc_rto_07
                  (ite a!278
                       v_0_cc_rto_08
                       (ite a!280 v_0_cc_rto_09 (ite a!282 v_0_cc_rto_10 a!309)))))
      (a!316 (ite a!274
                  v_0_cc_rto_07
                  (ite a!276
                       v_0_cc_rto_08
                       (ite a!278 v_0_cc_rto_09 (ite a!280 v_0_cc_rto_10 a!315)))))
      (a!321 (ite a!272
                  v_0_cc_rto_07
                  (ite a!274
                       v_0_cc_rto_08
                       (ite a!276 v_0_cc_rto_09 (ite a!278 v_0_cc_rto_10 a!320)))))
      (a!326 (ite a!270
                  v_0_cc_rto_07
                  (ite a!272
                       v_0_cc_rto_08
                       (ite a!274 v_0_cc_rto_09 (ite a!276 v_0_cc_rto_10 a!325)))))
      (a!331 (ite a!268
                  v_0_cc_rto_07
                  (ite a!270
                       v_0_cc_rto_08
                       (ite a!272 v_0_cc_rto_09 (ite a!274 v_0_cc_rto_10 a!330)))))
      (a!336 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_07
                  (ite a!268
                       v_0_cc_rto_08
                       (ite a!270 v_0_cc_rto_09 (ite a!272 v_0_cc_rto_10 a!335)))))
      (a!340 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_08
                  (ite a!268 v_0_cc_rto_09 (ite a!270 v_0_cc_rto_10 a!339))))
      (a!344 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_09
                  (ite a!268 v_0_cc_rto_10 a!343)))
      (a!348 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_10
                  a!347))
      (a!352 (and (not (>= 11 (ite a!40 a!63 v_0_rtx_buf))) a!351))
      (a!355 (and (not (>= 12 (ite a!40 a!63 v_0_rtx_buf))) a!354))
      (a!358 (and (not (>= 13 (ite a!40 a!63 v_0_rtx_buf))) a!357))
      (a!361 (and (not (>= 14 (ite a!40 a!63 v_0_rtx_buf))) a!360))
      (a!552 (+ v_0_cb_head
                a!386
                a!397
                a!408
                a!419
                a!430
                a!441
                a!452
                a!463
                a!474
                a!485
                a!496
                a!507
                a!518
                a!529
                a!540
                a!551))
      (a!998 (ite (and v_0_fr_active (not (= a!971 v_0_snd_una)))
                  (ite a!990 a!994 v_0_cc_ssthresh)
                  (+ v_0_cc_cwnd (ite a!996 0 a!997))))
      (a!1002 (<= 1 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1003 (<= 0 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1018 (* (- 1.0)
                 (ite (<= (ite a!1013 a!1017 v_0_rttvar_ms) (/ 1.0 4.0))
                      1.0
                      (* 4.0 (ite a!1013 a!1017 v_0_rttvar_ms)))))
      (a!1069 (<= 2 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1078 (<= 3 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1087 (<= 4 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1095 (<= 5 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1103 (<= 6 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1111 (<= 7 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1118 (<= 8 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1125 (<= 9 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1132 (<= 10 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1138 (<= 11 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1144 (<= 12 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1150 (<= 13 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1155 (<= 14 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1160 (<= 15 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1165 (<= 16 (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1174 (ite a!1172
                   0
                   (ite (and (<= 1 a!995)
                             (not v_0_persist_active)
                             (<= 1 v_0_snd_wnd))
                        (ite a!1173 (+ v_0_cc_ca_credit a!995) 0)
                        v_0_cc_ca_credit)))
      (a!1193 (ite a!1183
                   v_0_cc_rto_07
                   (ite a!1184
                        v_0_cc_rto_08
                        (ite a!1185
                             v_0_cc_rto_09
                             (ite a!1186 v_0_cc_rto_10 a!1192)))))
      (a!1198 (ite a!1182
                   v_0_cc_rto_07
                   (ite a!1183
                        v_0_cc_rto_08
                        (ite a!1184
                             v_0_cc_rto_09
                             (ite a!1185 v_0_cc_rto_10 a!1197)))))
      (a!1203 (ite a!1181
                   v_0_cc_rto_07
                   (ite a!1182
                        v_0_cc_rto_08
                        (ite a!1183
                             v_0_cc_rto_09
                             (ite a!1184 v_0_cc_rto_10 a!1202)))))
      (a!1208 (ite a!1180
                   v_0_cc_rto_07
                   (ite a!1181
                        v_0_cc_rto_08
                        (ite a!1182
                             v_0_cc_rto_09
                             (ite a!1183 v_0_cc_rto_10 a!1207)))))
      (a!1213 (ite a!1179
                   v_0_cc_rto_07
                   (ite a!1180
                        v_0_cc_rto_08
                        (ite a!1181
                             v_0_cc_rto_09
                             (ite a!1182 v_0_cc_rto_10 a!1212)))))
      (a!1217 (ite a!1178
                   v_0_cc_rto_07
                   (ite a!1179
                        v_0_cc_rto_08
                        (ite a!1180
                             v_0_cc_rto_09
                             (ite a!1181 v_0_cc_rto_10 a!1216)))))
      (a!1221 (ite a!1177
                   v_0_cc_rto_07
                   (ite a!1178
                        v_0_cc_rto_08
                        (ite a!1179
                             v_0_cc_rto_09
                             (ite a!1180 v_0_cc_rto_10 a!1220)))))
      (a!1225 (ite a!1176
                   v_0_cc_rto_07
                   (ite a!1177
                        v_0_cc_rto_08
                        (ite a!1178
                             v_0_cc_rto_09
                             (ite a!1179 v_0_cc_rto_10 a!1224)))))
      (a!1229 (and (not (>= 8 a!986))
                   (ite a!1176
                        v_0_cc_rto_08
                        (ite a!1177
                             v_0_cc_rto_09
                             (ite a!1178 v_0_cc_rto_10 a!1228)))))
      (a!1232 (= v_1_cc_rto_09
                 (and (not (>= 9 a!986))
                      (ite a!1176
                           v_0_cc_rto_09
                           (ite a!1177 v_0_cc_rto_10 a!1231)))))
      (a!1235 (= v_1_cc_rto_10
                 (and (not (>= 10 a!986)) (ite a!1176 v_0_cc_rto_10 a!1234))))
      (a!1238 (= v_1_cc_rto_11 (and (not (>= 11 a!986)) a!1237)))
      (a!1247 (= v_1_fr_emit_count (ite a!990 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1263 (and (not (>= 7 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1262))))
      (a!1269 (and (not (>= 8 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1268))))
      (a!1275 (and (not (>= 9 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1274))))
      (a!1281 (and (not (>= 10 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1280))))
      (a!1287 (and (not (>= 11 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1286))))
      (a!1293 (and (not (>= 12 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1292))))
      (a!1299 (and (not (>= 13 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1298))))
      (a!1305 (and (not (>= 14 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1304))))
      (a!1311 (and (not (>= 15 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1310))))
      (a!1317 (and (not (>= 0 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1316))))
      (a!1323 (and (not (>= 1 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1322))))
      (a!1329 (and (not (>= 2 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1328))))
      (a!1335 (and (not (>= 3 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1334))))
      (a!1341 (and (not (>= 4 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1340))))
      (a!1347 (and (not (>= 5 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1346))))
      (a!1353 (and (not (>= 6 v_0_cb_count))
                   (<= 1 a!995)
                   (not (<= 2147483648 a!1352))))
      (a!1406 (= active_1_rtx (or (and (not a!987) (or a!1403 a!1404)) a!1405))))
(let ((a!89 (ite a!88 a!85 (ite a!87 (ite (<= 4 a!83) 4 a!83) 0)))
      (a!107 (to_int (+ (* (- 1.0) (ite a!100 a!102 v_0_srtt_ms)) a!106)))
      (a!113 (<= v_0_snd_buf
                 (ite (<= (ite a!60 input_0_net.ack_window v_0_snd_wnd) a!111)
                      a!73
                      a!112)))
      (a!148 (<= (- 999.0) (+ (* (- 1.0) (ite a!100 a!102 v_0_srtt_ms)) a!106)))
      (a!299 (ite a!272
                  v_0_cc_rto_03
                  (ite a!274
                       v_0_cc_rto_04
                       (ite a!276 v_0_cc_rto_05 (ite a!278 v_0_cc_rto_06 a!298)))))
      (a!305 (ite a!270
                  v_0_cc_rto_03
                  (ite a!272
                       v_0_cc_rto_04
                       (ite a!274 v_0_cc_rto_05 (ite a!276 v_0_cc_rto_06 a!304)))))
      (a!311 (ite a!268
                  v_0_cc_rto_03
                  (ite a!270
                       v_0_cc_rto_04
                       (ite a!272 v_0_cc_rto_05 (ite a!274 v_0_cc_rto_06 a!310)))))
      (a!317 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_03
                  (ite a!268
                       v_0_cc_rto_04
                       (ite a!270 v_0_cc_rto_05 (ite a!272 v_0_cc_rto_06 a!316)))))
      (a!322 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_04
                  (ite a!268 v_0_cc_rto_05 (ite a!270 v_0_cc_rto_06 a!321))))
      (a!327 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_05
                  (ite a!268 v_0_cc_rto_06 a!326)))
      (a!332 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_06
                  a!331))
      (a!337 (and (not (>= 7 (ite a!40 a!63 v_0_rtx_buf))) a!336))
      (a!341 (and (not (>= 8 (ite a!40 a!63 v_0_rtx_buf))) a!340))
      (a!345 (and (not (>= 9 (ite a!40 a!63 v_0_rtx_buf))) a!344))
      (a!349 (and (not (>= 10 (ite a!40 a!63 v_0_rtx_buf))) a!348))
      (a!999 (ite a!990
                  (+ 12 (ite a!990 a!994 v_0_cc_ssthresh))
                  (ite a!77 (+ 4 v_0_cc_cwnd (ite a!996 0 a!997)) a!998)))
      (a!1004 (and a!1003
                   (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (not v_0_fr_active)
                   (= (ite a!66 (+ 1 v_0_fr_dupacks) v_0_fr_dupacks) 3)
                   (= a!971 v_0_snd_una)))
      (a!1019 (* (- 1) (to_int (+ (* (- 1.0) a!1015) a!1018))))
      (a!1194 (ite a!1179
                   v_0_cc_rto_03
                   (ite a!1180
                        v_0_cc_rto_04
                        (ite a!1181
                             v_0_cc_rto_05
                             (ite a!1182 v_0_cc_rto_06 a!1193)))))
      (a!1199 (ite a!1178
                   v_0_cc_rto_03
                   (ite a!1179
                        v_0_cc_rto_04
                        (ite a!1180
                             v_0_cc_rto_05
                             (ite a!1181 v_0_cc_rto_06 a!1198)))))
      (a!1204 (ite a!1177
                   v_0_cc_rto_03
                   (ite a!1178
                        v_0_cc_rto_04
                        (ite a!1179
                             v_0_cc_rto_05
                             (ite a!1180 v_0_cc_rto_06 a!1203)))))
      (a!1209 (ite a!1176
                   v_0_cc_rto_03
                   (ite a!1177
                        v_0_cc_rto_04
                        (ite a!1178
                             v_0_cc_rto_05
                             (ite a!1179 v_0_cc_rto_06 a!1208)))))
      (a!1214 (and (not (>= 4 a!986))
                   (ite a!1176
                        v_0_cc_rto_04
                        (ite a!1177
                             v_0_cc_rto_05
                             (ite a!1178 v_0_cc_rto_06 a!1213)))))
      (a!1218 (= v_1_cc_rto_05
                 (and (not (>= 5 a!986))
                      (ite a!1176
                           v_0_cc_rto_05
                           (ite a!1177 v_0_cc_rto_06 a!1217)))))
      (a!1222 (= v_1_cc_rto_06
                 (and (not (>= 6 a!986)) (ite a!1176 v_0_cc_rto_06 a!1221))))
      (a!1226 (= v_1_cc_rto_07 (and (not (>= 7 a!986)) a!1225)))
      (a!1354 (+ (ite a!1263 1 0)
                 (ite a!1269 1 0)
                 (ite a!1275 1 0)
                 (ite a!1281 1 0)
                 (ite a!1287 1 0)
                 (ite a!1293 1 0)
                 (ite a!1299 1 0)
                 (ite a!1305 1 0)
                 (ite a!1311 1 0)
                 (ite a!1317 1 0)
                 (ite a!1323 1 0)
                 (ite a!1329 1 0)
                 (ite a!1335 1 0)
                 (ite a!1341 1 0)
                 (ite a!1347 1 0)
                 (ite a!1353 1 0))))
(let ((a!90 (* (- 1) (ite (and a!84 (<= 1 a!89)) now_1 v_0_idle_last_data_ms)))
      (a!108 (ite (<= a!107 (- 1000)) (* (- 1) a!107) 1000))
      (a!114 (ite a!113
                  v_0_snd_buf
                  (ite (<= (ite a!60 input_0_net.ack_window v_0_snd_wnd) a!111)
                       a!73
                       a!112)))
      (a!139 (and (not a!64)
                  v_0_rtt_active
                  (not a!126)
                  (<= a!138 (+ (- 1) a!89))))
      (a!149 (<= 60000 (ite a!148 1000 (* (- 1) a!107))))
      (a!300 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_00
                  (ite a!268 v_0_cc_rto_01 (ite a!270 v_0_cc_rto_02 a!299))))
      (a!306 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_01
                  (ite a!268 v_0_cc_rto_02 a!305)))
      (a!312 (ite (or a!266
                      (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_una))
                  v_0_cc_rto_02
                  a!311))
      (a!318 (and (not (>= 3 (ite a!40 a!63 v_0_rtx_buf))) a!317))
      (a!323 (and (not (>= 4 (ite a!40 a!63 v_0_rtx_buf))) a!322))
      (a!328 (and (not (>= 5 (ite a!40 a!63 v_0_rtx_buf))) a!327))
      (a!333 (and (not (>= 6 (ite a!40 a!63 v_0_rtx_buf))) a!332))
      (a!555 (and a!84
                  (<= 1 a!89)
                  (= (ite a!40 input_0_net.ack_ack v_0_snd_una) v_0_snd_nxt)))
      (a!630 (and (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                      (- 4294967296))
                  (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                     8589934592)))
      (a!631 (ite (>= (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                      4294967296)
                  (- (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                     4294967296)
                  (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)))
      (a!1005 (<= (ite (<= a!986 0) 0 a!986)
                  (ite a!1004 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1020 (ite (<= (- 999.0) (+ (* (- 1.0) a!1015) a!1018)) 1000 a!1019))
      (a!1023 (<= (ite (and a!959 (<= a!964 v_0_rtx_buf) a!982)
                       input_0_net.ack_window
                       v_0_snd_wnd)
                  (+ 8 a!999)))
      (a!1195 (and (not (>= 0 a!986))
                   (ite a!1176
                        v_0_cc_rto_00
                        (ite a!1177
                             v_0_cc_rto_01
                             (ite a!1178 v_0_cc_rto_02 a!1194)))))
      (a!1200 (= v_1_cc_rto_01
                 (and (not (>= 1 a!986))
                      (ite a!1176
                           v_0_cc_rto_01
                           (ite a!1177 v_0_cc_rto_02 a!1199)))))
      (a!1205 (= v_1_cc_rto_02
                 (and (not (>= 2 a!986)) (ite a!1176 v_0_cc_rto_02 a!1204))))
      (a!1210 (= v_1_cc_rto_03 (and (not (>= 3 a!986)) a!1209))))
(let ((a!109 (<= (+ now_1 a!90)
                 (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_ms)))
      (a!117 (= v_1_rto_ms
                (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_ms)))
      (a!140 (ite a!84
                  (or (and (not a!64) (not a!126) v_0_rtt_ambiguous) a!139)
                  (and (not a!64) (not a!126) v_0_rtt_ambiguous)))
      (a!147 (= v_1_rto_base_ms
                (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_base_ms)))
      (a!150 (ite a!149 60000 (ite a!148 1000 (* (- 1) a!107))))
      (a!260 (ite a!259
                  (ite a!100 (ite (<= 60000 a!108) 60000 a!108) v_0_rto_ms)
                  v_0_persist_interval_ms))
      (a!301 (and (not (>= 0 (ite a!40 a!63 v_0_rtx_buf))) a!300))
      (a!307 (and (not (>= 1 (ite a!40 a!63 v_0_rtx_buf))) a!306))
      (a!313 (and (not (>= 2 (ite a!40 a!63 v_0_rtx_buf))) a!312))
      (a!632 (ite (< (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89) 0)
                  (+ (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                     4294967296)
                  a!631))
      (a!1006 (ite a!1005
                   (ite (<= a!986 0) 0 a!986)
                   (ite a!1004 (ite (<= 4 a!1001) 4 a!1001) 0)))
      (a!1024 (<= v_0_snd_buf (ite a!1023 a!992 (+ 8 a!999 (* (- 1) a!986)))))
      (a!1030 (= v_1_rto_ms
                 (ite a!1013 (ite (<= 60000 a!1020) 60000 a!1020) v_0_rto_ms)))
      (a!1059 (= v_1_rto_base_ms
                 (ite a!1013
                      (ite (<= 60000 a!1020) 60000 a!1020)
                      v_0_rto_base_ms)))
      (a!1170 (ite a!1169
                   (ite a!1013 (ite (<= 60000 a!1020) 60000 a!1020) v_0_rto_ms)
                   v_0_persist_interval_ms))
      (a!1408 (+ now_1
                 (ite a!1013 (ite (<= 60000 a!1020) 60000 a!1020) v_0_rto_ms))))
(let ((a!110 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  a!109))
      (a!141 (or a!140 (not (and (not a!64) v_0_rtt_active (not a!126)))))
      (a!261 (= v_1_persist_deadline_ms
                (ite a!64 (ite a!259 (+ now_1 a!260) v_0_persist_deadline_ms) 0)))
      (a!633 (ite a!630
                  a!632
                  (mod (+ (ite a!40 input_0_net.ack_ack v_0_snd_una) a!89)
                       4294967296)))
      (a!671 (= due_1_rtx
                (ite (or a!669 a!667)
                     (+ now_1 (ite a!100 a!150 v_0_rto_ms))
                     due_0_rtx)))
      (a!1007 (* (- 1)
                 (ite (and a!1002 (<= 1 a!1006)) now_1 v_0_idle_last_data_ms)))
      (a!1025 (ite a!1024
                   v_0_snd_buf
                   (ite a!1023 a!992 (+ 8 a!999 (* (- 1) a!986)))))
      (a!1050 (and (not a!987)
                   v_0_rtt_active
                   (not a!1041)
                   (<= (+ a!1047 (* (- 1) a!1049)) (+ (- 1) a!1006))))
      (a!1171 (= v_1_persist_deadline_ms
                 (ite a!987
                      (ite a!1169 (+ now_1 a!1170) v_0_persist_deadline_ms)
                      0)))
      (a!1357 (ite (and a!1002 (<= 1 a!1006) (= a!971 v_0_snd_nxt)) 1 0))
      (a!1399 (and (>= (+ a!971 a!1006) (- 4294967296))
                   (not (<= 8589934592 (+ a!971 a!1006)))))
      (a!1400 (ite (<= 0 (+ a!971 a!1006))
                   (ite (>= (+ a!971 a!1006) 4294967296)
                        (+ (- 4294967296) a!971 a!1006)
                        (+ a!971 a!1006))
                   (+ 4294967296 a!971 a!1006))))
(let ((a!115 (+ v_0_snd_nxt (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take)))
      (a!118 (<= 0 (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take)))
      (a!124 (= v_1_take (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take)))
      (a!127 (= v_1_rtt_active
                (or a!110 (and (not a!64) v_0_rtt_active (not a!126)))))
      (a!142 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  a!109
                  a!141))
      (a!370 (= v_1_lt_take (ite a!110 (ite (<= 4 a!114) 4 a!114) 0)))
      (a!372 (+ (ite a!371 0 v_0_lt_epoch_bytes)
                (ite a!110 (ite (<= 4 a!114) 4 a!114) 0)))
      (a!1021 (<= (+ now_1 a!1007)
                  (ite a!1013 (ite (<= 60000 a!1020) 60000 a!1020) v_0_rto_ms)))
      (a!1051 (ite a!1002
                   (or (and (not a!987) (not a!1041) v_0_rtt_ambiguous) a!1050)
                   (and (not a!987) (not a!1041) v_0_rtt_ambiguous)))
      (a!1401 (ite (and a!1002 (<= 1 a!1006) (= a!971 v_0_snd_nxt))
                   (ite a!1399 a!1400 (mod (+ a!971 a!1006) 4294967296))
                   0)))
(let ((a!116 (ite (and (>= a!115 (- 4294967296)) (< a!115 8589934592))
                  (ite (< a!115 0)
                       (+ a!115 4294967296)
                       (ite (>= a!115 4294967296) (- a!115 4294967296) a!115))
                  (mod a!115 4294967296)))
      (a!119 (ite a!118 (ite a!110 (ite (<= 4 a!114) 4 a!114) v_0_take) 0))
      (a!143 (= v_1_rtt_ambiguous (ite a!110 (and (not a!142) a!140) a!140)))
      (a!1022 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021))
      (a!1052 (or (not (and (not a!987) v_0_rtt_active (not a!1041))) a!1051)))
(let ((a!120 (ite (<= v_0_snd_buf a!119) 0 (+ v_0_snd_buf (* (- 1) a!119))))
      (a!122 (ite (<= (ite (<= v_0_snd_buf 0) 0 v_0_snd_buf) a!119)
                  (ite (<= v_0_snd_buf 0) 0 v_0_snd_buf)
                  a!119))
      (a!1026 (+ v_0_snd_nxt (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) v_0_take)))
      (a!1027 (+ (- 4294967296)
                 v_0_snd_nxt
                 (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) v_0_take)))
      (a!1028 (+ 4294967296
                 v_0_snd_nxt
                 (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) v_0_take)))
      (a!1031 (<= 0 (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) v_0_take)))
      (a!1039 (= v_1_take (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) v_0_take)))
      (a!1042 (= v_1_rtt_active
                 (or (and (not a!987) v_0_rtt_active (not a!1041)) a!1022)))
      (a!1053 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1052))
      (a!1253 (= v_1_lt_take (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) 0)))
      (a!1255 (+ (ite a!1254 0 v_0_lt_epoch_bytes)
                 (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) 0))))
(let ((a!121 (ite (<= a!120 (ite (<= 0 v_0_snd_buf) v_0_snd_buf 0))
                  a!120
                  (ite (<= 0 v_0_snd_buf) v_0_snd_buf 0)))
      (a!123 (ite a!110
                  (+ (ite a!40 a!63 v_0_rtx_buf) a!122)
                  (ite a!40 a!63 v_0_rtx_buf)))
      (a!144 (ite (< (+ v_0_snd_nxt a!122) 0)
                  (+ (+ v_0_snd_nxt a!122) 4294967296)
                  (ite (>= (+ v_0_snd_nxt a!122) 4294967296)
                       (- (+ v_0_snd_nxt a!122) 4294967296)
                       (+ v_0_snd_nxt a!122))))
      (a!146 (= v_1_rtt_remaining
                (ite a!142
                     a!122
                     (ite (or a!64 a!126) 0 (ite a!137 a!136 v_0_rtt_remaining)))))
      (a!151 (and (>= 0 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!175 (and (>= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 2 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!182 (and (>= 2 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 3 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!189 (and (>= 3 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 4 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!196 (and (>= 4 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 5 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!203 (and (>= 5 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 6 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!209 (and (>= 6 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 7 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!214 (and (>= 7 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 8 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!221 (and (>= 8 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 9 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!227 (and (>= 9 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 10 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!232 (and (>= 10 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 11 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!237 (and (>= 11 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 12 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!242 (and (>= 12 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 13 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!247 (and (>= 13 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 14 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!251 (and (>= 14 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 15 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!255 (and (>= 15 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 16 (+ (ite a!40 a!63 v_0_rtx_buf) a!122))))
      (a!365 (ite a!110
                  (or v_0_idle_data_valid (and a!84 (<= 1 a!89)) (<= 1 a!122))
                  (or v_0_idle_data_valid (and a!84 (<= 1 a!89)))))
      (a!366 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                  (or (and a!84 (<= 1 a!89)) (<= 1 a!122))))
      (a!368 (ite a!110
                  (or (and a!84 (<= 1 a!89)) (<= 1 a!122))
                  (and a!84 (<= 1 a!89))))
      (a!556 (and (<= 1 v_0_rtx_buf)
                  (not v_0_persist_active)
                  v_0_fr_window_valid
                  (<= 1 v_0_snd_wnd)
                  (= input_0_net.ack_ack v_0_snd_una)
                  (= input_0_net.ack_window v_0_fr_last_window)
                  (<= 1 input_0_net.ack_window)
                  a!67
                  a!68
                  (not a!72)
                  (not v_0_fin_sent)
                  (not a!64)
                  (<= 1 v_0_snd_buf)
                  (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                  (<= 1 a!73)
                  (<= (- 7) a!82)
                  a!109
                  (<= 1 a!122)))
      (a!1029 (ite (and (>= a!1026 (- 4294967296)) (not (<= 8589934592 a!1026)))
                   (ite (<= 0 a!1026)
                        (ite (>= a!1026 4294967296) a!1027 a!1026)
                        a!1028)
                   (mod a!1026 4294967296)))
      (a!1032 (ite a!1031 (ite a!1022 (ite (<= 4 a!1025) 4 a!1025) v_0_take) 0))
      (a!1054 (= v_1_rtt_ambiguous
                 (ite a!1022 (and (not a!1053) a!1051) a!1051))))
(let ((a!145 (ite (and (>= (+ v_0_snd_nxt a!122) (- 4294967296))
                       (< (+ v_0_snd_nxt a!122) 8589934592))
                  a!144
                  (mod (+ v_0_snd_nxt a!122) 4294967296)))
      (a!152 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!151 a!84))
                 (and (not a!110) a!84)))
      (a!176 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!174) a!175))
                 (and (not a!110) a!84 a!174)))
      (a!183 (or (and (not a!110) a!84 a!181)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!181) a!182))))
      (a!190 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!188) a!189))
                 (and (not a!110) a!84 a!188)))
      (a!197 (or (and (not a!110) a!84 a!195)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!195) a!196))))
      (a!204 (or (and (not a!110) a!84 a!202)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!203 (and a!84 a!202)))))
      (a!210 (or (and (not a!110) a!84 a!208)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!208) a!209))))
      (a!216 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!214 (and a!84 a!215)))
                 (and (not a!110) a!84 a!215)))
      (a!222 (or (and (not a!110) a!84 a!220)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!220) a!221))))
      (a!228 (or (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!226) a!227))
                 (and (not a!110) a!84 a!226)))
      (a!233 (or (and (not a!110) a!84 a!231)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!232 (and a!84 a!231)))))
      (a!238 (or (and (not a!110) a!84 a!236)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!237 (and a!84 a!236)))))
      (a!243 (or (and (not a!110) a!84 a!241)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!242 (and a!84 a!241)))))
      (a!248 (or (and (not a!110) a!84 a!246)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!247 (and a!84 a!246)))))
      (a!252 (or (and (not a!110) a!84 a!250)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or a!251 (and a!84 a!250)))))
      (a!256 (or (and (not a!110) a!84 a!254)
                 (and (<= 1 v_0_rtx_buf)
                      (not v_0_persist_active)
                      v_0_fr_window_valid
                      (<= 1 v_0_snd_wnd)
                      (= input_0_net.ack_ack v_0_snd_una)
                      (= input_0_net.ack_window v_0_fr_last_window)
                      (<= 1 input_0_net.ack_window)
                      a!67
                      a!68
                      (not a!72)
                      (not v_0_fin_sent)
                      (not a!64)
                      (<= 1 v_0_snd_buf)
                      (<= 1 (ite a!40 a!63 v_0_rtx_buf))
                      (<= 1 a!73)
                      (<= (- 7) a!82)
                      (<= (+ now_1 a!90) (ite a!100 a!150 v_0_rto_ms))
                      (or (and a!84 a!254) a!255))))
      (a!367 (ite (or (and (not a!110) a!84 (<= 1 a!89)) a!366)
                  now_1
                  v_0_idle_last_data_ms))
      (a!374 (+ v_0_snd_buf
                v_0_rtx_buf
                (* (- 1) a!78)
                (* (- 1) (ite a!110 a!121 v_0_snd_buf))
                (* (- 1) a!123)))
      (a!576 (= 1 (+ (ite a!555 1 0) (ite a!556 1 0))))
      (a!612 (= v_1_cb_emitted_total
                (+ v_0_cb_emitted_total (ite a!556 a!122 (ite a!555 a!89 0)))))
      (a!1033 (ite (<= v_0_snd_buf a!1032) 0 (+ v_0_snd_buf (* (- 1) a!1032))))
      (a!1035 (ite (<= (ite (<= v_0_snd_buf 0) 0 v_0_snd_buf) a!1032)
                   (ite (<= v_0_snd_buf 0) 0 v_0_snd_buf)
                   a!1032)))
(let ((a!187 (ite a!183
                  now_1
                  (ite (>= 2 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154
                            (ite a!155 v_0_tx_time_03 a!186)
                            v_0_tx_time_02))))
      (a!194 (ite a!190
                  now_1
                  (ite (>= 3 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154 a!193 v_0_tx_time_03))))
      (a!201 (ite a!197 now_1 (ite (>= 4 (ite a!40 a!63 v_0_rtx_buf)) 0 a!200)))
      (a!213 (ite a!210
                  now_1
                  (ite (>= 6 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154
                            (ite a!155 v_0_tx_time_07 a!212)
                            v_0_tx_time_06))))
      (a!219 (ite a!216
                  now_1
                  (ite (>= 7 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154 a!218 v_0_tx_time_07))))
      (a!225 (ite a!222 now_1 (ite (>= 8 (ite a!40 a!63 v_0_rtx_buf)) 0 a!224)))
      (a!235 (ite a!233
                  now_1
                  (ite (>= 10 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154
                            (ite a!155 v_0_tx_time_11 a!234)
                            v_0_tx_time_10))))
      (a!240 (ite a!238
                  now_1
                  (ite (>= 11 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154 a!239 v_0_tx_time_11))))
      (a!245 (ite a!243 now_1 (ite (>= 12 (ite a!40 a!63 v_0_rtx_buf)) 0 a!244)))
      (a!253 (ite a!252
                  now_1
                  (ite (>= 14 (ite a!40 a!63 v_0_rtx_buf))
                       0
                       (ite a!154 (ite a!155 v_0_tx_time_15 0) v_0_tx_time_14))))
      (a!375 (= v_1_svc_abandoned_bytes
                (+ v_0_svc_abandoned_bytes (ite (<= 0 a!374) a!374 0))))
      (a!553 (ite (<= 1 (ite (<= 0 a!374) a!374 0))
                  0
                  (ite (<= 16 a!552)
                       (+ (- 16)
                          v_0_cb_head
                          a!386
                          a!397
                          a!408
                          a!419
                          a!430
                          a!441
                          a!452
                          a!463
                          a!474
                          a!485
                          a!496
                          a!507
                          a!518
                          a!529
                          a!540
                          a!551)
                       a!552)))
      (a!554 (ite (<= 1 (ite (<= 0 a!374) a!374 0)) 0 v_0_cb_tail))
      (a!559 (ite (<= 1 (ite (<= 0 a!374) a!374 0))
                  0
                  (+ v_0_cb_count
                     (* (- 1) a!386)
                     (* (- 1) a!397)
                     (* (- 1) a!408)
                     (* (- 1) a!419)
                     (* (- 1) a!430)
                     (* (- 1) a!441)
                     (* (- 1) a!452)
                     (* (- 1) a!463)
                     (* (- 1) a!474)
                     (* (- 1) a!485)
                     (* (- 1) a!496)
                     (* (- 1) a!507)
                     (* (- 1) a!518)
                     (* (- 1) a!529)
                     (* (- 1) a!540)
                     (* (- 1) a!551))))
      (a!577 (or (= v_0_cb_tail 0) (<= 1 (ite (<= 0 a!374) a!374 0))))
      (a!578 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!376 v_0_cb_count)) (<= 1 a!78) a!385)))
      (a!580 (not (<= 1 (ite (<= 0 a!374) a!374 0))))
      (a!581 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!387 v_0_cb_count)) (<= 1 a!78) a!396)))
      (a!583 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!398 v_0_cb_count)) (<= 1 a!78) a!407)))
      (a!585 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!409 v_0_cb_count)) (<= 1 a!78) a!418)))
      (a!587 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!420 v_0_cb_count)) (<= 1 a!78) a!429)))
      (a!589 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!431 v_0_cb_count)) (<= 1 a!78) a!440)))
      (a!591 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!442 v_0_cb_count)) (<= 1 a!78) a!451)))
      (a!593 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!453 v_0_cb_count)) (<= 1 a!78) a!462)))
      (a!595 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!464 v_0_cb_count)) (<= 1 a!78) a!473)))
      (a!597 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!475 v_0_cb_count)) (<= 1 a!78) a!484)))
      (a!599 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!486 v_0_cb_count)) (<= 1 a!78) a!495)))
      (a!601 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!497 v_0_cb_count)) (<= 1 a!78) a!506)))
      (a!603 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!508 v_0_cb_count)) (<= 1 a!78) a!517)))
      (a!605 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!519 v_0_cb_count)) (<= 1 a!78) a!528)))
      (a!607 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!530 v_0_cb_count)) (<= 1 a!78) a!539)))
      (a!609 (or (<= 1 (ite (<= 0 a!374) a!374 0))
                 (and (not (>= a!541 v_0_cb_count)) (<= 1 a!78) a!550)))
      (a!629 (ite (<= 1 (ite (<= 0 a!374) a!374 0))
                  (+ a!613
                     a!614
                     a!615
                     a!616
                     a!617
                     a!618
                     a!619
                     a!620
                     a!621
                     a!622
                     a!623
                     a!624
                     a!625
                     a!626
                     a!627
                     a!628)
                  0))
      (a!1034 (ite (<= a!1033 (ite (<= 0 v_0_snd_buf) v_0_snd_buf 0))
                   a!1033
                   (ite (<= 0 v_0_snd_buf) v_0_snd_buf 0)))
      (a!1055 (and (>= (+ v_0_snd_nxt a!1035) (- 4294967296))
                   (not (<= 8589934592 (+ v_0_snd_nxt a!1035)))))
      (a!1056 (ite (<= 0 (+ v_0_snd_nxt a!1035))
                   (ite (>= (+ v_0_snd_nxt a!1035) 4294967296)
                        (+ (- 4294967296) v_0_snd_nxt a!1035)
                        (+ v_0_snd_nxt a!1035))
                   (+ 4294967296 v_0_snd_nxt a!1035)))
      (a!1060 (or (and (>= 0 a!986) (<= 1 (+ a!986 a!1035))) a!1002))
      (a!1070 (or (and a!1002 a!1069)
                  (and (>= 1 a!986) (<= 2 (+ a!986 a!1035)))))
      (a!1079 (or (and a!1002 a!1078)
                  (and (>= 2 a!986) (<= 3 (+ a!986 a!1035)))))
      (a!1088 (or (and a!1002 a!1087)
                  (and (>= 3 a!986) (<= 4 (+ a!986 a!1035)))))
      (a!1096 (or (and a!1002 a!1095)
                  (and (>= 4 a!986) (<= 5 (+ a!986 a!1035)))))
      (a!1104 (or (and a!1002 a!1103)
                  (and (>= 5 a!986) (<= 6 (+ a!986 a!1035)))))
      (a!1112 (or (and a!1002 a!1111)
                  (and (>= 6 a!986) (<= 7 (+ a!986 a!1035)))))
      (a!1119 (or (and a!1002 a!1118)
                  (and (>= 7 a!986) (<= 8 (+ a!986 a!1035)))))
      (a!1126 (or (and a!1002 a!1125)
                  (and (>= 8 a!986) (<= 9 (+ a!986 a!1035)))))
      (a!1133 (or (and a!1002 a!1132)
                  (and (>= 9 a!986) (<= 10 (+ a!986 a!1035)))))
      (a!1139 (or (and (>= 10 a!986) (<= 11 (+ a!986 a!1035)))
                  (and a!1002 a!1138)))
      (a!1145 (or (and a!1002 a!1144)
                  (and (>= 11 a!986) (<= 12 (+ a!986 a!1035)))))
      (a!1151 (or (and a!1002 a!1150)
                  (and (>= 12 a!986) (<= 13 (+ a!986 a!1035)))))
      (a!1156 (or (and a!1002 a!1155)
                  (and (>= 13 a!986) (<= 14 (+ a!986 a!1035)))))
      (a!1161 (or (and a!1002 a!1160)
                  (and (>= 14 a!986) (<= 15 (+ a!986 a!1035)))))
      (a!1166 (or (and a!1002 a!1165)
                  (and (>= 15 a!986) (<= 16 (+ a!986 a!1035)))))
      (a!1248 (ite a!1022
                   (or v_0_idle_data_valid
                       (and a!1002 (<= 1 a!1006))
                       (<= 1 a!1035))
                   (or v_0_idle_data_valid (and a!1002 (<= 1 a!1006)))))
      (a!1249 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   (or (and a!1002 (<= 1 a!1006)) (<= 1 a!1035))))
      (a!1251 (ite a!1022
                   (or (and a!1002 (<= 1 a!1006)) (<= 1 a!1035))
                   (and a!1002 (<= 1 a!1006))))
      (a!1358 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   (<= 1 a!1035))))
(let ((a!557 (+ a!554 (ite a!555 1 0) (ite a!556 1 0)))
      (a!579 (ite (and a!576 a!577)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!578 0 v_0_cb_length_00)))
      (a!582 (ite (and a!576 (= v_0_cb_tail 1) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!581 0 v_0_cb_length_01)))
      (a!584 (ite (and a!576 (= v_0_cb_tail 2) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!583 0 v_0_cb_length_02)))
      (a!586 (ite (and a!576 (= v_0_cb_tail 3) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!585 0 v_0_cb_length_03)))
      (a!588 (ite (and a!576 (= v_0_cb_tail 4) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!587 0 v_0_cb_length_04)))
      (a!590 (ite (and a!576 (= v_0_cb_tail 5) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!589 0 v_0_cb_length_05)))
      (a!592 (ite (and a!576 (= v_0_cb_tail 6) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!591 0 v_0_cb_length_06)))
      (a!594 (ite (and a!576 (= v_0_cb_tail 7) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!593 0 v_0_cb_length_07)))
      (a!596 (ite (and a!576 (= v_0_cb_tail 8) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!595 0 v_0_cb_length_08)))
      (a!598 (ite (and a!576 (= v_0_cb_tail 9) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!597 0 v_0_cb_length_09)))
      (a!600 (ite (and a!576 (= v_0_cb_tail 10) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!599 0 v_0_cb_length_10)))
      (a!602 (ite (and a!576 (= v_0_cb_tail 11) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!601 0 v_0_cb_length_11)))
      (a!604 (ite (and a!576 (= v_0_cb_tail 12) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!603 0 v_0_cb_length_12)))
      (a!606 (ite (and a!576 (= v_0_cb_tail 13) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!605 0 v_0_cb_length_13)))
      (a!608 (ite (and a!576 (= v_0_cb_tail 14) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!607 0 v_0_cb_length_14)))
      (a!610 (ite (and a!576 (= v_0_cb_tail 15) a!580)
                  (ite a!556 a!122 (ite a!555 a!89 0))
                  (ite a!609 0 v_0_cb_length_15)))
      (a!634 (= v_1_cb_end_00
                (ite (and a!576 a!577)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!578 0 v_0_cb_end_00))))
      (a!636 (= v_1_cb_end_01
                (ite (and a!576 (= v_0_cb_tail 1) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!581 0 v_0_cb_end_01))))
      (a!638 (= v_1_cb_end_02
                (ite (and a!576 (= v_0_cb_tail 2) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!583 0 v_0_cb_end_02))))
      (a!640 (= v_1_cb_end_03
                (ite (and a!576 (= v_0_cb_tail 3) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!585 0 v_0_cb_end_03))))
      (a!642 (= v_1_cb_end_04
                (ite (and a!576 (= v_0_cb_tail 4) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!587 0 v_0_cb_end_04))))
      (a!644 (= v_1_cb_end_05
                (ite (and a!576 (= v_0_cb_tail 5) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!589 0 v_0_cb_end_05))))
      (a!646 (= v_1_cb_end_06
                (ite (and a!576 (= v_0_cb_tail 6) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!591 0 v_0_cb_end_06))))
      (a!648 (= v_1_cb_end_07
                (ite (and a!576 (= v_0_cb_tail 7) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!593 0 v_0_cb_end_07))))
      (a!650 (= v_1_cb_end_08
                (ite (and a!576 (= v_0_cb_tail 8) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!595 0 v_0_cb_end_08))))
      (a!652 (= v_1_cb_end_09
                (ite (and a!576 (= v_0_cb_tail 9) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!597 0 v_0_cb_end_09))))
      (a!654 (= v_1_cb_end_10
                (ite (and a!576 (= v_0_cb_tail 10) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!599 0 v_0_cb_end_10))))
      (a!656 (= v_1_cb_end_11
                (ite (and a!576 (= v_0_cb_tail 11) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!601 0 v_0_cb_end_11))))
      (a!658 (= v_1_cb_end_12
                (ite (and a!576 (= v_0_cb_tail 12) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!603 0 v_0_cb_end_12))))
      (a!660 (= v_1_cb_end_13
                (ite (and a!576 (= v_0_cb_tail 13) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!605 0 v_0_cb_end_13))))
      (a!662 (= v_1_cb_end_14
                (ite (and a!576 (= v_0_cb_tail 14) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!607 0 v_0_cb_end_14))))
      (a!664 (= v_1_cb_end_15
                (ite (and a!576 (= v_0_cb_tail 15) a!580)
                     (ite a!556 a!145 (ite a!555 a!633 0))
                     (ite a!609 0 v_0_cb_end_15))))
      (a!1057 (ite a!1053
                   (ite a!1055 a!1056 (mod (+ v_0_snd_nxt a!1035) 4294967296))
                   v_0_rtt_end))
      (a!1061 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1060))
      (a!1071 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1070))
      (a!1080 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1079))
      (a!1089 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1088))
      (a!1097 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1096))
      (a!1105 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1104))
      (a!1113 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1112))
      (a!1120 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1119))
      (a!1127 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1126))
      (a!1134 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1133))
      (a!1140 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1139))
      (a!1146 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1145))
      (a!1152 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1151))
      (a!1157 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1156))
      (a!1162 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1161))
      (a!1167 (and (<= 1 v_0_rtx_buf)
                   (not v_0_persist_active)
                   v_0_fr_window_valid
                   (<= 1 v_0_snd_wnd)
                   (= input_0_net.ack_ack v_0_snd_una)
                   (= input_0_net.ack_window v_0_fr_last_window)
                   (<= 1 input_0_net.ack_window)
                   (<= 1 a!988)
                   (>= 2 a!988)
                   (not a!991)
                   (not v_0_fin_sent)
                   (not a!987)
                   (<= 1 v_0_snd_buf)
                   (<= 1 a!986)
                   (<= 1 a!992)
                   (<= (- 7) (+ a!999 (* (- 1) a!986)))
                   a!1021
                   a!1166))
      (a!1250 (ite (or (and (not a!1022) a!1002 (<= 1 a!1006)) a!1249)
                   now_1
                   v_0_idle_last_data_ms))
      (a!1256 (+ v_0_snd_buf
                 v_0_rtx_buf
                 (* (- 1) a!995)
                 (* (- 1) (ite a!1022 a!1034 v_0_snd_buf))
                 (* (- 1) (ite a!1022 (+ a!986 a!1035) a!986))))
      (a!1361 (ite a!1358
                   a!1035
                   (ite (and a!1002 (<= 1 a!1006) (= a!971 v_0_snd_nxt))
                        a!1006
                        0)))
      (a!1402 (ite a!1358
                   (ite a!1055 a!1056 (mod (+ v_0_snd_nxt a!1035) 4294967296))
                   a!1401)))
(let ((a!558 (= v_1_cb_tail
                (ite (<= 16 a!557)
                     (+ (- 16) a!554 (ite a!555 1 0) (ite a!556 1 0))
                     a!557)))
      (a!611 (= v_1_cb_partial_prefix
                (+ a!579
                   a!582
                   a!584
                   a!586
                   a!588
                   a!590
                   a!592
                   a!594
                   a!596
                   a!598
                   a!600
                   a!602
                   a!604
                   a!606
                   a!608
                   a!610
                   (* (- 1) a!123))))
      (a!1068 (ite (or (and (not a!1022) a!1002) a!1061)
                   now_1
                   (ite (>= 0 a!986) 0 (ite a!1062 a!1067 v_0_tx_time_00))))
      (a!1077 (ite (or a!1071 (and (not a!1022) a!1002 a!1069))
                   now_1
                   (ite (>= 1 a!986) 0 a!1076)))
      (a!1086 (ite (or (and (not a!1022) a!1002 a!1078) a!1080) now_1 a!1085))
      (a!1094 (ite (or (and (not a!1022) a!1002 a!1087) a!1089)
                   now_1
                   (ite (>= 3 a!986) 0 (ite a!1062 a!1093 v_0_tx_time_03))))
      (a!1102 (ite (or (and (not a!1022) a!1002 a!1095) a!1097)
                   now_1
                   (ite (>= 4 a!986) 0 a!1101)))
      (a!1110 (ite (or (and (not a!1022) a!1002 a!1103) a!1105) now_1 a!1109))
      (a!1117 (ite (or (and (not a!1022) a!1002 a!1111) a!1113)
                   now_1
                   (ite (>= 6 a!986) 0 (ite a!1062 a!1116 v_0_tx_time_06))))
      (a!1124 (ite (or a!1120 (and (not a!1022) a!1002 a!1118))
                   now_1
                   (ite (>= 7 a!986) 0 a!1123)))
      (a!1131 (ite (or (and (not a!1022) a!1002 a!1125) a!1127) now_1 a!1130))
      (a!1137 (ite (or (and (not a!1022) a!1002 a!1132) a!1134)
                   now_1
                   (ite (>= 9 a!986) 0 (ite a!1062 a!1136 v_0_tx_time_09))))
      (a!1143 (ite (or (and (not a!1022) a!1002 a!1138) a!1140)
                   now_1
                   (ite (>= 10 a!986) 0 a!1142)))
      (a!1149 (ite (or (and (not a!1022) a!1002 a!1144) a!1146) now_1 a!1148))
      (a!1154 (ite (or (and (not a!1022) a!1002 a!1150) a!1152)
                   now_1
                   (ite (>= 12 a!986) 0 (ite a!1062 a!1153 v_0_tx_time_12))))
      (a!1159 (ite (or (and (not a!1022) a!1002 a!1155) a!1157)
                   now_1
                   (ite (>= 13 a!986) 0 a!1158)))
      (a!1164 (ite (or (and (not a!1022) a!1002 a!1160) a!1162) now_1 a!1163))
      (a!1168 (ite (or (and (not a!1022) a!1002 a!1165) a!1167)
                   now_1
                   (ite (or (>= 15 a!986) a!1062) 0 v_0_tx_time_15)))
      (a!1257 (= v_1_svc_abandoned_bytes
                 (+ v_0_svc_abandoned_bytes (ite (<= 0 a!1256) a!1256 0))))
      (a!1355 (ite (<= 1 (ite (<= 0 a!1256) a!1256 0))
                   0
                   (ite (<= 7 a!1354)
                        (+ (- 7)
                           (ite a!1263 1 0)
                           (ite a!1269 1 0)
                           (ite a!1275 1 0)
                           (ite a!1281 1 0)
                           (ite a!1287 1 0)
                           (ite a!1293 1 0)
                           (ite a!1299 1 0)
                           (ite a!1305 1 0)
                           (ite a!1311 1 0)
                           (ite a!1317 1 0)
                           (ite a!1323 1 0)
                           (ite a!1329 1 0)
                           (ite a!1335 1 0)
                           (ite a!1341 1 0)
                           (ite a!1347 1 0)
                           (ite a!1353 1 0))
                        (+ 9
                           (ite a!1263 1 0)
                           (ite a!1269 1 0)
                           (ite a!1275 1 0)
                           (ite a!1281 1 0)
                           (ite a!1287 1 0)
                           (ite a!1293 1 0)
                           (ite a!1299 1 0)
                           (ite a!1305 1 0)
                           (ite a!1311 1 0)
                           (ite a!1317 1 0)
                           (ite a!1323 1 0)
                           (ite a!1329 1 0)
                           (ite a!1335 1 0)
                           (ite a!1341 1 0)
                           (ite a!1347 1 0)
                           (ite a!1353 1 0)))))
      (a!1356 (ite (<= 1 (ite (<= 0 a!1256) a!1256 0)) 0 v_0_cb_tail))
      (a!1360 (ite (<= 1 (ite (<= 0 a!1256) a!1256 0))
                   0
                   (+ v_0_cb_count
                      (* (- 1) (ite a!1263 1 0))
                      (* (- 1) (ite a!1269 1 0))
                      (* (- 1) (ite a!1275 1 0))
                      (* (- 1) (ite a!1281 1 0))
                      (* (- 1) (ite a!1287 1 0))
                      (* (- 1) (ite a!1293 1 0))
                      (* (- 1) (ite a!1299 1 0))
                      (* (- 1) (ite a!1305 1 0))
                      (* (- 1) (ite a!1311 1 0))
                      (* (- 1) (ite a!1317 1 0))
                      (* (- 1) (ite a!1323 1 0))
                      (* (- 1) (ite a!1329 1 0))
                      (* (- 1) (ite a!1335 1 0))
                      (* (- 1) (ite a!1341 1 0))
                      (* (- 1) (ite a!1347 1 0))
                      (* (- 1) (ite a!1353 1 0)))))
      (a!1362 (or (= v_0_cb_tail 0) (<= 1 (ite (<= 0 a!1256) a!1256 0))))
      (a!1364 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1263))
      (a!1365 (not (<= 1 (ite (<= 0 a!1256) a!1256 0))))
      (a!1367 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1269))
      (a!1369 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1275))
      (a!1371 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1281))
      (a!1373 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1287))
      (a!1375 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1293))
      (a!1377 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1299))
      (a!1379 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1305))
      (a!1381 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1311))
      (a!1383 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1317))
      (a!1385 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1323))
      (a!1387 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1329))
      (a!1389 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1335))
      (a!1391 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1341))
      (a!1393 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1347))
      (a!1395 (or (<= 1 (ite (<= 0 a!1256) a!1256 0)) a!1353))
      (a!1398 (ite (<= 1 (ite (<= 0 a!1256) a!1256 0))
                   (+ (ite a!1263 0 v_0_cb_length_00)
                      (ite a!1269 0 v_0_cb_length_01)
                      (ite a!1275 0 v_0_cb_length_02)
                      (ite a!1281 0 v_0_cb_length_03)
                      (ite a!1287 0 v_0_cb_length_04)
                      (ite a!1293 0 v_0_cb_length_05)
                      (ite a!1299 0 v_0_cb_length_06)
                      (ite a!1305 0 v_0_cb_length_07)
                      (ite a!1311 0 v_0_cb_length_08)
                      (ite a!1317 0 v_0_cb_length_09)
                      (ite a!1323 0 v_0_cb_length_10)
                      (ite a!1329 0 v_0_cb_length_11)
                      (ite a!1335 0 v_0_cb_length_12)
                      (ite a!1341 0 v_0_cb_length_13)
                      (ite a!1347 0 v_0_cb_length_14)
                      (ite a!1353 0 v_0_cb_length_15))
                   0)))
(let ((a!948 (and (>= v_0_snd_buf 0)
                  (>= v_0_rtx_buf 0)
                  (>= v_0_rcv_buf 0)
                  (>= v_0_rx_chunk 0)
                  (>= v_0_rx_slot_00 0)
                  (>= v_0_rx_slot_01 0)
                  (>= v_0_rx_slot_02 0)
                  (>= v_0_rx_slot_03 0)
                  (>= v_0_rx_slot_04 0)
                  (>= v_0_rx_slot_05 0)
                  (>= v_0_rx_slot_06 0)
                  (>= v_0_rx_slot_07 0)
                  (>= v_0_rx_slot_08 0)
                  (>= v_0_rx_slot_09 0)
                  (>= v_0_rx_slot_10 0)
                  (>= v_0_rx_slot_11 0)
                  (>= v_0_rx_slot_12 0)
                  (>= v_0_rx_slot_13 0)
                  (>= v_0_rx_slot_14 0)
                  (>= v_0_rx_slot_15 0)
                  (>= v_1_snd_buf 0)
                  (>= v_1_rtx_buf 0)
                  (>= v_1_rcv_buf 0)
                  (>= v_1_rx_chunk 0)
                  (>= v_1_rx_slot_00 0)
                  (>= v_1_rx_slot_01 0)
                  (>= v_1_rx_slot_02 0)
                  (>= v_1_rx_slot_03 0)
                  (>= v_1_rx_slot_04 0)
                  (>= v_1_rx_slot_05 0)
                  (>= v_1_rx_slot_06 0)
                  (>= v_1_rx_slot_07 0)
                  (>= v_1_rx_slot_08 0)
                  (>= v_1_rx_slot_09 0)
                  (>= v_1_rx_slot_10 0)
                  (>= v_1_rx_slot_11 0)
                  (>= v_1_rx_slot_12 0)
                  (>= v_1_rx_slot_13 0)
                  (>= v_1_rx_slot_14 0)
                  (>= v_1_rx_slot_15 0)
                  (>= v_0_iss 0)
                  (not (<= 4294967296 v_0_iss))
                  (>= v_0_irs 0)
                  (not (<= 4294967296 v_0_irs))
                  (>= v_0_snd_una 0)
                  (not (<= 4294967296 v_0_snd_una))
                  (>= v_0_snd_nxt 0)
                  (not (<= 4294967296 v_0_snd_nxt))
                  (>= v_0_rcv_nxt 0)
                  (not (<= 4294967296 v_0_rcv_nxt))
                  (>= v_0_tx_seq 0)
                  (not (<= 4294967296 v_0_tx_seq))
                  (>= v_0_tx_ack 0)
                  (not (<= 4294967296 v_0_tx_ack))
                  (>= v_0_snd_wl1 0)
                  (not (<= 4294967296 v_0_snd_wl1))
                  (>= v_0_snd_wl2 0)
                  (not (<= 4294967296 v_0_snd_wl2))
                  (>= v_0_fin_seq 0)
                  (not (<= 4294967296 v_0_fin_seq))
                  (>= v_0_rx_fin_seq 0)
                  (not (<= 4294967296 v_0_rx_fin_seq))
                  (>= v_0_rtt_end 0)
                  (not (<= 4294967296 v_0_rtt_end))
                  (>= v_0_cc_before_una 0)
                  (not (<= 4294967296 v_0_cc_before_una))
                  (>= v_0_fr_before_una 0)
                  (not (<= 4294967296 v_0_fr_before_una))
                  (>= v_0_fr_before_nxt 0)
                  (not (<= 4294967296 v_0_fr_before_nxt))
                  (>= v_0_lt_before_nxt 0)
                  (not (<= 4294967296 v_0_lt_before_nxt))
                  (>= v_0_choice_before_nxt 0)
                  (not (<= 4294967296 v_0_choice_before_nxt))
                  (>= v_0_cb_before_nxt 0)
                  (not (<= 4294967296 v_0_cb_before_nxt))
                  (>= v_0_cb_append_end 0)
                  (not (<= 4294967296 v_0_cb_append_end))
                  (>= v_0_cb_end_00 0)
                  (not (<= 4294967296 v_0_cb_end_00))
                  (>= v_0_cb_end_01 0)
                  (not (<= 4294967296 v_0_cb_end_01))
                  (>= v_0_cb_end_02 0)
                  (not (<= 4294967296 v_0_cb_end_02))
                  (>= v_0_cb_end_03 0)
                  (not (<= 4294967296 v_0_cb_end_03))
                  (>= v_0_cb_end_04 0)
                  (not (<= 4294967296 v_0_cb_end_04))
                  (>= v_0_cb_end_05 0)
                  (not (<= 4294967296 v_0_cb_end_05))
                  (>= v_0_cb_end_06 0)
                  (not (<= 4294967296 v_0_cb_end_06))
                  (>= v_0_cb_end_07 0)
                  (not (<= 4294967296 v_0_cb_end_07))
                  (>= v_0_cb_end_08 0)
                  (not (<= 4294967296 v_0_cb_end_08))
                  (>= v_0_cb_end_09 0)
                  (not (<= 4294967296 v_0_cb_end_09))
                  (>= v_0_cb_end_10 0)
                  (not (<= 4294967296 v_0_cb_end_10))
                  (>= v_0_cb_end_11 0)
                  (not (<= 4294967296 v_0_cb_end_11))
                  (>= v_0_cb_end_12 0)
                  (not (<= 4294967296 v_0_cb_end_12))
                  (>= v_0_cb_end_13 0)
                  (not (<= 4294967296 v_0_cb_end_13))
                  (>= v_0_cb_end_14 0)
                  (not (<= 4294967296 v_0_cb_end_14))
                  (>= v_0_cb_end_15 0)
                  (not (<= 4294967296 v_0_cb_end_15))
                  (>= v_1_iss 0)
                  (not (<= 4294967296 v_1_iss))
                  (>= v_1_irs 0)
                  (not (<= 4294967296 v_1_irs))
                  (>= v_1_snd_una 0)
                  (not (<= 4294967296 v_1_snd_una))
                  (>= v_1_snd_nxt 0)
                  (not (<= 4294967296 v_1_snd_nxt))
                  (>= v_1_rcv_nxt 0)
                  (not (<= 4294967296 v_1_rcv_nxt))
                  (>= v_1_tx_seq 0)
                  (not (<= 4294967296 v_1_tx_seq))
                  (>= v_1_tx_ack 0)
                  (not (<= 4294967296 v_1_tx_ack))
                  (>= v_1_snd_wl1 0)
                  (not (<= 4294967296 v_1_snd_wl1))
                  (>= v_1_snd_wl2 0)
                  (not (<= 4294967296 v_1_snd_wl2))
                  (>= v_1_fin_seq 0)
                  (not (<= 4294967296 v_1_fin_seq))
                  (>= v_1_rx_fin_seq 0)
                  (not (<= 4294967296 v_1_rx_fin_seq))
                  (>= v_1_rtt_end 0)
                  (not (<= 4294967296 v_1_rtt_end))
                  (>= v_1_cc_before_una 0)
                  (not (<= 4294967296 v_1_cc_before_una))
                  (>= v_1_fr_before_una 0)
                  (not (<= 4294967296 v_1_fr_before_una))
                  (>= v_1_fr_before_nxt 0)
                  (not (<= 4294967296 v_1_fr_before_nxt))
                  (>= v_1_lt_before_nxt 0)
                  (not (<= 4294967296 v_1_lt_before_nxt))
                  (>= v_1_choice_before_nxt 0)
                  (not (<= 4294967296 v_1_choice_before_nxt))
                  (>= v_1_cb_before_nxt 0)
                  (not (<= 4294967296 v_1_cb_before_nxt))
                  (>= v_1_cb_append_end 0)
                  (not (<= 4294967296 v_1_cb_append_end))
                  (>= v_1_cb_end_00 0)
                  (not (<= 4294967296 v_1_cb_end_00))
                  (>= v_1_cb_end_01 0)
                  (not (<= 4294967296 v_1_cb_end_01))
                  (>= v_1_cb_end_02 0)
                  (not (<= 4294967296 v_1_cb_end_02))
                  (>= v_1_cb_end_03 0)
                  (not (<= 4294967296 v_1_cb_end_03))
                  (>= v_1_cb_end_04 0)
                  (not (<= 4294967296 v_1_cb_end_04))
                  (>= v_1_cb_end_05 0)
                  (not (<= 4294967296 v_1_cb_end_05))
                  (>= v_1_cb_end_06 0)
                  (not (<= 4294967296 v_1_cb_end_06))
                  (>= v_1_cb_end_07 0)
                  (not (<= 4294967296 v_1_cb_end_07))
                  (>= v_1_cb_end_08 0)
                  (not (<= 4294967296 v_1_cb_end_08))
                  (>= v_1_cb_end_09 0)
                  (not (<= 4294967296 v_1_cb_end_09))
                  (>= v_1_cb_end_10 0)
                  (not (<= 4294967296 v_1_cb_end_10))
                  (>= v_1_cb_end_11 0)
                  (not (<= 4294967296 v_1_cb_end_11))
                  (>= v_1_cb_end_12 0)
                  (not (<= 4294967296 v_1_cb_end_12))
                  (>= v_1_cb_end_13 0)
                  (not (<= 4294967296 v_1_cb_end_13))
                  (>= v_1_cb_end_14 0)
                  (not (<= 4294967296 v_1_cb_end_14))
                  (>= v_1_cb_end_15 0)
                  (not (<= 4294967296 v_1_cb_end_15))
                  true
                  true
                  (>= now_0 0)
                  (or (not active_0_rtx) (>= due_0_rtx now_0))
                  (or (not active_0_user) (>= due_0_user now_0))
                  (or (not active_0_time_wait) (>= due_0_time_wait now_0))
                  (or (not active_0_delack) (>= due_0_delack now_0))
                  (or (not active_0_persist) (>= due_0_persist now_0))
                  (>= input_0_app.send_data 0)
                  (>= input_0_net.data_data 0)
                  (>= input_0_net.fin_segment_data 0)
                  (>= input_0_net.syn_seq 0)
                  (not (<= 4294967296 input_0_net.syn_seq))
                  (>= input_0_net.synack_seq 0)
                  (not (<= 4294967296 input_0_net.synack_seq))
                  (>= input_0_net.synack_ack 0)
                  (not (<= 4294967296 input_0_net.synack_ack))
                  (>= input_0_net.ack_seq 0)
                  (not (<= 4294967296 input_0_net.ack_seq))
                  (>= input_0_net.ack_ack 0)
                  (not (<= 4294967296 input_0_net.ack_ack))
                  (>= input_0_net.fin_seq 0)
                  (not (<= 4294967296 input_0_net.fin_seq))
                  (>= input_0_net.fin_ack 0)
                  (not (<= 4294967296 input_0_net.fin_ack))
                  (>= input_0_net.rst_seq 0)
                  (not (<= 4294967296 input_0_net.rst_seq))
                  (>= input_0_net.rstack_seq 0)
                  (not (<= 4294967296 input_0_net.rstack_seq))
                  (>= input_0_net.rstack_ack 0)
                  (not (<= 4294967296 input_0_net.rstack_ack))
                  (>= input_0_net.data_seq 0)
                  (not (<= 4294967296 input_0_net.data_seq))
                  (>= input_0_net.data_ack 0)
                  (not (<= 4294967296 input_0_net.data_ack))
                  (>= input_0_net.fin_segment_seq 0)
                  (not (<= 4294967296 input_0_net.fin_segment_seq))
                  (>= input_0_net.fin_segment_ack 0)
                  (not (<= 4294967296 input_0_net.fin_segment_ack))
                  (>= now_1 now_0)
                  (<= 0 input_0_net.ack_window)
                  (>= 65535 input_0_net.ack_window)
                  a!9
                  (or (and (= 0 v_0_local_window)
                           (= input_0_net.ack_seq v_0_rcv_nxt))
                      a!18)
                  a!27
                  a!36
                  (not a!37)
                  (or (not active_0_rtx) (not (<= due_0_rtx now_1)))
                  (or (not active_0_user) (not (<= due_0_user now_1)))
                  (or (not active_0_time_wait) (not (<= due_0_time_wait now_1)))
                  (or (not active_0_delack) (not (<= due_0_delack now_1)))
                  (or (not active_0_persist) (not (<= due_0_persist now_1)))
                  (= v_1_iss v_0_iss)
                  (= v_1_irs v_0_irs)
                  (= v_1_snd_una (ite a!40 input_0_net.ack_ack v_0_snd_una))
                  (= v_1_snd_nxt (ite a!110 a!116 v_0_snd_nxt))
                  (= v_1_rcv_nxt v_0_rcv_nxt)
                  (= v_1_tx_seq v_0_tx_seq)
                  (= v_1_tx_ack v_0_tx_ack)
                  (= v_1_tx_flags v_0_tx_flags)
                  a!117
                  (= v_1_retries v_0_retries)
                  (= v_1_active_open v_0_active_open)
                  (= v_1_user_timeout_ms v_0_user_timeout_ms)
                  (= v_1_msl_ms v_0_msl_ms)
                  (= v_1_local_window v_0_local_window)
                  (= v_1_snd_buf (ite a!110 a!121 v_0_snd_buf))
                  (= v_1_rtx_buf a!123)
                  (= v_1_rcv_buf v_0_rcv_buf)
                  (= v_1_snd_wnd (ite a!60 input_0_net.ack_window v_0_snd_wnd))
                  (= v_1_snd_wl1 (ite a!60 input_0_net.ack_seq v_0_snd_wl1))
                  (= v_1_snd_wl2 (ite a!60 input_0_net.ack_ack v_0_snd_wl2))
                  a!124
                  (= v_1_rx_chunk v_0_rx_chunk)
                  (= v_1_rx_slot_00 v_0_rx_slot_00)
                  (= v_1_rx_slot_01 v_0_rx_slot_01)
                  (= v_1_rx_slot_02 v_0_rx_slot_02)
                  (= v_1_rx_slot_03 v_0_rx_slot_03)
                  (= v_1_rx_slot_04 v_0_rx_slot_04)
                  (= v_1_rx_slot_05 v_0_rx_slot_05)
                  (= v_1_rx_slot_06 v_0_rx_slot_06)
                  (= v_1_rx_slot_07 v_0_rx_slot_07)
                  (= v_1_rx_slot_08 v_0_rx_slot_08)
                  (= v_1_rx_slot_09 v_0_rx_slot_09)
                  (= v_1_rx_slot_10 v_0_rx_slot_10)
                  (= v_1_rx_slot_11 v_0_rx_slot_11)
                  (= v_1_rx_slot_12 v_0_rx_slot_12)
                  (= v_1_rx_slot_13 v_0_rx_slot_13)
                  (= v_1_rx_slot_14 v_0_rx_slot_14)
                  (= v_1_rx_slot_15 v_0_rx_slot_15)
                  (= v_1_rx_advance v_0_rx_advance)
                  (= v_1_rx_acceptable v_0_rx_acceptable)
                  a!125
                  (= v_1_ack_delta
                     (ite (and a!19 a!20) (ite a!21 a!22 a!25) a!26))
                  (= v_1_ack_is_new (and a!38 a!39))
                  (= v_1_ack_is_future a!37)
                  (= v_1_ack_advance a!40)
                  (= v_1_ack_window_update a!60)
                  (= v_1_fin_requested v_0_fin_requested)
                  (= v_1_fin_sent v_0_fin_sent)
                  (= v_1_fin_seq v_0_fin_seq)
                  (= v_1_fin_acknowledged v_0_fin_acknowledged)
                  (= v_1_rx_fin_pending v_0_rx_fin_pending)
                  (= v_1_rx_fin_seq v_0_rx_fin_seq)
                  (= v_1_rx_fin_offset v_0_rx_fin_offset)
                  (= v_1_rx_fin_done v_0_rx_fin_done)
                  (= v_1_rx_fin_consumed v_0_rx_fin_consumed)
                  (= v_1_srtt_ms (ite a!100 a!102 v_0_srtt_ms))
                  (= v_1_rttvar_ms (ite a!100 a!105 v_0_rttvar_ms))
                  (= v_1_rtt_error_ms (ite a!100 a!104 v_0_rtt_error_ms))
                  (= v_1_rtt_previous_srtt
                     (ite a!100 v_0_srtt_ms v_0_rtt_previous_srtt))
                  (= v_1_rtt_previous_var
                     (ite a!100 v_0_rttvar_ms v_0_rtt_previous_var))
                  (= v_1_rtt_measured (or v_0_rtt_measured a!100))
                  (= v_1_rtt_previous_measured
                     (ite a!100 v_0_rtt_measured v_0_rtt_previous_measured))
                  a!127
                  a!143
                  (= v_1_rtt_sample_at_ms
                     (ite a!100 now_1 v_0_rtt_sample_at_ms))
                  (= v_1_rtt_start_ms (ite a!142 now_1 v_0_rtt_start_ms))
                  (= v_1_rtt_end (ite a!142 a!145 v_0_rtt_end))
                  a!146
                  (= v_1_rtt_start_new a!142)
                  (= v_1_rtt_sample_used a!100)
                  (= v_1_rtt_sample_was_ambiguous
                     (and v_0_rtt_active v_0_rtt_ambiguous))
                  (= v_1_rtt_last_ms a!101)
                  (= v_1_rtt_samples (+ v_0_rtt_samples (ite a!100 1 0)))
                  a!147
                  (= v_1_tx_time_00 (ite a!152 now_1 a!173))
                  (= v_1_tx_time_01 (ite a!176 now_1 a!180))
                  (= v_1_tx_time_02 a!187)
                  (= v_1_tx_time_03 a!194)
                  (= v_1_tx_time_04 a!201)
                  (= v_1_tx_time_05 (ite a!204 now_1 a!207))
                  (= v_1_tx_time_06 a!213)
                  (= v_1_tx_time_07 a!219)
                  (= v_1_tx_time_08 a!225)
                  (= v_1_tx_time_09 (ite a!228 now_1 a!230))
                  (= v_1_tx_time_10 a!235)
                  (= v_1_tx_time_11 a!240)
                  (= v_1_tx_time_12 a!245)
                  (= v_1_tx_time_13 (ite a!248 now_1 a!249))
                  (= v_1_tx_time_14 a!253)
                  (= v_1_tx_time_15 (ite a!256 now_1 a!257))
                  a!258
                  (= v_1_tx_emit_count v_0_tx_emit_count)
                  (= v_1_tx_eligible v_0_tx_eligible)
                  (= v_1_tx_max_previous v_0_tx_max_previous)
                  (not v_1_tx_retransmitted)
                  (= v_1_tx_elapsed v_0_tx_elapsed)
                  (= v_1_tx_previous_rto v_0_tx_previous_rto)
                  (= v_1_tx_is_fin v_0_tx_is_fin)
                  (not v_1_tx_waiting)
                  (= v_1_tx_syn_time 0)
                  (not v_1_tx_syn_pending)
                  (not v_1_syn_timeout_eligible)
                  (= v_1_ack_pending
                     (and (not a!110) (not a!84) v_0_ack_pending))
                  (= v_1_ack_since_ms (ite (or a!110 a!84) 0 v_0_ack_since_ms))
                  (= v_1_ack_bytes (ite (or a!110 a!84) 0 v_0_ack_bytes))
                  (= v_1_ack_full_segments
                     (ite (or a!110 a!84) 0 v_0_ack_full_segments))
                  (= v_1_ack_delay_ms v_0_ack_delay_ms)
                  (= v_1_ack_rmss v_0_ack_rmss)
                  (not v_1_ack_defer_candidate)
                  (not v_1_ack_defer_now)
                  (= v_1_persist_active a!64)
                  (= v_1_persist_eligible a!64)
                  (= v_1_persist_start a!259)
                  (= v_1_persist_was_active v_0_persist_active)
                  (not v_1_persist_first)
                  (not v_1_persist_probe_sent)
                  (not v_1_persist_probe_new)
                  (= v_1_persist_interval_ms (ite a!64 a!260 1000))
                  (= v_1_persist_previous_interval_ms
                     v_0_persist_previous_interval_ms)
                  (= v_1_persist_since_ms
                     (ite a!64 (ite a!259 now_1 v_0_persist_since_ms) 0))
                  (= v_1_persist_last_ms (ite a!64 v_0_persist_last_ms 0))
                  a!261
                  (= v_1_persist_probes (ite a!64 v_0_persist_probes 0))
                  (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)
                  (= v_1_cc_initial_window v_0_cc_initial_window)
                  (= v_1_cc_initial_threshold v_0_cc_initial_threshold)
                  a!262
                  (= v_1_cc_ssthresh (ite a!70 a!76 v_0_cc_ssthresh))
                  (= v_1_cc_ca_credit a!264)
                  (= v_1_cc_acked a!78)
                  (= v_1_cc_before_flight v_0_rtx_buf)
                  (= v_1_cc_before_una v_0_snd_una)
                  (= v_1_cc_before_persist v_0_persist_active)
                  (= v_1_cc_before_window v_0_snd_wnd)
                  (not v_1_cc_loss)
                  (not v_1_cc_threshold_changed)
                  (= v_1_cc_threshold_updates v_0_cc_threshold_updates)
                  (= v_1_cc_growth (ite a!79 0 a!80))
                  (= v_1_cc_before_cwnd v_0_cc_cwnd)
                  (= v_1_cc_send_budget (ite (<= 0 a!265) a!265 0))
                  (= 0 v_1_cc_new_sent)
                  (= v_1_cc_rto_00 a!301)
                  (= v_1_cc_rto_01 a!307)
                  (= v_1_cc_rto_02 a!313)
                  (= v_1_cc_rto_03 a!318)
                  (= v_1_cc_rto_04 a!323)
                  (= v_1_cc_rto_05 a!328)
                  (= v_1_cc_rto_06 a!333)
                  (= v_1_cc_rto_07 a!337)
                  (= v_1_cc_rto_08 a!341)
                  (= v_1_cc_rto_09 a!345)
                  (= v_1_cc_rto_10 a!349)
                  (= v_1_cc_rto_11 a!352)
                  (= v_1_cc_rto_12 a!355)
                  (= v_1_cc_rto_13 a!358)
                  (= v_1_cc_rto_14 a!361)
                  (= v_1_cc_rto_15 a!362)
                  (not v_1_fr_window_ignored)
                  (= v_1_fr_before_wire_window v_0_fr_last_window)
                  (= v_1_fr_before_window_valid v_0_fr_window_valid)
                  (= v_1_fr_active a!72)
                  a!363
                  v_1_fr_window_valid
                  (= v_1_fr_last_window input_0_net.ack_window)
                  (= v_1_fr_was_active v_0_fr_active)
                  (= v_1_fr_before_una v_0_snd_una)
                  (= v_1_fr_before_nxt v_0_snd_nxt)
                  (= v_1_fr_before_flight v_0_rtx_buf)
                  (= v_1_fr_before_rto v_0_rto_ms)
                  (= v_1_fr_before_retries v_0_retries)
                  (= v_1_fr_duplicate a!66)
                  (= v_1_fr_entered a!70)
                  (= v_1_fr_extra a!77)
                  (= v_1_fr_exited a!71)
                  (= v_1_fr_retransmitted a!84)
                  a!364
                  (= v_1_fr_entries (+ v_0_fr_entries (ite a!70 1 0)))
                  (= v_1_idle_data_valid a!365)
                  (= v_1_idle_last_data_ms a!367)
                  (= v_1_idle_event_ms now_1)
                  (= v_1_idle_data_emitted a!368)
                  (not v_1_idle_restart)
                  (= v_1_idle_elapsed_ms a!369)
                  (= v_1_idle_before_cwnd v_0_cc_cwnd)
                  (= v_1_idle_before_rto v_0_rto_ms)
                  (= v_1_idle_before_threshold v_0_cc_ssthresh)
                  (= v_1_idle_restart_count v_0_idle_restart_count)
                  (= v_1_lt_eligible a!110)
                  (= v_1_lt_emitted a!110)
                  a!370
                  (= v_1_lt_epoch_bytes a!372)
                  (= v_1_lt_epoch_packets
                     (+ (ite a!371 0 v_0_lt_epoch_packets) (ite a!110 1 0)))
                  (= v_1_lt_before_bytes v_0_lt_epoch_bytes)
                  (= v_1_lt_before_cwnd v_0_cc_cwnd)
                  (= v_1_lt_before_nxt v_0_snd_nxt)
                  (= v_1_lt_before_flight v_0_rtx_buf)
                  (= v_1_lt_before_window v_0_snd_wnd)
                  a!373
                  (not v_1_choice_used)
                  (= v_1_choice_count v_0_choice_count)
                  (= v_1_choice_limit v_0_choice_limit)
                  (= v_1_choice_before_nxt v_0_choice_before_nxt)
                  (= v_1_choice_before_flight v_0_choice_before_flight)
                  v_1_sched_open
                  (= v_1_sched_at_ms now_1)
                  (= 2 v_1_sched_cause)
                  (= 0 v_1_sched_bytes)
                  (= 0 v_1_sched_packets)
                  (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf))
                  (= 0 v_1_svc_accept_step)
                  (= v_1_svc_ack_step a!78)
                  (= v_1_svc_drop_step (ite (<= 0 a!374) a!374 0))
                  (= v_1_svc_written_bytes v_0_svc_written_bytes)
                  (= v_1_svc_acked_bytes (+ v_0_svc_acked_bytes a!78))
                  a!375
                  (= v_1_cb_head a!553)
                  a!558
                  (= v_1_cb_count (+ a!559 (ite a!555 1 0) (ite a!556 1 0)))
                  (= v_1_cb_new_count (+ (ite a!555 1 0) (ite a!556 1 0)))
                  (= v_1_cb_append_length (ite a!556 a!122 (ite a!555 a!89 0)))
                  (= v_1_cb_retired_count
                     (+ a!386
                        a!397
                        a!408
                        a!419
                        a!430
                        a!441
                        a!452
                        a!463
                        a!474
                        a!485
                        a!496
                        a!507
                        a!518
                        a!529
                        a!540
                        a!551))
                  (= v_1_cb_step_bytes
                     (+ a!560
                        a!561
                        a!562
                        a!563
                        a!564
                        a!565
                        a!566
                        a!567
                        a!568
                        a!569
                        a!570
                        a!571
                        a!572
                        a!573
                        a!574
                        a!575))
                  (= v_1_cb_live_total
                     (+ a!579
                        a!582
                        a!584
                        a!586
                        a!588
                        a!590
                        a!592
                        a!594
                        a!596
                        a!598
                        a!600
                        a!602
                        a!604
                        a!606
                        a!608
                        a!610))
                  a!611
                  a!612
                  (= v_1_cb_acked_total
                     (+ v_0_cb_acked_total
                        a!560
                        a!561
                        a!562
                        a!563
                        a!564
                        a!565
                        a!566
                        a!567
                        a!568
                        a!569
                        a!570
                        a!571
                        a!572
                        a!573
                        a!574
                        a!575))
                  (= v_1_cb_abandoned_total (+ v_0_cb_abandoned_total a!629))
                  (= v_1_cb_drop_step a!629)
                  (= v_1_cb_before_nxt v_0_snd_nxt)
                  (= v_1_cb_append_end (ite a!556 a!145 (ite a!555 a!633 0)))
                  (= v_1_cb_is_new a!556)
                  (= v_1_cb_length_00 a!579)
                  a!634
                  a!635
                  (= v_1_cb_length_01 a!582)
                  a!636
                  a!637
                  (= v_1_cb_length_02 a!584)
                  a!638
                  a!639
                  (= v_1_cb_length_03 a!586)
                  a!640
                  a!641
                  (= v_1_cb_length_04 a!588)
                  a!642
                  a!643
                  (= v_1_cb_length_05 a!590)
                  a!644
                  a!645
                  (= v_1_cb_length_06 a!592)
                  a!646
                  a!647
                  (= v_1_cb_length_07 a!594)
                  a!648
                  a!649
                  (= v_1_cb_length_08 a!596)
                  a!650
                  a!651
                  (= v_1_cb_length_09 a!598)
                  a!652
                  a!653
                  (= v_1_cb_length_10 a!600)
                  a!654
                  a!655
                  (= v_1_cb_length_11 a!602)
                  a!656
                  a!657
                  (= v_1_cb_length_12 a!604)
                  a!658
                  a!659
                  (= v_1_cb_length_13 a!606)
                  a!660
                  a!661
                  (= v_1_cb_length_14 a!608)
                  a!662
                  a!663
                  (= v_1_cb_length_15 a!610)
                  a!664
                  a!665
                  (= active_1_rtx (or a!668 a!669))
                  (= active_1_user active_0_user)
                  (= active_1_time_wait active_0_time_wait)
                  (= active_1_delack
                     (and (not a!110) (not a!84) active_0_delack))
                  (= active_1_persist a!670)
                  a!671
                  (= due_1_user due_0_user)
                  (= due_1_time_wait due_0_time_wait)
                  (= due_1_delack due_0_delack)
                  (= due_1_persist (ite a!259 (+ now_1 a!260) due_0_persist))
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  (not active_0_user)
                  (not active_0_time_wait)
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  true
                  (<= 1000 v_0_rto_ms)
                  (<= 0 v_0_retries)
                  (<= 1 v_0_msl_ms)
                  (<= 1 v_0_user_timeout_ms)
                  true
                  (>= 16 (+ v_0_snd_buf v_0_rtx_buf))
                  (>= 16 v_0_rcv_buf)
                  (<= 0 v_0_snd_wnd)
                  (>= 65535 v_0_snd_wnd)
                  a!672
                  (>= 1 v_0_rx_slot_00)
                  (or (not (>= v_0_rcv_buf 16)) (= 0 v_0_rx_slot_00))
                  (>= 1 v_0_rx_slot_01)
                  (or (not (>= v_0_rcv_buf 15)) (= 0 v_0_rx_slot_01))
                  (>= 1 v_0_rx_slot_02)
                  (or (not (>= v_0_rcv_buf 14)) (= 0 v_0_rx_slot_02))
                  (>= 1 v_0_rx_slot_03)
                  (or (not (>= v_0_rcv_buf 13)) (= 0 v_0_rx_slot_03))
                  (>= 1 v_0_rx_slot_04)
                  (or (not (>= v_0_rcv_buf 12)) (= 0 v_0_rx_slot_04))
                  (>= 1 v_0_rx_slot_05)
                  (or (not (>= v_0_rcv_buf 11)) (= 0 v_0_rx_slot_05))
                  (>= 1 v_0_rx_slot_06)
                  (or (not (>= v_0_rcv_buf 10)) (= 0 v_0_rx_slot_06))
                  (>= 1 v_0_rx_slot_07)
                  (or (not (>= v_0_rcv_buf 9)) (= 0 v_0_rx_slot_07))
                  (>= 1 v_0_rx_slot_08)
                  (or (not (>= v_0_rcv_buf 8)) (= 0 v_0_rx_slot_08))
                  (>= 1 v_0_rx_slot_09)
                  (or (not (>= v_0_rcv_buf 7)) (= 0 v_0_rx_slot_09))
                  (>= 1 v_0_rx_slot_10)
                  (or (not (>= v_0_rcv_buf 6)) (= 0 v_0_rx_slot_10))
                  (>= 1 v_0_rx_slot_11)
                  (or (not (>= v_0_rcv_buf 5)) (= 0 v_0_rx_slot_11))
                  (>= 1 v_0_rx_slot_12)
                  (or (not (>= v_0_rcv_buf 4)) (= 0 v_0_rx_slot_12))
                  (>= 1 v_0_rx_slot_13)
                  (or (not (>= v_0_rcv_buf 3)) (= 0 v_0_rx_slot_13))
                  (>= 1 v_0_rx_slot_14)
                  (or (not (>= v_0_rcv_buf 2)) (= 0 v_0_rx_slot_14))
                  (>= 1 v_0_rx_slot_15)
                  (or (not (>= v_0_rcv_buf 1)) (= 0 v_0_rx_slot_15))
                  (= 0 v_0_rx_slot_00)
                  a!673
                  (<= 0 v_0_rx_advance)
                  (>= 16 v_0_rx_advance)
                  (= v_0_rx_chunk v_0_rx_advance)
                  (<= 0 v_0_ack_delta)
                  (>= 4294967295 v_0_ack_delta)
                  true
                  (= v_0_snd_nxt a!677)
                  (not v_0_fin_sent)
                  (not v_0_fin_requested)
                  true
                  true
                  true
                  true
                  true
                  (not v_0_rx_fin_done)
                  (or (not v_0_rx_fin_pending) a!678)
                  (<= 0 v_0_rx_fin_offset)
                  (>= 15 v_0_rx_fin_offset)
                  (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset))
                  (or (not v_0_rx_fin_pending) (= v_0_rx_fin_seq a!680))
                  (or (not v_0_rx_fin_done) (= v_0_rcv_nxt a!682))
                  a!683
                  a!684
                  a!685
                  a!686
                  a!687
                  a!688
                  a!689
                  a!690
                  a!691
                  a!692
                  a!693
                  a!694
                  a!695
                  a!696
                  a!697
                  a!698
                  (<= 0.0 v_0_srtt_ms)
                  (<= 0.0 v_0_rttvar_ms)
                  (<= 0.0 v_0_rtt_error_ms)
                  (<= 0.0 v_0_rtt_previous_srtt)
                  (<= 0.0 v_0_rtt_previous_var)
                  (<= 0 v_0_rtt_start_ms)
                  (<= 0 v_0_rtt_last_ms)
                  (<= 0 v_0_rtt_samples)
                  (<= 1000 v_0_rto_base_ms)
                  (>= 60000 v_0_rto_base_ms)
                  (>= v_0_rto_ms v_0_rto_base_ms)
                  (>= 60000 v_0_rto_ms)
                  a!702
                  (= v_0_rtt_measured (<= 1 v_0_rtt_samples))
                  (or (not v_0_rtt_active) a!711)
                  (or v_0_rtt_active (= 0 v_0_rtt_remaining))
                  true
                  (or (not v_0_rtt_sample_used)
                      (and (not v_0_rtt_sample_was_ambiguous)
                           v_0_rtt_measured
                           a!712))
                  (<= 0 v_0_rtt_sample_at_ms)
                  (<= v_0_rtt_sample_at_ms now_0)
                  (or (not v_0_rtt_sample_used)
                      (and (= v_0_rttvar_ms a!715) (= v_0_srtt_ms a!716)))
                  (<= 0 v_0_tx_time_00)
                  (<= v_0_tx_time_00 now_0)
                  (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00))
                  (<= 0 v_0_tx_time_01)
                  (<= v_0_tx_time_01 now_0)
                  (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))
                  (<= 0 v_0_tx_time_02)
                  (<= v_0_tx_time_02 now_0)
                  (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))
                  (<= 0 v_0_tx_time_03)
                  (<= v_0_tx_time_03 now_0)
                  (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))
                  (<= 0 v_0_tx_time_04)
                  (<= v_0_tx_time_04 now_0)
                  (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))
                  (<= 0 v_0_tx_time_05)
                  (<= v_0_tx_time_05 now_0)
                  (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))
                  (<= 0 v_0_tx_time_06)
                  (<= v_0_tx_time_06 now_0)
                  (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))
                  (<= 0 v_0_tx_time_07)
                  (<= v_0_tx_time_07 now_0)
                  (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))
                  (<= 0 v_0_tx_time_08)
                  (<= v_0_tx_time_08 now_0)
                  (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))
                  (<= 0 v_0_tx_time_09)
                  (<= v_0_tx_time_09 now_0)
                  (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))
                  (<= 0 v_0_tx_time_10)
                  (<= v_0_tx_time_10 now_0)
                  (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))
                  (<= 0 v_0_tx_time_11)
                  (<= v_0_tx_time_11 now_0)
                  (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))
                  (<= 0 v_0_tx_time_12)
                  (<= v_0_tx_time_12 now_0)
                  (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))
                  (<= 0 v_0_tx_time_13)
                  (<= v_0_tx_time_13 now_0)
                  (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))
                  (<= 0 v_0_tx_time_14)
                  (<= v_0_tx_time_14 now_0)
                  (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))
                  (<= 0 v_0_tx_time_15)
                  (<= v_0_tx_time_15 now_0)
                  (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))
                  (<= 0 v_0_tx_fin_time)
                  (<= v_0_tx_fin_time now_0)
                  (<= 0 v_0_tx_emit_count)
                  (>= 4 v_0_tx_emit_count)
                  (<= 0 v_0_tx_eligible)
                  (>= 4 v_0_tx_eligible)
                  (<= 0 v_0_tx_elapsed)
                  (<= 0 v_0_tx_max_previous)
                  (<= v_0_tx_max_previous now_0)
                  (<= 1000 v_0_tx_previous_rto)
                  (>= 60000 v_0_tx_previous_rto)
                  a!717
                  (or (not v_0_tx_retransmitted) (not v_0_tx_waiting))
                  (<= 0 v_0_tx_syn_time)
                  (<= v_0_tx_syn_time now_0)
                  (not v_0_tx_syn_pending)
                  (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time))
                  true
                  (<= 1 v_0_ack_delay_ms)
                  (>= 499 v_0_ack_delay_ms)
                  (= 4 v_0_ack_rmss)
                  (= v_0_ack_pending active_0_delack)
                  (<= 0 v_0_ack_bytes)
                  (>= 7 v_0_ack_bytes)
                  (<= 0 v_0_ack_full_segments)
                  (>= 1 v_0_ack_full_segments)
                  (<= 0 v_0_ack_since_ms)
                  (<= v_0_ack_since_ms now_0)
                  (or (not v_0_ack_pending)
                      (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))
                  a!718
                  (= v_0_persist_active active_0_persist)
                  (= active_0_rtx a!719)
                  a!720
                  (or (not v_0_persist_active)
                      (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))
                  (<= 1000 v_0_persist_interval_ms)
                  (>= 60000 v_0_persist_interval_ms)
                  (<= 1000 v_0_persist_previous_interval_ms)
                  (>= 60000 v_0_persist_previous_interval_ms)
                  (<= 0 v_0_persist_probes)
                  (<= 0 v_0_persist_elapsed_ms)
                  (<= 0 v_0_persist_since_ms)
                  (<= v_0_persist_since_ms now_0)
                  (<= 0 v_0_persist_last_ms)
                  (<= v_0_persist_last_ms now_0)
                  (<= 0 v_0_persist_deadline_ms)
                  (or (not v_0_persist_active) a!721)
                  a!722
                  a!723
                  a!724
                  (<= 4 v_0_cc_initial_window)
                  (>= 16 v_0_cc_initial_window)
                  (<= 8 v_0_cc_initial_threshold)
                  (<= 4 v_0_cc_cwnd)
                  (<= 8 v_0_cc_ssthresh)
                  (<= 0 v_0_cc_ca_credit)
                  (not (>= v_0_cc_ca_credit v_0_cc_cwnd))
                  (<= 0 v_0_cc_growth)
                  (>= 4 v_0_cc_growth)
                  (<= 0 v_0_cc_acked)
                  (>= 16 v_0_cc_acked)
                  (<= 0 v_0_cc_threshold_updates)
                  (<= 0 v_0_cc_new_sent)
                  (<= v_0_cc_new_sent v_0_cc_send_budget)
                  (or (not v_0_cc_rto_00) (not (>= 0 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_01) (not (>= 1 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_02) (not (>= 2 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_03) (not (>= 3 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_04) (not (>= 4 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_05) (not (>= 5 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_06) (not (>= 6 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_07) (not (>= 7 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_08) (not (>= 8 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_09) (not (>= 9 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_10) (not (>= 10 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_11) (not (>= 11 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_12) (not (>= 12 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_13) (not (>= 13 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_14) (not (>= 14 v_0_rtx_buf)))
                  (or (not v_0_cc_rto_15) (not (>= 15 v_0_rtx_buf)))
                  (<= 0 v_0_fr_dupacks)
                  (<= 0 v_0_fr_entries)
                  (<= 0 v_0_fr_emit_count)
                  (>= 4 v_0_fr_emit_count)
                  (<= 0 v_0_fr_last_window)
                  (>= 65535 v_0_fr_last_window)
                  a!725
                  a!726
                  a!727
                  (or v_0_fr_retransmitted (not v_0_fr_entered))
                  (or (not v_0_fr_entered)
                      (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))
                  a!728
                  (<= 0 v_0_idle_last_data_ms)
                  (<= v_0_idle_last_data_ms v_0_idle_event_ms)
                  (<= v_0_idle_event_ms now_0)
                  (<= 0 v_0_idle_elapsed_ms)
                  (<= 0 v_0_idle_restart_count)
                  (or (not v_0_idle_data_emitted)
                      (= v_0_idle_last_data_ms v_0_idle_event_ms))
                  (or (not v_0_idle_restart) a!729)
                  (<= 0 v_0_lt_epoch_bytes)
                  (>= 8 v_0_lt_epoch_bytes)
                  (<= v_0_lt_epoch_bytes v_0_rtx_buf)
                  (<= 0 v_0_lt_epoch_packets)
                  (>= 2 v_0_lt_epoch_packets)
                  (<= v_0_lt_epoch_packets v_0_fr_dupacks)
                  (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets)
                  (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets))
                  (<= 0 v_0_lt_loss_flight)
                  a!732
                  (or (not v_0_fr_entered) a!733)
                  (<= 0 v_0_choice_count)
                  (>= 4 v_0_choice_count)
                  (<= 0 v_0_choice_limit)
                  (>= 4 v_0_choice_limit)
                  a!736
                  (<= 0 v_0_sched_packets)
                  (<= v_0_sched_packets v_0_sched_bytes)
                  (<= v_0_sched_bytes (* 4 v_0_sched_packets))
                  (>= 16 (+ v_0_sched_bytes v_0_snd_buf))
                  (<= 0 v_0_sched_at_ms)
                  (<= v_0_sched_at_ms now_0)
                  (or (not v_0_sched_open)
                      (= 1 v_0_sched_cause)
                      (= 2 v_0_sched_cause))
                  (or (not v_0_choice_used)
                      (and v_0_sched_open (= v_0_sched_at_ms v_0_idle_event_ms)))
                  (<= 0 v_0_svc_written_bytes)
                  (<= 0 v_0_svc_acked_bytes)
                  (<= 0 v_0_svc_abandoned_bytes)
                  (= v_0_svc_written_bytes
                     (+ v_0_svc_acked_bytes
                        v_0_svc_abandoned_bytes
                        v_0_snd_buf
                        v_0_rtx_buf))
                  (= v_0_svc_ack_step v_0_cc_acked)
                  (<= 0 v_0_svc_accept_step)
                  (<= 0 v_0_svc_ack_step)
                  (<= 0 v_0_svc_drop_step)
                  (<= 0 v_0_cb_head)
                  (not (<= 16 v_0_cb_head))
                  (<= 0 v_0_cb_tail)
                  (not (<= 16 v_0_cb_tail))
                  (<= 0 v_0_cb_count)
                  (<= v_0_cb_count v_0_rtx_buf)
                  a!737
                  (<= 0 v_0_cb_new_count)
                  (>= 1 v_0_cb_new_count)
                  (<= 0 v_0_cb_emitted_total)
                  (<= 0 v_0_cb_acked_total)
                  (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix)
                      v_0_svc_acked_bytes)
                  (<= v_0_cb_emitted_total v_0_svc_written_bytes)
                  (<= 0 v_0_cb_abandoned_total)
                  (<= 0 v_0_cb_step_bytes)
                  (>= 19 v_0_cb_step_bytes)
                  (<= 0 v_0_cb_drop_step)
                  (= v_0_cb_emitted_total
                     (+ v_0_cb_acked_total
                        v_0_cb_abandoned_total
                        v_0_cb_live_total))
                  a!738
                  a!739
                  (<= 0 v_0_cb_partial_prefix)
                  (>= 3 v_0_cb_partial_prefix)
                  (<= (+ v_0_cb_emitted_total v_0_snd_buf)
                      v_0_svc_written_bytes)
                  (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00))
                      (>= a!376 v_0_cb_count))
                  (or (not (>= a!376 v_0_cb_count))
                      (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00)))
                  (or a!740 a!749)
                  (or a!750 (= v_0_cb_end_00 a!752))
                  (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01))
                      (>= a!387 v_0_cb_count))
                  (or (not (>= a!387 v_0_cb_count))
                      (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01)))
                  (or a!753 a!762)
                  (or a!763 (= v_0_cb_end_01 a!765))
                  (or (>= a!398 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)))
                  (or (not (>= a!398 v_0_cb_count))
                      (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02)))
                  (or a!766 a!775)
                  (or a!776 (= v_0_cb_end_02 a!778))
                  (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03))
                      (>= a!409 v_0_cb_count))
                  (or (not (>= a!409 v_0_cb_count))
                      (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03)))
                  (or a!779 a!788)
                  (or a!789 (= v_0_cb_end_03 a!791))
                  (or (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04))
                      (>= a!420 v_0_cb_count))
                  (or (not (>= a!420 v_0_cb_count))
                      (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04)))
                  (or a!792 a!801)
                  (or a!802 (= v_0_cb_end_04 a!804))
                  (or (>= a!431 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))
                  (or (not (>= a!431 v_0_cb_count))
                      (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05)))
                  (or a!805 a!814)
                  (or a!815 (= v_0_cb_end_05 a!817))
                  (or (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06))
                      (>= a!442 v_0_cb_count))
                  (or (not (>= a!442 v_0_cb_count))
                      (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06)))
                  (or a!818 a!827)
                  (or a!828 (= v_0_cb_end_06 a!830))
                  (or (>= a!453 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))
                  (or (not (>= a!453 v_0_cb_count))
                      (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07)))
                  (or a!831 a!840)
                  (or a!841 (= v_0_cb_end_07 a!843))
                  (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08))
                      (>= a!464 v_0_cb_count))
                  (or (not (>= a!464 v_0_cb_count))
                      (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08)))
                  (or a!844 a!853)
                  (or a!854 (= v_0_cb_end_08 a!856))
                  (or (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09))
                      (>= a!475 v_0_cb_count))
                  (or (not (>= a!475 v_0_cb_count))
                      (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09)))
                  (or a!857 a!866)
                  (or a!867 (= v_0_cb_end_09 a!869))
                  (or (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10))
                      (>= a!486 v_0_cb_count))
                  (or (not (>= a!486 v_0_cb_count))
                      (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10)))
                  (or a!870 a!879)
                  (or a!880 (= v_0_cb_end_10 a!882))
                  (or (>= a!497 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)))
                  (or (not (>= a!497 v_0_cb_count))
                      (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11)))
                  (or a!883 a!892)
                  (or a!893 (= v_0_cb_end_11 a!895))
                  (or (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12))
                      (>= a!508 v_0_cb_count))
                  (or (not (>= a!508 v_0_cb_count))
                      (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12)))
                  (or a!896 a!905)
                  (or a!906 (= v_0_cb_end_12 a!908))
                  (or (>= a!519 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)))
                  (or (not (>= a!519 v_0_cb_count))
                      (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13)))
                  (or a!909 a!918)
                  (or a!919 (= v_0_cb_end_13 a!921))
                  (or (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14))
                      (>= a!530 v_0_cb_count))
                  (or (not (>= a!530 v_0_cb_count))
                      (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14)))
                  (or a!922 a!931)
                  (or a!932 (= v_0_cb_end_14 a!934))
                  (or (>= a!541 v_0_cb_count)
                      (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)))
                  (or (not (>= a!541 v_0_cb_count))
                      (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15)))
                  (or a!935 a!944)
                  (or a!945 (= v_0_cb_end_15 a!947))
                  (= 85 choice_0)
                  (= 4 state_0)
                  (= 4 state_1)
                  (or (not (<= v_1_cb_count v_1_rtx_buf)))))
      (a!1359 (ite (<= 16 (+ a!1356 a!1357 (ite a!1358 1 0)))
                   (+ (- 16) a!1356 a!1357 (ite a!1358 1 0))
                   (+ a!1356 a!1357 (ite a!1358 1 0))))
      (a!1363 (and (= 1 (+ a!1357 (ite a!1358 1 0))) a!1362))
      (a!1366 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 1) a!1365))
      (a!1368 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 2) a!1365))
      (a!1370 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 3) a!1365))
      (a!1372 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 4) a!1365))
      (a!1374 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 5) a!1365))
      (a!1376 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 6) a!1365))
      (a!1378 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 7) a!1365))
      (a!1380 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 8) a!1365))
      (a!1382 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 9) a!1365))
      (a!1384 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 10) a!1365))
      (a!1386 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 11) a!1365))
      (a!1388 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 12) a!1365))
      (a!1390 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 13) a!1365))
      (a!1392 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 14) a!1365))
      (a!1394 (and (= 1 (+ a!1357 (ite a!1358 1 0))) (= v_0_cb_tail 15) a!1365)))
(let ((a!1396 (= v_1_cb_live_total
                 (+ (ite a!1363 a!1361 (ite a!1364 0 v_0_cb_length_00))
                    (ite a!1366 a!1361 (ite a!1367 0 v_0_cb_length_01))
                    (ite a!1368 a!1361 (ite a!1369 0 v_0_cb_length_02))
                    (ite a!1370 a!1361 (ite a!1371 0 v_0_cb_length_03))
                    (ite a!1372 a!1361 (ite a!1373 0 v_0_cb_length_04))
                    (ite a!1374 a!1361 (ite a!1375 0 v_0_cb_length_05))
                    (ite a!1376 a!1361 (ite a!1377 0 v_0_cb_length_06))
                    (ite a!1378 a!1361 (ite a!1379 0 v_0_cb_length_07))
                    (ite a!1380 a!1361 (ite a!1381 0 v_0_cb_length_08))
                    (ite a!1382 a!1361 (ite a!1383 0 v_0_cb_length_09))
                    (ite a!1384 a!1361 (ite a!1385 0 v_0_cb_length_10))
                    (ite a!1386 a!1361 (ite a!1387 0 v_0_cb_length_11))
                    (ite a!1388 a!1361 (ite a!1389 0 v_0_cb_length_12))
                    (ite a!1390 a!1361 (ite a!1391 0 v_0_cb_length_13))
                    (ite a!1392 a!1361 (ite a!1393 0 v_0_cb_length_14))
                    (ite a!1394 a!1361 (ite a!1395 0 v_0_cb_length_15)))))
      (a!1397 (+ (ite a!1363 a!1361 (ite a!1364 0 v_0_cb_length_00))
                 (ite a!1366 a!1361 (ite a!1367 0 v_0_cb_length_01))
                 (ite a!1368 a!1361 (ite a!1369 0 v_0_cb_length_02))
                 (ite a!1370 a!1361 (ite a!1371 0 v_0_cb_length_03))
                 (ite a!1372 a!1361 (ite a!1373 0 v_0_cb_length_04))
                 (ite a!1374 a!1361 (ite a!1375 0 v_0_cb_length_05))
                 (ite a!1376 a!1361 (ite a!1377 0 v_0_cb_length_06))
                 (ite a!1378 a!1361 (ite a!1379 0 v_0_cb_length_07))
                 (ite a!1380 a!1361 (ite a!1381 0 v_0_cb_length_08))
                 (ite a!1382 a!1361 (ite a!1383 0 v_0_cb_length_09))
                 (ite a!1384 a!1361 (ite a!1385 0 v_0_cb_length_10))
                 (ite a!1386 a!1361 (ite a!1387 0 v_0_cb_length_11))
                 (ite a!1388 a!1361 (ite a!1389 0 v_0_cb_length_12))
                 (ite a!1390 a!1361 (ite a!1391 0 v_0_cb_length_13))
                 (ite a!1392 a!1361 (ite a!1393 0 v_0_cb_length_14))
                 (ite a!1394 a!1361 (ite a!1395 0 v_0_cb_length_15))
                 (* (- 1) (ite a!1022 (+ a!986 a!1035) a!986)))))
(let ((a!1492 (and (>= v_0_snd_buf 0)
                   (>= v_0_rtx_buf 0)
                   (>= v_0_rcv_buf 0)
                   (>= v_0_rx_chunk 0)
                   (>= v_0_rx_slot_00 0)
                   (>= v_0_rx_slot_01 0)
                   (>= v_0_rx_slot_02 0)
                   (>= v_0_rx_slot_03 0)
                   (>= v_0_rx_slot_04 0)
                   (>= v_0_rx_slot_05 0)
                   (>= v_0_rx_slot_06 0)
                   (>= v_0_rx_slot_07 0)
                   (>= v_0_rx_slot_08 0)
                   (>= v_0_rx_slot_09 0)
                   (>= v_0_rx_slot_10 0)
                   (>= v_0_rx_slot_11 0)
                   (>= v_0_rx_slot_12 0)
                   (>= v_0_rx_slot_13 0)
                   (>= v_0_rx_slot_14 0)
                   (>= v_0_rx_slot_15 0)
                   (>= v_1_snd_buf 0)
                   (>= v_1_rtx_buf 0)
                   (>= v_1_rcv_buf 0)
                   (>= v_1_rx_chunk 0)
                   (>= v_1_rx_slot_00 0)
                   (>= v_1_rx_slot_01 0)
                   (>= v_1_rx_slot_02 0)
                   (>= v_1_rx_slot_03 0)
                   (>= v_1_rx_slot_04 0)
                   (>= v_1_rx_slot_05 0)
                   (>= v_1_rx_slot_06 0)
                   (>= v_1_rx_slot_07 0)
                   (>= v_1_rx_slot_08 0)
                   (>= v_1_rx_slot_09 0)
                   (>= v_1_rx_slot_10 0)
                   (>= v_1_rx_slot_11 0)
                   (>= v_1_rx_slot_12 0)
                   (>= v_1_rx_slot_13 0)
                   (>= v_1_rx_slot_14 0)
                   (>= v_1_rx_slot_15 0)
                   (>= v_0_iss 0)
                   (not (<= 4294967296 v_0_iss))
                   (>= v_0_irs 0)
                   (not (<= 4294967296 v_0_irs))
                   (>= v_0_snd_una 0)
                   (not (<= 4294967296 v_0_snd_una))
                   (>= v_0_snd_nxt 0)
                   (not (<= 4294967296 v_0_snd_nxt))
                   (>= v_0_rcv_nxt 0)
                   (not (<= 4294967296 v_0_rcv_nxt))
                   (>= v_0_tx_seq 0)
                   (not (<= 4294967296 v_0_tx_seq))
                   (>= v_0_tx_ack 0)
                   (not (<= 4294967296 v_0_tx_ack))
                   (>= v_0_snd_wl1 0)
                   (not (<= 4294967296 v_0_snd_wl1))
                   (>= v_0_snd_wl2 0)
                   (not (<= 4294967296 v_0_snd_wl2))
                   (>= v_0_fin_seq 0)
                   (not (<= 4294967296 v_0_fin_seq))
                   (>= v_0_rx_fin_seq 0)
                   (not (<= 4294967296 v_0_rx_fin_seq))
                   (>= v_0_rtt_end 0)
                   (not (<= 4294967296 v_0_rtt_end))
                   (>= v_0_cc_before_una 0)
                   (not (<= 4294967296 v_0_cc_before_una))
                   (>= v_0_fr_before_una 0)
                   (not (<= 4294967296 v_0_fr_before_una))
                   (>= v_0_fr_before_nxt 0)
                   (not (<= 4294967296 v_0_fr_before_nxt))
                   (>= v_0_lt_before_nxt 0)
                   (not (<= 4294967296 v_0_lt_before_nxt))
                   (>= v_0_choice_before_nxt 0)
                   (not (<= 4294967296 v_0_choice_before_nxt))
                   (>= v_0_cb_before_nxt 0)
                   (not (<= 4294967296 v_0_cb_before_nxt))
                   (>= v_0_cb_append_end 0)
                   (not (<= 4294967296 v_0_cb_append_end))
                   (>= v_0_cb_end_00 0)
                   (not (<= 4294967296 v_0_cb_end_00))
                   (>= v_0_cb_end_01 0)
                   (not (<= 4294967296 v_0_cb_end_01))
                   (>= v_0_cb_end_02 0)
                   (not (<= 4294967296 v_0_cb_end_02))
                   (>= v_0_cb_end_03 0)
                   (not (<= 4294967296 v_0_cb_end_03))
                   (>= v_0_cb_end_04 0)
                   (not (<= 4294967296 v_0_cb_end_04))
                   (>= v_0_cb_end_05 0)
                   (not (<= 4294967296 v_0_cb_end_05))
                   (>= v_0_cb_end_06 0)
                   (not (<= 4294967296 v_0_cb_end_06))
                   (>= v_0_cb_end_07 0)
                   (not (<= 4294967296 v_0_cb_end_07))
                   (>= v_0_cb_end_08 0)
                   (not (<= 4294967296 v_0_cb_end_08))
                   (>= v_0_cb_end_09 0)
                   (not (<= 4294967296 v_0_cb_end_09))
                   (>= v_0_cb_end_10 0)
                   (not (<= 4294967296 v_0_cb_end_10))
                   (>= v_0_cb_end_11 0)
                   (not (<= 4294967296 v_0_cb_end_11))
                   (>= v_0_cb_end_12 0)
                   (not (<= 4294967296 v_0_cb_end_12))
                   (>= v_0_cb_end_13 0)
                   (not (<= 4294967296 v_0_cb_end_13))
                   (>= v_0_cb_end_14 0)
                   (not (<= 4294967296 v_0_cb_end_14))
                   (>= v_0_cb_end_15 0)
                   (not (<= 4294967296 v_0_cb_end_15))
                   (>= v_1_iss 0)
                   (not (<= 4294967296 v_1_iss))
                   (>= v_1_irs 0)
                   (not (<= 4294967296 v_1_irs))
                   (>= v_1_snd_una 0)
                   (not (<= 4294967296 v_1_snd_una))
                   (>= v_1_snd_nxt 0)
                   (not (<= 4294967296 v_1_snd_nxt))
                   (>= v_1_rcv_nxt 0)
                   (not (<= 4294967296 v_1_rcv_nxt))
                   (>= v_1_tx_seq 0)
                   (not (<= 4294967296 v_1_tx_seq))
                   (>= v_1_tx_ack 0)
                   (not (<= 4294967296 v_1_tx_ack))
                   (>= v_1_snd_wl1 0)
                   (not (<= 4294967296 v_1_snd_wl1))
                   (>= v_1_snd_wl2 0)
                   (not (<= 4294967296 v_1_snd_wl2))
                   (>= v_1_fin_seq 0)
                   (not (<= 4294967296 v_1_fin_seq))
                   (>= v_1_rx_fin_seq 0)
                   (not (<= 4294967296 v_1_rx_fin_seq))
                   (>= v_1_rtt_end 0)
                   (not (<= 4294967296 v_1_rtt_end))
                   (>= v_1_cc_before_una 0)
                   (not (<= 4294967296 v_1_cc_before_una))
                   (>= v_1_fr_before_una 0)
                   (not (<= 4294967296 v_1_fr_before_una))
                   (>= v_1_fr_before_nxt 0)
                   (not (<= 4294967296 v_1_fr_before_nxt))
                   (>= v_1_lt_before_nxt 0)
                   (not (<= 4294967296 v_1_lt_before_nxt))
                   (>= v_1_choice_before_nxt 0)
                   (not (<= 4294967296 v_1_choice_before_nxt))
                   (>= v_1_cb_before_nxt 0)
                   (not (<= 4294967296 v_1_cb_before_nxt))
                   (>= v_1_cb_append_end 0)
                   (not (<= 4294967296 v_1_cb_append_end))
                   (>= v_1_cb_end_00 0)
                   (not (<= 4294967296 v_1_cb_end_00))
                   (>= v_1_cb_end_01 0)
                   (not (<= 4294967296 v_1_cb_end_01))
                   (>= v_1_cb_end_02 0)
                   (not (<= 4294967296 v_1_cb_end_02))
                   (>= v_1_cb_end_03 0)
                   (not (<= 4294967296 v_1_cb_end_03))
                   (>= v_1_cb_end_04 0)
                   (not (<= 4294967296 v_1_cb_end_04))
                   (>= v_1_cb_end_05 0)
                   (not (<= 4294967296 v_1_cb_end_05))
                   (>= v_1_cb_end_06 0)
                   (not (<= 4294967296 v_1_cb_end_06))
                   (>= v_1_cb_end_07 0)
                   (not (<= 4294967296 v_1_cb_end_07))
                   (>= v_1_cb_end_08 0)
                   (not (<= 4294967296 v_1_cb_end_08))
                   (>= v_1_cb_end_09 0)
                   (not (<= 4294967296 v_1_cb_end_09))
                   (>= v_1_cb_end_10 0)
                   (not (<= 4294967296 v_1_cb_end_10))
                   (>= v_1_cb_end_11 0)
                   (not (<= 4294967296 v_1_cb_end_11))
                   (>= v_1_cb_end_12 0)
                   (not (<= 4294967296 v_1_cb_end_12))
                   (>= v_1_cb_end_13 0)
                   (not (<= 4294967296 v_1_cb_end_13))
                   (>= v_1_cb_end_14 0)
                   (not (<= 4294967296 v_1_cb_end_14))
                   (>= v_1_cb_end_15 0)
                   (not (<= 4294967296 v_1_cb_end_15))
                   (>= now_0 0)
                   (or (not active_0_rtx) (>= due_0_rtx now_0))
                   (or (not active_0_user) (>= due_0_user now_0))
                   (or (not active_0_time_wait) (>= due_0_time_wait now_0))
                   (or (not active_0_delack) (>= due_0_delack now_0))
                   (or (not active_0_persist) (>= due_0_persist now_0))
                   (>= input_0_app.send_data 0)
                   (>= input_0_net.data_data 0)
                   (>= input_0_net.fin_segment_data 0)
                   (>= input_0_net.syn_seq 0)
                   (not (<= 4294967296 input_0_net.syn_seq))
                   (>= input_0_net.synack_seq 0)
                   (not (<= 4294967296 input_0_net.synack_seq))
                   (>= input_0_net.synack_ack 0)
                   (not (<= 4294967296 input_0_net.synack_ack))
                   (>= input_0_net.ack_seq 0)
                   (not (<= 4294967296 input_0_net.ack_seq))
                   (>= input_0_net.ack_ack 0)
                   (not (<= 4294967296 input_0_net.ack_ack))
                   (>= input_0_net.fin_seq 0)
                   (not (<= 4294967296 input_0_net.fin_seq))
                   (>= input_0_net.fin_ack 0)
                   (not (<= 4294967296 input_0_net.fin_ack))
                   (>= input_0_net.rst_seq 0)
                   (not (<= 4294967296 input_0_net.rst_seq))
                   (>= input_0_net.rstack_seq 0)
                   (not (<= 4294967296 input_0_net.rstack_seq))
                   (>= input_0_net.rstack_ack 0)
                   (not (<= 4294967296 input_0_net.rstack_ack))
                   (>= input_0_net.data_seq 0)
                   (not (<= 4294967296 input_0_net.data_seq))
                   (>= input_0_net.data_ack 0)
                   (not (<= 4294967296 input_0_net.data_ack))
                   (>= input_0_net.fin_segment_seq 0)
                   (not (<= 4294967296 input_0_net.fin_segment_seq))
                   (>= input_0_net.fin_segment_ack 0)
                   (not (<= 4294967296 input_0_net.fin_segment_ack))
                   (>= now_1 now_0)
                   (<= 0 input_0_net.ack_window)
                   (>= 65535 input_0_net.ack_window)
                   (not (= a!953 2147483648))
                   a!959
                   (not (= a!964 2147483648))
                   (not (= a!969 2147483648))
                   a!970
                   (or (not active_0_rtx) (not (<= due_0_rtx now_1)))
                   (or (not active_0_user) (not (<= due_0_user now_1)))
                   (or (not active_0_time_wait)
                       (not (<= due_0_time_wait now_1)))
                   (or (not active_0_delack) (not (<= due_0_delack now_1)))
                   (or (not active_0_persist) (not (<= due_0_persist now_1)))
                   (= v_1_iss v_0_iss)
                   (= v_1_irs v_0_irs)
                   (= v_1_snd_una a!971)
                   (= v_1_snd_nxt (ite a!1022 a!1029 v_0_snd_nxt))
                   (= v_1_rcv_nxt v_0_rcv_nxt)
                   (= v_1_tx_seq v_0_tx_seq)
                   (= v_1_tx_ack v_0_tx_ack)
                   (= v_1_tx_flags v_0_tx_flags)
                   a!1030
                   (= v_1_retries v_0_retries)
                   (= v_1_active_open v_0_active_open)
                   (= v_1_user_timeout_ms v_0_user_timeout_ms)
                   (= v_1_msl_ms v_0_msl_ms)
                   (= v_1_local_window v_0_local_window)
                   (= v_1_snd_buf (ite a!1022 a!1034 v_0_snd_buf))
                   (= v_1_rtx_buf (ite a!1022 (+ a!986 a!1035) a!986))
                   (= v_1_rcv_buf v_0_rcv_buf)
                   a!1036
                   a!1037
                   a!1038
                   a!1039
                   (= v_1_rx_chunk v_0_rx_chunk)
                   (= v_1_rx_slot_00 v_0_rx_slot_00)
                   (= v_1_rx_slot_01 v_0_rx_slot_01)
                   (= v_1_rx_slot_02 v_0_rx_slot_02)
                   (= v_1_rx_slot_03 v_0_rx_slot_03)
                   (= v_1_rx_slot_04 v_0_rx_slot_04)
                   (= v_1_rx_slot_05 v_0_rx_slot_05)
                   (= v_1_rx_slot_06 v_0_rx_slot_06)
                   (= v_1_rx_slot_07 v_0_rx_slot_07)
                   (= v_1_rx_slot_08 v_0_rx_slot_08)
                   (= v_1_rx_slot_09 v_0_rx_slot_09)
                   (= v_1_rx_slot_10 v_0_rx_slot_10)
                   (= v_1_rx_slot_11 v_0_rx_slot_11)
                   (= v_1_rx_slot_12 v_0_rx_slot_12)
                   (= v_1_rx_slot_13 v_0_rx_slot_13)
                   (= v_1_rx_slot_14 v_0_rx_slot_14)
                   (= v_1_rx_slot_15 v_0_rx_slot_15)
                   (= v_1_rx_advance v_0_rx_advance)
                   (= v_1_rx_acceptable v_0_rx_acceptable)
                   (= v_1_seg_acceptable a!959)
                   (= v_1_ack_delta a!964)
                   (= v_1_ack_is_new (and (<= 1 a!964) (<= a!964 v_0_rtx_buf)))
                   a!1040
                   (= v_1_ack_advance
                      (and a!959 (<= 1 a!964) (<= a!964 v_0_rtx_buf)))
                   (= v_1_ack_window_update
                      (and a!959 (<= a!964 v_0_rtx_buf) a!982))
                   (= v_1_fin_requested v_0_fin_requested)
                   (= v_1_fin_sent v_0_fin_sent)
                   (= v_1_fin_seq v_0_fin_seq)
                   (= v_1_fin_acknowledged v_0_fin_acknowledged)
                   (= v_1_rx_fin_pending v_0_rx_fin_pending)
                   (= v_1_rx_fin_seq v_0_rx_fin_seq)
                   (= v_1_rx_fin_offset v_0_rx_fin_offset)
                   (= v_1_rx_fin_done v_0_rx_fin_done)
                   (= v_1_rx_fin_consumed v_0_rx_fin_consumed)
                   (= v_1_srtt_ms a!1015)
                   (= v_1_rttvar_ms (ite a!1013 a!1017 v_0_rttvar_ms))
                   (= v_1_rtt_error_ms (ite a!1013 a!1016 v_0_rtt_error_ms))
                   (= v_1_rtt_previous_srtt
                      (ite a!1013 v_0_srtt_ms v_0_rtt_previous_srtt))
                   (= v_1_rtt_previous_var
                      (ite a!1013 v_0_rttvar_ms v_0_rtt_previous_var))
                   (= v_1_rtt_measured (or v_0_rtt_measured a!1013))
                   (= v_1_rtt_previous_measured
                      (ite a!1013 v_0_rtt_measured v_0_rtt_previous_measured))
                   a!1042
                   a!1054
                   (= v_1_rtt_sample_at_ms
                      (ite a!1013 now_1 v_0_rtt_sample_at_ms))
                   (= v_1_rtt_start_ms (ite a!1053 now_1 v_0_rtt_start_ms))
                   (= v_1_rtt_end a!1057)
                   (= v_1_rtt_remaining (ite a!1053 a!1035 a!1049))
                   (= v_1_rtt_start_new a!1053)
                   (= v_1_rtt_sample_used a!1013)
                   (= v_1_rtt_sample_was_ambiguous
                      (and v_0_rtt_active v_0_rtt_ambiguous))
                   a!1058
                   (= v_1_rtt_samples (+ v_0_rtt_samples (ite a!1013 1 0)))
                   a!1059
                   (= v_1_tx_time_00 a!1068)
                   (= v_1_tx_time_01 a!1077)
                   (= v_1_tx_time_02 a!1086)
                   (= v_1_tx_time_03 a!1094)
                   (= v_1_tx_time_04 a!1102)
                   (= v_1_tx_time_05 a!1110)
                   (= v_1_tx_time_06 a!1117)
                   (= v_1_tx_time_07 a!1124)
                   (= v_1_tx_time_08 a!1131)
                   (= v_1_tx_time_09 a!1137)
                   (= v_1_tx_time_10 a!1143)
                   (= v_1_tx_time_11 a!1149)
                   (= v_1_tx_time_12 a!1154)
                   (= v_1_tx_time_13 a!1159)
                   (= v_1_tx_time_14 a!1164)
                   (= v_1_tx_time_15 a!1168)
                   a!258
                   (= v_1_tx_emit_count v_0_tx_emit_count)
                   (= v_1_tx_eligible v_0_tx_eligible)
                   (= v_1_tx_max_previous v_0_tx_max_previous)
                   (not v_1_tx_retransmitted)
                   (= v_1_tx_elapsed v_0_tx_elapsed)
                   (= v_1_tx_previous_rto v_0_tx_previous_rto)
                   (= v_1_tx_is_fin v_0_tx_is_fin)
                   (not v_1_tx_waiting)
                   (= v_1_tx_syn_time 0)
                   (not v_1_tx_syn_pending)
                   (not v_1_syn_timeout_eligible)
                   (= v_1_ack_pending
                      (and (not a!1022) (not a!1002) v_0_ack_pending))
                   (= v_1_ack_since_ms
                      (ite (or a!1002 a!1022) 0 v_0_ack_since_ms))
                   (= v_1_ack_bytes (ite (or a!1002 a!1022) 0 v_0_ack_bytes))
                   (= v_1_ack_full_segments
                      (ite (or a!1002 a!1022) 0 v_0_ack_full_segments))
                   (= v_1_ack_delay_ms v_0_ack_delay_ms)
                   (= v_1_ack_rmss v_0_ack_rmss)
                   (not v_1_ack_defer_candidate)
                   (not v_1_ack_defer_now)
                   (= v_1_persist_active a!987)
                   (= v_1_persist_eligible a!987)
                   (= v_1_persist_start a!1169)
                   (= v_1_persist_was_active v_0_persist_active)
                   (not v_1_persist_first)
                   (not v_1_persist_probe_sent)
                   (not v_1_persist_probe_new)
                   (= v_1_persist_interval_ms (ite a!987 a!1170 1000))
                   (= v_1_persist_previous_interval_ms
                      v_0_persist_previous_interval_ms)
                   (= v_1_persist_since_ms
                      (ite a!987 (ite a!1169 now_1 v_0_persist_since_ms) 0))
                   (= v_1_persist_last_ms (ite a!987 v_0_persist_last_ms 0))
                   a!1171
                   (= v_1_persist_probes (ite a!987 v_0_persist_probes 0))
                   (= v_1_persist_elapsed_ms v_0_persist_elapsed_ms)
                   (= v_1_cc_initial_window v_0_cc_initial_window)
                   (= v_1_cc_initial_threshold v_0_cc_initial_threshold)
                   (= v_1_cc_cwnd a!999)
                   (= v_1_cc_ssthresh (ite a!990 a!994 v_0_cc_ssthresh))
                   (= v_1_cc_ca_credit a!1174)
                   (= v_1_cc_acked a!995)
                   (= v_1_cc_before_flight v_0_rtx_buf)
                   (= v_1_cc_before_una v_0_snd_una)
                   (= v_1_cc_before_persist v_0_persist_active)
                   (= v_1_cc_before_window v_0_snd_wnd)
                   (not v_1_cc_loss)
                   (not v_1_cc_threshold_changed)
                   (= v_1_cc_threshold_updates v_0_cc_threshold_updates)
                   (= v_1_cc_growth (ite a!996 0 a!997))
                   (= v_1_cc_before_cwnd v_0_cc_cwnd)
                   (= v_1_cc_send_budget (ite (<= 0 a!1175) a!1175 0))
                   (= 0 v_1_cc_new_sent)
                   (= v_1_cc_rto_00 a!1195)
                   a!1200
                   a!1205
                   a!1210
                   (= v_1_cc_rto_04 a!1214)
                   a!1218
                   a!1222
                   a!1226
                   (= v_1_cc_rto_08 a!1229)
                   a!1232
                   a!1235
                   a!1238
                   (= v_1_cc_rto_12 a!1240)
                   a!1242
                   a!1244
                   a!1245
                   (not v_1_fr_window_ignored)
                   (= v_1_fr_before_wire_window v_0_fr_last_window)
                   (= v_1_fr_before_window_valid v_0_fr_window_valid)
                   (= v_1_fr_active a!991)
                   (= v_1_fr_dupacks a!988)
                   v_1_fr_window_valid
                   (= v_1_fr_last_window input_0_net.ack_window)
                   (= v_1_fr_was_active v_0_fr_active)
                   (= v_1_fr_before_una v_0_snd_una)
                   (= v_1_fr_before_nxt v_0_snd_nxt)
                   (= v_1_fr_before_flight v_0_rtx_buf)
                   (= v_1_fr_before_rto v_0_rto_ms)
                   (= v_1_fr_before_retries v_0_retries)
                   (= v_1_fr_duplicate a!66)
                   (= v_1_fr_entered a!990)
                   (= v_1_fr_extra a!77)
                   a!1246
                   (= v_1_fr_retransmitted a!1002)
                   a!1247
                   (= v_1_fr_entries (+ v_0_fr_entries (ite a!990 1 0)))
                   (= v_1_idle_data_valid a!1248)
                   (= v_1_idle_last_data_ms a!1250)
                   (= v_1_idle_event_ms now_1)
                   (= v_1_idle_data_emitted a!1251)
                   (not v_1_idle_restart)
                   a!1252
                   (= v_1_idle_before_cwnd v_0_cc_cwnd)
                   (= v_1_idle_before_rto v_0_rto_ms)
                   (= v_1_idle_before_threshold v_0_cc_ssthresh)
                   (= v_1_idle_restart_count v_0_idle_restart_count)
                   (= v_1_lt_eligible a!1022)
                   (= v_1_lt_emitted a!1022)
                   a!1253
                   (= v_1_lt_epoch_bytes a!1255)
                   (= v_1_lt_epoch_packets
                      (+ (ite a!1254 0 v_0_lt_epoch_packets) (ite a!1022 1 0)))
                   (= v_1_lt_before_bytes v_0_lt_epoch_bytes)
                   (= v_1_lt_before_cwnd v_0_cc_cwnd)
                   (= v_1_lt_before_nxt v_0_snd_nxt)
                   (= v_1_lt_before_flight v_0_rtx_buf)
                   (= v_1_lt_before_window v_0_snd_wnd)
                   (= v_1_lt_loss_flight
                      (+ v_0_rtx_buf (* (- 1) v_0_lt_epoch_bytes)))
                   (not v_1_choice_used)
                   (= v_1_choice_count v_0_choice_count)
                   (= v_1_choice_limit v_0_choice_limit)
                   (= v_1_choice_before_nxt v_0_choice_before_nxt)
                   (= v_1_choice_before_flight v_0_choice_before_flight)
                   v_1_sched_open
                   (= v_1_sched_at_ms now_1)
                   (= 2 v_1_sched_cause)
                   (= 0 v_1_sched_bytes)
                   (= 0 v_1_sched_packets)
                   (= v_1_svc_before_total (+ v_0_snd_buf v_0_rtx_buf))
                   (= 0 v_1_svc_accept_step)
                   (= v_1_svc_ack_step a!995)
                   (= v_1_svc_drop_step (ite (<= 0 a!1256) a!1256 0))
                   (= v_1_svc_written_bytes v_0_svc_written_bytes)
                   (= v_1_svc_acked_bytes (+ v_0_svc_acked_bytes a!995))
                   a!1257
                   (= v_1_cb_head a!1355)
                   (= v_1_cb_tail a!1359)
                   (= v_1_cb_count (+ a!1360 a!1357 (ite a!1358 1 0)))
                   (= v_1_cb_new_count (+ a!1357 (ite a!1358 1 0)))
                   (= v_1_cb_append_length a!1361)
                   (= v_1_cb_retired_count a!1354)
                   (= v_1_cb_step_bytes
                      (+ (ite a!1263 v_0_cb_length_00 0)
                         (ite a!1269 v_0_cb_length_01 0)
                         (ite a!1275 v_0_cb_length_02 0)
                         (ite a!1281 v_0_cb_length_03 0)
                         (ite a!1287 v_0_cb_length_04 0)
                         (ite a!1293 v_0_cb_length_05 0)
                         (ite a!1299 v_0_cb_length_06 0)
                         (ite a!1305 v_0_cb_length_07 0)
                         (ite a!1311 v_0_cb_length_08 0)
                         (ite a!1317 v_0_cb_length_09 0)
                         (ite a!1323 v_0_cb_length_10 0)
                         (ite a!1329 v_0_cb_length_11 0)
                         (ite a!1335 v_0_cb_length_12 0)
                         (ite a!1341 v_0_cb_length_13 0)
                         (ite a!1347 v_0_cb_length_14 0)
                         (ite a!1353 v_0_cb_length_15 0)))
                   a!1396
                   (= v_1_cb_partial_prefix a!1397)
                   (= v_1_cb_emitted_total (+ v_0_cb_emitted_total a!1361))
                   (= v_1_cb_acked_total
                      (+ v_0_cb_acked_total
                         (ite a!1263 v_0_cb_length_00 0)
                         (ite a!1269 v_0_cb_length_01 0)
                         (ite a!1275 v_0_cb_length_02 0)
                         (ite a!1281 v_0_cb_length_03 0)
                         (ite a!1287 v_0_cb_length_04 0)
                         (ite a!1293 v_0_cb_length_05 0)
                         (ite a!1299 v_0_cb_length_06 0)
                         (ite a!1305 v_0_cb_length_07 0)
                         (ite a!1311 v_0_cb_length_08 0)
                         (ite a!1317 v_0_cb_length_09 0)
                         (ite a!1323 v_0_cb_length_10 0)
                         (ite a!1329 v_0_cb_length_11 0)
                         (ite a!1335 v_0_cb_length_12 0)
                         (ite a!1341 v_0_cb_length_13 0)
                         (ite a!1347 v_0_cb_length_14 0)
                         (ite a!1353 v_0_cb_length_15 0)))
                   (= v_1_cb_abandoned_total (+ v_0_cb_abandoned_total a!1398))
                   (= v_1_cb_drop_step a!1398)
                   (= v_1_cb_before_nxt v_0_snd_nxt)
                   (= v_1_cb_append_end a!1402)
                   (= v_1_cb_is_new a!1358)
                   (= v_1_cb_length_00
                      (ite a!1363 a!1361 (ite a!1364 0 v_0_cb_length_00)))
                   (= v_1_cb_end_00
                      (ite a!1363 a!1402 (ite a!1364 0 v_0_cb_end_00)))
                   (= v_1_cb_done_00 a!1263)
                   (= v_1_cb_length_01
                      (ite a!1366 a!1361 (ite a!1367 0 v_0_cb_length_01)))
                   (= v_1_cb_end_01
                      (ite a!1366 a!1402 (ite a!1367 0 v_0_cb_end_01)))
                   (= v_1_cb_done_01 a!1269)
                   (= v_1_cb_length_02
                      (ite a!1368 a!1361 (ite a!1369 0 v_0_cb_length_02)))
                   (= v_1_cb_end_02
                      (ite a!1368 a!1402 (ite a!1369 0 v_0_cb_end_02)))
                   (= v_1_cb_done_02 a!1275)
                   (= v_1_cb_length_03
                      (ite a!1370 a!1361 (ite a!1371 0 v_0_cb_length_03)))
                   (= v_1_cb_end_03
                      (ite a!1370 a!1402 (ite a!1371 0 v_0_cb_end_03)))
                   (= v_1_cb_done_03 a!1281)
                   (= v_1_cb_length_04
                      (ite a!1372 a!1361 (ite a!1373 0 v_0_cb_length_04)))
                   (= v_1_cb_end_04
                      (ite a!1372 a!1402 (ite a!1373 0 v_0_cb_end_04)))
                   (= v_1_cb_done_04 a!1287)
                   (= v_1_cb_length_05
                      (ite a!1374 a!1361 (ite a!1375 0 v_0_cb_length_05)))
                   (= v_1_cb_end_05
                      (ite a!1374 a!1402 (ite a!1375 0 v_0_cb_end_05)))
                   (= v_1_cb_done_05 a!1293)
                   (= v_1_cb_length_06
                      (ite a!1376 a!1361 (ite a!1377 0 v_0_cb_length_06)))
                   (= v_1_cb_end_06
                      (ite a!1376 a!1402 (ite a!1377 0 v_0_cb_end_06)))
                   (= v_1_cb_done_06 a!1299)
                   (= v_1_cb_length_07
                      (ite a!1378 a!1361 (ite a!1379 0 v_0_cb_length_07)))
                   (= v_1_cb_end_07
                      (ite a!1378 a!1402 (ite a!1379 0 v_0_cb_end_07)))
                   (= v_1_cb_done_07 a!1305)
                   (= v_1_cb_length_08
                      (ite a!1380 a!1361 (ite a!1381 0 v_0_cb_length_08)))
                   (= v_1_cb_end_08
                      (ite a!1380 a!1402 (ite a!1381 0 v_0_cb_end_08)))
                   (= v_1_cb_done_08 a!1311)
                   (= v_1_cb_length_09
                      (ite a!1382 a!1361 (ite a!1383 0 v_0_cb_length_09)))
                   (= v_1_cb_end_09
                      (ite a!1382 a!1402 (ite a!1383 0 v_0_cb_end_09)))
                   (= v_1_cb_done_09 a!1317)
                   (= v_1_cb_length_10
                      (ite a!1384 a!1361 (ite a!1385 0 v_0_cb_length_10)))
                   (= v_1_cb_end_10
                      (ite a!1384 a!1402 (ite a!1385 0 v_0_cb_end_10)))
                   (= v_1_cb_done_10 a!1323)
                   (= v_1_cb_length_11
                      (ite a!1386 a!1361 (ite a!1387 0 v_0_cb_length_11)))
                   (= v_1_cb_end_11
                      (ite a!1386 a!1402 (ite a!1387 0 v_0_cb_end_11)))
                   (= v_1_cb_done_11 a!1329)
                   (= v_1_cb_length_12
                      (ite a!1388 a!1361 (ite a!1389 0 v_0_cb_length_12)))
                   (= v_1_cb_end_12
                      (ite a!1388 a!1402 (ite a!1389 0 v_0_cb_end_12)))
                   (= v_1_cb_done_12 a!1335)
                   (= v_1_cb_length_13
                      (ite a!1390 a!1361 (ite a!1391 0 v_0_cb_length_13)))
                   (= v_1_cb_end_13
                      (ite a!1390 a!1402 (ite a!1391 0 v_0_cb_end_13)))
                   (= v_1_cb_done_13 a!1341)
                   (= v_1_cb_length_14
                      (ite a!1392 a!1361 (ite a!1393 0 v_0_cb_length_14)))
                   (= v_1_cb_end_14
                      (ite a!1392 a!1402 (ite a!1393 0 v_0_cb_end_14)))
                   (= v_1_cb_done_14 a!1347)
                   (= v_1_cb_length_15
                      (ite a!1394 a!1361 (ite a!1395 0 v_0_cb_length_15)))
                   (= v_1_cb_end_15
                      (ite a!1394 a!1402 (ite a!1395 0 v_0_cb_end_15)))
                   (= v_1_cb_done_15 a!1353)
                   a!1406
                   (= active_1_user active_0_user)
                   (= active_1_time_wait active_0_time_wait)
                   (= active_1_delack
                      (and (not a!1022) (not a!1002) active_0_delack))
                   a!1407
                   (= due_1_rtx (ite (or a!1404 a!1405) a!1408 due_0_rtx))
                   (= due_1_user due_0_user)
                   (= due_1_time_wait due_0_time_wait)
                   (= due_1_delack due_0_delack)
                   (= due_1_persist (ite a!1169 (+ now_1 a!1170) due_0_persist))
                   (not active_0_user)
                   (not active_0_time_wait)
                   (<= 1000 v_0_rto_ms)
                   (<= 0 v_0_retries)
                   (<= 1 v_0_msl_ms)
                   (<= 1 v_0_user_timeout_ms)
                   (>= 16 (+ v_0_snd_buf v_0_rtx_buf))
                   (>= 16 v_0_rcv_buf)
                   (<= 0 v_0_snd_wnd)
                   (>= 65535 v_0_snd_wnd)
                   (= v_0_local_window (+ 16 (* (- 1) v_0_rcv_buf)))
                   (>= 1 v_0_rx_slot_00)
                   (or (not (>= v_0_rcv_buf 16)) (= 0 v_0_rx_slot_00))
                   (>= 1 v_0_rx_slot_01)
                   (or (not (>= v_0_rcv_buf 15)) (= 0 v_0_rx_slot_01))
                   (>= 1 v_0_rx_slot_02)
                   (or (not (>= v_0_rcv_buf 14)) (= 0 v_0_rx_slot_02))
                   (>= 1 v_0_rx_slot_03)
                   (or (not (>= v_0_rcv_buf 13)) (= 0 v_0_rx_slot_03))
                   (>= 1 v_0_rx_slot_04)
                   (or (not (>= v_0_rcv_buf 12)) (= 0 v_0_rx_slot_04))
                   (>= 1 v_0_rx_slot_05)
                   (or (not (>= v_0_rcv_buf 11)) (= 0 v_0_rx_slot_05))
                   (>= 1 v_0_rx_slot_06)
                   (or (not (>= v_0_rcv_buf 10)) (= 0 v_0_rx_slot_06))
                   (>= 1 v_0_rx_slot_07)
                   (or (not (>= v_0_rcv_buf 9)) (= 0 v_0_rx_slot_07))
                   (>= 1 v_0_rx_slot_08)
                   (or (not (>= v_0_rcv_buf 8)) (= 0 v_0_rx_slot_08))
                   (>= 1 v_0_rx_slot_09)
                   (or (not (>= v_0_rcv_buf 7)) (= 0 v_0_rx_slot_09))
                   (>= 1 v_0_rx_slot_10)
                   (or (not (>= v_0_rcv_buf 6)) (= 0 v_0_rx_slot_10))
                   (>= 1 v_0_rx_slot_11)
                   (or (not (>= v_0_rcv_buf 5)) (= 0 v_0_rx_slot_11))
                   (>= 1 v_0_rx_slot_12)
                   (or (not (>= v_0_rcv_buf 4)) (= 0 v_0_rx_slot_12))
                   (>= 1 v_0_rx_slot_13)
                   (or (not (>= v_0_rcv_buf 3)) (= 0 v_0_rx_slot_13))
                   (>= 1 v_0_rx_slot_14)
                   (or (not (>= v_0_rcv_buf 2)) (= 0 v_0_rx_slot_14))
                   (>= 1 v_0_rx_slot_15)
                   (or (not (>= v_0_rcv_buf 1)) (= 0 v_0_rx_slot_15))
                   (= 0 v_0_rx_slot_00)
                   a!673
                   (<= 0 v_0_rx_advance)
                   (>= 16 v_0_rx_advance)
                   (= v_0_rx_chunk v_0_rx_advance)
                   (<= 0 v_0_ack_delta)
                   (>= 4294967295 v_0_ack_delta)
                   (= v_0_snd_nxt a!1413)
                   (not v_0_fin_sent)
                   (not v_0_fin_requested)
                   (not v_0_rx_fin_done)
                   a!1414
                   (<= 0 v_0_rx_fin_offset)
                   (>= 15 v_0_rx_fin_offset)
                   (= v_0_rx_fin_pending (<= 1 v_0_rx_fin_offset))
                   (or (not v_0_rx_fin_pending) a!1417)
                   (or (not v_0_rx_fin_done) (= v_0_rcv_nxt a!1418))
                   a!683
                   a!684
                   a!685
                   a!686
                   a!687
                   a!688
                   a!689
                   a!690
                   a!691
                   a!692
                   a!693
                   a!694
                   a!695
                   a!696
                   a!697
                   a!698
                   (<= 0.0 v_0_srtt_ms)
                   (<= 0.0 v_0_rttvar_ms)
                   (<= 0.0 v_0_rtt_error_ms)
                   (<= 0.0 v_0_rtt_previous_srtt)
                   (<= 0.0 v_0_rtt_previous_var)
                   (<= 0 v_0_rtt_start_ms)
                   (<= 0 v_0_rtt_last_ms)
                   (<= 0 v_0_rtt_samples)
                   (<= 1000 v_0_rto_base_ms)
                   (>= 60000 v_0_rto_base_ms)
                   (>= v_0_rto_ms v_0_rto_base_ms)
                   (>= 60000 v_0_rto_ms)
                   (= v_0_rto_base_ms (ite v_0_rtt_measured a!1421 1000))
                   (= v_0_rtt_measured (<= 1 v_0_rtt_samples))
                   (or (not v_0_rtt_active)
                       (and (<= v_0_rtt_start_ms now_0)
                            (<= 1 v_0_rtt_remaining)
                            (>= 4 v_0_rtt_remaining)
                            (>= a!1012 v_0_rtt_remaining)
                            (<= a!1012 a!1426)))
                   (or v_0_rtt_active (= 0 v_0_rtt_remaining))
                   (or (not v_0_rtt_sample_used) a!1427)
                   (<= 0 v_0_rtt_sample_at_ms)
                   (<= v_0_rtt_sample_at_ms now_0)
                   (or (not v_0_rtt_sample_used)
                       (and a!1430 (= v_0_srtt_ms a!1431)))
                   (<= 0 v_0_tx_time_00)
                   (<= v_0_tx_time_00 now_0)
                   (or (not (>= 0 v_0_rtx_buf)) (= 0 v_0_tx_time_00))
                   (<= 0 v_0_tx_time_01)
                   (<= v_0_tx_time_01 now_0)
                   (or (not (>= 1 v_0_rtx_buf)) (= 0 v_0_tx_time_01))
                   (<= 0 v_0_tx_time_02)
                   (<= v_0_tx_time_02 now_0)
                   (or (not (>= 2 v_0_rtx_buf)) (= 0 v_0_tx_time_02))
                   (<= 0 v_0_tx_time_03)
                   (<= v_0_tx_time_03 now_0)
                   (or (not (>= 3 v_0_rtx_buf)) (= 0 v_0_tx_time_03))
                   (<= 0 v_0_tx_time_04)
                   (<= v_0_tx_time_04 now_0)
                   (or (not (>= 4 v_0_rtx_buf)) (= 0 v_0_tx_time_04))
                   (<= 0 v_0_tx_time_05)
                   (<= v_0_tx_time_05 now_0)
                   (or (not (>= 5 v_0_rtx_buf)) (= 0 v_0_tx_time_05))
                   (<= 0 v_0_tx_time_06)
                   (<= v_0_tx_time_06 now_0)
                   (or (not (>= 6 v_0_rtx_buf)) (= 0 v_0_tx_time_06))
                   (<= 0 v_0_tx_time_07)
                   (<= v_0_tx_time_07 now_0)
                   (or (not (>= 7 v_0_rtx_buf)) (= 0 v_0_tx_time_07))
                   (<= 0 v_0_tx_time_08)
                   (<= v_0_tx_time_08 now_0)
                   (or (not (>= 8 v_0_rtx_buf)) (= 0 v_0_tx_time_08))
                   (<= 0 v_0_tx_time_09)
                   (<= v_0_tx_time_09 now_0)
                   (or (not (>= 9 v_0_rtx_buf)) (= 0 v_0_tx_time_09))
                   (<= 0 v_0_tx_time_10)
                   (<= v_0_tx_time_10 now_0)
                   (or (not (>= 10 v_0_rtx_buf)) (= 0 v_0_tx_time_10))
                   (<= 0 v_0_tx_time_11)
                   (<= v_0_tx_time_11 now_0)
                   (or (not (>= 11 v_0_rtx_buf)) (= 0 v_0_tx_time_11))
                   (<= 0 v_0_tx_time_12)
                   (<= v_0_tx_time_12 now_0)
                   (or (not (>= 12 v_0_rtx_buf)) (= 0 v_0_tx_time_12))
                   (<= 0 v_0_tx_time_13)
                   (<= v_0_tx_time_13 now_0)
                   (or (not (>= 13 v_0_rtx_buf)) (= 0 v_0_tx_time_13))
                   (<= 0 v_0_tx_time_14)
                   (<= v_0_tx_time_14 now_0)
                   (or (not (>= 14 v_0_rtx_buf)) (= 0 v_0_tx_time_14))
                   (<= 0 v_0_tx_time_15)
                   (<= v_0_tx_time_15 now_0)
                   (or (not (>= 15 v_0_rtx_buf)) (= 0 v_0_tx_time_15))
                   (<= 0 v_0_tx_fin_time)
                   (<= v_0_tx_fin_time now_0)
                   (<= 0 v_0_tx_emit_count)
                   (>= 4 v_0_tx_emit_count)
                   (<= 0 v_0_tx_eligible)
                   (>= 4 v_0_tx_eligible)
                   (<= 0 v_0_tx_elapsed)
                   (<= 0 v_0_tx_max_previous)
                   (<= v_0_tx_max_previous now_0)
                   (<= 1000 v_0_tx_previous_rto)
                   (>= 60000 v_0_tx_previous_rto)
                   a!717
                   (or (not v_0_tx_retransmitted) (not v_0_tx_waiting))
                   (<= 0 v_0_tx_syn_time)
                   (<= v_0_tx_syn_time now_0)
                   (not v_0_tx_syn_pending)
                   (or v_0_tx_syn_pending (= 0 v_0_tx_syn_time))
                   (<= 1 v_0_ack_delay_ms)
                   (>= 499 v_0_ack_delay_ms)
                   (= 4 v_0_ack_rmss)
                   (= v_0_ack_pending active_0_delack)
                   (<= 0 v_0_ack_bytes)
                   (>= 7 v_0_ack_bytes)
                   (<= 0 v_0_ack_full_segments)
                   (>= 1 v_0_ack_full_segments)
                   (<= 0 v_0_ack_since_ms)
                   (<= v_0_ack_since_ms now_0)
                   (or (not v_0_ack_pending)
                       (and (<= 1 v_0_ack_bytes) (not v_0_rx_fin_done)))
                   a!718
                   (= v_0_persist_active active_0_persist)
                   (= active_0_rtx a!719)
                   a!720
                   (or (not v_0_persist_active)
                       (and (not v_0_rtt_active) (= 0 v_0_rtt_remaining)))
                   (<= 1000 v_0_persist_interval_ms)
                   (>= 60000 v_0_persist_interval_ms)
                   (<= 1000 v_0_persist_previous_interval_ms)
                   (>= 60000 v_0_persist_previous_interval_ms)
                   (<= 0 v_0_persist_probes)
                   (<= 0 v_0_persist_elapsed_ms)
                   (<= 0 v_0_persist_since_ms)
                   (<= v_0_persist_since_ms now_0)
                   (<= 0 v_0_persist_last_ms)
                   (<= v_0_persist_last_ms now_0)
                   (<= 0 v_0_persist_deadline_ms)
                   (or (not v_0_persist_active) a!721)
                   a!722
                   a!723
                   a!724
                   (<= 4 v_0_cc_initial_window)
                   (>= 16 v_0_cc_initial_window)
                   (<= 8 v_0_cc_initial_threshold)
                   (<= 4 v_0_cc_cwnd)
                   (<= 8 v_0_cc_ssthresh)
                   (<= 0 v_0_cc_ca_credit)
                   (not (>= v_0_cc_ca_credit v_0_cc_cwnd))
                   (<= 0 v_0_cc_growth)
                   (>= 4 v_0_cc_growth)
                   (<= 0 v_0_cc_acked)
                   (>= 16 v_0_cc_acked)
                   (<= 0 v_0_cc_threshold_updates)
                   (<= 0 v_0_cc_new_sent)
                   (<= v_0_cc_new_sent v_0_cc_send_budget)
                   (or (not v_0_cc_rto_00) (not (>= 0 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_01) (not (>= 1 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_02) (not (>= 2 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_03) (not (>= 3 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_04) (not (>= 4 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_05) (not (>= 5 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_06) (not (>= 6 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_07) (not (>= 7 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_08) (not (>= 8 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_09) (not (>= 9 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_10) (not (>= 10 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_11) (not (>= 11 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_12) (not (>= 12 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_13) (not (>= 13 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_14) (not (>= 14 v_0_rtx_buf)))
                   (or (not v_0_cc_rto_15) (not (>= 15 v_0_rtx_buf)))
                   (<= 0 v_0_fr_dupacks)
                   (<= 0 v_0_fr_entries)
                   (<= 0 v_0_fr_emit_count)
                   (>= 4 v_0_fr_emit_count)
                   (<= 0 v_0_fr_last_window)
                   (>= 65535 v_0_fr_last_window)
                   a!725
                   a!726
                   a!727
                   (or v_0_fr_retransmitted (not v_0_fr_entered))
                   (or (not v_0_fr_entered)
                       (= v_0_cc_cwnd (+ 12 v_0_cc_ssthresh)))
                   a!728
                   (<= 0 v_0_idle_last_data_ms)
                   (<= v_0_idle_last_data_ms v_0_idle_event_ms)
                   (<= v_0_idle_event_ms now_0)
                   (<= 0 v_0_idle_elapsed_ms)
                   (<= 0 v_0_idle_restart_count)
                   (or (not v_0_idle_data_emitted)
                       (= v_0_idle_last_data_ms v_0_idle_event_ms))
                   (or (not v_0_idle_restart) a!729)
                   (<= 0 v_0_lt_epoch_bytes)
                   (>= 8 v_0_lt_epoch_bytes)
                   (<= v_0_lt_epoch_bytes v_0_rtx_buf)
                   (<= 0 v_0_lt_epoch_packets)
                   (>= 2 v_0_lt_epoch_packets)
                   (<= v_0_lt_epoch_packets v_0_fr_dupacks)
                   (>= v_0_lt_epoch_bytes v_0_lt_epoch_packets)
                   (<= v_0_lt_epoch_bytes (* 4 v_0_lt_epoch_packets))
                   (<= 0 v_0_lt_loss_flight)
                   a!1435
                   a!1436
                   (<= 0 v_0_choice_count)
                   (>= 4 v_0_choice_count)
                   (<= 0 v_0_choice_limit)
                   (>= 4 v_0_choice_limit)
                   a!1440
                   (<= 0 v_0_sched_packets)
                   (<= v_0_sched_packets v_0_sched_bytes)
                   (<= v_0_sched_bytes (* 4 v_0_sched_packets))
                   (>= 16 (+ v_0_sched_bytes v_0_snd_buf))
                   (<= 0 v_0_sched_at_ms)
                   (<= v_0_sched_at_ms now_0)
                   (or (not v_0_sched_open)
                       (= 1 v_0_sched_cause)
                       (= 2 v_0_sched_cause))
                   (or (not v_0_choice_used)
                       (and v_0_sched_open
                            (= v_0_sched_at_ms v_0_idle_event_ms)))
                   (<= 0 v_0_svc_written_bytes)
                   (<= 0 v_0_svc_acked_bytes)
                   (<= 0 v_0_svc_abandoned_bytes)
                   (= v_0_svc_written_bytes
                      (+ v_0_svc_acked_bytes
                         v_0_svc_abandoned_bytes
                         v_0_snd_buf
                         v_0_rtx_buf))
                   (= v_0_svc_ack_step v_0_cc_acked)
                   (<= 0 v_0_svc_accept_step)
                   (<= 0 v_0_svc_ack_step)
                   (<= 0 v_0_svc_drop_step)
                   (<= 0 v_0_cb_tail)
                   (not (<= 16 v_0_cb_tail))
                   (<= 0 v_0_cb_count)
                   (<= v_0_cb_count v_0_rtx_buf)
                   (= v_0_cb_tail
                      (ite (<= 7 v_0_cb_count)
                           (+ (- 7) v_0_cb_count)
                           (+ 9 v_0_cb_count)))
                   (<= 0 v_0_cb_new_count)
                   (>= 1 v_0_cb_new_count)
                   (<= 0 v_0_cb_emitted_total)
                   (<= 0 v_0_cb_acked_total)
                   (<= (+ v_0_cb_acked_total v_0_cb_partial_prefix)
                       v_0_svc_acked_bytes)
                   (<= v_0_cb_emitted_total v_0_svc_written_bytes)
                   (<= 0 v_0_cb_abandoned_total)
                   (<= 0 v_0_cb_step_bytes)
                   (>= 19 v_0_cb_step_bytes)
                   (<= 0 v_0_cb_drop_step)
                   (= v_0_cb_emitted_total
                      (+ v_0_cb_acked_total
                         v_0_cb_abandoned_total
                         v_0_cb_live_total))
                   a!738
                   (= v_0_cb_partial_prefix
                      (+ v_0_cb_live_total (* (- 1) v_0_rtx_buf)))
                   (<= 0 v_0_cb_partial_prefix)
                   (>= 3 v_0_cb_partial_prefix)
                   (<= (+ v_0_cb_emitted_total v_0_snd_buf)
                       v_0_svc_written_bytes)
                   (or (and (<= 1 v_0_cb_length_00) (>= 4 v_0_cb_length_00))
                       (>= 7 v_0_cb_count))
                   (or (not (>= 7 v_0_cb_count))
                       (and (= 0 v_0_cb_length_00) (= 0 v_0_cb_end_00)))
                   (or (>= 7 v_0_cb_count) a!1443)
                   (or (and (<= 1 v_0_cb_length_01) (>= 4 v_0_cb_length_01))
                       (>= 8 v_0_cb_count))
                   (or (not (>= 8 v_0_cb_count))
                       (and (= 0 v_0_cb_length_01) (= 0 v_0_cb_end_01)))
                   (or (>= 8 v_0_cb_count) a!1446)
                   (or (>= 9 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_02) (>= 4 v_0_cb_length_02)))
                   (or (not (>= 9 v_0_cb_count))
                       (and (= 0 v_0_cb_length_02) (= 0 v_0_cb_end_02)))
                   (or (>= 9 v_0_cb_count) a!1449)
                   (or (and (<= 1 v_0_cb_length_03) (>= 4 v_0_cb_length_03))
                       (>= 10 v_0_cb_count))
                   (or (not (>= 10 v_0_cb_count))
                       (and (= 0 v_0_cb_length_03) (= 0 v_0_cb_end_03)))
                   (or (>= 10 v_0_cb_count) a!1452)
                   (or (and (<= 1 v_0_cb_length_04) (>= 4 v_0_cb_length_04))
                       (>= 11 v_0_cb_count))
                   (or (not (>= 11 v_0_cb_count))
                       (and (= 0 v_0_cb_length_04) (= 0 v_0_cb_end_04)))
                   (or (>= 11 v_0_cb_count) a!1455)
                   (or (>= 12 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_05) (>= 4 v_0_cb_length_05)))
                   (or (not (>= 12 v_0_cb_count))
                       (and (= 0 v_0_cb_length_05) (= 0 v_0_cb_end_05)))
                   (or (>= 12 v_0_cb_count) a!1458)
                   (or (and (<= 1 v_0_cb_length_06) (>= 4 v_0_cb_length_06))
                       (>= 13 v_0_cb_count))
                   (or (not (>= 13 v_0_cb_count))
                       (and (= 0 v_0_cb_length_06) (= 0 v_0_cb_end_06)))
                   (or (>= 13 v_0_cb_count) a!1461)
                   (or (>= 14 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_07) (>= 4 v_0_cb_length_07)))
                   (or (not (>= 14 v_0_cb_count))
                       (and (= 0 v_0_cb_length_07) (= 0 v_0_cb_end_07)))
                   (or (>= 14 v_0_cb_count) a!1464)
                   (or (and (<= 1 v_0_cb_length_08) (>= 4 v_0_cb_length_08))
                       (>= 15 v_0_cb_count))
                   (or (not (>= 15 v_0_cb_count))
                       (and (= 0 v_0_cb_length_08) (= 0 v_0_cb_end_08)))
                   (or (>= 15 v_0_cb_count) a!1467)
                   (or (and (<= 1 v_0_cb_length_09) (>= 4 v_0_cb_length_09))
                       (>= 0 v_0_cb_count))
                   (or (not (>= 0 v_0_cb_count))
                       (and (= 0 v_0_cb_length_09) (= 0 v_0_cb_end_09)))
                   a!1473
                   (or (and (<= 1 v_0_cb_length_10) (>= 4 v_0_cb_length_10))
                       (>= 1 v_0_cb_count))
                   (or (not (>= 1 v_0_cb_count))
                       (and (= 0 v_0_cb_length_10) (= 0 v_0_cb_end_10)))
                   (or (>= 1 v_0_cb_count) a!1476)
                   (or (>= 2 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_11) (>= 4 v_0_cb_length_11)))
                   (or (not (>= 2 v_0_cb_count))
                       (and (= 0 v_0_cb_length_11) (= 0 v_0_cb_end_11)))
                   (or (>= 2 v_0_cb_count) a!1479)
                   (or (and (<= 1 v_0_cb_length_12) (>= 4 v_0_cb_length_12))
                       (>= 3 v_0_cb_count))
                   (or (not (>= 3 v_0_cb_count))
                       (and (= 0 v_0_cb_length_12) (= 0 v_0_cb_end_12)))
                   (or (>= 3 v_0_cb_count) a!1482)
                   (or (>= 4 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_13) (>= 4 v_0_cb_length_13)))
                   (or (not (>= 4 v_0_cb_count))
                       (and (= 0 v_0_cb_length_13) (= 0 v_0_cb_end_13)))
                   (or (>= 4 v_0_cb_count) a!1485)
                   (or (and (<= 1 v_0_cb_length_14) (>= 4 v_0_cb_length_14))
                       (>= 5 v_0_cb_count))
                   (or (not (>= 5 v_0_cb_count))
                       (and (= 0 v_0_cb_length_14) (= 0 v_0_cb_end_14)))
                   (or (>= 5 v_0_cb_count) a!1488)
                   (or (>= 6 v_0_cb_count)
                       (and (<= 1 v_0_cb_length_15) (>= 4 v_0_cb_length_15)))
                   (or (not (>= 6 v_0_cb_count))
                       (and (= 0 v_0_cb_length_15) (= 0 v_0_cb_end_15)))
                   (or (>= 6 v_0_cb_count) a!1491)
                   (= 85 choice_0)
                   (= 4 state_0)
                   (= 4 state_1)
                   (not (<= v_1_cb_count v_1_rtx_buf)))))
  (xor a!948 a!1492))))))))))))))))))))))))))
(check-sat)

(declare-fun proved_conclusion_0 () Bool)
(declare-fun shared_context () Bool)
(declare-fun proved_conclusion_1 () Bool)
(declare-fun proved_conclusion_2 () Bool)
(declare-fun proved_conclusion_3 () Bool)
(declare-fun proved_conclusion_4 () Bool)
(declare-fun proved_conclusion_5 () Bool)
(declare-fun proved_conclusion_6 () Bool)
(declare-fun proved_conclusion_7 () Bool)
(declare-fun proved_conclusion_8 () Bool)
(declare-fun proved_conclusion_9 () Bool)
(declare-fun proved_conclusion_10 () Bool)
(declare-fun proved_conclusion_11 () Bool)
(declare-fun proved_conclusion_12 () Bool)
(declare-fun proved_conclusion_13 () Bool)
(declare-fun proved_conclusion_14 () Bool)
(declare-fun proved_conclusion_15 () Bool)
(declare-fun proved_conclusion_16 () Bool)
(declare-fun proved_conclusion_17 () Bool)
(declare-fun proved_conclusion_18 () Bool)
(declare-fun proved_conclusion_19 () Bool)
(declare-fun proved_conclusion_20 () Bool)
(declare-fun proved_conclusion_21 () Bool)
(declare-fun proved_conclusion_22 () Bool)
(declare-fun proved_conclusion_23 () Bool)
(declare-fun proved_conclusion_24 () Bool)
(declare-fun proved_conclusion_25 () Bool)
(declare-fun proved_conclusion_26 () Bool)
(declare-fun proved_conclusion_27 () Bool)
(declare-fun proved_conclusion_28 () Bool)
(declare-fun proved_conclusion_29 () Bool)
(declare-fun proved_conclusion_30 () Bool)
(declare-fun proved_conclusion_31 () Bool)
(declare-fun proved_conclusion_32 () Bool)
(declare-fun proved_conclusion_33 () Bool)
(declare-fun proved_conclusion_34 () Bool)
(declare-fun proved_conclusion_35 () Bool)
(declare-fun proved_conclusion_36 () Bool)
(declare-fun proved_conclusion_37 () Bool)
(declare-fun proved_conclusion_38 () Bool)
(declare-fun proved_conclusion_39 () Bool)
(declare-fun proved_conclusion_40 () Bool)
(declare-fun proved_conclusion_41 () Bool)
(declare-fun proved_conclusion_42 () Bool)
(declare-fun proved_conclusion_43 () Bool)
(declare-fun proved_conclusion_44 () Bool)
(declare-fun proved_conclusion_45 () Bool)
(declare-fun proved_conclusion_46 () Bool)
(declare-fun proved_conclusion_47 () Bool)
(declare-fun proved_conclusion_48 () Bool)
(declare-fun proved_conclusion_49 () Bool)
(declare-fun proved_conclusion_50 () Bool)
(declare-fun proved_conclusion_51 () Bool)
(declare-fun proved_conclusion_52 () Bool)
(declare-fun proved_conclusion_53 () Bool)
(declare-fun proved_conclusion_54 () Bool)
(declare-fun proved_conclusion_55 () Bool)
(declare-fun proved_conclusion_56 () Bool)
(declare-fun proved_conclusion_57 () Bool)
(declare-fun target_violation () Bool)
(assert (=> shared_context proved_conclusion_0))
(assert (=> shared_context proved_conclusion_1))
(assert (=> shared_context proved_conclusion_2))
(assert (=> shared_context proved_conclusion_3))
(assert (=> shared_context proved_conclusion_4))
(assert (=> shared_context proved_conclusion_5))
(assert (=> shared_context proved_conclusion_6))
(assert (=> shared_context proved_conclusion_7))
(assert (=> shared_context proved_conclusion_8))
(assert (=> shared_context proved_conclusion_9))
(assert (=> shared_context proved_conclusion_10))
(assert (=> shared_context proved_conclusion_11))
(assert (=> shared_context proved_conclusion_12))
(assert (=> shared_context proved_conclusion_13))
(assert (=> shared_context proved_conclusion_14))
(assert (=> shared_context proved_conclusion_15))
(assert (=> shared_context proved_conclusion_16))
(assert (=> shared_context proved_conclusion_17))
(assert (=> shared_context proved_conclusion_18))
(assert (=> shared_context proved_conclusion_19))
(assert (=> shared_context proved_conclusion_20))
(assert (=> shared_context proved_conclusion_21))
(assert (=> shared_context proved_conclusion_22))
(assert (=> shared_context proved_conclusion_23))
(assert (=> shared_context proved_conclusion_24))
(assert (=> shared_context proved_conclusion_25))
(assert (=> shared_context proved_conclusion_26))
(assert (=> shared_context proved_conclusion_27))
(assert (=> shared_context proved_conclusion_28))
(assert (=> shared_context proved_conclusion_29))
(assert (=> shared_context proved_conclusion_30))
(assert (=> shared_context proved_conclusion_31))
(assert (=> shared_context proved_conclusion_32))
(assert (=> shared_context proved_conclusion_33))
(assert (=> shared_context proved_conclusion_34))
(assert (=> shared_context proved_conclusion_35))
(assert (=> shared_context proved_conclusion_36))
(assert (=> shared_context proved_conclusion_37))
(assert (=> shared_context proved_conclusion_38))
(assert (=> shared_context proved_conclusion_39))
(assert (=> shared_context proved_conclusion_40))
(assert (=> shared_context proved_conclusion_41))
(assert (=> shared_context proved_conclusion_42))
(assert (=> shared_context proved_conclusion_43))
(assert (=> shared_context proved_conclusion_44))
(assert (=> shared_context proved_conclusion_45))
(assert (=> shared_context proved_conclusion_46))
(assert (=> shared_context proved_conclusion_47))
(assert (=> shared_context proved_conclusion_48))
(assert (=> shared_context proved_conclusion_49))
(assert (=> shared_context proved_conclusion_50))
(assert (=> shared_context proved_conclusion_51))
(assert (=> shared_context proved_conclusion_52))
(assert (=> shared_context proved_conclusion_53))
(assert (=> shared_context proved_conclusion_54))
(assert (=> shared_context proved_conclusion_55))
(assert (=> shared_context proved_conclusion_56))
(assert (=> shared_context proved_conclusion_57))
(assert (not (and shared_context
          target_violation
          proved_conclusion_0
          proved_conclusion_1
          proved_conclusion_2
          proved_conclusion_3
          proved_conclusion_4
          proved_conclusion_5
          proved_conclusion_6
          proved_conclusion_7
          proved_conclusion_8
          proved_conclusion_9
          proved_conclusion_10
          proved_conclusion_11
          proved_conclusion_12
          proved_conclusion_13
          proved_conclusion_14
          proved_conclusion_15
          proved_conclusion_16
          proved_conclusion_17
          proved_conclusion_18
          proved_conclusion_19
          proved_conclusion_20
          proved_conclusion_21
          proved_conclusion_22
          proved_conclusion_23
          proved_conclusion_24
          proved_conclusion_25
          proved_conclusion_26
          proved_conclusion_27
          proved_conclusion_28
          proved_conclusion_29
          proved_conclusion_30
          proved_conclusion_31
          proved_conclusion_32
          proved_conclusion_33
          proved_conclusion_34
          proved_conclusion_35
          proved_conclusion_36
          proved_conclusion_37
          proved_conclusion_38
          proved_conclusion_39
          proved_conclusion_40
          proved_conclusion_41
          proved_conclusion_42
          proved_conclusion_43
          proved_conclusion_44
          proved_conclusion_45
          proved_conclusion_46
          proved_conclusion_47
          proved_conclusion_48
          proved_conclusion_49
          proved_conclusion_50
          proved_conclusion_51
          proved_conclusion_52
          proved_conclusion_53
          proved_conclusion_54
          proved_conclusion_55
          proved_conclusion_56
          proved_conclusion_57)))
(assert shared_context)
(assert target_violation)
(check-sat)

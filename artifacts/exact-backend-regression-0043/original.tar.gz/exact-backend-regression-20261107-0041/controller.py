from pathlib import Path
import json,subprocess,os,time
out=Path(__file__).parent;w=out/"workspace";task=json.loads((out/"task.json").read_text());codes={}
def state(**kw):(out/"status.json").write_text(json.dumps(dict(provider="controller-zeroAPI",pid=os.getpid(),production_modified=False,paid_requests=0,results=codes,**kw),indent=2))
for pattern in task["patterns"]:
 state(status="running",stage=pattern)
 with(out/(pattern+".log")).open("w")as log:
  try:
   r=subprocess.run(["/home/blxu/protocol-flow/releases/udp-transmit-1b13a36f/venv/bin/python","-m","unittest","discover","-s","tests","-p",pattern,"-v"],cwd=w,stdout=log,stderr=subprocess.STDOUT,timeout=task["seconds_per_module"],env={"PATH":"/usr/bin:/bin","PYTHONPATH":str(w),"PYTHONDONTWRITEBYTECODE":"1"})
   codes[pattern]=dict(returncode=r.returncode)
  except subprocess.TimeoutExpired:codes[pattern]=dict(status="timeout",no_retry=True)
state(status="controller_review_required",stage="finished",finished_at=time.time(),all_modules_pass=all(v.get("returncode")==0 for v in codes.values()))

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.cache_ttl_milliseconds () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.cache_ttl_milliseconds () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x133 (= due_1_cache due_0_cache)))
 (let (($x132 (= due_1_query due_0_query)))
 (let (($x131 (= active_1_cache active_0_cache)))
 (let (($x130 (= active_1_query active_0_query)))
 (let (($x530 (= v_1_cache_ttl_ms 120000)))
 (let (($x495 (= v_1_retry_count 0)))
 (let (($x490 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x126 (= 0 state_1)))
 (let (($x79 (not active_0_cache)))
 (let (($x489 (or $x79 (not (<= due_0_cache 0)))))
 (let (($x77 (not active_0_query)))
 (let (($x486 (or $x77 (not (<= due_0_query 0)))))
 (let (($x51 (= state_0 0)))
 (and $x51 (>= 0 now_0) $x486 $x489 $x126 $x490 $x495 $x530 $x130 $x131 $x132 $x133)))))))))))))))
(assert
 true)
(assert
 (let (($x437 (= due_2_query due_1_query)))
 (let (($x1105 (not active_2_query)))
 (let (($x434 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x433 (= 0 v_2_retry_count)))
 (let ((?x93 (seq.unit (_ bv0 8))))
 (let ((?x733 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.unit (_ bv2 8))))))))
 (let ((?x95 (seq.unit (_ bv2 8))))
 (let (($x1104 (= v_2_peer_mac (seq.++ ?x95 ?x733))))
 (let (($x431 (= 2 state_2)))
 (let (($x1103 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x1099 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x277 (= state_1 0)))
 (and $x277 $x1099 $x1103 $x431 $x1104 $x433 $x434 $x1105 active_2_cache $x437 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x506 (= due_3_cache 60020)))
 (let (($x712 (= due_3_query due_2_query)))
 (let (($x710 (= active_3_query active_2_query)))
 (let (($x536 (= v_3_cache_ttl_ms 60000)))
 (let (($x708 (= v_3_retry_count v_2_retry_count)))
 (let (($x707 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x706 (= 2 state_3)))
 (let (($x503 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x1105 (not active_2_query)))
 (let (($x521 (or $x1105 (not (<= due_2_query 20)))))
 (let (($x535 (= state_2 2)))
 (and $x535 $x521 $x503 $x706 $x707 $x708 $x536 $x710 active_3_cache $x712 $x506)))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x864 (= due_4_cache due_3_cache)))
 (let (($x863 (= due_4_query due_3_query)))
 (let (($x532 (not active_4_cache)))
 (let (($x861 (= active_4_query active_3_query)))
 (let (($x860 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x859 (= 0 v_4_retry_count)))
 (let (($x538 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x857 (= 0 state_4)))
 (let (($x748 (= state_3 2)))
 (and $x748 active_3_cache (= 60020 due_3_cache) (or (not active_3_query) (<= due_3_cache due_3_query)) $x857 $x538 $x859 $x860 $x861 $x532 $x863 $x864)))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 6 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 120000 input_0_app.cache_ttl_milliseconds))
(assert
 (= 9 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x91 (seq.unit (_ bv192 8))))
 (let ((?x230 (seq.++ ?x91 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x150 (seq.unit (_ bv1 8))))
 (let ((?x93 (seq.unit (_ bv0 8))))
 (let ((?x1032 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x150 ?x230)))))))
 (let ((?x95 (seq.unit (_ bv2 8))))
 (let ((?x1037 (seq.++ ?x91 (seq.++ ?x93 (seq.++ ?x95 (seq.++ ?x95 (seq.++ ?x95 ?x1032)))))))
 (let ((?x1042 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x95 ?x1037)))))))
 (let ((?x179 (seq.unit (_ bv4 8))))
 (let ((?x177 (seq.unit (_ bv6 8))))
 (let ((?x1047 (seq.++ ?x177 (seq.++ ?x179 (seq.++ ?x93 (seq.++ ?x95 (seq.++ ?x95 ?x1042)))))))
 (let ((?x175 (seq.unit (_ bv8 8))))
 (let ((?x1052 (seq.++ ?x177 (seq.++ ?x93 (seq.++ ?x150 (seq.++ ?x175 (seq.++ ?x93 ?x1047)))))))
 (let ((?x1057 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x95 (seq.++ ?x175 ?x1052)))))))
 (let ((?x1062 (seq.++ ?x93 (seq.++ ?x93 (seq.++ ?x150 (seq.++ ?x95 (seq.++ ?x93 ?x1057)))))))
 (let ((?x1065 (seq.++ ?x95 (seq.++ ?x93 (seq.++ ?x93 ?x1062)))))
 (= input_1_net.frame_frame ?x1065))))))))))))))))))
(assert
 (= 16 choice_2))
(assert
 (= 20 now_3))
(assert
 (= 60000 input_2_app.cache_ttl_milliseconds))
(assert
 (= 5 choice_3))
(assert
 (= 60020 now_4))
(check-sat)

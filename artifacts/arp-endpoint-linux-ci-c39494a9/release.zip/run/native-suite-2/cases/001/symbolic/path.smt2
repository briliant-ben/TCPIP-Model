; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1021 (= due_1_cache 60000)))
 (let (($x266 (= due_1_query due_0_query)))
 (let (($x1020 (not active_1_query)))
 (let (($x1041 (= v_1_cache_ttl_ms 60000)))
 (let (($x1067 (= 0 v_1_retry_count)))
 (let ((?x355 (seq.unit (_ bv0 8))))
 (let ((?x153 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.unit (_ bv2 8))))))))
 (let ((?x24 (seq.unit (_ bv2 8))))
 (let (($x1019 (= v_1_peer_mac (seq.++ ?x24 ?x153))))
 (let (($x834 (= 2 state_1)))
 (let (($x255 (not active_0_cache)))
 (let (($x1018 (or $x255 (not (<= due_0_cache 0)))))
 (let (($x1065 (not active_0_query)))
 (let (($x1015 (or $x1065 (not (<= due_0_query 0)))))
 (let (($x1039 (= state_0 0)))
 (and $x1039 (>= 0 now_0) $x1015 $x1018 $x834 $x1019 $x1067 $x1041 $x1020 active_1_cache $x266 $x1021)))))))))))))))))
(assert
 true)
(assert
 (let (($x410 (= due_2_cache due_1_cache)))
 (let (($x409 (= due_2_query due_1_query)))
 (let (($x573 (not active_2_cache)))
 (let (($x407 (= active_2_query active_1_query)))
 (let (($x406 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x405 (= 0 v_2_retry_count)))
 (let (($x158 (= (as seq.empty (Seq (_ BitVec 8))) v_2_peer_mac)))
 (let (($x403 (= 0 state_2)))
 (let (($x183 (= state_1 2)))
 (and $x183 active_1_cache (= 60000 due_1_cache) (or (not active_1_query) (<= due_1_cache due_1_query)) $x403 $x158 $x405 $x406 $x407 $x573 $x409 $x410)))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x296 (= due_3_cache due_2_cache)))
 (let (($x125 (= due_3_query 61000)))
 (let (($x294 (= active_3_cache active_2_cache)))
 (let (($x292 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x291 (= 0 v_3_retry_count)))
 (let (($x290 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x289 (= 1 state_3)))
 (let (($x573 (not active_2_cache)))
 (let (($x146 (or $x573 (not (<= due_2_cache 60000)))))
 (let (($x84 (or (not active_2_query) (not (<= due_2_query 60000)))))
 (let (($x669 (= state_2 0)))
 (and $x669 $x84 $x146 $x289 $x290 $x291 $x292 active_3_query $x294 $x125 $x296)))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x623 (seq.unit (_ bv192 8))))
 (let ((?x81 (seq.++ ?x623 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x23 (seq.unit (_ bv1 8))))
 (let ((?x355 (seq.unit (_ bv0 8))))
 (let ((?x813 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x23 ?x81)))))))
 (let ((?x24 (seq.unit (_ bv2 8))))
 (let ((?x818 (seq.++ ?x623 (seq.++ ?x355 (seq.++ ?x24 (seq.++ ?x24 (seq.++ ?x24 ?x813)))))))
 (let ((?x823 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x24 ?x818)))))))
 (let ((?x277 (seq.unit (_ bv4 8))))
 (let ((?x515 (seq.unit (_ bv6 8))))
 (let ((?x828 (seq.++ ?x515 (seq.++ ?x277 (seq.++ ?x355 (seq.++ ?x24 (seq.++ ?x24 ?x823)))))))
 (let ((?x712 (seq.unit (_ bv8 8))))
 (let ((?x952 (seq.++ ?x515 (seq.++ ?x355 (seq.++ ?x23 (seq.++ ?x712 (seq.++ ?x355 ?x828)))))))
 (let ((?x957 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x24 (seq.++ ?x712 ?x952)))))))
 (let ((?x962 (seq.++ ?x355 (seq.++ ?x355 (seq.++ ?x23 (seq.++ ?x24 (seq.++ ?x355 ?x957)))))))
 (let ((?x965 (seq.++ ?x24 (seq.++ ?x355 (seq.++ ?x355 ?x962)))))
 (= input_0_net.frame_frame ?x965))))))))))))))))))
(assert
 (= 5 choice_1))
(assert
 (= 60000 now_2))
(assert
 (= 0 choice_2))
(assert
 (= 60000 now_3))
(assert
 (let ((?x623 (seq.unit (_ bv192 8))))
(let ((?x469 (seq.++ ?x623 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x469))))
(check-sat)

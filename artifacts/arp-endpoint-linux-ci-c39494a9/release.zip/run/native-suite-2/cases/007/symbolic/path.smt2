; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1338 (= due_1_cache 60000)))
 (let (($x1350 (= due_1_query due_0_query)))
 (let (($x501 (not active_1_query)))
 (let (($x1176 (= v_1_cache_ttl_ms 60000)))
 (let (($x610 (= 0 v_1_retry_count)))
 (let ((?x849 (seq.unit (_ bv0 8))))
 (let ((?x810 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.unit (_ bv2 8))))))))
 (let ((?x170 (seq.unit (_ bv2 8))))
 (let (($x405 (= v_1_peer_mac (seq.++ ?x170 ?x810))))
 (let (($x1052 (= 2 state_1)))
 (let (($x852 (not active_0_cache)))
 (let (($x974 (or $x852 (not (<= due_0_cache 0)))))
 (let (($x327 (not active_0_query)))
 (let (($x184 (or $x327 (not (<= due_0_query 0)))))
 (let (($x46 (= state_0 0)))
 (and $x46 (>= 0 now_0) $x184 $x974 $x1052 $x405 $x610 $x1176 $x501 active_1_cache $x1350 $x1338)))))))))))))))))
(assert
 true)
(assert
 (let (($x943 (= due_2_query due_1_query)))
 (let (($x704 (= active_2_query active_1_query)))
 (let (($x316 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x175 (= v_2_retry_count v_1_retry_count)))
 (let ((?x849 (seq.unit (_ bv0 8))))
 (let ((?x536 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.unit (_ bv3 8))))))))
 (let ((?x170 (seq.unit (_ bv2 8))))
 (let (($x1123 (= v_2_peer_mac (seq.++ ?x170 ?x536))))
 (let (($x249 (= 2 state_2)))
 (let (($x672 (or (not active_1_cache) (not (<= due_1_cache 59999)))))
 (let (($x501 (not active_1_query)))
 (let (($x991 (or $x501 (not (<= due_1_query 59999)))))
 (let (($x433 (= state_1 2)))
 (and $x433 $x991 $x672 $x249 $x1123 $x175 $x316 $x704 active_2_cache $x943 (= due_2_cache (+ 59999 v_1_cache_ttl_ms)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x686 (= due_3_cache due_2_cache)))
 (let (($x272 (= due_3_query due_2_query)))
 (let (($x749 (= active_3_cache active_2_cache)))
 (let (($x61 (= active_3_query active_2_query)))
 (let (($x77 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x840 (= v_3_retry_count v_2_retry_count)))
 (let (($x1227 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x762 (= 2 state_3)))
 (let (($x1332 (or (not active_2_cache) (not (<= due_2_cache 60001)))))
 (let (($x832 (or (not active_2_query) (not (<= due_2_query 60001)))))
 (let (($x1006 (= state_2 2)))
 (and $x1006 $x832 $x1332 $x762 $x1227 $x840 $x77 $x61 $x749 $x272 $x686)))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1041 (seq.unit (_ bv192 8))))
 (let ((?x560 (seq.++ ?x1041 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x1217 (seq.unit (_ bv1 8))))
 (let ((?x849 (seq.unit (_ bv0 8))))
 (let ((?x1310 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x1217 ?x560)))))))
 (let ((?x170 (seq.unit (_ bv2 8))))
 (let ((?x65 (seq.++ ?x1041 (seq.++ ?x849 (seq.++ ?x170 (seq.++ ?x170 (seq.++ ?x170 ?x1310)))))))
 (let ((?x781 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x170 ?x65)))))))
 (let ((?x232 (seq.unit (_ bv4 8))))
 (let ((?x745 (seq.unit (_ bv6 8))))
 (let ((?x321 (seq.++ ?x745 (seq.++ ?x232 (seq.++ ?x849 (seq.++ ?x170 (seq.++ ?x170 ?x781)))))))
 (let ((?x24 (seq.unit (_ bv8 8))))
 (let ((?x622 (seq.++ ?x745 (seq.++ ?x849 (seq.++ ?x1217 (seq.++ ?x24 (seq.++ ?x849 ?x321)))))))
 (let ((?x1287 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x170 (seq.++ ?x24 ?x622)))))))
 (let ((?x805 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x1217 (seq.++ ?x170 (seq.++ ?x849 ?x1287)))))))
 (let ((?x1134 (seq.++ ?x170 (seq.++ ?x849 (seq.++ ?x849 ?x805)))))
 (= input_0_net.frame_frame ?x1134))))))))))))))))))
(assert
 (= 20 choice_1))
(assert
 (= 59999 now_2))
(assert
 (let ((?x1041 (seq.unit (_ bv192 8))))
 (let ((?x148 (seq.++ ?x1041 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x849 (seq.unit (_ bv0 8))))
 (let ((?x876 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 ?x148)))))))
 (let ((?x170 (seq.unit (_ bv2 8))))
 (let ((?x468 (seq.++ ?x1041 (seq.++ ?x849 (seq.++ ?x170 (seq.++ ?x170 (seq.++ ?x849 ?x876)))))))
 (let ((?x756 (seq.unit (_ bv3 8))))
 (let ((?x978 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x756 ?x468)))))))
 (let ((?x1217 (seq.unit (_ bv1 8))))
 (let ((?x232 (seq.unit (_ bv4 8))))
 (let ((?x745 (seq.unit (_ bv6 8))))
 (let ((?x988 (seq.++ ?x745 (seq.++ ?x232 (seq.++ ?x849 (seq.++ ?x1217 (seq.++ ?x170 ?x978)))))))
 (let ((?x24 (seq.unit (_ bv8 8))))
 (let ((?x410 (seq.++ ?x745 (seq.++ ?x849 (seq.++ ?x1217 (seq.++ ?x24 (seq.++ ?x849 ?x988)))))))
 (let ((?x971 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x849 (seq.++ ?x756 (seq.++ ?x24 ?x410)))))))
 (let ((?x504 (seq.unit (_ bv255 8))))
 (let ((?x209 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x170 (seq.++ ?x849 ?x971)))))))
 (let ((?x1302 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 ?x209)))))
 (= input_1_net.frame_frame ?x1302))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 60001 now_3))
(assert
 (let ((?x1041 (seq.unit (_ bv192 8))))
(let ((?x1129 (seq.++ ?x1041 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x1129))))
(check-sat)

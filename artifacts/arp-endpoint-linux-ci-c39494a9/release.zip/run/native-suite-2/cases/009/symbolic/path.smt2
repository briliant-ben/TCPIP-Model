; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x560 (= due_1_cache due_0_cache)))
 (let (($x1167 (= due_1_query 1000)))
 (let (($x773 (= active_1_cache active_0_cache)))
 (let (($x142 (= v_1_cache_ttl_ms 60000)))
 (let (($x690 (= 0 v_1_retry_count)))
 (let (($x486 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x208 (= 1 state_1)))
 (let (($x6 (not active_0_cache)))
 (let (($x298 (or $x6 (not (<= due_0_cache 0)))))
 (let (($x79 (not active_0_query)))
 (let (($x84 (or $x79 (not (<= due_0_query 0)))))
 (let (($x768 (= state_0 0)))
 (and $x768 (>= 0 now_0) $x84 $x298 $x208 $x486 $x690 $x142 active_1_query $x773 $x1167 $x560))))))))))))))
(assert
 true)
(assert
 (let (($x803 (= due_2_query due_1_query)))
 (let (($x549 (not active_2_query)))
 (let (($x356 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x570 (= 0 v_2_retry_count)))
 (let ((?x1063 (seq.unit (_ bv0 8))))
 (let ((?x524 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.unit (_ bv2 8))))))))
 (let ((?x40 (seq.unit (_ bv2 8))))
 (let (($x359 (= v_2_peer_mac (seq.++ ?x40 ?x524))))
 (let (($x632 (= 2 state_2)))
 (let (($x651 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x296 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x732 (= state_1 1)))
 (and $x732 $x296 $x651 $x632 $x359 $x570 $x356 $x549 active_2_cache $x803 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x872 (= due_3_cache due_2_cache)))
 (let (($x619 (= due_3_query due_2_query)))
 (let (($x365 (= active_3_cache active_2_cache)))
 (let (($x683 (= active_3_query active_2_query)))
 (let (($x335 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x784 (= v_3_retry_count v_2_retry_count)))
 (let (($x905 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x240 (= 2 state_3)))
 (let (($x503 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x549 (not active_2_query)))
 (let (($x883 (or $x549 (not (<= due_2_query 20)))))
 (let (($x793 (= state_2 2)))
 (and $x793 $x883 $x503 $x240 $x905 $x784 $x335 $x683 $x365 $x619 $x872))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x712 (seq.unit (_ bv192 8))))
 (let ((?x259 (seq.++ ?x712 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x259))))
(assert
 (= 14 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x712 (seq.unit (_ bv192 8))))
 (let ((?x170 (seq.++ ?x712 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x1109 (seq.unit (_ bv1 8))))
 (let ((?x1063 (seq.unit (_ bv0 8))))
 (let ((?x1101 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1109 ?x170)))))))
 (let ((?x40 (seq.unit (_ bv2 8))))
 (let ((?x307 (seq.++ ?x712 (seq.++ ?x1063 (seq.++ ?x40 (seq.++ ?x40 (seq.++ ?x40 ?x1101)))))))
 (let ((?x1300 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x40 ?x307)))))))
 (let ((?x577 (seq.unit (_ bv4 8))))
 (let ((?x100 (seq.unit (_ bv6 8))))
 (let ((?x529 (seq.++ ?x100 (seq.++ ?x577 (seq.++ ?x1063 (seq.++ ?x40 (seq.++ ?x40 ?x1300)))))))
 (let ((?x530 (seq.unit (_ bv8 8))))
 (let ((?x106 (seq.++ ?x100 (seq.++ ?x1063 (seq.++ ?x1109 (seq.++ ?x530 (seq.++ ?x1063 ?x529)))))))
 (let ((?x343 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x40 (seq.++ ?x530 ?x106)))))))
 (let ((?x226 (seq.++ ?x1063 (seq.++ ?x1063 (seq.++ ?x1109 (seq.++ ?x40 (seq.++ ?x1063 ?x343)))))))
 (let ((?x826 (seq.++ ?x40 (seq.++ ?x1063 (seq.++ ?x1063 ?x226)))))
 (= input_1_net.frame_frame ?x826))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x712 (seq.unit (_ bv192 8))))
(let ((?x259 (seq.++ ?x712 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x259))))
(check-sat)

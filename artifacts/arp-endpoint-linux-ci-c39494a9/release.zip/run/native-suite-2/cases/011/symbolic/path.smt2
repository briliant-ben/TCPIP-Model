; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x332 (= due_1_cache due_0_cache)))
 (let (($x1170 (= due_1_query due_0_query)))
 (let (($x921 (= active_1_cache active_0_cache)))
 (let (($x911 (= active_1_query active_0_query)))
 (let (($x1274 (= v_1_cache_ttl_ms 60000)))
 (let (($x60 (= v_1_retry_count 0)))
 (let (($x283 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x427 (= 0 state_1)))
 (let (($x91 (not active_0_cache)))
 (let (($x1007 (or $x91 (not (<= due_0_cache 0)))))
 (let (($x1101 (not active_0_query)))
 (let (($x742 (or $x1101 (not (<= due_0_query 0)))))
 (let (($x897 (= state_0 0)))
 (and $x897 (>= 0 now_0) $x742 $x1007 $x427 $x283 $x60 $x1274 $x911 $x921 $x1170 $x332)))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 7 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1331 (seq.unit (_ bv0 8))))
(let ((?x98 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 ?x1331)))))))
(let ((?x1054 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 ?x98)))))))
(let ((?x113 (seq.++ ?x1331 (seq.++ ?x1331 (seq.++ ?x1331 ?x1054)))))
(= input_0_net.frame_frame ?x113))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun due_4_cache () Int)
(declare-fun due_4_query () Int)
(declare-fun active_4_cache () Bool)
(declare-fun active_4_query () Bool)
(declare-fun v_4_cache_ttl_ms () Int)
(declare-fun v_4_retry_count () Int)
(declare-fun v_4_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_4 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun choice_3 () Int)
(declare-fun now_4 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x515 (= due_1_cache due_0_cache)))
 (let (($x811 (= due_1_query 1000)))
 (let (($x298 (= active_1_cache active_0_cache)))
 (let (($x1310 (= v_1_cache_ttl_ms 60000)))
 (let (($x1033 (= 0 v_1_retry_count)))
 (let (($x1283 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x575 (= 1 state_1)))
 (let (($x1051 (not active_0_cache)))
 (let (($x440 (or $x1051 (not (<= due_0_cache 0)))))
 (let (($x1155 (not active_0_query)))
 (let (($x13 (or $x1155 (not (<= due_0_query 0)))))
 (let (($x1271 (= state_0 0)))
 (and $x1271 (>= 0 now_0) $x13 $x440 $x575 $x1283 $x1033 $x1310 active_1_query $x298 $x811 $x515))))))))))))))
(assert
 true)
(assert
 (let (($x877 (= due_2_cache due_1_cache)))
 (let (($x28 (= due_2_query due_1_query)))
 (let (($x489 (= active_2_cache active_1_cache)))
 (let (($x172 (= active_2_query active_1_query)))
 (let (($x1131 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1346 (= v_2_retry_count v_1_retry_count)))
 (let (($x1248 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x965 (= 1 state_2)))
 (let (($x1351 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x1170 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x427 (= state_1 1)))
 (and $x427 $x1170 $x1351 $x965 $x1248 $x1346 $x1131 $x172 $x489 $x28 $x877)))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x699 (= due_3_cache due_2_cache)))
 (let (($x197 (= due_3_query 2000)))
 (let (($x1035 (= active_3_cache active_2_cache)))
 (let (($x682 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x454 (= 1 v_3_retry_count)))
 (let (($x842 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x179 (= 1 state_3)))
 (let (($x393 (= 0 v_2_retry_count)))
 (let (($x1323 (= state_2 1)))
 (and $x1323 $x393 active_2_query (= 1000 due_2_query) (or (not active_2_cache) (not (<= due_2_cache due_2_query))) $x179 $x842 $x454 $x682 active_3_query $x1035 $x197 $x699)))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x602 (= due_4_cache due_3_cache)))
 (let (($x543 (= due_4_query due_3_query)))
 (let (($x518 (= active_4_cache active_3_cache)))
 (let (($x158 (not active_4_query)))
 (let (($x1236 (= v_4_cache_ttl_ms v_3_cache_ttl_ms)))
 (let (($x221 (= 0 v_4_retry_count)))
 (let (($x107 (= (as seq.empty (Seq (_ BitVec 8))) v_4_peer_mac)))
 (let (($x1046 (= 0 state_4)))
 (let (($x454 (= 1 v_3_retry_count)))
 (let (($x56 (= state_3 1)))
 (and $x56 $x454 active_3_query (= 2000 due_3_query) (or (not active_3_cache) (not (<= due_3_cache due_3_query))) $x1046 $x107 $x221 $x1236 $x158 $x518 $x543 $x602))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x463 (seq.unit (_ bv192 8))))
 (let ((?x178 (seq.++ ?x463 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x178))))
(assert
 (= 1 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x463 (seq.unit (_ bv192 8))))
 (let ((?x178 (seq.++ ?x463 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_1_app.resolve_ip ?x178))))
(assert
 (= 3 choice_2))
(assert
 (= 1000 now_3))
(assert
 (= 4 choice_3))
(assert
 (= 2000 now_4))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x1015 (= due_1_cache 60000)))
 (let (($x1058 (= due_1_query due_0_query)))
 (let (($x417 (not active_1_query)))
 (let (($x1318 (= v_1_cache_ttl_ms 60000)))
 (let (($x308 (= 0 v_1_retry_count)))
 (let ((?x504 (seq.unit (_ bv0 8))))
 (let ((?x345 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.unit (_ bv2 8))))))))
 (let ((?x696 (seq.unit (_ bv2 8))))
 (let (($x238 (= v_1_peer_mac (seq.++ ?x696 ?x345))))
 (let (($x852 (= 2 state_1)))
 (let (($x1032 (not active_0_cache)))
 (let (($x538 (or $x1032 (not (<= due_0_cache 0)))))
 (let (($x797 (not active_0_query)))
 (let (($x591 (or $x797 (not (<= due_0_query 0)))))
 (let (($x115 (= state_0 0)))
 (and $x115 (>= 0 now_0) $x591 $x538 $x852 $x238 $x308 $x1318 $x417 active_1_cache $x1058 $x1015)))))))))))))))))
(assert
 true)
(assert
 (let (($x82 (= due_2_query due_1_query)))
 (let (($x944 (not active_2_query)))
 (let (($x81 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x1158 (= 0 v_2_retry_count)))
 (let ((?x504 (seq.unit (_ bv0 8))))
 (let ((?x1203 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.unit (_ bv3 8))))))))
 (let ((?x696 (seq.unit (_ bv2 8))))
 (let (($x333 (= v_2_peer_mac (seq.++ ?x696 ?x1203))))
 (let (($x284 (= 2 state_2)))
 (let (($x800 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x417 (not active_1_query)))
 (let (($x400 (or $x417 (not (<= due_1_query 5)))))
 (let (($x231 (= state_1 2)))
 (and $x231 $x400 $x800 $x284 $x333 $x1158 $x81 $x944 active_2_cache $x82 (= due_2_cache (+ 5 v_1_cache_ttl_ms)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x455 (= due_3_cache due_2_cache)))
 (let (($x1265 (= due_3_query due_2_query)))
 (let (($x846 (= active_3_cache active_2_cache)))
 (let (($x690 (= active_3_query active_2_query)))
 (let (($x208 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x786 (= v_3_retry_count v_2_retry_count)))
 (let (($x952 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x546 (= 2 state_3)))
 (let (($x11 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x944 (not active_2_query)))
 (let (($x495 (or $x944 (not (<= due_2_query 10)))))
 (let (($x677 (= state_2 2)))
 (and $x677 $x495 $x11 $x546 $x952 $x786 $x208 $x690 $x846 $x1265 $x455))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 9 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x390 (seq.unit (_ bv192 8))))
 (let ((?x49 (seq.++ ?x390 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x908 (seq.unit (_ bv1 8))))
 (let ((?x504 (seq.unit (_ bv0 8))))
 (let ((?x1059 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x908 ?x49)))))))
 (let ((?x696 (seq.unit (_ bv2 8))))
 (let ((?x34 (seq.++ ?x390 (seq.++ ?x504 (seq.++ ?x696 (seq.++ ?x696 (seq.++ ?x696 ?x1059)))))))
 (let ((?x602 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x696 ?x34)))))))
 (let ((?x832 (seq.unit (_ bv4 8))))
 (let ((?x930 (seq.unit (_ bv6 8))))
 (let ((?x968 (seq.++ ?x930 (seq.++ ?x832 (seq.++ ?x504 (seq.++ ?x696 (seq.++ ?x696 ?x602)))))))
 (let ((?x90 (seq.unit (_ bv8 8))))
 (let ((?x866 (seq.++ ?x930 (seq.++ ?x504 (seq.++ ?x908 (seq.++ ?x90 (seq.++ ?x504 ?x968)))))))
 (let ((?x6 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x696 (seq.++ ?x90 ?x866)))))))
 (let ((?x771 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x908 (seq.++ ?x696 (seq.++ ?x504 ?x6)))))))
 (let ((?x1237 (seq.++ ?x696 (seq.++ ?x504 (seq.++ ?x504 ?x771)))))
 (= input_0_net.frame_frame ?x1237))))))))))))))))))
(assert
 (= 19 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x390 (seq.unit (_ bv192 8))))
 (let ((?x49 (seq.++ ?x390 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x908 (seq.unit (_ bv1 8))))
 (let ((?x504 (seq.unit (_ bv0 8))))
 (let ((?x1059 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x908 ?x49)))))))
 (let ((?x696 (seq.unit (_ bv2 8))))
 (let ((?x34 (seq.++ ?x390 (seq.++ ?x504 (seq.++ ?x696 (seq.++ ?x696 (seq.++ ?x696 ?x1059)))))))
 (let ((?x650 (seq.unit (_ bv3 8))))
 (let ((?x29 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x650 ?x34)))))))
 (let ((?x832 (seq.unit (_ bv4 8))))
 (let ((?x930 (seq.unit (_ bv6 8))))
 (let ((?x710 (seq.++ ?x930 (seq.++ ?x832 (seq.++ ?x504 (seq.++ ?x696 (seq.++ ?x696 ?x29)))))))
 (let ((?x90 (seq.unit (_ bv8 8))))
 (let ((?x414 (seq.++ ?x930 (seq.++ ?x504 (seq.++ ?x908 (seq.++ ?x90 (seq.++ ?x504 ?x710)))))))
 (let ((?x447 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x650 (seq.++ ?x90 ?x414)))))))
 (let ((?x579 (seq.++ ?x504 (seq.++ ?x504 (seq.++ ?x908 (seq.++ ?x696 (seq.++ ?x504 ?x447)))))))
 (let ((?x408 (seq.++ ?x696 (seq.++ ?x504 (seq.++ ?x504 ?x579)))))
 (= input_1_net.frame_frame ?x408)))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x390 (seq.unit (_ bv192 8))))
(let ((?x990 (seq.++ ?x390 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x990))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x337 (= due_1_cache due_0_cache)))
 (let (($x426 (= due_1_query 1000)))
 (let (($x1271 (= active_1_cache active_0_cache)))
 (let (($x226 (= v_1_cache_ttl_ms 60000)))
 (let (($x877 (= 0 v_1_retry_count)))
 (let (($x1322 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x489 (= 1 state_1)))
 (let (($x1292 (not active_0_cache)))
 (let (($x676 (or $x1292 (not (<= due_0_cache 0)))))
 (let (($x534 (not active_0_query)))
 (let (($x1082 (or $x534 (not (<= due_0_query 0)))))
 (let (($x554 (= state_0 0)))
 (and $x554 (>= 0 now_0) $x1082 $x676 $x489 $x1322 $x877 $x226 active_1_query $x1271 $x426 $x337))))))))))))))
(assert
 true)
(assert
 (let (($x202 (= due_2_query due_1_query)))
 (let (($x1019 (not active_2_query)))
 (let (($x341 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x862 (= 0 v_2_retry_count)))
 (let ((?x230 (seq.unit (_ bv0 8))))
 (let ((?x333 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.unit (_ bv3 8))))))))
 (let ((?x926 (seq.unit (_ bv2 8))))
 (let (($x1105 (= v_2_peer_mac (seq.++ ?x926 ?x333))))
 (let (($x818 (= 2 state_2)))
 (let (($x893 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x603 (or (not active_1_query) (not (<= due_1_query 10)))))
 (let (($x1164 (= state_1 1)))
 (and $x1164 $x603 $x893 $x818 $x1105 $x862 $x341 $x1019 active_2_cache $x202 (= due_2_cache (+ 10 v_1_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1066 (seq.unit (_ bv192 8))))
 (let ((?x1014 (seq.++ ?x1066 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x1014))))
(assert
 (= 13 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x1066 (seq.unit (_ bv192 8))))
(let ((?x1109 (seq.++ ?x1066 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x230 (seq.unit (_ bv0 8))))
(let ((?x1081 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 ?x1109)))))))
(let ((?x926 (seq.unit (_ bv2 8))))
(let ((?x203 (seq.++ ?x1066 (seq.++ ?x230 (seq.++ ?x926 (seq.++ ?x926 (seq.++ ?x230 ?x1081)))))))
(let ((?x947 (seq.unit (_ bv3 8))))
(let ((?x814 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x947 ?x203)))))))
(let ((?x132 (seq.unit (_ bv1 8))))
(let ((?x543 (seq.unit (_ bv4 8))))
(let ((?x518 (seq.unit (_ bv6 8))))
(let ((?x979 (seq.++ ?x518 (seq.++ ?x543 (seq.++ ?x230 (seq.++ ?x132 (seq.++ ?x926 ?x814)))))))
(let ((?x158 (seq.unit (_ bv8 8))))
(let ((?x43 (seq.++ ?x518 (seq.++ ?x230 (seq.++ ?x132 (seq.++ ?x158 (seq.++ ?x230 ?x979)))))))
(let ((?x550 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x230 (seq.++ ?x947 (seq.++ ?x158 ?x43)))))))
(let ((?x1048 (seq.unit (_ bv255 8))))
(let ((?x272 (seq.++ ?x1048 (seq.++ ?x1048 (seq.++ ?x1048 (seq.++ ?x926 (seq.++ ?x230 ?x550)))))))
(let ((?x891 (seq.++ ?x1048 (seq.++ ?x1048 (seq.++ ?x1048 ?x272)))))
(= input_1_net.frame_frame ?x891))))))))))))))))))))
(check-sat)

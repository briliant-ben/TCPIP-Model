; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x886 (= due_1_cache 60000)))
 (let (($x1252 (= due_1_query due_0_query)))
 (let (($x330 (not active_1_query)))
 (let (($x183 (= v_1_cache_ttl_ms 60000)))
 (let (($x289 (= 0 v_1_retry_count)))
 (let ((?x847 (seq.unit (_ bv0 8))))
 (let ((?x787 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 (seq.unit (_ bv2 8))))))))
 (let ((?x247 (seq.unit (_ bv2 8))))
 (let (($x839 (= v_1_peer_mac (seq.++ ?x247 ?x787))))
 (let (($x970 (= 2 state_1)))
 (let (($x338 (not active_0_cache)))
 (let (($x1242 (or $x338 (not (<= due_0_cache 0)))))
 (let (($x931 (not active_0_query)))
 (let (($x1027 (or $x931 (not (<= due_0_query 0)))))
 (let (($x136 (= state_0 0)))
 (and $x136 (>= 0 now_0) $x1027 $x1242 $x970 $x839 $x289 $x183 $x330 active_1_cache $x1252 $x886)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x805 (seq.unit (_ bv14 8))))
(let ((?x589 (seq.++ ?x805 (seq.++ (seq.unit (_ bv15 8)) (seq.++ (seq.unit (_ bv16 8)) (seq.unit (_ bv17 8)))))))
(let ((?x842 (seq.unit (_ bv13 8))))
(let ((?x1155 (seq.unit (_ bv12 8))))
(let ((?x915 (seq.unit (_ bv11 8))))
(let ((?x1278 (seq.unit (_ bv10 8))))
(let ((?x882 (seq.unit (_ bv9 8))))
(let ((?x1254 (seq.++ ?x882 (seq.++ ?x1278 (seq.++ ?x915 (seq.++ ?x1155 (seq.++ ?x842 ?x589)))))))
(let ((?x232 (seq.unit (_ bv8 8))))
(let ((?x359 (seq.unit (_ bv7 8))))
(let ((?x231 (seq.unit (_ bv6 8))))
(let ((?x241 (seq.unit (_ bv5 8))))
(let ((?x235 (seq.unit (_ bv4 8))))
(let ((?x193 (seq.++ ?x235 (seq.++ ?x241 (seq.++ ?x231 (seq.++ ?x359 (seq.++ ?x232 ?x1254)))))))
(let ((?x535 (seq.unit (_ bv3 8))))
(let ((?x247 (seq.unit (_ bv2 8))))
(let ((?x130 (seq.unit (_ bv1 8))))
(let ((?x847 (seq.unit (_ bv0 8))))
(let ((?x825 (seq.++ ?x130 (seq.++ ?x847 (seq.++ ?x130 (seq.++ ?x247 (seq.++ ?x535 ?x193)))))))
(let ((?x1275 (seq.unit (_ bv192 8))))
(let ((?x670 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x1275 (seq.++ ?x847 (seq.++ ?x247 ?x825)))))))
(let ((?x526 (seq.++ ?x247 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 ?x670)))))))
(let ((?x503 (seq.++ ?x847 (seq.++ ?x247 (seq.++ ?x1275 (seq.++ ?x847 (seq.++ ?x247 ?x526)))))))
(let ((?x851 (seq.++ ?x130 (seq.++ ?x247 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 ?x503)))))))
(let ((?x198 (seq.++ ?x232 (seq.++ ?x847 (seq.++ ?x231 (seq.++ ?x235 (seq.++ ?x847 ?x851)))))))
(let ((?x869 (seq.++ ?x247 (seq.++ ?x232 (seq.++ ?x231 (seq.++ ?x847 (seq.++ ?x130 ?x198)))))))
(let ((?x414 (seq.++ ?x247 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 (seq.++ ?x847 ?x869)))))))
(let ((?x778 (seq.unit (_ bv255 8))))
(let ((?x472 (seq.++ ?x778 (seq.++ ?x778 (seq.++ ?x778 (seq.++ ?x778 (seq.++ ?x778 ?x414)))))))
(let ((?x237 (seq.++ ?x778 ?x472)))
(= input_0_net.frame_frame ?x237))))))))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x958 (= due_1_cache due_0_cache)))
 (let (($x1133 (= due_1_query due_0_query)))
 (let (($x485 (= active_1_cache active_0_cache)))
 (let (($x480 (= active_1_query active_0_query)))
 (let (($x137 (= v_1_cache_ttl_ms 60000)))
 (let (($x808 (= v_1_retry_count 0)))
 (let (($x677 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1020 (= 0 state_1)))
 (let (($x1240 (not active_0_cache)))
 (let (($x219 (or $x1240 (not (<= due_0_cache 0)))))
 (let (($x736 (not active_0_query)))
 (let (($x880 (or $x736 (not (<= due_0_query 0)))))
 (let (($x1066 (= state_0 0)))
 (and $x1066 (>= 0 now_0) $x880 $x219 $x1020 $x677 $x808 $x137 $x480 $x485 $x1133 $x958)))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 10 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x242 (seq.unit (_ bv192 8))))
(let ((?x150 (seq.++ ?x242 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
(let ((?x607 (seq.unit (_ bv0 8))))
(let ((?x44 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x607 ?x150)))))))
(let ((?x26 (seq.unit (_ bv2 8))))
(let ((?x860 (seq.++ ?x242 (seq.++ ?x607 (seq.++ ?x26 (seq.++ ?x26 (seq.++ ?x607 ?x44)))))))
(let ((?x48 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x26 ?x860)))))))
(let ((?x56 (seq.unit (_ bv1 8))))
(let ((?x440 (seq.unit (_ bv4 8))))
(let ((?x201 (seq.unit (_ bv6 8))))
(let ((?x698 (seq.++ ?x201 (seq.++ ?x440 (seq.++ ?x607 (seq.++ ?x56 (seq.++ ?x26 ?x48)))))))
(let ((?x636 (seq.unit (_ bv8 8))))
(let ((?x1276 (seq.++ ?x201 (seq.++ ?x607 (seq.++ ?x56 (seq.++ ?x636 (seq.++ ?x607 ?x698)))))))
(let ((?x200 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x607 (seq.++ ?x26 (seq.++ ?x636 ?x1276)))))))
(let ((?x595 (seq.unit (_ bv255 8))))
(let ((?x1275 (seq.++ ?x595 (seq.++ ?x595 (seq.++ ?x595 (seq.++ ?x26 (seq.++ ?x607 ?x200)))))))
(let ((?x585 (seq.++ ?x595 (seq.++ ?x595 (seq.++ ?x595 ?x1275)))))
(= input_0_net.frame_frame ?x585)))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x528 (= due_1_cache due_0_cache)))
 (let (($x962 (= due_1_query 1000)))
 (let (($x1069 (= active_1_cache active_0_cache)))
 (let (($x610 (= v_1_cache_ttl_ms 60000)))
 (let (($x750 (= 0 v_1_retry_count)))
 (let (($x1052 (= (as seq.empty (Seq (_ BitVec 8))) v_1_peer_mac)))
 (let (($x1268 (= 1 state_1)))
 (let (($x179 (not active_0_cache)))
 (let (($x1204 (or $x179 (not (<= due_0_cache 0)))))
 (let (($x576 (not active_0_query)))
 (let (($x456 (or $x576 (not (<= due_0_query 0)))))
 (let (($x466 (= state_0 0)))
 (and $x466 (>= 0 now_0) $x456 $x1204 $x1268 $x1052 $x750 $x610 active_1_query $x1069 $x962 $x528))))))))))))))
(assert
 true)
(assert
 (let (($x764 (= due_2_cache due_1_cache)))
 (let (($x558 (= due_2_query due_1_query)))
 (let (($x1309 (= active_2_cache active_1_cache)))
 (let (($x586 (= active_2_query active_1_query)))
 (let (($x1181 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x471 (= v_2_retry_count v_1_retry_count)))
 (let (($x497 (= v_2_peer_mac v_1_peer_mac)))
 (let (($x743 (= 1 state_2)))
 (let (($x280 (or (not active_1_cache) (not (<= due_1_cache 5)))))
 (let (($x1051 (or (not active_1_query) (not (<= due_1_query 5)))))
 (let (($x1143 (= state_1 1)))
 (and $x1143 $x1051 $x280 $x743 $x497 $x471 $x1181 $x586 $x1309 $x558 $x764)))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x717 (= due_3_query due_2_query)))
 (let (($x182 (not active_3_query)))
 (let (($x910 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x521 (= 0 v_3_retry_count)))
 (let ((?x918 (seq.unit (_ bv0 8))))
 (let ((?x264 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.unit (_ bv2 8))))))))
 (let ((?x796 (seq.unit (_ bv2 8))))
 (let (($x568 (= v_3_peer_mac (seq.++ ?x796 ?x264))))
 (let (($x220 (= 2 state_3)))
 (let (($x1317 (or (not active_2_cache) (not (<= due_2_cache 10)))))
 (let (($x651 (or (not active_2_query) (not (<= due_2_query 10)))))
 (let (($x932 (= state_2 1)))
 (and $x932 $x651 $x1317 $x220 $x568 $x521 $x910 $x182 active_3_cache $x717 (= due_3_cache (+ 10 v_2_cache_ttl_ms))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x153 (seq.unit (_ bv192 8))))
 (let ((?x1058 (seq.++ ?x153 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_app.resolve_ip ?x1058))))
(assert
 (= 15 choice_1))
(assert
 (= 5 now_2))
(assert
 (let ((?x153 (seq.unit (_ bv192 8))))
 (let ((?x224 (seq.++ ?x153 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x918 (seq.unit (_ bv0 8))))
 (let ((?x1210 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 ?x224)))))))
 (let ((?x796 (seq.unit (_ bv2 8))))
 (let ((?x1300 (seq.++ ?x153 (seq.++ ?x918 (seq.++ ?x796 (seq.++ ?x796 (seq.++ ?x918 ?x1210)))))))
 (let ((?x427 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x796 ?x1300)))))))
 (let ((?x442 (seq.unit (_ bv1 8))))
 (let ((?x966 (seq.unit (_ bv4 8))))
 (let ((?x391 (seq.unit (_ bv6 8))))
 (let ((?x540 (seq.++ ?x391 (seq.++ ?x966 (seq.++ ?x918 (seq.++ ?x442 (seq.++ ?x796 ?x427)))))))
 (let ((?x48 (seq.unit (_ bv8 8))))
 (let ((?x337 (seq.++ ?x391 (seq.++ ?x918 (seq.++ ?x442 (seq.++ ?x48 (seq.++ ?x918 ?x540)))))))
 (let ((?x1331 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x796 (seq.++ ?x48 ?x337)))))))
 (let ((?x1263 (seq.unit (_ bv255 8))))
 (let ((?x495 (seq.++ ?x1263 (seq.++ ?x1263 (seq.++ ?x1263 (seq.++ ?x796 (seq.++ ?x918 ?x1331)))))))
 (let ((?x126 (seq.++ ?x1263 (seq.++ ?x1263 (seq.++ ?x1263 ?x495)))))
 (= input_1_net.frame_frame ?x126)))))))))))))))))))
(assert
 (= 14 choice_2))
(assert
 (= 10 now_3))
(assert
 (let ((?x153 (seq.unit (_ bv192 8))))
(let ((?x636 (seq.++ ?x153 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x442 (seq.unit (_ bv1 8))))
(let ((?x918 (seq.unit (_ bv0 8))))
(let ((?x162 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x442 ?x636)))))))
(let ((?x796 (seq.unit (_ bv2 8))))
(let ((?x313 (seq.++ ?x153 (seq.++ ?x918 (seq.++ ?x796 (seq.++ ?x796 (seq.++ ?x796 ?x162)))))))
(let ((?x1176 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x796 ?x313)))))))
(let ((?x966 (seq.unit (_ bv4 8))))
(let ((?x391 (seq.unit (_ bv6 8))))
(let ((?x71 (seq.++ ?x391 (seq.++ ?x966 (seq.++ ?x918 (seq.++ ?x796 (seq.++ ?x796 ?x1176)))))))
(let ((?x48 (seq.unit (_ bv8 8))))
(let ((?x1352 (seq.++ ?x391 (seq.++ ?x918 (seq.++ ?x442 (seq.++ ?x48 (seq.++ ?x918 ?x71)))))))
(let ((?x45 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x796 (seq.++ ?x48 ?x1352)))))))
(let ((?x239 (seq.++ ?x918 (seq.++ ?x918 (seq.++ ?x442 (seq.++ ?x796 (seq.++ ?x918 ?x45)))))))
(let ((?x1333 (seq.++ ?x796 (seq.++ ?x918 (seq.++ ?x918 ?x239)))))
(= input_2_net.frame_frame ?x1333))))))))))))))))))
(check-sat)

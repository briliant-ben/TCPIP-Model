; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x238 (= due_1_cache 60000)))
 (let (($x854 (= due_1_query due_0_query)))
 (let (($x237 (not active_1_query)))
 (let (($x515 (= v_1_cache_ttl_ms 60000)))
 (let (($x37 (= 0 v_1_retry_count)))
 (let ((?x959 (seq.unit (_ bv0 8))))
 (let ((?x333 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.unit (_ bv2 8))))))))
 (let ((?x961 (seq.unit (_ bv2 8))))
 (let (($x236 (= v_1_peer_mac (seq.++ ?x961 ?x333))))
 (let (($x40 (= 2 state_1)))
 (let (($x827 (not active_0_cache)))
 (let (($x235 (or $x827 (not (<= due_0_cache 0)))))
 (let (($x825 (not active_0_query)))
 (let (($x232 (or $x825 (not (<= due_0_query 0)))))
 (let (($x712 (= state_0 0)))
 (and $x712 (>= 0 now_0) $x232 $x235 $x40 $x236 $x37 $x515 $x237 active_1_cache $x854 $x238)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x957 (seq.unit (_ bv192 8))))
(let ((?x967 (seq.++ ?x957 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x959 (seq.unit (_ bv0 8))))
(let ((?x897 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 ?x967)))))))
(let ((?x961 (seq.unit (_ bv2 8))))
(let ((?x300 (seq.++ ?x957 (seq.++ ?x959 (seq.++ ?x961 (seq.++ ?x961 (seq.++ ?x959 ?x897)))))))
(let ((?x305 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x961 ?x300)))))))
(let ((?x289 (seq.unit (_ bv1 8))))
(let ((?x403 (seq.unit (_ bv4 8))))
(let ((?x400 (seq.unit (_ bv6 8))))
(let ((?x310 (seq.++ ?x400 (seq.++ ?x403 (seq.++ ?x959 (seq.++ ?x289 (seq.++ ?x961 ?x305)))))))
(let ((?x1020 (seq.unit (_ bv8 8))))
(let ((?x314 (seq.++ ?x400 (seq.++ ?x959 (seq.++ ?x289 (seq.++ ?x1020 (seq.++ ?x959 ?x310)))))))
(let ((?x318 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x959 (seq.++ ?x961 (seq.++ ?x1020 ?x314)))))))
(let ((?x292 (seq.unit (_ bv255 8))))
(let ((?x323 (seq.++ ?x292 (seq.++ ?x292 (seq.++ ?x292 (seq.++ ?x961 (seq.++ ?x959 ?x318)))))))
(let ((?x326 (seq.++ ?x292 (seq.++ ?x292 (seq.++ ?x292 ?x323)))))
(= input_0_net.frame_frame ?x326)))))))))))))))))))
(check-sat)

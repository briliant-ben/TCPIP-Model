; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_query () Bool)
(declare-fun due_0_query () Int)
(declare-fun active_0_cache () Bool)
(declare-fun due_0_cache () Int)
(declare-fun due_1_cache () Int)
(declare-fun due_1_query () Int)
(declare-fun active_1_cache () Bool)
(declare-fun active_1_query () Bool)
(declare-fun v_1_cache_ttl_ms () Int)
(declare-fun v_1_retry_count () Int)
(declare-fun v_1_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_cache () Int)
(declare-fun due_2_query () Int)
(declare-fun active_2_cache () Bool)
(declare-fun active_2_query () Bool)
(declare-fun v_2_cache_ttl_ms () Int)
(declare-fun v_2_retry_count () Int)
(declare-fun v_2_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_cache () Int)
(declare-fun due_3_query () Int)
(declare-fun active_3_cache () Bool)
(declare-fun active_3_query () Bool)
(declare-fun v_3_cache_ttl_ms () Int)
(declare-fun v_3_retry_count () Int)
(declare-fun v_3_peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_retry_count () Int)
(declare-fun v_0_cache_ttl_ms () Int)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_app.resolve_ip () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_query))
(assert
 (= due_0_query 0))
(assert
 (not active_0_cache))
(assert
 (= due_0_cache 0))
(assert
 true)
(assert
 (let (($x570 (= due_1_cache 60000)))
 (let (($x808 (= due_1_query due_0_query)))
 (let (($x735 (not active_1_query)))
 (let (($x304 (= v_1_cache_ttl_ms 60000)))
 (let (($x104 (= 0 v_1_retry_count)))
 (let ((?x712 (seq.unit (_ bv0 8))))
 (let ((?x98 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.unit (_ bv2 8))))))))
 (let ((?x734 (seq.unit (_ bv2 8))))
 (let (($x517 (= v_1_peer_mac (seq.++ ?x734 ?x98))))
 (let (($x120 (= 2 state_1)))
 (let (($x951 (not active_0_cache)))
 (let (($x865 (or $x951 (not (<= due_0_cache 0)))))
 (let (($x326 (not active_0_query)))
 (let (($x261 (or $x326 (not (<= due_0_query 0)))))
 (let (($x302 (= state_0 0)))
 (and $x302 (>= 0 now_0) $x261 $x865 $x120 $x517 $x104 $x304 $x735 active_1_cache $x808 $x570)))))))))))))))))
(assert
 true)
(assert
 (let (($x741 (= due_2_query due_1_query)))
 (let (($x144 (= active_2_query active_1_query)))
 (let (($x831 (= v_2_cache_ttl_ms v_1_cache_ttl_ms)))
 (let (($x699 (= v_2_retry_count v_1_retry_count)))
 (let ((?x712 (seq.unit (_ bv0 8))))
 (let ((?x374 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.unit (_ bv3 8))))))))
 (let ((?x734 (seq.unit (_ bv2 8))))
 (let (($x1170 (= v_2_peer_mac (seq.++ ?x734 ?x374))))
 (let (($x221 (= 2 state_2)))
 (let (($x704 (or (not active_1_cache) (not (<= due_1_cache 10)))))
 (let (($x735 (not active_1_query)))
 (let (($x996 (or $x735 (not (<= due_1_query 10)))))
 (let (($x578 (= state_1 2)))
 (and $x578 $x996 $x704 $x221 $x1170 $x699 $x831 $x144 active_2_cache $x741 (= due_2_cache (+ 10 v_1_cache_ttl_ms)))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x875 (= due_3_cache due_2_cache)))
 (let (($x339 (= due_3_query due_2_query)))
 (let (($x731 (= active_3_cache active_2_cache)))
 (let (($x385 (= active_3_query active_2_query)))
 (let (($x1252 (= v_3_cache_ttl_ms v_2_cache_ttl_ms)))
 (let (($x214 (= v_3_retry_count v_2_retry_count)))
 (let (($x970 (= v_3_peer_mac v_2_peer_mac)))
 (let (($x437 (= 2 state_3)))
 (let (($x606 (or (not active_2_cache) (not (<= due_2_cache 20)))))
 (let (($x443 (or (not active_2_query) (not (<= due_2_query 20)))))
 (let (($x1128 (= state_2 2)))
 (and $x1128 $x443 $x606 $x437 $x970 $x214 $x1252 $x385 $x731 $x339 $x875)))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_retry_count))
(assert
 (= 60000 v_0_cache_ttl_ms))
(assert
 (= 8 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x819 (seq.unit (_ bv192 8))))
 (let ((?x576 (seq.++ ?x819 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x712 (seq.unit (_ bv0 8))))
 (let ((?x199 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 ?x576)))))))
 (let ((?x734 (seq.unit (_ bv2 8))))
 (let ((?x1240 (seq.++ ?x819 (seq.++ ?x712 (seq.++ ?x734 (seq.++ ?x734 (seq.++ ?x712 ?x199)))))))
 (let ((?x247 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x734 ?x1240)))))))
 (let ((?x19 (seq.unit (_ bv1 8))))
 (let ((?x670 (seq.unit (_ bv4 8))))
 (let ((?x665 (seq.unit (_ bv6 8))))
 (let ((?x759 (seq.++ ?x665 (seq.++ ?x670 (seq.++ ?x712 (seq.++ ?x19 (seq.++ ?x734 ?x247)))))))
 (let ((?x894 (seq.unit (_ bv8 8))))
 (let ((?x26 (seq.++ ?x665 (seq.++ ?x712 (seq.++ ?x19 (seq.++ ?x894 (seq.++ ?x712 ?x759)))))))
 (let ((?x903 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x734 (seq.++ ?x894 ?x26)))))))
 (let ((?x25 (seq.unit (_ bv255 8))))
 (let ((?x681 (seq.++ ?x25 (seq.++ ?x25 (seq.++ ?x25 (seq.++ ?x734 (seq.++ ?x712 ?x903)))))))
 (let ((?x245 (seq.++ ?x25 (seq.++ ?x25 (seq.++ ?x25 ?x681)))))
 (= input_0_net.frame_frame ?x245)))))))))))))))))))
(assert
 (= 20 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x819 (seq.unit (_ bv192 8))))
 (let ((?x835 (seq.++ ?x819 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv3 8)))))))
 (let ((?x712 (seq.unit (_ bv0 8))))
 (let ((?x709 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 ?x835)))))))
 (let ((?x734 (seq.unit (_ bv2 8))))
 (let ((?x1238 (seq.++ ?x819 (seq.++ ?x712 (seq.++ ?x734 (seq.++ ?x734 (seq.++ ?x712 ?x709)))))))
 (let ((?x856 (seq.unit (_ bv3 8))))
 (let ((?x1214 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x856 ?x1238)))))))
 (let ((?x19 (seq.unit (_ bv1 8))))
 (let ((?x670 (seq.unit (_ bv4 8))))
 (let ((?x665 (seq.unit (_ bv6 8))))
 (let ((?x1217 (seq.++ ?x665 (seq.++ ?x670 (seq.++ ?x712 (seq.++ ?x19 (seq.++ ?x734 ?x1214)))))))
 (let ((?x894 (seq.unit (_ bv8 8))))
 (let ((?x1077 (seq.++ ?x665 (seq.++ ?x712 (seq.++ ?x19 (seq.++ ?x894 (seq.++ ?x712 ?x1217)))))))
 (let ((?x1204 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x712 (seq.++ ?x856 (seq.++ ?x894 ?x1077)))))))
 (let ((?x25 (seq.unit (_ bv255 8))))
 (let ((?x595 (seq.++ ?x25 (seq.++ ?x25 (seq.++ ?x25 (seq.++ ?x734 (seq.++ ?x712 ?x1204)))))))
 (let ((?x1237 (seq.++ ?x25 (seq.++ ?x25 (seq.++ ?x25 ?x595)))))
 (= input_1_net.frame_frame ?x1237))))))))))))))))))))
(assert
 (= 2 choice_2))
(assert
 (= 20 now_3))
(assert
 (let ((?x819 (seq.unit (_ bv192 8))))
(let ((?x153 (seq.++ ?x819 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
(= input_2_app.resolve_ip ?x153))))
(check-sat)

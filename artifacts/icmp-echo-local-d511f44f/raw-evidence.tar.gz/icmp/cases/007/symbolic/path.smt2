; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x837 (= v_1_disposition "reply")))
 (let ((?x193 (seq.unit (_ bv192 8))))
 (let ((?x497 (seq.++ ?x193 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x414 (seq.unit (_ bv1 8))))
 (let ((?x620 (seq.unit (_ bv2 8))))
 (let ((?x28 (seq.unit (_ bv0 8))))
 (let ((?x1524 (seq.++ ?x28 (seq.++ ?x193 (seq.++ ?x28 (seq.++ ?x620 (seq.++ ?x414 ?x497)))))))
 (let ((?x440 (seq.unit (_ bv64 8))))
 (let ((?x822 (seq.++ ?x440 (seq.++ ?x28 (seq.++ ?x440 (seq.++ ?x414 (seq.++ ?x28 ?x1524)))))))
 (let ((?x322 (seq.++ ?x28 (seq.++ ?x28 ?x822))))
 (let ((?x390 (seq.unit (_ bv33 8))))
 (let ((?x988 (seq.unit (_ bv69 8))))
 (let (($x2370 (= v_1_ip_zero (seq.++ ?x988 (seq.++ ?x28 (seq.++ ?x28 (seq.++ ?x390 ?x322)))))))
 (let ((?x834 (seq.unit (_ bv128 8))))
 (let ((?x1435 (seq.++ ?x28 (seq.++ ?x834 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) ?x28))))))
 (let ((?x365 (seq.unit (_ bv205 8))))
 (let ((?x1035 (seq.unit (_ bv171 8))))
 (let ((?x1074 (seq.unit (_ bv52 8))))
 (let ((?x1341 (seq.unit (_ bv18 8))))
 (let ((?x1259 (seq.++ ?x1341 (seq.++ ?x1074 (seq.++ ?x1035 (seq.++ ?x365 ?x1435))))))
 (let ((?x1420 (seq.unit (_ bv118 8))))
 (let ((?x541 (seq.++ ?x1420 ?x1259)))
 (let ((?x2310 (seq.++ ?x28 (seq.++ ?x28 (seq.++ (seq.unit (_ bv66 8)) ?x541)))))
 (let (($x2369 (= v_1_icmp_wire ?x2310)))
 (let (($x2368 (= v_1_icmp_zero (seq.++ ?x28 (seq.++ ?x28 (seq.++ ?x28 (seq.++ ?x28 ?x1259)))))))
 (let ((?x2351 (seq.++ ?x414 (seq.++ ?x193 (seq.++ ?x28 (seq.++ ?x620 (seq.++ ?x620 ?x2310)))))))
 (let ((?x171 (seq.unit (_ bv216 8))))
 (let ((?x597 (seq.unit (_ bv182 8))))
 (let ((?x2356 (seq.++ ?x597 (seq.++ ?x171 (seq.++ ?x193 (seq.++ ?x28 (seq.++ ?x620 ?x2351)))))))
 (let ((?x2361 (seq.++ ?x28 (seq.++ ?x440 (seq.++ ?x28 (seq.++ ?x440 (seq.++ ?x414 ?x2356)))))))
 (let ((?x2366 (seq.++ ?x988 (seq.++ ?x28 (seq.++ ?x28 (seq.++ ?x390 (seq.++ ?x28 ?x2361)))))))
 (let (($x2367 (= v_1_reply ?x2366)))
 (let (($x1047 (= 0 state_1)))
 (let (($x86 (= state_0 0)))
 (and $x86 (>= 0 now_0) $x1047 $x2367 $x2368 $x2369 $x2370 $x837))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x834 (seq.unit (_ bv128 8))))
(let ((?x418 (seq.++ ?x834 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x28 (seq.unit (_ bv0 8))))
(let ((?x365 (seq.unit (_ bv205 8))))
(let ((?x1035 (seq.unit (_ bv171 8))))
(let ((?x1074 (seq.unit (_ bv52 8))))
(let ((?x1341 (seq.unit (_ bv18 8))))
(let ((?x1259 (seq.++ ?x1341 (seq.++ ?x1074 (seq.++ ?x1035 (seq.++ ?x365 (seq.++ ?x28 ?x418)))))))
(let ((?x1420 (seq.unit (_ bv118 8))))
(let ((?x541 (seq.++ ?x1420 ?x1259)))
(let ((?x1312 (seq.unit (_ bv58 8))))
(let ((?x1211 (seq.unit (_ bv8 8))))
(let ((?x414 (seq.unit (_ bv1 8))))
(let ((?x620 (seq.unit (_ bv2 8))))
(let ((?x732 (seq.++ ?x620 (seq.++ ?x414 (seq.++ ?x1211 (seq.++ ?x28 (seq.++ ?x1312 ?x541)))))))
(let ((?x193 (seq.unit (_ bv192 8))))
(let ((?x945 (seq.++ ?x28 (seq.++ ?x620 (seq.++ ?x620 (seq.++ ?x193 (seq.++ ?x28 ?x732)))))))
(let ((?x171 (seq.unit (_ bv216 8))))
(let ((?x597 (seq.unit (_ bv182 8))))
(let ((?x440 (seq.unit (_ bv64 8))))
(let ((?x332 (seq.++ ?x440 (seq.++ ?x414 (seq.++ ?x597 (seq.++ ?x171 (seq.++ ?x193 ?x945)))))))
(let ((?x390 (seq.unit (_ bv33 8))))
(let ((?x683 (seq.++ ?x390 (seq.++ ?x28 (seq.++ ?x28 (seq.++ ?x440 (seq.++ ?x28 ?x332)))))))
(let ((?x988 (seq.unit (_ bv69 8))))
(let ((?x636 (seq.++ ?x988 (seq.++ ?x28 (seq.++ ?x28 ?x683)))))
(= input_0_net.packet_packet ?x636)))))))))))))))))))))))))))
(check-sat)

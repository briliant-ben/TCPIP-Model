; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x513 (= v_1_disposition "reply")))
 (let ((?x2082 (seq.unit (_ bv192 8))))
 (let ((?x2073 (seq.++ ?x2082 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x2173 (seq.unit (_ bv1 8))))
 (let ((?x253 (seq.unit (_ bv2 8))))
 (let ((?x1627 (seq.unit (_ bv0 8))))
 (let ((?x347 (seq.++ ?x1627 (seq.++ ?x2082 (seq.++ ?x1627 (seq.++ ?x253 (seq.++ ?x2173 ?x2073)))))))
 (let ((?x1461 (seq.unit (_ bv64 8))))
 (let ((?x86 (seq.++ ?x1461 (seq.++ ?x1627 (seq.++ ?x1461 (seq.++ ?x2173 (seq.++ ?x1627 ?x347)))))))
 (let ((?x1079 (seq.++ ?x1627 (seq.++ ?x1627 ?x86))))
 (let ((?x1861 (seq.unit (_ bv28 8))))
 (let ((?x1921 (seq.unit (_ bv69 8))))
 (let (($x161 (= v_1_ip_zero (seq.++ ?x1921 (seq.++ ?x1627 (seq.++ ?x1627 (seq.++ ?x1861 ?x1079)))))))
 (let ((?x1611 (seq.++ ?x1627 (seq.++ (seq.unit (_ bv247 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ ?x1627 ?x1627))))))
 (let ((?x1935 (seq.unit (_ bv8 8))))
 (let ((?x2063 (seq.++ ?x1627 (seq.++ ?x1627 (seq.++ ?x1935 ?x1611)))))
 (let (($x964 (= v_1_icmp_wire ?x2063)))
 (let (($x1759 (= v_1_icmp_zero (seq.++ ?x1627 (seq.++ ?x1627 (seq.++ ?x1627 ?x1611))))))
 (let ((?x2195 (seq.++ ?x2173 (seq.++ ?x2082 (seq.++ ?x1627 (seq.++ ?x253 (seq.++ ?x253 ?x2063)))))))
 (let ((?x1792 (seq.unit (_ bv221 8))))
 (let ((?x549 (seq.unit (_ bv182 8))))
 (let ((?x1905 (seq.++ ?x549 (seq.++ ?x1792 (seq.++ ?x2082 (seq.++ ?x1627 (seq.++ ?x253 ?x2195)))))))
 (let ((?x2058 (seq.++ ?x1627 (seq.++ ?x1461 (seq.++ ?x1627 (seq.++ ?x1461 (seq.++ ?x2173 ?x1905)))))))
 (let ((?x787 (seq.++ ?x1921 (seq.++ ?x1627 (seq.++ ?x1627 (seq.++ ?x1861 (seq.++ ?x1627 ?x2058)))))))
 (let (($x1758 (= v_1_reply ?x787)))
 (let (($x675 (= 0 state_1)))
 (let (($x349 (= state_0 0)))
 (and $x349 (>= 0 now_0) $x675 $x1758 $x1759 $x964 $x161 $x513)))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1603 (seq.unit (_ bv247 8))))
(let ((?x930 (seq.++ ?x1603 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
(let ((?x1627 (seq.unit (_ bv0 8))))
(let ((?x1611 (seq.++ ?x1627 ?x930)))
(let ((?x1781 (seq.++ ?x1627 (seq.++ ?x1627 ?x1611))))
(let ((?x1935 (seq.unit (_ bv8 8))))
(let ((?x2173 (seq.unit (_ bv1 8))))
(let ((?x253 (seq.unit (_ bv2 8))))
(let ((?x2082 (seq.unit (_ bv192 8))))
(let ((?x839 (seq.++ ?x2082 (seq.++ ?x1627 (seq.++ ?x253 (seq.++ ?x2173 (seq.++ ?x1935 ?x1781)))))))
(let ((?x1792 (seq.unit (_ bv221 8))))
(let ((?x1206 (seq.++ ?x1792 (seq.++ ?x2082 (seq.++ ?x1627 (seq.++ ?x253 (seq.++ ?x253 ?x839)))))))
(let ((?x549 (seq.unit (_ bv182 8))))
(let ((?x1461 (seq.unit (_ bv64 8))))
(let ((?x44 (seq.++ ?x1461 (seq.++ ?x1627 (seq.++ ?x1461 (seq.++ ?x2173 (seq.++ ?x549 ?x1206)))))))
(let ((?x1861 (seq.unit (_ bv28 8))))
(let ((?x2237 (seq.++ ?x1627 (seq.++ ?x1627 (seq.++ ?x1861 (seq.++ ?x1627 (seq.++ ?x1627 ?x44)))))))
(let ((?x1921 (seq.unit (_ bv69 8))))
(let ((?x180 (seq.++ ?x1921 ?x2237)))
(= input_0_net.packet_packet ?x180)))))))))))))))))))))
(check-sat)

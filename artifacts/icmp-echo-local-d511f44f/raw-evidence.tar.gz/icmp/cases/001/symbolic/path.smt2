; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x86 (= v_1_disposition "drop_icmp_checksum")))
 (let (($x1361 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1446 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_wire)))
 (let (($x1224 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_zero)))
 (let (($x1225 (= (as seq.empty (Seq (_ BitVec 8))) v_1_reply)))
 (let (($x69 (= 0 state_1)))
 (let (($x745 (= state_0 0)))
 (and $x745 (>= 0 now_0) $x69 $x1225 $x1224 $x1446 $x1361 $x86)))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 3 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1422 (seq.unit (_ bv128 8))))
(let ((?x1338 (seq.++ ?x1422 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv1 8)))))))
(let ((?x16 (seq.unit (_ bv0 8))))
(let ((?x1420 (seq.unit (_ bv205 8))))
(let ((?x1418 (seq.unit (_ bv171 8))))
(let ((?x1416 (seq.unit (_ bv52 8))))
(let ((?x460 (seq.unit (_ bv18 8))))
(let ((?x1343 (seq.++ ?x460 (seq.++ ?x1416 (seq.++ ?x1418 (seq.++ ?x1420 (seq.++ ?x16 ?x1338)))))))
(let ((?x384 (seq.unit (_ bv118 8))))
(let ((?x381 (seq.unit (_ bv58 8))))
(let ((?x375 (seq.unit (_ bv8 8))))
(let ((?x610 (seq.unit (_ bv1 8))))
(let ((?x530 (seq.++ ?x610 (seq.++ ?x375 (seq.++ ?x16 (seq.++ ?x381 (seq.++ ?x384 ?x1343)))))))
(let ((?x17 (seq.unit (_ bv2 8))))
(let ((?x1552 (seq.unit (_ bv192 8))))
(let ((?x1377 (seq.++ ?x17 (seq.++ ?x17 (seq.++ ?x1552 (seq.++ ?x16 (seq.++ ?x17 ?x530)))))))
(let ((?x378 (seq.unit (_ bv216 8))))
(let ((?x371 (seq.unit (_ bv182 8))))
(let ((?x1464 (seq.++ ?x610 (seq.++ ?x371 (seq.++ ?x378 (seq.++ ?x1552 (seq.++ ?x16 ?x1377)))))))
(let ((?x367 (seq.unit (_ bv64 8))))
(let ((?x1477 (seq.++ ?x16 (seq.++ ?x16 (seq.++ ?x367 (seq.++ ?x16 (seq.++ ?x367 ?x1464)))))))
(let ((?x461 (seq.unit (_ bv33 8))))
(let ((?x508 (seq.unit (_ bv69 8))))
(let ((?x428 (seq.++ ?x508 (seq.++ ?x16 (seq.++ ?x16 (seq.++ ?x461 ?x1477))))))
(= input_0_net.packet_packet ?x428))))))))))))))))))))))))))
(check-sat)

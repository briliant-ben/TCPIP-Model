; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x586 (= v_1_disposition "reply")))
 (let ((?x1395 (seq.unit (_ bv192 8))))
 (let ((?x2300 (seq.++ ?x1395 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x2167 (seq.unit (_ bv1 8))))
 (let ((?x1867 (seq.unit (_ bv2 8))))
 (let ((?x1055 (seq.unit (_ bv0 8))))
 (let ((?x2285 (seq.++ ?x1055 (seq.++ ?x1395 (seq.++ ?x1055 (seq.++ ?x1867 (seq.++ ?x2167 ?x2300)))))))
 (let ((?x1359 (seq.unit (_ bv64 8))))
 (let ((?x1636 (seq.++ ?x1359 (seq.++ ?x1055 (seq.++ ?x1359 (seq.++ ?x2167 (seq.++ ?x1055 ?x2285)))))))
 (let ((?x1639 (seq.++ ?x1055 (seq.++ ?x1055 ?x1636))))
 (let ((?x1612 (seq.unit (_ bv31 8))))
 (let ((?x1082 (seq.unit (_ bv69 8))))
 (let (($x2382 (= v_1_ip_zero (seq.++ ?x1082 (seq.++ ?x1055 (seq.++ ?x1055 (seq.++ ?x1612 ?x1639)))))))
 (let ((?x1815 (seq.unit (_ bv205 8))))
 (let ((?x1490 (seq.++ ?x1815 (seq.++ (seq.unit (_ bv84 8)) (seq.++ (seq.unit (_ bv84 8)) (seq.unit (_ bv76 8)))))))
 (let ((?x831 (seq.unit (_ bv171 8))))
 (let ((?x2112 (seq.unit (_ bv52 8))))
 (let ((?x702 (seq.unit (_ bv18 8))))
 (let ((?x1263 (seq.++ ?x702 (seq.++ ?x2112 (seq.++ ?x831 ?x1490)))))
 (let ((?x1171 (seq.unit (_ bv169 8))))
 (let ((?x355 (seq.++ ?x1171 ?x1263)))
 (let ((?x2305 (seq.++ ?x1055 (seq.++ ?x1055 (seq.++ (seq.unit (_ bv161 8)) ?x355)))))
 (let (($x2381 (= v_1_icmp_wire ?x2305)))
 (let (($x2380 (= v_1_icmp_zero (seq.++ ?x1055 (seq.++ ?x1055 (seq.++ ?x1055 (seq.++ ?x1055 ?x1263)))))))
 (let ((?x1716 (seq.++ ?x2167 (seq.++ ?x1395 (seq.++ ?x1055 (seq.++ ?x1867 (seq.++ ?x1867 ?x2305)))))))
 (let ((?x652 (seq.++ (seq.unit (_ bv218 8)) (seq.++ ?x1395 (seq.++ ?x1055 (seq.++ ?x1867 ?x1716))))))
 (let ((?x2046 (seq.++ ?x1055 (seq.++ ?x1359 (seq.++ ?x2167 (seq.++ (seq.unit (_ bv182 8)) ?x652))))))
 (let ((?x2376 (seq.++ ?x1055 (seq.++ ?x1612 (seq.++ ?x1055 (seq.++ ?x1055 (seq.++ ?x1359 ?x2046)))))))
 (let (($x2379 (= v_1_reply (seq.++ ?x1082 (seq.++ ?x1055 ?x2376)))))
 (let (($x1227 (= 0 state_1)))
 (let (($x895 (= state_0 0)))
 (and $x895 (>= 0 now_0) $x1227 $x2379 $x2380 $x2381 $x2382 $x586)))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1815 (seq.unit (_ bv205 8))))
(let ((?x1490 (seq.++ ?x1815 (seq.++ (seq.unit (_ bv84 8)) (seq.++ (seq.unit (_ bv84 8)) (seq.unit (_ bv76 8)))))))
(let ((?x831 (seq.unit (_ bv171 8))))
(let ((?x2112 (seq.unit (_ bv52 8))))
(let ((?x702 (seq.unit (_ bv18 8))))
(let ((?x1263 (seq.++ ?x702 (seq.++ ?x2112 (seq.++ ?x831 ?x1490)))))
(let ((?x1171 (seq.unit (_ bv169 8))))
(let ((?x355 (seq.++ ?x1171 ?x1263)))
(let ((?x2155 (seq.unit (_ bv153 8))))
(let ((?x1055 (seq.unit (_ bv0 8))))
(let ((?x1101 (seq.unit (_ bv8 8))))
(let ((?x2167 (seq.unit (_ bv1 8))))
(let ((?x1867 (seq.unit (_ bv2 8))))
(let ((?x2075 (seq.++ ?x1867 (seq.++ ?x2167 (seq.++ ?x1101 (seq.++ ?x1055 (seq.++ ?x2155 ?x355)))))))
(let ((?x1395 (seq.unit (_ bv192 8))))
(let ((?x2292 (seq.++ ?x1055 (seq.++ ?x1867 (seq.++ ?x1867 (seq.++ ?x1395 (seq.++ ?x1055 ?x2075)))))))
(let ((?x1413 (seq.unit (_ bv217 8))))
(let ((?x961 (seq.unit (_ bv247 8))))
(let ((?x1738 (seq.unit (_ bv255 8))))
(let ((?x1576 (seq.++ ?x1738 (seq.++ ?x2167 (seq.++ ?x961 (seq.++ ?x1413 (seq.++ ?x1395 ?x2292)))))))
(let ((?x1359 (seq.unit (_ bv64 8))))
(let ((?x1612 (seq.unit (_ bv31 8))))
(let ((?x1719 (seq.++ ?x1612 (seq.++ ?x1055 (seq.++ ?x1055 (seq.++ ?x1359 (seq.++ ?x1055 ?x1576)))))))
(let ((?x1082 (seq.unit (_ bv69 8))))
(let ((?x1569 (seq.++ ?x1082 (seq.++ ?x1055 (seq.++ ?x1055 ?x1719)))))
(= input_0_net.packet_packet ?x1569)))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x384 (= v_1_disposition "reply")))
 (let ((?x1900 (seq.unit (_ bv192 8))))
 (let ((?x732 (seq.++ ?x1900 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x2311 (seq.unit (_ bv1 8))))
 (let ((?x2379 (seq.unit (_ bv2 8))))
 (let ((?x1227 (seq.unit (_ bv0 8))))
 (let ((?x1119 (seq.++ ?x1227 (seq.++ ?x1900 (seq.++ ?x1227 (seq.++ ?x2379 (seq.++ ?x2311 ?x732)))))))
 (let ((?x1518 (seq.unit (_ bv64 8))))
 (let ((?x1189 (seq.++ ?x1518 (seq.++ ?x1227 (seq.++ ?x1518 (seq.++ ?x2311 (seq.++ ?x1227 ?x1119)))))))
 (let ((?x673 (seq.++ ?x1227 (seq.++ ?x1227 ?x1189))))
 (let ((?x1117 (seq.unit (_ bv31 8))))
 (let ((?x2173 (seq.unit (_ bv69 8))))
 (let (($x2182 (= v_1_ip_zero (seq.++ ?x2173 (seq.++ ?x1227 (seq.++ ?x1227 (seq.++ ?x1117 ?x673)))))))
 (let ((?x362 (seq.unit (_ bv205 8))))
 (let ((?x928 (seq.++ ?x362 (seq.++ (seq.unit (_ bv84 8)) (seq.++ (seq.unit (_ bv84 8)) (seq.unit (_ bv76 8)))))))
 (let ((?x1087 (seq.unit (_ bv171 8))))
 (let ((?x1694 (seq.unit (_ bv52 8))))
 (let ((?x1279 (seq.unit (_ bv18 8))))
 (let ((?x855 (seq.++ ?x1279 (seq.++ ?x1694 (seq.++ ?x1087 ?x928)))))
 (let ((?x2245 (seq.unit (_ bv169 8))))
 (let ((?x1547 (seq.++ ?x2245 ?x855)))
 (let ((?x1000 (seq.++ ?x1227 (seq.++ ?x1227 (seq.++ (seq.unit (_ bv161 8)) ?x1547)))))
 (let (($x796 (= v_1_icmp_wire ?x1000)))
 (let (($x1854 (= v_1_icmp_zero (seq.++ ?x1227 (seq.++ ?x1227 (seq.++ ?x1227 (seq.++ ?x1227 ?x855)))))))
 (let ((?x1828 (seq.++ ?x2311 (seq.++ ?x1900 (seq.++ ?x1227 (seq.++ ?x2379 (seq.++ ?x2379 ?x1000)))))))
 (let ((?x1784 (seq.unit (_ bv218 8))))
 (let ((?x929 (seq.++ (seq.unit (_ bv182 8)) (seq.++ ?x1784 (seq.++ ?x1900 (seq.++ ?x1227 (seq.++ ?x2379 ?x1828)))))))
 (let ((?x276 (seq.++ ?x1227 (seq.++ ?x1518 (seq.++ ?x1227 (seq.++ ?x1518 (seq.++ ?x2311 ?x929)))))))
 (let ((?x2302 (seq.++ ?x2173 (seq.++ ?x1227 (seq.++ ?x1227 (seq.++ ?x1117 (seq.++ ?x1227 ?x276)))))))
 (let (($x1475 (= v_1_reply ?x2302)))
 (let (($x383 (= 0 state_1)))
 (let (($x159 (= state_0 0)))
 (and $x159 (>= 0 now_0) $x383 $x1475 $x1854 $x796 $x2182 $x384))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x362 (seq.unit (_ bv205 8))))
(let ((?x928 (seq.++ ?x362 (seq.++ (seq.unit (_ bv84 8)) (seq.++ (seq.unit (_ bv84 8)) (seq.unit (_ bv76 8)))))))
(let ((?x1087 (seq.unit (_ bv171 8))))
(let ((?x1694 (seq.unit (_ bv52 8))))
(let ((?x1279 (seq.unit (_ bv18 8))))
(let ((?x855 (seq.++ ?x1279 (seq.++ ?x1694 (seq.++ ?x1087 ?x928)))))
(let ((?x2245 (seq.unit (_ bv169 8))))
(let ((?x1547 (seq.++ ?x2245 ?x855)))
(let ((?x1661 (seq.unit (_ bv153 8))))
(let ((?x1227 (seq.unit (_ bv0 8))))
(let ((?x2101 (seq.unit (_ bv8 8))))
(let ((?x2311 (seq.unit (_ bv1 8))))
(let ((?x2379 (seq.unit (_ bv2 8))))
(let ((?x524 (seq.++ ?x2379 (seq.++ ?x2311 (seq.++ ?x2101 (seq.++ ?x1227 (seq.++ ?x1661 ?x1547)))))))
(let ((?x1900 (seq.unit (_ bv192 8))))
(let ((?x1041 (seq.++ ?x1227 (seq.++ ?x2379 (seq.++ ?x2379 (seq.++ ?x1900 (seq.++ ?x1227 ?x524)))))))
(let ((?x1784 (seq.unit (_ bv218 8))))
(let ((?x641 (seq.unit (_ bv245 8))))
(let ((?x1778 (seq.++ ?x2311 (seq.++ ?x2311 (seq.++ ?x641 (seq.++ ?x1784 (seq.++ ?x1900 ?x1041)))))))
(let ((?x1518 (seq.unit (_ bv64 8))))
(let ((?x1117 (seq.unit (_ bv31 8))))
(let ((?x1418 (seq.++ ?x1117 (seq.++ ?x1227 (seq.++ ?x1227 (seq.++ ?x1518 (seq.++ ?x1227 ?x1778)))))))
(let ((?x2173 (seq.unit (_ bv69 8))))
(let ((?x2024 (seq.++ ?x2173 (seq.++ ?x1227 (seq.++ ?x1227 ?x1418)))))
(= input_0_net.packet_packet ?x2024))))))))))))))))))))))))))
(check-sat)

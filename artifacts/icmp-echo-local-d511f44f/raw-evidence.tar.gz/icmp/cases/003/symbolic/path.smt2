; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x1239 (= v_1_disposition "drop_ip_length")))
 (let (($x1546 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x287 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_wire)))
 (let (($x284 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_zero)))
 (let (($x399 (= (as seq.empty (Seq (_ BitVec 8))) v_1_reply)))
 (let (($x1236 (= 0 state_1)))
 (let (($x106 (= state_0 0)))
 (and $x106 (>= 0 now_0) $x1236 $x399 $x284 $x287 $x1546 $x1239)))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 1 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x832 (seq.unit (_ bv128 8))))
(let ((?x217 (seq.++ ?x832 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x577 (seq.unit (_ bv0 8))))
(let ((?x34 (seq.unit (_ bv205 8))))
(let ((?x418 (seq.unit (_ bv171 8))))
(let ((?x415 (seq.unit (_ bv52 8))))
(let ((?x432 (seq.unit (_ bv18 8))))
(let ((?x142 (seq.++ ?x432 (seq.++ ?x415 (seq.++ ?x418 (seq.++ ?x34 (seq.++ ?x577 ?x217)))))))
(let ((?x310 (seq.unit (_ bv118 8))))
(let ((?x1409 (seq.unit (_ bv58 8))))
(let ((?x586 (seq.unit (_ bv8 8))))
(let ((?x18 (seq.unit (_ bv1 8))))
(let ((?x1113 (seq.++ ?x18 (seq.++ ?x586 (seq.++ ?x577 (seq.++ ?x1409 (seq.++ ?x310 ?x142)))))))
(let ((?x603 (seq.unit (_ bv2 8))))
(let ((?x598 (seq.unit (_ bv192 8))))
(let ((?x210 (seq.++ ?x603 (seq.++ ?x603 (seq.++ ?x598 (seq.++ ?x577 (seq.++ ?x603 ?x1113)))))))
(let ((?x427 (seq.unit (_ bv215 8))))
(let ((?x1175 (seq.unit (_ bv182 8))))
(let ((?x1362 (seq.++ ?x18 (seq.++ ?x1175 (seq.++ ?x427 (seq.++ ?x598 (seq.++ ?x577 ?x210)))))))
(let ((?x1410 (seq.unit (_ bv64 8))))
(let ((?x971 (seq.++ ?x577 (seq.++ ?x577 (seq.++ ?x1410 (seq.++ ?x577 (seq.++ ?x1410 ?x1362)))))))
(let ((?x1321 (seq.unit (_ bv34 8))))
(let ((?x605 (seq.unit (_ bv69 8))))
(let ((?x32 (seq.++ ?x605 (seq.++ ?x577 (seq.++ ?x577 (seq.++ ?x1321 ?x971))))))
(= input_0_net.packet_packet ?x32))))))))))))))))))))))))))
(check-sat)

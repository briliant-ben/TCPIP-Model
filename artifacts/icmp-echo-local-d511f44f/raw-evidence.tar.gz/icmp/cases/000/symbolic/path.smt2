; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x320 (= v_1_disposition "reply")))
 (let ((?x155 (seq.unit (_ bv192 8))))
 (let ((?x162 (seq.++ ?x155 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x170 (seq.unit (_ bv1 8))))
 (let ((?x159 (seq.unit (_ bv2 8))))
 (let ((?x157 (seq.unit (_ bv0 8))))
 (let ((?x286 (seq.++ ?x157 (seq.++ ?x155 (seq.++ ?x157 (seq.++ ?x159 (seq.++ ?x170 ?x162)))))))
 (let ((?x281 (seq.unit (_ bv64 8))))
 (let ((?x291 (seq.++ ?x281 (seq.++ ?x157 (seq.++ ?x281 (seq.++ ?x170 (seq.++ ?x157 ?x286)))))))
 (let ((?x293 (seq.++ ?x157 (seq.++ ?x157 ?x291))))
 (let ((?x723 (seq.unit (_ bv30 8))))
 (let ((?x271 (seq.unit (_ bv69 8))))
 (let (($x1554 (= v_1_ip_zero (seq.++ ?x271 (seq.++ ?x157 (seq.++ ?x157 (seq.++ ?x723 ?x293)))))))
 (let ((?x741 (seq.unit (_ bv171 8))))
 (let ((?x750 (seq.++ ?x741 (seq.++ (seq.unit (_ bv205 8)) (seq.++ (seq.unit (_ bv73 8)) (seq.unit (_ bv68 8)))))))
 (let ((?x739 (seq.unit (_ bv52 8))))
 (let ((?x737 (seq.unit (_ bv18 8))))
 (let ((?x752 (seq.++ ?x737 (seq.++ ?x739 ?x750))))
 (let ((?x735 (seq.unit (_ bv185 8))))
 (let ((?x753 (seq.++ ?x735 ?x752)))
 (let ((?x1494 (seq.++ ?x157 (seq.++ ?x157 (seq.++ (seq.unit (_ bv248 8)) ?x753)))))
 (let (($x1553 (= v_1_icmp_wire ?x1494)))
 (let (($x1552 (= v_1_icmp_zero (seq.++ ?x157 (seq.++ ?x157 (seq.++ ?x157 (seq.++ ?x157 ?x752)))))))
 (let ((?x1535 (seq.++ ?x170 (seq.++ ?x155 (seq.++ ?x157 (seq.++ ?x159 (seq.++ ?x159 ?x1494)))))))
 (let ((?x729 (seq.unit (_ bv219 8))))
 (let ((?x727 (seq.unit (_ bv182 8))))
 (let ((?x1540 (seq.++ ?x727 (seq.++ ?x729 (seq.++ ?x155 (seq.++ ?x157 (seq.++ ?x159 ?x1535)))))))
 (let ((?x1545 (seq.++ ?x157 (seq.++ ?x281 (seq.++ ?x157 (seq.++ ?x281 (seq.++ ?x170 ?x1540)))))))
 (let ((?x1550 (seq.++ ?x271 (seq.++ ?x157 (seq.++ ?x157 (seq.++ ?x723 (seq.++ ?x157 ?x1545)))))))
 (let (($x1551 (= v_1_reply ?x1550)))
 (let (($x315 (= 0 state_1)))
 (let (($x20 (= state_0 0)))
 (and $x20 (>= 0 now_0) $x315 $x1551 $x1552 $x1553 $x1554 $x320))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x741 (seq.unit (_ bv171 8))))
(let ((?x750 (seq.++ ?x741 (seq.++ (seq.unit (_ bv205 8)) (seq.++ (seq.unit (_ bv73 8)) (seq.unit (_ bv68 8)))))))
(let ((?x739 (seq.unit (_ bv52 8))))
(let ((?x737 (seq.unit (_ bv18 8))))
(let ((?x752 (seq.++ ?x737 (seq.++ ?x739 ?x750))))
(let ((?x735 (seq.unit (_ bv185 8))))
(let ((?x753 (seq.++ ?x735 ?x752)))
(let ((?x733 (seq.unit (_ bv240 8))))
(let ((?x157 (seq.unit (_ bv0 8))))
(let ((?x731 (seq.unit (_ bv8 8))))
(let ((?x170 (seq.unit (_ bv1 8))))
(let ((?x159 (seq.unit (_ bv2 8))))
(let ((?x758 (seq.++ ?x159 (seq.++ ?x170 (seq.++ ?x731 (seq.++ ?x157 (seq.++ ?x733 ?x753)))))))
(let ((?x155 (seq.unit (_ bv192 8))))
(let ((?x763 (seq.++ ?x157 (seq.++ ?x159 (seq.++ ?x159 (seq.++ ?x155 (seq.++ ?x157 ?x758)))))))
(let ((?x729 (seq.unit (_ bv219 8))))
(let ((?x727 (seq.unit (_ bv182 8))))
(let ((?x281 (seq.unit (_ bv64 8))))
(let ((?x768 (seq.++ ?x281 (seq.++ ?x170 (seq.++ ?x727 (seq.++ ?x729 (seq.++ ?x155 ?x763)))))))
(let ((?x725 (seq.unit (_ bv255 8))))
(let ((?x723 (seq.unit (_ bv30 8))))
(let ((?x773 (seq.++ ?x723 (seq.++ ?x725 (seq.++ ?x725 (seq.++ ?x281 (seq.++ ?x157 ?x768)))))))
(let ((?x271 (seq.unit (_ bv69 8))))
(let ((?x776 (seq.++ ?x271 (seq.++ ?x157 (seq.++ ?x157 ?x773)))))
(= input_0_net.packet_packet ?x776))))))))))))))))))))))))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x1378 (= v_1_disposition "reply")))
 (let ((?x127 (seq.unit (_ bv192 8))))
 (let ((?x306 (seq.++ ?x127 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x715 (seq.unit (_ bv1 8))))
 (let ((?x1332 (seq.unit (_ bv2 8))))
 (let ((?x765 (seq.unit (_ bv0 8))))
 (let ((?x509 (seq.++ ?x765 (seq.++ ?x127 (seq.++ ?x765 (seq.++ ?x1332 (seq.++ ?x715 ?x306)))))))
 (let ((?x1338 (seq.unit (_ bv64 8))))
 (let ((?x600 (seq.++ ?x1338 (seq.++ ?x765 (seq.++ ?x1338 (seq.++ ?x715 (seq.++ ?x765 ?x509)))))))
 (let ((?x1485 (seq.++ ?x765 (seq.++ ?x765 ?x600))))
 (let ((?x251 (seq.unit (_ bv28 8))))
 (let ((?x682 (seq.unit (_ bv69 8))))
 (let (($x1503 (= v_1_ip_zero (seq.++ ?x682 (seq.++ ?x765 (seq.++ ?x765 (seq.++ ?x251 ?x1485)))))))
 (let ((?x897 (seq.unit (_ bv18 8))))
 (let ((?x962 (seq.++ ?x897 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
 (let ((?x145 (seq.unit (_ bv254 8))))
 (let ((?x964 (seq.++ ?x145 ?x962)))
 (let ((?x543 (seq.++ ?x765 (seq.++ ?x765 (seq.++ (seq.unit (_ bv65 8)) ?x964)))))
 (let (($x24 (= v_1_icmp_wire ?x543)))
 (let (($x1345 (= v_1_icmp_zero (seq.++ ?x765 (seq.++ ?x765 (seq.++ ?x765 (seq.++ ?x765 ?x962)))))))
 (let ((?x1427 (seq.++ ?x715 (seq.++ ?x127 (seq.++ ?x765 (seq.++ ?x1332 (seq.++ ?x1332 ?x543)))))))
 (let ((?x903 (seq.unit (_ bv221 8))))
 (let ((?x424 (seq.unit (_ bv182 8))))
 (let ((?x1505 (seq.++ ?x424 (seq.++ ?x903 (seq.++ ?x127 (seq.++ ?x765 (seq.++ ?x1332 ?x1427)))))))
 (let ((?x1514 (seq.++ ?x765 (seq.++ ?x1338 (seq.++ ?x765 (seq.++ ?x1338 (seq.++ ?x715 ?x1505)))))))
 (let ((?x470 (seq.++ ?x682 (seq.++ ?x765 (seq.++ ?x765 (seq.++ ?x251 (seq.++ ?x765 ?x1514)))))))
 (let (($x1058 (= v_1_reply ?x470)))
 (let (($x92 (= 0 state_1)))
 (let (($x594 (= state_0 0)))
 (and $x594 (>= 0 now_0) $x92 $x1058 $x1345 $x24 $x1503 $x1378)))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x897 (seq.unit (_ bv18 8))))
(let ((?x962 (seq.++ ?x897 (seq.++ (seq.unit (_ bv52 8)) (seq.++ (seq.unit (_ bv171 8)) (seq.unit (_ bv205 8)))))))
(let ((?x145 (seq.unit (_ bv254 8))))
(let ((?x964 (seq.++ ?x145 ?x962)))
(let ((?x1108 (seq.unit (_ bv57 8))))
(let ((?x765 (seq.unit (_ bv0 8))))
(let ((?x207 (seq.unit (_ bv8 8))))
(let ((?x715 (seq.unit (_ bv1 8))))
(let ((?x1332 (seq.unit (_ bv2 8))))
(let ((?x699 (seq.++ ?x1332 (seq.++ ?x715 (seq.++ ?x207 (seq.++ ?x765 (seq.++ ?x1108 ?x964)))))))
(let ((?x127 (seq.unit (_ bv192 8))))
(let ((?x1126 (seq.++ ?x765 (seq.++ ?x1332 (seq.++ ?x1332 (seq.++ ?x127 (seq.++ ?x765 ?x699)))))))
(let ((?x903 (seq.unit (_ bv221 8))))
(let ((?x424 (seq.unit (_ bv182 8))))
(let ((?x1338 (seq.unit (_ bv64 8))))
(let ((?x271 (seq.++ ?x1338 (seq.++ ?x715 (seq.++ ?x424 (seq.++ ?x903 (seq.++ ?x127 ?x1126)))))))
(let ((?x251 (seq.unit (_ bv28 8))))
(let ((?x510 (seq.++ ?x251 (seq.++ ?x765 (seq.++ ?x765 (seq.++ ?x1338 (seq.++ ?x765 ?x271)))))))
(let ((?x682 (seq.unit (_ bv69 8))))
(let ((?x963 (seq.++ ?x682 (seq.++ ?x765 (seq.++ ?x765 ?x510)))))
(= input_0_net.packet_packet ?x963))))))))))))))))))))))
(check-sat)

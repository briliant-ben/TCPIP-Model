; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x356 (= v_1_disposition "reply")))
 (let ((?x603 (seq.unit (_ bv192 8))))
 (let ((?x1384 (seq.++ ?x603 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x1360 (seq.unit (_ bv1 8))))
 (let ((?x157 (seq.unit (_ bv2 8))))
 (let ((?x1329 (seq.unit (_ bv0 8))))
 (let ((?x351 (seq.++ ?x1329 (seq.++ ?x603 (seq.++ ?x1329 (seq.++ ?x157 (seq.++ ?x1360 ?x1384)))))))
 (let ((?x219 (seq.unit (_ bv64 8))))
 (let ((?x209 (seq.++ ?x219 (seq.++ ?x1329 (seq.++ ?x219 (seq.++ ?x1360 (seq.++ ?x1329 ?x351)))))))
 (let ((?x407 (seq.++ ?x1329 (seq.++ ?x1329 ?x209))))
 (let ((?x982 (seq.unit (_ bv28 8))))
 (let ((?x776 (seq.unit (_ bv69 8))))
 (let (($x1193 (= v_1_ip_zero (seq.++ ?x776 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x982 ?x407)))))))
 (let ((?x392 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x1329 ?x1329)))))
 (let ((?x448 (seq.unit (_ bv255 8))))
 (let ((?x713 (seq.++ ?x448 ?x392)))
 (let ((?x1033 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x448 ?x713)))))
 (let (($x491 (= v_1_icmp_wire ?x1033)))
 (let (($x1320 (= v_1_icmp_zero (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x1329 ?x392)))))))
 (let ((?x1519 (seq.++ ?x1360 (seq.++ ?x603 (seq.++ ?x1329 (seq.++ ?x157 (seq.++ ?x157 ?x1033)))))))
 (let ((?x1489 (seq.unit (_ bv221 8))))
 (let ((?x999 (seq.unit (_ bv182 8))))
 (let ((?x144 (seq.++ ?x999 (seq.++ ?x1489 (seq.++ ?x603 (seq.++ ?x1329 (seq.++ ?x157 ?x1519)))))))
 (let ((?x563 (seq.++ ?x1329 (seq.++ ?x219 (seq.++ ?x1329 (seq.++ ?x219 (seq.++ ?x1360 ?x144)))))))
 (let ((?x900 (seq.++ ?x776 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x982 (seq.++ ?x1329 ?x563)))))))
 (let (($x876 (= v_1_reply ?x900)))
 (let (($x773 (= 0 state_1)))
 (let (($x959 (= state_0 0)))
 (and $x959 (>= 0 now_0) $x773 $x876 $x1320 $x491 $x1193 $x356))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1329 (seq.unit (_ bv0 8))))
(let ((?x392 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x1329 ?x1329)))))
(let ((?x448 (seq.unit (_ bv255 8))))
(let ((?x713 (seq.++ ?x448 ?x392)))
(let ((?x1221 (seq.unit (_ bv247 8))))
(let ((?x421 (seq.unit (_ bv8 8))))
(let ((?x1360 (seq.unit (_ bv1 8))))
(let ((?x157 (seq.unit (_ bv2 8))))
(let ((?x722 (seq.++ ?x157 (seq.++ ?x1360 (seq.++ ?x421 (seq.++ ?x1329 (seq.++ ?x1221 ?x713)))))))
(let ((?x603 (seq.unit (_ bv192 8))))
(let ((?x968 (seq.++ ?x1329 (seq.++ ?x157 (seq.++ ?x157 (seq.++ ?x603 (seq.++ ?x1329 ?x722)))))))
(let ((?x1489 (seq.unit (_ bv221 8))))
(let ((?x999 (seq.unit (_ bv182 8))))
(let ((?x219 (seq.unit (_ bv64 8))))
(let ((?x267 (seq.++ ?x219 (seq.++ ?x1360 (seq.++ ?x999 (seq.++ ?x1489 (seq.++ ?x603 ?x968)))))))
(let ((?x982 (seq.unit (_ bv28 8))))
(let ((?x1316 (seq.++ ?x982 (seq.++ ?x1329 (seq.++ ?x1329 (seq.++ ?x219 (seq.++ ?x1329 ?x267)))))))
(let ((?x776 (seq.unit (_ bv69 8))))
(let ((?x579 (seq.++ ?x776 (seq.++ ?x1329 (seq.++ ?x1329 ?x1316)))))
(= input_0_net.packet_packet ?x579)))))))))))))))))))))
(check-sat)

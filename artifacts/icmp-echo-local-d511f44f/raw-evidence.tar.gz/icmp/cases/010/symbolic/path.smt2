; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x1835 (= v_1_disposition "drop_short")))
 (let (($x1774 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x365 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_wire)))
 (let (($x1204 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_zero)))
 (let (($x1045 (= (as seq.empty (Seq (_ BitVec 8))) v_1_reply)))
 (let (($x1338 (= 0 state_1)))
 (let (($x1153 (= state_0 0)))
 (and $x1153 (>= 0 now_0) $x1338 $x1045 $x1204 $x365 $x1774 $x1835)))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x313 (seq.unit (_ bv254 8))))
(let ((?x435 (seq.++ ?x313 (seq.++ (seq.unit (_ bv18 8)) (seq.++ (seq.unit (_ bv52 8)) (seq.unit (_ bv171 8)))))))
(let ((?x1000 (seq.unit (_ bv57 8))))
(let ((?x406 (seq.unit (_ bv0 8))))
(let ((?x495 (seq.unit (_ bv8 8))))
(let ((?x649 (seq.unit (_ bv1 8))))
(let ((?x1070 (seq.unit (_ bv2 8))))
(let ((?x683 (seq.++ ?x1070 (seq.++ ?x649 (seq.++ ?x495 (seq.++ ?x406 (seq.++ ?x1000 ?x435)))))))
(let ((?x2327 (seq.unit (_ bv192 8))))
(let ((?x2252 (seq.++ ?x406 (seq.++ ?x1070 (seq.++ ?x1070 (seq.++ ?x2327 (seq.++ ?x406 ?x683)))))))
(let ((?x732 (seq.unit (_ bv221 8))))
(let ((?x2239 (seq.unit (_ bv182 8))))
(let ((?x1900 (seq.unit (_ bv64 8))))
(let ((?x1705 (seq.++ ?x1900 (seq.++ ?x649 (seq.++ ?x2239 (seq.++ ?x732 (seq.++ ?x2327 ?x2252)))))))
(let ((?x2244 (seq.unit (_ bv28 8))))
(let ((?x1857 (seq.++ ?x2244 (seq.++ ?x406 (seq.++ ?x406 (seq.++ ?x1900 (seq.++ ?x406 ?x1705)))))))
(let ((?x1126 (seq.unit (_ bv69 8))))
(let ((?x1930 (seq.++ ?x1126 (seq.++ ?x406 (seq.++ ?x406 ?x1857)))))
(= input_0_net.packet_packet ?x1930))))))))))))))))))))
(check-sat)

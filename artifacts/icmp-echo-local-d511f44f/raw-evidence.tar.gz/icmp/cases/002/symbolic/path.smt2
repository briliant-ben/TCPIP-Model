; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x775 (= v_1_disposition "drop_ip_checksum")))
 (let (($x1528 (= (as seq.empty (Seq (_ BitVec 8))) v_1_ip_zero)))
 (let (($x1411 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_wire)))
 (let (($x58 (= (as seq.empty (Seq (_ BitVec 8))) v_1_icmp_zero)))
 (let (($x1364 (= (as seq.empty (Seq (_ BitVec 8))) v_1_reply)))
 (let (($x1434 (= 0 state_1)))
 (let (($x1553 (= state_0 0)))
 (and $x1553 (>= 0 now_0) $x1434 $x1364 $x58 $x1411 $x1528 $x775)))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 2 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x1524 (seq.unit (_ bv128 8))))
(let ((?x1332 (seq.++ ?x1524 (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
(let ((?x305 (seq.unit (_ bv0 8))))
(let ((?x317 (seq.unit (_ bv205 8))))
(let ((?x1213 (seq.unit (_ bv171 8))))
(let ((?x487 (seq.unit (_ bv52 8))))
(let ((?x452 (seq.unit (_ bv18 8))))
(let ((?x1250 (seq.++ ?x452 (seq.++ ?x487 (seq.++ ?x1213 (seq.++ ?x317 (seq.++ ?x305 ?x1332)))))))
(let ((?x359 (seq.unit (_ bv118 8))))
(let ((?x365 (seq.unit (_ bv58 8))))
(let ((?x569 (seq.unit (_ bv8 8))))
(let ((?x503 (seq.unit (_ bv1 8))))
(let ((?x389 (seq.++ ?x503 (seq.++ ?x569 (seq.++ ?x305 (seq.++ ?x365 (seq.++ ?x359 ?x1250)))))))
(let ((?x303 (seq.unit (_ bv2 8))))
(let ((?x710 (seq.unit (_ bv192 8))))
(let ((?x485 (seq.++ ?x303 (seq.++ ?x303 (seq.++ ?x710 (seq.++ ?x305 (seq.++ ?x303 ?x389)))))))
(let ((?x854 (seq.unit (_ bv216 8))))
(let ((?x338 (seq.unit (_ bv183 8))))
(let ((?x1328 (seq.++ ?x503 (seq.++ ?x338 (seq.++ ?x854 (seq.++ ?x710 (seq.++ ?x305 ?x485)))))))
(let ((?x1468 (seq.unit (_ bv64 8))))
(let ((?x818 (seq.++ ?x305 (seq.++ ?x305 (seq.++ ?x1468 (seq.++ ?x305 (seq.++ ?x1468 ?x1328)))))))
(let ((?x613 (seq.unit (_ bv33 8))))
(let ((?x392 (seq.unit (_ bv69 8))))
(let ((?x1430 (seq.++ ?x392 (seq.++ ?x305 (seq.++ ?x305 (seq.++ ?x613 ?x818))))))
(= input_0_net.packet_packet ?x1430))))))))))))))))))))))))))
(check-sat)

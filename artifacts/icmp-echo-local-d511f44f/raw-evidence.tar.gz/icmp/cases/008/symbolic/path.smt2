; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (let (($x123 (= v_1_disposition "reply")))
 (let ((?x1382 (seq.unit (_ bv192 8))))
 (let ((?x1227 (seq.++ ?x1382 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (let ((?x309 (seq.unit (_ bv1 8))))
 (let ((?x2368 (seq.unit (_ bv2 8))))
 (let ((?x2367 (seq.unit (_ bv0 8))))
 (let ((?x412 (seq.++ ?x2367 (seq.++ ?x1382 (seq.++ ?x2367 (seq.++ ?x2368 (seq.++ ?x309 ?x1227)))))))
 (let ((?x1296 (seq.unit (_ bv64 8))))
 (let ((?x1356 (seq.++ ?x1296 (seq.++ ?x2367 (seq.++ ?x1296 (seq.++ ?x309 (seq.++ ?x2367 ?x412)))))))
 (let ((?x718 (seq.++ ?x2367 (seq.++ ?x2367 ?x1356))))
 (let ((?x2099 (seq.unit (_ bv30 8))))
 (let ((?x396 (seq.unit (_ bv69 8))))
 (let (($x1774 (= v_1_ip_zero (seq.++ ?x396 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2099 ?x718)))))))
 (let ((?x436 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ (seq.unit (_ bv255 8)) (seq.unit (_ bv255 8))))))))
 (let ((?x654 (seq.++ ?x2367 ?x436)))
 (let ((?x992 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2367 ?x654))))))
 (let (($x1182 (= v_1_icmp_wire ?x992)))
 (let (($x1204 (= v_1_icmp_zero ?x992)))
 (let ((?x1639 (seq.++ ?x309 (seq.++ ?x1382 (seq.++ ?x2367 (seq.++ ?x2368 (seq.++ ?x2368 ?x992)))))))
 (let ((?x464 (seq.unit (_ bv219 8))))
 (let ((?x2109 (seq.unit (_ bv182 8))))
 (let ((?x1644 (seq.++ ?x2109 (seq.++ ?x464 (seq.++ ?x1382 (seq.++ ?x2367 (seq.++ ?x2368 ?x1639)))))))
 (let ((?x1649 (seq.++ ?x2367 (seq.++ ?x1296 (seq.++ ?x2367 (seq.++ ?x1296 (seq.++ ?x309 ?x1644)))))))
 (let ((?x1625 (seq.++ ?x396 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2099 (seq.++ ?x2367 ?x1649)))))))
 (let (($x1867 (= v_1_reply ?x1625)))
 (let (($x717 (= 0 state_1)))
 (let (($x384 (= state_0 0)))
 (and $x384 (>= 0 now_0) $x717 $x1867 $x1204 $x1182 $x1774 $x123)))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= 4 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x2367 (seq.unit (_ bv0 8))))
(let ((?x436 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ (seq.unit (_ bv255 8)) (seq.unit (_ bv255 8))))))))
(let ((?x654 (seq.++ ?x2367 ?x436)))
(let ((?x2068 (seq.unit (_ bv255 8))))
(let ((?x2067 (seq.unit (_ bv247 8))))
(let ((?x1974 (seq.unit (_ bv8 8))))
(let ((?x309 (seq.unit (_ bv1 8))))
(let ((?x587 (seq.++ ?x309 (seq.++ ?x1974 (seq.++ ?x2367 (seq.++ ?x2067 (seq.++ ?x2068 ?x654)))))))
(let ((?x2368 (seq.unit (_ bv2 8))))
(let ((?x1382 (seq.unit (_ bv192 8))))
(let ((?x1782 (seq.++ ?x2368 (seq.++ ?x2368 (seq.++ ?x1382 (seq.++ ?x2367 (seq.++ ?x2368 ?x587)))))))
(let ((?x464 (seq.unit (_ bv219 8))))
(let ((?x2109 (seq.unit (_ bv182 8))))
(let ((?x279 (seq.++ ?x309 (seq.++ ?x2109 (seq.++ ?x464 (seq.++ ?x1382 (seq.++ ?x2367 ?x1782)))))))
(let ((?x1296 (seq.unit (_ bv64 8))))
(let ((?x757 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x1296 (seq.++ ?x2367 (seq.++ ?x1296 ?x279)))))))
(let ((?x2099 (seq.unit (_ bv30 8))))
(let ((?x396 (seq.unit (_ bv69 8))))
(let ((?x1004 (seq.++ ?x396 (seq.++ ?x2367 (seq.++ ?x2367 (seq.++ ?x2099 ?x757))))))
(= input_0_net.packet_packet ?x1004)))))))))))))))))))))
(check-sat)

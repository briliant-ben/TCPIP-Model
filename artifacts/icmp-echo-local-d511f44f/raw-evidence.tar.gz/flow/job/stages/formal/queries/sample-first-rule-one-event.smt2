; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_disposition () String)
(declare-fun choice_0 () Int)
(declare-fun v_1_disposition () String)
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_reply () (Seq (_ BitVec 8)))
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(declare-fun input_0_net.packet_packet () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_disposition "none"))
(assert
 (= choice_0 0))
(assert
 (let (($x357 (= choice_0 (- 1))))
 (let (($x358 (and $x357 (= state_1 state_0) (= now_1 now_0) (= v_1_reply v_0_reply) (= v_1_icmp_zero v_0_icmp_zero) (= v_1_icmp_wire v_0_icmp_wire) (= v_1_ip_zero v_0_ip_zero) (= v_1_disposition v_0_disposition))))
 (let (($x81 (= v_1_ip_zero (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x80 (= v_1_icmp_wire (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x79 (= v_1_icmp_zero (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x78 (= v_1_reply (as seq.empty (Seq (_ BitVec 8))))))
 (let (($x77 (= 0 state_1)))
 (let (($x76 (= choice_0 0)))
 (let ((?x71 (seq.len input_0_net.packet_packet)))
 (let (($x73 (>= 27 ?x71)))
 (let (($x70 (>= now_1 now_0)))
 (let (($x27 (= state_0 0)))
 (let (($x83 (and and $x27 $x70 $x73 $x76 $x77 $x78 $x79 $x80 $x81 (= v_1_disposition "drop_short"))))
 (or $x83 $x358)))))))))))))))
(assert
 (>= choice_0 0))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x377817 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x44971 (= due_1_T.user 30000)))
 (let (($x44970 (= due_1_T.rtx 1000)))
 (let (($x377805 (= due_1_L.cache due_0_L.cache)))
 (let (($x44969 (= due_1_L.query 1000)))
 (let (($x44968 (not active_1_T.time_wait)))
 (let (($x377800 (= active_1_L.cache active_0_L.cache)))
 (let (($x377798 (= v_1_ip_pending_owner "TCP")))
 (let (($x377797 (= v_1_T.control "SYN-SENT")))
 (let (($x44967 (= v_1_T.wire_flags 2)))
 (let ((?x222981 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x8060 (seq.unit (_ bv16 8))))
 (let ((?x315328 (seq.unit (_ bv0 8))))
 (let ((?x160676 (seq.unit (_ bv2 8))))
 (let ((?x348591 (seq.unit (_ bv80 8))))
 (let ((?x44792 (seq.++ ?x315328 (seq.++ ?x348591 (seq.++ ?x160676 (seq.++ ?x315328 (seq.++ ?x8060 ?x222981)))))))
 (let ((?x6457 (seq.unit (_ bv232 8))))
 (let ((?x8030 (seq.unit (_ bv3 8))))
 (let ((?x44846 (seq.++ ?x8030 (seq.++ ?x6457 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 ?x44792)))))))
 (let ((?x30935 (seq.unit (_ bv144 8))))
 (let ((?x7953 (seq.unit (_ bv31 8))))
 (let ((?x30874 (seq.unit (_ bv64 8))))
 (let ((?x8089 (seq.++ ?x30874 (seq.++ ?x7953 (seq.++ ?x30935 (seq.++ ?x315328 (seq.++ ?x315328 ?x44846)))))))
 (let ((?x221439 (seq.unit (_ bv156 8))))
 (let ((?x8093 (seq.++ ?x221439 ?x8089)))
 (let ((?x223371 (seq.unit (_ bv192 8))))
 (let ((?x68002 (seq.unit (_ bv1 8))))
 (let ((?x8149 (seq.++ ?x68002 (seq.++ ?x223371 (seq.++ ?x315328 (seq.++ ?x160676 (seq.++ ?x160676 ?x8093)))))))
 (let ((?x348618 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x223371 (seq.++ ?x315328 (seq.++ ?x160676 ?x8149))))))
 (let ((?x6626 (seq.unit (_ bv182 8))))
 (let ((?x223347 (seq.unit (_ bv6 8))))
 (let ((?x191867 (seq.++ ?x30874 (seq.++ ?x315328 (seq.++ ?x30874 (seq.++ ?x223347 (seq.++ ?x6626 ?x348618)))))))
 (let ((?x6251 (seq.unit (_ bv40 8))))
 (let ((?x8102 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x6251 (seq.++ ?x315328 (seq.++ ?x315328 ?x191867)))))))
 (let ((?x67923 (seq.unit (_ bv69 8))))
 (let ((?x30931 (seq.++ ?x67923 ?x8102)))
 (let (($x44966 (= v_1_T.wire_packet ?x30931)))
 (let ((?x160337 (seq.++ ?x160676 (seq.++ ?x68002 (seq.++ ?x223371 (seq.++ ?x315328 (seq.++ ?x160676 ?x160676)))))))
 (let ((?x128232 (seq.++ ?x223347 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x223371 (seq.++ ?x315328 ?x160337)))))))
 (let ((?x128718 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x30874 (seq.++ ?x315328 (seq.++ ?x30874 ?x128232)))))))
 (let (($x44965 (= v_1_T.wire_ip_zero (seq.++ ?x67923 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x6251 ?x128718)))))))
 (let (($x44964 (= v_1_T.wire_tcp ?x8093)))
 (let ((?x6951 (seq.++ ?x160676 (seq.++ ?x315328 (seq.++ ?x223347 (seq.++ ?x315328 (seq.unit (_ bv20 8))))))))
 (let ((?x9265 (seq.++ ?x160676 (seq.++ ?x68002 (seq.++ ?x223371 (seq.++ ?x315328 (seq.++ ?x160676 ?x6951)))))))
 (let (($x44963 (= v_1_T.wire_pseudo (seq.++ ?x223371 (seq.++ ?x315328 ?x9265)))))
 (let ((?x9345 (seq.++ ?x315328 (seq.++ ?x8060 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 ?x315328)))))))
 (let ((?x9350 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x348591 (seq.++ ?x160676 ?x9345)))))))
 (let ((?x6547 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x8030 (seq.++ ?x6457 (seq.++ ?x315328 ?x9350)))))))
 (let (($x30734 (= v_1_T.wire_tcp_zero (seq.++ ?x221439 (seq.++ ?x30874 (seq.++ ?x7953 (seq.++ ?x30935 ?x6547)))))))
 (let (($x30465 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x44961 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x6695 (= v_1_T.take 0)))
 (let (($x6696 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x6697 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x6698 (= v_1_T.snd_wnd 8)))
 (let (($x161092 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x67671 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x65042 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x6865 (= v_1_T.local_window 16)))
 (let (($x6866 (= v_1_T.msl_ms 60000)))
 (let (($x6867 (= v_1_T.user_timeout_ms 30000)))
 (let (($x377776 (= 0 v_1_T.retries)))
 (let (($x377775 (= 1000 v_1_T.rto_ms)))
 (let (($x377774 (= v_1_T.tx_flags "S")))
 (let (($x6870 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x6871 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x6872 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x66118 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x6874 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x6875 (= v_1_T.irs (_ bv0 32))))
 (let (($x6821 (= v_1_T.iss (_ bv1000 32))))
 (let (($x377766 (= v_1_L.control "PENDING")))
 (let (($x8128 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x8130 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x8108 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x8097 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x30033 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x5716 (not v_1_L.rxudp_require_checksum)))
 (let (($x33542 (= v_1_L.pending_packet ?x30931)))
 (let (($x6841 (= v_1_L.ip_checksum 0)))
 (let (($x6842 (= v_1_L.udp_checksum 0)))
 (let (($x6259 (= v_1_L.udp_raw_checksum 0)))
 (let (($x6260 (= v_1_L.ip_length 0)))
 (let (($x6331 (= v_1_L.udp_length 0)))
 (let (($x6930 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x9259 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x9256 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x9255 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x9260 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x9257 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x9258 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x6496 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x377658 (= 0 v_1_L.retry_count)))
 (let (($x9254 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x377656 (= 0 state_1)))
 (let (($x254913 (not active_0_T.time_wait)))
 (let (($x6661 (or $x254913 (not (<= due_0_T.time_wait 0)))))
 (let (($x64631 (not active_0_T.user)))
 (let (($x6653 (or $x64631 (not (<= due_0_T.user 0)))))
 (let (($x30 (not active_0_T.rtx)))
 (let (($x6650 (or $x30 (not (<= due_0_T.rtx 0)))))
 (let (($x254912 (not active_0_L.cache)))
 (let (($x6690 (or $x254912 (not (<= due_0_L.cache 0)))))
 (let (($x3375 (not active_0_L.query)))
 (let (($x6687 (or $x3375 (not (<= due_0_L.query 0)))))
 (let (($x44736 (= state_0 0)))
 (and $x44736 (>= 0 now_0) $x6687 $x6690 $x6650 $x6653 $x6661 $x377656 $x9254 $x377658 $x6496 v_1_L.checksums_enabled $x9258 $x9257 $x9260 $x9255 $x9256 $x9259 $x6930 $x6331 $x6260 $x6259 $x6842 $x6841 $x33542 $x5716 $x30033 (= v_1_L.rxudp_disposition "none") $x8097 $x8108 $x8130 $x8128 (= v_1_L.echo_disposition "none") $x377766 $x6821 $x6875 $x6874 $x66118 $x6872 $x6871 $x6870 $x377774 $x377775 $x377776 v_1_T.active_open $x6867 $x6866 $x6865 $x65042 $x67671 $x161092 $x6698 $x6697 $x6696 $x6695 $x44961 $x30465 $x30734 $x44963 $x44964 $x44965 $x44966 $x44967 (= v_1_T.wire_disposition "none") $x377797 $x377798 active_1_L.query $x377800 active_1_T.rtx active_1_T.user $x44968 $x44969 $x377805 $x44970 $x44971 $x377817))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x9152 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x9151 (= due_2_T.user due_1_T.user)))
 (let (($x9150 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x9149 (= due_2_L.cache due_1_L.cache)))
 (let (($x9148 (= due_2_L.query due_1_L.query)))
 (let (($x9147 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x9146 (= active_2_T.user active_1_T.user)))
 (let (($x9145 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x9144 (= active_2_L.cache active_1_L.cache)))
 (let (($x9143 (= active_2_L.query active_1_L.query)))
 (let (($x9142 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x9141 (= v_2_T.control v_1_T.control)))
 (let (($x9140 (= v_2_T.wire_disposition "drop_ip_length")))
 (let (($x9139 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x9138 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x9137 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x9136 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x9135 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x9134 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x9133 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x9132 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x9131 (= v_2_T.take v_1_T.take)))
 (let (($x9130 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x9129 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x9128 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x9127 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x9126 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x9125 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x9124 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x9123 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x9122 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x9121 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x9120 (= v_2_T.retries v_1_T.retries)))
 (let (($x9119 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x9118 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x9117 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x9116 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x9115 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x9114 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x9113 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x9112 (= v_2_T.irs v_1_T.irs)))
 (let (($x9111 (= v_2_T.iss v_1_T.iss)))
 (let (($x9110 (= v_2_L.control v_1_L.control)))
 (let (($x9109 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x9108 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x9107 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x9106 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x9105 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x9104 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x9103 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x9102 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x9101 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x9100 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x9099 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x9098 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x9097 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x9096 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x9095 (= v_2_L.packet v_1_L.packet)))
 (let (($x9094 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x9093 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x9092 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x9091 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x9090 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x9089 (= v_2_L.payload v_1_L.payload)))
 (let (($x9088 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x9087 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x9086 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x9085 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x9084 (= 0 state_2)))
 (let (($x44968 (not active_1_T.time_wait)))
 (let (($x6298 (or $x44968 (not (<= due_1_T.time_wait 1)))))
 (let (($x6924 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x6265 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x6732 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x6469 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x6248 (= state_1 0)))
 (and $x6248 $x6469 $x6732 $x6265 $x6924 $x6298 $x9084 $x9085 $x9086 $x9087 $x9088 $x9089 $x9090 $x9091 $x9092 $x9093 $x9094 $x9095 $x9096 $x9097 $x9098 $x9099 $x9100 $x9101 $x9102 $x9103 $x9104 $x9105 $x9106 $x9107 $x9108 $x9109 $x9110 $x9111 $x9112 $x9113 $x9114 $x9115 $x9116 $x9117 $x9118 $x9119 $x9120 $x9121 $x9122 $x9123 $x9124 $x9125 $x9126 $x9127 $x9128 $x9129 $x9130 $x9131 $x9132 $x9133 $x9134 $x9135 $x9136 $x9137 $x9138 $x9139 $x9140 $x9141 $x9142 $x9143 $x9144 $x9145 $x9146 $x9147 $x9148 $x9149 $x9150 $x9151 $x9152))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 334 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x315328 (seq.unit (_ bv0 8))))
(let ((?x528 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 ?x315328)))))
(let ((?x223549 (seq.++ ?x315328 (seq.++ ?x315328 ?x528))))
(let ((?x377629 (seq.++ ?x315328 (seq.++ ?x315328 ?x223549))))
(let ((?x1204 (seq.unit (_ bv221 8))))
(let ((?x64447 (seq.unit (_ bv72 8))))
(let ((?x8060 (seq.unit (_ bv16 8))))
(let ((?x8056 (seq.unit (_ bv18 8))))
(let ((?x224287 (seq.++ ?x8056 (seq.++ ?x315328 (seq.++ ?x8060 (seq.++ ?x64447 (seq.++ ?x1204 ?x377629)))))))
(let ((?x348591 (seq.unit (_ bv80 8))))
(let ((?x8052 (seq.unit (_ bv233 8))))
(let ((?x8030 (seq.unit (_ bv3 8))))
(let ((?x65044 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x8030 (seq.++ ?x8052 (seq.++ ?x348591 ?x224287)))))))
(let ((?x6251 (seq.unit (_ bv40 8))))
(let ((?x8023 (seq.unit (_ bv35 8))))
(let ((?x30874 (seq.unit (_ bv64 8))))
(let ((?x44763 (seq.++ ?x30874 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x8023 (seq.++ ?x6251 ?x65044)))))))
(let ((?x221439 (seq.unit (_ bv156 8))))
(let ((?x30935 (seq.unit (_ bv144 8))))
(let ((?x7953 (seq.unit (_ bv31 8))))
(let ((?x68002 (seq.unit (_ bv1 8))))
(let ((?x160676 (seq.unit (_ bv2 8))))
(let ((?x33323 (seq.++ ?x160676 (seq.++ ?x68002 (seq.++ ?x7953 (seq.++ ?x30935 (seq.++ ?x221439 ?x44763)))))))
(let ((?x223371 (seq.unit (_ bv192 8))))
(let ((?x44841 (seq.++ ?x315328 (seq.++ ?x160676 (seq.++ ?x160676 (seq.++ ?x223371 (seq.++ ?x315328 ?x33323)))))))
(let ((?x128790 (seq.unit (_ bv197 8))))
(let ((?x6626 (seq.unit (_ bv182 8))))
(let ((?x223347 (seq.unit (_ bv6 8))))
(let ((?x8146 (seq.++ ?x30874 (seq.++ ?x223347 (seq.++ ?x6626 (seq.++ ?x128790 (seq.++ ?x223371 ?x44841)))))))
(let ((?x44786 (seq.unit (_ bv47 8))))
(let ((?x159329 (seq.++ ?x44786 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x30874 (seq.++ ?x315328 ?x8146)))))))
(let ((?x67923 (seq.unit (_ bv69 8))))
(let ((?x1273 (seq.unit (_ bv8 8))))
(let ((?x348518 (seq.++ ?x1273 (seq.++ ?x315328 (seq.++ ?x67923 (seq.++ ?x315328 (seq.++ ?x315328 ?x159329)))))))
(let ((?x67426 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x160676 ?x348518)))))))
(let ((?x8141 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x315328 (seq.++ ?x68002 (seq.++ ?x160676 ?x67426)))))))
(let ((?x64355 (seq.++ ?x160676 (seq.++ ?x315328 ?x8141))))
(= input_1_L.net.frame_frame ?x64355)))))))))))))))))))))))))))))))))))))))
(check-sat)

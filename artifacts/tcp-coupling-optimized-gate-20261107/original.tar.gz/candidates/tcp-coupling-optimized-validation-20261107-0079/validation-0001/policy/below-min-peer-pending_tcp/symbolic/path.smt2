; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x1244 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x44955 (= due_1_T.user 30000)))
 (let (($x44954 (= due_1_T.rtx 1000)))
 (let (($x1028 (= due_1_L.cache due_0_L.cache)))
 (let (($x44953 (= due_1_L.query 1000)))
 (let (($x44952 (not active_1_T.time_wait)))
 (let (($x64798 (= active_1_L.cache active_0_L.cache)))
 (let (($x65286 (= v_1_ip_pending_owner "TCP")))
 (let (($x129 (= v_1_T.control "SYN-SENT")))
 (let (($x44951 (= v_1_T.wire_flags 2)))
 (let ((?x44859 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x44684 (seq.unit (_ bv16 8))))
 (let ((?x191888 (seq.unit (_ bv0 8))))
 (let ((?x67111 (seq.unit (_ bv2 8))))
 (let ((?x377690 (seq.unit (_ bv80 8))))
 (let ((?x44864 (seq.++ ?x191888 (seq.++ ?x377690 (seq.++ ?x67111 (seq.++ ?x191888 (seq.++ ?x44684 ?x44859)))))))
 (let ((?x223947 (seq.unit (_ bv232 8))))
 (let ((?x44678 (seq.unit (_ bv3 8))))
 (let ((?x44869 (seq.++ ?x44678 (seq.++ ?x223947 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 ?x44864)))))))
 (let ((?x377839 (seq.unit (_ bv144 8))))
 (let ((?x377837 (seq.unit (_ bv31 8))))
 (let ((?x377827 (seq.unit (_ bv64 8))))
 (let ((?x44874 (seq.++ ?x377827 (seq.++ ?x377837 (seq.++ ?x377839 (seq.++ ?x191888 (seq.++ ?x191888 ?x44869)))))))
 (let ((?x377841 (seq.unit (_ bv156 8))))
 (let ((?x44875 (seq.++ ?x377841 ?x44874)))
 (let ((?x224353 (seq.unit (_ bv192 8))))
 (let ((?x160769 (seq.unit (_ bv1 8))))
 (let ((?x44916 (seq.++ ?x160769 (seq.++ ?x224353 (seq.++ ?x191888 (seq.++ ?x67111 (seq.++ ?x67111 ?x44875)))))))
 (let ((?x44920 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x224353 (seq.++ ?x191888 (seq.++ ?x67111 ?x44916))))))
 (let ((?x128254 (seq.unit (_ bv182 8))))
 (let ((?x348317 (seq.unit (_ bv6 8))))
 (let ((?x44925 (seq.++ ?x377827 (seq.++ ?x191888 (seq.++ ?x377827 (seq.++ ?x348317 (seq.++ ?x128254 ?x44920)))))))
 (let ((?x159873 (seq.unit (_ bv40 8))))
 (let ((?x44930 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x159873 (seq.++ ?x191888 (seq.++ ?x191888 ?x44925)))))))
 (let ((?x377821 (seq.unit (_ bv69 8))))
 (let ((?x44931 (seq.++ ?x377821 ?x44930)))
 (let (($x44950 (= v_1_T.wire_packet ?x44931)))
 (let ((?x377872 (seq.++ ?x67111 (seq.++ ?x160769 (seq.++ ?x224353 (seq.++ ?x191888 (seq.++ ?x67111 ?x67111)))))))
 (let ((?x67648 (seq.++ ?x348317 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x224353 (seq.++ ?x191888 ?x377872)))))))
 (let ((?x377809 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x377827 (seq.++ ?x191888 (seq.++ ?x377827 ?x67648)))))))
 (let (($x44949 (= v_1_T.wire_ip_zero (seq.++ ?x377821 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x159873 ?x377809)))))))
 (let (($x44948 (= v_1_T.wire_tcp ?x44875)))
 (let ((?x192206 (seq.++ ?x67111 (seq.++ ?x191888 (seq.++ ?x348317 (seq.++ ?x191888 (seq.unit (_ bv20 8))))))))
 (let ((?x94847 (seq.++ ?x67111 (seq.++ ?x160769 (seq.++ ?x224353 (seq.++ ?x191888 (seq.++ ?x67111 ?x192206)))))))
 (let (($x44947 (= v_1_T.wire_pseudo (seq.++ ?x224353 (seq.++ ?x191888 ?x94847)))))
 (let ((?x8156 (seq.++ ?x191888 (seq.++ ?x44684 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 ?x191888)))))))
 (let ((?x8161 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x377690 (seq.++ ?x67111 ?x8156)))))))
 (let ((?x8166 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x44678 (seq.++ ?x223947 (seq.++ ?x191888 ?x8161)))))))
 (let (($x44946 (= v_1_T.wire_tcp_zero (seq.++ ?x377841 (seq.++ ?x377827 (seq.++ ?x377837 (seq.++ ?x377839 ?x8166)))))))
 (let (($x44945 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x44944 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x159917 (= v_1_T.take 0)))
 (let (($x159918 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x159919 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x159920 (= v_1_T.snd_wnd 8)))
 (let (($x44943 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x44942 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x44941 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x159924 (= v_1_T.local_window 16)))
 (let (($x159925 (= v_1_T.msl_ms 60000)))
 (let (($x159926 (= v_1_T.user_timeout_ms 30000)))
 (let (($x65296 (= 0 v_1_T.retries)))
 (let (($x207 (= 1000 v_1_T.rto_ms)))
 (let (($x64893 (= v_1_T.tx_flags "S")))
 (let (($x128276 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x128277 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x1202 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x44940 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x33159 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x128279 (= v_1_T.irs (_ bv0 32))))
 (let (($x2390 (= v_1_T.iss (_ bv1000 32))))
 (let (($x64404 (= v_1_L.control "PENDING")))
 (let (($x44937 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x44936 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x44935 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x44934 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x44933 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x6512 (not v_1_L.rxudp_require_checksum)))
 (let (($x44932 (= v_1_L.pending_packet ?x44931)))
 (let (($x317184 (= v_1_L.ip_checksum 0)))
 (let (($x348465 (= v_1_L.udp_checksum 0)))
 (let (($x348466 (= v_1_L.udp_raw_checksum 0)))
 (let (($x348469 (= v_1_L.ip_length 0)))
 (let (($x67127 (= v_1_L.udp_length 0)))
 (let (($x94864 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x94863 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x97352 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x94862 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x97351 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x94861 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x97350 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x129290 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x94266 (= 0 v_1_L.retry_count)))
 (let (($x94860 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x94265 (= 0 state_1)))
 (let (($x64926 (not active_0_T.time_wait)))
 (let (($x97349 (or $x64926 (not (<= due_0_T.time_wait 0)))))
 (let (($x223506 (not active_0_T.user)))
 (let (($x94858 (or $x223506 (not (<= due_0_T.user 0)))))
 (let (($x64925 (not active_0_T.rtx)))
 (let (($x67130 (or $x64925 (not (<= due_0_T.rtx 0)))))
 (let (($x223508 (not active_0_L.cache)))
 (let (($x222 (or $x223508 (not (<= due_0_L.cache 0)))))
 (let (($x222983 (not active_0_L.query)))
 (let (($x97335 (or $x222983 (not (<= due_0_L.query 0)))))
 (let (($x160438 (= state_0 0)))
 (and $x160438 (>= 0 now_0) $x97335 $x222 $x67130 $x94858 $x97349 $x94265 $x94860 $x94266 $x129290 v_1_L.checksums_enabled $x97350 $x94861 $x97351 $x94862 $x97352 $x94863 $x94864 $x67127 $x348469 $x348466 $x348465 $x317184 $x44932 $x6512 $x44933 (= v_1_L.rxudp_disposition "none") $x44934 $x44935 $x44936 $x44937 (= v_1_L.echo_disposition "none") $x64404 $x2390 $x128279 $x33159 $x44940 $x1202 $x128277 $x128276 $x64893 $x207 $x65296 v_1_T.active_open $x159926 $x159925 $x159924 $x44941 $x44942 $x44943 $x159920 $x159919 $x159918 $x159917 $x44944 $x44945 $x44946 $x44947 $x44948 $x44949 $x44950 $x44951 (= v_1_T.wire_disposition "none") $x129 $x65286 active_1_L.query $x64798 active_1_T.rtx active_1_T.user $x44952 $x44953 $x1028 $x44954 $x44955 $x1244))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x7970 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x7969 (= due_2_T.user due_1_T.user)))
 (let (($x7968 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x7967 (= due_2_L.cache due_1_L.cache)))
 (let (($x7966 (= due_2_L.query due_1_L.query)))
 (let (($x7965 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x7964 (= active_2_T.user active_1_T.user)))
 (let (($x7963 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x7962 (= active_2_L.cache active_1_L.cache)))
 (let (($x7961 (= active_2_L.query active_1_L.query)))
 (let (($x7960 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x7959 (= v_2_T.control v_1_T.control)))
 (let (($x7958 (= v_2_T.wire_disposition "drop_ip_length")))
 (let (($x7957 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x7956 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x7955 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x7954 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x7953 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x7952 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x7951 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x7950 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x7949 (= v_2_T.take v_1_T.take)))
 (let (($x7948 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x7947 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x7946 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x7945 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x7944 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x7943 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x7942 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x7941 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x7940 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x7939 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x7938 (= v_2_T.retries v_1_T.retries)))
 (let (($x7937 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x7936 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x7935 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x7934 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x7933 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x7932 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x7931 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x7930 (= v_2_T.irs v_1_T.irs)))
 (let (($x7929 (= v_2_T.iss v_1_T.iss)))
 (let (($x7928 (= v_2_L.control v_1_L.control)))
 (let (($x7927 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x7926 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x7925 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x7924 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x7923 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x7922 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x7921 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x7920 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x7919 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x7918 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x7917 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x7916 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x7915 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x7914 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x7913 (= v_2_L.packet v_1_L.packet)))
 (let (($x7912 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x7911 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x7910 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x7909 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x7908 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x7907 (= v_2_L.payload v_1_L.payload)))
 (let (($x7906 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x7905 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x7904 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x7903 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x7902 (= 0 state_2)))
 (let (($x44952 (not active_1_T.time_wait)))
 (let (($x159903 (or $x44952 (not (<= due_1_T.time_wait 1)))))
 (let (($x160771 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x191873 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x67660 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x65024 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x316 (= state_1 0)))
 (and $x316 $x65024 $x67660 $x191873 $x160771 $x159903 $x7902 $x7903 $x7904 $x7905 $x7906 $x7907 $x7908 $x7909 $x7910 $x7911 $x7912 $x7913 $x7914 $x7915 $x7916 $x7917 $x7918 $x7919 $x7920 $x7921 $x7922 $x7923 $x7924 $x7925 $x7926 $x7927 $x7928 $x7929 $x7930 $x7931 $x7932 $x7933 $x7934 $x7935 $x7936 $x7937 $x7938 $x7939 $x7940 $x7941 $x7942 $x7943 $x7944 $x7945 $x7946 $x7947 $x7948 $x7949 $x7950 $x7951 $x7952 $x7953 $x7954 $x7955 $x7956 $x7957 $x7958 $x7959 $x7960 $x7961 $x7962 $x7963 $x7964 $x7965 $x7966 $x7967 $x7968 $x7969 $x7970))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 334 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x191888 (seq.unit (_ bv0 8))))
(let ((?x377704 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 ?x191888)))))
(let ((?x843 (seq.++ ?x191888 (seq.++ ?x191888 ?x377704))))
(let ((?x31768 (seq.++ ?x191888 (seq.++ ?x191888 ?x843))))
(let ((?x44688 (seq.unit (_ bv221 8))))
(let ((?x44686 (seq.unit (_ bv72 8))))
(let ((?x44684 (seq.unit (_ bv16 8))))
(let ((?x44682 (seq.unit (_ bv18 8))))
(let ((?x44693 (seq.++ ?x44682 (seq.++ ?x191888 (seq.++ ?x44684 (seq.++ ?x44686 (seq.++ ?x44688 ?x31768)))))))
(let ((?x377690 (seq.unit (_ bv80 8))))
(let ((?x44680 (seq.unit (_ bv233 8))))
(let ((?x44678 (seq.unit (_ bv3 8))))
(let ((?x44698 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x44678 (seq.++ ?x44680 (seq.++ ?x377690 ?x44693)))))))
(let ((?x159873 (seq.unit (_ bv40 8))))
(let ((?x44676 (seq.unit (_ bv35 8))))
(let ((?x377827 (seq.unit (_ bv64 8))))
(let ((?x44703 (seq.++ ?x377827 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x44676 (seq.++ ?x159873 ?x44698)))))))
(let ((?x377841 (seq.unit (_ bv156 8))))
(let ((?x377839 (seq.unit (_ bv144 8))))
(let ((?x377837 (seq.unit (_ bv31 8))))
(let ((?x160769 (seq.unit (_ bv1 8))))
(let ((?x67111 (seq.unit (_ bv2 8))))
(let ((?x44708 (seq.++ ?x67111 (seq.++ ?x160769 (seq.++ ?x377837 (seq.++ ?x377839 (seq.++ ?x377841 ?x44703)))))))
(let ((?x224353 (seq.unit (_ bv192 8))))
(let ((?x44713 (seq.++ ?x191888 (seq.++ ?x67111 (seq.++ ?x67111 (seq.++ ?x224353 (seq.++ ?x191888 ?x44708)))))))
(let ((?x44674 (seq.unit (_ bv205 8))))
(let ((?x128254 (seq.unit (_ bv182 8))))
(let ((?x348317 (seq.unit (_ bv6 8))))
(let ((?x44718 (seq.++ ?x377827 (seq.++ ?x348317 (seq.++ ?x128254 (seq.++ ?x44674 (seq.++ ?x224353 ?x44713)))))))
(let ((?x44672 (seq.unit (_ bv39 8))))
(let ((?x44723 (seq.++ ?x44672 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x377827 (seq.++ ?x191888 ?x44718)))))))
(let ((?x377821 (seq.unit (_ bv69 8))))
(let ((?x68075 (seq.unit (_ bv8 8))))
(let ((?x44728 (seq.++ ?x68075 (seq.++ ?x191888 (seq.++ ?x377821 (seq.++ ?x191888 (seq.++ ?x191888 ?x44723)))))))
(let ((?x44733 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x67111 ?x44728)))))))
(let ((?x44738 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x191888 (seq.++ ?x160769 (seq.++ ?x67111 ?x44733)))))))
(let ((?x44740 (seq.++ ?x67111 (seq.++ ?x191888 ?x44738))))
(= input_1_L.net.frame_frame ?x44740)))))))))))))))))))))))))))))))))))))))
(check-sat)

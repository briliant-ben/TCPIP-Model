from pathlib import Path
import hashlib,json,os,resource,shutil,subprocess,tarfile,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-coupling-complete-deps-20261107-0081';O.mkdir(exist_ok=False);PRE=P/'candidates/tcp-coupling-optimized-validation-20261107-0079';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,prototype_complete=False,**v))
try:
 status(status='running',stage='complete_pinned_test_dependency',started_at=time.time())
 old=json.loads((PRE/'status.json').read_text());assert old['error']=='generic regression failed; inspect log';log=(PRE/'generic-tests.log').read_text();assert "ModuleNotFoundError: No module named 'formal'"in log
 gate=json.loads((PRE/'validation-0001/status.json').read_text());assert gate['status']=='finite_candidate_gate_pass_controller_review_required'and gate['fixed_Z3_cases']==8
 fixture=P/'incoming/tcp-formal-dependency-137ad5c3.tar';assert hashlib.sha256(fixture.read_bytes()).hexdigest()=='aba9f4268349f598c1f0f5efb3fc06ddb897ae6503b94b40dc693c6523a63e31'
 overlay=O/'workspace';shutil.copytree(PRE/'workspace',overlay,ignore=shutil.ignore_patterns('__pycache__'))
 with tarfile.open(fixture)as tar:
  for item in tar.getmembers():
   path=Path(item.name);assert not path.is_absolute()and'..'not in path.parts and(item.isfile()or item.isdir())and path.parts[0]=='formal'
   dest=overlay/path
   if item.isdir():dest.mkdir(parents=True,exist_ok=True)
   else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(tar.extractfile(item).read())
 save('bindings.json',dict(pinned_dependency_git='137ad5c3',dependency_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),existing_exact_gate=gate,existing_exact_model_C=json.loads((PRE/'exact-model-C-bindings.json').read_text()),existing_gate_not_rerun=True,old_failure_preserved=True))
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(900,900));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 status(status='running',stage='five_frozen_generic_regression_modules')
 with(O/'generic-tests.log').open('w')as log:cp=subprocess.run([str(PY),'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=1200,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 assert cp.returncode==0,'generic regression failed; inspect log'
 status(status='running',stage='45_original_literal_reference_native_fixedZ3_regressions')
 template=(P/'incoming/tcp-coupling-policy-regression-0069.py').read_text().replace("O=P/'candidates/tcp-ir-coupling-policy-20261107-0069/regression-0001'","O=P/'candidates/tcp-coupling-complete-deps-20261107-0081/regression-0001'").replace("W=P/'candidates/tcp-endpoint-composition-20261107-0062/workspace'","W=P/'candidates/tcp-coupling-complete-deps-20261107-0081/workspace'").replace("C=P/'candidates/tcp-ir-coupling-policy-20261107-0069/validation-0001'","C=P/'candidates/tcp-coupling-optimized-validation-20261107-0079/validation-0001'")
 rp=O/'executed-legacy-regression.py';rp.write_text(template)
 with(O/'legacy-controller.log').open('w')as log:cp=subprocess.run([str(PY),str(rp)],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=1200,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 f=O/'regression-0001/status.json';result=json.loads(f.read_text())if f.exists()else {'status':'no_result'}
 status(status='finite_generic_and_45_regression_pass_controller_review_required'if cp.returncode==0 and result.get('status')=='finite_regression_pass_controller_review_required'else'failed_or_unresolved',stage='finished',regression=result,returncode=cp.returncode,all_input_safety='not_claimed',live_network=False,finished_at=time.time())
except Exception as e:
 status(status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__,error=str(e),automatic_solver_retry=False,finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

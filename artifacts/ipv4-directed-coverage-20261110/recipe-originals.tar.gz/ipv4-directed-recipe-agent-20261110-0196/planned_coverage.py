"""DeepSeek proposes bounded recipes over frozen input steps; real IR decides all behavior."""
from pathlib import Path
import copy,json,sys,os,time
from protocol_lab.ir import Machine,Uncovered,Conflict,ModelError
P=Path('/home/blxu/protocol-flow')
def collect(model,seeds,targets,limits,out):
 out=Path(out);out.mkdir();save=lambda n,x:(out/n).write_text(json.dumps(x,indent=2)+'\n')
 def status(s):save('status.json',dict(pid=os.getpid(),status=s,updated_at=time.time()))
 status('preparing_real_prefix_context_zero_API');attempts=0;cutoff=False;rows=[];cases=[];misses=[];failures=[];reached=set();targetids={t['id']for t in targets};byseed={s['id']:s for s in seeds}
 def apply(m,s):
  nonlocal attempts
  if attempts>=limits['max_attempts']:raise StopIteration('reference input budget exhausted')
  attempts+=1
  if s.get('tick'):m.tick(s['at_ms'])
  else:m.dispatch(s['event'],copy.deepcopy(s.get('fields',{})),s['at_ms'])
 chosen=[seeds[i]for i in [2,7,8,9,10]]
 for seed in chosen:
  assert not seed.get('initial',{});m=Machine(model);snaps=[]
  def snap(k):snaps.append(dict(prefix_steps=k,now_ms=m.now_ms,link_control=m.values['L.control'],tcp_control=m.values['T.control'],timers=m.timers.copy(),snd_len=len(m.values['T.snd_buf']),rcv_len=len(m.values['T.rcv_buf']),last_rule=m.trace[-1]['transition']if m.trace else None))
  snap(0)
  for k,s in enumerate(seed['steps'],1):apply(m,s);snap(k)
  rows.append(dict(seed_id=seed['id'],steps=seed['steps'],prefix_states=snaps))
 payload=dict(task='Propose up to24 default-initial directed input recipes to cover listed14still-unobserved close/abort rules. Output strict JSON {recipes:[{id,seed_id,prefix_steps,append:[actions],target_rule}],limitations:[strings]}. NoPython/code/expectedoutputs/initialoverrides/IR edits. Seed prefix is exactly firstprefix_steps originalsteps. Allowedappend actions: {op:"close"} or {op:"abort"} dispatch T.app.close/abort atcurrentlogicaltime; {op:"tick_earliest"} mechanicallyticks min active IRtimerdeadline (rejectifnone); {op:"seed_step",index:integer} reuses EXACT originalexternal step fields/bytes from SAME seed index with at_ms=max(currentnow, originalat_ms). Internal timerinjection forbidden. <=8append actions, totalinputsteps<=20. Models unchanged; generatedexpectedstate must becomputedbyrealIR notyou. Targetmustactuallyappearincanonicaltrace orrecipe rejected. No claim unobservedunreachable. Use REALprefixstates given, notguess API. EMPTYlink often requires cacheexpiry inESTABLISHED orCLOSEWAIT withnoTCPtimer; canthen close/abort. CLOSING/LASTACK use frozen simultaneous/passiveclose prefixes beforefinalACK. SYNRECEIVED EMPTY/PENDING mayneed coldcache thenreuseSYN/earliestexpiry; donotfillnewbytes. Goalall14buthonestlimitsifnotconstructible. Only reference-derived recipes, notRFCwireoracle or proof.',targets=targets,seeds=rows,limits=dict(recipes=24,append=8,totalsteps=20,max_reference_inputs=limits['max_attempts']))
 ms=[dict(role='system',content='Return primitive JSON test recipes over provided frozen steps and exact public time operations; no source code or fake execution claims.'),dict(role='user',content=json.dumps(payload))];save('messages.json',ms);status('DeepSeek_request')
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 response=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=6500,thinking='disabled',reasoning_effort=None,timeout=900)
 data=json.loads((P/'private/api-ledger'/response['response_file']).read_text())['response'];save('response.json',data);save('usage.json',{k:response.get(k)for k in ['usage','cached','request_sha256']});status('proposal_received_not_validated')
 if type(data)is not dict or type(data.get('recipes'))is not list or len(data['recipes'])>24:raise ValueError('invalid recipe envelope')
 for i,recipe in enumerate(data['recipes']):
  if type(recipe)is not dict or set(recipe)!={'id','seed_id','prefix_steps','append','target_rule'}:raise ValueError('invalid recipe fields')
  seed=byseed[recipe['seed_id']];k=recipe['prefix_steps'];append=recipe['append'];target=recipe['target_rule']
  if type(k)is not int or not 0<=k<=len(seed['steps'])or type(append)is not list or len(append)>8 or k+len(append)>limits['max_steps']or target not in targetids:raise ValueError('invalid recipe bounds/target')
  if seed.get('initial',{}):raise ValueError('initial override forbidden')
  path=copy.deepcopy(seed['steps'][:k]);m=Machine(model)
  try:
   for step in path:apply(m,step)
   for action in append:
    if type(action)is not dict:raise ValueError('invalid action')
    if action.get('op')in ['close','abort']and set(action)=={'op'}:step=dict(at_ms=m.now_ms,event='T.app.'+action['op'],fields={})
    elif action.get('op')=='tick_earliest'and set(action)=={'op'}:
     if not m.timers:raise Uncovered('recipe tick requested with no active timer')
     step=dict(at_ms=min(m.timers.values()),tick=True)
    elif action.get('op')=='seed_step'and set(action)=={'op','index'}and type(action['index'])is int and 0<=action['index']<len(seed['steps']):
     step=copy.deepcopy(seed['steps'][action['index']]);event=step.get('event')
     if event is None or model['events'][event]['origin']=='timer':raise ValueError('external frozen event step required')
     step['at_ms']=max(m.now_ms,step['at_ms'])
    else:raise ValueError('invalid recipe operation')
    apply(m,step);path.append(step)
  except StopIteration:cutoff=True;break
  except Uncovered as e:misses.append(dict(recipe=i,classification='model_gap_or_invalid_tick',reason=str(e)));continue
  except (Conflict,ModelError)as e:failures.append(dict(recipe=i,classification=type(e).__name__,reason=str(e)));break
  actual={r['transition']for r in m.trace}
  if target not in actual:misses.append(dict(recipe=i,classification='target_not_reached',requested=target,actual=sorted(actual)));continue
  new=actual.intersection(targetids)-reached
  if not new:continue
  scene=dict(scenario_version='0.1',id='recipe-'+str(i).zfill(3),initial={},steps=path,expect=m.snapshot())
  cases.append(dict(target_rules=sorted(new),scenario=scene,origin='model_generated',initial_override=False));reached.update(new)
 status('candidate_recipes_reference_validated_not_C_Z3_accepted')
 return dict(schema='model-derived-directed-cases-v1',cases=cases,attempts=attempts,unreached_targets=sorted(targetids-reached),failures=failures,rejections=misses,cutoff=cutoff,scope='primitive recipes over frozen stimuli; timing variants explicit; real Machine produces states. No C/Z3 acceptance or independentRFC oracle yet')

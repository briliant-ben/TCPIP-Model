from pathlib import Path
import sys,json,os,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/ipv4-directed-independent-review-20261110-0188';O.mkdir(exist_ok=False)
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
def st(**x):save(O/'status.json',dict(pid=os.getpid(),updated_at=time.time(),**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(status='running',stage='DeepSeek_independent_source_review')
try:
 S=P/'candidates/ipv4-qualified-flow-20261109-0181/workspace'
 payload=dict(task='Independent strict source review. Return ONLY JSON {blocking:[{file,line,reason}],findings:[...],limitations:[...]}. Do NOT write patches or claim tests executed. Review actual sources, no toy interpreter assumptions. Collector is root fallback after DeepSeek unfinished source rejected: uses real Machine default state, clones preserving immutablemodel only, bounded prefix cache, original inputpaths; model-derived expectedsnapshots require actualfreshC/reference/fixedZ3 gate. No arbitrary override/reachabilityproof. Formal renderer DeepSeek source +one root added fixedtargetguard: allEncodingassertions, all65INVold/new, no presetT.control/bytes. FourABORTrules; arbitrary prestate SATdoesNOTprove reachablebug; unknownnotpass. Verify outputC/reference/querybinding and any hidden omissions or bogus coverage. Source-only review, actualgate0187 concurrentlyrunning and not certified byyou. Give concrete blockers only, scope limitations separately.',sources={n:(P/'incoming/qualified-0187'/n).read_text()for n in ['controller_coverage.py','qualified_rule_probe.py']},gate=(P/'incoming/coverage-gate-0187.py').read_text(),ir_excerpt=(S/'protocol_lab/ir.py').read_text()[-17500:],symbolic_excerpt=(S/'protocol_lab/symbolic.py').read_text()[8500:16500])
 ms=[dict(role='system',content='Independent technical reviewer, exact APIs only, no fakeexecution/claims. JSON strict.'),dict(role='user',content=json.dumps(payload))];save(O/'messages.json',ms)
 r=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=7000,thinking='disabled',reasoning_effort=None,timeout=900)
 save(O/'response.json',json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response']);save(O/'usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']});st(status='review_requires_controller_disposition',stage='finished')
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st(status='failed_or_rejected',stage='stopped',error_type=type(e).__name__)

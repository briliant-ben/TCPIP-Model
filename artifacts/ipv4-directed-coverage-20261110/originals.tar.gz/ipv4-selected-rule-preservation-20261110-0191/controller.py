from pathlib import Path
import sys,json,hashlib,os,time,traceback,subprocess,concurrent.futures
P=Path('/home/blxu/protocol-flow');S=P/'candidates/ipv4-qualified-flow-20261109-0181/workspace';O=P/'candidates/ipv4-selected-rule-preservation-20261110-0191';O.mkdir(exist_ok=False);sys.path[:0]=[str(P/'incoming/qualified-0187'),str(S)]
from protocol_lab.ir import load
from protocol_lab.flow import run_scenario
from protocol_lab.codegen import generate,sha
from protocol_lab.codegen.execute import build,run
from protocol_lab.symbolic import crosscheck_trace,model_hash
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
def st(p,**kw):save(p/'status.json',dict(pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(O,status='running',stage='bounded_actual_tool_gates')
mfile=S/'model/ipv4-endpoint-virtual-link.json';m=load(mfile);assert sha(mfile)=='7d5a82541ea55cde3ff39b2e1cf883f6c9f942f5dc535a2736e69044d9e154a5'
ctx=json.loads((P/'candidates/ipv4-coverage-and-formal-20261110-0184/frozen-context.json').read_text());save(O/'frozen-context.json',ctx)
for n in ['controller_coverage.py','qualified_rule_probe.py']:(O/n).write_bytes((P/'incoming/qualified-0187'/n).read_bytes())
save(O/'source-bindings.json',{str(p):sha(p)for p in [mfile,*[S/'protocol_lab'/x for x in ['ir.py','symbolic.py','flow.py','codegen/__init__.py','codegen/execute.py']],O/'controller.py',O/'controller_coverage.py',O/'qualified_rule_probe.py']})
def coverage():
 d=O/'coverage';d.mkdir();st(d,status='running',stage='reference_only_candidate_collection')
 try:
  from controller_coverage import collect
  result=collect(m,ctx['seeds'],ctx['targets'],ctx['limits']);save(d/'candidate-cases.json',result);frozen=sha(d/'candidate-cases.json');save(d/'candidate-freeze.json',dict(sha256=frozen,independent_RFC_oracle=False));st(d,status='running',stage='fresh_C_compile_and_fixed_trace_gates',cases=len(result['cases']),attempts=result['attempts'])
  if result['failures']:raise ValueError('collector canonical error: '+str(result['failures'][0])[:500])
  g=generate(mfile,d/'generation');c=build(d/'generation',d/'build');assert c['status']=='pass';assert sha(d/'generation/protocol.c')=='19ce9855194a5d8b243648f12b710d739266f4d49ff31001e378c1815975e36b'
  rows=[];save(d/'results.json',rows)
  for i,case in enumerate(result['cases']):
   out=d/('case-'+str(i).zfill(3));out.mkdir();scene=case['scenario'];assert scene['initial']=={};save(out/'scenario.json',scene)
   native=run(d/'generation',d/'build',out/'scenario.json',out/'native');assert native['status']=='pass'
   ref=run_scenario(m,scene);actual=[r['transition']for r in ref.trace];assert set(case['target_rules'])<=set(actual);save(out/'reference.json',dict(trace=ref.trace,snapshot=ref.snapshot()))
   z=crosscheck_trace(m,ref.trace,out/'symbolic');assert z['query']=='sat'and z['status']=='match'
   rows.append(dict(key=scene['id'],origin='model_generated',initial_override=False,status='pass',transitions=actual,target_rules=case['target_rules']));save(d/'results.json',rows);st(d,status='running',stage='actual_fixed_input_C_Z3',completed=len(rows),total=len(result['cases']))
  assert sha(d/'candidate-cases.json')==frozen
  union=set(ctx['covered'])|{r for row in rows for r in row['transitions']};save(d/'summary.json',dict(status='selected_candidates_pass',old_covered=len(ctx['covered']),covered_default=len(union),declared=335,new_rules=sorted(union-set(ctx['covered'])),unreached=result['unreached_targets'],cutoff=result['cutoff'],cases=len(rows),scope='model-derived default-reachable fixed-input reference/native/Z3 evidence; not independent RFC oracle or all-input proof'));st(d,status='selected_candidates_pass',stage='finished',completed=len(rows))
 except Exception as e:(d/'traceback.txt').write_text(traceback.format_exc());st(d,status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__)
def formal():
 d=O/'formal';d.mkdir();st(d,status='running',stage='render_selected_rules_full_arbitrary_prestate')
 try:
  from qualified_rule_probe import render_probe
  already={'T.C-ABORT-LISTEN','T.C-ABORT-CLOSING','T.C-ABORT-LAST-ACK','T.C-ABORT-TIME-WAIT'};ids=[t['id']for t in ctx['targets']if t['id']not in already];save(d/'scope.json',dict(rule_ids=ids,property_ids=[x['id']for x in m['invariants']],solver_timeout_ms=10000,scope='selected rule invariant preservation only; arbitrary prestate satisfying all declared invariants and type/timer constraints; reachable counterexample not claimed',whole_protocol_proved=False));r=render_probe(m,ids)
  save(d/'rendered-queries.json',r)
  for q in r['queries']:
   (d/q['file']).write_text(q['smt2']);assert sha(d/q['file'])==q['sha256']
  import z3
  rows=[];save(d/'results.json',rows)
  for q in r['queries']:
   st(d,status='running',stage='solve_exact_frozen_query',rule=q['rule'],role=q['role']);ctxz=z3.Context();s=z3.Solver(ctx=ctxz);s.set(timeout=10000);s.from_string(q['smt2']);start=time.monotonic();a=str(s.check());row={k:q[k]for k in ['rule','role','file','sha256']};row.update(answer=a,seconds=time.monotonic()-start,solver_version=z3.get_version_string(),solver_timeout_ms=10000)
   if a=='unknown':row['reason']=s.reason_unknown()
   if a=='sat'and q['role']=='preservation':row['arbitrary_prestate_counterexample_model']=s.model().sexpr();row['reachable_from_initial']='not_claimed'
   rows.append(row);save(d/'results.json',rows)
  st(d,status='completed_selected_observations_not_global_proof',stage='finished',answers=[x['answer']for x in rows])
 except Exception as e:(d/'traceback.txt').write_text(traceback.format_exc());st(d,status='failed_or_unresolved',stage='stopped',error_type=type(e).__name__)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 fs=[pool.submit(formal)]
 for f in fs:f.result()
st(O,status='finished_requires_controller_review',stage='finished')

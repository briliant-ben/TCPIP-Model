from pathlib import Path
import json,sys,os,time,hashlib,traceback
P=Path('/home/blxu/protocol-flow');S=P/'candidates/ipv4-qualified-flow-20261109-0181/workspace';O=P/'candidates/ipv4-nonvacuity-observed-gate-20261111-0219';O.mkdir(exist_ok=False);sys.path.insert(0,str(S))
import z3
from protocol_lab.ir import load
from protocol_lab.flow import run_scenario
from protocol_lab.symbolic import Encoding
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
def status(s,**kw):save(O/'status.json',dict(status=s,pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());status('running',stage='prepare_observed_candidates_zero_API')
try:
 m=load(S/'model/ipv4-endpoint-virtual-link.json');g=P/'candidates/ipv4-remaining-rule-preservation-20261110-0194';targets={r['rule']:r for r in json.loads((g/'results.json').read_text())if r['role']=='nonvacuity'and r['answer']=='unknown'};seen={};parents=['ipv4-directed-gates-20261110-0187','ipv4-directed-focused-gates-20261110-0190','ipv4-directed-recipe-agent-20261110-0196','ipv4-directed-valid-subset-20261110-0200']
 for parent in parents:
  root=P/'candidates'/parent/'coverage';assert json.loads((root/'summary.json').read_text())['status']=='selected_candidates_pass'
  for f in sorted(root.glob('case-*/reference.json')):
   scene=json.loads((f.parent/'scenario.json').read_text());assert scene.get('initial',{})=={};ref=run_scenario(m,scene);saved=json.loads(f.read_text());assert ref.trace==saved['trace'] and ref.snapshot()==saved['snapshot'];previous=0
   for index,t in enumerate(ref.trace):
    rid=t['transition']
    if rid in targets and rid not in seen:seen[rid]=dict(trace=t,previous_ms=previous,source_reference=str(f),source_sha256=sha(f.read_bytes()),source_scene_sha256=sha((f.parent/'scenario.json').read_bytes()),trace_index=index,default_initial_replayed=True)
    previous=t['time_ms']
 save(O/'candidates.json',seen);save(O/'scope.json',dict(original_unknown_count=len(targets),candidate_rules=len(seen),scope='existential sufficient assignment only; all original assertions retained, no all-input or new C/network claim',paid_API_calls=0,plan_source='0218 DeepSeek completed design; controller implements concrete observed bindings'))
 results=[];save(O/'results.json',results)
 for k,(rid,w)in enumerate(seen.items()):
  status('running',stage='check_exact_original_nonvacuity_with_observed_assignment',completed=k,total=len(seen),rule=rid);r=targets[rid];raw=(g/r['file']).read_text();assert sha(raw.encode())==r['sha256'];idx=next(i for i,t in enumerate(m['transitions'])if t['id']==rid);enc=Encoding(m,1,tuple(m['variables']),arbitrary_state=True,fixed_choices=[idx]);tr=w['trace'];pairs=[]
  for frame,snap,now in [(enc.frames[0],tr['before'],w['previous_ms']),(enc.frames[1],tr['after'],tr['time_ms'])]:
   assert set(snap['variables'])==set(m['variables']);pairs.extend([(frame['state'],z3.IntVal(m['states'].index(snap['state']))),(frame['now'],z3.IntVal(now))])
   for name,spec in m['variables'].items():pairs.append((frame['values'][name],enc.literal(snap['variables'][name],spec['type'])))
   for name in m['timers']:
    active=name in snap['timers'];pairs.append((frame['active'][name],z3.BoolVal(active)))
    if active:pairs.append((frame['due'][name],z3.IntVal(snap['timers'][name])))
  event=tr['event'];assert event['name']==m['transitions'][idx]['event'];schema=m['events'][event['name']]['fields'];assert set(event['fields'])==set(schema)
  for name,value in event['fields'].items():pairs.append((enc.events[0][event['name']][name],enc.literal(value,schema[name])))
  pairs.append((z3.Int('choice_0'),z3.IntVal(idx)))
  # Parse the frozen ORIGINAL, not a newly rendered replacement with fresh checksum names.
  orig=list(z3.parse_smt2_string(raw));s=z3.Then(*[z3.Tactic(x)for x in ['propagate-values','solve-eqs','simplify','smt']]).solver();s.set(timeout=10000);s.add(*orig);s.add(*[v==literal for v,literal in pairs]);d=O/str(k).zfill(3);d.mkdir();(d/'original.smt2').write_text(raw);query=s.to_smt2();(d/'observed-witness.smt2').write_text(query);save(d/'observed.json',w);a=str(s.check());row=dict(rule=rid,answer=a,original_sha256=r['sha256'],query_sha256=sha(query.encode()),solver_timeout_ms=10000,solver_version=z3.get_version_string(),original_unknown_unchanged=True,all_original_assertions_retained=True,original_native_execution_reused_not_rerun=True)
  if a=='sat':
   solution=s.model();assert all(z3.is_true(solution.eval(t,model_completion=True))for t in orig);row['all_original_assertions_model_true']=True;(d/'assignment.sexpr').write_text(solution.sexpr());row['assignment_sha256']=sha((d/'assignment.sexpr').read_bytes())
  if a=='unknown':row['reason']=s.reason_unknown()
  assert sha((g/r['file']).read_bytes())==r['sha256'];results.append(row);save(O/'results.json',results)
 status('completed_requires_independent_review',counts={a:sum(r['answer']==a for r in results)for a in ['sat','unsat','unknown']},original_unknown_count=len(targets),candidate_rules=len(seen))
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());status('failed_or_rejected_no_retry',error_type=type(e).__name__)

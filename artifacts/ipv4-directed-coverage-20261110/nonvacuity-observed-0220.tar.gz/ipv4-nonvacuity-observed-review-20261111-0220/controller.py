from pathlib import Path
import sys,json,hashlib,os,time,traceback
P=Path('/home/blxu/protocol-flow');S=P/'candidates/ipv4-qualified-flow-20261109-0181/workspace';O=P/'candidates/ipv4-nonvacuity-observed-review-20261111-0220';O.mkdir(exist_ok=False)
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
def status(s,**kw):save(O/'status.json',dict(status=s,pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes())
try:
 status('waiting_zero_API',stage='wait_for_actual0219_terminal')
 G=P/'candidates/ipv4-nonvacuity-observed-gate-20261111-0219'
 deadline=time.monotonic()+1800
 while True:
  st=json.loads((G/'status.json').read_text())
  if st['status']!='running':break
  try:
   proc=Path('/proc')/str(st['pid']);assert proc.exists() and proc.joinpath('stat').read_text().split()[2]!='Z'
  except Exception:raise ValueError('gate process missing; no review API')
  if time.monotonic()>deadline:raise ValueError('bounded wait expired; no review API')
  time.sleep(30)
 assert st['status']=='completed_requires_independent_review'
 rows=json.loads((G/'results.json').read_text());assert rows and any(r['answer']=='sat'for r in rows)
 payload=dict(task='Independent review of NEW existential observed-state nonvacuity witness gate. Return strictJSON {blocking:[],findings:[],limitations:[]} string lists. SOURCEONLYreview, actual original solver receipts separate, do not falsely claim independent execution. Old163UNKNOWN remainunchanged; SATnewwitness onlyvalid if ALLoriginal frozenassertions kept,model.evalTRUE and source actualref/native matched. No allinputclaim/noprotocol ororaclemutation. Check inactive timers left due unconstrained but activeflags bound, arbitraryState bindings all58vars, bothbefore/after andpreviousrow time, events andchoices exact, original RecFunctions names never replaced. Point out concrete unsoundness ifany; original C/ref savedtraces reusednotrerunC. Fresh canonical refscene defaultinitial replay exact before/after. Thisisnot a complete reachability proof byitself. Reject originalassertions omitted or originalquery replaced, false oldUNKNOWN upgrades. Source and results supplied.',controller=(G/'controller.py').read_text(),scope=json.loads((G/'scope.json').read_text()),results=rows,sample_original=(G/'000/original.smt2').read_text(),original_design=json.loads((P/'candidates/ipv4-nonvacuity-witness-plan-20261111-0218/response.json').read_text()))
 ms=[dict(role='system',content='Independent formal verification design analyst. Strict small JSON only, no executable source, do not claim execution.'),dict(role='user',content=json.dumps(payload))];assert len(json.dumps(ms).encode())<85000;save(O/'messages.json',ms);status('running',stage='DeepSeek_independent_nonvacuity_review');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 a=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=4500,thinking='disabled',reasoning_effort=None,timeout=900);r=json.loads((P/'private/api-ledger'/a['response_file']).read_text())['response'];save(O/'response.json',r);save(O/'usage.json',{k:a.get(k)for k in ['usage','cached','request_sha256']});assert all(type(r.get(k))is list and all(type(x)is str for x in r[k])for k in ['blocking','findings','limitations']);status('review_returned_requires_operator_decision',blocking=len(r['blocking']),findings=len(r['findings']))
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());status('failed_or_rejected_no_retry',error_type=type(e).__name__)

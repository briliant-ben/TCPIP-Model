from pathlib import Path
import json,sys,hashlib,os,time,traceback
P=Path('/home/blxu/protocol-flow');G=P/'candidates/ipv4-remaining-rule-preservation-20261110-0194';O=P/'candidates/ipv4-partial-ack-positive-conjuncts-20261111-0209';O.mkdir(exist_ok=False)
import z3
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
def st(**x):save(O/'status.json',dict(pid=os.getpid(),updated_at=time.time(),**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(status='running',stage='prepare_exact_positive_conjunct_candidates')
def atoms(terms):
 out=[]
 def visit(t):
  if z3.is_and(t):
   for c in t.children():visit(c)
  else:out.append(t)
 for t in terms:visit(t)
 return out

def info(t):
 variables=set();checksum=False;unsafe=False
 def visit(n):
  nonlocal checksum,unsafe
  if z3.is_quantifier(n)or z3.is_var(n):unsafe=True;return
  if not z3.is_app(n):return
  name=str(n.decl().name())
  if name.startswith('ir4_ones_sum16_'):checksum=True
  if z3.is_const(n)and n.decl().kind()==z3.Z3_OP_UNINTERPRETED:variables.add(name)
  for c in n.children():visit(c)
 visit(t)
 return dict(sha256=sha(t.sexpr().encode()),variables=sorted(variables),checksum_function=checksum,eligible=not unsafe and checksum and bool(variables)and all(v.startswith('input_0_')for v in variables))
try:
 ctx=z3.Context();seq=z3.Const('input_0_test_frame',z3.SeqSort(z3.BitVecSort(8,ctx=ctx)));f=z3.RecFunction('ir4_ones_sum16_qualification',seq.sort(),z3.BitVecSort(16,ctx=ctx));arg=z3.Const('qualification_arg',seq.sort());z3.RecAddDefinition(f,arg,z3.BitVecVal(0,16,ctx=ctx));x=z3.Int('v_1_not_removable',ctx=ctx);assert info(f(seq)==1)['eligible']and not info(x==0)['eligible'];s=z3.Solver(ctx=ctx);s.add(x==0,x==1);assert s.check()==z3.unsat;s=z3.Solver(ctx=ctx);assert s.check()==z3.sat;assert not z3.is_true(s.model().eval(f(seq)==1,model_completion=True));save(O/'qualification.json',dict(status='pass',original_positive_conjuncts_only=True,post_state_atom_not_eligible=True,overapprox_SAT_not_original_violation=True))
 rows=json.loads((G/'results.json').read_text());targets=[r for r in rows if r['role']=='preservation'and r['answer']=='unknown'and r['rule']in ['T.D-ACK-PARTIAL-WINDOW','T.D-ACK-PARTIAL-STALE-WINDOW']];assert len(targets)==2;contexts={};candidates=[]
 for i,r in enumerate(targets):
  text=(G/r['file']).read_text();assert sha(text.encode())==r['sha256'];ctx=z3.Context();terms=z3.parse_smt2_string(text,ctx=ctx);flat=atoms(terms);eligible=[dict(index=k,**info(a),text_excerpt=a.sexpr()[:1600])for k,a in enumerate(flat)if info(a)['eligible']];assert eligible;contexts[r['rule']]=(ctx,terms,flat,text,r);save(O/('atoms-'+str(i)+'.json'),[dict(index=k,**info(a),sexpr=a.sexpr())for k,a in enumerate(flat)]);candidates.append(dict(rule=r['rule'],original_sha256=r['sha256'],original_positive_atom_count=len(flat),eligible_input_only_checksum_atoms=eligible))
 payload=dict(task='Choose positive top-level AND atoms whose omission provides a STRONGER sufficient invariance proof obligation. ReturnstrictJSON {drops:[{rule,atom_sha256:[eligibleSHA],reason}],protocol_model_changed:false,oracle_changed:false,proof_overapproximation:true,limitations:[strings]}. Actual2partialACK preservationUNKNOWN remain after exactv1, exhaustivepartitions andotherverifiedlemmawork. ONLY eligible ORIGINAL top-level positive conjunction members (afterANDflatten), containing ir4_ones_sum16_ recursivefunction and ONLY input_0_ freeconstants, canbeomitted. No old/new state/timer/invariant/SSA/postbad clause eligible. Byte sequences remainFULLSeqBV8; no rewrite of checksum meaning/no payload/window fixing. Original P=AND(allatoms) implies weaker Q=AND(retainedoriginalatoms); UNSAT(Q) provesUNSAT(P), a stronger property over more packets. SAT(Q) is NOToriginalbug unless modelvalidates ALLoriginalassertions, sourceRootdoescheck. Originalruntime/model/oracle unchanged andoldUNKNOWNfilespreserved. Wholecomplement splitting notneeded here sinceconjunctsubsetimplication hasone direction only. Do NOTsuggest increasingtimeout (10s), addingassumptions/droppingpostINVs/assumingpostconditions. SourceStatic certificates willbind exact retained/droppedatomIDs and originalSMT. NoPython/code/privateaccess. Original3partialwindow sourceCRC may distract proof ofpurebuffer/sequence contracts, thisisaHYPOTHESIS notsuccessclaim. Explain limits.',candidates=candidates,scope='only negative invariant-preservation obligations; never use overapprox SAT as nonvacuity or execution coverage')
 ms=[dict(role='system',content='Proof sufficient-condition analyst; exact source atom identifiers only, strictJSON, no hidden assumptions or false success.'),dict(role='user',content=json.dumps(payload))];save(O/'messages.json',ms);st(status='running',stage='DeepSeek_positive_conjunct_analysis');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 api=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=4500,thinking='disabled',reasoning_effort=None,timeout=900);p=json.loads((P/'private/api-ledger'/api['response_file']).read_text())['response'];save(O/'response.json',p);save(O/'usage.json',{k:api.get(k)for k in ['usage','cached','request_sha256']});assert p.get('protocol_model_changed')is False and p.get('oracle_changed')is False and p.get('proof_overapproximation')is True;drops=p['drops'];assert len(drops)==2 and{r['rule']for r in drops}==set(contexts);results=[]
 for i,d in enumerate(drops):
  rid=d['rule'];ctx,terms,flat,text,original=contexts[rid];ids=d['atom_sha256'];assert type(ids)is list and ids and len(ids)==len(set(ids));allowed={info(t)['sha256']for t in flat if info(t)['eligible']};assert set(ids)<=allowed;retained=[t for t in flat if info(t)['sha256']not in ids];assert retained;indices=[k for k,t in enumerate(flat)if info(t)['sha256']not in ids]
  # Every new assertion is an unmodified original positive conjunct; P=>Q structurally.
  assert all(retained[j].eq(flat[k])for j,k in enumerate(indices));out=O/str(i).zfill(3);out.mkdir();(out/'original.smt2').write_text(text);save(out/'derivation.json',dict(rule=rid,original_sha256=original['sha256'],dropped_atom_sha256=ids,retained_original_indices=indices,certificate='AND(all original positive conjuncts) implies AND(original indexed subset)',full_bytes_retained=True,original_model_and_oracle_unchanged=True))
  s=z3.Then(*[z3.Tactic(n,ctx=ctx)for n in ['propagate-values','solve-eqs','simplify','smt']]).solver();s.set(timeout=10000);s.add(retained);query=s.to_smt2();(out/'stronger-safety-obligation.smt2').write_text(query);st(status='running',stage='solve_stronger_safety_obligation',rule=rid);answer=str(s.check());r=dict(rule=rid,answer=answer,original_sha256=original['sha256'],new_query_sha256=sha(query.encode()),solver_timeout_ms=10000,solver_version=z3.get_version_string(),old_answer_unchanged='unknown',original_P_implies_new_Q=True,status='original_preservation_UNSAT_by_sufficient_condition'if answer=='unsat'else'unresolved')
  if answer=='unknown':r['reason']=s.reason_unknown()
  if answer=='sat':
   model=s.model();r['original_assertions_satisfied']=all(z3.is_true(model.eval(t,model_completion=True))for t in terms);r['model_sexpr']=model.sexpr();r['reachable_from_initial']='not_claimed';r['status']='original_formula_SAT_witness_not_reachability'if r['original_assertions_satisfied']else'overapprox_SAT_not_original_counterexample'
  assert sha((G/original['file']).read_bytes())==original['sha256'];results.append(r);save(O/'results.json',results)
 st(status='completed_sufficient_condition_diagnostic_requires_review',stage='finished',answers=[r['answer']for r in results])
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st(status='failed_or_rejected_no_retry',stage='stopped',error_type=type(e).__name__)

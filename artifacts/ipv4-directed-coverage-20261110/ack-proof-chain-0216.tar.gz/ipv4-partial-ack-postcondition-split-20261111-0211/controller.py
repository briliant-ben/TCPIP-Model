from pathlib import Path
import json,sys,hashlib,os,time,traceback
P=Path('/home/blxu/protocol-flow');G=P/'candidates/ipv4-remaining-rule-preservation-20261110-0194';O=P/'candidates/ipv4-partial-ack-postcondition-split-20261111-0211';O.mkdir(exist_ok=False)
import z3
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
def st(**x):save(O/'status.json',dict(pid=os.getpid(),updated_at=time.time(),**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(status='running',stage='prepare_complete_postcondition_disjunction_split')
def split(t):
 if z3.is_or(t):return [x for c in t.children()for x in split(c)]
 if z3.is_not(t)and z3.is_and(t.arg(0)):return [x for c in t.arg(0).children()for x in split(z3.Not(c))]
 if z3.is_false(t):return []
 return [t]
try:
 rows=json.loads((G/'results.json').read_text());targets=[r for r in rows if r['role']=='preservation'and r['answer']=='unknown'and r['rule']in ['T.D-ACK-PARTIAL-WINDOW','T.D-ACK-PARTIAL-STALE-WINDOW']];assert len(targets)==2;work={};summaries=[]
 for i,row in enumerate(targets):
  text=(G/row['file']).read_text();assert sha(text.encode())==row['sha256'];ctx=z3.Context();terms=z3.parse_smt2_string(text,ctx=ctx);bad=terms[-1];leaves=split(bad);assert 0<len(leaves)<=90
  c=z3.Solver(ctx=ctx);c.set(timeout=10000);c.add(z3.Xor(bad,z3.Or(*leaves)));cover=c.to_smt2();answer=str(c.check());(O/('coverage-'+str(i)+'.smt2')).write_text(cover);assert answer=='unsat';save(O/('coverage-'+str(i)+'.json'),dict(answer=answer,sha256=sha(cover.encode()),property='Original final bad-postcondition OR equals complete split leaf OR; full original base retained per leaf',solver_timeout_ms=10000))
  d=O/str(i).zfill(3);d.mkdir();(d/'original.smt2').write_text(text);leafdata=[dict(index=k,sha256=sha(t.sexpr().encode()),sexpr=t.sexpr())for k,t in enumerate(leaves)];save(d/'leaves.json',leafdata);work[row['rule']]=(row,ctx,terms,leaves,d);summaries.append(dict(rule=row['rule'],original_sha256=row['sha256'],leaf_count=len(leaves),leaf_ids=[x['sha256']for x in leafdata],buffer_related=[dict(index=x['index'],sha256=x['sha256'],excerpt=x['sexpr'][:1300])for x in leafdata if any(w in x['sexpr']for w in ['snd_buf','rtx_buf','tx_cursor','snd_una','snd_nxt'])][:12]))
 payload=dict(task='Prioritize (orderingONLY) exact postcondition disjunction leaves for two partialACK invariance UNKNOWN rules. Return JSON {priorities:[{rule,first_leaf_sha256:[IDs],reason}],limitations:[strings]}. Alloriginalbase constraints preserved; controller checks EVERYleaf including nonpriority/timer/actionfaults, no skipping or assumptions. Original finalbad OR was split ONLY byORflatten andDeMorgan Not(And); independentXORnegation equivalence actualUNSAT pertarget at10s. AllfullByteSeqBV8/state/events/65preINVs andSSA remain. Eachleaf originalBASE AND onebadconjunct, allleavesUNSAT => originalnegativeUNSAT; unknownleafkeepsunresolved. SATmustvalidateALLoriginalassertions/notdefaultreachability. Existingexactv1/exhaustive scalar partitions/verifiedmathlemmas/strongerCRCinputpredicateomission stillpartialUNKNOWN. Which exactbuffer/sequence postcondition shouldbeexaminedfirst tolocalizeproofdifficulty? No code/newlemmas/budgetincrease/fixingpayload/preconditions/model/oraclechange. IDs onlyfromsuppliedlists. Thisisnotwholeprotocol/compiler/wireproof.',targets=summaries)
 ms=[dict(role='system',content='Proof obligation triage agent. StrictJSON, priorityIDs only, no false completedclaims.'),dict(role='user',content=json.dumps(payload))];assert len(json.dumps(ms).encode())<85000;save(O/'messages.json',ms);st(status='running',stage='DeepSeek_postcondition_priority_analysis');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 api=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=4500,thinking='disabled',reasoning_effort=None,timeout=900);p=json.loads((P/'private/api-ledger'/api['response_file']).read_text())['response'];save(O/'response.json',p);save(O/'usage.json',{k:api.get(k)for k in ['usage','cached','request_sha256']});priority={}
 for r in p.get('priorities',[]):
  assert r['rule']in work;known={sha(t.sexpr().encode())for t in work[r['rule']][3]};ids=r['first_leaf_sha256'];assert type(ids)is list and len(ids)==len(set(ids))and set(ids)<=known;priority[r['rule']]=ids
 results=[];save(O/'results.json',results)
 for rid,(row,ctx,terms,leaves,d)in work.items():
  ids=priority.get(rid,[]);indices=sorted(range(len(leaves)),key=lambda k:(ids.index(sha(leaves[k].sexpr().encode()))if sha(leaves[k].sexpr().encode())in ids else len(ids),k));assert sorted(indices)==list(range(len(leaves)));group=[]
  for k in indices:
   s=z3.Then(*[z3.Tactic(n,ctx=ctx)for n in ['propagate-values','solve-eqs','simplify','smt']]).solver();s.set(timeout=10000);s.add(list(terms)[:-1]);s.add(leaves[k]);query=s.to_smt2();name='leaf-'+str(k).zfill(3)+'.smt2';(d/name).write_text(query);st(status='running',stage='solve_all_postcondition_leaves',rule=rid,leaf=k,completed=len(group),total=len(leaves));a=str(s.check());r=dict(rule=rid,leaf=k,leaf_sha256=sha(leaves[k].sexpr().encode()),query_sha256=sha(query.encode()),answer=a,solver_version=z3.get_version_string(),solver_timeout_ms=10000,all_original_base_assertions_preserved=True)
   if a=='unknown':r['reason']=s.reason_unknown()
   if a=='sat':
    model=s.model();r['original_assertions_satisfied']=all(z3.is_true(model.eval(t,model_completion=True))for t in terms);r['arbitrary_prestate_model']=model.sexpr();r['reachable_from_initial']='not_claimed'
   assert sha((G/row['file']).read_bytes())==row['sha256'];group.append(r);results.append(r);save(d/'results.json',group);save(O/'results.json',results)
  conclusion='original_preservation_UNSAT_by_complete_postcondition_split'if all(r['answer']=='unsat'for r in group)else'original_formula_SAT_witness_reachability_unclaimed'if any(r['answer']=='sat'and r.get('original_assertions_satisfied')for r in group)else'unresolved';save(d/'classification.json',dict(rule=rid,status=conclusion,original_answer_unchanged='unknown',all_leaves_checked=len(group)==len(leaves)))
 st(status='completed_postcondition_split_requires_controller_review',stage='finished')
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st(status='failed_or_rejected_no_retry',stage='stopped',error_type=type(e).__name__)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun lemma_count () Int)
(declare-fun lemma_start () Int)
(declare-fun lemma_seq () (Seq (_ BitVec 8)))
(assert
 (let ((?x8 (seq.extract lemma_seq lemma_start lemma_count)))
(let ((?x9 (seq.len ?x8)))
(let (($x10 (= ?x9 lemma_count)))
(not $x10)))))
(check-sat)

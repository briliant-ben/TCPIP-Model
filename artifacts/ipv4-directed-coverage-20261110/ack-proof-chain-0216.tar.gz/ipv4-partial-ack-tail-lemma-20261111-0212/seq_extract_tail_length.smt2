; benchmark generated from python API
(set-info :status unknown)
(declare-fun lemma_start () Int)
(declare-fun lemma_seq () (Seq (_ BitVec 8)))
(declare-fun lemma_count () Int)
(assert
 (let ((?x13 (seq.len lemma_seq)))
(let ((?x15 (- ?x13 lemma_start)))
(let ((?x8 (seq.extract lemma_seq lemma_start lemma_count)))
(let ((?x9 (seq.len ?x8)))
(let (($x12 (>= lemma_start 0)))
(let (($x19 (=> (and $x12 (<= lemma_start ?x13) (>= lemma_count ?x15)) (= ?x9 ?x15))))
(not $x19))))))))
(check-sat)

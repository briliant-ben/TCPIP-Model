; benchmark generated from python API
(set-info :status unknown)
(declare-fun lemma_b () (_ BitVec 32))
(declare-fun lemma_a () (_ BitVec 32))
(assert
 (let ((?x11 (ubv_to_int lemma_b)))
(let ((?x10 (ubv_to_int lemma_a)))
(let ((?x12 (- ?x10 ?x11)))
(let ((?x15 (ite (bvuge lemma_a lemma_b) ?x12 (+ ?x12 4294967296))))
(let ((?x8 (ubv_to_int (bvsub lemma_a lemma_b))))
(let (($x16 (= ?x8 ?x15)))
(not $x16))))))))
(check-sat)

from pathlib import Path
import json,sys,hashlib,os,time,traceback
P=Path('/home/blxu/protocol-flow');G=P/'candidates/ipv4-remaining-rule-preservation-20261110-0194';O=P/'candidates/ipv4-partial-ack-tail-lemma-20261111-0212';O.mkdir(exist_ok=False)
import z3
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
def st(**x):save(O/'status.json',dict(pid=os.getpid(),updated_at=time.time(),**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(status='running',stage='verify_theory_templates_before_any_use')
try:
 templates={};proofs=[]
 for name in ['seq_extract_inside_length','seq_extract_tail_length','bv32_unsigned_subtraction_int','invalid_extract_no_bounds_negative_control']:
  ctx=z3.Context();s=z3.Solver(ctx=ctx);s.set(timeout=10000)
  if name.startswith(('seq_extract','invalid_extract')):
   data=z3.Const('lemma_seq',z3.SeqSort(z3.BitVecSort(8,ctx=ctx)));start=z3.Int('lemma_start',ctx=ctx);count=z3.Int('lemma_count',ctx=ctx);eq=z3.Length(z3.SubSeq(data,start,count))==count
   theorem=z3.Implies(z3.And(start>=0,count>=0,start+count<=z3.Length(data)),eq)if name=='seq_extract_inside_length'else z3.Implies(z3.And(start>=0,start<=z3.Length(data),count>=z3.Length(data)-start),z3.Length(z3.SubSeq(data,start,count))==z3.Length(data)-start)if name=='seq_extract_tail_length'else eq
  else:
   a=z3.BitVec('lemma_a',32,ctx=ctx);b=z3.BitVec('lemma_b',32,ctx=ctx);left=z3.BV2Int(a-b);right=z3.If(z3.UGE(a,b),z3.BV2Int(a)-z3.BV2Int(b),z3.BV2Int(a)-z3.BV2Int(b)+(1<<32));theorem=left==right
  s.add(z3.Not(theorem));text=s.to_smt2();(O/(name+'.smt2')).write_text(text);answer=str(s.check());row=dict(template=name,negated_theorem_answer=answer,sha256=sha(text.encode()),solver_timeout_ms=10000,solver_version=z3.get_version_string());proofs.append(row)
  if answer=='unknown':row['reason']=s.reason_unknown()
  if name=='invalid_extract_no_bounds_negative_control':assert answer=='sat';row['accepted_as_theorem']=False
  elif answer=='unsat':templates[name]=True;row['accepted_as_theorem']=True
  else:row['accepted_as_theorem']=False
  save(O/'theorem-verification.json',proofs)
 if not templates:st(status='no_verified_lemmas_zero_API',stage='finished');raise SystemExit(0)
 payload=dict(task='Choose only already actually verified theory templates to aid two partialACK invariance UNKNOWN queries. Return strictJSON {use_templates:[IDs from verified],domain_changes:[],extra_protocol_assumptions:[],analysis:[strings],limitations:[strings]}. No code/newlemmas orbody edits. Actual0211postcondition decomposition checks ALLleaves:148UNSAT and2UNKNOWN, bothsamepostcondition ESTABLISHED implies snd_nxt=snd_una+Int2BV(len(rtx_buf),32). CRComission0209/0210didnotresolve. IMPORTANT exact IR bytes_slice(a,offset,count) usesCOUNT notend and truncatesatsequenceend: source z.SubSeq(a,If(offset<0,0,offset),If(count<0,0,count)). Inside-lengthlemma antecedentfails fortail slice withcount=len(a)andoffset>0; newlyverifiedTAILlemma coversoverrunclip. Preferseq_extract_tail_length, allfullbyteskept. FullSeqBV8 retained. Rootverified universal negatedtheoremUNSAT beforeanyapplication; false no-bounds extract lemma actualSAT andREJECTED. Existingexactv1 and complete0..16+complement partitions leftpartialUNKNOWN. Additional valid theory instances are tautologies, not protocol assumptions/lengthprojection. Only templates verifiedUNSAT mayinstantiate bymatching actualZ3 AST types/operators in originalSMT. Rootvisits originalassertionDAG, skipsquantifiers/boundvars, addsconditionalextractlengthfacts or exactunsigned32subtractionIntfacts; ALLoriginalconstraints remain. Same10s/target, no timeoutincrease/inputfix/prestate strengthening; oldUNKNOWNretained. No claimcompiler/wire/defaultreachability orwholeprotocol proof. Targets T.D-ACK-PARTIAL-WINDOW andT.D-ACK-PARTIAL-STALE-WINDOW. Discuss likely SSA/slice/modulararithmetic interaction andthelimits of templatecoverage.',verified=list(templates),theorem_results=proofs,scope='Selected defined-transition invariant checks; all65INVpre/post,fulltypedvariables/events,originaltransitionrelation',templates=dict(seq_extract_tail_length='ForSeqBV8 s/Int i,n:0<=i<=Length(s) and n>=Length(s)-i => Length(SubSeq(s,i,n))=Length(s)-i',seq_extract_inside_length='ForSeqBV8 s andInt i,n: i>=0 & n>=0 & i+n<=Length(s) => Length(SubSeq(s,i,n))=n',bv32_unsigned_subtraction_int='ForBV32 a,b: BV2Int(a-b)=If(UGE(a,b),BV2Int(a)-BV2Int(b),BV2Int(a)-BV2Int(b)+2^32)'))
 ms=[dict(role='system',content='Theory-lemma analyst; choose verified identifiers only, no unsupported proof/behavior claims. StrictJSON.'),dict(role='user',content=json.dumps(payload))];save(O/'messages.json',ms);st(status='running',stage='DeepSeek_verified_template_analysis')
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 api=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=4500,thinking='disabled',reasoning_effort=None,timeout=900);proposal=json.loads((P/'private/api-ledger'/api['response_file']).read_text())['response'];save(O/'response.json',proposal);save(O/'usage.json',{k:api.get(k)for k in ['usage','cached','request_sha256']});chosen=proposal.get('use_templates')
 assert type(chosen)is list and chosen and len(chosen)==len(set(chosen))and set(chosen)<=set(templates)and proposal.get('domain_changes')==[]and proposal.get('extra_protocol_assumptions')==[]
 rows=json.loads((G/'results.json').read_text());targets=[r for r in rows if r['role']=='preservation'and r['answer']=='unknown'and r['rule']in ['T.D-ACK-PARTIAL-WINDOW','T.D-ACK-PARTIAL-STALE-WINDOW']];assert len(targets)==2;results=[]
 for i,row in enumerate(targets):
  st(status='running',stage='instantiate_only_verified_theory_facts',rule=row['rule']);original=G/row['file'];text=original.read_text();assert sha(text.encode())==row['sha256'];ctx=z3.Context();terms=z3.parse_smt2_string(text,ctx=ctx);seqsort=z3.SeqSort(z3.BitVecSort(8,ctx=ctx));seen=set();facts=[]
  def visit(node):
   if z3.is_quantifier(node)or not z3.is_app(node)or node.get_id()in seen:return
   seen.add(node.get_id())
   for child in node.children():visit(child)
   if len(facts)>=200:return
   kind=node.decl().kind()
   if 'seq_extract_inside_length'in chosen and kind==z3.Z3_OP_SEQ_EXTRACT and node.arg(0).sort().eq(seqsort):
    data,start,count=node.children();facts.append(z3.Implies(z3.And(start>=0,count>=0,start+count<=z3.Length(data)),z3.Length(node)==count))
   if 'seq_extract_tail_length'in chosen and kind==z3.Z3_OP_SEQ_EXTRACT and node.arg(0).sort().eq(seqsort):
    data,start,count=node.children();facts.append(z3.Implies(z3.And(start>=0,start<=z3.Length(data),count>=z3.Length(data)-start),z3.Length(node)==z3.Length(data)-start))
   if 'bv32_unsigned_subtraction_int'in chosen and kind==z3.Z3_OP_BSUB and node.size()==32:
    a,b=node.children();facts.append(z3.BV2Int(node)==z3.If(z3.UGE(a,b),z3.BV2Int(a)-z3.BV2Int(b),z3.BV2Int(a)-z3.BV2Int(b)+(1<<32)))
  for q in terms:visit(q)
  s=z3.Then(*[z3.Tactic(n,ctx=ctx)for n in ['propagate-values','solve-eqs','simplify','smt']]).solver();s.set(timeout=10000);s.add(terms);s.add(facts);out=O/str(i).zfill(3);out.mkdir();(out/'original.smt2').write_text(text);(out/'with-verified-lemmas.smt2').write_text(s.to_smt2());save(out/'instances.json',[f.sexpr()for f in facts]);answer=str(s.check());r=dict(rule=row['rule'],original_sha256=row['sha256'],new_query_sha256=sha((out/'with-verified-lemmas.smt2').read_bytes()),answer=answer,theorem_templates=chosen,verified_instances=len(facts),all_original_assertions_preserved=True,full_byte_sequences_preserved=True,old_answer_unchanged='unknown',solver_timeout_ms=10000,solver_version=z3.get_version_string())
  if answer=='unknown':r['reason']=s.reason_unknown()
  if answer=='sat':
   model=s.model();r['original_assertions_satisfied']=all(z3.is_true(model.eval(t,model_completion=True))for t in terms);r['arbitrary_prestate_model']=model.sexpr();r['reachable_from_initial']='not_claimed'
  assert sha(original.read_bytes())==row['sha256'];results.append(r);save(O/'results.json',results)
 st(status='completed_verified_lemma_diagnostic_requires_review',stage='finished',answers=[r['answer']for r in results])
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st(status='failed_or_rejected_no_retry',stage='stopped',error_type=type(e).__name__)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun lemma_buf () (Seq (_ BitVec 8)))
(declare-fun lemma_una () (_ BitVec 32))
(declare-fun lemma_ack () (_ BitVec 32))
(assert
 (let ((?x25 (bvadd lemma_una ((_ int_to_bv 32) (seq.len lemma_buf)))))
(let ((?x10 (ubv_to_int (bvsub lemma_ack lemma_una))))
(let ((?x16 (seq.extract lemma_buf (ite (< ?x10 0) 0 ?x10) (ite (< (seq.len lemma_buf) 0) 0 (seq.len lemma_buf)))))
(and (and (<= (seq.len lemma_buf) 16) (<= ?x10 (seq.len lemma_buf))) (not (= (bvadd lemma_ack ((_ int_to_bv 32) (seq.len ?x16))) ?x25)))))))
(check-sat)

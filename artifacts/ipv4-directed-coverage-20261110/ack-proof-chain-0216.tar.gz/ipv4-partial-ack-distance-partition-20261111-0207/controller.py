from pathlib import Path
import json,sys,hashlib,os,time,traceback,copy
P=Path('/home/blxu/protocol-flow');S=P/'candidates/ipv4-qualified-flow-20261109-0181/workspace';G=P/'candidates/ipv4-remaining-rule-preservation-20261110-0194';O=P/'candidates/ipv4-partial-ack-distance-partition-20261111-0207';O.mkdir(exist_ok=False);sys.path.insert(0,str(S))
from protocol_lab.ir import load
from protocol_lab.symbolic import Encoding,model_hash
import z3
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
def st(**x):save(O/'status.json',dict(pid=os.getpid(),updated_at=time.time(),**x))
(O/'controller.py').write_bytes(Path(__file__).read_bytes());st(status='running',stage='qualify_complete_partition_including_outside')
PLAN=['propagate-values','solve-eqs','simplify','smt']
def leaf(text,selector,k,out):
 ctx=z3.Context();terms=z3.parse_smt2_string(text,ctx=ctx);v=selector.translate(ctx);finite=[v==i for i in range(17)];outside=z3.Not(z3.Or(*finite));coverage_solver=z3.Solver(ctx=ctx);coverage_solver.set(timeout=10000);coverage_solver.add(z3.Not(z3.Or(*finite,outside)));assert coverage_solver.check()==z3.unsat;member=outside if k=='outside'else v==k
 s=z3.Then(*[z3.Tactic(n,ctx=ctx)for n in PLAN]).solver();s.set(timeout=10000);s.add(terms);s.add(member);query=s.to_smt2()
 if out is not None:out.write_text(query)
 t=time.monotonic()
 try:a=str(s.check())
 except z3.Z3Exception as e:return dict(answer='unknown',reason=str(e),case=k)
 r=dict(case=k,answer=a,seconds=time.monotonic()-t,query_sha256=sha(query.encode()),original_sha256=sha(text.encode()),solver_version=z3.get_version_string(),solver_timeout_ms=10000,solver_plan=PLAN,full_complement_included=True)
 if a=='unknown':r['reason']=s.reason_unknown()
 if a=='sat':
  model=s.model();r['original_assertions_satisfied']=all(z3.is_true(model.eval(q,model_completion=True))for q in terms);r['original_model_sexpr']=model.sexpr();r['reachable_from_initial']='not_claimed'
 return r
try:
 x=z3.Int('partition_test_x');q='(declare-const partition_test_x Int) (assert (= partition_test_x 17))';qualification=[leaf(q,x,k,None)for k in [*range(17),'outside']];assert all(r['answer']=='unsat'for r in qualification[:-1])and qualification[-1]['answer']=='sat'and qualification[-1]['original_assertions_satisfied'];save(O/'qualification.json',dict(status='pass',purpose='outside SAT prevents finite-inside UNSAT from becoming a universal pass',queries=qualification))
 mf=S/'model/ipv4-endpoint-virtual-link.json';assert sha(mf.read_bytes())=='7d5a82541ea55cde3ff39b2e1cf883f6c9f942f5dc535a2736e69044d9e154a5';m=load(mf);rows=json.loads((G/'results.json').read_text());targets=[r for r in rows if r['role']=='preservation'and r['answer']=='unknown'and r['rule']in ['T.D-ACK-PARTIAL-WINDOW','T.D-ACK-PARTIAL-STALE-WINDOW']];assert len(targets)==2;ids=[r['rule']for r in targets];pool={}
 def visit(v):
  if isinstance(v,dict):
   if v.get('op')in ['seq_distance','bytes_len']:
    b=json.dumps(v,sort_keys=True,separators=(',',':')).encode();pool[sha(b)]=copy.deepcopy(v)
   for a in v.values():visit(a)
  elif isinstance(v,list):
   for a in v:visit(a)
 selected=[r for r in m['transitions']if r['id']in ids]
 for r in selected:visit(r['guard']);visit(r['actions'])
 for inv in m['invariants']:visit(inv['assert'])
 save(O/'candidate-expressions-full.json',pool)
 def summary(v):
  variables=set();events=set()
  def walk(n):
   if isinstance(n,dict):
    if 'var'in n:variables.add(n['var'])
    if 'event'in n:events.add(n['event'])
    for q in n.values():walk(q)
   elif isinstance(n,list):
    for q in n:walk(q)
  walk(v);return dict(op=v['op'],variables=sorted(variables),event_fields=sorted(events),expression_bytes=len(json.dumps(v).encode()))
 pool_summary={h:summary(v)for h,v in pool.items()}
 selected_summary=[dict(id=r['id'],event=r['event'],guard_sha256=sha(json.dumps(r['guard'],sort_keys=True).encode()),actions=[dict(kind=next(iter(a)),variable=a.get('set',{}).get('var'),value_op=a.get('set',{}).get('value',{}).get('op')if isinstance(a.get('set',{}).get('value'),dict)else None)for a in r['actions']])for r in selected]
 samples=[dict(rule=r['rule'],file=r['file'],sha256=r['sha256'])for r in targets];save(O/'candidate-expressions.json',pool);save(O/'original-targets.json',samples)
 payload=dict(task='Choose ONE useful scalar integer partition selector per each actual3ACK preservationUNKNOWN rules. Exactv1 alreadytimedout onall3 sameoriginalbodies/10s. Return strictJSON {selectors:[{rule,expression_sha256,reason}],domain_changes:[],extra_assumptions:[],cases_config:"0..16_plus_full_complement",limitations:[strings]}. SelectONLYSHAfromexactIRexpressionpool, no code/newexpressions/model/invariant/domain changes. Expressions evaluated in symbolicPRESTATE plusoriginaleventfields. Proofstrategy originalfullSMT PLUS selector==k for eachk0..16 AND mandatoryoutside Not(Or(selector==0..16)). FinitecasesDO NOTassume selectorbounded: outside isalso solved atsame10s. OnlyALL18UNSAT permitsoriginalproperty conclusion; anyunknownkeepsunresolved; SATmustsatisfyALLoriginalassertions, notinitialreachability. Poolcontains sequence distances andbufferlengths fromactualrules/all65INV; ACKdelta/buffer-slice length finite relation islikelybottleneck, chooseconcretegoodselectorandjustifyas hypothesis. Modelbuffers16/SMSS4 motivateworkpartition NOTdomainrestriction. No lengthprojection (allSeqBV8 bytes/content retained), no fixedpayload/window/T.control, no droppedguards/invariants/SSArelation. SourceoldreviewincorrectlycalledunknownICMP/SYN; actual3ruleslistedareACK FULLSTALE/PARTIAL/PARTIALSTALE. DoNOTraisetimeout/retryoriginalplain/checkoldpassed30, orstrengthenpreconditions tofixvacuity. Qualification actualx=17 provesoutsideSATkeepspropertynotpass. Only selectorschosen byyou, all solver/formula code trustedcontroller.',targets=samples,rules=selected_summary,invariants=m['invariants'],variables=m['variables'],candidate_expressions=pool_summary,prior_experiment='0206 full ACK stale solved by complete partition; partial ACK length-based partitions left UNKNOWN. Prefer original IR acknowledged sequence-distance term reading T.snd_una and frame, NOT another buffer-length split. Full expressions remain frozen by hash; summaries only reduce prompt size, never semantic contents.')
 ms=[dict(role='system',content='Exact-formula proof decomposition analyst, strictJSON identifiers only. No source code or unsupported proof claims.'),dict(role='user',content=json.dumps(payload))];assert len(json.dumps(ms).encode())<85000;save(O/'messages.json',ms);st(status='running',stage='DeepSeek_ACK_partition_analysis')
 sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 api=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=5500,thinking='disabled',reasoning_effort=None,timeout=900);p=json.loads((P/'private/api-ledger'/api['response_file']).read_text())['response'];save(O/'response.json',p);save(O/'usage.json',{k:api.get(k)for k in ['usage','cached','request_sha256']})
 assert type(p)is dict and p.get('domain_changes')==[]and p.get('extra_assumptions')==[]and p.get('cases_config')=='0..16_plus_full_complement';choices=p['selectors'];assert len(choices)==2 and {c['rule']for c in choices}==set(ids);choice={c['rule']:c['expression_sha256']for c in choices};assert all(h in pool for h in choice.values())
 save(O/'scope.json',dict(model_semantic_sha256=model_hash(m),model_file_sha256=sha(mf.read_bytes()),targets=samples,selectors=choice,cases=[*range(17),'outside'],per_leaf_timeout_ms=10000,max_leaves=36,aggregate_leaf_budget_is_separate_from_original_query=True,original_UNKNOWN_unchanged=True,coverage_identity='P & (s=0 or ... or s=16 or not(s=0 or ... or s=16)) == P',full_byte_sequences=True,domain_restriction=False,whole_protocol_proved=False));save(O/'source-bindings.json',{str(f):sha(f.read_bytes())for f in [mf,S/'protocol_lab/ir.py',S/'protocol_lab/symbolic.py',O/'controller.py']});results=[];save(O/'results.json',results)
 for i,row in enumerate(targets):
  rid=row['rule'];idx=next(k for k,r in enumerate(m['transitions'])if r['id']==rid);enc=Encoding(m,1,tuple(m['variables']),arbitrary_state=True,fixed_choices=[idx]);selector=enc.expr(pool[choice[rid]],enc.frames[0],enc.events[0][m['transitions'][idx]['event']]);assert selector.sort().kind()==z3.Z3_INT_SORT;d=O/str(i).zfill(3);d.mkdir();original=G/row['file'];text=original.read_text();assert sha(text.encode())==row['sha256'];(d/'original.smt2').write_text(text);group=[]
  for k in [*range(17),'outside']:
   st(status='running',stage='solve_exhaustive_partition_leaf',rule=rid,case=k,completed_queries=len(results),total_queries=36);r=leaf(text,selector,k,d/(str(k)+'.smt2'));assert sha(original.read_bytes())==row['sha256'];r['rule']=rid;group.append(r);results.append(r);save(d/'results.json',group);save(O/'results.json',results)
  conclusion='original_preservation_UNSAT_by_complete_partition'if all(r['answer']=='unsat'for r in group)else'original_formula_SAT_witness_reachability_unclaimed'if any(r['answer']=='sat'and r.get('original_assertions_satisfied')for r in group)else'unresolved'
  save(d/'classification.json',dict(rule=rid,status=conclusion,original_answer_unchanged='unknown',full_complement_checked=True))
 st(status='completed_partition_requires_controller_review',stage='finished')
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st(status='failed_or_proposal_rejected_no_retry',stage='stopped',error_type=type(e).__name__)

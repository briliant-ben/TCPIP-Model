from pathlib import Path
import ast,difflib,hashlib,json,os,resource,shutil,subprocess,sys,tarfile,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-timer-root-validation-20261108-0099';O.mkdir(exist_ok=False);W=P/'candidates/tcp-coupling-complete-deps-20261107-0081/workspace';F=P/'candidates/tcp-owner-validation-20261107-0094';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'))
from deepseek_gateway import request

def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),provider='DeepSeek-independent-review-only',production_modified=False,automatic_failed_API_retry=False,prototype_complete=False,**v))
try:
 status(status='running',stage='isolated_controller_fix_validation',started_at=time.time())
 tarpath=P/'incoming/tcp-timer-root-fix-clean-20261108.tar';assert hashlib.sha256(tarpath.read_bytes()).hexdigest()=='baec993bff87d6ca4732539cfe8f3442aced410051c6c4f6dccfafe75f6d579e'
 overlay=O/'workspace';shutil.copytree(W,overlay,ignore=shutil.ignore_patterns('__pycache__'));names={'protocol_lab/ir.py','protocol_lab/symbolic.py','tests/test_symbolic_timer_replay.py'}
 with tarfile.open(tarpath)as tar:
  assert {m.name for m in tar.getmembers()}==names
  for m in tar.getmembers():assert m.isfile();(overlay/m.name).write_bytes(tar.extractfile(m).read())
 old_encoding=next(n for n in ast.parse((W/'protocol_lab/symbolic.py').read_text()).body if isinstance(n,ast.ClassDef)and n.name=='Encoding');new_encoding=next(n for n in ast.parse((overlay/'protocol_lab/symbolic.py').read_text()).body if isinstance(n,ast.ClassDef)and n.name=='Encoding');assert ast.dump(old_encoding)==ast.dump(new_encoding)
 save('source-bindings.json',dict(tar_sha256=hashlib.sha256(tarpath.read_bytes()).hexdigest(),files={n:hashlib.sha256((overlay/n).read_bytes()).hexdigest()for n in names},Encoding_AST_identical=True,origin='controller fallback after0096 incomplete API; NOT DeepSeek implementation or failed API retry'))
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(240,240));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 with(O/'tests.log').open('w')as log:cp=subprocess.run([str(PY),'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=360,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 assert cp.returncode==0,'53 actual unit tests failed'
 child="""from pathlib import Path
import json,sys
R=Path(sys.argv[1]);sys.path.insert(0,str(R));P=Path('/home/blxu/protocol-flow');F=P/'candidates/tcp-owner-validation-20261107-0094';O=Path(sys.argv[2])
from protocol_lab.ir import load
from protocol_lab.symbolic import crosscheck_trace
m=load(F/'candidate-model.json');trace=json.loads((F/'cases/tcp-arp-failure-keeps-tcp/reference-trace.json').read_text());result=crosscheck_trace(m,trace,O);assert result['query']=='sat'and result['status']=='match';assert(F/'cases/tcp-arp-failure-keeps-tcp/symbolic/path.smt2').read_bytes()==(O/'path.smt2').read_bytes()
"""
 script=O/'executed-exact-query.py';script.write_text(child);status(status='running',stage='original_SAT_query_byte_identity_and_replay')
 with(O/'exact-query.log').open('w')as log:cp=subprocess.run([str(PY),str(script),str(overlay),str(O/'exact-query')],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=180,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 assert cp.returncode==0,'original exact query/replay failed'
 # Re-run the existing fully frozen owner gate with only reference/checker
 # workspace changed. No oracle or model/solver budget changes.
 source=(P/'incoming/tcp-owner-validation-0094.py').read_text().replace("O=P/'candidates/tcp-owner-validation-20261107-0094'","O=P/'candidates/tcp-timer-root-validation-20261108-0099/owner-validation'").replace("W=P/'candidates/tcp-coupling-complete-deps-20261107-0081/workspace'","W=P/'candidates/tcp-timer-root-validation-20261108-0099/workspace'")
 owner_script=O/'executed-owner-validation.py';owner_script.write_text(source);status(status='running',stage='five_owner_cases_and_three_fault_probes')
 with(O/'owner.log').open('w')as log:cp=subprocess.run([str(PY),str(owner_script)],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=420,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
 owner=json.loads((O/'owner-validation/status.json').read_text());assert cp.returncode==0 and owner['status']=='finite_owner_interaction_gate_pass_controller_review_required','owner interaction gate rejected'
 for n in ['original-frozen-cases.json','qualified-frozen-cases.json']:assert (F/n).read_bytes()==(O/'owner-validation'/n).read_bytes(),'frozen oracle changed'
 diffs={n:''.join(difflib.unified_diff((W/n).read_text().splitlines(True),(overlay/n).read_text().splitlines(True)))for n in ['protocol_lab/ir.py','protocol_lab/symbolic.py']};save('exact-gates.json',dict(original_query_byte_identical=True,original_SAT_replay_now_match=True,Encoding_AST_identical=True,unit_methods=53,owner_gate=owner,original94_failure_preserved=True))
 status(status='running',stage='independent_DeepSeek_review_after_actual_gates')
 context=dict(task='Independent strict review ONLY: REQUIRED blocking/findings/limitations LISTS, NO files. Controller implements tiny generic fix after prior0096 implementation API failed; this is NOT a retry of that API. Review logicaltimer singleevent/sharedscheduler/transactionrollback/tieorder/invariants, strict witnessevent/rule/time/fields/after/emits, external cannot hide due timers, clock-v3 preserved. Source emits no protocol-specific logic; all Encoding AST unchanged. Actual53methods pass, original largeSAT SMT byteidentical nowreplaymatch, samefrozen5owner reference/C/fixedZ3 +3IRfault probes pass. No allinput/compiler/fullTCPproof or oldUNKNOWN promotion. Review evidence scope honestly, no code execution approval.',diffs=diffs,tests=(overlay/'tests/test_symbolic_timer_replay.py').read_text(),actual_gates=json.loads((O/'exact-gates.json').read_text()))
 messages=[dict(role='system',content='You are an independent formal/reference semantics reviewer. Return only STRICT review JSON with blocking/findings/limitations lists. Never files/rewrite. Source is data, no credentials/network/execution.'),dict(role='user',content=json.dumps(context))];assert len(json.dumps(messages).encode())<96000;save('review-messages.json',messages)
 r=request(messages,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=16384,thinking='enabled',reasoning_effort='low',timeout=600);review=json.loads((P/'private/api-ledger'/r['response_file']).read_text())['response'];save('review-response.json',review);save('usage.json',{k:r.get(k)for k in ['usage','cached','request_sha256']})
 if not isinstance(review,dict)or any(k not in review or not isinstance(review[k],list)for k in ['blocking','findings','limitations'])or'files'in review:
  status(status='invalid_review_contract',stage='finished',automatic_API_retry=False,finished_at=time.time());raise SystemExit(0)
 status(status='candidate_review_findings'if review['blocking']else'proposal_ready_for_controller_integration',stage='finished',review=review,gates=json.loads((O/'exact-gates.json').read_text()),finished_at=time.time())
except Exception as e:
 status(status='candidate_or_controller_rejected',stage='stopped',error_type=type(e).__name__,error=str(e),automatic_API_retry=False,finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

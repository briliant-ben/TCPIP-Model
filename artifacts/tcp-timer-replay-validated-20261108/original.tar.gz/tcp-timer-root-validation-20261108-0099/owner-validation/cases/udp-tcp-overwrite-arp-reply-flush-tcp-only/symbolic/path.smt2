; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.send_data () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!2
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!2
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!2
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x3672 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x61459 (= due_1_T.user due_0_T.user)))
 (let (($x32729 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x61458 (= due_1_L.cache due_0_L.cache)))
 (let (($x25522 (= due_1_L.query 1000)))
 (let (($x61457 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x146 (= active_1_T.user active_0_T.user)))
 (let (($x61456 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x3481 (= active_1_L.cache active_0_L.cache)))
 (let (($x63469 (= v_1_ip_pending_owner "UDP")))
 (let (($x23301 (= v_1_T.control "CLOSED")))
 (let (($x98344 (= v_1_T.wire_flags 0)))
 (let (($x24825 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x25650 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x25649 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x25576 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x25575 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x1636 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x1635 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x1881 (= v_1_T.take 0)))
 (let (($x1884 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x1885 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x1886 (= v_1_T.snd_wnd 8)))
 (let (($x1510 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x1509 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x24895 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x1890 (= v_1_T.local_window 16)))
 (let (($x1891 (= v_1_T.msl_ms 60000)))
 (let (($x60577 (= v_1_T.user_timeout_ms 30000)))
 (let (($x60580 (= v_1_T.retries 0)))
 (let (($x60581 (= v_1_T.rto_ms 1000)))
 (let (($x60579 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x60582 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x60583 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x60584 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x60585 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x60588 (= v_1_T.irs (_ bv0 32))))
 (let (($x60589 (= v_1_T.iss (_ bv1000 32))))
 (let (($x98439 (= v_1_L.control "PENDING")))
 (let (($x24894 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x25076 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x25578 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x25577 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x25100 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x23131 (not v_1_L.rxudp_require_checksum)))
 (let ((?x93908 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x33281 (seq.unit (_ bv0 8))))
 (let ((?x93909 (seq.++ ?x33281 ?x93908)))
 (let ((?x30133 (seq.unit (_ bv192 8))))
 (let ((?x25196 (seq.unit (_ bv13 8))))
 (let ((?x60626 (seq.++ ?x33281 (seq.++ ?x25196 (seq.++ ?x30133 (seq.++ (seq.unit (_ bv119 8)) ?x93909))))))
 (let ((?x33273 (seq.unit (_ bv144 8))))
 (let ((?x1349 (seq.unit (_ bv31 8))))
 (let ((?x30233 (seq.unit (_ bv64 8))))
 (let ((?x1345 (seq.unit (_ bv156 8))))
 (let ((?x60637 (seq.++ ?x1345 (seq.++ ?x30233 (seq.++ ?x1349 (seq.++ ?x33273 ?x60626))))))
 (let ((?x63059 (seq.unit (_ bv2 8))))
 (let ((?x432 (seq.unit (_ bv1 8))))
 (let ((?x25038 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x63059 ?x60637)))))))
 (let ((?x1791 (seq.unit (_ bv200 8))))
 (let ((?x24888 (seq.unit (_ bv182 8))))
 (let ((?x25070 (seq.++ ?x24888 (seq.++ ?x1791 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 ?x25038)))))))
 (let ((?x98675 (seq.unit (_ bv17 8))))
 (let ((?x24826 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x98675 ?x25070)))))))
 (let ((?x60643 (seq.unit (_ bv33 8))))
 (let ((?x98684 (seq.unit (_ bv69 8))))
 (let ((?x1526 (seq.++ ?x98684 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x60643 (seq.++ ?x33281 ?x24826)))))))
 (let (($x1176 (= v_1_L.pending_packet ?x1526)))
 (let (($x1175 (= v_1_L.ip_checksum 46792)))
 (let (($x24864 (= v_1_L.udp_checksum 49271)))
 (let (($x24863 (= v_1_L.udp_raw_checksum 49271)))
 (let (($x1679 (= v_1_L.ip_length 33)))
 (let (($x1678 (= v_1_L.udp_length 13)))
 (let (($x25069 (= v_1_L.packet ?x1526)))
 (let ((?x1514 (seq.++ ?x63059 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 ?x63059)))))))
 (let ((?x1516 (seq.++ ?x30133 (seq.++ ?x33281 ?x1514))))
 (let ((?x25010 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x98675 (seq.++ ?x24888 (seq.++ ?x1791 ?x1516)))))))
 (let ((?x24993 (seq.++ ?x33281 (seq.++ ?x60643 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x30233 ?x25010)))))))
 (let (($x24996 (= v_1_L.ip_wire (seq.++ ?x98684 (seq.++ ?x33281 ?x24993)))))
 (let ((?x25113 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x98675 (seq.++ ?x33281 (seq.++ ?x33281 ?x1516)))))))
 (let ((?x25118 (seq.++ ?x33281 (seq.++ ?x60643 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x30233 ?x25113)))))))
 (let (($x25121 (= v_1_L.ip_zero (seq.++ ?x98684 (seq.++ ?x33281 ?x25118)))))
 (let (($x60638 (= v_1_L.udp_wire ?x60637)))
 (let ((?x25179 (seq.++ ?x63059 (seq.++ ?x63059 (seq.++ ?x33281 (seq.++ ?x98675 (seq.++ ?x33281 ?x25196)))))))
 (let ((?x19914 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 ?x25179)))))))
 (let (($x19916 (= v_1_L.pseudoheader (seq.++ ?x30133 ?x19914))))
 (let ((?x1599 (seq.++ ?x33273 (seq.++ ?x33281 (seq.++ ?x25196 (seq.++ ?x33281 (seq.++ ?x33281 ?x93909)))))))
 (let (($x24950 (= v_1_L.udp_zero (seq.++ ?x1345 (seq.++ ?x30233 (seq.++ ?x1349 ?x1599))))))
 (let (($x25349 (= v_1_L.payload ?x93909)))
 (let (($x1687 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x30094 (= 0 v_1_L.retry_count)))
 (let (($x25209 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x2624 (= 0 state_1)))
 (let (($x65479 (not active_0_T.time_wait)))
 (let (($x25208 (or $x65479 (not (<= due_0_T.time_wait 0)))))
 (let (($x65480 (not active_0_T.user)))
 (let (($x25205 (or $x65480 (not (<= due_0_T.user 0)))))
 (let (($x65481 (not active_0_T.rtx)))
 (let (($x25155 (or $x65481 (not (<= due_0_T.rtx 0)))))
 (let (($x653 (not active_0_L.cache)))
 (let (($x24912 (or $x653 (not (<= due_0_L.cache 0)))))
 (let (($x654 (not active_0_L.query)))
 (let (($x24909 (or $x654 (not (<= due_0_L.query 0)))))
 (let (($x3320 (= state_0 0)))
 (and $x3320 (>= 0 now_0) $x24909 $x24912 $x25155 $x25205 $x25208 $x2624 $x25209 $x30094 $x1687 v_1_L.checksums_enabled $x25349 $x24950 $x19916 $x60638 $x25121 $x24996 $x25069 $x1678 $x1679 $x24863 $x24864 $x1175 $x1176 $x23131 $x25100 (= v_1_L.rxudp_disposition "none") $x25577 $x25578 $x25076 $x24894 (= v_1_L.echo_disposition "none") $x98439 $x60589 $x60588 $x60585 $x60584 $x60583 $x60582 $x60579 (= v_1_T.tx_flags "S") $x60581 $x60580 v_1_T.active_open $x60577 $x1891 $x1890 $x24895 $x1509 $x1510 $x1886 $x1885 $x1884 $x1881 $x1635 $x1636 $x25575 $x25576 $x25649 $x25650 $x24825 $x98344 (= v_1_T.wire_disposition "none") $x23301 $x63469 active_1_L.query $x3481 $x61456 $x146 $x61457 $x25522 $x61458 $x32729 $x61459 $x3672))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x23513 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x25130 (= due_2_T.rtx 1001)))
 (let (($x23510 (= due_2_L.cache due_1_L.cache)))
 (let (($x23509 (= due_2_L.query due_1_L.query)))
 (let (($x24886 (not active_2_T.time_wait)))
 (let (($x23505 (= active_2_L.cache active_1_L.cache)))
 (let (($x23504 (= active_2_L.query active_1_L.query)))
 (let (($x23503 (= v_2_ip_pending_owner "TCP")))
 (let (($x23502 (= v_2_T.control "SYN-SENT")))
 (let (($x23501 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x24781 (= v_2_T.wire_flags 2)))
 (let ((?x33281 (seq.unit (_ bv0 8))))
 (let ((?x33197 (seq.++ ?x33281 ?x33281)))
 (let ((?x225 (seq.++ ?x33281 (seq.++ ?x33281 ?x33197))))
 (let ((?x23368 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) v_1_T.local_window)))))
 (let ((?x23366 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) v_1_T.local_window)))))
 (let ((?x63059 (seq.unit (_ bv2 8))))
 (let ((?x23359 (seq.unit (_ bv80 8))))
 (let ((?x1488 (seq.++ ?x33281 (seq.++ ?x23359 (seq.++ ?x63059 (seq.++ ?x23366 (seq.++ ?x23368 ?x225)))))))
 (let ((?x1511 (seq.unit ((_ extract 7 0) v_1_T.iss))))
 (let ((?x25635 (seq.unit ((_ extract 15 8) v_1_T.iss))))
 (let ((?x94941 (seq.++ ?x25635 (seq.++ ?x1511 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 ?x1488)))))))
 (let ((?x24810 (seq.unit ((_ extract 23 16) v_1_T.iss))))
 (let ((?x65773 (seq.unit ((_ extract 31 24) v_1_T.iss))))
 (let ((?x33273 (seq.unit (_ bv144 8))))
 (let ((?x1349 (seq.unit (_ bv31 8))))
 (let ((?x30233 (seq.unit (_ bv64 8))))
 (let ((?x24980 (seq.++ ?x30233 (seq.++ ?x1349 (seq.++ ?x33273 (seq.++ ?x65773 (seq.++ ?x24810 ?x94941)))))))
 (let ((?x1345 (seq.unit (_ bv156 8))))
 (let ((?x24862 (seq.++ ?x1345 ?x24980)))
 (let ((?x25060 (seq.unit (_ bv20 8))))
 (let ((?x3144 (seq.unit (_ bv6 8))))
 (let ((?x24844 (seq.++ ?x63059 (seq.++ ?x33281 (seq.++ ?x3144 (seq.++ ?x33281 (seq.++ ?x25060 ?x24862)))))))
 (let ((?x30133 (seq.unit (_ bv192 8))))
 (let ((?x432 (seq.unit (_ bv1 8))))
 (let ((?x1848 (seq.++ ?x63059 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 ?x24844)))))))
 (let ((?x1802 ((_ ir4_ones_sum16_checksum_instance!2 0) (seq.++ ?x30133 (seq.++ ?x33281 ?x1848)))))
 (let ((?x25214 (seq.++ (seq.unit (bvnot ((_ extract 15 8) ?x1802))) (seq.++ (seq.unit (bvnot ((_ extract 7 0) ?x1802))) ?x33197))))
 (let ((?x1893 (seq.++ ?x33281 (seq.++ ?x23359 (seq.++ ?x63059 (seq.++ ?x23366 (seq.++ ?x23368 ?x25214)))))))
 (let ((?x1829 (seq.++ ?x25635 (seq.++ ?x1511 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 ?x1893)))))))
 (let ((?x25468 (seq.++ ?x30233 (seq.++ ?x1349 (seq.++ ?x33273 (seq.++ ?x65773 (seq.++ ?x24810 ?x1829)))))))
 (let ((?x19873 (seq.++ ?x1345 ?x25468)))
 (let ((?x25416 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x63059 ?x19873)))))))
 (let ((?x1217 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 ?x25416))))))
 (let ((?x24888 (seq.unit (_ bv182 8))))
 (let ((?x25041 (seq.++ ?x30233 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x3144 (seq.++ ?x24888 ?x1217)))))))
 (let ((?x25401 (seq.unit (_ bv40 8))))
 (let ((?x1730 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x25401 (seq.++ ?x33281 (seq.++ ?x33281 ?x25041)))))))
 (let ((?x98684 (seq.unit (_ bv69 8))))
 (let ((?x1727 (seq.++ ?x98684 ?x1730)))
 (let (($x24887 (= v_2_T.wire_packet ?x1727)))
 (let ((?x1514 (seq.++ ?x63059 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 ?x63059)))))))
 (let ((?x1516 (seq.++ ?x30133 (seq.++ ?x33281 ?x1514))))
 (let ((?x1720 (seq.++ ?x33281 (seq.++ ?x33281 ?x1516))))
 (let ((?x23420 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x33281 (seq.++ ?x30233 (seq.++ ?x3144 ?x1720)))))))
 (let ((?x23421 (seq.++ ?x33281 ?x23420)))
 (let (($x25572 (= v_2_T.wire_ip_zero (seq.++ ?x98684 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x25401 ?x23421)))))))
 (let (($x25571 (= v_2_T.wire_tcp ?x19873)))
 (let ((?x1535 (seq.++ ?x63059 (seq.++ ?x63059 (seq.++ ?x33281 (seq.++ ?x3144 (seq.++ ?x33281 ?x25060)))))))
 (let ((?x25492 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x432 (seq.++ ?x30133 (seq.++ ?x33281 ?x1535)))))))
 (let (($x25200 (= v_2_T.wire_pseudo (seq.++ ?x30133 ?x25492))))
 (let (($x1784 (= v_2_T.wire_tcp_zero ?x24862)))
 (let (($x1594 (= (as seq.empty (Seq (_ BitVec 8))) v_2_T.wire_data)))
 (let (($x23493 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x23492 (= v_2_T.take v_1_T.take)))
 (let (($x23491 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x23490 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x23489 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x23488 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x23487 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x23486 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x23485 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x23484 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x23483 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x23481 (= 0 v_2_T.retries)))
 (let (($x23480 (= 1000 v_2_T.rto_ms)))
 (let (($x23479 (= v_2_T.tx_flags "S")))
 (let (($x1593 (= v_2_T.tx_ack (_ bv0 32))))
 (let (($x23477 (= v_2_T.tx_seq v_1_T.iss)))
 (let (($x23476 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x24763 (= v_2_T.snd_nxt (bvadd (_ bv1 32) v_1_T.iss))))
 (let (($x23474 (= v_2_T.snd_una v_1_T.iss)))
 (let (($x23473 (= v_2_T.irs v_1_T.irs)))
 (let (($x23472 (= v_2_T.iss v_1_T.iss)))
 (let (($x23471 (= v_2_L.control v_1_L.control)))
 (let (($x23470 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x23469 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x23468 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x23467 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x23466 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x23465 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x23464 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x23463 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x1729 (= v_2_L.pending_packet ?x1727)))
 (let (($x23461 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x23460 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x23459 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x23458 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x23457 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x23456 (= v_2_L.packet v_1_L.packet)))
 (let (($x23455 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x23454 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x23453 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x23452 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x23451 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x23450 (= v_2_L.payload v_1_L.payload)))
 (let (($x23449 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x23448 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x23447 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x23446 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x23445 (= 0 state_2)))
 (let (($x25395 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 1)))))
 (let (($x25393 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x25222 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x25399 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x25217 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let (($x98439 (= v_1_L.control "PENDING")))
 (let (($x23301 (= v_1_T.control "CLOSED")))
 (let (($x1202 (= state_1 0)))
 (and $x1202 $x23301 $x98439 $x25217 $x25399 $x25222 $x25393 $x25395 $x23445 $x23446 $x23447 $x23448 $x23449 $x23450 $x23451 $x23452 $x23453 $x23454 $x23455 $x23456 $x23457 $x23458 $x23459 $x23460 $x23461 $x1729 $x23463 $x23464 $x23465 $x23466 $x23467 $x23468 $x23469 $x23470 $x23471 $x23472 $x23473 $x23474 $x24763 $x23476 $x23477 $x1593 $x23479 $x23480 $x23481 v_2_T.active_open $x23483 $x23484 $x23485 $x23486 $x23487 $x23488 $x23489 $x23490 $x23491 $x23492 $x23493 $x1594 $x1784 $x25200 $x25571 $x25572 $x24887 $x24781 $x23501 $x23502 $x23503 $x23504 $x23505 active_2_T.rtx active_2_T.user $x24886 $x23509 $x23510 $x25130 (= due_2_T.user (+ 1 v_1_T.user_timeout_ms)) $x23513)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x59035 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x59034 (= due_3_T.user due_2_T.user)))
 (let (($x59033 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x59031 (= due_3_L.query due_2_L.query)))
 (let (($x59030 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x59029 (= active_3_T.user active_2_T.user)))
 (let (($x59028 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x1681 (not active_3_L.query)))
 (let (($x59025 (= v_3_ip_pending_owner "none")))
 (let (($x59024 (= v_3_T.control v_2_T.control)))
 (let (($x59023 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x59022 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x59021 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x59020 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x59019 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x59018 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x59017 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x59016 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x59015 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x59014 (= v_3_T.take v_2_T.take)))
 (let (($x59013 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x59012 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x59011 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x59010 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x59009 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x59008 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x59007 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x59006 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x59005 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x59004 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x59003 (= v_3_T.retries v_2_T.retries)))
 (let (($x59002 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x59001 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x59000 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x58999 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x58998 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x58997 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x58996 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x58995 (= v_3_T.irs v_2_T.irs)))
 (let (($x58994 (= v_3_T.iss v_2_T.iss)))
 (let (($x58993 (= v_3_L.control "RESOLVED")))
 (let (($x58992 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x58991 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x58990 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x58989 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x58988 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x58987 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x58986 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x58985 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x1680 (= (as seq.empty (Seq (_ BitVec 8))) v_3_L.pending_packet)))
 (let (($x58983 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x58982 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x58981 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x58980 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x58979 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x58978 (= v_3_L.packet v_2_L.packet)))
 (let (($x58977 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x58976 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x58975 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x58974 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x58973 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x58972 (= v_3_L.payload v_2_L.payload)))
 (let (($x58971 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x58970 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x58969 (= 0 v_3_L.retry_count)))
 (let ((?x33281 (seq.unit (_ bv0 8))))
 (let ((?x98562 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.unit (_ bv2 8))))))))
 (let ((?x63059 (seq.unit (_ bv2 8))))
 (let ((?x98654 (seq.++ ?x63059 ?x98562)))
 (let (($x24936 (= v_3_L.peer_mac ?x98654)))
 (let (($x58967 (= 0 state_3)))
 (let (($x24886 (not active_2_T.time_wait)))
 (let (($x24943 (or $x24886 (not (<= due_2_T.time_wait 2)))))
 (let (($x25358 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x25471 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x1532 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x25478 (or (not active_2_L.query) (not (<= due_2_L.query 2)))))
 (let ((?x58924 (seq.len v_2_L.pending_packet)))
 (let (($x58925 (<= 28 ?x58924)))
 (let (($x58812 (= v_2_L.control "PENDING")))
 (let (($x24796 (= state_2 0)))
 (and $x24796 $x58812 $x58925 $x25478 $x1532 $x25471 $x25358 $x24943 $x58967 $x24936 $x58969 $x58970 $x58971 $x58972 $x58973 $x58974 $x58975 $x58976 $x58977 $x58978 $x58979 $x58980 $x58981 $x58982 $x58983 $x1680 $x58985 $x58986 $x58987 $x58988 $x58989 $x58990 $x58991 $x58992 $x58993 $x58994 $x58995 $x58996 $x58997 $x58998 $x58999 $x59000 $x59001 $x59002 $x59003 $x59004 $x59005 $x59006 $x59007 $x59008 $x59009 $x59010 $x59011 $x59012 $x59013 $x59014 $x59015 $x59016 $x59017 $x59018 $x59019 $x59020 $x59021 $x59022 $x59023 $x59024 $x59025 $x1681 active_3_L.cache $x59028 $x59029 $x59030 $x59031 (= due_3_L.cache (+ 2 v_2_L.cache_ttl_ms)) $x59033 $x59034 $x59035)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 18 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x93908 (seq.++ (seq.unit (_ bv128 8)) (seq.++ (seq.unit (_ bv255 8)) (seq.++ (seq.unit (_ bv7 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x33281 (seq.unit (_ bv0 8))))
 (let ((?x93909 (seq.++ ?x33281 ?x93908)))
 (= input_0_L.app.send_data ?x93909)))))
(assert
 (= 65 choice_1))
(assert
 (= 1 now_2))
(assert
 (= 29 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x30133 (seq.unit (_ bv192 8))))
(let ((?x97502 (seq.++ ?x30133 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x432 (seq.unit (_ bv1 8))))
(let ((?x33281 (seq.unit (_ bv0 8))))
(let ((?x93917 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x432 ?x97502)))))))
(let ((?x63059 (seq.unit (_ bv2 8))))
(let ((?x93922 (seq.++ ?x30133 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x63059 (seq.++ ?x63059 ?x93917)))))))
(let ((?x93927 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x63059 ?x93922)))))))
(let ((?x97486 (seq.unit (_ bv4 8))))
(let ((?x3144 (seq.unit (_ bv6 8))))
(let ((?x93932 (seq.++ ?x3144 (seq.++ ?x97486 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x63059 ?x93927)))))))
(let ((?x415 (seq.unit (_ bv8 8))))
(let ((?x93937 (seq.++ ?x3144 (seq.++ ?x33281 (seq.++ ?x432 (seq.++ ?x415 (seq.++ ?x33281 ?x93932)))))))
(let ((?x93942 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x63059 (seq.++ ?x415 ?x93937)))))))
(let ((?x93947 (seq.++ ?x33281 (seq.++ ?x33281 (seq.++ ?x432 (seq.++ ?x63059 (seq.++ ?x33281 ?x93942)))))))
(let ((?x93950 (seq.++ ?x63059 (seq.++ ?x33281 (seq.++ ?x33281 ?x93947)))))
(= input_2_L.net.frame_frame ?x93950))))))))))))))))))
(check-sat)

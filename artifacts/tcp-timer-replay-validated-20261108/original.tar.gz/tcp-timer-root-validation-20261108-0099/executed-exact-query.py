from pathlib import Path
import json,sys
R=Path(sys.argv[1]);sys.path.insert(0,str(R));P=Path('/home/blxu/protocol-flow');F=P/'candidates/tcp-owner-validation-20261107-0094';O=Path(sys.argv[2])
from protocol_lab.ir import load
from protocol_lab.symbolic import crosscheck_trace
m=load(F/'candidate-model.json');trace=json.loads((F/'cases/tcp-arp-failure-keeps-tcp/reference-trace.json').read_text());result=crosscheck_trace(m,trace,O);assert result['query']=='sat'and result['status']=='match';assert(F/'cases/tcp-arp-failure-keeps-tcp/symbolic/path.smt2').read_bytes()==(O/'path.smt2').read_bytes()

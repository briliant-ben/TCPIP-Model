from pathlib import Path
import ast,builtins,copy,hashlib,json,os,resource,struct,subprocess,sys,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-timer-root-validation-20261108-0099/owner-validation';O.mkdir(exist_ok=False);PRE=P/'candidates/tcp-owner-oracle-20261107-0092';W=P/'candidates/tcp-timer-root-validation-20261108-0099/workspace';G=P/'candidates/tcp-coupling-optimized-validation-20261107-0079'
resource.setrlimit(resource.RLIMIT_CPU,(240,240));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3));sys.path.insert(0,str(W))
from protocol_lab.ir import load,validate
from protocol_lab.flow import run_scenario,TraceContractMismatch
from protocol_lab.codegen import generate
from protocol_lab.codegen.execute import build,run,commands
from protocol_lab.symbolic import crosscheck_trace

def save(n,v):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,prototype_complete=False,**v))
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
try:
 status(status='running',stage='capability_check_and_freeze_without_subject_execution',started_at=time.time())
 approval=json.loads((PRE/'status.json').read_text());need(approval['status']=='oracle_proposal_ready_for_controller_freeze'and not approval['review']['blocking'],'oracle review not ready')
 trusted=ast.parse((P/'incoming/validate-tcp-coupling-0069.py').read_text());pure_node=next(n for n in trusted.body if isinstance(n,ast.FunctionDef)and n.name=='pure');env=dict(ast=ast,builtins=builtins,copy=copy,struct=struct,validate=validate,need=need);exec(compile(ast.Module(body=[pure_node],type_ignores=[]),'trusted-fixture-capability-gate','exec'),env);fn=env['pure'](PRE/'owner_oracle.py',True)['build_cases']
 names=['arp-endpoint','arp-udp-transmit','tcp-wire-endpoint'];old=[json.loads((W/('spec/'+n+'-oracle.json')).read_text())for n in names];before=copy.deepcopy(old);original=fn(*old);need(old==before,'oracle mutated source inputs');need(len(original['cases'])==4,'expected four independent cases');save('original-frozen-cases.json',original)
 # Profile contract already specifies two simultaneous timer transitions. Keep
 # original incomplete trace, correct its missing non-emitting retransmit row
 # using only the pre-existing independent TCP retransmission oracle.
 cases=copy.deepcopy(original['cases']);first=next(c for c in cases if c['id']=='tcp-arp-failure-keeps-tcp');step=next(s for s in first['steps']if s['at_ms']==1000);need(len(step['expect_trace'])==1,'unexpected original timer trace shape')
 tcp_tick=next(s for s in old[2]['cases']['syn-loss-retransmission']['steps']if s['at_ms']==1000);timer_rows=[dict(at_ms=r['at_ms'],emitted=[dict(message='T.'+e['message'],fields=copy.deepcopy(e['fields']))for e in r['emitted']if e['message']!='ipv4.tx'])for r in tcp_tick['expect_trace']];need(len(timer_rows)==1,'unexpected independent TCP timer rows');step['expect_trace'].extend(timer_rows)
 # A separate derived timing variant observes that pending TCP connect cannot
 # rearm the older UDP-started query. It is frozen before loading the subject.
 third=next(c for c in cases if c['id']=='udp-tcp-overwrite-arp-reply-flush-tcp-only');derived=copy.deepcopy(third);derived['id']='pending-tcp-connect-keeps-original-query-deadline';reply=derived['steps'].pop();need(reply['at_ms']==2,'unexpected original ARP reply time');reply['at_ms']=1002
 for row in reply['expect_trace']:row['at_ms']=1002
 derived['steps'].extend([dict(at_ms=1000,tick=True,expect_trace=[copy.deepcopy(first['steps'][1]['expect_trace'][0])]),dict(at_ms=1001,tick=True,expect_trace=[dict(at_ms=1001,emitted=copy.deepcopy(timer_rows[0]['emitted']))]),reply]);derived['expect']['timers']={'L.cache':61002,'T.rtx':3001,'T.user':30001};cases.append(derived);save('qualified-frozen-cases.json',dict(cases=cases,scope=original['scope']))
 save('freeze-receipt.json',dict(source_sha256=sha(PRE/'owner_oracle.py'),original_sha256=sha(O/'original-frozen-cases.json'),qualified_sha256=sha(O/'qualified-frozen-cases.json'),source_oracle_sha256={n:sha(W/('spec/'+n+'-oracle.json'))for n in names},subject_loaded_before_freeze=False,correction='Originalcase1 omitted non-emitting T.rtx trace row at1000; supplied contract already requires L.query then T.rtx. Derivedrow comes from independently frozen originalTCP retransmission projection, not candidate observations. Extra fifthcase exposes query-rearm bug by postponingARPreply. Original four raw oracle cases retained unchanged.'))
 status(status='running',stage='fresh_generate_and_compile')
 M=O/'candidate-model.json';M.write_bytes((G/'validation-0001/candidate-model.json').read_bytes());m=load(M);generate(M,O/'generated');comp=build(O/'generated',O/'build');need(comp['status']=='pass','native compile failed');results=[]
 for case in cases:
  status(status='running',stage='reference_native_fixedZ3',case=case['id'],completed=len(results));folder=O/'cases'/case['id'];save('cases/'+case['id']+'/scenario.json',case);ref=run_scenario(m,case);save('cases/'+case['id']+'/reference-trace.json',ref.trace);native=run(O/'generated',O/'build',folder/'scenario.json',folder/'native');need(native['status']=='pass','native mismatch');formal=crosscheck_trace(m,ref.trace,folder/'symbolic');need(formal['status']=='match'and formal['query']=='sat','fixed input unresolved/mismatch');results.append(dict(id=case['id'],transitions=len(ref.trace),native='pass',fixed_Z3='sat_replay_match'));save('results.json',results)
 status(status='running',stage='actual_valid_model_fault_probes')
 faults=[]
 # Positive oracle can reject a protocol leak while declared invariants pass.
 leak=copy.deepcopy(m);udp=next(t for t in leak['transitions']if t['id']=='L.QUERY-FAIL-QUEUED-UDP');emit=next(copy.deepcopy(a)for a in udp['actions']if a.get('emit',{}).get('message')=='L.udp.send_failed');tcp=next(t for t in leak['transitions']if t['id']=='L.QUERY-FAIL-QUEUED-TCP');tcp['actions'].append(emit)
 def nodes(x):
  if isinstance(x,dict):
   yield x
   for v in x.values():yield from nodes(v)
  elif isinstance(x,list):
   for v in x:yield from nodes(v)
 rearm=copy.deepcopy(m);target=[t for t in rearm['transitions']if t['event']=='T.app.connect'and any(n=={'op':'eq','args':[{'var':'L.control'},'PENDING']}for n in nodes(t['guard']))];need(len(target)==1,'pendingconnect target not unique');target[0]['actions'].append({'arm':{'timer':'L.query','delay_ms':1000}})
 clear=copy.deepcopy(m);changed=0
 for t in clear['transitions']:
  if t['event']!='T.app.abort':continue
  for a in t['actions']:
   s=a.get('set',{});value=s.get('value')
   if s.get('var')in ['L.pending_packet','ip_pending_owner']and isinstance(value,dict)and value.get('op')=='ite':s['value']={'bytes':[]}if s['var']=='L.pending_packet'else'none';changed+=1
 need(changed>0,'abort conditional clear missing')
 for name,mutant,case in [('UDP-notification-leak',leak,cases[0]),('pending-query-rearm',rearm,derived),('abort-clears-UDP',clear,cases[3])]:
  validate(mutant)
  try:run_scenario(mutant,case)
  except TraceContractMismatch as e:faults.append(dict(id=name,status='literal_trace_oracle_rejects',error_type=type(e).__name__,invariant_failure_before_trace_mismatch=False))
  else:raise ValueError('fault not rejected by frozen trace: '+name)
 save('fault-results.json',faults)
 status(status='finite_owner_interaction_gate_pass_controller_review_required',stage='finished',cases=len(results),transitions=sum(r['transitions']for r in results),faults=len(faults),all_input_safety='not_claimed',live_network=False,finished_at=time.time())
except Exception as e:
 status(status='candidate_or_controller_rejected',stage='stopped',error_type=type(e).__name__,error=str(e),automatic_solver_retry=False,finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

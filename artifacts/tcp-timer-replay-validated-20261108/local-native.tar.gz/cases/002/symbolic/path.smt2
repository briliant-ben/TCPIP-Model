; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x480 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x62996 (= due_1_T.user 30000)))
 (let (($x62995 (= due_1_T.rtx 1000)))
 (let (($x476 (= due_1_L.cache due_0_L.cache)))
 (let (($x62994 (= due_1_L.query 1000)))
 (let (($x62993 (not active_1_T.time_wait)))
 (let (($x473 (= active_1_L.cache active_0_L.cache)))
 (let (($x471 (= v_1_ip_pending_owner "TCP")))
 (let (($x470 (= v_1_T.control "SYN-SENT")))
 (let (($x62992 (= v_1_T.wire_flags 2)))
 (let ((?x62900 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2314 (seq.unit (_ bv16 8))))
 (let ((?x3007 (seq.unit (_ bv0 8))))
 (let ((?x32589 (seq.unit (_ bv2 8))))
 (let ((?x64423 (seq.unit (_ bv80 8))))
 (let ((?x62905 (seq.++ ?x3007 (seq.++ ?x64423 (seq.++ ?x32589 (seq.++ ?x3007 (seq.++ ?x2314 ?x62900)))))))
 (let ((?x30980 (seq.unit (_ bv232 8))))
 (let ((?x30978 (seq.unit (_ bv3 8))))
 (let ((?x62910 (seq.++ ?x30978 (seq.++ ?x30980 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 ?x62905)))))))
 (let ((?x31009 (seq.unit (_ bv144 8))))
 (let ((?x31008 (seq.unit (_ bv31 8))))
 (let ((?x2727 (seq.unit (_ bv64 8))))
 (let ((?x62915 (seq.++ ?x2727 (seq.++ ?x31008 (seq.++ ?x31009 (seq.++ ?x3007 (seq.++ ?x3007 ?x62910)))))))
 (let ((?x31010 (seq.unit (_ bv156 8))))
 (let ((?x62916 (seq.++ ?x31010 ?x62915)))
 (let ((?x63344 (seq.unit (_ bv192 8))))
 (let ((?x282 (seq.unit (_ bv1 8))))
 (let ((?x62957 (seq.++ ?x282 (seq.++ ?x63344 (seq.++ ?x3007 (seq.++ ?x32589 (seq.++ ?x32589 ?x62916)))))))
 (let ((?x62961 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x63344 (seq.++ ?x3007 (seq.++ ?x32589 ?x62957))))))
 (let ((?x50 (seq.unit (_ bv6 8))))
 (let ((?x62965 (seq.++ ?x3007 (seq.++ ?x2727 (seq.++ ?x50 (seq.++ (seq.unit (_ bv182 8)) ?x62961))))))
 (let ((?x31297 (seq.unit (_ bv40 8))))
 (let ((?x62970 (seq.++ ?x3007 (seq.++ ?x31297 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x2727 ?x62965)))))))
 (let ((?x1212 (seq.unit (_ bv69 8))))
 (let ((?x62972 (seq.++ ?x1212 (seq.++ ?x3007 ?x62970))))
 (let (($x62991 (= v_1_T.wire_packet ?x62972)))
 (let ((?x3436 (seq.++ ?x32589 (seq.++ ?x282 (seq.++ ?x63344 (seq.++ ?x3007 (seq.++ ?x32589 ?x32589)))))))
 (let ((?x3035 (seq.++ ?x50 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x63344 (seq.++ ?x3007 ?x3436)))))))
 (let ((?x34366 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x2727 (seq.++ ?x3007 (seq.++ ?x2727 ?x3035)))))))
 (let (($x62990 (= v_1_T.wire_ip_zero (seq.++ ?x1212 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x31297 ?x34366)))))))
 (let (($x62989 (= v_1_T.wire_tcp ?x62916)))
 (let ((?x30851 (seq.++ ?x32589 (seq.++ ?x3007 (seq.++ ?x50 (seq.++ ?x3007 (seq.unit (_ bv20 8))))))))
 (let ((?x2322 (seq.++ ?x32589 (seq.++ ?x282 (seq.++ ?x63344 (seq.++ ?x3007 (seq.++ ?x32589 ?x30851)))))))
 (let (($x62988 (= v_1_T.wire_pseudo (seq.++ ?x63344 (seq.++ ?x3007 ?x2322)))))
 (let ((?x2476 (seq.++ ?x3007 (seq.++ ?x2314 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 ?x3007)))))))
 (let ((?x2481 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x64423 (seq.++ ?x32589 ?x2476)))))))
 (let ((?x2486 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x30978 (seq.++ ?x30980 (seq.++ ?x3007 ?x2481)))))))
 (let (($x62987 (= v_1_T.wire_tcp_zero (seq.++ ?x31010 (seq.++ ?x2727 (seq.++ ?x31008 (seq.++ ?x31009 ?x2486)))))))
 (let (($x62986 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x62985 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x30946 (= v_1_T.take 0)))
 (let (($x30947 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x30948 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x30949 (= v_1_T.snd_wnd 8)))
 (let (($x62984 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x62983 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x62982 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x31193 (= v_1_T.local_window 16)))
 (let (($x31194 (= v_1_T.msl_ms 60000)))
 (let (($x31195 (= v_1_T.user_timeout_ms 30000)))
 (let (($x448 (= 0 v_1_T.retries)))
 (let (($x409 (= 1000 v_1_T.rto_ms)))
 (let (($x438 (= v_1_T.tx_flags "S")))
 (let (($x31198 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x31199 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x31200 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x62981 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x31202 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x31203 (= v_1_T.irs (_ bv0 32))))
 (let (($x31149 (= v_1_T.iss (_ bv1000 32))))
 (let (($x3225 (= v_1_L.control "PENDING")))
 (let (($x62978 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x62977 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x62976 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x62975 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x62974 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x28462 (not v_1_L.rxudp_require_checksum)))
 (let (($x62973 (= v_1_L.pending_packet ?x62972)))
 (let (($x31169 (= v_1_L.ip_checksum 0)))
 (let (($x31170 (= v_1_L.udp_checksum 0)))
 (let (($x2148 (= v_1_L.udp_raw_checksum 0)))
 (let (($x2149 (= v_1_L.ip_length 0)))
 (let (($x2157 (= v_1_L.udp_length 0)))
 (let (($x31299 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x31207 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x31206 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x31204 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x2319 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x2318 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x31256 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x2451 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x3078 (= 0 v_1_L.retry_count)))
 (let (($x31255 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x3450 (= 0 state_1)))
 (let (($x64585 (not active_0_T.time_wait)))
 (let (($x31277 (or $x64585 (not (<= due_0_T.time_wait 0)))))
 (let (($x64701 (not active_0_T.user)))
 (let (($x31274 (or $x64701 (not (<= due_0_T.user 0)))))
 (let (($x64586 (not active_0_T.rtx)))
 (let (($x31271 (or $x64586 (not (<= due_0_T.rtx 0)))))
 (let (($x64698 (not active_0_L.cache)))
 (let (($x31252 (or $x64698 (not (<= due_0_L.cache 0)))))
 (let (($x65217 (not active_0_L.query)))
 (let (($x2346 (or $x65217 (not (<= due_0_L.query 0)))))
 (let (($x94833 (= state_0 0)))
 (and $x94833 (>= 0 now_0) $x2346 $x31252 $x31271 $x31274 $x31277 $x3450 $x31255 $x3078 $x2451 v_1_L.checksums_enabled $x31256 $x2318 $x2319 $x31204 $x31206 $x31207 $x31299 $x2157 $x2149 $x2148 $x31170 $x31169 $x62973 $x28462 $x62974 (= v_1_L.rxudp_disposition "none") $x62975 $x62976 $x62977 $x62978 (= v_1_L.echo_disposition "none") $x3225 $x31149 $x31203 $x31202 $x62981 $x31200 $x31199 $x31198 $x438 $x409 $x448 v_1_T.active_open $x31195 $x31194 $x31193 $x62982 $x62983 $x62984 $x30949 $x30948 $x30947 $x30946 $x62985 $x62986 $x62987 $x62988 $x62989 $x62990 $x62991 $x62992 (= v_1_T.wire_disposition "none") $x470 $x471 active_1_L.query $x473 active_1_T.rtx active_1_T.user $x62993 $x62994 $x476 $x62995 $x62996 $x480)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x28327 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x28326 (= due_2_T.user due_1_T.user)))
 (let (($x28325 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x28323 (= due_2_L.query due_1_L.query)))
 (let (($x28322 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x28321 (= active_2_T.user active_1_T.user)))
 (let (($x28320 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x62726 (not active_2_L.query)))
 (let (($x28317 (= v_2_ip_pending_owner "none")))
 (let (($x28316 (= v_2_T.control v_1_T.control)))
 (let (($x28315 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x28314 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x28313 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x28312 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x28311 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x28310 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x28309 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x28308 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x28307 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x28306 (= v_2_T.take v_1_T.take)))
 (let (($x28305 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x28304 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x28303 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x28302 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x28301 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x28300 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x28299 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x28298 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x28297 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x28296 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x28295 (= v_2_T.retries v_1_T.retries)))
 (let (($x28294 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x28293 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x28292 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x28291 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x28290 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x28289 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x28288 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x28287 (= v_2_T.irs v_1_T.irs)))
 (let (($x28286 (= v_2_T.iss v_1_T.iss)))
 (let (($x28285 (= v_2_L.control "RESOLVED")))
 (let (($x28284 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x28283 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x28282 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x28281 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x28280 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x28279 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x28278 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x28277 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x62725 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x28275 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x28274 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x28273 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x28272 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x28271 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x28270 (= v_2_L.packet v_1_L.packet)))
 (let (($x28269 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x28268 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x28267 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x28266 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x28265 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x28264 (= v_2_L.payload v_1_L.payload)))
 (let (($x28263 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x28262 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x28261 (= 0 v_2_L.retry_count)))
 (let ((?x3007 (seq.unit (_ bv0 8))))
 (let ((?x649 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.unit (_ bv2 8))))))))
 (let ((?x32589 (seq.unit (_ bv2 8))))
 (let ((?x650 (seq.++ ?x32589 ?x649)))
 (let (($x62724 (= v_2_L.peer_mac ?x650)))
 (let (($x28259 (= 0 state_2)))
 (let (($x62993 (not active_1_T.time_wait)))
 (let (($x62723 (or $x62993 (not (<= due_1_T.time_wait 10)))))
 (let (($x62720 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x62716 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x62894 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x62818 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x28216 (seq.len v_1_L.pending_packet)))
 (let (($x28217 (<= 28 ?x28216)))
 (let (($x3225 (= v_1_L.control "PENDING")))
 (let (($x2146 (= state_1 0)))
 (and $x2146 $x3225 $x28217 $x62818 $x62894 $x62716 $x62720 $x62723 $x28259 $x62724 $x28261 $x28262 $x28263 $x28264 $x28265 $x28266 $x28267 $x28268 $x28269 $x28270 $x28271 $x28272 $x28273 $x28274 $x28275 $x62725 $x28277 $x28278 $x28279 $x28280 $x28281 $x28282 $x28283 $x28284 $x28285 $x28286 $x28287 $x28288 $x28289 $x28290 $x28291 $x28292 $x28293 $x28294 $x28295 $x28296 $x28297 $x28298 $x28299 $x28300 $x28301 $x28302 $x28303 $x28304 $x28305 $x28306 $x28307 $x28308 $x28309 $x28310 $x28311 $x28312 $x28313 $x28314 $x28315 $x28316 $x28317 $x62726 active_2_L.cache $x28320 $x28321 $x28322 $x28323 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x28325 $x28326 $x28327)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x63344 (seq.unit (_ bv192 8))))
(let ((?x64871 (seq.++ ?x63344 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x282 (seq.unit (_ bv1 8))))
(let ((?x3007 (seq.unit (_ bv0 8))))
(let ((?x62652 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x282 ?x64871)))))))
(let ((?x32589 (seq.unit (_ bv2 8))))
(let ((?x62657 (seq.++ ?x63344 (seq.++ ?x3007 (seq.++ ?x32589 (seq.++ ?x32589 (seq.++ ?x32589 ?x62652)))))))
(let ((?x62662 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x32589 ?x62657)))))))
(let ((?x252 (seq.unit (_ bv4 8))))
(let ((?x50 (seq.unit (_ bv6 8))))
(let ((?x62667 (seq.++ ?x50 (seq.++ ?x252 (seq.++ ?x3007 (seq.++ ?x32589 (seq.++ ?x32589 ?x62662)))))))
(let ((?x2708 (seq.unit (_ bv8 8))))
(let ((?x62672 (seq.++ ?x50 (seq.++ ?x3007 (seq.++ ?x282 (seq.++ ?x2708 (seq.++ ?x3007 ?x62667)))))))
(let ((?x62677 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x32589 (seq.++ ?x2708 ?x62672)))))))
(let ((?x62682 (seq.++ ?x3007 (seq.++ ?x3007 (seq.++ ?x282 (seq.++ ?x32589 (seq.++ ?x3007 ?x62677)))))))
(let ((?x62685 (seq.++ ?x32589 (seq.++ ?x3007 (seq.++ ?x3007 ?x62682)))))
(= input_1_L.net.frame_frame ?x62685))))))))))))))))))
(check-sat)

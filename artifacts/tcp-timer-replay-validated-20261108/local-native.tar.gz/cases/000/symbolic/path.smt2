; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x1340 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x63694 (= due_1_T.user 30000)))
 (let (($x63693 (= due_1_T.rtx 1000)))
 (let (($x1337 (= due_1_L.cache due_0_L.cache)))
 (let (($x63692 (= due_1_L.query 1000)))
 (let (($x63691 (not active_1_T.time_wait)))
 (let (($x1332 (= active_1_L.cache active_0_L.cache)))
 (let (($x1330 (= v_1_ip_pending_owner "TCP")))
 (let (($x1329 (= v_1_T.control "SYN-SENT")))
 (let (($x63690 (= v_1_T.wire_flags 2)))
 (let ((?x63598 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x2690 (seq.unit (_ bv16 8))))
 (let ((?x442 (seq.unit (_ bv0 8))))
 (let ((?x444 (seq.unit (_ bv2 8))))
 (let ((?x1139 (seq.unit (_ bv80 8))))
 (let ((?x63603 (seq.++ ?x442 (seq.++ ?x1139 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x2690 ?x63598)))))))
 (let ((?x2758 (seq.unit (_ bv232 8))))
 (let ((?x2756 (seq.unit (_ bv3 8))))
 (let ((?x63608 (seq.++ ?x2756 (seq.++ ?x2758 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x63603)))))))
 (let ((?x744 (seq.unit (_ bv144 8))))
 (let ((?x742 (seq.unit (_ bv31 8))))
 (let ((?x732 (seq.unit (_ bv64 8))))
 (let ((?x63613 (seq.++ ?x732 (seq.++ ?x742 (seq.++ ?x744 (seq.++ ?x442 (seq.++ ?x442 ?x63608)))))))
 (let ((?x746 (seq.unit (_ bv156 8))))
 (let ((?x63614 (seq.++ ?x746 ?x63613)))
 (let ((?x440 (seq.unit (_ bv192 8))))
 (let ((?x514 (seq.unit (_ bv1 8))))
 (let ((?x63655 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 (seq.++ ?x444 ?x63614)))))))
 (let ((?x63659 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x63655))))))
 (let ((?x540 (seq.unit (_ bv6 8))))
 (let ((?x63663 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x540 (seq.++ (seq.unit (_ bv182 8)) ?x63659))))))
 (let ((?x2719 (seq.unit (_ bv40 8))))
 (let ((?x63668 (seq.++ ?x442 (seq.++ ?x2719 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x732 ?x63663)))))))
 (let ((?x726 (seq.unit (_ bv69 8))))
 (let ((?x63670 (seq.++ ?x726 (seq.++ ?x442 ?x63668))))
 (let (($x63689 (= v_1_T.wire_packet ?x63670)))
 (let ((?x1202 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x444)))))))
 (let ((?x1207 (seq.++ ?x540 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x440 (seq.++ ?x442 ?x1202)))))))
 (let ((?x1212 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x732 (seq.++ ?x442 (seq.++ ?x732 ?x1207)))))))
 (let (($x63688 (= v_1_T.wire_ip_zero (seq.++ ?x726 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x2719 ?x1212)))))))
 (let (($x63687 (= v_1_T.wire_tcp ?x63614)))
 (let ((?x3590 (seq.++ ?x444 (seq.++ ?x442 (seq.++ ?x540 (seq.++ ?x442 (seq.unit (_ bv20 8))))))))
 (let ((?x3595 (seq.++ ?x444 (seq.++ ?x514 (seq.++ ?x440 (seq.++ ?x442 (seq.++ ?x444 ?x3590)))))))
 (let (($x63686 (= v_1_T.wire_pseudo (seq.++ ?x440 (seq.++ ?x442 ?x3595)))))
 (let ((?x3176 (seq.++ ?x442 (seq.++ ?x2690 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 ?x442)))))))
 (let ((?x3276 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x1139 (seq.++ ?x444 ?x3176)))))))
 (let ((?x3036 (seq.++ ?x442 (seq.++ ?x442 (seq.++ ?x2756 (seq.++ ?x2758 (seq.++ ?x442 ?x3276)))))))
 (let (($x63685 (= v_1_T.wire_tcp_zero (seq.++ ?x746 (seq.++ ?x732 (seq.++ ?x742 (seq.++ ?x744 ?x3036)))))))
 (let (($x63684 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x63683 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x3053 (= v_1_T.take 0)))
 (let (($x3598 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x3599 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x3129 (= v_1_T.snd_wnd 8)))
 (let (($x63682 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x63681 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x63680 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x3133 (= v_1_T.local_window 16)))
 (let (($x3134 (= v_1_T.msl_ms 60000)))
 (let (($x3135 (= v_1_T.user_timeout_ms 30000)))
 (let (($x1308 (= 0 v_1_T.retries)))
 (let (($x1307 (= 1000 v_1_T.rto_ms)))
 (let (($x1306 (= v_1_T.tx_flags "S")))
 (let (($x3302 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x3303 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x3304 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x63679 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x3306 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x3307 (= v_1_T.irs (_ bv0 32))))
 (let (($x3308 (= v_1_T.iss (_ bv1000 32))))
 (let (($x1298 (= v_1_L.control "PENDING")))
 (let (($x63676 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x63675 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x63674 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x63673 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x63672 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x32872 (not v_1_L.rxudp_require_checksum)))
 (let (($x63671 (= v_1_L.pending_packet ?x63670)))
 (let (($x3263 (= v_1_L.ip_checksum 0)))
 (let (($x3264 (= v_1_L.udp_checksum 0)))
 (let (($x3265 (= v_1_L.udp_raw_checksum 0)))
 (let (($x3266 (= v_1_L.ip_length 0)))
 (let (($x3267 (= v_1_L.udp_length 0)))
 (let (($x2716 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x2713 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x2715 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x2698 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x2697 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x3059 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x3110 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x353 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x1274 (= 0 v_1_L.retry_count)))
 (let (($x3109 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x1272 (= 0 state_1)))
 (let (($x407 (not active_0_T.time_wait)))
 (let (($x3085 (or $x407 (not (<= due_0_T.time_wait 0)))))
 (let (($x405 (not active_0_T.user)))
 (let (($x3066 (or $x405 (not (<= due_0_T.user 0)))))
 (let (($x403 (not active_0_T.rtx)))
 (let (($x3120 (or $x403 (not (<= due_0_T.rtx 0)))))
 (let (($x401 (not active_0_L.cache)))
 (let (($x3117 (or $x401 (not (<= due_0_L.cache 0)))))
 (let (($x399 (not active_0_L.query)))
 (let (($x3063 (or $x399 (not (<= due_0_L.query 0)))))
 (let (($x216 (= state_0 0)))
 (and $x216 (>= 0 now_0) $x3063 $x3117 $x3120 $x3066 $x3085 $x1272 $x3109 $x1274 $x353 v_1_L.checksums_enabled $x3110 $x3059 $x2697 $x2698 $x2715 $x2713 $x2716 $x3267 $x3266 $x3265 $x3264 $x3263 $x63671 $x32872 $x63672 (= v_1_L.rxudp_disposition "none") $x63673 $x63674 $x63675 $x63676 (= v_1_L.echo_disposition "none") $x1298 $x3308 $x3307 $x3306 $x63679 $x3304 $x3303 $x3302 $x1306 $x1307 $x1308 v_1_T.active_open $x3135 $x3134 $x3133 $x63680 $x63681 $x63682 $x3129 $x3599 $x3598 $x3053 $x63683 $x63684 $x63685 $x63686 $x63687 $x63688 $x63689 $x63690 (= v_1_T.wire_disposition "none") $x1329 $x1330 active_1_L.query $x1332 active_1_T.rtx active_1_T.user $x63691 $x63692 $x1337 $x63693 $x63694 $x1340)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x33736 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x33735 (= due_2_T.user due_1_T.user)))
 (let (($x33734 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x33733 (= due_2_L.cache due_1_L.cache)))
 (let (($x33732 (= due_2_L.query due_1_L.query)))
 (let (($x3465 (not active_2_T.time_wait)))
 (let (($x3464 (not active_2_T.user)))
 (let (($x3461 (not active_2_T.rtx)))
 (let (($x33728 (= active_2_L.cache active_1_L.cache)))
 (let (($x33727 (= active_2_L.query active_1_L.query)))
 (let (($x33726 (= v_2_ip_pending_owner (ite (= v_1_ip_pending_owner "TCP") "none" v_1_ip_pending_owner))))
 (let (($x33725 (= v_2_T.control "CLOSED")))
 (let (($x33724 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x33723 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x33722 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x33721 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x33720 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x33719 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x33718 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x33717 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x33716 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x33715 (= v_2_T.take v_1_T.take)))
 (let (($x33714 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x33713 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x33712 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x33711 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x33710 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x33709 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x33708 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x33707 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x33706 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x33705 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x33704 (= v_2_T.retries v_1_T.retries)))
 (let (($x33703 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x33702 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x33701 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x33700 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x33699 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x33698 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x33697 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x33696 (= v_2_T.irs v_1_T.irs)))
 (let (($x33695 (= v_2_T.iss v_1_T.iss)))
 (let (($x33694 (= v_2_L.control v_1_L.control)))
 (let (($x33693 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x33692 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x33691 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x33690 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x33689 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x33688 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x33687 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x33686 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x1330 (= v_1_ip_pending_owner "TCP")))
 (let (($x33685 (= v_2_L.pending_packet (ite $x1330 (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet))))
 (let (($x33684 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x33683 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x33682 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x33681 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x33680 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x33679 (= v_2_L.packet v_1_L.packet)))
 (let (($x33678 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x33677 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x33676 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x33675 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x33674 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x33673 (= v_2_L.payload v_1_L.payload)))
 (let (($x33672 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x33671 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x33670 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x33669 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x33668 (= 0 state_2)))
 (let (($x63691 (not active_1_T.time_wait)))
 (let (($x3458 (or $x63691 (not (<= due_1_T.time_wait 5)))))
 (let (($x3457 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x3463 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x3423 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x2686 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x1329 (= v_1_T.control "SYN-SENT")))
 (let (($x2684 (= state_1 0)))
 (and $x2684 $x1329 $x2686 $x3423 $x3463 $x3457 $x3458 $x33668 $x33669 $x33670 $x33671 $x33672 $x33673 $x33674 $x33675 $x33676 $x33677 $x33678 $x33679 $x33680 $x33681 $x33682 $x33683 $x33684 $x33685 $x33686 $x33687 $x33688 $x33689 $x33690 $x33691 $x33692 $x33693 $x33694 $x33695 $x33696 $x33697 $x33698 $x33699 $x33700 $x33701 $x33702 $x33703 $x33704 $x33705 $x33706 $x33707 $x33708 $x33709 $x33710 $x33711 $x33712 $x33713 $x33714 $x33715 $x33716 $x33717 $x33718 $x33719 $x33720 $x33721 $x33722 $x33723 $x33724 $x33725 $x33726 $x33727 $x33728 $x3461 $x3464 $x3465 $x33732 $x33733 $x33734 $x33735 $x33736))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 174 choice_1))
(assert
 (= 5 now_2))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!1
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!1
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!1
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x3054 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x63355 (= due_1_T.user due_0_T.user)))
 (let (($x63354 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x3635 (= due_1_L.cache due_0_L.cache)))
 (let (($x34491 (= due_1_L.query 1000)))
 (let (($x63348 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x2970 (= active_1_T.user active_0_T.user)))
 (let (($x2969 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x3310 (= active_1_L.cache active_0_L.cache)))
 (let (($x31375 (= v_1_T.control "CLOSED")))
 (let (($x64639 (= v_1_T.wire_flags 0)))
 (let (($x34488 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x34485 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x34484 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x34483 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x34480 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x34481 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x34477 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x64417 (= v_1_T.take 0)))
 (let (($x64582 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x64583 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x64584 (= v_1_T.snd_wnd 8)))
 (let (($x34476 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x34475 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x34472 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x64588 (= v_1_T.local_window 16)))
 (let (($x64589 (= v_1_T.msl_ms 60000)))
 (let (($x64590 (= v_1_T.user_timeout_ms 30000)))
 (let (($x64591 (= v_1_T.retries 0)))
 (let (($x64592 (= v_1_T.rto_ms 1000)))
 (let (($x64594 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x64595 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x64596 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x64597 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x64691 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x64692 (= v_1_T.irs (_ bv0 32))))
 (let (($x64693 (= v_1_T.iss (_ bv1000 32))))
 (let (($x2973 (= v_1_L.control "PENDING")))
 (let (($x34471 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x34470 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x34469 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x34468 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x34463 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x31205 (not v_1_L.rxudp_require_checksum)))
 (let (($x34462 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x64703 (= v_1_L.ip_checksum 0)))
 (let (($x64705 (= v_1_L.udp_checksum 0)))
 (let (($x64706 (= v_1_L.udp_raw_checksum 0)))
 (let (($x64707 (= v_1_L.ip_length 0)))
 (let (($x64708 (= v_1_L.udp_length 0)))
 (let (($x34457 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x34456 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x34455 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x34454 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x34451 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x34450 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x2550 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x64740 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x63687 (= 0 v_1_L.retry_count)))
 (let (($x2549 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x63685 (= 0 state_1)))
 (let (($x131 (not active_0_T.time_wait)))
 (let (($x2548 (or $x131 (not (<= due_0_T.time_wait 0)))))
 (let (($x33722 (not active_0_T.user)))
 (let (($x2545 (or $x33722 (not (<= due_0_T.user 0)))))
 (let (($x200 (not active_0_T.rtx)))
 (let (($x2542 (or $x200 (not (<= due_0_T.rtx 0)))))
 (let (($x129 (not active_0_L.cache)))
 (let (($x2541 (or $x129 (not (<= due_0_L.cache 0)))))
 (let (($x33720 (not active_0_L.query)))
 (let (($x125 (or $x33720 (not (<= due_0_L.query 0)))))
 (let (($x141 (= state_0 0)))
 (and $x141 (>= 0 now_0) $x125 $x2541 $x2542 $x2545 $x2548 $x63685 $x2549 $x63687 $x64740 v_1_L.checksums_enabled $x2550 $x34450 $x34451 $x34454 $x34455 $x34456 $x34457 $x64708 $x64707 $x64706 $x64705 $x64703 $x34462 $x31205 $x34463 (= v_1_L.rxudp_disposition "none") $x34468 $x34469 $x34470 $x34471 (= v_1_L.echo_disposition "none") $x2973 $x64693 $x64692 $x64691 $x64597 $x64596 $x64595 $x64594 (= v_1_T.tx_flags "S") $x64592 $x64591 v_1_T.active_open $x64590 $x64589 $x64588 $x34472 $x34475 $x34476 $x64584 $x64583 $x64582 $x64417 $x34477 $x34481 $x34480 $x34483 $x34484 $x34485 $x34488 $x64639 (= v_1_T.wire_disposition "none") $x31375 (= v_1_ip_pending_owner "none") active_1_L.query $x3310 $x2969 $x2970 $x63348 $x34491 $x3635 $x63354 $x63355 $x3054))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x31073 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x31072 (= due_2_T.user due_1_T.user)))
 (let (($x31071 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x31069 (= due_2_L.query due_1_L.query)))
 (let (($x31068 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x31067 (= active_2_T.user active_1_T.user)))
 (let (($x31066 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x65217 (not active_2_L.query)))
 (let (($x31063 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x31062 (= v_2_T.control v_1_T.control)))
 (let (($x31061 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x31060 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x31059 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x31058 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x31057 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x31056 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x31055 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x31054 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x31053 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x31052 (= v_2_T.take v_1_T.take)))
 (let (($x31051 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x31050 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x31049 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x31048 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x31047 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x31046 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x31045 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x31044 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x31043 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x31042 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x31041 (= v_2_T.retries v_1_T.retries)))
 (let (($x31040 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x31039 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x31038 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x31037 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x31036 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x31035 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x31034 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x31033 (= v_2_T.irs v_1_T.irs)))
 (let (($x31032 (= v_2_T.iss v_1_T.iss)))
 (let (($x31031 (= v_2_L.control "RESOLVED")))
 (let (($x31030 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x31029 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x31028 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x31027 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x31026 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x31025 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x31024 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x31023 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x31022 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x31021 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x31020 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x31019 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x31018 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x31017 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x31016 (= v_2_L.packet v_1_L.packet)))
 (let (($x31015 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x31014 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x31013 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x31012 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x31011 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x31010 (= v_2_L.payload v_1_L.payload)))
 (let (($x31009 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x31008 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x31007 (= 0 v_2_L.retry_count)))
 (let ((?x6 (seq.unit (_ bv0 8))))
 (let ((?x1374 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.unit (_ bv2 8))))))))
 (let ((?x65 (seq.unit (_ bv2 8))))
 (let ((?x1375 (seq.++ ?x65 ?x1374)))
 (let (($x65215 (= v_2_L.peer_mac ?x1375)))
 (let (($x31005 (= 0 state_2)))
 (let (($x65214 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x65210 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x65245 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x64982 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x64664 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x30974 (seq.len v_1_L.pending_packet)))
 (let (($x30984 (= 0 ?x30974)))
 (let (($x2973 (= v_1_L.control "PENDING")))
 (let (($x2537 (= state_1 0)))
 (and $x2537 $x2973 $x30984 $x64664 $x64982 $x65245 $x65210 $x65214 $x31005 $x65215 $x31007 $x31008 $x31009 $x31010 $x31011 $x31012 $x31013 $x31014 $x31015 $x31016 $x31017 $x31018 $x31019 $x31020 $x31021 $x31022 $x31023 $x31024 $x31025 $x31026 $x31027 $x31028 $x31029 $x31030 $x31031 $x31032 $x31033 $x31034 $x31035 $x31036 $x31037 $x31038 $x31039 $x31040 $x31041 $x31042 $x31043 $x31044 $x31045 $x31046 $x31047 $x31048 $x31049 $x31050 $x31051 $x31052 $x31053 $x31054 $x31055 $x31056 $x31057 $x31058 $x31059 $x31060 $x31061 $x31062 $x31063 $x65217 active_2_L.cache $x31066 $x31067 $x31068 $x31069 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x31071 $x31072 $x31073))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x63472 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x64990 (= due_3_T.rtx 1020)))
 (let (($x63469 (= due_3_L.cache due_2_L.cache)))
 (let (($x63468 (= due_3_L.query due_2_L.query)))
 (let (($x64864 (not active_3_T.time_wait)))
 (let (($x63464 (= active_3_L.cache active_2_L.cache)))
 (let (($x63463 (= active_3_L.query active_2_L.query)))
 (let (($x63462 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x63461 (= v_3_T.control "SYN-SENT")))
 (let (($x2999 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x65080 (= v_3_T.wire_flags 2)))
 (let ((?x6 (seq.unit (_ bv0 8))))
 (let ((?x63675 (seq.++ ?x6 ?x6)))
 (let ((?x3309 (seq.++ ?x6 (seq.++ ?x6 ?x63675))))
 (let ((?x63449 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x63447 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x65 (seq.unit (_ bv2 8))))
 (let ((?x63439 (seq.unit (_ bv80 8))))
 (let ((?x65181 (seq.++ ?x6 (seq.++ ?x63439 (seq.++ ?x65 (seq.++ ?x63447 (seq.++ ?x63449 ?x3309)))))))
 (let ((?x64418 (seq.unit ((_ extract 7 0) v_2_T.iss))))
 (let ((?x64624 (seq.unit ((_ extract 15 8) v_2_T.iss))))
 (let ((?x64873 (seq.++ ?x64624 (seq.++ ?x64418 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 ?x65181)))))))
 (let ((?x64442 (seq.unit ((_ extract 23 16) v_2_T.iss))))
 (let ((?x64473 (seq.unit ((_ extract 31 24) v_2_T.iss))))
 (let ((?x600 (seq.unit (_ bv144 8))))
 (let ((?x598 (seq.unit (_ bv31 8))))
 (let ((?x588 (seq.unit (_ bv64 8))))
 (let ((?x64878 (seq.++ ?x588 (seq.++ ?x598 (seq.++ ?x600 (seq.++ ?x64473 (seq.++ ?x64442 ?x64873)))))))
 (let ((?x602 (seq.unit (_ bv156 8))))
 (let ((?x64879 (seq.++ ?x602 ?x64878)))
 (let ((?x64779 (seq.unit (_ bv20 8))))
 (let ((?x3059 (seq.unit (_ bv6 8))))
 (let ((?x34516 (seq.++ ?x65 (seq.++ ?x6 (seq.++ ?x3059 (seq.++ ?x6 (seq.++ ?x64779 ?x64879)))))))
 (let ((?x216 (seq.unit (_ bv192 8))))
 (let ((?x407 (seq.unit (_ bv1 8))))
 (let ((?x34557 (seq.++ ?x65 (seq.++ ?x407 (seq.++ ?x216 (seq.++ ?x6 (seq.++ ?x65 ?x34516)))))))
 (let ((?x64366 ((_ ir4_ones_sum16_checksum_instance!1 0) (seq.++ ?x216 (seq.++ ?x6 ?x34557)))))
 (let ((?x64968 (seq.++ (seq.unit (bvnot ((_ extract 15 8) ?x64366))) (seq.++ (seq.unit (bvnot ((_ extract 7 0) ?x64366))) ?x63675))))
 (let ((?x64973 (seq.++ ?x6 (seq.++ ?x63439 (seq.++ ?x65 (seq.++ ?x63447 (seq.++ ?x63449 ?x64968)))))))
 (let ((?x64747 (seq.++ ?x64624 (seq.++ ?x64418 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 ?x64973)))))))
 (let ((?x64902 (seq.++ ?x588 (seq.++ ?x598 (seq.++ ?x600 (seq.++ ?x64473 (seq.++ ?x64442 ?x64747)))))))
 (let ((?x64903 (seq.++ ?x602 ?x64902)))
 (let ((?x64502 (seq.++ ?x407 (seq.++ ?x216 (seq.++ ?x6 (seq.++ ?x65 (seq.++ ?x65 ?x64903)))))))
 (let ((?x64784 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x216 (seq.++ ?x6 (seq.++ ?x65 ?x64502))))))
 (let ((?x65170 (seq.++ ?x6 (seq.++ ?x588 (seq.++ ?x3059 (seq.++ (seq.unit (_ bv182 8)) ?x64784))))))
 (let ((?x64907 (seq.unit (_ bv40 8))))
 (let ((?x2518 (seq.++ ?x6 (seq.++ ?x64907 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x588 ?x65170)))))))
 (let ((?x582 (seq.unit (_ bv69 8))))
 (let (($x64889 (= v_3_T.wire_packet (seq.++ ?x582 (seq.++ ?x6 ?x2518)))))
 (let ((?x245 (seq.++ ?x65 (seq.++ ?x407 (seq.++ ?x216 (seq.++ ?x6 (seq.++ ?x65 ?x65)))))))
 (let ((?x2987 (seq.++ ?x3059 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x216 (seq.++ ?x6 ?x245)))))))
 (let ((?x3286 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x588 (seq.++ ?x6 (seq.++ ?x588 ?x2987)))))))
 (let (($x34500 (= v_3_T.wire_ip_zero (seq.++ ?x582 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x64907 ?x3286)))))))
 (let (($x64904 (= v_3_T.wire_tcp ?x64903)))
 (let ((?x65005 (seq.++ ?x65 (seq.++ ?x65 (seq.++ ?x6 (seq.++ ?x3059 (seq.++ ?x6 ?x64779)))))))
 (let ((?x65010 (seq.++ ?x6 (seq.++ ?x65 (seq.++ ?x407 (seq.++ ?x216 (seq.++ ?x6 ?x65005)))))))
 (let (($x64746 (= v_3_T.wire_pseudo (seq.++ ?x216 ?x65010))))
 (let (($x64742 (= v_3_T.wire_tcp_zero ?x64879)))
 (let (($x64470 (= (as seq.empty (Seq (_ BitVec 8))) v_3_T.wire_data)))
 (let (($x2991 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x2990 (= v_3_T.take v_2_T.take)))
 (let (($x2989 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x2986 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x2988 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x3010 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x3068 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x3067 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x2710 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x2709 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x2708 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x2923 (= 0 v_3_T.retries)))
 (let (($x372 (= 1000 v_3_T.rto_ms)))
 (let (($x2883 (= v_3_T.tx_flags "S")))
 (let (($x64469 (= v_3_T.tx_ack (_ bv0 32))))
 (let (($x63536 (= v_3_T.tx_seq v_2_T.iss)))
 (let (($x63535 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x64509 (= v_3_T.snd_nxt (bvadd (_ bv1 32) v_2_T.iss))))
 (let (($x3604 (= v_3_T.snd_una v_2_T.iss)))
 (let (($x282 (= v_3_T.irs v_2_T.irs)))
 (let (($x63697 (= v_3_T.iss v_2_T.iss)))
 (let (($x3185 (= v_3_L.control v_2_L.control)))
 (let (($x3184 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x3479 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x3478 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x3491 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x3490 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x3080 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x3079 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x3011 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x3012 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x2887 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x2869 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x3421 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x2732 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x2862 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x2831 (= v_3_L.packet v_2_L.packet)))
 (let (($x2861 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x63511 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x63572 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x63571 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x2879 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x3008 (= v_3_L.payload v_2_L.payload)))
 (let (($x3007 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x3562 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x3350 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x2945 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x2944 (= 0 state_3)))
 (let (($x64795 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x65178 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x34502 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x64700 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x65217 (not active_2_L.query)))
 (let (($x64586 (or $x65217 (not (<= due_2_L.query 20)))))
 (let (($x31031 (= v_2_L.control "RESOLVED")))
 (let (($x311 (= v_2_T.control "CLOSED")))
 (let (($x34544 (= state_2 0)))
 (and $x34544 $x311 $x31031 $x64586 $x64700 $x34502 $x65178 $x64795 $x2944 $x2945 $x3350 $x3562 $x3007 $x3008 $x2879 $x63571 $x63572 $x63511 $x2861 $x2831 $x2862 $x2732 $x3421 $x2869 $x2887 $x3012 $x3011 $x3079 $x3080 $x3490 $x3491 $x3478 $x3479 $x3184 $x3185 $x63697 $x282 $x3604 $x64509 $x63535 $x63536 $x64469 $x2883 $x372 $x2923 v_3_T.active_open $x2708 $x2709 $x2710 $x3067 $x3068 $x3010 $x2988 $x2986 $x2989 $x2990 $x2991 $x64470 $x64742 $x64746 $x64904 $x34500 $x64889 $x65080 $x2999 $x63461 $x63462 $x63463 $x63464 active_3_T.rtx active_3_T.user $x64864 $x63468 $x63469 $x64990 (= due_3_T.user (+ 20 v_2_T.user_timeout_ms)) $x63472))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x216 (seq.unit (_ bv192 8))))
 (let ((?x3215 (seq.++ ?x216 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x3215))))
(assert
 (= 30 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x216 (seq.unit (_ bv192 8))))
 (let ((?x63673 (seq.++ ?x216 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x407 (seq.unit (_ bv1 8))))
 (let ((?x6 (seq.unit (_ bv0 8))))
 (let ((?x94261 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x407 ?x63673)))))))
 (let ((?x65 (seq.unit (_ bv2 8))))
 (let ((?x94266 (seq.++ ?x216 (seq.++ ?x6 (seq.++ ?x65 (seq.++ ?x65 (seq.++ ?x65 ?x94261)))))))
 (let ((?x94271 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x65 ?x94266)))))))
 (let ((?x2698 (seq.unit (_ bv4 8))))
 (let ((?x3059 (seq.unit (_ bv6 8))))
 (let ((?x94276 (seq.++ ?x3059 (seq.++ ?x2698 (seq.++ ?x6 (seq.++ ?x65 (seq.++ ?x65 ?x94271)))))))
 (let ((?x353 (seq.unit (_ bv8 8))))
 (let ((?x94281 (seq.++ ?x3059 (seq.++ ?x6 (seq.++ ?x407 (seq.++ ?x353 (seq.++ ?x6 ?x94276)))))))
 (let ((?x94286 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x65 (seq.++ ?x353 ?x94281)))))))
 (let ((?x94291 (seq.++ ?x6 (seq.++ ?x6 (seq.++ ?x407 (seq.++ ?x65 (seq.++ ?x6 ?x94286)))))))
 (let ((?x94294 (seq.++ ?x65 (seq.++ ?x6 (seq.++ ?x6 ?x94291)))))
 (= input_1_L.net.frame_frame ?x94294))))))))))))))))))
(assert
 (= 66 choice_2))
(assert
 (= 20 now_3))
(check-sat)

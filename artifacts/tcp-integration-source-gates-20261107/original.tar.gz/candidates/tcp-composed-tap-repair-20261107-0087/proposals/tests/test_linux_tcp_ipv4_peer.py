"""Synthetic tests for linux-tcp-ipv4-peer harness. NOT Linux evidence."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ports.linux_tcp_ipv4_peer.run import (
    CONFIG, dump, inputs, inside, run, verify, assess_case, stream_check
)
from ports.native_session import Session
from protocol_lab.ir import load
from protocol_lab.codegen import generate, sha
from protocol_lab.codegen.execute import build, commands, compare


class TestHarnessCLI(unittest.TestCase):
    def test_inside_requires_parent(self):
        """Child inside invocation must include --parent explicitly."""
        with mock.patch('subprocess.run') as mock_run:
            mock_run.return_value = subprocess.CompletedProcess([], 0)
            with tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp) / 'out'
                run(out)
                call = mock_run.call_args[0][0]
                self.assertIn('--inside', call)
                self.assertIn('--parent', call)
                idx_inside = call.index('--inside')
                idx_parent = call.index('--parent')
                self.assertLess(idx_inside, idx_parent)
                self.assertEqual(call[idx_parent + 1], os.readlink('/proc/self/ns/net'))

class TestNamespaceProof(unittest.TestCase):
    def test_inside_checks_namespace_before_commands(self):
        """Distinct namespace proof must occur before any ip/link command."""
        with mock.patch('os.readlink') as mock_read, \
             mock.patch('os.open') as mock_open, \
             mock.patch('fcntl.ioctl') as mock_io, \
             mock.patch('subprocess.Popen') as mock_popen:
            mock_read.side_effect = [
                'net:[4026531840]',  # parent
                'net:[4026531841]',  # current
                'net:[4026531840]'   # actual
            ]
            mock_open.return_value = 3
            mock_io.return_value = None
            # We'll mock inside to raise after namespace check to stop, then inspect order
            with tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp) / 'inside'
                with self.assertRaises(RuntimeError):
                    inside(out, 'net:[4026531840]')
                # Check that namespace.json was written before commands attempted
                ns_file = out / 'namespace.json'
                self.assertTrue(ns_file.exists())
                # And no setup files exist because failure occurred before commands? 
                # Actually the exception might happen later; we need to check that the first thing inside does is namespace check.
                # We can assert that setup logs do not exist if we fail before them.
                self.assertFalse((out / 'setup-0.log').exists())

class TestRawFrameHandling(unittest.TestCase):
    def test_unpadded_frame_causes_model_gap(self):
        """A short TCP frame (<60 bytes) must cause error and preserve raw, not pad."""
        # Create a synthetic scenario: monkeypatch functions to simulate inside.
        # We can test the is_selected and the dispatch logic but easier to test that if a frame length <60 is passed,
        # the model will raise model_gap because IR requires max(60,14+total). This is known externally.
        # So we test that our harness does not modify frame length before dispatch.
        raw_short = bytes.fromhex('450000280001000040060000c0000201c0000202')  # 40 bytes, no TCP header yet
        self.assertEqual(len(raw_short), 40)
        # In our inside, we would call is_selected then dispatch. The dispatch would call commands and actor.operation.
        # We'll mock actor.operation to return an error row with failure 'uncovered_event' and assert raw is preserved.
        with mock.patch('ports.linux_tcp_ipv4_peer.run.load') as mock_load, \
             mock.patch('ports.linux_tcp_ipv4_peer.run.Session') as mock_session, \
             mock.patch('time.monotonic_ns') as mock_time, \
             mock.patch('os.read') as mock_read, \
             mock.patch('os.write') as mock_write, \
             mock.patch('select.select') as mock_select:
            mock_load.return_value = {}  # dummy model
            mock_session.return_value = mock.MagicMock()
            mock_session.return_value.process.pid = 123
            mock_session.return_value.rows = []
            mock_session.return_value.snapshot = {}
            mock_session.return_value.operation.return_value = [{'status': 'error', 'failure': 'uncovered_event'}]
            mock_time.return_value = 0
            mock_read.return_value = raw_short
            mock_select.return_value = [3], [], []
            mock_write.return_value = len(raw_short)
            with tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp)
                # We must call inside but it will fail; we catch and check link file exists with same raw.
                with self.assertRaises(RuntimeError):
                    inside(out, 'net:[fake]')
                # The raw frame should be saved in link file before dispatch, so check it's there and identical.
                links = json.loads((out / 'links.json').read_text())
                self.assertEqual(len(links), 1)
                saved_raw = (out / links[0]['file']).read_bytes()
                self.assertEqual(saved_raw, raw_short)

class TestQuietDropLifecycle(unittest.TestCase):
    def test_capture_drops_cause_rejection(self):
        """If tcpdump reports drops, assess_case must fail."""
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            # Create minimal fake evidence with drops
            (out / 'namespace.json').write_text(json.dumps({
                'capture_command': ['tcpdump', '--immediate-mode', '-c', '10'],  # count cap and missing filter
                'quiet_ms': 50,
                'capture_stop_request_monotonic_ns': 100,
                'last_selected_monotonic_ns': 90,
                'native_returncode': 0, 'capture_returncode': 0,
                'peer_listening_monotonic_ns': 10, 'capture_ready_monotonic_ns': 20,
                'clock_origin_monotonic_ns': 30, 'capture_exit_monotonic_ns': 40,
                'native_closed_monotonic_ns': 50, 'peer_closed_monotonic_ns': 60,
                'resources_closed_monotonic_ns': 70
            }))
            (out / 'capture.log').write_text('2 packets captured\n1 packet dropped by kernel\n')
            (out / 'capture.pcap').write_bytes(b'\xd4\xc3\xb2\xa1\x02\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x65\x00\x00\x00\x01\x00\x00\x00')
            (out / 'links.json').write_text('[]')
            (out / 'services.json').write_text('[]')
            (out / 'unselected.json').write_text('[]')
            (out / 'extra.json').write_text('[]')
            (out / 'events.json').write_text('[]')
            (out / 'received.json').write_text('[]')
            (out / 'scenario.json').write_text(json.dumps({'steps': []}))
            (out / 'native').mkdir()
            (out / 'native' / 'session.json').write_text(json.dumps({'process_starts': 1, 'returncode': 0, 'transport': 'stdin-pipe-stdout-raw-pty', 'pid': 1, 'operations': []}))
            (out / 'native' / 'native-input.txt').write_text('B\n')
            (out / 'native' / 'native.stdout').write_text('')
            (out / 'native' / 'native.stderr').write_text('')
            (out / 'symbolic-result.json').write_text(json.dumps({'status': 'match', 'query': 'sat'}))
            (out / 'decoded.json').write_text('[]')
            (out / 'difference.json').write_text(json.dumps({'status': 'match'}))
            with self.assertRaises(RuntimeError):
                assess_case(out)

    def test_quiet_window_too_short(self):
        """If quiet duration is less than required, assess_case must fail."""
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / 'namespace.json').write_text(json.dumps({
                'capture_command': ['tcpdump', '--immediate-mode', '-Z', 'root', '-U', '-n', '-s', '0', '-i', 'tap0', '-w', 'x.pcap', 'arp or tcp'],
                'quiet_ms': 100,
                'capture_stop_request_monotonic_ns': 150,
                'last_selected_monotonic_ns': 100,
                'native_returncode': 0, 'capture_returncode': 0,
                'peer_listening_monotonic_ns': 10, 'capture_ready_monotonic_ns': 20,
                'clock_origin_monotonic_ns': 30, 'capture_exit_monotonic_ns': 40,
                'native_closed_monotonic_ns': 50, 'peer_closed_monotonic_ns': 60,
                'resources_closed_monotonic_ns': 70
            }))
            # Other files minimal
            (out / 'capture.log').write_text('0 packets captured\n0 packets dropped\n')
            (out / 'capture.pcap').write_bytes(b'\xd4\xc3\xb2\xa1\x02\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x65\x00\x00\x00\x01\x00\x00\x00')
            (out / 'links.json').write_text('[]')
            (out / 'services.json').write_text('[]')
            (out / 'unselected.json').write_text('[]')
            (out / 'extra.json').write_text('[]')
            (out / 'events.json').write_text('[]')
            (out / 'received.json').write_text('[]')
            (out / 'scenario.json').write_text(json.dumps({'steps': []}))
            (out / 'native').mkdir()
            (out / 'native' / 'session.json').write_text(json.dumps({'process_starts': 1, 'returncode': 0, 'transport': 'stdin-pipe-stdout-raw-pty', 'pid': 1, 'operations': []}))
            (out / 'native' / 'native-input.txt').write_text('B\n')
            (out / 'native' / 'native.stdout').write_text('')
            (out / 'native' / 'native.stderr').write_text('')
            (out / 'symbolic-result.json').write_text(json.dumps({'status': 'match', 'query': 'sat'}))
            (out / 'decoded.json').write_text('[]')
            (out / 'difference.json').write_text(json.dumps({'status': 'match'}))
            with self.assertRaises(RuntimeError):
                assess_case(out)

class TestSymbolicVerification(unittest.TestCase):
    def test_missing_symbolic_result_rejected(self):
        """Offline verify must fail if symbolic-result.json is missing."""
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            report = {'status': 'pass', 'linux_peer_evidence': True, 'whole_ipv4_endpoint_complete': False,
                      'api_calls': 0, 'physical_ethernet': False, 'generated_subject_uses_host_stack': False,
                      'packet_bytes_rewritten': False, 'file_hashes': {}, 'input_hashes': {}}
            (out / 'report.json').write_text(json.dumps(report))
            # No symbolic-result.json
            with self.assertRaises(RuntimeError):
                verify(out, offline=True)

    def test_empty_file_hash_map_rejected(self):
        """Empty file_hashes map should be rejected."""
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / 'report.json').write_text(json.dumps({
                'status': 'pass', 'linux_peer_evidence': True, 'whole_ipv4_endpoint_complete': False,
                'api_calls': 0, 'physical_ethernet': False, 'generated_subject_uses_host_stack': False,
                'packet_bytes_rewritten': False, 'file_hashes': {}, 'input_hashes': {}
            }))
            # Add a dummy file to cause expected set non-empty
            (out / 'dummy.txt').write_text('dummy')
            with self.assertRaises(RuntimeError):
                verify(out, offline=True)

class TestPeerLifecycle(unittest.TestCase):
    def test_peer_exit_not_overwritten(self):
        """finally block must not overwrite earlier peer_exit receipt."""
        # This is a static check: we can inspect the source to ensure peer_exit is recorded before finally.
        source = (ROOT / 'ports/linux-tcp-ipv4-peer/run.py').read_text()
        self.assertIn("meta['peer_returncode'] = peer.wait(timeout=5)", source)
        self.assertIn("finally:", source)
        # The finally should not set peer_returncode again. We can check that there is no assignment inside finally.
        finally_start = source.find('finally:')
        self.assertNotIn('peer_returncode', source[finally_start:])

if __name__ == '__main__':
    unittest.main()

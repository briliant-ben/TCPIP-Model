"""One generated Ethernet/ARP/IPv4/TCP IR subject with isolated Linux kernel peer."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import platform
import re
import select
import shutil
import socket
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
PORT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PORT))

from ports.native_session import Session
from protocol_lab.codegen import generate, sha
from protocol_lab.codegen.execute import build, commands, compare, write
from protocol_lab.ir import load, model_files
from protocol_lab.flow import run_scenario
from protocol_lab.symbolic import crosscheck_trace, replay

# Minimal PCAP decoder (raw IP only) reused from wire-peer; no callbacks.
def checksum_valid(raw):
    total = sum(value * (256 if i % 2 == 0 else 1) for i, value in enumerate(raw))
    while total >> 16:
        total = (total & 65535) + (total >> 16)
    return total == 65535

def decode_packet(raw):
    if len(raw) < 40 or raw[0] >> 4 != 4:
        raise ValueError('Short/non-IPv4 TCP packet')
    ihl = (raw[0] & 15) * 4
    total = struct.unpack('!H', raw[2:4])[0]
    if ihl < 20 or len(raw) < ihl + 20 or total != len(raw) or raw[9] != 6:
        raise ValueError('Invalid IPv4 TCP extent')
    fragment = struct.unpack('!H', raw[6:8])[0]
    if fragment & 0x3fff:
        raise ValueError('Fragmented TCP not decoded')
    if not checksum_valid(raw[:ihl]):
        raise ValueError('Invalid IPv4 checksum')
    tcp = raw[ihl:]
    if len(tcp) < 20:
        raise ValueError('Short TCP header')
    sport, dport, seq, ack, offset, flags, window, check, urgent = struct.unpack('!HHIIBBHHH', tcp[:20])
    header = (offset >> 4) * 4
    if header < 20 or header > len(tcp):
        raise ValueError('Invalid TCP header extent')
    pseudo = raw[12:20] + struct.pack('!BBH', 0, 6, len(tcp))
    if not checksum_valid(pseudo + tcp):
        raise ValueError('Invalid TCP checksum')
    return {
        'source': socket.inet_ntoa(raw[12:16]),
        'destination': socket.inet_ntoa(raw[16:20]),
        'source_port': sport,
        'destination_port': dport,
        'seq': seq,
        'ack': ack,
        'flags': flags,
        'window': window,
        'payload_hex': tcp[header:].hex(),
        'options_hex': tcp[20:header].hex(),
        'tcp_header_bytes': header,
        'ip_header_bytes': ihl,
        'ttl': raw[8],
        'ip_id': struct.unpack('!H', raw[4:6])[0],
        'df': bool(fragment & 16384),
        'tos': raw[1],
        'urgent': urgent,
        'reserved': offset & 15
    }

def records(path):
    raw = Path(path).read_bytes()
    magics = {
        b'\xd4\xc3\xb2\xa1': ('<', 1000),
        b'\xa1\xb2\xc3\xd4': ('>', 1000),
        b'\x4d\x3c\xb2\xa1': ('<', 1),
        b'\xa1\xb2\x3c\x4d': ('>', 1)
    }
    if len(raw) < 24 or raw[:4] not in magics:
        raise ValueError('Invalid classic PCAP')
    endian, factor = magics[raw[:4]]
    major, minor, zone, accuracy, snap, link = struct.unpack(endian + 'HHIIII', raw[4:24])
    if (major, minor) != (2, 4) or link != 101 or snap <= 0:
        raise ValueError('Expected raw-IP PCAP')
    offset = 24
    previous = -1
    result = []
    while offset < len(raw):
        if offset + 16 > len(raw):
            raise ValueError('Truncated PCAP record')
        sec, frac, size, original = struct.unpack(endian + 'IIII', raw[offset:offset + 16])
        offset += 16
        stamp = sec * 1000000000 + frac * factor
        if frac >= 1000000000 // factor or size != original or size > snap or offset + size > len(raw) or stamp < previous:
            raise ValueError('Invalid PCAP packet/time')
        packet = raw[offset:offset + size]
        offset += size
        previous = stamp
        result.append({
            'timestamp_ns': stamp,
            'hex': packet.hex(),
            'decoded': decode_packet(packet)
        })
    return result

CONFIG = {
    'model': 'model/tcp-ipv4-endpoint.json',
    'interface': 'tap0',
    'subject': {'ip': '192.0.2.1', 'mac': '02:00:00:00:00:01', 'port': 40000},
    'peer': {'ip': '192.0.2.2', 'mac': '02:00:00:00:00:02', 'port': 8080},
    'mtu': 1500,
    'payload_hex': '0080ff0700',
    'quiet_ms': 100,
    'phase_timeout_seconds': 10,
    'expected_cache_ttl_ms': 60000,
    'wire_timing_contract': {}
}

def require(cond, msg):
    if not cond:
        raise RuntimeError(msg)

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2) + chr(10))

def inputs():
    """Collect hashes of all required source/config files."""
    model_path = ROOT / CONFIG['model']
    require(model_path.is_file(), 'Model file missing: ' + str(model_path))
    paths = {
        ROOT / 'ports/native_session.py',
        ROOT / 'ports/linux-tcp-ipv4-peer/run.py',
        ROOT / 'ports/linux-tcp-wire-peer/server.py',
        model_path,
        ROOT / 'spec/tcp-wire-endpoint-oracle.json',
    }
    paths.update(Path(p) for p in model_files(model_path))
    paths.update(p for p in (ROOT / 'protocol_lab').rglob('*.py'))
    paths.update(p for p in (ROOT / 'protocol_lab').rglob('*.c'))
    for p in sorted(paths):
        require(p.resolve().is_relative_to(ROOT), 'Source escapes root')
        require(p.is_file(), 'Source missing: ' + str(p))
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}

def command(args, out, name, timeout=20):
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    (out / name).write_text(p.stdout + p.stderr)
    require(p.returncode == 0, 'Command failed: ' + repr(args))
    return dict(command=args, returncode=p.returncode, log=name)

def tools_info():
    result = {}
    for name, args in (('ip', ['-V']), ('unshare', ['--version']), ('tcpdump', ['--version']), ('cc', ['--version'])):
        path = shutil.which(name)
        require(path is not None, 'missing tool ' + name)
        real = Path(path).resolve()
        result[name] = dict(path=str(real), sha256=sha(real), version=subprocess.run([str(real)] + args, capture_output=True, text=True, timeout=15).stdout[-500:])
    py = Path(sys.executable).resolve()
    result['python'] = dict(path=str(py), sha256=sha(py), version=subprocess.run([str(py), '--version'], capture_output=True, text=True, timeout=15).stdout[-500:])
    return result

def commit():
    return subprocess.check_output(['git', '-c', 'safe.directory=' + str(ROOT), 'rev-parse', 'HEAD'], cwd=ROOT, text=True, timeout=15).strip()

SELECTED_ETHERTYPES = {0x0806, 0x0800}  # ARP and IPv4
SELECTED_IP_PROTO = 6  # TCP

def is_selected(raw):
    """Return True if frame should be fed to model (ARP or IPv4 TCP)."""
    if len(raw) < 14:
        return False
    ethertype = struct.unpack('!H', raw[12:14])[0]
    if ethertype == 0x0806:
        return True
    if ethertype == 0x0800 and len(raw) >= 34:
        ip_proto = raw[23] if (raw[14] & 0xf0) == 0x40 else -1
        if ip_proto == SELECTED_IP_PROTO:
            return True
    return False

def inside(out, parent):
    """Execute the full exchange in an already-isolated network namespace."""
    require(platform.system() == 'Linux' and os.geteuid() == 0, 'Linux namespace root required')
    actual = os.readlink('/proc/' + str(os.getppid()) + '/ns/net')
    current = os.readlink('/proc/self/ns/net')
    require(parent.startswith('net:[') and current.startswith('net:[') and parent != current and actual == parent, 'Distinct network namespace required')

    out.mkdir(parents=True, exist_ok=True)
    meta = {
        'platform': 'Linux',
        'kernel': platform.release(),
        'parent_netns': parent,
        'actual_parent_netns': actual,
        'execution_netns': current,
        'host_network_mutations': False,
        'packet_bytes_rewritten': False,
        'peer': 'ordinary Linux TCP socket',
        'quiet_ms': CONFIG['quiet_ms'],
        'wire_timing_contract': CONFIG['wire_timing_contract'],
        'commands': [],
    }
    dump(out / 'namespace.json', meta)

    fd = None
    capture = None
    actor = None
    peer = None
    handles = []
    extra = []
    try:
        # Create TAP interface
        fd = os.open('/dev/net/tun', os.O_RDWR)
        fcntl.ioctl(fd, 0x400454ca, struct.pack('16sH22x', CONFIG['interface'].encode(), 0x1002))
        os.set_blocking(fd, False)

        # Configure interface (peer side)
        mac = ':'.join(CONFIG['peer']['mac'][i:i + 2] for i in range(0, 12, 2))
        setup = [
            ['ip', 'link', 'set', 'lo', 'up'],
            ['ip', 'link', 'set', CONFIG['interface'], 'address', mac],
            ['ip', 'addr', 'add', CONFIG['peer']['ip'] + '/24', 'dev', CONFIG['interface']],
            ['ip', 'link', 'set', CONFIG['interface'], 'mtu', str(CONFIG['mtu']), 'up'],
            ['ip', 'route', 'add', CONFIG['subject']['ip'] + '/32', 'dev', CONFIG['interface'], 'src', CONFIG['peer']['ip']],
            ['ip', 'addr', 'show'],
            ['ip', 'route', 'show'],
        ]
        for i, args in enumerate(setup):
            meta['commands'].append(command(args, out, 'setup-' + str(i) + '.log'))

        # Start tcpdump
        cap_log = (out / 'capture.log').open('w')
        handles.append(cap_log)
        cap_cmd = ['tcpdump', '--immediate-mode', '-Z', 'root', '-U', '-n', '-s', '0', '-i', CONFIG['interface'], '-w', str(out / 'capture.pcap'), 'arp or tcp']
        meta['capture_command'] = cap_cmd
        capture = subprocess.Popen(cap_cmd, stdout=cap_log, stderr=cap_log)
        deadline = time.monotonic() + 5
        while 'listening on' not in (out / 'capture.log').read_text() and time.monotonic() < deadline:
            require(capture.poll() is None, 'capture failed startup')
            time.sleep(0.02)
        require('listening on' in (out / 'capture.log').read_text(), 'capture readiness timeout')
        meta['capture_ready_monotonic_ns'] = time.monotonic_ns()

        # Start peer server
        peer_script = ROOT / 'ports/linux-tcp-wire-peer/server.py'
        require(peer_script.is_file(), 'peer server missing')
        peer_out = out / 'peer'
        peer_out.mkdir()
        peer_stdout = (out / 'peer.stdout').open('w')
        peer_stderr = (out / 'peer.stderr').open('w')
        handles.extend([peer_stdout, peer_stderr])
        payload = bytes.fromhex(CONFIG['payload_hex'])
        peer = subprocess.Popen(
            [sys.executable, str(peer_script), '--out', str(peer_out), '--ip', CONFIG['peer']['ip'],
             '--port', str(CONFIG['peer']['port']), '--count', str(len(payload))],
            stdin=subprocess.PIPE, stdout=peer_stdout, stderr=peer_stderr)
        # Wait for peer listening
        deadline = time.monotonic() + 5
        while True:
            require(peer.poll() is None, 'peer exited before listening')
            events_path = peer_out / 'server-events.jsonl'
            if events_path.exists():
                listening = False
                for line in events_path.read_text().splitlines():
                    if line:
                        row = json.loads(line)
                        if row.get('event') == 'listening':
                            listening = True
                            break
                if listening:
                    break
            if time.monotonic() >= deadline:
                raise RuntimeError('peer listening timeout')
            time.sleep(0.02)
        meta['peer_listening_monotonic_ns'] = time.monotonic_ns()

        # Load model and start native session
        model = load(ROOT / CONFIG['model'])
        actor = Session(out.parent / 'build/protocol-native', out / 'native')
        origin_ns = time.monotonic_ns()
        meta['clock_origin_monotonic_ns'] = origin_ns
        ns = {'origin_ns': origin_ns}

        def now_ms():
            return (time.monotonic_ns() - origin_ns) // 1000000

        # Storage for evidence
        links = []
        services = []
        unselected = []
        events = []
        received = []
        steps = []
        scene = {'scenario_version': '0.2', 'id': 'linux-live-tcp-ipv4', 'initial': {}, 'steps': steps}
        selected_last_ns = None

        def deliver(rows):
            """Handle emitted messages from native rows."""
            nonlocal links, services, selected_last_ns
            for row in rows:
                if row.get('status') == 'error':
                    reason = row.get('failure')
                    category = ('model_gap' if reason == 'uncovered_event' else
                                'rule_conflict' if reason == 'rule_conflict' else
                                'invariant_failure' if reason.startswith('invariant:') else
                                'backend_or_input_failure')
                    raise RuntimeError(category + ': ' + str(reason))
                require(row.get('status') in ('transition', 'ok'), 'native operation did not commit')
                for item in row.get('emitted', []):
                    msg = item.get('message')
                    fields = item.get('fields', {})
                    if msg == 'L.ethernet.tx':
                        require(set(fields.keys()) == {'frame'}, 'Unexpected wire shape')
                        raw = bytes(fields['frame'])
                        path = 'link-' + str(len(links)) + '.raw'
                        (out / path).write_bytes(raw)
                        links.append({'direction': 'subject_tx', 'file': path, 'monotonic_ns': time.monotonic_ns()})
                        written = os.write(fd, raw)
                        require(written == len(raw), 'partial TAP write')
                    elif msg in ('L.neighbor.resolved', 'L.neighbor.failed'):
                        services.append({'message': msg, 'fields': fields})
                    elif msg in ('T.application', 'T.application_data'):
                        services.append({'message': msg, 'fields': fields})
                    else:
                        raise RuntimeError('unknown native message: ' + str(msg))

        def dispatch(step):
            """Dispatch one step to native session and process emissions."""
            nonlocal events, steps, selected_last_ns
            at_ms = step.get('at_ms')
            steps.append(step)
            row_start = len(actor.rows)
            sampled_ns = time.monotonic_ns()
            receipt = {'at_ms': at_ms, 'pid': actor.process.pid, 'sampled_monotonic_ns': sampled_ns, 'row_start': row_start, 'step': step}
            try:
                line = commands(model, {'initial': {}, 'steps': [step]}).splitlines()[1]
            except Exception as e:
                receipt['raised'] = 'commands:' + str(e)
                events.append(receipt)
                raise
            receipt['line'] = line
            rows = actor.operation(line)
            receipt['row_end'] = len(actor.rows)
            receipt['reply_monotonic_ns'] = time.monotonic_ns()
            events.append(receipt)
            deliver(rows)
            if step.get('tick'):
                pass
            else:
                if step.get('event') == 'L.net.frame':
                    selected_last_ns = receipt['reply_monotonic_ns']
            return actor.snapshot

        def pump_once(deadline_s):
            """Process one due timer or one ready FD event."""
            if actor.process.poll() is not None:
                raise RuntimeError('native subject exited during pump')
            if peer.poll() is not None:
                raise RuntimeError('peer exited during pump')
            snap = actor.snapshot or {}
            now_ms = now_ms()
            timers = snap.get('timers') or {}
            due = [(name, d) for name, d in timers.items() if isinstance(d, int) and d <= now_ms]
            if due:
                due.sort(key=lambda x: (x[1], x[0]))
                name, due_ms = due[0]
                dispatch({'tick': True, 'at_ms': now_ms})
                return True
            wait = min(0.01, max(0, deadline_s - time.monotonic()))
            ready = select.select([fd], [], [], wait)[0]
            if not ready:
                return False
            raw = os.read(fd, 65535)
            if not raw:
                return False
            if is_selected(raw):
                path = 'link-' + str(len(links)) + '.raw'
                (out / path).write_bytes(raw)
                links.append({'direction': 'peer_tx', 'file': path, 'monotonic_ns': time.monotonic_ns()})
                # Record last selected timestamp BEFORE dispatch; if dispatch raises, the raw is preserved.
                selected_last_ns = time.monotonic_ns()
                dispatch({'at_ms': now_ms(), 'event': 'L.net.frame', 'fields': {'frame': list(raw)}})
                return True
            else:
                path = 'unselected-' + str(len(unselected)) + '.raw'
                (out / path).write_bytes(raw)
                unselected.append({'file': path, 'length': len(raw), 'ethertype': raw[12:14].hex(), 'monotonic_ns': time.monotonic_ns()})
                return True

        def pump_until(deadline_s, predicate):
            """Pump until predicate(snapshot) is true or timeout."""
            while True:
                snap = actor.snapshot or {}
                if predicate(snap):
                    return snap
                if time.monotonic() >= deadline_s:
                    raise RuntimeError('pump timeout')
                pump_once(deadline_s)

        # Phase 1: connect
        dispatch({'at_ms': now_ms(), 'event': 'T.app.connect', 'fields': {}})
        pump_until(time.monotonic() + CONFIG['phase_timeout_seconds'], lambda s: s.get('state') == 'ESTABLISHED')

        # Phase 2: send and transmit
        dispatch({'at_ms': now_ms(), 'event': 'T.app.send', 'fields': {'data': list(payload)}})
        dispatch({'at_ms': now_ms(), 'event': 'T.app.transmit', 'fields': {}})

        # Phase 3: receive echo
        def echo_received(s):
            vars = s.get('variables') or {}
            rcv = list(vars.get('T.rcv_buf') or [])
            return len(rcv) >= len(payload)
        pump_until(time.monotonic() + CONFIG['phase_timeout_seconds'], echo_received)
        rcv_len = len(payload)
        dispatch({'at_ms': now_ms(), 'event': 'T.app.receive', 'fields': {'count': rcv_len}})

        # Phase 4: close
        dispatch({'at_ms': now_ms(), 'event': 'T.app.close', 'fields': {}})
        final_snap = pump_until(time.monotonic() + CONFIG['phase_timeout_seconds'],
                                lambda s: s.get('state') in ('TIME-WAIT', 'CLOSED'))

        # Record last selected packet timestamp
        require(selected_last_ns is not None, 'no selected peer packet observed')
        quiet_end = selected_last_ns + CONFIG['quiet_ms'] * 1000000
        # Quiet window: read frames but do not dispatch, save as extra.
        while time.monotonic_ns() < quiet_end:
            remaining = (quiet_end - time.monotonic_ns()) / 1000000000
            ready = select.select([fd], [], [], max(0, min(0.01, remaining)))[0]
            if not ready:
                continue
            raw = os.read(fd, 65535)
            if raw:
                path = 'extra-' + str(len(extra)) + '.raw'
                (out / path).write_bytes(raw)
                extra.append({'file': path, 'length': len(raw), 'monotonic_ns': time.monotonic_ns()})

        # Stop capture
        meta['capture_stop_request_monotonic_ns'] = time.monotonic_ns()
        require(capture.poll() is None, 'capture ended early')
        capture.send_signal(2)
        meta['capture_returncode'] = capture.wait(timeout=5)
        meta['capture_exit_monotonic_ns'] = time.monotonic_ns()
        require(meta['capture_returncode'] == 0, 'capture failed')

        # Close native and peer
        meta['native_returncode'] = actor.close()
        meta['native_pid'] = actor.process.pid
        meta['native_closed_monotonic_ns'] = time.monotonic_ns()
        actor = None
        peer.stdin.close()
        meta['peer_returncode'] = peer.wait(timeout=5)
        meta['peer_closed_monotonic_ns'] = time.monotonic_ns()
        peer = None

        # Write final evidence
        dump(out / 'links.json', links)
        dump(out / 'services.json', services)
        dump(out / 'unselected.json', unselected)
        dump(out / 'extra.json', extra)
        dump(out / 'events.json', events)
        dump(out / 'received.json', received)
        scene['expect'] = {
            'state': final_snap.get('state'),
            'variables': final_snap.get('variables'),
            'timers': final_snap.get('timers'),
        }
        dump(out / 'scenario.json', scene)
        meta['resources_closed_monotonic_ns'] = time.monotonic_ns()
        dump(out / 'namespace.json', meta)

    except Exception as e:
        # Write failure evidence
        try:
            dump(out / 'namespace-failure.json', {
                'status': 'failed_or_blocked',
                'type': type(e).__name__,
                'reason': str(e)
            })
        except Exception:
            pass
        raise
    finally:
        if capture is not None and capture.poll() is None:
            capture.send_signal(2)
            capture.wait(timeout=5)
        if actor is not None:
            actor.close()
        if peer is not None and peer.poll() is None:
            peer.stdin.close()
            peer.wait(timeout=5)
        if fd is not None:
            os.close(fd)
        for h in handles:
            try:
                h.close()
            except Exception:
                pass

def assess_case(out, save=True):
    """Verify all evidence produced by inside()."""
    ns = json.loads((out / 'namespace.json').read_text())
    scene = json.loads((out / 'scenario.json').read_text())
    model = load(ROOT / CONFIG['model'])
    require(ns['actual_parent_netns'] == ns['parent_netns'] and not ns['host_network_mutations'] and not ns['packet_bytes_rewritten'], 'Namespace/scope changed')
    require('--immediate-mode' in ns['capture_command'] and '-c' not in ns['capture_command'] and ns['capture_command'][-1] == 'arp or tcp', 'Capture limited/buffered/filtered differently')
    require(ns['peer_listening_monotonic_ns'] <= ns['capture_ready_monotonic_ns'] <= ns['clock_origin_monotonic_ns'] <= ns['capture_stop_request_monotonic_ns'] <= ns['capture_exit_monotonic_ns'] <= ns['native_closed_monotonic_ns'] <= ns['peer_closed_monotonic_ns'] <= ns['resources_closed_monotonic_ns'], 'Lifecycle changed')
    require(ns['quiet_ms'] == CONFIG['quiet_ms'] and ns['capture_stop_request_monotonic_ns'] - ns['last_selected_monotonic_ns'] >= CONFIG['quiet_ms'] * 1000000, 'Quiet capture shortened')
    require(ns['native_returncode'] == ns['capture_returncode'] == 0, 'Native/capture failed')
    cap_log = (out / 'capture.log').read_text()
    stats = {name: re.findall(r'(\d+) packets ' + name, cap_log) for name in ('captured', 'received by filter', 'dropped by kernel')}
    require(all(stats.values()) and int(stats['dropped by kernel'][-1]) == 0, 'Missing stats/capture drops')
    captured = records(out / 'capture.pcap')
    links = json.loads((out / 'links.json').read_text())
    require(len(captured) == len(links), 'capture/link count mismatch')
    for cap, link in zip(captured, links):
        require(cap['hex'] == (out / link['file']).read_bytes().hex(), 'capture/TAP bytes differ')
        require(cap['decoded']['source_port'] == CONFIG['subject']['port'] if link['direction'] == 'subject_tx' else cap['decoded']['destination_port'] == CONFIG['subject']['port'], 'port mismatch')
    rows, session = stream_check(out / 'native', model, scene)
    require(session['pid'] == ns['native_pid'], 'Native PID changed')
    diff = compare(model, scene, rows)
    require(diff['status'] == 'match', 'Reference/native difference')
    services = json.loads((out / 'services.json').read_text())
    msgs = [s['message'] for s in services]
    require('T.application' in msgs and 'T.application_data' in msgs, 'missing application services')
    symbolic_path = out / 'symbolic-result.json'
    require(symbolic_path.exists(), 'symbolic result missing')
    symbolic = json.loads(symbolic_path.read_text())
    require(symbolic['status'] == 'match' and symbolic['query'] == 'sat', 'symbolic check failed')
    # Also verify symbolic input trace matches actual scenario
    require(symbolic['input_trace'] == scene, 'symbolic input trace mismatch')
    if save:
        dump(out / 'decoded.json', captured)
        dump(out / 'difference.json', diff)
    else:
        require(json.loads((out / 'decoded.json').read_text()) == captured and json.loads((out / 'difference.json').read_text()) == diff, 'Saved decoding/Difference changed')
    return {'status': 'pass', 'packets': len(captured), 'process_starts': 1}

def stream_check(folder, model, scene):
    session = json.loads((folder / 'session.json').read_text())
    lines = (folder / 'native-input.txt').read_text().splitlines()
    rows = [json.loads(r) for r in (folder / 'native.stdout').read_text().splitlines()]
    require(session['process_starts'] == 1 and session['returncode'] == 0 and session['transport'] == 'stdin-pipe-stdout-raw-pty', 'native continuity/returncode changed')
    require(commands(model, scene) == chr(10).join(lines) + chr(10) and lines[0] == 'B' and lines.count('B') == 1, 'native ingress/reset/replay changed')
    require([o['line'] for o in session['operations']] == lines, 'native operation transcript changed')
    end = 0
    for i, o in enumerate(session['operations']):
        require(o['pid'] == session['pid'] and o['row_start'] == end and o['sent_monotonic_ns'] <= o['reply_monotonic_ns'], 'native PID/timeline changed')
        end = o['row_end']
        require(end > o['row_start'] and rows[end - 1]['status'] == ('ready' if i == 0 else 'ok'), 'native operation failed')
    require(end == len(rows), 'unaccounted native output')
    return rows, session

def run(out):
    """Main orchestration: preflight, build, execute, verify, symbolic."""
    out.mkdir(parents=True, exist_ok=False)
    before = inputs()
    pre = {
        'platform': platform.system(),
        'kernel': platform.release(),
        'euid': os.geteuid(),
        'tun': Path('/dev/net/tun').exists(),
        'tools': tools_info()
    }
    dump(out / 'preflight.json', pre)
    dump(out / 'report.json', {'status': 'not_run', 'linux_peer_evidence': False})
    require(pre['platform'] == 'Linux' and pre['euid'] == 0 and pre['tun'] and all(t in pre['tools'] for t in ('ip', 'unshare', 'tcpdump', 'cc')), 'Linux root/TAP/tools unavailable')
    generate(ROOT / CONFIG['model'], out / 'generated')
    require(build(out / 'generated', out / 'build')['status'] == 'pass', 'Native build failed')
    case = out / 'network'
    case.mkdir()
    parent_ns = os.readlink('/proc/self/ns/net')
    cmd = ['unshare', '--net', '--', sys.executable, str(PORT / 'run.py'), '--inside', '--parent', parent_ns, '--out', str(case)]
    command(cmd, case, 'namespace-driver.log', timeout=60)
    cases = assess_case(case)
    model = load(ROOT / CONFIG['model'])
    scene = json.loads((case / 'scenario.json').read_text())
    trace = run_scenario(model, scene).trace
    symbolic = crosscheck_trace(model, trace, case / 'symbolic')
    require(symbolic['status'] == 'match' and symbolic['query'] == 'sat', 'Actual-input Z3 unresolved/different')
    require(json.loads((case / 'symbolic' / 'result.json').read_text()) == symbolic, 'symbolic on-disk mismatch')
    dump(case / 'symbolic-result.json', symbolic)
    require(inputs() == before, 'Inputs changed during execution')
    result = {
        'schema': 'linux-live-tcp-ipv4-peer-v1',
        'status': 'pass',
        'linux_peer_evidence': True,
        'kernel': pre['kernel'],
        'cases': cases,
        'execution_source_root': str(ROOT),
        'execution_output_dir': str(out),
        'source_commit': commit(),
        'tool_hashes': {str(k): v['sha256'] for k, v in pre['tools'].items()},
        'input_hashes': before,
        'api_calls': 0,
        'physical_ethernet': False,
        'whole_ipv4_endpoint_complete': False,
        'generated_subject_uses_host_stack': False,
        'packet_bytes_rewritten': False,
        'integrity_is_not_authenticity': True
    }
    expected_files = set()
    for p in out.rglob('*'):
        if p.is_file() and p.name != 'report.json':
            expected_files.add(str(p.relative_to(out)))
    result['file_hashes'] = {p: sha(out / p) for p in expected_files}
    dump(out / 'report.json', result)
    return result

def verify(out, offline=False):
    """Verify an existing output directory."""
    report = json.loads((out / 'report.json').read_text())
    require(report['status'] == 'pass', 'report not pass')
    require(report['linux_peer_evidence'] == True, 'not Linux peer evidence')
    require(report['whole_ipv4_endpoint_complete'] == False, 'unexpected completeness claim')
    require(report['api_calls'] == 0, 'API calls not zero')
    require(report['physical_ethernet'] == False, 'physical ethernet claim')
    require(report['generated_subject_uses_host_stack'] == False, 'host stack claim')
    require(report['packet_bytes_rewritten'] == False, 'packet rewrite claim')
    # Verify expected file set independently, not self-attested empty map.
    expected_files = set()
    for p in out.rglob('*'):
        if p.is_file() and p.name != 'report.json':
            expected_files.add(str(p.relative_to(out)))
    for rel in expected_files:
        require(sha(out / rel) == report.get('file_hashes', {}).get(rel), 'file hash mismatch: ' + rel)
    require(len(report.get('file_hashes', {})) == len(expected_files), 'file hash map size mismatch')
    # Verify source hashes match report.input_hashes
    current_inputs = inputs()
    for rel, h in report['input_hashes'].items():
        require(current_inputs.get(rel) == h, 'source hash mismatch: ' + rel)
    if offline:
        # In offline mode, we do not execute code, but we can read evidence and recompute constraints.
        # We rely on stored assessment files; the assess_case function would require root TAP? No, it only reads files.
        # But assess_case also accesses model and might use compare which could run native? Actually compare reads rows and runs reference, no native execution.
        # So it is safe to call assess_case in offline mode.
        cases = assess_case(out / 'network', save=False)
        return {'status': 'verified_offline', 'evidence_present': True, 'cases': cases}
    else:
        # Online verification can also re-run checks, but does not need to re-execute network.
        cases = assess_case(out / 'network', save=False)
        return {'status': 'verified_online', 'cases': cases}

def preflight():
    """Return environment info without executing."""
    info = {
        'platform': platform.system(),
        'kernel': platform.release(),
        'euid': os.geteuid(),
        'tun': Path('/dev/net/tun').exists(),
        'model_exists': (ROOT / CONFIG['model']).is_file(),
        'tools': tools_info(),
    }
    return info

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--inside', action='store_true')
    parser.add_argument('--parent', type=str)
    parser.add_argument('--verify', action='store_true')
    parser.add_argument('--offline', action='store_true')
    args = parser.parse_args()
    out = args.out.resolve()
    try:
        if args.inside and args.parent:
            inside(out, args.parent)
        elif args.verify:
            print(json.dumps(verify(out, offline=args.offline)))
        else:
            print(json.dumps(run(out)))
    except Exception as e:
        out.mkdir(parents=True, exist_ok=True)
        try:
            dump(out / 'failure.json', {
                'status': 'failed_or_blocked',
                'type': type(e).__name__,
                'reason': str(e)
            })
        except Exception:
            pass
        raise

import unittest
from unittest.mock import patch

import z3

from protocol_lab.symbolic import Encoding, encode_trace, crosscheck_trace


def make_accumulator_model():
    return {
        "ir_version": "0.6",
        "semantics": "flat-efsm-atomic-ordered-v1",
        "protocol": "test-acc",
        "scope": {"terminal_states": []},
        "states": ["S"],
        "initial_state": "S",
        "variables": {
            "total": {"type": "int", "initial": 0}
        },
        "events": {
            "add": {"fields": {"n": "int"}}
        },
        "messages": {},
        "timers": {},
        "requirements": {
            "REQ": {
                "source": "tests/test_guard_memo.py",
                "kind": "test",
                "interpretation": "test model"
            }
        },
        "transitions": [
            {
                "id": "ADD",
                "from": "S",
                "to": "S",
                "event": "add",
                "guard": {"op": "ge", "args": [{"event": "n"}, 0]},
                "actions": [
                    {"set": {"var": "total", "value": {"op": "add", "args": [{"var": "total"}, {"event": "n"}]}}}
                ],
                "requirements": ["REQ"]
            }
        ],
        "invariants": []
    }


class TestGuardMemo(unittest.TestCase):

    def test_encoding_requires_third_arg(self):
        model = make_accumulator_model()
        with self.assertRaises(TypeError):
            Encoding(model, 1)  # missing symbolic_initials
        enc = Encoding(model, 1, {})
        self.assertIsNotNone(enc)

    def test_guard_event_cache_no_alias_hazard(self):
        model = make_accumulator_model()
        trace = [
            {"time_ms": 0, "event": {"name": "add", "fields": {"n": 1}}},
            {"time_ms": 1, "event": {"name": "add", "fields": {"n": 2}}},
        ]
        result = crosscheck_trace(model, trace)
        self.assertEqual(result["status"], "ok")
        # If aliasing occurred, the solver would be unsat because the same
        # event variable cannot be both 1 and 2.

    def test_conflicting_guard_reported_unsat(self):
        model = make_accumulator_model()
        model["transitions"][0]["guard"] = False
        trace = [{"time_ms": 0, "event": {"name": "add", "fields": {"n": 1}}}]
        enc = encode_trace(model, trace)
        answer = enc.solve()
        self.assertEqual(answer, z3.unsat)

    def test_interrupted_solve_preserves_smt(self):
        model = make_accumulator_model()
        trace = [{"time_ms": 0, "event": {"name": "add", "fields": {"n": 1}}}]
        enc = encode_trace(model, trace)
        assertions_before = list(enc.solver.assertions())

        with patch.object(enc, "solve", side_effect=z3.Z3Exception("interrupted")):
            with self.assertRaises(z3.Z3Exception):
                enc.solve()

        self.assertEqual(list(enc.solver.assertions()), assertions_before)
        self.assertFalse(hasattr(enc, "_witness"))


if __name__ == "__main__":
    unittest.main()

import copy
import json
import unittest
from pathlib import Path
from unittest.mock import patch

import tools.build_tcp_ipv4_endpoint as builder
from protocol_lab.symbolic import model_hash


class TestTCPIPv4Coupling(unittest.TestCase):
    def setUp(self):
        self.committed_path = builder.OUTPUT_DEFAULT
        with open(self.committed_path, "r", encoding="utf-8") as f:
            self.committed_model = json.load(f)

    def test_build_model_matches_committed_file(self):
        generated = builder.build_model()
        self.assertEqual(generated, self.committed_model)
        self.assertEqual(model_hash(generated), builder.APPROVED_OUTPUT_SHA)

    def test_component_mutation_rejected(self):
        original_ipv4 = builder._read_component("ipv4-udp-icmp")
        original_tcp = builder._read_component("tcp-wire")

        mutated = copy.deepcopy(original_ipv4)
        # Mutate a variable's initial value (numeric) if present, else requirement text.
        for var_name, decl in mutated["variables"].items():
            if "initial" in decl and isinstance(decl["initial"], int):
                decl["initial"] += 1
                break
        else:
            first_key = next(iter(mutated["requirements"]))
            mutated["requirements"][first_key]["interpretation"] += " mutated"

        def mock_read(name):
            if name == "ipv4-udp-icmp":
                return mutated
            if name == "tcp-wire":
                return original_tcp
            raise KeyError(name)

        with patch.object(builder, "_read_component", side_effect=mock_read) as mock_read:
            with self.assertRaisesRegex(ValueError, "semantic hash mismatch"):
                builder.build_model()

        self.assertEqual(builder._read_component("ipv4-udp-icmp"), original_ipv4)
        self.assertEqual(builder._read_component("tcp-wire"), original_tcp)

    def test_expression_based_t_control_rejected_directly(self):
        # Create a fake merged_base with expression assignment to T.control.
        fake_base = {
            "transitions": [
                {
                    "id": "BAD",
                    "actions": [
                        {
                            "set": {
                                "var": "T.control",
                                "value": {"op": "ite", "args": [True, "CLOSED", "LISTEN"]}
                            }
                        }
                    ]
                }
            ]
        }
        with self.assertRaisesRegex(ValueError, "unsupported expression-based T.control"):
            builder._check_expression_based_t_control(fake_base)

    def test_write_output_file_hash_matches_approved(self):
        import tempfile
        import os
        import hashlib

        model = builder.build_model()
        text = json.dumps(model, indent=2) + "\n"
        expected_file_sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
        self.assertEqual(expected_file_sha, builder.APPROVED_OUTPUT_FILE_SHA)

        # Optional: test write_output with a temporary file
        with tempfile.TemporaryDirectory() as tmpdir:
            out_path = Path(tmpdir) / "model.json"
            builder.write_output(model, out_path)
            self.assertEqual(out_path.read_text(encoding="utf-8"), text)


if __name__ == "__main__":
    unittest.main()

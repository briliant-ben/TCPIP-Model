from pathlib import Path
import ast,hashlib,json,os,resource,shutil,subprocess,time,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/tcp-integration-normalize-20261107-0089/validation-0001';O.mkdir(exist_ok=False);PRE=P/'candidates/tcp-integration-normalize-20261107-0089';W=P/'candidates/tcp-coupling-complete-deps-20261107-0081/workspace';G=P/'candidates/tcp-coupling-optimized-validation-20261107-0079';PY=P/'releases/udp-transmit-1b13a36f/venv/bin/python'
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def status(**v):save('status.json',dict(pid=os.getpid(),API_calls=0,production_modified=False,prototype_complete=False,**v))
try:
 status(status='running',stage='static_approval_for_isolated_negative_validation',started_at=time.time())
 src=PRE/'proposals';names=['tools/build_tcp_ipv4_endpoint.py','tests/test_tcp_ipv4_coupling.py','tests/test_guard_memo.py','docs/tcp-ipv4-endpoint.md'];allowed={'argparse','copy','hashlib','json','sys','pathlib','unittest','unittest.mock','tempfile','os','z3','protocol_lab.compose.disjoint_union','protocol_lab.compose.lower_component_state','protocol_lab.compose.namespace_component','protocol_lab.compose.tcp_link','protocol_lab.symbolic','protocol_lab.ir','tools.build_tcp_ipv4_endpoint'}
 for n in names:
  if n.endswith('.py'):
   tree=ast.parse((src/n).read_text())
   for x in ast.walk(tree):
    if isinstance(x,ast.Import):assert all(v.name in allowed for v in x.names),'unexpected import'
    if isinstance(x,ast.ImportFrom):assert x.module in allowed,'unexpected from import'
    if isinstance(x,ast.Call)and isinstance(x.func,ast.Name):assert x.func.id not in ['exec','eval','compile','__import__'],'dynamic execution'
 overlay=O/'workspace';shutil.copytree(W,overlay,ignore=shutil.ignore_patterns('__pycache__'))
 for n in names:
  dst=overlay/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/n,dst)
 shutil.copyfile(G/'round-1/couple_tcp.py',overlay/'protocol_lab/compose/tcp_link.py');shutil.copyfile(G/'validation-0001/candidate-model.json',overlay/'model/tcp-ipv4-endpoint.json')
 save('source-bindings.json',dict(files={n:hashlib.sha256((src/n).read_bytes()).hexdigest()for n in names},scope='isolated nonprivileged tests only, no acceptance or integration'))
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 results=[]
 for pattern in ['test_tcp_ipv4_coupling.py','test_guard_memo.py']:
  status(status='running',stage='actual_isolated_tests',pattern=pattern)
  with(O/(pattern+'.log')).open('w')as log:cp=subprocess.run([str(PY),'-m','unittest','discover','-s','tests','-p',pattern,'-v'],cwd=overlay,stdout=log,stderr=subprocess.STDOUT,timeout=180,preexec_fn=limits,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
  results.append(dict(pattern=pattern,returncode=cp.returncode,log=pattern+'.log'))
 status(status='finite_integration_tests_pass_review_required'if all(r['returncode']==0 for r in results)else'candidate_rejected_by_actual_tests',stage='finished',results=results,finished_at=time.time())
except Exception as e:
 status(status='controller_validation_failed',stage='stopped',error_type=type(e).__name__,error=str(e),finished_at=time.time());(O/'traceback.txt').write_text(traceback.format_exc());raise

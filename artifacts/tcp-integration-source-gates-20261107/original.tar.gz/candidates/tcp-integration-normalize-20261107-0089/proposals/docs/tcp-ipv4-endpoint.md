# Finite TCP/IPv4 Endpoint Model

This document describes the composed finite IR model `model/tcp-ipv4-endpoint.json`,
which couples the pre-existing IPv4/UDP/ICMP endpoint and TCP wire endpoint into a
single monolithic state machine. The model is **not** a general TCP implementation;
it is a **finite offline profile** with explicitly frozen parameters and bounded
behavior, intended for static analysis and bounded verification only.

## Scope and Assembly

- **IR version**: 0.6  
- **Semantics**: `flat-efsm-atomic-ordered-v1` (strict sequential atomic ordered actions).  
- **States**: Single global state `COMPOSED`. Internal component states are lowered
  into explicit string control variables `L.control` (link) and `T.control` (TCP).  
- **Component origins**:  
  - `model/ipv4-udp-icmp-endpoint.json` (lowered, namespaced as `L.*`)  
  - `model/tcp-wire-endpoint.json` (lowered, namespaced as `T.*`)  
- **Merge**: Disjoint union of the two namespaced lowered components, yielding a
  model with **58 variables**, **335 transitions**, and a single `COMPOSED` state.  
- **Coupling**: An approved offline compilation transform (`protocol_lab/compose/tcp_link.py`)
  rewrites the link layer to carry TCP payloads over Ethernet with ARP, adds a shared
  pending owner slot, and injects explicit drop rules for malformed TCP IP lengths.
  All resulting guards and actions are explicit in the flattened authoritative IR.

## Fixed Profile Parameters

All addresses, ports, and bounds are **hard-coded** in the model source. While some
configuration parameters (such as the pending slot TTL and checksum policy) exist
in the model, they are not runtime-modifiable; they are fixed profile constants.
Key constants include:

- Local MAC: `02:00:00:00:00:01`  
- Peer MAC (when resolved): `02:00:00:00:00:02`  
- Local IPv4: `192.0.2.1`  
- Peer IPv4: `192.0.2.2`  
- TCP peer port: `8080`, local TCP port: `40000`  
- Fixed MTU: 1500 bytes; Ethernet frame length bounds `[60,1514]`  
- ARP query retry interval: 1000 ms  
- TCP timers and windows are inherited from the `tcp-wire-endpoint` profile, which
  itself is a finite modern-TCP subset (see inherited limitations below).

## Shared Pending IP Payload and Owner

The IPv4 link already maintained a single `L.pending_packet` byte sequence for
outgoing UDP packets. To accommodate TCP, a new string variable
`ip_pending_owner` records which protocol (`UDP` or `TCP`) currently owns the
pending slot. The invariant `IP-PENDING-OWNER` enforces that the owner is `none`
if and only if the pending packet is empty, and that the owner is always one of
the declared values.  

Transitions that set `L.pending_packet` are updated to also set the owner; when
the slot is cleared, the owner becomes `none`. The link's query-failure handling
is split into `L.QUERY-FAIL-QUEUED-UDP` and `L.QUERY-FAIL-QUEUED-TCP` so that
only UDP receives a send-failure notification.  

When any transition sets `T.control` to the literal string `"CLOSED"`, an explicit
cleanup action is prepended that clears the pending packet and owner **only if**
the owner is `TCP`. This detection relies on literal assignment; expression-based
assignments to `T.control` are **unsupported** and rejected by the builder.

## Ethernet Ingress and TCP Frame Envelope

TCP segments arriving on `L.net.frame` must satisfy a complete binary envelope
checked by `_tcp_frame_envelope_guard()` in the coupling transform. The guard verifies
Ethernet destination/source MACs, EtherType `0x0800`, IPv4 header fields (version,
IHL, total length, protocol 6, source/destination IPs), TCP ports, and exact
frame length consistency (including minimum padding). If a frame fails this
envelope, it is an atomic model gap (`Uncovered`), not an implicit drop.  

Additionally, an explicit drop transition `T.WIRE-DROP-IP-LENGTH-MALFORMED` is
added for frames where the IPv4 total length is `<= 1500` and either `<= 39` or
`>= frame_len - 13`. This drop sets `T.wire_disposition = drop_ip_length`.

## ARP Resolution for TCP Transmit

All `T.ipv4.tx` emissions are transformed into three cases based on `L.control`:

- `EMPTY`: no pending packet, no ARP resolution. The transition buffers the TCP
  packet into `L.pending_packet`, sets owner to `TCP`, resets `L.retry_count`,
  emits an ARP request, arms the `L.query` timer, and switches `L.control` to
  `PENDING`.  
- `PENDING`: ARP query already in progress. The transition simply overwrites the
  pending packet (latest wins) and owner remains `TCP`.  
- `RESOLVED`: the peer MAC is known. The transition builds a full Ethernet frame
  by prefixing destination MAC, local MAC, EtherType, the original IP packet, and
  appropriate padding, then emits it on `L.ethernet.tx`.

## Modeling Choices and Requirements

- `CROSS-IP-LINK`: The coupling introduces a **latest shared pending slot** with a
  single owner. This is a deliberate simplification: no packet queueing, no
  per-flow buffering, and not an RFC mandated policy. Source: this document.  
- `TCP-IP-FRAME-DROP`: An **explicit drop rule** for malformed TCP IP total
  lengths is added as a finite policy, not derived from any RFC. Source:
  this document.

## Inherited Limitations and Known Differences

The underlying `tcp-wire-endpoint` component inherits limitations from the
modern TCP data/window/reassembly subset:

- Limited window management and reassembly; no out-of-order buffering beyond the
  declared window.  
- Fixed timers based on a simplified retransmission model (not full RFC 6298).  
- **UNKNOWN** entries in the original TCP model remain unresolved.  
- **lwIP 2750ms** observation: In the TCP wire profile, the initial RTO is
  1000 ms, while lwIP is observed to use a 2750 ms SYN-loss retransmission
  difference. This is not a confirmed lwIP default or a Linux difference; it is
  an observed discrepancy in the finite profiles.  
- **LinuxTCP Differences**: The model does not replicate Linux-specific TCP
  behaviors such as delayed ACKs, quick ACK mode, or congestion control details.
  Piggyback ACK/window advancement on data and out-of-order reassembly are not
  implemented.

## Verification Status

- **No live composed execution evidence** exists. The model is an offline IR
  artifact; any execution is performed by generated independent C code that
  follows the IR semantics, not by the Python runtime in production.  
- The 45 legacy literal regressions and 18 policy variants passed in the
  approved gate, but **all-input safety is not claimed**.  
- No general compiler or unbounded TCP correctness proof is provided; all
  conclusions are limited to the exact pinned profile.

## Sources and References

- `docs/arp-endpoint.md`, `docs/arp-udp-transmit.md`, `docs/component-state-lowering.md`  
- `docs/ipv4-udp-icmp-endpoint.md`, `docs/tcp-data.md`, `docs/tcp-wire-endpoint.md`  
- `docs/udp-wire-transmit.md`  
- RFC 768, RFC 791, RFC 792, RFC 826, RFC 894, RFC 1122, RFC 6298, RFC 6864, RFC 9293 (relevant sections)

All novel profile choices in this document are explicitly **modeling choices**;
they are not normative protocol requirements.

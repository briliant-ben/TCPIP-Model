; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x25878 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x58385 (= due_1_T.user 30000)))
 (let (($x58384 (= due_1_T.rtx 1000)))
 (let (($x21373 (= due_1_L.cache due_0_L.cache)))
 (let (($x58383 (= due_1_L.query 1000)))
 (let (($x58382 (not active_1_T.time_wait)))
 (let (($x3385 (= active_1_L.cache active_0_L.cache)))
 (let (($x30034 (= v_1_ip_pending_owner "TCP")))
 (let (($x21369 (= v_1_T.control "SYN-SENT")))
 (let (($x58381 (= v_1_T.wire_flags 2)))
 (let ((?x58289 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x18518 (seq.unit (_ bv16 8))))
 (let ((?x73350 (seq.unit (_ bv0 8))))
 (let ((?x21593 (seq.unit (_ bv2 8))))
 (let ((?x21648 (seq.unit (_ bv80 8))))
 (let ((?x58294 (seq.++ ?x73350 (seq.++ ?x21648 (seq.++ ?x21593 (seq.++ ?x73350 (seq.++ ?x18518 ?x58289)))))))
 (let ((?x18812 (seq.unit (_ bv232 8))))
 (let ((?x18810 (seq.unit (_ bv3 8))))
 (let ((?x58299 (seq.++ ?x18810 (seq.++ ?x18812 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x73350 ?x58294)))))))
 (let ((?x18694 (seq.unit (_ bv144 8))))
 (let ((?x18693 (seq.unit (_ bv31 8))))
 (let ((?x18688 (seq.unit (_ bv64 8))))
 (let ((?x58304 (seq.++ ?x18688 (seq.++ ?x18693 (seq.++ ?x18694 (seq.++ ?x73350 (seq.++ ?x73350 ?x58299)))))))
 (let ((?x3692 (seq.unit (_ bv156 8))))
 (let ((?x58305 (seq.++ ?x3692 ?x58304)))
 (let ((?x16950 (seq.unit (_ bv192 8))))
 (let ((?x74866 (seq.unit (_ bv1 8))))
 (let ((?x58346 (seq.++ ?x74866 (seq.++ ?x16950 (seq.++ ?x73350 (seq.++ ?x21593 (seq.++ ?x21593 ?x58305)))))))
 (let ((?x58350 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x16950 (seq.++ ?x73350 (seq.++ ?x21593 ?x58346))))))
 (let ((?x72417 (seq.unit (_ bv6 8))))
 (let ((?x58354 (seq.++ ?x73350 (seq.++ ?x18688 (seq.++ ?x72417 (seq.++ (seq.unit (_ bv182 8)) ?x58350))))))
 (let ((?x18793 (seq.unit (_ bv40 8))))
 (let ((?x58359 (seq.++ ?x73350 (seq.++ ?x18793 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x18688 ?x58354)))))))
 (let ((?x24407 (seq.unit (_ bv69 8))))
 (let ((?x58361 (seq.++ ?x24407 (seq.++ ?x73350 ?x58359))))
 (let (($x58380 (= v_1_T.wire_packet ?x58361)))
 (let ((?x1150 (seq.++ ?x21593 (seq.++ ?x74866 (seq.++ ?x16950 (seq.++ ?x73350 (seq.++ ?x21593 ?x21593)))))))
 (let ((?x1151 (seq.++ ?x72417 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x16950 (seq.++ ?x73350 ?x1150)))))))
 (let ((?x1413 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x18688 (seq.++ ?x73350 (seq.++ ?x18688 ?x1151)))))))
 (let (($x58379 (= v_1_T.wire_ip_zero (seq.++ ?x24407 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x18793 ?x1413)))))))
 (let (($x58378 (= v_1_T.wire_tcp ?x58305)))
 (let ((?x95501 (seq.++ ?x21593 (seq.++ ?x73350 (seq.++ ?x72417 (seq.++ ?x73350 (seq.unit (_ bv20 8))))))))
 (let ((?x18817 (seq.++ ?x21593 (seq.++ ?x74866 (seq.++ ?x16950 (seq.++ ?x73350 (seq.++ ?x21593 ?x95501)))))))
 (let (($x58377 (= v_1_T.wire_pseudo (seq.++ ?x16950 (seq.++ ?x73350 ?x18817)))))
 (let ((?x540 (seq.++ ?x73350 (seq.++ ?x18518 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x73350 ?x73350)))))))
 (let ((?x68036 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x21648 (seq.++ ?x21593 ?x540)))))))
 (let ((?x1500 (seq.++ ?x73350 (seq.++ ?x73350 (seq.++ ?x18810 (seq.++ ?x18812 (seq.++ ?x73350 ?x68036)))))))
 (let (($x58376 (= v_1_T.wire_tcp_zero (seq.++ ?x3692 (seq.++ ?x18688 (seq.++ ?x18693 (seq.++ ?x18694 ?x1500)))))))
 (let (($x58375 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x58374 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x18541 (= v_1_T.take 0)))
 (let (($x2340 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x2462 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x18549 (= v_1_T.snd_wnd 8)))
 (let (($x58373 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x58372 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x58371 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x18932 (= v_1_T.local_window 16)))
 (let (($x18933 (= v_1_T.msl_ms 60000)))
 (let (($x18615 (= v_1_T.user_timeout_ms 30000)))
 (let (($x617 (= 0 v_1_T.retries)))
 (let (($x616 (= 1000 v_1_T.rto_ms)))
 (let (($x69674 (= v_1_T.tx_flags "S")))
 (let (($x18618 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x18619 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x18620 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x58370 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x18622 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x18874 (= v_1_T.irs (_ bv0 32))))
 (let (($x18875 (= v_1_T.iss (_ bv1000 32))))
 (let (($x2694 (= v_1_L.control "PENDING")))
 (let (($x58367 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x58366 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x58365 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x58364 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x58363 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x16009 (not v_1_L.rxudp_require_checksum)))
 (let (($x58362 (= v_1_L.pending_packet ?x58361)))
 (let (($x18885 (= v_1_L.ip_checksum 0)))
 (let (($x18886 (= v_1_L.udp_checksum 0)))
 (let (($x18887 (= v_1_L.udp_raw_checksum 0)))
 (let (($x18888 (= v_1_L.ip_length 0)))
 (let (($x18889 (= v_1_L.udp_length 0)))
 (let (($x18768 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x18767 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x18806 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x18805 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x18804 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x18803 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x18802 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x14049 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x73416 (= 0 v_1_L.retry_count)))
 (let (($x18801 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x73415 (= 0 state_1)))
 (let (($x73721 (not active_0_T.time_wait)))
 (let (($x30013 (or $x73721 (not (<= due_0_T.time_wait 0)))))
 (let (($x73727 (not active_0_T.user)))
 (let (($x30006 (or $x73727 (not (<= due_0_T.user 0)))))
 (let (($x69965 (not active_0_T.rtx)))
 (let (($x30005 (or $x69965 (not (<= due_0_T.rtx 0)))))
 (let (($x32963 (not active_0_L.cache)))
 (let (($x30004 (or $x32963 (not (<= due_0_L.cache 0)))))
 (let (($x1729 (not active_0_L.query)))
 (let (($x30003 (or $x1729 (not (<= due_0_L.query 0)))))
 (let (($x73377 (= state_0 0)))
 (and $x73377 (>= 0 now_0) $x30003 $x30004 $x30005 $x30006 $x30013 $x73415 $x18801 $x73416 $x14049 v_1_L.checksums_enabled $x18802 $x18803 $x18804 $x18805 $x18806 $x18767 $x18768 $x18889 $x18888 $x18887 $x18886 $x18885 $x58362 $x16009 $x58363 (= v_1_L.rxudp_disposition "none") $x58364 $x58365 $x58366 $x58367 (= v_1_L.echo_disposition "none") $x2694 $x18875 $x18874 $x18622 $x58370 $x18620 $x18619 $x18618 $x69674 $x616 $x617 v_1_T.active_open $x18615 $x18933 $x18932 $x58371 $x58372 $x58373 $x18549 $x2462 $x2340 $x18541 $x58374 $x58375 $x58376 $x58377 $x58378 $x58379 $x58380 $x58381 (= v_1_T.wire_disposition "none") $x21369 $x30034 active_1_L.query $x3385 active_1_T.rtx active_1_T.user $x58382 $x58383 $x21373 $x58384 $x58385 $x25878)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x16862 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x16861 (= due_2_T.user due_1_T.user)))
 (let (($x16860 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x16859 (= due_2_L.cache due_1_L.cache)))
 (let (($x16858 (= due_2_L.query due_1_L.query)))
 (let (($x19127 (not active_2_T.time_wait)))
 (let (($x19126 (not active_2_T.user)))
 (let (($x19123 (not active_2_T.rtx)))
 (let (($x16854 (= active_2_L.cache active_1_L.cache)))
 (let (($x16853 (= active_2_L.query active_1_L.query)))
 (let (($x16852 (= v_2_ip_pending_owner (ite (= v_1_ip_pending_owner "TCP") "none" v_1_ip_pending_owner))))
 (let (($x16851 (= v_2_T.control "CLOSED")))
 (let (($x16850 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x16849 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x16848 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x16847 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x16846 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x16845 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x16844 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x16843 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x16842 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x16841 (= v_2_T.take v_1_T.take)))
 (let (($x16840 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x16839 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x16838 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x16837 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x16836 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x16835 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x16834 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x16833 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x16832 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x16831 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x16830 (= v_2_T.retries v_1_T.retries)))
 (let (($x16829 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x16828 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x16827 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x16826 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x16825 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x16824 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x16823 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x16822 (= v_2_T.irs v_1_T.irs)))
 (let (($x16821 (= v_2_T.iss v_1_T.iss)))
 (let (($x16820 (= v_2_L.control v_1_L.control)))
 (let (($x16819 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x16818 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x16817 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x16816 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x16815 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x16814 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x16813 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x16812 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x30034 (= v_1_ip_pending_owner "TCP")))
 (let (($x16811 (= v_2_L.pending_packet (ite $x30034 (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet))))
 (let (($x16810 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x16809 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x16808 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x16807 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x16806 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x16805 (= v_2_L.packet v_1_L.packet)))
 (let (($x16804 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x16803 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x16802 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x16801 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x16800 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x16799 (= v_2_L.payload v_1_L.payload)))
 (let (($x16798 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x16797 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x16796 (= v_2_L.retry_count v_1_L.retry_count)))
 (let (($x16795 (= v_2_L.peer_mac v_1_L.peer_mac)))
 (let (($x16794 (= 0 state_2)))
 (let (($x58382 (not active_1_T.time_wait)))
 (let (($x19084 (or $x58382 (not (<= due_1_T.time_wait 5)))))
 (let (($x19083 (or (not active_1_T.user) (not (<= due_1_T.user 5)))))
 (let (($x19125 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 5)))))
 (let (($x19077 (or (not active_1_L.cache) (not (<= due_1_L.cache 5)))))
 (let (($x14040 (or (not active_1_L.query) (not (<= due_1_L.query 5)))))
 (let (($x21369 (= v_1_T.control "SYN-SENT")))
 (let (($x68057 (= state_1 0)))
 (and $x68057 $x21369 $x14040 $x19077 $x19125 $x19083 $x19084 $x16794 $x16795 $x16796 $x16797 $x16798 $x16799 $x16800 $x16801 $x16802 $x16803 $x16804 $x16805 $x16806 $x16807 $x16808 $x16809 $x16810 $x16811 $x16812 $x16813 $x16814 $x16815 $x16816 $x16817 $x16818 $x16819 $x16820 $x16821 $x16822 $x16823 $x16824 $x16825 $x16826 $x16827 $x16828 $x16829 $x16830 $x16831 $x16832 $x16833 $x16834 $x16835 $x16836 $x16837 $x16838 $x16839 $x16840 $x16841 $x16842 $x16843 $x16844 $x16845 $x16846 $x16847 $x16848 $x16849 $x16850 $x16851 $x16852 $x16853 $x16854 $x19123 $x19126 $x19127 $x16858 $x16859 $x16860 $x16861 $x16862))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 174 choice_1))
(assert
 (= 5 now_2))
(check-sat)

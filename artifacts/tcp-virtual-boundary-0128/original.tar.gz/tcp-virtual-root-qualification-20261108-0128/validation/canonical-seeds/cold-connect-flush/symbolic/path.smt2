; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x74855 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x57674 (= due_1_T.user 30000)))
 (let (($x57673 (= due_1_T.rtx 1000)))
 (let (($x1639 (= due_1_L.cache due_0_L.cache)))
 (let (($x57672 (= due_1_L.query 1000)))
 (let (($x57671 (not active_1_T.time_wait)))
 (let (($x25823 (= active_1_L.cache active_0_L.cache)))
 (let (($x74852 (= v_1_ip_pending_owner "TCP")))
 (let (($x72230 (= v_1_T.control "SYN-SENT")))
 (let (($x57670 (= v_1_T.wire_flags 2)))
 (let ((?x57578 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x69930 (seq.unit (_ bv16 8))))
 (let ((?x58069 (seq.unit (_ bv0 8))))
 (let ((?x15733 (seq.unit (_ bv2 8))))
 (let ((?x75706 (seq.unit (_ bv80 8))))
 (let ((?x57583 (seq.++ ?x58069 (seq.++ ?x75706 (seq.++ ?x15733 (seq.++ ?x58069 (seq.++ ?x69930 ?x57578)))))))
 (let ((?x13069 (seq.unit (_ bv232 8))))
 (let ((?x13067 (seq.unit (_ bv3 8))))
 (let ((?x57588 (seq.++ ?x13067 (seq.++ ?x13069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 ?x57583)))))))
 (let ((?x14137 (seq.unit (_ bv144 8))))
 (let ((?x14136 (seq.unit (_ bv31 8))))
 (let ((?x18553 (seq.unit (_ bv64 8))))
 (let ((?x57593 (seq.++ ?x18553 (seq.++ ?x14136 (seq.++ ?x14137 (seq.++ ?x58069 (seq.++ ?x58069 ?x57588)))))))
 (let ((?x14138 (seq.unit (_ bv156 8))))
 (let ((?x57594 (seq.++ ?x14138 ?x57593)))
 (let ((?x18566 (seq.unit (_ bv192 8))))
 (let ((?x21465 (seq.unit (_ bv1 8))))
 (let ((?x57635 (seq.++ ?x21465 (seq.++ ?x18566 (seq.++ ?x58069 (seq.++ ?x15733 (seq.++ ?x15733 ?x57594)))))))
 (let ((?x57639 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x18566 (seq.++ ?x58069 (seq.++ ?x15733 ?x57635))))))
 (let ((?x21296 (seq.unit (_ bv6 8))))
 (let ((?x57643 (seq.++ ?x58069 (seq.++ ?x18553 (seq.++ ?x21296 (seq.++ (seq.unit (_ bv182 8)) ?x57639))))))
 (let ((?x14481 (seq.unit (_ bv40 8))))
 (let ((?x57648 (seq.++ ?x58069 (seq.++ ?x14481 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x18553 ?x57643)))))))
 (let ((?x1413 (seq.unit (_ bv69 8))))
 (let ((?x57650 (seq.++ ?x1413 (seq.++ ?x58069 ?x57648))))
 (let (($x57669 (= v_1_T.wire_packet ?x57650)))
 (let ((?x19133 (seq.++ ?x15733 (seq.++ ?x21465 (seq.++ ?x18566 (seq.++ ?x58069 (seq.++ ?x15733 ?x15733)))))))
 (let ((?x19010 (seq.++ ?x21296 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x18566 (seq.++ ?x58069 ?x19133)))))))
 (let ((?x95492 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x18553 (seq.++ ?x58069 (seq.++ ?x18553 ?x19010)))))))
 (let (($x57668 (= v_1_T.wire_ip_zero (seq.++ ?x1413 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x14481 ?x95492)))))))
 (let (($x57667 (= v_1_T.wire_tcp ?x57594)))
 (let ((?x14300 (seq.++ ?x15733 (seq.++ ?x58069 (seq.++ ?x21296 (seq.++ ?x58069 (seq.unit (_ bv20 8))))))))
 (let ((?x13964 (seq.++ ?x15733 (seq.++ ?x21465 (seq.++ ?x18566 (seq.++ ?x58069 (seq.++ ?x15733 ?x14300)))))))
 (let (($x57666 (= v_1_T.wire_pseudo (seq.++ ?x18566 (seq.++ ?x58069 ?x13964)))))
 (let ((?x13047 (seq.++ ?x58069 (seq.++ ?x69930 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 ?x58069)))))))
 (let ((?x14122 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x75706 (seq.++ ?x15733 ?x13047)))))))
 (let ((?x13029 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x13067 (seq.++ ?x13069 (seq.++ ?x58069 ?x14122)))))))
 (let (($x57665 (= v_1_T.wire_tcp_zero (seq.++ ?x14138 (seq.++ ?x18553 (seq.++ ?x14136 (seq.++ ?x14137 ?x13029)))))))
 (let (($x57664 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x57663 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x14082 (= v_1_T.take 0)))
 (let (($x14083 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x14324 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x14325 (= v_1_T.snd_wnd 8)))
 (let (($x57662 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x57661 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x57660 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x14329 (= v_1_T.local_window 16)))
 (let (($x14330 (= v_1_T.msl_ms 60000)))
 (let (($x14331 (= v_1_T.user_timeout_ms 30000)))
 (let (($x1493 (= 0 v_1_T.retries)))
 (let (($x806 (= 1000 v_1_T.rto_ms)))
 (let (($x21596 (= v_1_T.tx_flags "S")))
 (let (($x14335 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x14336 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x14337 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x57659 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x14339 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x14340 (= v_1_T.irs (_ bv0 32))))
 (let (($x14432 (= v_1_T.iss (_ bv1000 32))))
 (let (($x17532 (= v_1_L.control "PENDING")))
 (let (($x57656 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x57655 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x57654 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x57653 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x57652 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x11560 (not v_1_L.rxudp_require_checksum)))
 (let (($x57651 (= v_1_L.pending_packet ?x57650)))
 (let (($x14442 (= v_1_L.ip_checksum 0)))
 (let (($x14443 (= v_1_L.udp_checksum 0)))
 (let (($x14444 (= v_1_L.udp_raw_checksum 0)))
 (let (($x14446 (= v_1_L.ip_length 0)))
 (let (($x14447 (= v_1_L.udp_length 0)))
 (let (($x14450 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x14449 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x14431 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x14430 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x27084 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x67842 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x14389 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x14284 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x19120 (= 0 v_1_L.retry_count)))
 (let (($x14388 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x19184 (= 0 state_1)))
 (let (($x75638 (not active_0_T.time_wait)))
 (let (($x14410 (or $x75638 (not (<= due_0_T.time_wait 0)))))
 (let (($x65695 (not active_0_T.user)))
 (let (($x14407 (or $x65695 (not (<= due_0_T.user 0)))))
 (let (($x75639 (not active_0_T.rtx)))
 (let (($x14404 (or $x75639 (not (<= due_0_T.rtx 0)))))
 (let (($x63438 (not active_0_L.cache)))
 (let (($x14385 (or $x63438 (not (<= due_0_L.cache 0)))))
 (let (($x76476 (not active_0_L.query)))
 (let (($x14010 (or $x76476 (not (<= due_0_L.query 0)))))
 (let (($x1961 (= state_0 0)))
 (and $x1961 (>= 0 now_0) $x14010 $x14385 $x14404 $x14407 $x14410 $x19184 $x14388 $x19120 $x14284 v_1_L.checksums_enabled $x14389 $x67842 $x27084 $x14430 $x14431 $x14449 $x14450 $x14447 $x14446 $x14444 $x14443 $x14442 $x57651 $x11560 $x57652 (= v_1_L.rxudp_disposition "none") $x57653 $x57654 $x57655 $x57656 (= v_1_L.echo_disposition "none") $x17532 $x14432 $x14340 $x14339 $x57659 $x14337 $x14336 $x14335 $x21596 $x806 $x1493 v_1_T.active_open $x14331 $x14330 $x14329 $x57660 $x57661 $x57662 $x14325 $x14324 $x14083 $x14082 $x57663 $x57664 $x57665 $x57666 $x57667 $x57668 $x57669 $x57670 (= v_1_T.wire_disposition "none") $x72230 $x74852 active_1_L.query $x25823 active_1_T.rtx active_1_T.user $x57671 $x57672 $x1639 $x57673 $x57674 $x74855)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x11425 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x11424 (= due_2_T.user due_1_T.user)))
 (let (($x11423 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x11421 (= due_2_L.query due_1_L.query)))
 (let (($x11420 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x11419 (= active_2_T.user active_1_T.user)))
 (let (($x11418 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x14046 (not active_2_L.query)))
 (let (($x11415 (= v_2_ip_pending_owner "none")))
 (let (($x11414 (= v_2_T.control v_1_T.control)))
 (let (($x11413 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x11412 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x11411 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x11410 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x11409 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x11408 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x11407 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x11406 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x11405 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x11404 (= v_2_T.take v_1_T.take)))
 (let (($x11403 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x11402 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x11401 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x11400 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x11399 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x11398 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x11397 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x11396 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x11395 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x11394 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x11393 (= v_2_T.retries v_1_T.retries)))
 (let (($x11392 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x11391 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x11390 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x11389 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x11388 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x11387 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x11386 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x11385 (= v_2_T.irs v_1_T.irs)))
 (let (($x11384 (= v_2_T.iss v_1_T.iss)))
 (let (($x11383 (= v_2_L.control "RESOLVED")))
 (let (($x11382 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x11381 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x11380 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x11379 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x11378 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x11377 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x11376 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x11375 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x67843 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x11373 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x11372 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x11371 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x11370 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x11369 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x11368 (= v_2_L.packet v_1_L.packet)))
 (let (($x11367 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x11366 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x11365 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x11364 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x11363 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x11362 (= v_2_L.payload v_1_L.payload)))
 (let (($x11361 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x11360 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x11359 (= 0 v_2_L.retry_count)))
 (let ((?x58069 (seq.unit (_ bv0 8))))
 (let ((?x74914 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.unit (_ bv2 8))))))))
 (let ((?x15733 (seq.unit (_ bv2 8))))
 (let ((?x18626 (seq.++ ?x15733 ?x74914)))
 (let (($x72453 (= v_2_L.peer_mac ?x18626)))
 (let (($x11357 (= 0 state_2)))
 (let (($x57671 (not active_1_T.time_wait)))
 (let (($x14031 (or $x57671 (not (<= due_1_T.time_wait 10)))))
 (let (($x14087 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x14206 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x3158 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x13025 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x11314 (seq.len v_1_L.pending_packet)))
 (let (($x11315 (<= 28 ?x11314)))
 (let (($x17532 (= v_1_L.control "PENDING")))
 (let (($x62411 (= state_1 0)))
 (and $x62411 $x17532 $x11315 $x13025 $x3158 $x14206 $x14087 $x14031 $x11357 $x72453 $x11359 $x11360 $x11361 $x11362 $x11363 $x11364 $x11365 $x11366 $x11367 $x11368 $x11369 $x11370 $x11371 $x11372 $x11373 $x67843 $x11375 $x11376 $x11377 $x11378 $x11379 $x11380 $x11381 $x11382 $x11383 $x11384 $x11385 $x11386 $x11387 $x11388 $x11389 $x11390 $x11391 $x11392 $x11393 $x11394 $x11395 $x11396 $x11397 $x11398 $x11399 $x11400 $x11401 $x11402 $x11403 $x11404 $x11405 $x11406 $x11407 $x11408 $x11409 $x11410 $x11411 $x11412 $x11413 $x11414 $x11415 $x14046 active_2_L.cache $x11418 $x11419 $x11420 $x11421 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x11423 $x11424 $x11425)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 29 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x18566 (seq.unit (_ bv192 8))))
(let ((?x76375 (seq.++ ?x18566 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
(let ((?x21465 (seq.unit (_ bv1 8))))
(let ((?x58069 (seq.unit (_ bv0 8))))
(let ((?x57333 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x21465 ?x76375)))))))
(let ((?x15733 (seq.unit (_ bv2 8))))
(let ((?x57338 (seq.++ ?x18566 (seq.++ ?x58069 (seq.++ ?x15733 (seq.++ ?x15733 (seq.++ ?x15733 ?x57333)))))))
(let ((?x57343 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x15733 ?x57338)))))))
(let ((?x669 (seq.unit (_ bv4 8))))
(let ((?x21296 (seq.unit (_ bv6 8))))
(let ((?x57348 (seq.++ ?x21296 (seq.++ ?x669 (seq.++ ?x58069 (seq.++ ?x15733 (seq.++ ?x15733 ?x57343)))))))
(let ((?x19195 (seq.unit (_ bv8 8))))
(let ((?x57353 (seq.++ ?x21296 (seq.++ ?x58069 (seq.++ ?x21465 (seq.++ ?x19195 (seq.++ ?x58069 ?x57348)))))))
(let ((?x57358 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x15733 (seq.++ ?x19195 ?x57353)))))))
(let ((?x57363 (seq.++ ?x58069 (seq.++ ?x58069 (seq.++ ?x21465 (seq.++ ?x15733 (seq.++ ?x58069 ?x57358)))))))
(let ((?x57366 (seq.++ ?x15733 (seq.++ ?x58069 (seq.++ ?x58069 ?x57363)))))
(= input_1_L.net.frame_frame ?x57366))))))))))))))))))
(check-sat)

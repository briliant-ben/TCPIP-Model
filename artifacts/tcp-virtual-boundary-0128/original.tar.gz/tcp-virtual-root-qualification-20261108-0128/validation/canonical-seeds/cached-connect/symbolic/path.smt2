; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun input_0_L.app.resolve_ip () (Seq (_ BitVec 8)))
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(define-funs-rec ( ( ir4_ones_sum16_checksum_instance!7
                     ((x!1 (Seq (_ BitVec 8))))
                     (_ BitVec 16)))
                 ( (let ((a!1 (concat (seq.nth x!1 0)
                                      (ite (> (seq.len x!1) 1)
                                           (seq.nth x!1 1)
                                           #x00)))
                         (a!2 (seq.extract x!1
                                           2
                                           (ite (> (seq.len x!1) 2)
                                                (- (seq.len x!1) 2)
                                                0))))
                   (let ((a!3 ((_ extract 15 0)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!7
                                             0)
                                           a!2)))))
                         (a!4 ((_ extract 16 16)
                                (bvadd ((_ zero_extend 1) a!1)
                                       ((_ zero_extend 1)
                                         ((_ ir4_ones_sum16_checksum_instance!7
                                             0)
                                           a!2))))))
                     (ite (= (seq.len x!1) 0)
                          #x0000
                          (bvadd a!3 ((_ zero_extend 15) a!4)))))))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x18542 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x58236 (= due_1_T.user due_0_T.user)))
 (let (($x58207 (= due_1_T.rtx due_0_T.rtx)))
 (let (($x18505 (= due_1_L.cache due_0_L.cache)))
 (let (($x764 (= due_1_L.query 1000)))
 (let (($x18502 (= active_1_T.time_wait active_0_T.time_wait)))
 (let (($x18843 (= active_1_T.user active_0_T.user)))
 (let (($x18842 (= active_1_T.rtx active_0_T.rtx)))
 (let (($x18877 (= active_1_L.cache active_0_L.cache)))
 (let (($x14503 (= v_1_T.control "CLOSED")))
 (let (($x75582 (= v_1_T.wire_flags 0)))
 (let (($x16841 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_packet)))
 (let (($x73629 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_ip_zero)))
 (let (($x75528 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp)))
 (let (($x75530 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_pseudo)))
 (let (($x75529 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_tcp_zero)))
 (let (($x75788 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x75787 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x75675 (= v_1_T.take 0)))
 (let (($x75676 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x75636 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x75637 (= v_1_T.snd_wnd 8)))
 (let (($x75753 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x75752 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x76236 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x75660 (= v_1_T.local_window 16)))
 (let (($x75661 (= v_1_T.msl_ms 60000)))
 (let (($x75579 (= v_1_T.user_timeout_ms 30000)))
 (let (($x75580 (= v_1_T.retries 0)))
 (let (($x75608 (= v_1_T.rto_ms 1000)))
 (let (($x75610 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x75585 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x75606 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x75607 (= v_1_T.snd_nxt (_ bv1000 32))))
 (let (($x16814 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x65978 (= v_1_T.irs (_ bv0 32))))
 (let (($x95872 (= v_1_T.iss (_ bv1000 32))))
 (let (($x95452 (= v_1_L.control "PENDING")))
 (let (($x76235 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x76234 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x76233 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x76232 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x76231 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x14333 (not v_1_L.rxudp_require_checksum)))
 (let (($x76230 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pending_packet)))
 (let (($x63439 (= v_1_L.ip_checksum 0)))
 (let (($x65696 (= v_1_L.udp_checksum 0)))
 (let (($x95530 (= v_1_L.udp_raw_checksum 0)))
 (let (($x63440 (= v_1_L.ip_length 0)))
 (let (($x1898 (= v_1_L.udp_length 0)))
 (let (($x76229 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x76228 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x76227 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x76226 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x76225 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x76224 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x76223 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x17625 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x58378 (= 0 v_1_L.retry_count)))
 (let (($x76222 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x58376 (= 0 state_1)))
 (let (($x24492 (not active_0_T.time_wait)))
 (let (($x76221 (or $x24492 (not (<= due_0_T.time_wait 0)))))
 (let (($x16848 (not active_0_T.user)))
 (let (($x76330 (or $x16848 (not (<= due_0_T.user 0)))))
 (let (($x75272 (not active_0_T.rtx)))
 (let (($x75988 (or $x75272 (not (<= due_0_T.rtx 0)))))
 (let (($x73583 (not active_0_L.cache)))
 (let (($x75978 (or $x73583 (not (<= due_0_L.cache 0)))))
 (let (($x16846 (not active_0_L.query)))
 (let (($x75751 (or $x16846 (not (<= due_0_L.query 0)))))
 (let (($x73753 (= state_0 0)))
 (and $x73753 (>= 0 now_0) $x75751 $x75978 $x75988 $x76330 $x76221 $x58376 $x76222 $x58378 $x17625 v_1_L.checksums_enabled $x76223 $x76224 $x76225 $x76226 $x76227 $x76228 $x76229 $x1898 $x63440 $x95530 $x65696 $x63439 $x76230 $x14333 $x76231 (= v_1_L.rxudp_disposition "none") $x76232 $x76233 $x76234 $x76235 (= v_1_L.echo_disposition "none") $x95452 $x95872 $x65978 $x16814 $x75607 $x75606 $x75585 $x75610 (= v_1_T.tx_flags "S") $x75608 $x75580 v_1_T.active_open $x75579 $x75661 $x75660 $x76236 $x75752 $x75753 $x75637 $x75636 $x75676 $x75675 $x75787 $x75788 $x75529 $x75530 $x75528 $x73629 $x16841 $x75582 (= v_1_T.wire_disposition "none") $x14503 (= v_1_ip_pending_owner "none") active_1_L.query $x18877 $x18842 $x18843 $x18502 $x764 $x18505 $x58207 $x58236 $x18542))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x14201 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x14200 (= due_2_T.user due_1_T.user)))
 (let (($x14199 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x14197 (= due_2_L.query due_1_L.query)))
 (let (($x14196 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x14195 (= active_2_T.user active_1_T.user)))
 (let (($x14194 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x76476 (not active_2_L.query)))
 (let (($x14191 (= v_2_ip_pending_owner v_1_ip_pending_owner)))
 (let (($x14190 (= v_2_T.control v_1_T.control)))
 (let (($x14189 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x14188 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x14187 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x14186 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x14185 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x14184 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x14183 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x14182 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x14181 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x14180 (= v_2_T.take v_1_T.take)))
 (let (($x14179 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x14178 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x14177 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x14176 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x14175 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x14174 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x14173 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x14172 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x14171 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x14170 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x14169 (= v_2_T.retries v_1_T.retries)))
 (let (($x14168 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x14167 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x14166 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x14165 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x14164 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x14163 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x14162 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x14161 (= v_2_T.irs v_1_T.irs)))
 (let (($x14160 (= v_2_T.iss v_1_T.iss)))
 (let (($x14159 (= v_2_L.control "RESOLVED")))
 (let (($x14158 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x14157 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x14156 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x14155 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x14154 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x14153 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x14152 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x14151 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x14150 (= v_2_L.pending_packet v_1_L.pending_packet)))
 (let (($x14149 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x14148 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x14147 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x14146 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x14145 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x14144 (= v_2_L.packet v_1_L.packet)))
 (let (($x14143 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x14142 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x14141 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x14140 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x14139 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x14138 (= v_2_L.payload v_1_L.payload)))
 (let (($x14137 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x14136 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x14135 (= 0 v_2_L.retry_count)))
 (let ((?x21414 (seq.unit (_ bv0 8))))
 (let ((?x2234 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.unit (_ bv2 8))))))))
 (let ((?x73355 (seq.unit (_ bv2 8))))
 (let ((?x21395 (seq.++ ?x73355 ?x2234)))
 (let (($x21288 (= v_2_L.peer_mac ?x21395)))
 (let (($x14133 (= 0 state_2)))
 (let (($x694 (or (not active_1_T.time_wait) (not (<= due_1_T.time_wait 10)))))
 (let (($x76472 (or (not active_1_T.user) (not (<= due_1_T.user 10)))))
 (let (($x76468 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 10)))))
 (let (($x76464 (or (not active_1_L.cache) (not (<= due_1_L.cache 10)))))
 (let (($x76460 (or (not active_1_L.query) (not (<= due_1_L.query 10)))))
 (let ((?x14102 (seq.len v_1_L.pending_packet)))
 (let (($x14112 (= 0 ?x14102)))
 (let (($x95452 (= v_1_L.control "PENDING")))
 (let (($x1831 (= state_1 0)))
 (and $x1831 $x95452 $x14112 $x76460 $x76464 $x76468 $x76472 $x694 $x14133 $x21288 $x14135 $x14136 $x14137 $x14138 $x14139 $x14140 $x14141 $x14142 $x14143 $x14144 $x14145 $x14146 $x14147 $x14148 $x14149 $x14150 $x14151 $x14152 $x14153 $x14154 $x14155 $x14156 $x14157 $x14158 $x14159 $x14160 $x14161 $x14162 $x14163 $x14164 $x14165 $x14166 $x14167 $x14168 $x14169 $x14170 $x14171 $x14172 $x14173 $x14174 $x14175 $x14176 $x14177 $x14178 $x14179 $x14180 $x14181 $x14182 $x14183 $x14184 $x14185 $x14186 $x14187 $x14188 $x14189 $x14190 $x14191 $x76476 active_2_L.cache $x14194 $x14195 $x14196 $x14197 (= due_2_L.cache (+ 10 v_1_L.cache_ttl_ms)) $x14199 $x14200 $x14201))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x18814 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x76305 (= due_3_T.rtx 1020)))
 (let (($x18798 (= due_3_L.cache due_2_L.cache)))
 (let (($x18797 (= due_3_L.query due_2_L.query)))
 (let (($x76424 (not active_3_T.time_wait)))
 (let (($x18828 (= active_3_L.cache active_2_L.cache)))
 (let (($x18827 (= active_3_L.query active_2_L.query)))
 (let (($x18905 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x58023 (= v_3_T.control "SYN-SENT")))
 (let (($x58022 (= v_3_T.wire_disposition v_2_T.wire_disposition)))
 (let (($x75768 (= v_3_T.wire_flags 2)))
 (let ((?x21414 (seq.unit (_ bv0 8))))
 (let ((?x58366 (seq.++ ?x21414 ?x21414)))
 (let ((?x18876 (seq.++ ?x21414 (seq.++ ?x21414 ?x58366))))
 (let ((?x58956 (seq.unit ((_ extract 7 0) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x95808 (seq.unit ((_ extract 15 8) ((_ int_to_bv 16) v_2_T.local_window)))))
 (let ((?x73355 (seq.unit (_ bv2 8))))
 (let ((?x73841 (seq.unit (_ bv80 8))))
 (let ((?x76356 (seq.++ ?x21414 (seq.++ ?x73841 (seq.++ ?x73355 (seq.++ ?x95808 (seq.++ ?x58956 ?x18876)))))))
 (let ((?x17665 (seq.unit ((_ extract 7 0) v_2_T.iss))))
 (let ((?x24560 (seq.unit ((_ extract 15 8) v_2_T.iss))))
 (let ((?x76399 (seq.++ ?x24560 (seq.++ ?x17665 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 ?x76356)))))))
 (let ((?x17660 (seq.unit ((_ extract 23 16) v_2_T.iss))))
 (let ((?x17651 (seq.unit ((_ extract 31 24) v_2_T.iss))))
 (let ((?x72032 (seq.unit (_ bv144 8))))
 (let ((?x74893 (seq.unit (_ bv31 8))))
 (let ((?x69793 (seq.unit (_ bv64 8))))
 (let ((?x75739 (seq.++ ?x69793 (seq.++ ?x74893 (seq.++ ?x72032 (seq.++ ?x17651 (seq.++ ?x17660 ?x76399)))))))
 (let ((?x34511 (seq.unit (_ bv156 8))))
 (let ((?x75740 (seq.++ ?x34511 ?x75739)))
 (let ((?x76076 (seq.unit (_ bv20 8))))
 (let ((?x18803 (seq.unit (_ bv6 8))))
 (let ((?x76181 (seq.++ ?x73355 (seq.++ ?x21414 (seq.++ ?x18803 (seq.++ ?x21414 (seq.++ ?x76076 ?x75740)))))))
 (let ((?x73377 (seq.unit (_ bv192 8))))
 (let ((?x73721 (seq.unit (_ bv1 8))))
 (let ((?x1932 (seq.++ ?x73355 (seq.++ ?x73721 (seq.++ ?x73377 (seq.++ ?x21414 (seq.++ ?x73355 ?x76181)))))))
 (let ((?x29895 ((_ ir4_ones_sum16_checksum_instance!7 0) (seq.++ ?x73377 (seq.++ ?x21414 ?x1932)))))
 (let ((?x76006 (seq.++ (seq.unit (bvnot ((_ extract 15 8) ?x29895))) (seq.++ (seq.unit (bvnot ((_ extract 7 0) ?x29895))) ?x58366))))
 (let ((?x76012 (seq.++ ?x21414 (seq.++ ?x73841 (seq.++ ?x73355 (seq.++ ?x95808 (seq.++ ?x58956 ?x76006)))))))
 (let ((?x76017 (seq.++ ?x24560 (seq.++ ?x17665 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 ?x76012)))))))
 (let ((?x76022 (seq.++ ?x69793 (seq.++ ?x74893 (seq.++ ?x72032 (seq.++ ?x17651 (seq.++ ?x17660 ?x76017)))))))
 (let ((?x76023 (seq.++ ?x34511 ?x76022)))
 (let ((?x76247 (seq.++ ?x73721 (seq.++ ?x73377 (seq.++ ?x21414 (seq.++ ?x73355 (seq.++ ?x73355 ?x76023)))))))
 (let ((?x76057 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x73377 (seq.++ ?x21414 (seq.++ ?x73355 ?x76247))))))
 (let ((?x76098 (seq.++ ?x21414 (seq.++ ?x69793 (seq.++ ?x18803 (seq.++ (seq.unit (_ bv182 8)) ?x76057))))))
 (let ((?x75680 (seq.unit (_ bv40 8))))
 (let ((?x17691 (seq.++ ?x21414 (seq.++ ?x75680 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x69793 ?x76098)))))))
 (let ((?x71609 (seq.unit (_ bv69 8))))
 (let (($x75767 (= v_3_T.wire_packet (seq.++ ?x71609 (seq.++ ?x21414 ?x17691)))))
 (let ((?x18555 (seq.++ ?x73355 (seq.++ ?x73721 (seq.++ ?x73377 (seq.++ ?x21414 (seq.++ ?x73355 ?x73355)))))))
 (let ((?x18515 (seq.++ ?x18803 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x73377 (seq.++ ?x21414 ?x18555)))))))
 (let ((?x18931 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x69793 (seq.++ ?x21414 (seq.++ ?x69793 ?x18515)))))))
 (let (($x76175 (= v_3_T.wire_ip_zero (seq.++ ?x71609 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x75680 ?x18931)))))))
 (let (($x75533 (= v_3_T.wire_tcp ?x76023)))
 (let ((?x76357 (seq.++ ?x73355 (seq.++ ?x73355 (seq.++ ?x21414 (seq.++ ?x18803 (seq.++ ?x21414 ?x76076)))))))
 (let ((?x75629 (seq.++ ?x21414 (seq.++ ?x73355 (seq.++ ?x73721 (seq.++ ?x73377 (seq.++ ?x21414 ?x76357)))))))
 (let (($x76240 (= v_3_T.wire_pseudo (seq.++ ?x73377 ?x75629))))
 (let (($x76073 (= v_3_T.wire_tcp_zero ?x75740)))
 (let (($x17646 (= (as seq.empty (Seq (_ BitVec 8))) v_3_T.wire_data)))
 (let (($x24174 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x73852 (= v_3_T.take v_2_T.take)))
 (let (($x585 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x24133 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x22974 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x22975 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x2569 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x30186 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x24553 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x18986 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x19195 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x67695 (= 0 v_3_T.retries)))
 (let (($x24545 (= 1000 v_3_T.rto_ms)))
 (let (($x67694 (= v_3_T.tx_flags "S")))
 (let (($x17643 (= v_3_T.tx_ack (_ bv0 32))))
 (let (($x69995 (= v_3_T.tx_seq v_2_T.iss)))
 (let (($x73706 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x17644 (= v_3_T.snd_nxt (bvadd (_ bv1 32) v_2_T.iss))))
 (let (($x73367 (= v_3_T.snd_una v_2_T.iss)))
 (let (($x21465 (= v_3_T.irs v_2_T.irs)))
 (let (($x24065 (= v_3_T.iss v_2_T.iss)))
 (let (($x21476 (= v_3_L.control v_2_L.control)))
 (let (($x18499 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x25855 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x70646 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x68456 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x68335 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x2298 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x3187 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x95459 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x19163 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x19160 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x58227 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x58226 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x1341 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x72658 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x19089 (= v_3_L.packet v_2_L.packet)))
 (let (($x29986 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x17524 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x58388 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x58072 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x58071 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x58070 (= v_3_L.payload v_2_L.payload)))
 (let (($x58069 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x58068 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x58067 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x58066 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x58065 (= 0 state_3)))
 (let (($x17619 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 20)))))
 (let (($x16844 (or (not active_2_T.user) (not (<= due_2_T.user 20)))))
 (let (($x16824 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 20)))))
 (let (($x2745 (or (not active_2_L.cache) (not (<= due_2_L.cache 20)))))
 (let (($x76476 (not active_2_L.query)))
 (let (($x75639 (or $x76476 (not (<= due_2_L.query 20)))))
 (let (($x14159 (= v_2_L.control "RESOLVED")))
 (let (($x58081 (= v_2_T.control "CLOSED")))
 (let (($x17707 (= state_2 0)))
 (and $x17707 $x58081 $x14159 $x75639 $x2745 $x16824 $x16844 $x17619 $x58065 $x58066 $x58067 $x58068 $x58069 $x58070 $x58071 $x58072 $x58388 $x17524 $x29986 $x19089 $x72658 $x1341 $x58226 $x58227 $x19160 $x19163 $x95459 $x3187 $x2298 $x68335 $x68456 $x70646 $x25855 $x18499 $x21476 $x24065 $x21465 $x73367 $x17644 $x73706 $x69995 $x17643 $x67694 $x24545 $x67695 v_3_T.active_open $x19195 $x18986 $x24553 $x30186 $x2569 $x22975 $x22974 $x24133 $x585 $x73852 $x24174 $x17646 $x76073 $x76240 $x75533 $x76175 $x75767 $x75768 $x58022 $x58023 $x18905 $x18827 $x18828 active_3_T.rtx active_3_T.user $x76424 $x18797 $x18798 $x76305 (= due_3_T.user (+ 20 v_2_T.user_timeout_ms)) $x18814))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 0 choice_0))
(assert
 (= 0 now_1))
(assert
 (let ((?x73377 (seq.unit (_ bv192 8))))
 (let ((?x30002 (seq.++ ?x73377 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv2 8)))))))
 (= input_0_L.app.resolve_ip ?x30002))))
(assert
 (= 30 choice_1))
(assert
 (= 10 now_2))
(assert
 (let ((?x73377 (seq.unit (_ bv192 8))))
 (let ((?x58364 (seq.++ ?x73377 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x73721 (seq.unit (_ bv1 8))))
 (let ((?x21414 (seq.unit (_ bv0 8))))
 (let ((?x21284 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x73721 ?x58364)))))))
 (let ((?x73355 (seq.unit (_ bv2 8))))
 (let ((?x75232 (seq.++ ?x73377 (seq.++ ?x21414 (seq.++ ?x73355 (seq.++ ?x73355 (seq.++ ?x73355 ?x21284)))))))
 (let ((?x21630 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x73355 ?x75232)))))))
 (let ((?x18805 (seq.unit (_ bv4 8))))
 (let ((?x18803 (seq.unit (_ bv6 8))))
 (let ((?x75237 (seq.++ ?x18803 (seq.++ ?x18805 (seq.++ ?x21414 (seq.++ ?x73355 (seq.++ ?x73355 ?x21630)))))))
 (let ((?x14049 (seq.unit (_ bv8 8))))
 (let ((?x21558 (seq.++ ?x18803 (seq.++ ?x21414 (seq.++ ?x73721 (seq.++ ?x14049 (seq.++ ?x21414 ?x75237)))))))
 (let ((?x20359 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x73355 (seq.++ ?x14049 ?x21558)))))))
 (let ((?x21853 (seq.++ ?x21414 (seq.++ ?x21414 (seq.++ ?x73721 (seq.++ ?x73355 (seq.++ ?x21414 ?x20359)))))))
 (let ((?x20374 (seq.++ ?x73355 (seq.++ ?x21414 (seq.++ ?x21414 ?x21853)))))
 (= input_1_L.net.frame_frame ?x20374))))))))))))))))))
(assert
 (= 66 choice_2))
(assert
 (= 20 now_3))
(check-sat)

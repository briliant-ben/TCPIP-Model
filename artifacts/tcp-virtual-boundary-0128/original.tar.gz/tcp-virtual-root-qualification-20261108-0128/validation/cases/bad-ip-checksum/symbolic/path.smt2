; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x70613 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x73933 (= due_1_T.user 30000)))
 (let (($x72068 (= due_1_T.rtx 1000)))
 (let (($x70495 (= due_1_L.cache due_0_L.cache)))
 (let (($x72079 (= due_1_L.query 1000)))
 (let (($x72547 (not active_1_T.time_wait)))
 (let (($x1899 (= active_1_L.cache active_0_L.cache)))
 (let (($x2079 (= v_1_ip_pending_owner "TCP")))
 (let (($x28699 (= v_1_T.control "SYN-SENT")))
 (let (($x24448 (= v_1_T.wire_flags 2)))
 (let ((?x65590 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x20336 (seq.unit (_ bv16 8))))
 (let ((?x70240 (seq.unit (_ bv0 8))))
 (let ((?x73370 (seq.unit (_ bv2 8))))
 (let ((?x2306 (seq.unit (_ bv80 8))))
 (let ((?x21296 (seq.++ ?x70240 (seq.++ ?x2306 (seq.++ ?x73370 (seq.++ ?x70240 (seq.++ ?x20336 ?x65590)))))))
 (let ((?x21918 (seq.unit (_ bv232 8))))
 (let ((?x32894 (seq.unit (_ bv3 8))))
 (let ((?x21838 (seq.++ ?x32894 (seq.++ ?x21918 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 ?x21296)))))))
 (let ((?x21428 (seq.unit (_ bv144 8))))
 (let ((?x73677 (seq.unit (_ bv31 8))))
 (let ((?x72141 (seq.unit (_ bv64 8))))
 (let ((?x21550 (seq.++ ?x72141 (seq.++ ?x73677 (seq.++ ?x21428 (seq.++ ?x70240 (seq.++ ?x70240 ?x21838)))))))
 (let ((?x21430 (seq.unit (_ bv156 8))))
 (let ((?x21551 (seq.++ ?x21430 ?x21550)))
 (let ((?x73369 (seq.unit (_ bv192 8))))
 (let ((?x73393 (seq.unit (_ bv1 8))))
 (let ((?x1619 (seq.++ ?x73393 (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 (seq.++ ?x73370 ?x21551)))))))
 (let ((?x27214 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 ?x1619))))))
 (let ((?x2130 (seq.unit (_ bv6 8))))
 (let ((?x30258 (seq.++ ?x70240 (seq.++ ?x72141 (seq.++ ?x2130 (seq.++ (seq.unit (_ bv182 8)) ?x27214))))))
 (let ((?x21204 (seq.unit (_ bv40 8))))
 (let ((?x749 (seq.++ ?x70240 (seq.++ ?x21204 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x72141 ?x30258)))))))
 (let ((?x70143 (seq.unit (_ bv69 8))))
 (let ((?x3578 (seq.++ ?x70143 (seq.++ ?x70240 ?x749))))
 (let (($x21962 (= v_1_T.wire_packet ?x3578)))
 (let ((?x61553 (seq.++ ?x73370 (seq.++ ?x73393 (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 ?x73370)))))))
 (let ((?x33226 (seq.++ ?x2130 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x73369 (seq.++ ?x70240 ?x61553)))))))
 (let ((?x61557 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x72141 (seq.++ ?x70240 (seq.++ ?x72141 ?x33226)))))))
 (let (($x20401 (= v_1_T.wire_ip_zero (seq.++ ?x70143 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x21204 ?x61557)))))))
 (let (($x20404 (= v_1_T.wire_tcp ?x21551)))
 (let ((?x75274 (seq.++ ?x73370 (seq.++ ?x70240 (seq.++ ?x2130 (seq.++ ?x70240 (seq.unit (_ bv20 8))))))))
 (let ((?x75277 (seq.++ ?x73370 (seq.++ ?x73393 (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 ?x75274)))))))
 (let (($x20403 (= v_1_T.wire_pseudo (seq.++ ?x73369 (seq.++ ?x70240 ?x75277)))))
 (let ((?x21529 (seq.++ ?x70240 (seq.++ ?x20336 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 ?x70240)))))))
 (let ((?x95872 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x2306 (seq.++ ?x73370 ?x21529)))))))
 (let ((?x20332 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x32894 (seq.++ ?x21918 (seq.++ ?x70240 ?x95872)))))))
 (let (($x75389 (= v_1_T.wire_tcp_zero (seq.++ ?x21430 (seq.++ ?x72141 (seq.++ ?x73677 (seq.++ ?x21428 ?x20332)))))))
 (let (($x75392 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x75391 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x75095 (= v_1_T.take 0)))
 (let (($x75098 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x75099 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x75100 (= v_1_T.snd_wnd 8)))
 (let (($x1909 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x1276 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x32821 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x75106 (= v_1_T.local_window 16)))
 (let (($x59694 (= v_1_T.msl_ms 60000)))
 (let (($x21923 (= v_1_T.user_timeout_ms 30000)))
 (let (($x1427 (= 0 v_1_T.retries)))
 (let (($x1426 (= 1000 v_1_T.rto_ms)))
 (let (($x25849 (= v_1_T.tx_flags "S")))
 (let (($x158 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x231 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x161 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x70485 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x75226 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x75227 (= v_1_T.irs (_ bv0 32))))
 (let (($x60377 (= v_1_T.iss (_ bv1000 32))))
 (let (($x26922 (= v_1_L.control "PENDING")))
 (let (($x30187 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x27400 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x72618 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x69709 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x67869 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x18865 (not v_1_L.rxudp_require_checksum)))
 (let (($x62529 (= v_1_L.pending_packet ?x3578)))
 (let (($x21315 (= v_1_L.ip_checksum 0)))
 (let (($x21316 (= v_1_L.udp_checksum 0)))
 (let (($x21317 (= v_1_L.udp_raw_checksum 0)))
 (let (($x21318 (= v_1_L.ip_length 0)))
 (let (($x21463 (= v_1_L.udp_length 0)))
 (let (($x21322 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x166 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x236 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x64416 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x165 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x235 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x64415 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x21340 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x26936 (= 0 v_1_L.retry_count)))
 (let (($x164 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x26966 (= 0 state_1)))
 (let (($x73358 (not active_0_T.time_wait)))
 (let (($x234 (or $x73358 (not (<= due_0_T.time_wait 0)))))
 (let (($x30336 (not active_0_T.user)))
 (let (($x21436 (or $x30336 (not (<= due_0_T.user 0)))))
 (let (($x29932 (not active_0_T.rtx)))
 (let (($x21433 (or $x29932 (not (<= due_0_T.rtx 0)))))
 (let (($x73356 (not active_0_L.cache)))
 (let (($x3237 (or $x73356 (not (<= due_0_L.cache 0)))))
 (let (($x27333 (not active_0_L.query)))
 (let (($x21714 (or $x27333 (not (<= due_0_L.query 0)))))
 (let (($x1066 (= state_0 0)))
 (and $x1066 (>= 0 now_0) $x21714 $x3237 $x21433 $x21436 $x234 $x26966 $x164 $x26936 $x21340 v_1_L.checksums_enabled $x64415 $x235 $x165 $x64416 $x236 $x166 $x21322 $x21463 $x21318 $x21317 $x21316 $x21315 $x62529 $x18865 $x67869 (= v_1_L.rxudp_disposition "none") $x69709 $x72618 $x27400 $x30187 (= v_1_L.echo_disposition "none") $x26922 $x60377 $x75227 $x75226 $x70485 $x161 $x231 $x158 $x25849 $x1426 $x1427 v_1_T.active_open $x21923 $x59694 $x75106 $x32821 $x1276 $x1909 $x75100 $x75099 $x75098 $x75095 $x75391 $x75392 $x75389 $x20403 $x20404 $x20401 $x21962 $x24448 (= v_1_T.wire_disposition "none") $x28699 $x2079 active_1_L.query $x1899 active_1_T.rtx active_1_T.user $x72547 $x72079 $x70495 $x72068 $x73933 $x70613)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x18737 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x18736 (= due_2_T.user due_1_T.user)))
 (let (($x18735 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x18733 (= due_2_L.query due_1_L.query)))
 (let (($x18732 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x18731 (= active_2_T.user active_1_T.user)))
 (let (($x18730 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x21912 (not active_2_L.query)))
 (let (($x18727 (= v_2_ip_pending_owner "none")))
 (let (($x18726 (= v_2_T.control v_1_T.control)))
 (let (($x18725 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x18724 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x18723 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x18722 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x18721 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x18720 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x18719 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x18718 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x18717 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x18716 (= v_2_T.take v_1_T.take)))
 (let (($x18715 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x18714 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x18713 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x18712 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x18711 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x18710 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x18709 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x18708 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x18707 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x18706 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x18705 (= v_2_T.retries v_1_T.retries)))
 (let (($x18704 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x18703 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x18702 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x18701 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x18700 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x18699 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x18698 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x18697 (= v_2_T.irs v_1_T.irs)))
 (let (($x18696 (= v_2_T.iss v_1_T.iss)))
 (let (($x18695 (= v_2_L.control "RESOLVED")))
 (let (($x18694 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x18693 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x18692 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x18691 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x18690 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x18689 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x18688 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x18687 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x21909 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x18685 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x18684 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x18683 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x18682 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x18681 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x18680 (= v_2_L.packet v_1_L.packet)))
 (let (($x18679 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x18678 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x18677 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x18676 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x18675 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x18674 (= v_2_L.payload v_1_L.payload)))
 (let (($x18673 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x18672 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x18671 (= 0 v_2_L.retry_count)))
 (let ((?x70240 (seq.unit (_ bv0 8))))
 (let ((?x70045 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.unit (_ bv2 8))))))))
 (let ((?x73370 (seq.unit (_ bv2 8))))
 (let ((?x31620 (seq.++ ?x73370 ?x70045)))
 (let (($x21908 (= v_2_L.peer_mac ?x31620)))
 (let (($x18669 (= 0 state_2)))
 (let (($x72547 (not active_1_T.time_wait)))
 (let (($x21907 (or $x72547 (not (<= due_1_T.time_wait 1)))))
 (let (($x20393 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x21228 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x21224 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x20308 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x18626 (seq.len v_1_L.pending_packet)))
 (let (($x18627 (<= 28 ?x18626)))
 (let (($x26922 (= v_1_L.control "PENDING")))
 (let (($x157 (= state_1 0)))
 (and $x157 $x26922 $x18627 $x20308 $x21224 $x21228 $x20393 $x21907 $x18669 $x21908 $x18671 $x18672 $x18673 $x18674 $x18675 $x18676 $x18677 $x18678 $x18679 $x18680 $x18681 $x18682 $x18683 $x18684 $x18685 $x21909 $x18687 $x18688 $x18689 $x18690 $x18691 $x18692 $x18693 $x18694 $x18695 $x18696 $x18697 $x18698 $x18699 $x18700 $x18701 $x18702 $x18703 $x18704 $x18705 $x18706 $x18707 $x18708 $x18709 $x18710 $x18711 $x18712 $x18713 $x18714 $x18715 $x18716 $x18717 $x18718 $x18719 $x18720 $x18721 $x18722 $x18723 $x18724 $x18725 $x18726 $x18727 $x21912 active_2_L.cache $x18730 $x18731 $x18732 $x18733 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x18735 $x18736 $x18737)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x74916 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x74915 (= due_3_T.user due_2_T.user)))
 (let (($x74914 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x74913 (= due_3_L.cache due_2_L.cache)))
 (let (($x74912 (= due_3_L.query due_2_L.query)))
 (let (($x74911 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x74910 (= active_3_T.user active_2_T.user)))
 (let (($x74909 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x74908 (= active_3_L.cache active_2_L.cache)))
 (let (($x74907 (= active_3_L.query active_2_L.query)))
 (let (($x74906 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x74905 (= v_3_T.control "SYN-SENT")))
 (let (($x74904 (= v_3_T.wire_disposition "drop_ip_checksum")))
 (let (($x74903 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x74902 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x74901 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x74900 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x74899 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x74898 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x74897 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x74896 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x74895 (= v_3_T.take v_2_T.take)))
 (let (($x74894 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x74893 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x74892 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x74891 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x74890 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x74889 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x74888 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x74887 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x74886 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x74885 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x74884 (= v_3_T.retries v_2_T.retries)))
 (let (($x74883 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x74882 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x74881 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x74880 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x74879 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x74878 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x74877 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x74876 (= v_3_T.irs v_2_T.irs)))
 (let (($x74875 (= v_3_T.iss v_2_T.iss)))
 (let (($x74874 (= v_3_L.control v_2_L.control)))
 (let (($x74873 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x74872 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x74871 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x74870 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x74869 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x74868 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x74867 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x74866 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x74865 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x74864 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x74863 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x74862 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x74861 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x74860 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x74859 (= v_3_L.packet v_2_L.packet)))
 (let (($x74858 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x74857 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x74856 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x74855 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x74854 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x74853 (= v_3_L.payload v_2_L.payload)))
 (let (($x74852 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x74851 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x74850 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x74849 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x74848 (= 0 state_3)))
 (let (($x21171 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x20358 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x16951 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x21596 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x21912 (not active_2_L.query)))
 (let (($x21326 (or $x21912 (not (<= due_2_L.query 2)))))
 (let (($x59615 (= v_2_T.control "SYN-SENT")))
 (let (($x20381 (= state_2 0)))
 (and $x20381 $x59615 $x21326 $x21596 $x16951 $x20358 $x21171 $x74848 $x74849 $x74850 $x74851 $x74852 $x74853 $x74854 $x74855 $x74856 $x74857 $x74858 $x74859 $x74860 $x74861 $x74862 $x74863 $x74864 $x74865 $x74866 $x74867 $x74868 $x74869 $x74870 $x74871 $x74872 $x74873 $x74874 $x74875 $x74876 $x74877 $x74878 $x74879 $x74880 $x74881 $x74882 $x74883 $x74884 $x74885 $x74886 $x74887 $x74888 $x74889 $x74890 $x74891 $x74892 $x74893 $x74894 $x74895 $x74896 $x74897 $x74898 $x74899 $x74900 $x74901 $x74902 $x74903 $x74904 $x74905 $x74906 $x74907 $x74908 $x74909 $x74910 $x74911 $x74912 $x74913 $x74914 $x74915 $x74916)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x73369 (seq.unit (_ bv192 8))))
 (let ((?x24482 (seq.++ ?x73369 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x73393 (seq.unit (_ bv1 8))))
 (let ((?x70240 (seq.unit (_ bv0 8))))
 (let ((?x24553 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x73393 ?x24482)))))))
 (let ((?x73370 (seq.unit (_ bv2 8))))
 (let ((?x585 (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 (seq.++ ?x73370 (seq.++ ?x73370 ?x24553)))))))
 (let ((?x24568 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x73370 ?x585)))))))
 (let ((?x73402 (seq.unit (_ bv4 8))))
 (let ((?x2130 (seq.unit (_ bv6 8))))
 (let ((?x24589 (seq.++ ?x2130 (seq.++ ?x73402 (seq.++ ?x70240 (seq.++ ?x73370 (seq.++ ?x73370 ?x24568)))))))
 (let ((?x1768 (seq.unit (_ bv8 8))))
 (let ((?x24384 (seq.++ ?x2130 (seq.++ ?x70240 (seq.++ ?x73393 (seq.++ ?x1768 (seq.++ ?x70240 ?x24589)))))))
 (let ((?x600 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x73370 (seq.++ ?x1768 ?x24384)))))))
 (let ((?x73715 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x73393 (seq.++ ?x73370 (seq.++ ?x70240 ?x600)))))))
 (let ((?x73942 (seq.++ ?x73370 (seq.++ ?x70240 (seq.++ ?x70240 ?x73715)))))
 (= input_1_L.net.frame_frame ?x73942))))))))))))))))))
(assert
 (= 291 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x73370 (seq.unit (_ bv2 8))))
(let ((?x24598 (seq.++ ?x73370 (seq.++ (seq.unit (_ bv4 8)) (seq.++ (seq.unit (_ bv5 8)) (seq.unit (_ bv180 8)))))))
(let ((?x70240 (seq.unit (_ bv0 8))))
(let ((?x24491 (seq.unit (_ bv246 8))))
(let ((?x24492 (seq.unit (_ bv240 8))))
(let ((?x73746 (seq.++ ?x24492 (seq.++ ?x24491 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 ?x24598)))))))
(let ((?x73583 (seq.unit (_ bv250 8))))
(let ((?x24560 (seq.unit (_ bv18 8))))
(let ((?x24373 (seq.unit (_ bv96 8))))
(let ((?x73629 (seq.unit (_ bv233 8))))
(let ((?x32894 (seq.unit (_ bv3 8))))
(let ((?x699 (seq.++ ?x32894 (seq.++ ?x73629 (seq.++ ?x24373 (seq.++ ?x24560 (seq.++ ?x73583 ?x73746)))))))
(let ((?x73731 (seq.unit (_ bv234 8))))
(let ((?x73717 (seq.unit (_ bv43 8))))
(let ((?x24537 (seq.unit (_ bv125 8))))
(let ((?x636 (seq.++ ?x24537 (seq.++ ?x73717 (seq.++ ?x73731 (seq.++ ?x70240 (seq.++ ?x70240 ?x699)))))))
(let ((?x73957 (seq.unit (_ bv55 8))))
(let ((?x72141 (seq.unit (_ bv64 8))))
(let ((?x21430 (seq.unit (_ bv156 8))))
(let ((?x21428 (seq.unit (_ bv144 8))))
(let ((?x73677 (seq.unit (_ bv31 8))))
(let ((?x2888 (seq.++ ?x73677 (seq.++ ?x21428 (seq.++ ?x21430 (seq.++ ?x72141 (seq.++ ?x73957 ?x636)))))))
(let ((?x73393 (seq.unit (_ bv1 8))))
(let ((?x73369 (seq.unit (_ bv192 8))))
(let ((?x65978 (seq.++ ?x73370 (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 (seq.++ ?x73393 ?x2888)))))))
(let ((?x73781 (seq.unit (_ bv200 8))))
(let ((?x845 (seq.unit (_ bv183 8))))
(let ((?x107 (seq.++ ?x845 (seq.++ ?x73781 (seq.++ ?x73369 (seq.++ ?x70240 (seq.++ ?x73370 ?x65978)))))))
(let ((?x2130 (seq.unit (_ bv6 8))))
(let ((?x717 (seq.++ ?x70240 (seq.++ ?x72141 (seq.++ ?x70240 (seq.++ ?x72141 (seq.++ ?x2130 ?x107)))))))
(let ((?x24151 (seq.unit (_ bv44 8))))
(let ((?x70143 (seq.unit (_ bv69 8))))
(let ((?x66408 (seq.++ ?x70143 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x24151 (seq.++ ?x70240 ?x717)))))))
(let ((?x1768 (seq.unit (_ bv8 8))))
(let ((?x24581 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x73370 (seq.++ ?x1768 (seq.++ ?x70240 ?x66408)))))))
(let ((?x74029 (seq.++ ?x70240 (seq.++ ?x73393 (seq.++ ?x73370 (seq.++ ?x70240 (seq.++ ?x70240 ?x24581)))))))
(let ((?x24177 (seq.++ ?x73370 (seq.++ ?x70240 (seq.++ ?x70240 (seq.++ ?x70240 ?x74029))))))
(= input_2_L.net.frame_frame ?x24177)))))))))))))))))))))))))))))))))))))))
(check-sat)

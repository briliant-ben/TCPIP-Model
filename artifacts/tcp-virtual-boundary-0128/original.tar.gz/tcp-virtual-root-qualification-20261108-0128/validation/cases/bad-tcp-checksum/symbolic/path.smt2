; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun active_0_L.query () Bool)
(declare-fun due_0_L.query () Int)
(declare-fun active_0_L.cache () Bool)
(declare-fun due_0_L.cache () Int)
(declare-fun active_0_T.rtx () Bool)
(declare-fun due_0_T.rtx () Int)
(declare-fun active_0_T.user () Bool)
(declare-fun due_0_T.user () Int)
(declare-fun active_0_T.time_wait () Bool)
(declare-fun due_0_T.time_wait () Int)
(declare-fun due_1_T.time_wait () Int)
(declare-fun due_1_T.user () Int)
(declare-fun due_1_T.rtx () Int)
(declare-fun due_1_L.cache () Int)
(declare-fun due_1_L.query () Int)
(declare-fun active_1_T.time_wait () Bool)
(declare-fun active_1_T.user () Bool)
(declare-fun active_1_T.rtx () Bool)
(declare-fun active_1_L.cache () Bool)
(declare-fun active_1_L.query () Bool)
(declare-fun v_1_ip_pending_owner () String)
(declare-fun v_1_T.control () String)
(declare-fun v_1_T.wire_disposition () String)
(declare-fun v_1_T.wire_flags () Int)
(declare-fun v_1_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_1_T.take () Int)
(declare-fun v_1_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_1_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_1_T.snd_wnd () Int)
(declare-fun v_1_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_1_T.local_window () Int)
(declare-fun v_1_T.msl_ms () Int)
(declare-fun v_1_T.user_timeout_ms () Int)
(declare-fun v_1_T.active_open () Bool)
(declare-fun v_1_T.retries () Int)
(declare-fun v_1_T.rto_ms () Int)
(declare-fun v_1_T.tx_flags () String)
(declare-fun v_1_T.tx_ack () (_ BitVec 32))
(declare-fun v_1_T.tx_seq () (_ BitVec 32))
(declare-fun v_1_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_nxt () (_ BitVec 32))
(declare-fun v_1_T.snd_una () (_ BitVec 32))
(declare-fun v_1_T.irs () (_ BitVec 32))
(declare-fun v_1_T.iss () (_ BitVec 32))
(declare-fun v_1_L.control () String)
(declare-fun v_1_L.echo_disposition () String)
(declare-fun v_1_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_disposition () String)
(declare-fun v_1_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.rxudp_require_checksum () Bool)
(declare-fun v_1_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_checksum () Int)
(declare-fun v_1_L.udp_checksum () Int)
(declare-fun v_1_L.udp_raw_checksum () Int)
(declare-fun v_1_L.ip_length () Int)
(declare-fun v_1_L.udp_length () Int)
(declare-fun v_1_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_1_L.checksums_enabled () Bool)
(declare-fun v_1_L.cache_ttl_ms () Int)
(declare-fun v_1_L.retry_count () Int)
(declare-fun v_1_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_1 () Int)
(declare-fun due_2_T.time_wait () Int)
(declare-fun due_2_T.user () Int)
(declare-fun due_2_T.rtx () Int)
(declare-fun due_2_L.cache () Int)
(declare-fun due_2_L.query () Int)
(declare-fun active_2_T.time_wait () Bool)
(declare-fun active_2_T.user () Bool)
(declare-fun active_2_T.rtx () Bool)
(declare-fun active_2_L.cache () Bool)
(declare-fun active_2_L.query () Bool)
(declare-fun v_2_ip_pending_owner () String)
(declare-fun v_2_T.control () String)
(declare-fun v_2_T.wire_disposition () String)
(declare-fun v_2_T.wire_flags () Int)
(declare-fun v_2_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_2_T.take () Int)
(declare-fun v_2_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_2_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_2_T.snd_wnd () Int)
(declare-fun v_2_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_2_T.local_window () Int)
(declare-fun v_2_T.msl_ms () Int)
(declare-fun v_2_T.user_timeout_ms () Int)
(declare-fun v_2_T.active_open () Bool)
(declare-fun v_2_T.retries () Int)
(declare-fun v_2_T.rto_ms () Int)
(declare-fun v_2_T.tx_flags () String)
(declare-fun v_2_T.tx_ack () (_ BitVec 32))
(declare-fun v_2_T.tx_seq () (_ BitVec 32))
(declare-fun v_2_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_nxt () (_ BitVec 32))
(declare-fun v_2_T.snd_una () (_ BitVec 32))
(declare-fun v_2_T.irs () (_ BitVec 32))
(declare-fun v_2_T.iss () (_ BitVec 32))
(declare-fun v_2_L.control () String)
(declare-fun v_2_L.echo_disposition () String)
(declare-fun v_2_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_disposition () String)
(declare-fun v_2_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.rxudp_require_checksum () Bool)
(declare-fun v_2_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_checksum () Int)
(declare-fun v_2_L.udp_checksum () Int)
(declare-fun v_2_L.udp_raw_checksum () Int)
(declare-fun v_2_L.ip_length () Int)
(declare-fun v_2_L.udp_length () Int)
(declare-fun v_2_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_2_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_2_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_2_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_2_L.checksums_enabled () Bool)
(declare-fun v_2_L.cache_ttl_ms () Int)
(declare-fun v_2_L.retry_count () Int)
(declare-fun v_2_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_2 () Int)
(declare-fun due_3_T.time_wait () Int)
(declare-fun due_3_T.user () Int)
(declare-fun due_3_T.rtx () Int)
(declare-fun due_3_L.cache () Int)
(declare-fun due_3_L.query () Int)
(declare-fun active_3_T.time_wait () Bool)
(declare-fun active_3_T.user () Bool)
(declare-fun active_3_T.rtx () Bool)
(declare-fun active_3_L.cache () Bool)
(declare-fun active_3_L.query () Bool)
(declare-fun v_3_ip_pending_owner () String)
(declare-fun v_3_T.control () String)
(declare-fun v_3_T.wire_disposition () String)
(declare-fun v_3_T.wire_flags () Int)
(declare-fun v_3_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_3_T.take () Int)
(declare-fun v_3_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_3_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_3_T.snd_wnd () Int)
(declare-fun v_3_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_3_T.local_window () Int)
(declare-fun v_3_T.msl_ms () Int)
(declare-fun v_3_T.user_timeout_ms () Int)
(declare-fun v_3_T.active_open () Bool)
(declare-fun v_3_T.retries () Int)
(declare-fun v_3_T.rto_ms () Int)
(declare-fun v_3_T.tx_flags () String)
(declare-fun v_3_T.tx_ack () (_ BitVec 32))
(declare-fun v_3_T.tx_seq () (_ BitVec 32))
(declare-fun v_3_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_nxt () (_ BitVec 32))
(declare-fun v_3_T.snd_una () (_ BitVec 32))
(declare-fun v_3_T.irs () (_ BitVec 32))
(declare-fun v_3_T.iss () (_ BitVec 32))
(declare-fun v_3_L.control () String)
(declare-fun v_3_L.echo_disposition () String)
(declare-fun v_3_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_disposition () String)
(declare-fun v_3_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.rxudp_require_checksum () Bool)
(declare-fun v_3_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_checksum () Int)
(declare-fun v_3_L.udp_checksum () Int)
(declare-fun v_3_L.udp_raw_checksum () Int)
(declare-fun v_3_L.ip_length () Int)
(declare-fun v_3_L.udp_length () Int)
(declare-fun v_3_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_3_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_3_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_3_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_3_L.checksums_enabled () Bool)
(declare-fun v_3_L.cache_ttl_ms () Int)
(declare-fun v_3_L.retry_count () Int)
(declare-fun v_3_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun state_3 () Int)
(declare-fun v_0_L.peer_mac () (Seq (_ BitVec 8)))
(declare-fun v_0_L.retry_count () Int)
(declare-fun v_0_L.cache_ttl_ms () Int)
(declare-fun v_0_L.checksums_enabled () Bool)
(declare-fun v_0_L.payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.udp_length () Int)
(declare-fun v_0_L.ip_length () Int)
(declare-fun v_0_L.udp_raw_checksum () Int)
(declare-fun v_0_L.udp_checksum () Int)
(declare-fun v_0_L.ip_checksum () Int)
(declare-fun v_0_L.pending_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_require_checksum () Bool)
(declare-fun v_0_L.rxudp_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_L.rxudp_disposition () String)
(declare-fun v_0_L.echo_reply () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_icmp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_L.echo_disposition () String)
(declare-fun v_0_L.control () String)
(declare-fun v_0_T.iss () (_ BitVec 32))
(declare-fun v_0_T.irs () (_ BitVec 32))
(declare-fun v_0_T.snd_una () (_ BitVec 32))
(declare-fun v_0_T.snd_nxt () (_ BitVec 32))
(declare-fun v_0_T.rcv_nxt () (_ BitVec 32))
(declare-fun v_0_T.tx_seq () (_ BitVec 32))
(declare-fun v_0_T.tx_ack () (_ BitVec 32))
(declare-fun v_0_T.tx_flags () String)
(declare-fun v_0_T.rto_ms () Int)
(declare-fun v_0_T.retries () Int)
(declare-fun v_0_T.active_open () Bool)
(declare-fun v_0_T.user_timeout_ms () Int)
(declare-fun v_0_T.msl_ms () Int)
(declare-fun v_0_T.local_window () Int)
(declare-fun v_0_T.snd_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rtx_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.rcv_buf () (Seq (_ BitVec 8)))
(declare-fun v_0_T.snd_wnd () Int)
(declare-fun v_0_T.snd_wl1 () (_ BitVec 32))
(declare-fun v_0_T.snd_wl2 () (_ BitVec 32))
(declare-fun v_0_T.take () Int)
(declare-fun v_0_T.rx_chunk () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_data () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_pseudo () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_tcp () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_T.wire_flags () Int)
(declare-fun v_0_T.wire_disposition () String)
(declare-fun v_0_T.control () String)
(declare-fun v_0_ip_pending_owner () String)
(declare-fun choice_0 () Int)
(declare-fun now_1 () Int)
(declare-fun choice_1 () Int)
(declare-fun now_2 () Int)
(declare-fun input_1_L.net.frame_frame () (Seq (_ BitVec 8)))
(declare-fun choice_2 () Int)
(declare-fun now_3 () Int)
(declare-fun input_2_L.net.frame_frame () (Seq (_ BitVec 8)))
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (not active_0_L.query))
(assert
 (= due_0_L.query 0))
(assert
 (not active_0_L.cache))
(assert
 (= due_0_L.cache 0))
(assert
 (not active_0_T.rtx))
(assert
 (= due_0_T.rtx 0))
(assert
 (not active_0_T.user))
(assert
 (= due_0_T.user 0))
(assert
 (not active_0_T.time_wait))
(assert
 (= due_0_T.time_wait 0))
(assert
 true)
(assert
 (let (($x65468 (= due_1_T.time_wait due_0_T.time_wait)))
 (let (($x66463 (= due_1_T.user 30000)))
 (let (($x73971 (= due_1_T.rtx 1000)))
 (let (($x3605 (= due_1_L.cache due_0_L.cache)))
 (let (($x73970 (= due_1_L.query 1000)))
 (let (($x30262 (not active_1_T.time_wait)))
 (let (($x32776 (= active_1_L.cache active_0_L.cache)))
 (let (($x3629 (= v_1_ip_pending_owner "TCP")))
 (let (($x68512 (= v_1_T.control "SYN-SENT")))
 (let (($x739 (= v_1_T.wire_flags 2)))
 (let ((?x24100 (seq.++ (seq.unit (_ bv108 8)) (seq.++ (seq.unit (_ bv22 8)) (seq.++ (seq.unit (_ bv0 8)) (seq.unit (_ bv0 8)))))))
 (let ((?x73863 (seq.unit (_ bv16 8))))
 (let ((?x1728 (seq.unit (_ bv0 8))))
 (let ((?x95454 (seq.unit (_ bv2 8))))
 (let ((?x27456 (seq.unit (_ bv80 8))))
 (let ((?x24292 (seq.++ ?x1728 (seq.++ ?x27456 (seq.++ ?x95454 (seq.++ ?x1728 (seq.++ ?x73863 ?x24100)))))))
 (let ((?x574 (seq.unit (_ bv232 8))))
 (let ((?x72122 (seq.unit (_ bv3 8))))
 (let ((?x73841 (seq.++ ?x72122 (seq.++ ?x574 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 ?x24292)))))))
 (let ((?x68159 (seq.unit (_ bv144 8))))
 (let ((?x68158 (seq.unit (_ bv31 8))))
 (let ((?x70640 (seq.unit (_ bv64 8))))
 (let ((?x715 (seq.++ ?x70640 (seq.++ ?x68158 (seq.++ ?x68159 (seq.++ ?x1728 (seq.++ ?x1728 ?x73841)))))))
 (let ((?x2298 (seq.unit (_ bv156 8))))
 (let ((?x73687 (seq.++ ?x2298 ?x715)))
 (let ((?x1274 (seq.unit (_ bv192 8))))
 (let ((?x32963 (seq.unit (_ bv1 8))))
 (let ((?x24312 (seq.++ ?x32963 (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 (seq.++ ?x95454 ?x73687)))))))
 (let ((?x622 (seq.++ (seq.unit (_ bv204 8)) (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 ?x24312))))))
 (let ((?x806 (seq.unit (_ bv182 8))))
 (let ((?x61540 (seq.unit (_ bv6 8))))
 (let ((?x24064 (seq.++ ?x70640 (seq.++ ?x1728 (seq.++ ?x70640 (seq.++ ?x61540 (seq.++ ?x806 ?x622)))))))
 (let ((?x24525 (seq.unit (_ bv40 8))))
 (let ((?x24558 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x24525 (seq.++ ?x1728 (seq.++ ?x1728 ?x24064)))))))
 (let ((?x67578 (seq.unit (_ bv69 8))))
 (let ((?x24559 (seq.++ ?x67578 ?x24558)))
 (let (($x738 (= v_1_T.wire_packet ?x24559)))
 (let ((?x27278 (seq.++ ?x95454 (seq.++ ?x32963 (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 ?x95454)))))))
 (let ((?x921 (seq.++ ?x61540 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1274 (seq.++ ?x1728 ?x27278)))))))
 (let ((?x72323 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x70640 (seq.++ ?x1728 (seq.++ ?x70640 ?x921)))))))
 (let (($x737 (= v_1_T.wire_ip_zero (seq.++ ?x67578 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x24525 ?x72323)))))))
 (let (($x736 (= v_1_T.wire_tcp ?x73687)))
 (let ((?x73779 (seq.++ ?x95454 (seq.++ ?x1728 (seq.++ ?x61540 (seq.++ ?x1728 (seq.unit (_ bv20 8))))))))
 (let ((?x73982 (seq.++ ?x95454 (seq.++ ?x32963 (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 ?x73779)))))))
 (let (($x735 (= v_1_T.wire_pseudo (seq.++ ?x1274 (seq.++ ?x1728 ?x73982)))))
 (let ((?x24459 (seq.++ ?x1728 (seq.++ ?x73863 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 ?x1728)))))))
 (let ((?x34474 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x27456 (seq.++ ?x95454 ?x24459)))))))
 (let ((?x22966 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x72122 (seq.++ ?x574 (seq.++ ?x1728 ?x34474)))))))
 (let (($x721 (= v_1_T.wire_tcp_zero (seq.++ ?x2298 (seq.++ ?x70640 (seq.++ ?x68158 (seq.++ ?x68159 ?x22966)))))))
 (let (($x24110 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.wire_data)))
 (let (($x24109 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rx_chunk)))
 (let (($x73591 (= v_1_T.take 0)))
 (let (($x73594 (= v_1_T.snd_wl2 (_ bv0 32))))
 (let (($x73595 (= v_1_T.snd_wl1 (_ bv0 32))))
 (let (($x73596 (= v_1_T.snd_wnd 8)))
 (let (($x30039 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rcv_buf)))
 (let (($x73641 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.rtx_buf)))
 (let (($x73639 (= (as seq.empty (Seq (_ BitVec 8))) v_1_T.snd_buf)))
 (let (($x73602 (= v_1_T.local_window 16)))
 (let (($x2256 (= v_1_T.msl_ms 60000)))
 (let (($x24607 (= v_1_T.user_timeout_ms 30000)))
 (let (($x1954 (= 0 v_1_T.retries)))
 (let (($x1953 (= 1000 v_1_T.rto_ms)))
 (let (($x1079 (= v_1_T.tx_flags "S")))
 (let (($x24375 (= v_1_T.tx_ack (_ bv0 32))))
 (let (($x24053 (= v_1_T.tx_seq (_ bv1000 32))))
 (let (($x24054 (= v_1_T.rcv_nxt (_ bv0 32))))
 (let (($x73644 (= v_1_T.snd_nxt (_ bv1001 32))))
 (let (($x24056 (= v_1_T.snd_una (_ bv1000 32))))
 (let (($x24057 (= v_1_T.irs (_ bv0 32))))
 (let (($x24058 (= v_1_T.iss (_ bv1000 32))))
 (let (($x1951 (= v_1_L.control "PENDING")))
 (let (($x24507 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_ip_zero)))
 (let (($x24506 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_wire)))
 (let (($x1399 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_icmp_zero)))
 (let (($x65438 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.echo_reply)))
 (let (($x134 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.rxudp_payload)))
 (let (($x21565 (not v_1_L.rxudp_require_checksum)))
 (let (($x621 (= v_1_L.pending_packet ?x24559)))
 (let (($x24323 (= v_1_L.ip_checksum 0)))
 (let (($x24324 (= v_1_L.udp_checksum 0)))
 (let (($x24325 (= v_1_L.udp_raw_checksum 0)))
 (let (($x24326 (= v_1_L.ip_length 0)))
 (let (($x24327 (= v_1_L.udp_length 0)))
 (let (($x24527 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.packet)))
 (let (($x24526 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_wire)))
 (let (($x73711 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.ip_zero)))
 (let (($x73712 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_wire)))
 (let (($x73710 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.pseudoheader)))
 (let (($x73709 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.udp_zero)))
 (let (($x73708 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.payload)))
 (let (($x24428 (= v_1_L.cache_ttl_ms 60000)))
 (let (($x62262 (= 0 v_1_L.retry_count)))
 (let (($x73707 (= (as seq.empty (Seq (_ BitVec 8))) v_1_L.peer_mac)))
 (let (($x28770 (= 0 state_1)))
 (let (($x95950 (not active_0_T.time_wait)))
 (let (($x73699 (or $x95950 (not (<= due_0_T.time_wait 0)))))
 (let (($x95951 (not active_0_T.user)))
 (let (($x73704 (or $x95951 (not (<= due_0_T.user 0)))))
 (let (($x95952 (not active_0_T.rtx)))
 (let (($x73696 (or $x95952 (not (<= due_0_T.rtx 0)))))
 (let (($x32949 (not active_0_L.cache)))
 (let (($x73694 (or $x32949 (not (<= due_0_L.cache 0)))))
 (let (($x2607 (not active_0_L.query)))
 (let (($x73684 (or $x2607 (not (<= due_0_L.query 0)))))
 (let (($x2342 (= state_0 0)))
 (and $x2342 (>= 0 now_0) $x73684 $x73694 $x73696 $x73704 $x73699 $x28770 $x73707 $x62262 $x24428 v_1_L.checksums_enabled $x73708 $x73709 $x73710 $x73712 $x73711 $x24526 $x24527 $x24327 $x24326 $x24325 $x24324 $x24323 $x621 $x21565 $x134 (= v_1_L.rxudp_disposition "none") $x65438 $x1399 $x24506 $x24507 (= v_1_L.echo_disposition "none") $x1951 $x24058 $x24057 $x24056 $x73644 $x24054 $x24053 $x24375 $x1079 $x1953 $x1954 v_1_T.active_open $x24607 $x2256 $x73602 $x73639 $x73641 $x30039 $x73596 $x73595 $x73594 $x73591 $x24109 $x24110 $x721 $x735 $x736 $x737 $x738 $x739 (= v_1_T.wire_disposition "none") $x68512 $x3629 active_1_L.query $x32776 active_1_T.rtx active_1_T.user $x30262 $x73970 $x3605 $x73971 $x66463 $x65468))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 (let (($x21430 (= due_2_T.time_wait due_1_T.time_wait)))
 (let (($x21429 (= due_2_T.user due_1_T.user)))
 (let (($x21428 (= due_2_T.rtx due_1_T.rtx)))
 (let (($x21426 (= due_2_L.query due_1_L.query)))
 (let (($x21425 (= active_2_T.time_wait active_1_T.time_wait)))
 (let (($x21424 (= active_2_T.user active_1_T.user)))
 (let (($x21423 (= active_2_T.rtx active_1_T.rtx)))
 (let (($x73791 (not active_2_L.query)))
 (let (($x21420 (= v_2_ip_pending_owner "none")))
 (let (($x21419 (= v_2_T.control v_1_T.control)))
 (let (($x21418 (= v_2_T.wire_disposition v_1_T.wire_disposition)))
 (let (($x21417 (= v_2_T.wire_flags v_1_T.wire_flags)))
 (let (($x21416 (= v_2_T.wire_packet v_1_T.wire_packet)))
 (let (($x21415 (= v_2_T.wire_ip_zero v_1_T.wire_ip_zero)))
 (let (($x21414 (= v_2_T.wire_tcp v_1_T.wire_tcp)))
 (let (($x21413 (= v_2_T.wire_pseudo v_1_T.wire_pseudo)))
 (let (($x21412 (= v_2_T.wire_tcp_zero v_1_T.wire_tcp_zero)))
 (let (($x21411 (= v_2_T.wire_data v_1_T.wire_data)))
 (let (($x21410 (= v_2_T.rx_chunk v_1_T.rx_chunk)))
 (let (($x21409 (= v_2_T.take v_1_T.take)))
 (let (($x21408 (= v_2_T.snd_wl2 v_1_T.snd_wl2)))
 (let (($x21407 (= v_2_T.snd_wl1 v_1_T.snd_wl1)))
 (let (($x21406 (= v_2_T.snd_wnd v_1_T.snd_wnd)))
 (let (($x21405 (= v_2_T.rcv_buf v_1_T.rcv_buf)))
 (let (($x21404 (= v_2_T.rtx_buf v_1_T.rtx_buf)))
 (let (($x21403 (= v_2_T.snd_buf v_1_T.snd_buf)))
 (let (($x21402 (= v_2_T.local_window v_1_T.local_window)))
 (let (($x21401 (= v_2_T.msl_ms v_1_T.msl_ms)))
 (let (($x21400 (= v_2_T.user_timeout_ms v_1_T.user_timeout_ms)))
 (let (($x21399 (= v_2_T.active_open v_1_T.active_open)))
 (let (($x21398 (= v_2_T.retries v_1_T.retries)))
 (let (($x21397 (= v_2_T.rto_ms v_1_T.rto_ms)))
 (let (($x21396 (= v_2_T.tx_flags v_1_T.tx_flags)))
 (let (($x21395 (= v_2_T.tx_ack v_1_T.tx_ack)))
 (let (($x21394 (= v_2_T.tx_seq v_1_T.tx_seq)))
 (let (($x21393 (= v_2_T.rcv_nxt v_1_T.rcv_nxt)))
 (let (($x21392 (= v_2_T.snd_nxt v_1_T.snd_nxt)))
 (let (($x21391 (= v_2_T.snd_una v_1_T.snd_una)))
 (let (($x21390 (= v_2_T.irs v_1_T.irs)))
 (let (($x21389 (= v_2_T.iss v_1_T.iss)))
 (let (($x21388 (= v_2_L.control "RESOLVED")))
 (let (($x21387 (= v_2_L.echo_disposition v_1_L.echo_disposition)))
 (let (($x21386 (= v_2_L.echo_ip_zero v_1_L.echo_ip_zero)))
 (let (($x21385 (= v_2_L.echo_icmp_wire v_1_L.echo_icmp_wire)))
 (let (($x21384 (= v_2_L.echo_icmp_zero v_1_L.echo_icmp_zero)))
 (let (($x21383 (= v_2_L.echo_reply v_1_L.echo_reply)))
 (let (($x21382 (= v_2_L.rxudp_disposition v_1_L.rxudp_disposition)))
 (let (($x21381 (= v_2_L.rxudp_payload v_1_L.rxudp_payload)))
 (let (($x21380 (= v_2_L.rxudp_require_checksum v_1_L.rxudp_require_checksum)))
 (let (($x33049 (= (as seq.empty (Seq (_ BitVec 8))) v_2_L.pending_packet)))
 (let (($x21378 (= v_2_L.ip_checksum v_1_L.ip_checksum)))
 (let (($x21377 (= v_2_L.udp_checksum v_1_L.udp_checksum)))
 (let (($x21376 (= v_2_L.udp_raw_checksum v_1_L.udp_raw_checksum)))
 (let (($x21375 (= v_2_L.ip_length v_1_L.ip_length)))
 (let (($x21374 (= v_2_L.udp_length v_1_L.udp_length)))
 (let (($x21373 (= v_2_L.packet v_1_L.packet)))
 (let (($x21372 (= v_2_L.ip_wire v_1_L.ip_wire)))
 (let (($x21371 (= v_2_L.ip_zero v_1_L.ip_zero)))
 (let (($x21370 (= v_2_L.udp_wire v_1_L.udp_wire)))
 (let (($x21369 (= v_2_L.pseudoheader v_1_L.pseudoheader)))
 (let (($x21368 (= v_2_L.udp_zero v_1_L.udp_zero)))
 (let (($x21367 (= v_2_L.payload v_1_L.payload)))
 (let (($x21366 (= v_2_L.checksums_enabled v_1_L.checksums_enabled)))
 (let (($x21365 (= v_2_L.cache_ttl_ms v_1_L.cache_ttl_ms)))
 (let (($x21364 (= 0 v_2_L.retry_count)))
 (let ((?x1728 (seq.unit (_ bv0 8))))
 (let ((?x70078 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.unit (_ bv2 8))))))))
 (let ((?x95454 (seq.unit (_ bv2 8))))
 (let ((?x70080 (seq.++ ?x95454 ?x70078)))
 (let (($x66182 (= v_2_L.peer_mac ?x70080)))
 (let (($x21362 (= 0 state_2)))
 (let (($x30262 (not active_1_T.time_wait)))
 (let (($x65976 (or $x30262 (not (<= due_1_T.time_wait 1)))))
 (let (($x24339 (or (not active_1_T.user) (not (<= due_1_T.user 1)))))
 (let (($x615 (or (not active_1_T.rtx) (not (<= due_1_T.rtx 1)))))
 (let (($x24388 (or (not active_1_L.cache) (not (<= due_1_L.cache 1)))))
 (let (($x24576 (or (not active_1_L.query) (not (<= due_1_L.query 1)))))
 (let ((?x21319 (seq.len v_1_L.pending_packet)))
 (let (($x21320 (<= 28 ?x21319)))
 (let (($x1951 (= v_1_L.control "PENDING")))
 (let (($x116 (= state_1 0)))
 (and $x116 $x1951 $x21320 $x24576 $x24388 $x615 $x24339 $x65976 $x21362 $x66182 $x21364 $x21365 $x21366 $x21367 $x21368 $x21369 $x21370 $x21371 $x21372 $x21373 $x21374 $x21375 $x21376 $x21377 $x21378 $x33049 $x21380 $x21381 $x21382 $x21383 $x21384 $x21385 $x21386 $x21387 $x21388 $x21389 $x21390 $x21391 $x21392 $x21393 $x21394 $x21395 $x21396 $x21397 $x21398 $x21399 $x21400 $x21401 $x21402 $x21403 $x21404 $x21405 $x21406 $x21407 $x21408 $x21409 $x21410 $x21411 $x21412 $x21413 $x21414 $x21415 $x21416 $x21417 $x21418 $x21419 $x21420 $x73791 active_2_L.cache $x21423 $x21424 $x21425 $x21426 (= due_2_L.cache (+ 1 v_1_L.cache_ttl_ms)) $x21428 $x21429 $x21430)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 (let (($x73419 (= due_3_T.time_wait due_2_T.time_wait)))
 (let (($x73418 (= due_3_T.user due_2_T.user)))
 (let (($x73417 (= due_3_T.rtx due_2_T.rtx)))
 (let (($x73416 (= due_3_L.cache due_2_L.cache)))
 (let (($x73415 (= due_3_L.query due_2_L.query)))
 (let (($x73414 (= active_3_T.time_wait active_2_T.time_wait)))
 (let (($x73413 (= active_3_T.user active_2_T.user)))
 (let (($x73412 (= active_3_T.rtx active_2_T.rtx)))
 (let (($x73411 (= active_3_L.cache active_2_L.cache)))
 (let (($x73410 (= active_3_L.query active_2_L.query)))
 (let (($x73409 (= v_3_ip_pending_owner v_2_ip_pending_owner)))
 (let (($x73408 (= v_3_T.control "SYN-SENT")))
 (let (($x73407 (= v_3_T.wire_disposition "drop_tcp_checksum")))
 (let (($x73406 (= v_3_T.wire_flags v_2_T.wire_flags)))
 (let (($x73405 (= v_3_T.wire_packet v_2_T.wire_packet)))
 (let (($x73404 (= v_3_T.wire_ip_zero v_2_T.wire_ip_zero)))
 (let (($x73403 (= v_3_T.wire_tcp v_2_T.wire_tcp)))
 (let (($x73402 (= v_3_T.wire_pseudo v_2_T.wire_pseudo)))
 (let (($x73401 (= v_3_T.wire_tcp_zero v_2_T.wire_tcp_zero)))
 (let (($x73400 (= v_3_T.wire_data v_2_T.wire_data)))
 (let (($x73399 (= v_3_T.rx_chunk v_2_T.rx_chunk)))
 (let (($x73398 (= v_3_T.take v_2_T.take)))
 (let (($x73397 (= v_3_T.snd_wl2 v_2_T.snd_wl2)))
 (let (($x73396 (= v_3_T.snd_wl1 v_2_T.snd_wl1)))
 (let (($x73395 (= v_3_T.snd_wnd v_2_T.snd_wnd)))
 (let (($x73394 (= v_3_T.rcv_buf v_2_T.rcv_buf)))
 (let (($x73393 (= v_3_T.rtx_buf v_2_T.rtx_buf)))
 (let (($x73392 (= v_3_T.snd_buf v_2_T.snd_buf)))
 (let (($x73391 (= v_3_T.local_window v_2_T.local_window)))
 (let (($x73390 (= v_3_T.msl_ms v_2_T.msl_ms)))
 (let (($x73389 (= v_3_T.user_timeout_ms v_2_T.user_timeout_ms)))
 (let (($x73388 (= v_3_T.active_open v_2_T.active_open)))
 (let (($x73387 (= v_3_T.retries v_2_T.retries)))
 (let (($x73386 (= v_3_T.rto_ms v_2_T.rto_ms)))
 (let (($x73385 (= v_3_T.tx_flags v_2_T.tx_flags)))
 (let (($x73384 (= v_3_T.tx_ack v_2_T.tx_ack)))
 (let (($x73383 (= v_3_T.tx_seq v_2_T.tx_seq)))
 (let (($x73382 (= v_3_T.rcv_nxt v_2_T.rcv_nxt)))
 (let (($x73381 (= v_3_T.snd_nxt v_2_T.snd_nxt)))
 (let (($x73380 (= v_3_T.snd_una v_2_T.snd_una)))
 (let (($x73379 (= v_3_T.irs v_2_T.irs)))
 (let (($x73378 (= v_3_T.iss v_2_T.iss)))
 (let (($x73377 (= v_3_L.control v_2_L.control)))
 (let (($x73376 (= v_3_L.echo_disposition v_2_L.echo_disposition)))
 (let (($x73375 (= v_3_L.echo_ip_zero v_2_L.echo_ip_zero)))
 (let (($x73374 (= v_3_L.echo_icmp_wire v_2_L.echo_icmp_wire)))
 (let (($x73373 (= v_3_L.echo_icmp_zero v_2_L.echo_icmp_zero)))
 (let (($x73372 (= v_3_L.echo_reply v_2_L.echo_reply)))
 (let (($x73371 (= v_3_L.rxudp_disposition v_2_L.rxudp_disposition)))
 (let (($x73370 (= v_3_L.rxudp_payload v_2_L.rxudp_payload)))
 (let (($x73369 (= v_3_L.rxudp_require_checksum v_2_L.rxudp_require_checksum)))
 (let (($x73368 (= v_3_L.pending_packet v_2_L.pending_packet)))
 (let (($x73367 (= v_3_L.ip_checksum v_2_L.ip_checksum)))
 (let (($x73366 (= v_3_L.udp_checksum v_2_L.udp_checksum)))
 (let (($x73365 (= v_3_L.udp_raw_checksum v_2_L.udp_raw_checksum)))
 (let (($x73364 (= v_3_L.ip_length v_2_L.ip_length)))
 (let (($x73363 (= v_3_L.udp_length v_2_L.udp_length)))
 (let (($x73362 (= v_3_L.packet v_2_L.packet)))
 (let (($x73361 (= v_3_L.ip_wire v_2_L.ip_wire)))
 (let (($x73360 (= v_3_L.ip_zero v_2_L.ip_zero)))
 (let (($x73359 (= v_3_L.udp_wire v_2_L.udp_wire)))
 (let (($x73358 (= v_3_L.pseudoheader v_2_L.pseudoheader)))
 (let (($x73357 (= v_3_L.udp_zero v_2_L.udp_zero)))
 (let (($x73356 (= v_3_L.payload v_2_L.payload)))
 (let (($x73355 (= v_3_L.checksums_enabled v_2_L.checksums_enabled)))
 (let (($x73354 (= v_3_L.cache_ttl_ms v_2_L.cache_ttl_ms)))
 (let (($x73353 (= v_3_L.retry_count v_2_L.retry_count)))
 (let (($x73352 (= v_3_L.peer_mac v_2_L.peer_mac)))
 (let (($x73351 (= 0 state_3)))
 (let (($x32987 (or (not active_2_T.time_wait) (not (<= due_2_T.time_wait 2)))))
 (let (($x67695 (or (not active_2_T.user) (not (<= due_2_T.user 2)))))
 (let (($x226 (or (not active_2_T.rtx) (not (<= due_2_T.rtx 2)))))
 (let (($x67692 (or (not active_2_L.cache) (not (<= due_2_L.cache 2)))))
 (let (($x73791 (not active_2_L.query)))
 (let (($x23071 (or $x73791 (not (<= due_2_L.query 2)))))
 (let (($x60377 (= v_2_T.control "SYN-SENT")))
 (let (($x23049 (= state_2 0)))
 (and $x23049 $x60377 $x23071 $x67692 $x226 $x67695 $x32987 $x73351 $x73352 $x73353 $x73354 $x73355 $x73356 $x73357 $x73358 $x73359 $x73360 $x73361 $x73362 $x73363 $x73364 $x73365 $x73366 $x73367 $x73368 $x73369 $x73370 $x73371 $x73372 $x73373 $x73374 $x73375 $x73376 $x73377 $x73378 $x73379 $x73380 $x73381 $x73382 $x73383 $x73384 $x73385 $x73386 $x73387 $x73388 $x73389 $x73390 $x73391 $x73392 $x73393 $x73394 $x73395 $x73396 $x73397 $x73398 $x73399 $x73400 $x73401 $x73402 $x73403 $x73404 $x73405 $x73406 $x73407 $x73408 $x73409 $x73410 $x73411 $x73412 $x73413 $x73414 $x73415 $x73416 $x73417 $x73418 $x73419)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 true)
(assert
 (= v_0_L.peer_mac (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.retry_count))
(assert
 (= 60000 v_0_L.cache_ttl_ms))
(assert
 (= v_0_L.checksums_enabled true))
(assert
 (= v_0_L.payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_L.udp_length))
(assert
 (= 0 v_0_L.ip_length))
(assert
 (= 0 v_0_L.udp_raw_checksum))
(assert
 (= 0 v_0_L.udp_checksum))
(assert
 (= 0 v_0_L.ip_checksum))
(assert
 (= v_0_L.pending_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_require_checksum false))
(assert
 (= v_0_L.rxudp_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.rxudp_disposition "none"))
(assert
 (= v_0_L.echo_reply (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_icmp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_L.echo_disposition "none"))
(assert
 (= v_0_L.control "EMPTY"))
(assert
 (= (_ bv1000 32) v_0_T.iss))
(assert
 (= (_ bv0 32) v_0_T.irs))
(assert
 (= (_ bv1000 32) v_0_T.snd_una))
(assert
 (= (_ bv1000 32) v_0_T.snd_nxt))
(assert
 (= (_ bv0 32) v_0_T.rcv_nxt))
(assert
 (= (_ bv1000 32) v_0_T.tx_seq))
(assert
 (= (_ bv0 32) v_0_T.tx_ack))
(assert
 (= v_0_T.tx_flags "S"))
(assert
 (= 1000 v_0_T.rto_ms))
(assert
 (= 0 v_0_T.retries))
(assert
 (= v_0_T.active_open true))
(assert
 (= 30000 v_0_T.user_timeout_ms))
(assert
 (= 60000 v_0_T.msl_ms))
(assert
 (= 16 v_0_T.local_window))
(assert
 (= v_0_T.snd_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rtx_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.rcv_buf (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 8 v_0_T.snd_wnd))
(assert
 (= (_ bv0 32) v_0_T.snd_wl1))
(assert
 (= (_ bv0 32) v_0_T.snd_wl2))
(assert
 (= 0 v_0_T.take))
(assert
 (= v_0_T.rx_chunk (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_data (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_pseudo (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_tcp (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_T.wire_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_T.wire_flags))
(assert
 (= v_0_T.wire_disposition "none"))
(assert
 (= v_0_T.control "CLOSED"))
(assert
 (= v_0_ip_pending_owner "none"))
(assert
 (= 64 choice_0))
(assert
 (= 0 now_1))
(assert
 (= 29 choice_1))
(assert
 (= 1 now_2))
(assert
 (let ((?x1274 (seq.unit (_ bv192 8))))
 (let ((?x95860 (seq.++ ?x1274 (seq.++ (seq.unit (_ bv0 8)) (seq.++ (seq.unit (_ bv2 8)) (seq.unit (_ bv1 8)))))))
 (let ((?x32963 (seq.unit (_ bv1 8))))
 (let ((?x1728 (seq.unit (_ bv0 8))))
 (let ((?x72440 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x32963 ?x95860)))))))
 (let ((?x95454 (seq.unit (_ bv2 8))))
 (let ((?x72460 (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 (seq.++ ?x95454 (seq.++ ?x95454 ?x72440)))))))
 (let ((?x71869 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x95454 ?x72460)))))))
 (let ((?x2400 (seq.unit (_ bv4 8))))
 (let ((?x61540 (seq.unit (_ bv6 8))))
 (let ((?x864 (seq.++ ?x61540 (seq.++ ?x2400 (seq.++ ?x1728 (seq.++ ?x95454 (seq.++ ?x95454 ?x71869)))))))
 (let ((?x70322 (seq.unit (_ bv8 8))))
 (let ((?x72526 (seq.++ ?x61540 (seq.++ ?x1728 (seq.++ ?x32963 (seq.++ ?x70322 (seq.++ ?x1728 ?x864)))))))
 (let ((?x1465 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x95454 (seq.++ ?x70322 ?x72526)))))))
 (let ((?x71884 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x32963 (seq.++ ?x95454 (seq.++ ?x1728 ?x1465)))))))
 (let ((?x987 (seq.++ ?x95454 (seq.++ ?x1728 (seq.++ ?x1728 ?x71884)))))
 (= input_1_L.net.frame_frame ?x987))))))))))))))))))
(assert
 (= 293 choice_2))
(assert
 (= 2 now_3))
(assert
 (let ((?x95454 (seq.unit (_ bv2 8))))
(let ((?x65729 (seq.++ ?x95454 (seq.++ (seq.unit (_ bv4 8)) (seq.++ (seq.unit (_ bv5 8)) (seq.unit (_ bv180 8)))))))
(let ((?x1728 (seq.unit (_ bv0 8))))
(let ((?x72206 (seq.unit (_ bv247 8))))
(let ((?x27174 (seq.unit (_ bv240 8))))
(let ((?x895 (seq.++ ?x27174 (seq.++ ?x72206 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 ?x65729)))))))
(let ((?x72445 (seq.unit (_ bv250 8))))
(let ((?x71655 (seq.unit (_ bv18 8))))
(let ((?x26924 (seq.unit (_ bv96 8))))
(let ((?x1100 (seq.unit (_ bv233 8))))
(let ((?x72122 (seq.unit (_ bv3 8))))
(let ((?x72230 (seq.++ ?x72122 (seq.++ ?x1100 (seq.++ ?x26924 (seq.++ ?x71655 (seq.++ ?x72445 ?x895)))))))
(let ((?x904 (seq.unit (_ bv234 8))))
(let ((?x27217 (seq.unit (_ bv43 8))))
(let ((?x71612 (seq.unit (_ bv125 8))))
(let ((?x30080 (seq.++ ?x71612 (seq.++ ?x27217 (seq.++ ?x904 (seq.++ ?x1728 (seq.++ ?x1728 ?x72230)))))))
(let ((?x72569 (seq.unit (_ bv55 8))))
(let ((?x70640 (seq.unit (_ bv64 8))))
(let ((?x2298 (seq.unit (_ bv156 8))))
(let ((?x68159 (seq.unit (_ bv144 8))))
(let ((?x68158 (seq.unit (_ bv31 8))))
(let ((?x27007 (seq.++ ?x68158 (seq.++ ?x68159 (seq.++ ?x2298 (seq.++ ?x70640 (seq.++ ?x72569 ?x30080)))))))
(let ((?x32963 (seq.unit (_ bv1 8))))
(let ((?x1274 (seq.unit (_ bv192 8))))
(let ((?x72697 (seq.++ ?x95454 (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 (seq.++ ?x32963 ?x27007)))))))
(let ((?x630 (seq.unit (_ bv200 8))))
(let ((?x806 (seq.unit (_ bv182 8))))
(let ((?x72337 (seq.++ ?x806 (seq.++ ?x630 (seq.++ ?x1274 (seq.++ ?x1728 (seq.++ ?x95454 ?x72697)))))))
(let ((?x61540 (seq.unit (_ bv6 8))))
(let ((?x30246 (seq.++ ?x1728 (seq.++ ?x70640 (seq.++ ?x1728 (seq.++ ?x70640 (seq.++ ?x61540 ?x72337)))))))
(let ((?x27392 (seq.unit (_ bv44 8))))
(let ((?x67578 (seq.unit (_ bv69 8))))
(let ((?x27419 (seq.++ ?x67578 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x27392 (seq.++ ?x1728 ?x30246)))))))
(let ((?x70322 (seq.unit (_ bv8 8))))
(let ((?x71608 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x95454 (seq.++ ?x70322 (seq.++ ?x1728 ?x27419)))))))
(let ((?x25805 (seq.++ ?x1728 (seq.++ ?x32963 (seq.++ ?x95454 (seq.++ ?x1728 (seq.++ ?x1728 ?x71608)))))))
(let ((?x72066 (seq.++ ?x95454 (seq.++ ?x1728 (seq.++ ?x1728 (seq.++ ?x1728 ?x25805))))))
(= input_2_L.net.frame_frame ?x72066)))))))))))))))))))))))))))))))))))))))
(check-sat)

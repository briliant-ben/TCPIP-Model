from pathlib import Path
import ast,copy,hashlib,importlib.util,json,subprocess,sys
W=Path(sys.argv[1]);O=Path(sys.argv[2]);sys.path.insert(0,str(W))
from protocol_lab.ir import load,validate,Machine,Uncovered
from protocol_lab.symbolic import model_hash,crosscheck_trace
from protocol_lab.codegen import generate
from protocol_lab.codegen.execute import build,commands
from protocol_lab.pipeline.worker import reference_case,compare_case
from protocol_lab.flow import run_scenario

def save(n,x):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
contract=json.loads((W/'virtual-contract.json').read_text());oracle_path=W/'spec/tcp-ipv4-virtual-link-oracle.json';assert sha(oracle_path)=='fa6b2d169a8f583d6144a7369a969d730c55139fce48cc34de352f66fbdd7a1a';oracle=json.loads(oracle_path.read_text());base=load(W/'model/tcp-ipv4-endpoint.json');assert model_hash(base)==contract['base_semantic_sha256']
# Execute only a statically restricted PURE offline IR builder. No subject
# protocol callback or archived binary is executed here.
p=W/'tools/tcp_ipv4_virtual_link.py';tree=ast.parse(p.read_text());functions={n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)};assert'build_virtual_link'in functions
allowed_names=functions|{'isinstance','type','dict','list','set','tuple','len','range','enumerate','any','all','sum','sorted','str','int','validate','require','model_hash','ValueError','AssertionError'}
attrs={'deepcopy','items','values','keys','get','append','copy','update','setdefault','dumps','loads','encode','sha256','hexdigest','format'}
for n in ast.walk(tree):
 if isinstance(n,ast.Import):assert all(x.name in {'copy','json','hashlib'}for x in n.names)
 if isinstance(n,ast.ImportFrom):assert (n.module=='protocol_lab.ir'and all(x.name in {'validate','require','ModelError'}for x in n.names))or(n.module=='protocol_lab.symbolic'and all(x.name=='model_hash'for x in n.names))
 if isinstance(n,ast.Attribute):assert n.attr in attrs and not isinstance(n.ctx,ast.Store)
 if isinstance(n,ast.Attribute)and n.attr=='format':assert isinstance(n.value,ast.Constant)and isinstance(n.value.value,str)and '__'not in n.value.value
 if isinstance(n,ast.Call)and isinstance(n.func,ast.Name):assert n.func.id in allowed_names
spec=importlib.util.spec_from_file_location('bounded_virtual_builder',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);candidate=module.build_virtual_link(base);assert model_hash(base)==contract['base_semantic_sha256'];validate(candidate)
ge=contract['old_frame_ge'];eq=contract['old_frame_eq'];flen=copy.deepcopy(ge['args'][0]);total=copy.deepcopy(eq['args'][1]['args'][2]['args'][1]);newge={'op':'ge','args':[flen,54]};neweq={'op':'or','args':[eq,{'op':'eq','args':[flen,{'op':'add','args':[14,total]}]}]}
def rewrite(n):
 if n==ge:return copy.deepcopy(newge)
 if n==eq:return copy.deepcopy(neweq)
 if isinstance(n,dict):return{k:rewrite(v)for k,v in n.items()}
 if isinstance(n,list):return[rewrite(v)for v in n]
 return n
expected=copy.deepcopy(base);expected['scope'][contract['scope_key']]=contract['scope_value'];expected['requirements']['VIRTUAL-ETHERNET-RX']=contract['required_new_requirement']
for r in expected['transitions']:
 if r['id']in contract['changed_rule_ids']:
  r['guard']=rewrite(r['guard']);r['requirements'].append('VIRTUAL-ETHERNET-RX')
assert candidate==expected,'Builder changed unrelated IR or did not implement exact approved boundary'
model_file=W/'model/tcp-ipv4-virtual-link.json';model_file.write_text(json.dumps(candidate,indent=2)+'\n');save('model-binding.json',dict(base_semantic_sha256=model_hash(base),candidate_semantic_sha256=model_hash(candidate),model_file_sha256=sha(model_file),changed_rules=len(contract['changed_rule_ids']),only_guard_requirement_scope_changes=True,oracle_sha256=sha(oracle_path)))
# Unknown bases must not silently acquire this pinned profile.
bad=copy.deepcopy(base);bad['protocol']+='-not-approved'
try:module.build_virtual_link(bad)
except (ValueError,AssertionError):pass
else:raise AssertionError('Builder accepted unapproved base')
generation=O/'generation';compiled=O/'build';generate(model_file,generation);c=build(generation,compiled);assert c['status']=='pass';records=[]
for case in oracle['cases']:
 folder=O/'cases'/case['id'];folder.mkdir(parents=True)
 scene=dict(scenario_version='0.2',id=case['id'],initial={},steps=[dict(at_ms=s['at_ms'],event=s['event'],fields=s['fields'])for s in oracle['prefix']]+[dict(at_ms=case['at_ms'],event='L.net.frame',fields=dict(frame=case['frame']))])
 ref=reference_case(candidate,scene)
 for row,step in zip(ref['trace'][:2],oracle['prefix']):assert row['emitted']==step['expected_emitted']
 assert all(ref['final']['variables'][k]==v for k,v in case['expected_variables'].items()),case['id']
 assert ref['final']['timers']==case['expected_timers'],case['id']
 negative=case['kind']=='model_gap'
 if negative:assert ref['error']and ref['error']['classification']=='model_gap'and len(ref['trace'])==2
 else:assert ref['error']is None and len(ref['trace'])==3 and ref['trace'][-1]['emitted']==case['expected_emitted']
 data=commands(candidate,scene);(folder/'native-input.txt').write_text(data);cp=subprocess.run([str(compiled/'protocol-native')],input=data,text=True,capture_output=True,timeout=30);(folder/'native.stdout').write_text(cp.stdout);(folder/'native.stderr').write_text(cp.stderr);rows=[json.loads(x)for x in cp.stdout.splitlines()];diff=compare_case(ref,rows,cp.returncode,negative);assert diff['status']=='pass',case['id'];save('cases/'+case['id']+'/reference.json',ref);save('cases/'+case['id']+'/difference.json',diff);save('cases/'+case['id']+'/scene.json',scene)
 formal=None
 if not negative:
  machine=run_scenario(candidate,scene);formal=crosscheck_trace(candidate,machine.trace,folder/'symbolic');assert formal['query']=='sat'and formal['status']=='match'
 records.append(dict(id=case['id'],kind=case['kind'],native_returncode=cp.returncode,reference_native='pass',formal='fixed_input_SAT_replay_match'if formal else'negative_reference_native_only'))
 save('case-progress.json',records)
# Original four frozen literal seeds remain byte-for-byte unchanged.
legacy=[]
for f in sorted((W/'scenarios/tcp-ipv4-endpoint').glob('*.json')):
 scene=json.loads(f.read_text());run_scenario(base,scene);machine=run_scenario(candidate,scene);ref=reference_case(candidate,scene);folder=O/'canonical-seeds'/f.stem;folder.mkdir(parents=True);data=commands(candidate,scene);(folder/'native-input.txt').write_text(data);cp=subprocess.run([str(compiled/'protocol-native')],input=data,text=True,capture_output=True,timeout=30);(folder/'native.stdout').write_text(cp.stdout);(folder/'native.stderr').write_text(cp.stderr);diff=compare_case(ref,[json.loads(x)for x in cp.stdout.splitlines()],cp.returncode,False);assert diff['status']=='pass';save('canonical-seeds/'+f.stem+'/difference.json',diff);formal=crosscheck_trace(candidate,machine.trace,folder/'symbolic');assert formal['query']=='sat'and formal['status']=='match';legacy.append(dict(id=scene['id'],seed_sha256=sha(f),reference_native='pass',fixed_input='sat_match'))
save('canonical-seed-results.json',legacy)
# Reference-only typed fault probe: overbroad extent admission still satisfies
# declared invariants but violates the independently frozen model_gap oracle.
fault=copy.deepcopy(candidate);target=next(r for r in fault['transitions']if r['id']=='T.C-ACCEPT-SYNACK-RESOLVED');badbare={'op':'ge','args':[flen,{'op':'add','args':[14,total]}]}
def broaden(n):
 if n==neweq:return{'op':'or','args':[copy.deepcopy(eq),copy.deepcopy(badbare)]}
 if isinstance(n,dict):return{k:broaden(v)for k,v in n.items()}
 if isinstance(n,list):return[broaden(v)for v in n]
 return n
target['guard']=broaden(target['guard']);validate(fault);case=next(c for c in oracle['cases']if c['id']=='partial-surplus-padding');machine=Machine(fault)
for s in oracle['prefix']:machine.dispatch(s['event'],s['fields'],s['at_ms'])
machine.dispatch('L.net.frame',{'frame':case['frame']},case['at_ms']);machine.check_invariants();assert machine.values['T.control']=='ESTABLISHED';save('fault-probe.json',dict(typed_IR_valid=True,invariants_still_pass=True,oracle_failure_detected=True,expected='model_gap',observed='accepted_connected',compiled_or_formal_fault_probe=False))
save('validation-summary.json',dict(status='finite_virtual_profile_gate_pass',cases=records,canonical_seeds=legacy,changed_rules=194,unknown_or_unbounded_proof_not_claimed=True,live_network=False,negative_formal_proof_not_claimed=True))
print('finite virtual profile reference/C/fixed-input Z3 gates complete')

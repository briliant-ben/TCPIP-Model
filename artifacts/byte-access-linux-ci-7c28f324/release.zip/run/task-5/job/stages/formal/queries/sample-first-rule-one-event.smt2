; benchmark generated from python API
(set-info :status unknown)
(declare-fun state_0 () Int)
(declare-fun now_0 () Int)
(declare-fun v_0_checksums_enabled () Bool)
(declare-fun v_0_payload () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_0_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_0_packet () (Seq (_ BitVec 8)))
(declare-fun v_0_udp_length () Int)
(declare-fun v_0_ip_length () Int)
(declare-fun v_0_udp_raw_checksum () Int)
(declare-fun v_0_udp_checksum () Int)
(declare-fun v_0_ip_checksum () Int)
(declare-fun choice_0 () Int)
(declare-fun v_1_ip_checksum () Int)
(declare-fun v_1_udp_checksum () Int)
(declare-fun v_1_udp_raw_checksum () Int)
(declare-fun v_1_ip_length () Int)
(declare-fun v_1_udp_length () Int)
(declare-fun v_1_packet () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_ip_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_wire () (Seq (_ BitVec 8)))
(declare-fun v_1_pseudoheader () (Seq (_ BitVec 8)))
(declare-fun v_1_udp_zero () (Seq (_ BitVec 8)))
(declare-fun v_1_payload () (Seq (_ BitVec 8)))
(declare-fun v_1_checksums_enabled () Bool)
(declare-fun now_1 () Int)
(declare-fun state_1 () Int)
(declare-fun input_0_app.configure_checksum_enabled () Bool)
(assert
 (= state_0 0))
(assert
 (= now_0 0))
(assert
 (= v_0_checksums_enabled true))
(assert
 (= v_0_payload (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_pseudoheader (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_udp_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_zero (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_ip_wire (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= v_0_packet (as seq.empty (Seq (_ BitVec 8)))))
(assert
 (= 0 v_0_udp_length))
(assert
 (= 0 v_0_ip_length))
(assert
 (= 0 v_0_udp_raw_checksum))
(assert
 (= 0 v_0_udp_checksum))
(assert
 (= 0 v_0_ip_checksum))
(assert
 (= choice_0 0))
(assert
 (let (($x116 (= v_1_ip_checksum v_0_ip_checksum)))
 (let (($x115 (= v_1_udp_checksum v_0_udp_checksum)))
 (let (($x114 (= v_1_udp_raw_checksum v_0_udp_raw_checksum)))
 (let (($x113 (= v_1_ip_length v_0_ip_length)))
 (let (($x112 (= v_1_udp_length v_0_udp_length)))
 (let (($x111 (= v_1_packet v_0_packet)))
 (let (($x110 (= v_1_ip_wire v_0_ip_wire)))
 (let (($x109 (= v_1_ip_zero v_0_ip_zero)))
 (let (($x108 (= v_1_udp_wire v_0_udp_wire)))
 (let (($x107 (= v_1_pseudoheader v_0_pseudoheader)))
 (let (($x106 (= v_1_udp_zero v_0_udp_zero)))
 (let (($x105 (= v_1_payload v_0_payload)))
 (let (($x262 (= v_1_checksums_enabled v_0_checksums_enabled)))
 (let (($x279 (= choice_0 (- 1))))
 (let (($x280 (and $x279 (= state_1 state_0) (= now_1 now_0) $x262 $x105 $x106 $x107 $x108 $x109 $x110 $x111 $x112 $x113 $x114 $x115 $x116)))
 (let (($x104 (= v_1_checksums_enabled input_0_app.configure_checksum_enabled)))
 (let (($x103 (= 0 state_1)))
 (let (($x102 (= choice_0 0)))
 (let (($x100 (>= now_1 now_0)))
 (let (($x51 (= state_0 0)))
 (let (($x117 (and and $x51 $x100 true $x102 $x103 $x104 $x105 $x106 $x107 $x108 $x109 $x110 $x111 $x112 $x113 $x114 $x115 $x116)))
 (or $x117 $x280)))))))))))))))))))))))
(assert
 (>= choice_0 0))
(check-sat)

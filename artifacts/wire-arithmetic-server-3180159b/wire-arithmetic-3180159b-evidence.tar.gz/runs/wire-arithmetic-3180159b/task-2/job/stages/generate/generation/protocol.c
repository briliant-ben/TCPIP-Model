#define STRING_COUNT 1
/* Native support primitives. Protocol guards/actions are generated C below. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#define LOG_CAP 131072
#define FIELD_CAP 64
#define SEQ_MOD INT64_C(4294967296)
typedef struct { char data[LOG_CAP]; size_t size; } Buffer;
const char *failure = NULL;
void text(Buffer *b, const char *s) {
    size_t n=strlen(s);
    if(n>=LOG_CAP-b->size) { failure="output_capacity"; return; }
    memcpy(b->data+b->size,s,n+1); b->size+=n;
}
void number(Buffer *b,int64_t n) { char s[32]; snprintf(s,sizeof(s),"%" PRId64,n); text(b,s); }
int64_t add(int64_t a,int64_t b) {
    if((b>0 && a>INT64_MAX-b)||(b<0 && a<INT64_MIN-b)) {failure="integer_overflow";return 0;}
    return a+b;
}
int64_t sub(int64_t a,int64_t b) {
    if((b>0 && a<INT64_MIN+b)||(b<0 && a>INT64_MAX+b)) {failure="integer_overflow";return 0;}
    return a-b;
}
int64_t mul(int64_t a,int64_t b) {
    if(a==0||b==0)return 0;
    if((a==-1&&b==INT64_MIN)||(b==-1&&a==INT64_MIN)) {failure="integer_overflow";return 0;}
    if((a>0 && b>0 && a>INT64_MAX/b)||(a>0 && b<0 && b<INT64_MIN/a)||
       (a<0 && b>0 && a<INT64_MIN/b)||(a<0 && b<0 && a<INT64_MAX/b)) {
        failure="integer_overflow";return 0;
    }
    return a*b;
}
int64_t seqadd(int64_t a,int64_t b) {
    int64_t n=(a+b%SEQ_MOD)%SEQ_MOD; return n<0?n+SEQ_MOD:n;
}
int64_t distance(int64_t a,int64_t b) { return (b-a+SEQ_MOD)%SEQ_MOD; }
int64_t minimum(int64_t a,int64_t b) { return a<b?a:b; }
int valid(int64_t n,int kind) {
    return kind==0 || (kind==1 && (n==0||n==1)) || (kind==2 && n>=0 && n<SEQ_MOD) || (kind==4 && n>=0 && n<STRING_COUNT);
}

void json_string(Buffer *out,const char *s) {
    const unsigned char *p=(const unsigned char *)s;char escaped[8];
    text(out,"\"");
    for(;*p;p++) {
        if(*p=='"'||*p=='\\'){escaped[0]='\\';escaped[1]=(char)*p;escaped[2]=0;text(out,escaped);}
        else if(*p<32){snprintf(escaped,sizeof(escaped),"\\u%04x",*p);text(out,escaped);}
        else {escaped[0]=(char)*p;escaped[1]=0;text(out,escaped);}
    }
    text(out,"\"");
}
/* Bytes are value types. Capacity is an explicit execution domain, never silent
   truncation. IR slice arguments are OFFSET and COUNT, clamped independently. */
#define BYTE_CAP 4096
#define INPUT_CAP (2*BYTE_CAP*FIELD_CAP+4096)
typedef struct { size_t len; unsigned char data[BYTE_CAP]; } Bytes;
Bytes byte_literal(const unsigned char *p,size_t n) {
    Bytes out={0};
    if(n>BYTE_CAP){failure="byte_capacity";return out;}
    out.len=n;if(n)memcpy(out.data,p,n);return out;
}
Bytes byte_concat(Bytes a,Bytes b) {
    Bytes out={0};
    if(a.len>BYTE_CAP||b.len>BYTE_CAP||b.len>BYTE_CAP-a.len){failure="byte_capacity";return out;}
    out.len=a.len+b.len;memcpy(out.data,a.data,a.len);memcpy(out.data+a.len,b.data,b.len);return out;
}
Bytes byte_slice(Bytes a,int64_t offset,int64_t count) {
    Bytes out={0};size_t start,n;
    if(a.len>BYTE_CAP){failure="byte_capacity";return out;}
    start=offset<0?0:(uint64_t)offset>a.len?a.len:(size_t)offset;
    n=count<0?0:(uint64_t)count>a.len-start?a.len-start:(size_t)count;
    out.len=n;if(n)memcpy(out.data,a.data+start,n);return out;
}
int byte_equal(Bytes a,Bytes b) {return a.len==b.len&&memcmp(a.data,b.data,a.len)==0;}
Bytes byte_pack8(int64_t n) {
    unsigned char b[1]={(uint8_t)n};return byte_literal(b,1);
}
Bytes byte_pack16be(int64_t n) {
    uint16_t v=(uint16_t)n;unsigned char b[2]={(unsigned char)(v>>8),(unsigned char)(v&255)};
    return byte_literal(b,2);
}
int64_t byte_checksum16(Bytes a) {
    size_t i;uint32_t sum=0;
    if(a.len>BYTE_CAP){failure="byte_capacity";return 0;}
    for(i=0;i<a.len;i+=2){
        uint32_t word=((uint32_t)a.data[i]<<8)+(i+1<a.len?a.data[i+1]:0);
        sum+=word;sum=(sum&UINT32_C(65535))+(sum>>16);
    }
    return (int64_t)(UINT32_C(65535)-sum);
}
void byte_json(Buffer *out,Bytes a) {
    size_t i;text(out,"[");for(i=0;i<a.len;i++){if(i)text(out,",");number(out,a.data[i]);}text(out,"]");
}
int byte_nibble(char c) {
    if(c>='0'&&c<='9')return c-'0';
    if(c>='a'&&c<='f')return c-'a'+10;
    if(c>='A'&&c<='F')return c-'A'+10;
    return -1;
}
int parse_bytes(const char *s,Bytes *out) {
    size_t n,i;*out=(Bytes){0};
    if(!s||s[0]!='b'||s[1]!=':'){failure="invalid_bytes_token";return 0;}
    n=strlen(s+2);
    if(n%2){failure="invalid_bytes_token";return 0;}
    if(n/2>BYTE_CAP){failure="byte_capacity";return 0;}
    for(i=0;i<n/2;i++){
        int a=byte_nibble(s[2+2*i]),b=byte_nibble(s[3+2*i]);
        if(a<0||b<0){failure="invalid_bytes_token";return 0;}out->data[i]=(unsigned char)((a<<4)|b);
    }
    out->len=n/2;return 1;
}

enum { NV=5, NB=0, NT=0 };
typedef struct { int state; int64_t now,v[NV?NV:1],due[NT?NT:1]; Bytes b[NB?NB:1]; int active[NT?NT:1]; } Machine;
const char *state_names[]={"\122\105\101\104\131"};
const char *event_names[]={"\141\160\160\056\143\157\156\146\151\147\165\162\145\137\143\150\145\143\153\163\165\155","\141\160\160\056\163\145\156\144","\156\145\164\056\144\141\164\141\147\162\141\155"};
const char *timer_names[]={""};
int event_origin[]={0,0,0};
int event_fields[]={1,3,6};
int event_kinds[3][FIELD_CAP]={{1},{0,0,0},{0,0,0,0,0,1}};
int timer_events[]={0};
int variable_kinds[]={1,0,0,0,0};
int variable_byte_index[]={-1,-1,-1,-1,-1};
const char *variable_names[]={"\143\150\145\143\153\163\165\155\163\137\145\156\141\142\154\145\144","\164\170\137\143\157\165\156\164","\162\170\137\143\157\165\156\164","\144\151\163\143\141\162\144\137\143\157\165\156\164","\154\141\163\164\137\160\141\171\154\157\141\144\137\154\145\156\147\164\150"};
const char *source_json_strings[]={"\042\160\141\171\154\157\141\144\137\154\145\156\147\164\150\137\157\165\164\163\151\144\145\137\151\160\166\064\137\160\162\157\146\151\154\145\042"};
const char *source_json(int64_t i) { if(i<0||i>=STRING_COUNT){failure="string_domain";return "\042\042";}return source_json_strings[i];}
void initialize(Machine *m) { memset(m,0,sizeof(*m)); m->state=0;
m->v[0]=1;
m->v[1]=INT64_C(0);
m->v[2]=INT64_C(0);
m->v[3]=INT64_C(0);
m->v[4]=INT64_C(0);
}
int invariants(Machine *m) { (void)m; if(failure)return 0;
if(!((((m->v[1]>=INT64_C(0))&&(m->v[2]>=INT64_C(0)))&&(m->v[3]>=INT64_C(0))))) {failure="\151\156\166\141\162\151\141\156\164\072\125\055\103\117\125\116\124\105\122\123\055\116\117\116\116\105\107\101\124\111\126\105";return 0;}
if(!(((m->v[4]>=INT64_C(0))&&(m->v[4]<=INT64_C(65507))))) {failure="\151\156\166\141\162\151\141\156\164\072\125\055\104\105\114\111\126\105\122\131\055\114\105\116\107\124\110";return 0;}
return failure==NULL; }
void snapshot(Buffer *out,Machine *m) { int first=1;
text(out,"\173\042\163\164\141\164\145\042\072");
switch(m->state) {
case 0:
text(out,"\042\122\105\101\104\131\042");
break;
default:failure="invalid_state";}
text(out,"\054\042\166\141\162\151\141\142\154\145\163\042\072\173");
text(out,"\042\143\150\145\143\153\163\165\155\163\137\145\156\141\142\154\145\144\042\072");
text(out,m->v[0]?"true":"false");
text(out,"\054\042\164\170\137\143\157\165\156\164\042\072");
number(out,m->v[1]);
text(out,"\054\042\162\170\137\143\157\165\156\164\042\072");
number(out,m->v[2]);
text(out,"\054\042\144\151\163\143\141\162\144\137\143\157\165\156\164\042\072");
number(out,m->v[3]);
text(out,"\054\042\154\141\163\164\137\160\141\171\154\157\141\144\137\154\145\156\147\164\150\042\072");
number(out,m->v[4]);
text(out,"\175\054\042\164\151\155\145\162\163\042\072\173");
(void)first;
text(out,"\175\175");
}
int fire(Machine *m,int event,int64_t *f,Bytes *bf,int expiring,Buffer *log) { int match=-1,count=0; Buffer messages={{0},0}; int emitted=0; (void)f; (void)bf; (void)emitted;
if(m->state==0&&event==0&&(1)) {match=0;count++;}
if(m->state==0&&event==1&&(((((f[0]>=INT64_C(0))&&(f[0]<=INT64_C(65535)))&&((f[1]>=INT64_C(1))&&(f[1]<=INT64_C(65535))))&&((f[2]>=INT64_C(0))&&(f[2]<=INT64_C(65507)))))) {match=1;count++;}
if(m->state==0&&event==1&&(((((f[0]>=INT64_C(0))&&(f[0]<=INT64_C(65535)))&&((f[1]>=INT64_C(1))&&(f[1]<=INT64_C(65535))))&&(!((f[2]>=INT64_C(0))&&(f[2]<=INT64_C(65507))))))) {match=2;count++;}
if(m->state==0&&event==2&&((((((((f[0]>=INT64_C(0))&&(f[0]<=INT64_C(65535)))&&(f[1]==INT64_C(8080)))&&((f[2]>=INT64_C(0))&&(f[2]<=INT64_C(65535))))&&((f[3]>=INT64_C(0))&&(f[3]<=INT64_C(65515))))&&((f[4]>=INT64_C(0))&&(f[4]<=INT64_C(65535))))&&(!((f[2]>=INT64_C(8))&&(f[2]<=f[3])))))) {match=3;count++;}
if(m->state==0&&event==2&&((((((((((f[0]>=INT64_C(0))&&(f[0]<=INT64_C(65535)))&&(f[1]==INT64_C(8080)))&&((f[2]>=INT64_C(0))&&(f[2]<=INT64_C(65535))))&&((f[3]>=INT64_C(0))&&(f[3]<=INT64_C(65515))))&&((f[4]>=INT64_C(0))&&(f[4]<=INT64_C(65535))))&&((f[2]>=INT64_C(8))&&(f[2]<=f[3])))&&(!(f[4]==INT64_C(0))))&&(!f[5])))) {match=4;count++;}
if(m->state==0&&event==2&&(((((((((f[0]>=INT64_C(0))&&(f[0]<=INT64_C(65535)))&&(f[1]==INT64_C(8080)))&&((f[2]>=INT64_C(0))&&(f[2]<=INT64_C(65535))))&&((f[3]>=INT64_C(0))&&(f[3]<=INT64_C(65515))))&&((f[4]>=INT64_C(0))&&(f[4]<=INT64_C(65535))))&&((f[2]>=INT64_C(8))&&(f[2]<=f[3])))&&(f[4]==INT64_C(0))))) {match=5;count++;}
if(m->state==0&&event==2&&((((((((((f[0]>=INT64_C(0))&&(f[0]<=INT64_C(65535)))&&(f[1]==INT64_C(8080)))&&((f[2]>=INT64_C(0))&&(f[2]<=INT64_C(65535))))&&((f[3]>=INT64_C(0))&&(f[3]<=INT64_C(65515))))&&((f[4]>=INT64_C(0))&&(f[4]<=INT64_C(65535))))&&((f[2]>=INT64_C(8))&&(f[2]<=f[3])))&&(!(f[4]==INT64_C(0))))&&f[5]))) {match=6;count++;}
if(failure)return 0;
if(count!=1){failure=count?"rule_conflict":"uncovered_event";return 0;} if(expiring>=0)m->active[expiring]=0; switch(match) {
case 0: {
m->v[0]=f[0];
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\103\117\116\106\111\107\125\122\105\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\103\110\105\103\113\123\125\115\055\104\105\106\101\125\114\124\042\054\040\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\143\157\156\146\151\147\165\162\145\137\143\150\145\143\153\163\165\155\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\145\156\141\142\154\145\144\042\072");
text(log,f[0]?"true":"false");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 1: {
m->v[1]=add(m->v[1],INT64_C(1));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\165\144\160\056\144\141\164\141\147\162\141\155\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(&messages,f[0]);
text(&messages,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\154\145\156\147\164\150\042\072");
number(&messages,add(f[2],INT64_C(8)));
text(&messages,"\054\042\143\150\145\143\153\163\165\155\137\160\162\145\163\145\156\164\042\072");
text(&messages,m->v[0]?"true":"false");
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\123\105\116\104\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\114\105\116\107\124\110\042\054\040\042\125\104\120\055\123\117\125\122\103\105\055\120\117\122\124\042\054\040\042\125\104\120\055\103\110\105\103\113\123\125\115\055\104\105\106\101\125\114\124\042\054\040\042\125\104\120\055\111\116\124\105\122\106\101\103\105\042\054\040\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\163\145\156\144\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(log,f[0]);
text(log,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(log,f[1]);
text(log,"\054\042\160\141\171\154\157\141\144\137\154\145\156\147\164\150\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 2: {
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\165\144\160\056\145\162\162\157\162\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\162\145\141\163\157\156\042\072");
text(&messages,source_json(0));
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\123\105\116\104\055\123\111\132\105\055\105\122\122\117\122\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\141\160\160\056\163\145\156\144\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(log,f[0]);
text(log,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(log,f[1]);
text(log,"\054\042\160\141\171\154\157\141\144\137\154\145\156\147\164\150\042\072");
number(log,f[2]);
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 3: {
m->v[3]=add(m->v[3],INT64_C(1));
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\104\111\123\103\101\122\104\055\114\105\116\107\124\110\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\114\105\116\107\124\110\042\054\040\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\147\162\141\155\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(log,f[0]);
text(log,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(log,f[1]);
text(log,"\054\042\154\145\156\147\164\150\042\072");
number(log,f[2]);
text(log,"\054\042\141\166\141\151\154\141\142\154\145\137\154\145\156\147\164\150\042\072");
number(log,f[3]);
text(log,"\054\042\143\150\145\143\153\163\165\155\042\072");
number(log,f[4]);
text(log,"\054\042\163\165\155\137\166\141\154\151\144\042\072");
text(log,f[5]?"true":"false");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 4: {
m->v[3]=add(m->v[3],INT64_C(1));
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\104\111\123\103\101\122\104\055\103\110\105\103\113\123\125\115\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\103\110\105\103\113\123\125\115\055\122\105\103\105\111\126\105\042\054\040\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\147\162\141\155\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(log,f[0]);
text(log,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(log,f[1]);
text(log,"\054\042\154\145\156\147\164\150\042\072");
number(log,f[2]);
text(log,"\054\042\141\166\141\151\154\141\142\154\145\137\154\145\156\147\164\150\042\072");
number(log,f[3]);
text(log,"\054\042\143\150\145\143\153\163\165\155\042\072");
number(log,f[4]);
text(log,"\054\042\163\165\155\137\166\141\154\151\144\042\072");
text(log,f[5]?"true":"false");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 5: {
m->v[2]=add(m->v[2],INT64_C(1));
if(failure)return 0;
m->v[4]=sub(f[2],INT64_C(8));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\165\144\160\056\144\145\154\151\166\145\162\171\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(&messages,f[0]);
text(&messages,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\160\141\171\154\157\141\144\137\154\145\156\147\164\150\042\072");
number(&messages,m->v[4]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\104\105\114\111\126\105\122\055\116\117\055\103\110\105\103\113\123\125\115\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\114\105\116\107\124\110\042\054\040\042\125\104\120\055\123\117\125\122\103\105\055\120\117\122\124\042\054\040\042\125\104\120\055\103\110\105\103\113\123\125\115\055\132\105\122\117\042\054\040\042\125\104\120\055\111\116\124\105\122\106\101\103\105\042\054\040\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\147\162\141\155\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(log,f[0]);
text(log,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(log,f[1]);
text(log,"\054\042\154\145\156\147\164\150\042\072");
number(log,f[2]);
text(log,"\054\042\141\166\141\151\154\141\142\154\145\137\154\145\156\147\164\150\042\072");
number(log,f[3]);
text(log,"\054\042\143\150\145\143\153\163\165\155\042\072");
number(log,f[4]);
text(log,"\054\042\163\165\155\137\166\141\154\151\144\042\072");
text(log,f[5]?"true":"false");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
case 6: {
m->v[2]=add(m->v[2],INT64_C(1));
if(failure)return 0;
m->v[4]=sub(f[2],INT64_C(8));
if(failure)return 0;
{
if(emitted++)text(&messages,",");
text(&messages,"\173\042\155\145\163\163\141\147\145\042\072\042\165\144\160\056\144\145\154\151\166\145\162\171\042\054\042\146\151\145\154\144\163\042\072\173");
text(&messages,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(&messages,f[0]);
text(&messages,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(&messages,f[1]);
text(&messages,"\054\042\160\141\171\154\157\141\144\137\154\145\156\147\164\150\042\072");
number(&messages,m->v[4]);
text(&messages,"\175\175");
}
if(failure)return 0;
m->state=0; if(!invariants(m))return 0;
text(log,"\173\042\163\164\141\164\165\163\042\072\042\164\162\141\156\163\151\164\151\157\156\042\054\042\164\162\141\156\163\151\164\151\157\156\042\072\042\125\055\104\105\114\111\126\105\122\055\103\110\105\103\113\123\125\115\042\054\042\162\145\161\165\151\162\145\155\145\156\164\163\042\072\133\042\125\104\120\055\114\105\116\107\124\110\042\054\040\042\125\104\120\055\123\117\125\122\103\105\055\120\117\122\124\042\054\040\042\125\104\120\055\103\110\105\103\113\123\125\115\055\122\105\103\105\111\126\105\042\054\040\042\125\104\120\055\111\116\124\105\122\106\101\103\105\042\054\040\042\125\104\120\055\120\122\117\106\111\114\105\042\135\054\042\164\151\155\145\137\155\163\042\072");
number(log,m->now);
text(log,"\054\042\145\166\145\156\164\042\072\173\042\156\141\155\145\042\072\042\156\145\164\056\144\141\164\141\147\162\141\155\042\054\042\146\151\145\154\144\163\042\072\173");
text(log,"\042\163\157\165\162\143\145\137\160\157\162\164\042\072");
number(log,f[0]);
text(log,"\054\042\144\145\163\164\151\156\141\164\151\157\156\137\160\157\162\164\042\072");
number(log,f[1]);
text(log,"\054\042\154\145\156\147\164\150\042\072");
number(log,f[2]);
text(log,"\054\042\141\166\141\151\154\141\142\154\145\137\154\145\156\147\164\150\042\072");
number(log,f[3]);
text(log,"\054\042\143\150\145\143\153\163\165\155\042\072");
number(log,f[4]);
text(log,"\054\042\163\165\155\137\166\141\154\151\144\042\072");
text(log,f[5]?"true":"false");
text(log,"\175\175\054\042\141\146\164\145\162\042\072");
snapshot(log,m);
text(log,"\054\042\145\155\151\164\164\145\144\042\072\133");
text(log,messages.data);
text(log,"\135\175\012");
break; }
default:failure="invalid_rule";return 0;} return failure==NULL; }
/* Line interface for independent execution; no JSON model is read at runtime.
   I variable-index integer (before B), B, D milliseconds event integer-fields,
   T milliseconds. Each operation is committed atomically after all checks. */
int advance(Machine *m,int64_t at,Buffer *log) {
    int steps=0;
    if(at<m->now){failure="nonmonotonic_time";return 0;}
    for(;;) {
        int next=-1,i;
        for(i=0;i<NT;i++)if(m->active[i] && (next<0||m->due[i]<m->due[next]||
             (m->due[i]==m->due[next]&&strcmp(timer_names[i],timer_names[next])<0)))next=i;
        if(next<0||m->due[next]>at)break;
        if(++steps>4096){failure="timer_step_capacity";return 0;}
        m->now=m->due[next];
        if(!fire(m,timer_events[next],NULL,NULL,next,log)){if(!failure)failure="internal_transition_failure";return 0;}
    }
    m->now=at;return 1;
}
int parse_integer(const char *s,int64_t *out) {
    char *end; long long n;
    if(!s||!*s)return 0;
    errno=0;n=strtoll(s,&end,10);
    if(errno||*end||n<INT64_MIN||n>INT64_MAX)return 0;
    *out=(int64_t)n;return 1;
}
void reply(Machine *m,const char *status,const char *error) {
    Buffer out={{0},0};
    text(&out,"{\"status\":\"");text(&out,status);text(&out,"\"");
    if(error){text(&out,",\"failure\":");json_string(&out,error);}
    text(&out,",\"snapshot\":");snapshot(&out,m);text(&out,"}\n");fputs(out.data,stdout);
}
int snapshot_fits(Machine *m) {
    Buffer preview={{0},0};snapshot(&preview,m);
    if(preview.size>LOG_CAP-4096)failure="output_capacity";
    return failure==NULL;
}
int main(void) {
    Machine committed;char line[INPUT_CAP];int begun=0,errors=0;
    initialize(&committed);
    while(fgets(line,sizeof(line),stdin)) {
        char *tokens[FIELD_CAP+4];int count=0,overflow=0,i,event=-1;char *token;
        int64_t at=0,fields[FIELD_CAP]={0};Bytes byte_fields[FIELD_CAP]={{0}};Machine candidate=committed;Buffer log={{0},0};
        failure=NULL;
        if(!strchr(line,'\n')&&!feof(stdin)){failure="input_capacity";while((i=getchar())!='\n'&&i!=EOF){} }
        token=strtok(line," \t\r\n");
        while(token){if(count<(int)(sizeof(tokens)/sizeof(tokens[0])))tokens[count++]=token;else overflow=1;token=strtok(NULL," \t\r\n");}
        if(!count)continue;
        if(overflow)failure="input_capacity";
        if(!failure && !strcmp(tokens[0],"I")) {
            int64_t index,value;
            if(begun||count!=3||!parse_integer(tokens[1],&index)||index<0||index>=NV)failure="invalid_initial_override";
            else if(variable_kinds[index]==3)parse_bytes(tokens[2],&candidate.b[variable_byte_index[index]]);
            else if(!parse_integer(tokens[2],&value)||!valid(value,variable_kinds[index]))failure="invalid_initial_override";
            else candidate.v[index]=value;
            if(!failure&&snapshot_fits(&candidate)){committed=candidate;continue;}
        } else if(!failure && !strcmp(tokens[0],"B")) {
            if(begun||count!=1)failure="invalid_begin";
            else if(invariants(&candidate)){begun=1;reply(&committed,"ready",NULL);continue;}
        } else if(!failure && (!strcmp(tokens[0],"D")||!strcmp(tokens[0],"T")
#ifdef WIRE_PROFILE
                  ||!strcmp(tokens[0],"P")
#endif
                  )) {
            if(!begun||count<2||!parse_integer(tokens[1],&at))failure="invalid_command";
            if(!failure && !strcmp(tokens[0],"D")) {
                if(count<3)failure="invalid_command";
                else {
                    for(i=0;i<(int)(sizeof(event_names)/sizeof(event_names[0]));i++)if(!strcmp(tokens[2],event_names[i]))event=i;
                    if(event<0)failure="unknown_event";
                    else if(event_origin[event])failure="timer_injection";
                    else if(count!=3+event_fields[event])failure="event_field_mismatch";
                    else for(i=0;i<event_fields[event]&&!failure;i++) {
                        if(event_kinds[event][i]==3)parse_bytes(tokens[3+i],&byte_fields[i]);
                        else if(!parse_integer(tokens[3+i],&fields[i])||!valid(fields[i],event_kinds[event][i]))failure="invalid_event_value";
                    }
                }
            }
#ifdef WIRE_PROFILE
            else if(!failure && !strcmp(tokens[0],"P")) {
                if(count!=3)failure="invalid_wire_command";
                else if(wire_decode(tokens[2],fields))event=WIRE_EVENT;
            }
#endif
            else if(!failure && count!=2)failure="invalid_command";
            if(!failure && advance(&candidate,at,&log)) {
                if(event>=0){if(!fire(&candidate,event,fields,byte_fields,-1,&log)&&!failure)failure="internal_transition_failure";}
                else if(!invariants(&candidate)&&!failure)failure="internal_invariant_failure";
            }
            if(!failure&&snapshot_fits(&candidate)){committed=candidate;fputs(log.data,stdout);reply(&committed,"ok",NULL);continue;}
        } else if(!failure)failure="invalid_command";
        errors++;reply(&committed,"error",failure?failure:"internal_error");
    }
    if(ferror(stdin))return 2;
    if(!begun)return 2;
    return errors?1:0;
}

